# Unit-reply phase-0 qualification plan and driver review

Read-only audit; no builds, tests, lint, profiles, benchmarks, or tracked changes. This review checks scripts/plan/current initial config, not a completed measurement or production acceptance. Final executable proof and final refreshed freeze remain pending.

## Disposition

No matrix/runner/claim blocker for the declared phase-0 diagnostic. Proceed only after final query/error/lifetime/child-overlay proof is reviewed, all local tools are stopped, and the final config is refreshed and frozen. The initial config already maps exactly all ten required binary identities and records the official local Go 1.26.8 compiler and PGO-off for all roles. All six production Wasm/module fingerprints in that config match current bytes. The configuration must be regenerated after final proof sources/logs and reviewer notes, as planned; an earlier provisional freeze cannot substitute for the final one.

The plan is internally consistent: 18 groups, 66 sequential benchmark processes/pass, two rounds of seven samples = 924 raw rows. Twelve DD/corpus groups have baseline/probe/control/reference, the raw guest and synthetic ReplyUnit groups have three roles, and four complete-stream leaves have three real linked roles. Expected metric coverage is 280 P1 rows, 168 P16 stream rows, and 476 original/raw/runtime framework-P16 rows. Explicit P1/P16 leaf metrics, not the testing suffix16, determine the measured processor claims for the first 448 rows. The remaining rows are honestly described as framework-P16, with unchanged source containing no leaf processor override; they do not claim the same executable instrumentation.

Canonical baselines/controls/probes remain separate from additional proof overlays. The control's ordinary runtime binary is byte-identical to baseline. The changed stream binaries are real roles: Close invokes ResultUnit, so unchanged guest sources do not make the linked stream candidate identical. Streaming covers complete resource lifetime and existing bounded output retention, rather than isolated writes. P16 fixed and holdout corpora use one and sixteen homes. P1/default-stream leaves are absent; no P1 equivalence or production qualification claim follows. Any later private production qualification must add the P1/default-stream guard. Original scalar is an increasing calibrated prefix with evolving sketch state, while cyclic corpora and batch leaves have different histories; these remain distinct workloads rather than additive components.

The primary original facade baseline and the same-call-shape old ResultUnit control both constrain promotion. Original scalar must gain against both in both rounds; repeated detected losses against a consistent comparator disqualify promotion. A synthetic ReplyUnit improvement, raw-guest/link change, or a one-round gain is insufficient. Single-round losses, mixed signs, nondetections and holdouts must all be reported even if they do not independently trip the preregistered rule. Exploratory p-values are unadjusted; nondetection is not equivalence. The phase-0 rule permits at most a separate private production specification, not shipment or M1 acceptance. Old profile cumulative11.17% and isolated8.597ns are nonadditive context; the1e9 iteration cap resulted in about8.6 seconds despite requested10 seconds.

The runner executes one exact anchored benchmark selector per process, requires exactly one Benchmark row/PASS/expected names and allocation metrics, validates every required actual-procs value, preserves full stdout/command/start/end/exit, and rejects process failures. Alternating order is mirrored for the independent longer confirmation, with reversed group order. There is no selected retiming, outlier filter, or concurrency in the runner. Frozen inputs are checked before, between rounds and after; CPU governor/boost and affinity are checked independently of observed clock frequencies. GOGC/GOMEMLIMIT/GODEBUG are reset to agreed defaults and recorded. Operator/local-tool isolation is explicitly external to the script; unrelated system work cannot be proven absent.

Freeze identifies all role binaries, regenerated overlay sources, production source/tests/harnesses, scripts, profiles, proof files, tool binaries and reference provenance; all existing benchmark harnesses are compared with the baseline revision. Build metadata checks Go1.26.8/CGO0/amd64/v1 and separately records explicit PGO-off argv. Historical official/compiler-distribution relocation is disclosed, so older74af... times are not compared with freshc73d... binaries. All fresh roles and reference use the same official compiler.

Summarization requires the entire row count and seven unique samples per role/round, keeps original process metrics, and changes only derived benchmark names/package grouping for benchstat. Secondary control→probe reports are explicit, not silently substituted for the untouched primary comparison. Archive assembly keeps every raw process, exact script/source/proof bytes and derived statistic with a relative-regular-member SHA manifest, preserving the unversioned reference's selected authored source bytes; executables/committed production modules are reproducible identities rather than included duplicate payloads. Full archive coverage and hashes still require a post-run independent audit.

## Reviewed identities

```json
{
  ".cache/unit-reply-phase0/qualification-plan.json": "bfc5a0a0c33f6bdfc177be2a6b8bc9c17ec0dfdbddaa6d5770e718f2b80ef7a5",
  ".cache/unit-reply-phase0/decision-plan.json": "eafda1565b8beff40b0f3514c4a1cbe911b5a0ce2dc80b79e7f8b8296fc7d49b",
  ".cache/unit-reply-phase0/qualification-config.json": "4675528e06b75ef91079d49c7f9fdcaf81debcd39c4fe104ab1a8f0e6ea1c7c9",
  ".cache/unit-reply-phase0/prepare-config.py": "897c98274391cdb1e8fa4624502159ee7b0d30d8d418f27b44a906a62b629438",
  ".cache/unit-reply-phase0/common.py": "15b03b50c3f1cb8afd06083076999784ec06c5636429c5d36b5b974d9fa98dd2",
  ".cache/unit-reply-phase0/freeze.py": "f73011f748e6496ac1a70e671a8d593478ced502aba66d3d15581b4c630eaa1c",
  ".cache/unit-reply-phase0/paired.py": "2159861a5f3c47a505f4b5041228024de0e1e4d9fa808ba9aae21a2450f421e5",
  ".cache/unit-reply-phase0/summarize.py": "79e33f31e1d57fb30a2d13f5e0d8c7b108d218bdba1ed8178ca3d09ae21f0501",
  ".cache/unit-reply-phase0/archive.py": "2c73d56d0d49870e58443d2b3055a9fbdc5794e4a2a61f48b1f062469457d2f8"
}
```
