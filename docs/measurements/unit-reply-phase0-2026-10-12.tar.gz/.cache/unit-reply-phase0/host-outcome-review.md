# Host outcome audit: checked unit-reply phase 0

2026-10-12, read-only evidence review. No builds, tests, lint, profiling or
measurements executed here; this ignored note is the only write. Retain evidence
only: the preregistered promotion rule fails, and repeated SQL holdout losses
independently forbid promotion. No production specification/implementation,
public API/ABI change, or M1 acceptance follows.

## Provenance and comparison identity

All430 frozen byte hashes match at audit.924 rows split462/462 for seven
alternating500ms and seven reversed-order1s samples. Each role has252 rows
except independent reference168. There are280 matched rows reporting actualP1,
168 stream rows reporting actualP16 and476 original/raw/runtime rows lacking an
in-window metric. Framework16 and runner GOMAXPROCS16 are recorded; do not claim
the suffix itself proves in-window processors for those476 rows. Timing uses
CGO0/GOAMD64v1/PGOoff/defaultGC-memory-debug-experiment settings; powersave governor,
boost enabled and frequency snapshots are recorded without a fixed-frequency
claim. Root completed isolated timing before subsequent sequential quality gates.

All new consumer/build/proof commands use the exact official Go1.26.8 executable
under .cache/toolchains/go1.26.8/go/bin/go. Root preserved the discarded system
Go1.26.9 preflight; quality toolchain is now1.27.2. Old/new binary hashes and
timings are not compared across the changed Go distribution/GOROOT. Current
source is clean6be3980; Range/ResultView/Call/guest/shim/Wasm sources are unchanged
in the ignored candidate. Authored generator overlay regenerates all three
facades to call existing ResultUnit. Control uses original ResultUnit;
probe uses captured-once checked ResultUnit/cold-tail specialization. The runtime
baseline/control binaries are byte-identical because the control changes only
generator/facades; runtime-probe has the actual runtime experiment.

Unlike the preceding store-guard round, streaming now has THREE REAL distinct
roles: original facade/runtime, unchanged-ResultUnit call shape, and specialization.
Existing generated resource destructors already call ResultUnit, so the runtime
change affects timed stream Close. These are not identical-binary bracket controls.
Guest Wasm/payload remains unchanged, and no module-only optimization is retained.

Fresh independent reference:56 before/after source hashes unchanged; ten build/
correctness commands and48 functional1x corpus leaves pass. Its own locked Rust1.97,
Binaryen133, wasm2go0.4.16 and own hardener reproduce Wasm8bda5ff7… and module
5ff25314…; officialGo1.26.8 consumer binary is5c4f361a… rather than the prior
systemGo ELFf8846dd9…. This was recorded rather than forced. ABI2 borrowed-input,
background-context/four-instance ownership and original batch/trace corpus
differences remain contextual limits; matching success corpora do not prove
contract equivalence. No Cocoon runtime/generator/guest/hardener transplant.

## No-go and material negatives

Original supported scalar87.41→87.03 ns(-0.435%,p=.456) /88.38→88.59 ns(+0.238%,
p=1.000) has no detected gain in either primary comparison. Control increases
to88.55/89.53 ns(+1.304/+1.301%,p=.001/.017). Probe beats this slower control
by1.717/1.050%(p=.024/.026); that does not demonstrate improvement over supported
baseline. The preregistered rule requires original scalar to improve against
BOTH controls in BOTH rounds, so it fails.

Varied SQL2679→2740 /2715→2805 ns regresses2.277/3.315%(p=.001/.003) versus
baseline. Holdout SQL5471→5590 /5490→5629 ns regresses2.175/2.532%(p=.024/.026)
versus baseline AND2.119/1.423%(p=.001/.038) versus control5474/5550 ns. These
repeated same-comparator losses are material even though source bodies for SQL's
ResultView path are unchanged. Generator/runtime helper/caller/linkage placement
effects remain a confound; do not infer that unit-only arithmetic caused SQL's
per-query cost or rescue a failed candidate through source-layout tuning.

Original SQL2138→2138 /2168→2153 ns has no detected primary difference(.618/.535).
Control2179/2198 ns is slower; the screening-only probe/control gain does not
create an accepted SQL gain. Varied scalar improves1.18/1.13% against baseline
(.001/.026), but it cannot substitute for the failed original scalar guard.
Negative-bin gains do not confirm against baseline(.001/.128). Increasing
scalar improves in screening(-0.81%,.017), then trends slower in confirmation
(+0.21%,.710). Broad scalar trends slower in both(+0.60/+0.28%,.259/.456).

Original batch trends-0.32/+0.38%, repeated1024+0.20/+0.09%, broad8192-0.17/-0.17%,
all primary differences undetected. Trace trends+0.67/-0.48%, also undetected;
the control instead regresses3.57/1.95% with detection in both rounds. Raw guest
53.00→52.74 /53.30→53.20 ns has screening-only detection(.003/.620) despite
executing the identical guest export body. This is further scope/placement
evidence, not a reply-specialization guest speedup.

Unit-only component8.600→6.990 /8.684→7.051 ns improves18.72/18.80%(.001/.001)
versus baseline, and18.58/18.65% versus byte-identical control. All allocate zero.
It omits guest, admission, ownership, execution/recovery and post-memory work;
its1.610/1.633 ns difference cannot be subtracted from independently calibrated
scalar timing. Current profile ResultView11.17% cumulative likewise overlaps
mandatory work and is not a removable11.17% share. No new public contract was
tested; descriptor, logical range, limits/status/empty validation still apply.

## Current baseline versus fresh M1 limits

Use untouched baseline, not the rejected probe/control, when describing current
production. Absolute limits remain55.44 ns scalar and2215.4 ns SQL.

| Scope | Baseline screen / confirm | Fresh independent reference | Reference×1.10 |
| --- | ---: | ---: | ---: |
| Scalar |87.41 /88.38 ns|55.24 /55.66 ns|60.764 /61.226 ns|
| SQL |2.138 /2.168 µs|1.968 /1.986 µs|2.1648 /2.1846 µs|

Scalar overhead versus fresh reference is58.237/58.785%; it misses fresh caps
by26.646/27.154 ns and absolute by31.970/32.940 ns. SQL overhead is8.638/9.164%;
it meets fresh MEDIAN caps by26.8/16.6 ns and absolute by77.4/47.4 ns. These
session-specific margins do not establish durable SQL equivalence or broad
performance acceptance. Scalar alone still prevents M1 acceptance. Rejected
probe scalar87.03/88.59 ns also misses both limits; probe SQL2138/2153 ns does
not replace production baseline, particularly with repeated SQL holdout losses.

## P16 complete-lifetime streaming observations

Every168 raw stream row verifies actualP16, exact output/owned-byte/group counts
and Go allocation counts. These four leaves time COMPLETE16KiB stream lifetimes
NewStream/Write/End/Close, nominal64B chunking and finite Retain32 groups. They
use standalone methods, including the checked-role name StandaloneHomesP, not
typed Batch. Library Open, lazy-home warmup, corpus and full oracle are outside
timing; owned replies and disposal are inside. Fixed has256 writes+End, holdout
averages343.5 variable-width/empty writes+End across four patterns. Direct raw
custom writes/s excludes End; it is not a ratio reconstructed from rounded ns/op.

| Topology/corpus | Screen baseline / control / probe writes/s | Confirm baseline / control / probe writes/s | Go allocs/full stream |
| --- | ---: | ---: | ---: |
| One home, Fixed |1,353,316 /1,362,104 /1,360,137|1,320,480 /1,316,362 /1,319,708|250|
|16 homes, Fixed |10,632,482 /10,672,623 /10,670,765|9,265,249 /9,334,311 /8,833,492|250|
| One home, Holdout |1,507,564 /1,526,863 /1,505,678|1,477,134 /1,459,879 /1,461,748|268|
|16 homes, Holdout |10,607,379 /10,685,009 /10,939,531|9,452,007 /9,540,167 /9,991,199|268|

| Topology/corpus | Screen baseline / control / probe complete streams/s | Confirm baseline / control / probe complete streams/s |
| --- | ---: | ---: |
| One home, Fixed |5,286 /5,321 /5,313|5,158 /5,142 /5,155|
|16 homes, Fixed |41,533 /41,690 /41,683|36,192 /36,462 /34,506|
| One home, Holdout |4,389 /4,445 /4,383|4,300 /4,250 /4,255|
|16 homes, Holdout |30,880 /31,106 /31,847|27,517 /27,773 /29,086|

All fixed rows have257 outputs/16,392 ownedB/9 groups and250 allocations per
complete stream; all holdout rows344.5 outputs/16,390 ownedB/11 groups and268
allocations. Configured16-home leaves report16 resource homes/one independent
stateless pool slot. Default leaves use ResourceInstances default1 and
Instances1; a pool slot is not an extra resource execution lane. MediansB/op
screen/confirm are defaultFixed17,513–17,515/17,509;shardedFixed17,496/17,496;
defaultHoldout19,620–19,622/19,617–19,618;shardedHoldout19,604/19,604. These are
timed Go allocation metrics, not retained guest memory/processRSS bounds.

Probe versus baseline median streaming deltas/p-values, screen / confirmation:

| Scope | Deltas | p-values |
| --- | ---: | ---: |
| One home, Fixed |-0.502% /+0.058%|.068 /1.000|
|16 homes, Fixed |-0.357% /+4.890%|.209 /.535|
| One home, Holdout |+0.125% /+1.053%|.710 /.318|
|16 homes, Holdout |-3.036% /-5.396%|.001 /.535|

One-home holdout probe/control screening has a detected+1.407% loss(.002),
which does not confirm(-0.128%,.710). Sharded holdout probe/control screening
gain(-2.327%,.001) does not confirm(-4.516%,.620). The sharded fixed confirmation
cost(+4.89% versus baseline,+5.67% versus control) is noisy/undetected(.535/.805)
but must stay visible. No stream comparison establishes a repeated same-
comparator regression OR an accepted throughput gain. Nondetection is not
equivalence. P1/default scalar streaming was NOT timed; this P16-only phase0
does not resolve the existing default streaming cost or satisfy a production
qualification matrix.

Rates describe finite lifetime observed throughput on one host under one/sixteen
serialized resource homes. They are not strict capacity ceilings, fairness,
initialized/live-home counts or RSS guarantees. Earlier streaming numbers and
old toolchain-session scalar/SQL results are not added to this qualification.
