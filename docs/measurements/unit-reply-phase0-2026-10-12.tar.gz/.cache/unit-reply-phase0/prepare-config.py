"""Pin the existing-ABI diagnostic roles after all untimed proofs finish."""
from pathlib import Path
import hashlib
import json
import subprocess

root = Path.cwd()
out = root / '.cache/unit-reply-phase0'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
records = json.loads((out / 'variant-build-records.json').read_text())
commands = {row['name']: row['argv'] for row in records if 'name' in row}
roles = ['baseline', 'control', 'probe', 'reference']
roles += [family + '-' + role for family in ('runtime', 'stream') for role in ('baseline', 'control', 'probe')]
identities = {
    'baseline': 'Untouched clean production at ' + head,
    'control': 'Authored emitter overlay regenerated all three facades to existing ResultUnit; original runtime unchanged',
    'probe': 'Same emitter/facades as control plus source-pinned one-Memory checked ResultUnit and private captured-memory error tail; Range/ResultView/Call unchanged',
}
production = [prefix + '/' + filename for prefix in ('examples/datadog/go/dd', 'testdata/compute/go/compute', 'testdata/streaming/go/streaming') for filename in ('testdata/module.wasm', 'internal/wasm/module.go')]
config = {
    'plan': '.cache/unit-reply-phase0/qualification-plan.json',
    'binaries': {role: '.cache/unit-reply-phase0/' + role + '.test' for role in roles},
    'added_harness': [],
    'build_records': {},
    'artifacts': ['go.mod', 'go.sum', 'Makefile', 'examples/datadog/cocoon.lock.json', 'testdata/compute/cocoon.lock.json', 'testdata/streaming/cocoon.lock.json', '.cache/reference.mod', '.cache/reference.sum'],
    'production_sha256': {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in production},
}
for role in roles:
    if role == 'reference':
        journal = json.loads((out / 'reference-run-provenance.json').read_text())['commands']
        matches = [row for row in journal if row.get('event') == 'end' and '-c' in row['argv'] and str(out / 'reference.test') in row['argv']]
        assert len(matches) == 1 and matches[0]['exit'] == 0
        config['build_records'][role] = {
            'command': matches[0]['argv'], 'cwd': matches[0]['cwd'],
            'source_identity': 'Fresh absent-target locked independent Rust shim and own hardener; 56 exact authored inputs and actual command journal; no Cocoon implementation transplant',
        }
    else:
        family, variant = role.split('-', 1) if '-' in role else ('dd', role)
        key = variant + ('-compile' if family == 'dd' else '-' + family + '-compile')
        config['build_records'][role] = {'command': commands[key], 'cwd': str(root), 'source_identity': identities[variant] + '; ordinary ' + family + ' harness, no extra proof source or SSA/profile instrumentation'}
for directory in ('internal/gen/gogen', 'internal/gen/rtgen', 'internal/manifest', 'internal/build'):
    config['artifacts'].extend(str(p.relative_to(root)) for p in (root / directory).rglob('*.go'))
for p in out.rglob('*'):
    if p.is_file() and p.suffix in {'.go', '.json', '.jsonl', '.py', '.asm', '.md', '.dump', '.wat', '.log', '.cpu', '.txt', '.wasm', '.mod', '.sum', '.sh', '.patch'} and 'reference-rust' not in p.parts and '__pycache__' not in p.parts:
        config['artifacts'].append(str(p.relative_to(root)))
config['artifacts'].extend(str(p.relative_to(root)) for p in (out / 'proof').glob('*.test'))
go_root = root / '.cache/toolchains/go1.26.8/go'
config['artifacts'].extend(str(p) for p in [go_root / 'bin/go', *(go_root / 'pkg/tool/linux_amd64' / name for name in ('compile', 'link', 'asm')), Path('/home/dario/go/bin/benchstat')])
config['artifacts'] = sorted(set(config['artifacts']))
(out / 'qualification-config.json').write_text(json.dumps(config, indent=2) + '\n')
print('Pinned', len(roles), 'ordinary benchmark binaries; freeze after final review remains required')
