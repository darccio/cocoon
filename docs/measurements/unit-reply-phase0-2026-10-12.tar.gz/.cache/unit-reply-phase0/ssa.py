from pathlib import Path
import datetime,hashlib,json,os,subprocess
root=Path.cwd();out=root/'.cache/unit-reply-phase0';go=root/'.cache/toolchains/go1.26.8/go/bin/go';records=[]
functions=('ResultView','ResultUnit','unitReplyTail');flags='-gcflags=dario.cat/cocoon/rt=-d='+','.join('ssa/'+stage+'/dump='+fn for fn in functions for stage in ('opt','regalloc','genssa'))
for role in ('baseline','control','probe'):
 directory=out/'ssa'/role;directory.mkdir(parents=True,exist_ok=False)
 env=dict(os.environ,GOTOOLCHAIN='local',CGO_ENABLED='0',GOAMD64='v1',GOCACHE=str(root/'.cache/go'),GOFLAGS='-buildvcs=false',GOSSADIR=str(directory));env['PATH']=str(go.parent)+':'+env['PATH']
 overlay=[] if role=='baseline' else ['-overlay='+str(out/(role+'-overlay.json'))]
 argv=[str(go),'test','-c','-pgo=off',*overlay,flags,'-o',str(out/(role+'-ssa.test')),'./examples/datadog/go/dd'];record={'role':role,'argv':argv,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (out/(role+'-ssa-build.log')).open('x') as log: result=subprocess.run(argv,env=env,stdout=log,stderr=subprocess.STDOUT)
 record.update(exit=result.returncode,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),outputs={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in directory.glob('*.dump')});records.append(record)
 (out/'ssa-provenance.json').write_text(json.dumps(records,indent=2)+'\n')
 assert result.returncode==0 and len(record['outputs'])==(9 if role=='probe' else 6),(role,record)
 print('PASS',role,len(record['outputs']),'diagnostic SSA dumps',flush=True)
