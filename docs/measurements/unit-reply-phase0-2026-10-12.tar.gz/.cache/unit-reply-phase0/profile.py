"""Sequential P1 CPU diagnostics on the frozen ordinary production binary."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess

root = Path.cwd()
out = root / '.cache/unit-reply-phase0'
binary = out / 'baseline.test'
viewer = Path('/usr/lib64/go/1.24/pkg/tool/linux_amd64/pprof')
env = dict(os.environ, GOTOOLCHAIN='local', CGO_ENABLED='0', GOAMD64='v1',
           GOMAXPROCS='1', GOFLAGS='-buildvcs=false', GOCACHE=str(root / '.cache/go'))
assert os.environ.get('GOGC') in (None, '', '100')
assert os.environ.get('GOMEMLIMIT') in (None, '', 'off')
assert not os.environ.get('GODEBUG') and not os.environ.get('GOEXPERIMENT')

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

sources = subprocess.check_output(['git', 'ls-files', '--', 'rt', 'internal/harden',
                                  'internal/gen/gogen', 'examples/datadog',
                                  'go.mod', 'go.sum', 'Makefile'], text=True).splitlines()
files = [root / name for name in sources] + [binary, out/'runtime-baseline.test', viewer, Path(__file__), out/'go1268-toolchain.json', out/'baseline-build-provenance.json']
record = {'started_utc': utc(), 'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
          'go': subprocess.check_output([str(root / '.cache/toolchains/go1.26.8/go/bin/go'), 'version'], text=True).strip(),
          'affinity': sorted(os.sched_getaffinity(0)),
          'policy': {str(p): p.read_text().strip() for pattern in ('cpu*/cpufreq/scaling_governor', 'cpufreq/boost')
                     for p in Path('/sys/devices/system/cpu').glob(pattern)},
          'environment': {k: env.get(k, 'default') for k in ('GOTOOLCHAIN', 'CGO_ENABLED', 'GOAMD64', 'GOMAXPROCS',
                          'GOFLAGS', 'GOGC', 'GOMEMLIMIT', 'GODEBUG', 'GOEXPERIMENT')},
          'sha256': {str(p): sha(p) for p in files}, 'commands': [],
          'scope': 'Six sequential ten-second P1 CPU diagnostics, five real payload leaves plus one unsupported runtime-unit component. Ordinary Go1.26.8 -pgo=off production binary; '
                   'Go1.24 viewer only. Original/layer benchmark sources unchanged, no custom in-window procs metric. '
                   'Profile timings/percentages are not acceptance samples or attainable gains. '
                   'No builds/tests/lint/fuzz/reviewer tools overlap profiling; external system work cannot be excluded.'}
provenance = out / 'profile-provenance.json'
assert not provenance.exists()
provenance.write_text(json.dumps(record, indent=2) + '\n')

for name, selector in [('scalar', '^BenchmarkSketchAdd$'), ('guest', '^BenchmarkSketchAddLayers$/^Guest$'),
                       ('sql', '^BenchmarkObfuscateSQL$'), ('batch', '^BenchmarkSketchAddMany1k$'),
                       ('trace', '^BenchmarkObfuscateTraces1k$'), ('runtime-reply', '^BenchmarkSessionLayers$/^ReplyUnit$')]:
    for p, expected in record['sha256'].items():
        assert sha(Path(p)) == expected, p
    selected_binary = out/'runtime-baseline.test' if name == 'runtime-reply' else binary
    profile = out / (name + '.cpu')
    args = [str(selected_binary), '-test.run=^$', '-test.bench=' + selector, '-test.cpu=1', '-test.benchtime=10s',
            '-test.count=1', '-test.benchmem', '-test.cpuprofile=' + str(profile)]
    command = {'argv': args, 'started_utc': utc()}
    with (out / (name + '-profile-run.txt')).open('x') as log:
        print('COMMAND', json.dumps(args), file=log, flush=True)
        result = subprocess.run(args, env=env, stdout=log, stderr=subprocess.STDOUT)
        print('EXIT', result.returncode, file=log, flush=True)
    command.update(exit=result.returncode, completed_utc=utc(), profile_sha256=sha(profile))
    record['commands'].append(command)
    provenance.write_text(json.dumps(record, indent=2) + '\n')
    assert result.returncode == 0
    for mode in ('flat', 'cum'):
        args = [str(viewer), '-top', '-nodecount=50'] + (['-cum'] if mode == 'cum' else []) + [str(selected_binary), str(profile)]
        (out / (name + '-' + mode + '.txt')).write_text(subprocess.check_output(args, env=env, text=True, stderr=subprocess.STDOUT))
    args = [str(viewer), '-list=.*rt.*(ResultView|ResultUnit|Range|Call)$', str(selected_binary), str(profile)]
    (out / (name + '-lines.txt')).write_text(subprocess.check_output(args, env=env, text=True, stderr=subprocess.STDOUT))
    print('PASS CPU diagnostic', name, flush=True)

assert all(sha(Path(p)) == expected for p, expected in record['sha256'].items())
record['completed_utc'] = utc()
provenance.write_text(json.dumps(record, indent=2) + '\n')
print('PASS frozen inputs unchanged', len(record['sha256']), flush=True)
