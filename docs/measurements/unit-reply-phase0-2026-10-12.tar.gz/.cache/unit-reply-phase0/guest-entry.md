# Existing-ABI unit-reply phase-zero guest entry

Read-only entry after merged PR7/main6be3980. No guest, shim, Wasm, generated
artifact, production source, build, test, profile or benchmark was changed or
run. This note supplies review constraints for a measured ignored host-only
diagnostic, not a public contract, typed-return design or production spec.

## Actual current call shapes

`examples/datadog/go/dd/cocoon_gen.go:571` Sketch.Add admits through Lifecycle,
uses the shared Resource ownership/epoch check, enters Instance.Call, invokes
the guest, then calls ResultView and rejects a nonempty success. It performs no
PrepareInput/Reserve. AddMany at597 keeps size checks, PrepareInput,
putSliceF64, guest invocation, ResultView and the same empty-success test.

Only the destructor callback created at560 uses ResultUnit directly. Sketch.Close
at697 performs nil guards then owner.Close; it does not separately enter
Lifecycle. Resource.Close invalidates all aliases, stops the ownership-cell
cleanup and runs its shared once-only destructor outside the cell lock.

Therefore a ResultUnit-only runtime overlay does not exercise current scalar
Add unless an independently labelled ignored facade overlay routes its unit
site through ResultUnit. Use the real ResultView+len baseline, an unchanged
ResultUnit-delegates-to-ResultView call-shape control, and the specialized
existing-ABI validator separately. Do not describe custom controls as current
generated-facade performance or edit generated production modules alone.

## Guest publication already retained

`rust/cocoon-guest/src/lib.rs:123` reply_unit is already inline(always) for
success. It clears previous output, publishes the current output Vec pointer
and length0, and returns OK. Error publication goes through the retained cold
helper at136 and ordinary reply: it owns the diagnostic bytes, clears previous
output, enforces guest MaxOutput, and publishes pointer/length/status. An
oversized guest message returns ERR_LIMIT with empty published bytes.

Canonical unit success means zero length, not a required zero pointer. The
pointer may be the retained output allocation after a prior reply/error, or
the empty Vec sentinel. Trim clears buffers/descriptors; cocoon_out's descriptor
address stays fixed, while current backing views must be reacquired after
allocation/growth. Existing Rust tests at421–474 cover previous-data clearing,
descriptor identity, every expected status, owned messages including NUL/UTF8,
output-limit handling and subsequent success.

Generated Rust Add/AddMany/Close at cocoon_gen.rs80–143 all call reply_unit.
Add checks the slab handle and preserves authored finite/nonnegative validation
before DDSketch mutation. AddMany owns decoded bytes and Vec<f64>, validates
width, then validates the complete batch before mutation. Close removes the
handle and drops the resource before publishing success. Guest fault/abort or
host-import panic containment belongs to Instance.Call, not a reply shortcut.
None of these paths should change in the initial ceiling round.

## Specialized validator must preserve this exact order

Current ResultUnit at rt/instance.go335 delegates to ResultView at349, then
requires an empty success. ResultView queries current module.Memory once for
reply validation, checks the cached descriptor's full8 bytes against logical
length, decodes two little-endian u32s, checks size against MaxOutput, validates
the payload range, interprets status, and only then exposes the borrowed view.
Instance.Call independently queries memory again for its per-operation
MaxMemory check. "Single memory query" means the reply validator's query,
not removal of the post-operation memory check.

Keep descriptor-range errors before field/status interpretation, MaxOutput
before payload bounds/status, and payload bounds before status/unit shape.
Both zero and nonzero lengths require logical range validation. For size0,
pointer0 and pointer==logicalEnd are valid, but pointer beyond logicalEnd or
inside only spare Go capacity is invalid. A nonempty OK must be rejected after
its structural range checks; early rejection can change the concrete error and
precedence. Widen pointer+size arithmetic so wasm32 addition cannot wrap.

Expected ErrApp/ErrArg/ErrHandle/ErrLimit must retain the existing owned concrete
error values/messages after the call or later guest writes. Reserved Pending,
unknown/negative status, malformed descriptor/range and nonempty success remain
protocol errors. Structural errors and MaxOutput may take precedence over a
reserved or expected status: do not inspect status early or trust an empty
successful status without its descriptor. ErrTooLarge alone leaves a healthy
instance; malformed protocol replies immediately poison it. A post-operation
MaxMemory failure wins over the callback result and poisons, invalidating prior
resource epochs and preventing subsequent execution.

The existing generated checked boundary still resets every Call, clears host
panic state, contains/classifies panic, checks MaxMemory, and poisons protocol
errors under its execution lock. Library admission/drain, Resource identity,
epochs, alias/destructor semantics and expected-error recovery remain required.
No Call, borrowed memory view or error-message backing may escape.

## Existing proof coverage and limitations

`rt/unit_result_test.go` already exercises valid empty pointers, invalid logical
end/spare/max pointers, overflowing/truncated payloads, limit-before-bounds and
limit-before-status, Pending/unknown/negative status, healthy/error ownership,
current backing replacement, truncated descriptor with spare capacity and
allocation-free success. Extend the ignored proof only where the new shape has
additional risks: one current-memory query per validation, exact concrete error
precedence/diagnostics, all descriptor boundaries, payload shape versus invalid
status, error→success reset, post-MaxMemory precedence and immediate prior-live
resource invalidation. A changed error decoder must not re-query a different
memory header on its fallback path.

Generated wazero compareOperation at zz_wazero_test.go52 compares statuses
before expected-error conversion, then concrete messages/output against the
original Wasm. It uses Result plus PrepareInput even for no-variable arguments,
so it is a guest/wire oracle, not an exact scalar-facade call-shape benchmark.
Generated ownership/Close tests cover aliases, once-only destruction, poisoning,
home replacement and terminal library shutdown. Valid Add/AddMany Count/full
protobuf histories and invalid-input atomicity tests remain stronger real
payload state oracles than successful status-only tests.

## Ceiling interpretation and prior negatives

The last matching scalar profile attributes10.42% cumulatively to ResultView
and57.08% cumulatively to the guest export. These are overlapping CPU samples,
not additive facade costs or removable fractions. Historical unit/Instance
microbenchmarks and profile times used different calibrated prefixes/evolving
states. A specialized validator retains descriptor/range/limit/status work;
neither its share nor an empty-call difference predicts a full scalar gain.

Fresh matching ordinary Go1.26.8 PGO-off profiles, SSA/assembly, an unchanged
call-shape control and copied-validation controls should identify what changes
in successful and cold error paths before interpreting timing. Function/file
placement and inlining can move unaffected SQL/batch/trace paths, so full
interleaved before/after controls and negative holdouts are still needed.

An earlier successful-unit decoding candidate improved scalar but regressed
trace and was removed; it is evidence of guard risk, not permission to revive
it or skip validation. Prior scalar bin caching, float shortcuts and three
adjacent-store bounds removal were also no-go. This existing-ABI round should
measure one precise host call shape, preserve raw negatives and unchanged
guest hashes, and proceed to design only if its end-to-end ceiling survives the
predeclared controls. No ABI version change, typed returns or M1 acceptance is
implied.
