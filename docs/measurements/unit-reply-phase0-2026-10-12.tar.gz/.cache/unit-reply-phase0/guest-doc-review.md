# Guest final documentation review

Read-only audit, 2026-10-12, after the 924-row matrix. Reviewed
`performance-section.md`, the actual derived file `outcome-table.md`, pinned
probe inventory/source, ordinary machine summary, corrected SSA provenance,
profile provenance, and the guest-owned final runtime/fixture proof artifacts.
No build, test, lint, profile or timing was run for this review, and no tracked
file was edited. The parent's quality placeholder was pending at read time;
this note does not predeclare unfinished gates passed.

After this review was written, the parent reported all six gates plus
integration and both 61-file three-proof/runtime repetitions passing, with all
430 frozen hashes independently unchanged. It replaced the placeholder in the
cached section and durable performance document. The initial Go1.27.2
lint-reader failure remains recorded separately from the successful pinned
Go1.26 check. No new code/proof issue or additional reviewer tool run follows
that final status update.

**Verdict: no meaningful guest/proof/report blocker found. Retain the no-go
evidence and durable conclusions only.** There is no case to implement the
private specialization or change the existing public API/ABI/schema/guest
contract. Final archive/gate status should be inserted only after the parent's
actual completions. M1 remains unaccepted.

## Runtime, emitter and guest facts

The draft correctly distinguishes actual generated Add/AddMany's baseline
ResultView-plus-empty-check from destructors' existing ResultUnit call. Control
and probe share regenerated ordinary unit tails from one authored generator
overlay; only the probe changes the runtime ResultUnit body. Baseline facades
reproduce tracked output. The listed Datadog/compute/stream unit sites and
unchanged constructors/nonunit methods/typed Batch/input encoding are the right
scope. No optimization is retained in a generated module alone.

The probe captures current Memory once, validates the eight-byte descriptor
against logical length, reads little-endian pointer/size, checks MaxOutput,
and validates the payload before interpreting a failure or rejecting successful
unit shape. Its direct empty-OK path still calls Range for size0. Empty end
pointers remain valid, while spare-capacity/out-of-range pointers remain
protocol failures. Other cases pass the same captured slice and fields to the
private tail; calling ResultView/Call.Range again would add an observable query.
The post-operation Memory/MaxMemory check is separate and unchanged.

Expected application/argument/handle/limit errors retain concrete owned opaque
messages and healthy state. Malformed protocol replies poison immediately;
the shared boundary gives post-MaxMemory failure precedence and invalidates
epochs/prior live resources. Full call reset, panic classification/containment,
aliases/destructor cardinality, library admission/drain and home replacement
are unchanged source contracts. The prototype does not assume a pure Memory
getter or add any new public ownership rule.

Rust's retained inline unit-success/cold-error publication, descriptor identity,
guest state/validation, Wasm and translated guest sources are unchanged. The
draft's "cold tail" describes the rare/error/nonempty path; it should not be
read as a new Go compiler cold attribute. No numerical or guest-execution
optimization is claimed or supported.

## Proof and procedural scope

The final ignored proof has 30 independent wire scenarios, concrete error-field
and raw-byte ownership checks, query ordering and alternating views, Memory
panics at validation/post-check, post-MaxMemory priority, poisoned prior-owner
rejection/no later callback, reset/error-to-success, aliases, once-only and
faulting destructors, sibling invalidation, and terminal Close. Both callback
shapes run against all three overlays. All runtime and propagated generated
mock unit-consumer roles pass on native amd64/native386 with pinned Go 1.26.8,
CGO disabled. Native386 was actually executed with sandbox escalation; no arm64
execution follows from this result.

All four safe mutants fail explicit TestUnitPhase0MutantProbe assertions on
both architectures: skip-empty-range, early nonempty rejection, second Memory
fallback, and skipped post-MaxMemory enforcement retaining the query. The
driver requires successful build and semantic test/diagnostic markers, so a
compile/startup failure cannot count as rejection.

The draft correctly records two distinct procedural issues. The initial
gogen parent could regenerate a candidate facade but its child GOFLAGS lost
the runtime overlay; that success did not establish dynamic candidate runtime
coverage. Final proof-only child propagation resolves it with exact resolved
compiler/architecture/role overlay in logs and pinned source. Separately, the
proof driver initially ran a compiled gogen test from repo root, giving the
existing relative-root calculation `/home`; the child failed module setup
before candidate compilation. Its actual raw log/driver snapshot is preserved.
Neither issue is a candidate semantic failure or timing sample.

The parent-owned broader real guest/wazero/state suites remain independent
evidence. The synthetic runtime and unit fixture do not replace those guest
oracles, establish a public caller shape, or prove an unmeasured typed-return
contract. The draft's scope does not overclaim them.

## Static and measured limits

The ordinary summaries match the draft's byte/frame/site/instruction counts:
fn176 5462/128/78, fn96 110236/856/1452, scalar export 3004/112/57; unchanged
ResultView 605/104/168 instructions. Add caller closure 143/42 →92/25 in control
and probe. Original ResultUnit 124-byte/32-byte frame; probe 489/96/128 plus
350/64 private tail. These are static descriptions, not dynamic savings or
spill/causality proof. Corrected SSA provenance contains 6+6+9=21 dumps. It does
not imply that all other linkage/placement or register effects are controlled.

The component directly invokes an internally constructed Call's ResultUnit on
a synthetic descriptor. It omits guest execution and the normal admission,
ownership, execution/recovery and post-memory boundary. Its repeated 18.72%/
18.80% improvement and 1.610/1.633 ns median differences cannot be subtracted
from separately calibrated facade timing. The draft makes this distinction.
The preceding profile's ten-second request hit the billion-iteration cap at
about 8.6 s; it is contextual profiling, not a hidden ten-second sample. CPU
profile shares overlap and are not removable or additive ceilings.

The promotion rule fails decisively: default scalar versus untouched is
undetected in both rounds (p=.456/1.000); varied SQL repeatedly regresses
+2.28%/+3.31% (p=.001/.003), and SQL holdout loses against both comparators
in both rounds. Varied scalar's repeated primary gain and the component gain
are real within their measured scopes but do not satisfy default-scalar or
guard requirements. Probe/control improvements over a slower call-shape
control are not untouched-production improvements. The draft retains broad
upward medians and nonconfirming negative-bin/increasing/raw guest results.

SQL still uses unchanged ResultView and guest code; linkage/compiler effects
limit direct unit-instruction attribution. Raw guest bypasses the reply path
and has unchanged guest source, yet its screen shift does not confirm. That
too demonstrates why full end-to-end outcomes and controls matter.

Streaming is a real three-binary comparison in this round because timed Close
already invokes ResultUnit, rather than the same-binary brackets from the
previous adjacent-store experiment. P16 complete-lifetime medians include
New/Write/End/Close and Retain32 groups, not just writes or a 32-byte holdback.
The described owned-output/write/group/allocation quantities match the fixture
scope. Direct writes/s excludes End only in its numerator, while elapsed time
includes the whole lifetime. The draft correctly avoids strict capacity,
fairness/RSS/live-instance/equivalence claims and discloses absent P1 streaming
qualification and unconfirmed adverse medians.

The official Go 1.26.8 distribution differs from the prior distro toolchain;
same-version source equality does not make old/new ELF timing comparable.
All current roles and child compilers are pinned alike. The independently
rebuilt ABI2 reference remains contextual: borrowed inputs/error/partial-state
and original corpus/instance/context differences prevent full contract
equivalence. Rejected probe timing does not change current production or
accept M1 even where the untouched SQL medians meet this run's narrow caps.
