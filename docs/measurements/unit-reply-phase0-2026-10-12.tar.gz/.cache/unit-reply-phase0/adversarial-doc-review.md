# Unit-reply phase-0 final documentation audit

Read-only final prose/transcription/gate review before compressed evidence assembly. No build, test, lint, profile, benchmark or tracked edit by this reviewer.

## Verdict

Approve evidence-only documentation retention, pending the independent final compressed archive byte/member audit and root's separate exact staged-snapshot validation. No remaining prose/numerical/contract/M1 blocker. The performance section, roadmap follow-up and concise summary accurately reject this measured default scalar hypothesis, while preserving the varied-scalar benefit, repeated SQL negatives and all control/holdout limits. The pre-existing track4 sentence implying that a measured profile share directly limits scalar gain is now corrected: profiles choose a matched checked prototype; controls/holdouts establish its attainable full-facade gain.

Direct transcription checks verify every baseline/probe median, time delta and primary/secondary p-value across all18 table rows in both rounds, and all24 reported median writes/s values. Fixed streams remain250 and held-out streams268 Go allocations; original scalar and direct ReplyUnit component remain allocation-free. All values match the exact raw-derived summary/benchstat data. The benchmark suffix16 is not represented as measured-P1/P16 instrumentation; exact280P1/168P16/476framework16 scope is explicit. Real stream Close uses ResultUnit and complete16KiB New/Write/End/Close timing with Retain32 is distinguished from untimed opening/warmup/corpus/full oracle. Writes/s excludes End and is a workload-specific observed full-lifetime rate, not a strict ceiling, fairness/RSS guarantee or P1/default-stream equivalence.

The no-go is stated consistently. Original scalar lacks detected gain versus untouched in either round despite beating the slower call-shape control; that control's scalar/trace losses remain disclosed. Varied scalar improves in both rounds; negative bins/increasing do not confirm. Varied SQL and SQL holdout losses repeat against untouched, while SQL holdout also repeats against control. The single-round VariedSQL/control and OneHome-Holdout/control losses, broad/scaled stream upward medians, raw guest nonconfirmation, exploratory p-values/dispersion and nondetection limits remain visible. No unit instruction/linkage mechanism is asserted to cause a particular whole-SQL regression. Component8.6→~7ns and cumulative11.17% are explicitly nonadditive; the testing1e9 iteration duration cap is disclosed. M1 scalar remains above both55.44ns absolute and currentfresh110%caps; narrow current SQL median margins are not durable acceptance.

The existing-ABI semantic scope is accurate: single captured reply Memory, descriptor8/LE/MaxOutput/payload range inclzero pointer/status/empty order, owned opaque errors, separate post-memory limit, reset/poison/epochs/drain/ownership are retained. No production spec/API/ABI/schema/artifact change or broader predicate follows. Native amd64/386 proof scopes, child overlay propagation gap and wrong-cwd setup failure, semantic-mutant rejection and tool failures remain disclosed; no arm64 proof claim is invented.

Recorded post-measurement gates/reproductions are complete. All16 logged exits match the post-gate inventory: original systemGo1.27.2 makecheck exit2 export-data5/max4 lint incompatibility, unchanged pinned2.13.1 successful officialGo1.26.8 retry, race/rust/cross/smoke/fuzz/integration success, and eight additional three-proof/runtime generation commands. Quality versus measurement compilers are clear. The docs do not claim the still-future exact staged snapshot has already passed; later logs remain outside timing/archive evidence. Root's post-gate inventory records61 committed-entry fingerprints reproduced; this reviewer directly reverified every430 frozen fingerprint after those gates. Original/consumer harness bytes and production runtime/generator/Wasm/modules/locks remain unchanged.

Archive/readable/SHA links identify intended artifacts that root will assemble next. The final immutable archive must contain these outcome/doc/proof reviews, all924 raw rows and exact overlay/reference/proof/script/provenance bytes; final independent archive audit remains outstanding. No additional source or measurement scope is requested.

## Reviewed identities

```json
{
  "docs/performance.md": "25de0567d9e87b8c2acb30536b4bf9e6bbe11fb157c827061d5dbb2b463b2db1",
  "docs/roadmap.md": "ff49997dc1da00e831a396853d073c38bf6c18521b3c7472d1d07187258f81f8",
  ".cache/unit-reply-phase0/performance-section.md": "cd6c38c941a73cca178971f0c1fb4efa3d783b9852883fc256aee33f9394ee56",
  ".cache/unit-reply-phase0/final-summary.md": "75ac28b1eda030cebc6d6b05a42926d6136ae348df592401d4f4557c327d9f87",
  ".cache/unit-reply-phase0/post-gate-audit.json": "d4b5dca1d0c0743872160fdd08fb9e3bbbf846cd45daf4acc81ff24af4c5d626",
  ".cache/unit-reply-phase0/quality-negative.json": "0fb75a8411ef49f2671af43cbaec32045669e856ca3ba3a200b50a2fd1c93b79",
  ".cache/unit-reply-phase0/quality-toolchains.json": "d0084f93632f3c848615e65abaff47838649fc4a8d35c2447cdee361d5084f52",
  ".cache/unit-reply-phase0/quality-toolchains-resume.json": "d0084f93632f3c848615e65abaff47838649fc4a8d35c2447cdee361d5084f52"
}
```
