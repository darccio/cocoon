TEXT dario.cat/cocoon/rt.(*Call).ResultView(SB) /home/dario/Code/cocoon/rt/instance.go
  instance.go:356	0x5c80c0		493b6610		CMPQ SP, 0x10(R14)							
  instance.go:356	0x5c80c4		0f8621020000		JBE 0x5c82eb								
  instance.go:356	0x5c80ca		55			PUSHQ BP								
  instance.go:356	0x5c80cb		4889e5			MOVQ SP, BP								
  instance.go:356	0x5c80ce		4883ec68		SUBQ $0x68, SP								
  instance.go:72	0x5c80d2		4889442478		MOVQ AX, 0x78(SP)							
  instance.go:72	0x5c80d7		89bc2490000000		MOVL DI, 0x90(SP)							
  instance.go:72	0x5c80de		48898c2488000000	MOVQ CX, 0x88(SP)							
  instance.go:72	0x5c80e6		48899c2480000000	MOVQ BX, 0x80(SP)							
  instance.go:357	0x5c80ee		488b08			MOVQ 0(AX), CX								
  instance.go:357	0x5c80f1		488b11			MOVQ 0(CX), DX								
  instance.go:357	0x5c80f4		488b4108		MOVQ 0x8(CX), AX							
  instance.go:357	0x5c80f8		488b4a20		MOVQ 0x20(DX), CX							
  instance.go:357	0x5c80fc		ffd1			CALL CX									
  instance.go:357	0x5c80fe		48895c2440		MOVQ BX, 0x40(SP)							
  instance.go:358	0x5c8103		488b4c2478		MOVQ 0x78(SP), CX							
  instance.go:358	0x5c8108		488b11			MOVQ 0(CX), DX								
  instance.go:358	0x5c810b		8b5260			MOVL 0x60(DX), DX							
  instance.go:71	0x5c810e		488d7208		LEAQ 0x8(DX), SI							
  instance.go:72	0x5c8112		4839f3			CMPQ BX, SI								
  instance.go:72	0x5c8115		7221			JB 0x5c8138								
  instance.go:75	0x5c8117		4189d1			MOVL DX, R9								
  instance.go:75	0x5c811a		4829d2			SUBQ DX, DX								
  instance.go:75	0x5c811d		4883c208		ADDQ $0x8, DX								
  instance.go:75	0x5c8121		4989d2			MOVQ DX, R10								
  instance.go:75	0x5c8124		48f7da			NEGQ DX									
  instance.go:75	0x5c8127		48c1fa3f		SARQ $0x3f, DX								
  instance.go:75	0x5c812b		4921d1			ANDQ DX, R9								
  instance.go:75	0x5c812e		4a8d1408		LEAQ 0(AX)(R9*1), DX							
  instance.go:75	0x5c8132		31f6			XORL SI, SI								
  instance.go:75	0x5c8134		31ff			XORL DI, DI								
  instance.go:358	0x5c8136		eb50			JMP 0x5c8188								
  instance.go:358	0x5c8138		89542430		MOVL DX, 0x30(SP)							
  instance.go:71	0x5c813c		4889742450		MOVQ SI, 0x50(SP)							
  instance.go:357	0x5c8141		4889442460		MOVQ AX, 0x60(SP)							
  instance.go:73	0x5c8146		488d0553912c00		LEAQ 0x2c9153(IP), AX							
  instance.go:73	0x5c814d		e8cea0e5ff		CALL runtime.newobject(SB)						
  instance.go:73	0x5c8152		8b4c2430		MOVL 0x30(SP), CX							
  instance.go:73	0x5c8156		894810			MOVL CX, 0x10(AX)							
  instance.go:73	0x5c8159		488b4c2450		MOVQ 0x50(SP), CX							
  instance.go:73	0x5c815e		488908			MOVQ CX, 0(AX)								
  instance.go:73	0x5c8161		488b4c2440		MOVQ 0x40(SP), CX							
  instance.go:73	0x5c8166		48894808		MOVQ CX, 0x8(AX)							
  instance.go:364	0x5c816a		488b4c2478		MOVQ 0x78(SP), CX							
  instance.go:72	0x5c816f		488b5c2440		MOVQ 0x40(SP), BX							
  instance.go:72	0x5c8174		488d3525d33300		LEAQ go:itab.*dario.cat/cocoon/rt.memoryRangeError,error(SB), SI	
  instance.go:72	0x5c817b		4531d2			XORL R10, R10								
  instance.go:72	0x5c817e		31d2			XORL DX, DX								
  instance.go:358	0x5c8180		4889c7			MOVQ AX, DI								
  instance.go:75	0x5c8183		488b442460		MOVQ 0x60(SP), AX							
  instance.go:359	0x5c8188		4885f6			TESTQ SI, SI								
  instance.go:359	0x5c818b		0f8537010000		JNE 0x5c82c8								
  instance.go:362	0x5c8191		90			NOPL									
  binary.go:91		0x5c8192		4983fa03		CMPQ R10, $0x3								
  binary.go:91		0x5c8196		0f8649010000		JBE 0x5c82e5								
  instance.go:363	0x5c819c		4d8d4afc		LEAQ -0x4(R10), R9							
  binary.go:91		0x5c81a0		4983f903		CMPQ R9, $0x3								
  binary.go:91		0x5c81a4		0f8634010000		JBE 0x5c82de								
  instance.go:363	0x5c81aa		49f7d9			NEGQ R9									
  instance.go:363	0x5c81ad		49c1f93f		SARQ $0x3f, R9								
  instance.go:363	0x5c81b1		4183e104		ANDL $0x4, R9								
  instance.go:364	0x5c81b5		4c8b11			MOVQ 0(CX), R10								
  binary.go:92		0x5c81b8		468b0c0a		MOVL 0(DX)(R9*1), R9							
  binary.go:92		0x5c81bc		0f1f4000		NOPL 0(AX)								
  instance.go:364	0x5c81c0		4d394a38		CMPQ 0x38(R10), R9							
  instance.go:364	0x5c81c4		0f82e3000000		JB 0x5c82ad								
  binary.go:92		0x5c81ca		8b12			MOVL 0(DX), DX								
  instance.go:71	0x5c81cc		4901d1			ADDQ DX, R9								
  instance.go:72	0x5c81cf		4c39cb			CMPQ BX, R9								
  instance.go:72	0x5c81d2		7219			JB 0x5c81ed								
  instance.go:75	0x5c81d4		4929d1			SUBQ DX, R9								
  instance.go:75	0x5c81d7		4d89ca			MOVQ R9, R10								
  instance.go:75	0x5c81da		49f7d9			NEGQ R9									
  instance.go:75	0x5c81dd		49c1f93f		SARQ $0x3f, R9								
  instance.go:75	0x5c81e1		4c21ca			ANDQ R9, DX								
  instance.go:75	0x5c81e4		4801c2			ADDQ AX, DX								
  instance.go:75	0x5c81e7		31c0			XORL AX, AX								
  instance.go:75	0x5c81e9		31c9			XORL CX, CX								
  instance.go:367	0x5c81eb		eb3f			JMP 0x5c822c								
  instance.go:71	0x5c81ed		4c894c2448		MOVQ R9, 0x48(SP)							
  binary.go:92		0x5c81f2		89542434		MOVL DX, 0x34(SP)							
  instance.go:73	0x5c81f6		488d05a3902c00		LEAQ 0x2c90a3(IP), AX							
  instance.go:73	0x5c81fd		0f1f00			NOPL 0(AX)								
  instance.go:73	0x5c8200		e81ba0e5ff		CALL runtime.newobject(SB)						
  instance.go:73	0x5c8205		8b4c2434		MOVL 0x34(SP), CX							
  instance.go:73	0x5c8209		894810			MOVL CX, 0x10(AX)							
  instance.go:73	0x5c820c		488b4c2448		MOVQ 0x48(SP), CX							
  instance.go:73	0x5c8211		488908			MOVQ CX, 0(AX)								
  instance.go:73	0x5c8214		488b4c2440		MOVQ 0x40(SP), CX							
  instance.go:73	0x5c8219		48894808		MOVQ CX, 0x8(AX)							
  instance.go:73	0x5c821d		4531d2			XORL R10, R10								
  instance.go:73	0x5c8220		31d2			XORL DX, DX								
  instance.go:367	0x5c8222		4889c1			MOVQ AX, CX								
  instance.go:367	0x5c8225		488d0574d23300		LEAQ go:itab.*dario.cat/cocoon/rt.memoryRangeError,error(SB), AX	
  instance.go:368	0x5c822c		4885c0			TESTQ AX, AX								
  instance.go:368	0x5c822f		7569			JNE 0x5c829a								
  instance.go:371	0x5c8231		8b8c2490000000		MOVL 0x90(SP), CX							
  instance.go:371	0x5c8238		85c9			TESTL CX, CX								
  instance.go:371	0x5c823a		7438			JE 0x5c8274								
  instance.go:367	0x5c823c		4c89542438		MOVQ R10, 0x38(SP)							
  instance.go:367	0x5c8241		4889542458		MOVQ DX, 0x58(SP)							
  instance.go:372	0x5c8246		488b842480000000	MOVQ 0x80(SP), AX							
  instance.go:372	0x5c824e		488b9c2488000000	MOVQ 0x88(SP), BX							
  instance.go:372	0x5c8256		4889d7			MOVQ DX, DI								
  instance.go:372	0x5c8259		4c89d6			MOVQ R10, SI								
  instance.go:372	0x5c825c		4989f0			MOVQ SI, R8								
  instance.go:372	0x5c825f		90			NOPL									
  instance.go:372	0x5c8260		e8dbe0ffff		CALL dario.cat/cocoon/rt.FromStatus(SB)					
  instance.go:372	0x5c8265		4885c0			TESTQ AX, AX								
  instance.go:372	0x5c8268		751d			JNE 0x5c8287								
  instance.go:376	0x5c826a		488b542458		MOVQ 0x58(SP), DX							
  instance.go:376	0x5c826f		4c8b542438		MOVQ 0x38(SP), R10							
  instance.go:376	0x5c8274		4889d0			MOVQ DX, AX								
  instance.go:376	0x5c8277		4c89d3			MOVQ R10, BX								
  instance.go:376	0x5c827a		4889d9			MOVQ BX, CX								
  instance.go:376	0x5c827d		31ff			XORL DI, DI								
  instance.go:376	0x5c827f		31f6			XORL SI, SI								
  instance.go:376	0x5c8281		4883c468		ADDQ $0x68, SP								
  instance.go:376	0x5c8285		5d			POPQ BP									
  instance.go:376	0x5c8286		c3			RET									
  instance.go:373	0x5c8287		31c9			XORL CX, CX								
  instance.go:373	0x5c8289		4889c7			MOVQ AX, DI								
  instance.go:373	0x5c828c		4889de			MOVQ BX, SI								
  instance.go:373	0x5c828f		31c0			XORL AX, AX								
  instance.go:373	0x5c8291		4889cb			MOVQ CX, BX								
  instance.go:373	0x5c8294		4883c468		ADDQ $0x68, SP								
  instance.go:373	0x5c8298		5d			POPQ BP									
  instance.go:373	0x5c8299		c3			RET									
  instance.go:369	0x5c829a		31db			XORL BX, BX								
  instance.go:369	0x5c829c		4889c7			MOVQ AX, DI								
  instance.go:369	0x5c829f		4889ce			MOVQ CX, SI								
  instance.go:369	0x5c82a2		31c0			XORL AX, AX								
  instance.go:369	0x5c82a4		4889d9			MOVQ BX, CX								
  instance.go:369	0x5c82a7		4883c468		ADDQ $0x68, SP								
  instance.go:369	0x5c82ab		5d			POPQ BP									
  instance.go:369	0x5c82ac		c3			RET									
  instance.go:365	0x5c82ad		488b3d5c857000		MOVQ dario.cat/cocoon/rt.ErrTooLarge(SB), DI				
  instance.go:365	0x5c82b4		488b355d857000		MOVQ dario.cat/cocoon/rt.ErrTooLarge+8(SB), SI				
  instance.go:365	0x5c82bb		31c0			XORL AX, AX								
  instance.go:365	0x5c82bd		31db			XORL BX, BX								
  instance.go:365	0x5c82bf		4889d9			MOVQ BX, CX								
  instance.go:365	0x5c82c2		4883c468		ADDQ $0x68, SP								
  instance.go:365	0x5c82c6		5d			POPQ BP									
  instance.go:365	0x5c82c7		c3			RET									
  instance.go:360	0x5c82c8		31c0			XORL AX, AX								
  instance.go:360	0x5c82ca		31db			XORL BX, BX								
  instance.go:360	0x5c82cc		4889d9			MOVQ BX, CX								
  instance.go:358	0x5c82cf		4889fa			MOVQ DI, DX								
  instance.go:360	0x5c82d2		4889f7			MOVQ SI, DI								
  instance.go:360	0x5c82d5		4889d6			MOVQ DX, SI								
  instance.go:360	0x5c82d8		4883c468		ADDQ $0x68, SP								
  instance.go:360	0x5c82dc		5d			POPQ BP									
  instance.go:360	0x5c82dd		c3			RET									
  binary.go:91		0x5c82de		6690			NOPW									
  binary.go:91		0x5c82e0		e8db86ecff		CALL runtime.panicBounds(SB)						
  binary.go:91		0x5c82e5		e8d686ecff		CALL runtime.panicBounds(SB)						
  binary.go:91		0x5c82ea		90			NOPL									
  instance.go:356	0x5c82eb		4889442408		MOVQ AX, 0x8(SP)							
  instance.go:356	0x5c82f0		48895c2410		MOVQ BX, 0x10(SP)							
  instance.go:356	0x5c82f5		48894c2418		MOVQ CX, 0x18(SP)							
  instance.go:356	0x5c82fa		897c2420		MOVL DI, 0x20(SP)							
  instance.go:356	0x5c82fe		6690			NOPW									
  instance.go:356	0x5c8300		e89b69ecff		CALL runtime.morestack_noctxt.abi0(SB)					
  instance.go:356	0x5c8305		488b442408		MOVQ 0x8(SP), AX							
  instance.go:356	0x5c830a		488b5c2410		MOVQ 0x10(SP), BX							
  instance.go:356	0x5c830f		488b4c2418		MOVQ 0x18(SP), CX							
  instance.go:356	0x5c8314		8b7c2420		MOVL 0x20(SP), DI							
  instance.go:356	0x5c8318		e9a3fdffff		JMP dario.cat/cocoon/rt.(*Call).ResultView(SB)				
