# ABI3 checked unit-reply phase0 adversarial entry, 2026-10-12

Read-only entry at clean6be3980 (merged PR7). Scope is a narrow ignored source-pinned existing-contract call-shape/specialization diagnostic, not implementation or new public ABI permission. Reviewer ran no builds/tests/lint/profiles/benchmarks and made no tracked edits. Stop all tools before root isolated profiles/timing.

## Contract and exact query/error order

Current generated Add performs full Lifecycle admission/release, Resource shared-cell identity/epoch/alive/Close/GC protection, Instance serialized state/reset/panic/postmemory/poison boundary, ResultView and nonempty-unit rejection. Scalar has no input reserve/copy. Existing ResultUnit simply calls ResultView once, propagates error, then rejects nonempty successful reply.

Preserve one captured current module.Memory() query within result validation: descriptor Range8 → pointer/size LE decode → size>MaxOutput → payload Range(memory,pointer,size) → nonOK FromStatus → nonempty successful-unit rejection. Payload Range must validate zero-length pointers against logical length (zero/logical-end valid; spare-capacity/maxpointer invalid), as well as nonempty and widened-end cases. Descriptor must remain bounded too. Size limit wins over payload bounds and status; payload bounds win over status; FromStatus wins over unit-shape checks for nonOK. Preserve concrete error class/fields/message/sentinel/wrap details as well as errors.Is. Native ABI.Memory() may have observable query count, alternating values or panic; an extra query before a ResultView fallback is not equivalent. Capture once and use that same view throughout every success/error branch.

Keep the separate post-call Memory() query in Instance.Call unchanged: its MaxMemory failure can supersede earlier callback error and poisons. Do not cache/skip it. Initial NewInstance has its own queries; instrumentation must reset counters after successful init. No shortcut based on OK/size0/nonzero size may omit canonical descriptor/payload/limit checks or change status/pointer/error priority. FromStatus currently owns strings/messages but does not impose UTF8 validation; preserve exact existing bytes, including NUL/invalid UTF8. No view/Call escapes or survives guest invocation.

## Controls and credible ceiling

Primary untouched generated-facade baseline is essential. Same-call-shape control replaces only existing unit decoder tail with old ResultUnit, while keeping its body unchanged. Candidate uses exactly that facade shape with specialized ResultUnit; compare against both to distinguish generator call shape from helper implementation/linking. Keep guest/Wasm/Rust/facade input/admission/Resource/Instance/lifecycle/reset/recovery/limits unchanged; no synthetic unprotected wrapper can substitute supported scalar calls. Do not revive prior R1–R7/R11 Call/recovery/helper-boundary rewrites without independent new evidence. Profile ResultView10.42% cumulative is neither a removable-ns bound nor additive attainable share/M1 promise. Raw and empty layers are context only.

Full source hashes + recorded exact diffs pin private runtime/facade overlays; separate ordinary binaries/profile/SSA identities. Adding only benchmark files previously reversed signs, so preserve original harness linking and bracket changed diagnostics with untouched frozen binary. Actual measured leaf GOMAXPROCS assertions/metrics, Go1.26.8 CGO0 PGOoff, isolated profiles separately from seven alternating500ms + seven reversed1s sample rounds. Full scalar/corpora/negative/increasing/broad and SQL/batch/trace/stream guards, fresh independent locked reference, full raw data/no outlier filtering. Calibrated increasing prefixes differ and are evolving state; no additive layer subtraction or historical-gain sums. Guest state/count/full-protobuf finite matched oracles outside timing.

## Executable proof and adversarial mutants

Source-pinned baseline, same-call-shape control and candidate must agree on exact returned errors, ownership/healthy/epoch state, guest callbacks, memory-query count/order and final bytes. Instrument Memory() for query counters, alternating descriptors/lengths/backing and getter panics; verify exactly one reply-query plus original post-query for each relevant operation. Same captured memory across fallback must be proved, not merely asserted.

Cover truncated descriptor; logical len<cap and exact boundaries; zero-size valid/invalid ptr; nonempty OK with valid/out-of-range ptr; zero/exact/exceeded MaxOutput; unknown positive/negative/PENDING; every expected error with empty/nonempty/opaque-byte messages; invalid payload + badstatus; overlimit + badptr/badstatus; outputfault plus postmemory overMax; expected-error healthy reuse and owned-message stability after overwrite; stale Call reset/panic metadata. Immediate protocol poison/stale aliases/no next callback, Close waits while active then rejects admission, alias-close/destructor once, traps/import panic shield remain unchanged. Compare actual facade outputs with current original-Wasm oracle for success/error/NaN/Inf/boundary histories.

Deliberate mutants must fail semantic tests: skip empty-pointer Range; short-circuit nonempty before limit/range/status; second Memory query on fallback; return borrowed expected-error message; omit post-MaxMemory check/poison. Parent harness must reject child failures semantically (explicit mismatch markers), not accept compiler/startup crashes as proof. No invalid physical-memory access; accessible spare backing catches logical violations safely. Available native amd64/386 and checked error/race proof later; no native arm64/big-endian performance claim.

No new public API/ABI/schema/ownership/cancellation contract follows. A payload-free-unit/typed-return ABI proposal needs explicit compatibility/migration spec and operator approval before implementation. This phase0 only measures an existing-ABI checked shape. If it lacks repeatable supported-scalar gain or creates repeated scalar/SQL guard losses, park it and retain evidence rather than rescue via skipped checks/retimed subsets/new contract. M1 stays unaccepted until full original/fresh criteria actually pass.

## Read input identities

{
  "rt/instance.go": "607103f216fb1da1445e705deaea8891f21cbdd04f74e385f4958795ef107d74",
  "rt/errors.go": "08701336f91d84ef2b061f091eee8fc23ec5be2a67b39d315bdeb34ab970317e",
  "rt/lifecycle.go": "f3d9d622162f78f0b952e44a9aa21a5c1933d366e5078dbf93e8eada098b39b7",
  "rt/resource.go": "10576bedf0d4745afed6f73f4dd7db2c0f11c1018b302c2df5cfcfab96cfee8c",
  "rt/unit_result_test.go": "6607192109f3cd70579e8b208e7a1b323c74647f8402acfbf8010ca0c1ee1fab",
  "examples/datadog/go/dd/cocoon_gen.go": "3d5aeacda6069a347a0e91e7840792ec194b0cdfd414f3c33328ec037231d672",
  "examples/datadog/go/dd/internal/wasm/module.go": "626550cafa323c490a6a2ec6b2b341656c40e223c7c84701e414078633dcc298"
}
