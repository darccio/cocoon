TEXT dario.cat/cocoon/rt.(*Call).ResultUnit(SB) /home/dario/Code/cocoon/rt/instance.go
  instance.go:335	0x5c7ec0		493b6610		CMPQ SP, 0x10(R14)							
  instance.go:335	0x5c7ec4		0f86af010000		JBE 0x5c8079								
  instance.go:335	0x5c7eca		55			PUSHQ BP								
  instance.go:335	0x5c7ecb		4889e5			MOVQ SP, BP								
  instance.go:335	0x5c7ece		4883ec60		SUBQ $0x60, SP								
  instance.go:72	0x5c7ed2		4889442470		MOVQ AX, 0x70(SP)							
  instance.go:72	0x5c7ed7		89bc2488000000		MOVL DI, 0x88(SP)							
  instance.go:72	0x5c7ede		48898c2480000000	MOVQ CX, 0x80(SP)							
  instance.go:72	0x5c7ee6		48895c2478		MOVQ BX, 0x78(SP)							
  instance.go:336	0x5c7eeb		488b08			MOVQ 0(AX), CX								
  instance.go:336	0x5c7eee		488b11			MOVQ 0(CX), DX								
  instance.go:336	0x5c7ef1		488b4108		MOVQ 0x8(CX), AX							
  instance.go:336	0x5c7ef5		488b4a20		MOVQ 0x20(DX), CX							
  instance.go:336	0x5c7ef9		ffd1			CALL CX									
  instance.go:336	0x5c7efb		48895c2440		MOVQ BX, 0x40(SP)							
  instance.go:337	0x5c7f00		488b542470		MOVQ 0x70(SP), DX							
  instance.go:337	0x5c7f05		488b32			MOVQ 0(DX), SI								
  instance.go:337	0x5c7f08		8b7660			MOVL 0x60(SI), SI							
  instance.go:71	0x5c7f0b		488d7e08		LEAQ 0x8(SI), DI							
  instance.go:72	0x5c7f0f		4839fb			CMPQ BX, DI								
  instance.go:72	0x5c7f12		7221			JB 0x5c7f35								
  instance.go:75	0x5c7f14		4189f3			MOVL SI, R11								
  instance.go:75	0x5c7f17		4829f6			SUBQ SI, SI								
  instance.go:75	0x5c7f1a		4c8d6608		LEAQ 0x8(SI), R12							
  instance.go:75	0x5c7f1e		4d89e5			MOVQ R12, R13								
  instance.go:75	0x5c7f21		49f7dc			NEGQ R12								
  instance.go:75	0x5c7f24		49c1fc3f		SARQ $0x3f, R12								
  instance.go:75	0x5c7f28		4d21dc			ANDQ R11, R12								
  instance.go:75	0x5c7f2b		4e8d1c20		LEAQ 0(AX)(R12*1), R11							
  instance.go:75	0x5c7f2f		31f6			XORL SI, SI								
  instance.go:75	0x5c7f31		31ff			XORL DI, DI								
  instance.go:337	0x5c7f33		eb59			JMP 0x5c7f8e								
  instance.go:337	0x5c7f35		89742438		MOVL SI, 0x38(SP)							
  instance.go:71	0x5c7f39		48897c2450		MOVQ DI, 0x50(SP)							
  instance.go:336	0x5c7f3e		48894c2448		MOVQ CX, 0x48(SP)							
  instance.go:336	0x5c7f43		4889442458		MOVQ AX, 0x58(SP)							
  instance.go:73	0x5c7f48		488d0551932c00		LEAQ 0x2c9351(IP), AX							
  instance.go:73	0x5c7f4f		e8cca2e5ff		CALL runtime.newobject(SB)						
  instance.go:73	0x5c7f54		8b4c2438		MOVL 0x38(SP), CX							
  instance.go:73	0x5c7f58		894810			MOVL CX, 0x10(AX)							
  instance.go:73	0x5c7f5b		488b4c2450		MOVQ 0x50(SP), CX							
  instance.go:73	0x5c7f60		488908			MOVQ CX, 0(AX)								
  instance.go:73	0x5c7f63		488b742440		MOVQ 0x40(SP), SI							
  instance.go:73	0x5c7f68		48897008		MOVQ SI, 0x8(AX)							
  instance.go:350	0x5c7f6c		488b4c2448		MOVQ 0x48(SP), CX							
  instance.go:343	0x5c7f71		488b542470		MOVQ 0x70(SP), DX							
  instance.go:350	0x5c7f76		4889f3			MOVQ SI, BX								
  instance.go:350	0x5c7f79		488d3520d53300		LEAQ go:itab.*dario.cat/cocoon/rt.memoryRangeError,error(SB), SI	
  instance.go:350	0x5c7f80		4531ed			XORL R13, R13								
  instance.go:350	0x5c7f83		4531db			XORL R11, R11								
  instance.go:337	0x5c7f86		4889c7			MOVQ AX, DI								
  instance.go:350	0x5c7f89		488b442458		MOVQ 0x58(SP), AX							
  instance.go:338	0x5c7f8e		4885f6			TESTQ SI, SI								
  instance.go:338	0x5c7f91		0f85cb000000		JNE 0x5c8062								
  instance.go:341	0x5c7f97		90			NOPL									
  instance.go:341	0x5c7f98		0f1f840000000000	NOPL 0(AX)(AX*1)							
  binary.go:91		0x5c7fa0		4983fd03		CMPQ R13, $0x3								
  binary.go:91		0x5c7fa4		0f86c9000000		JBE 0x5c8073								
  instance.go:342	0x5c7faa		4d8d65fc		LEAQ -0x4(R13), R12							
  binary.go:91		0x5c7fae		4983fc03		CMPQ R12, $0x3								
  binary.go:91		0x5c7fb2		0f86b6000000		JBE 0x5c806e								
  instance.go:342	0x5c7fb8		49f7dc			NEGQ R12								
  instance.go:342	0x5c7fbb		49c1fc3f		SARQ $0x3f, R12								
  instance.go:342	0x5c7fbf		4183e404		ANDL $0x4, R12								
  instance.go:343	0x5c7fc3		488b12			MOVQ 0(DX), DX								
  binary.go:92		0x5c7fc6		478b1423		MOVL 0(R11)(R12*1), R10							
  instance.go:343	0x5c7fca		4c395238		CMPQ 0x38(DX), R10							
  instance.go:343	0x5c7fce		727e			JB 0x5c804e								
  binary.go:92		0x5c7fd0		458b0b			MOVL 0(R11), R9								
  instance.go:346	0x5c7fd3		8b942488000000		MOVL 0x88(SP), DX							
  instance.go:346	0x5c7fda		85d2			TESTL DX, DX								
  instance.go:346	0x5c7fdc		754d			JNE 0x5c802b								
  instance.go:346	0x5c7fde		6690			NOPW									
  instance.go:346	0x5c7fe0		4585d2			TESTL R10, R10								
  instance.go:346	0x5c7fe3		7546			JNE 0x5c802b								
  instance.go:72	0x5c7fe5		4c39cb			CMPQ BX, R9								
  instance.go:72	0x5c7fe8		7206			JB 0x5c7ff0								
  instance.go:72	0x5c7fea		31c0			XORL AX, AX								
  instance.go:72	0x5c7fec		31c9			XORL CX, CX								
  instance.go:347	0x5c7fee		eb32			JMP 0x5c8022								
  binary.go:92		0x5c7ff0		44894c243c		MOVL R9, 0x3c(SP)							
  instance.go:73	0x5c7ff5		488d05a4922c00		LEAQ 0x2c92a4(IP), AX							
  instance.go:73	0x5c7ffc		0f1f4000		NOPL 0(AX)								
  instance.go:73	0x5c8000		e81ba2e5ff		CALL runtime.newobject(SB)						
  instance.go:73	0x5c8005		8b4c243c		MOVL 0x3c(SP), CX							
  instance.go:73	0x5c8009		894810			MOVL CX, 0x10(AX)							
  instance.go:73	0x5c800c		488908			MOVQ CX, 0(AX)								
  instance.go:73	0x5c800f		488b4c2440		MOVQ 0x40(SP), CX							
  instance.go:73	0x5c8014		48894808		MOVQ CX, 0x8(AX)							
  instance.go:347	0x5c8018		4889c1			MOVQ AX, CX								
  instance.go:347	0x5c801b		488d057ed43300		LEAQ go:itab.*dario.cat/cocoon/rt.memoryRangeError,error(SB), AX	
  instance.go:348	0x5c8022		4889cb			MOVQ CX, BX								
  instance.go:348	0x5c8025		4883c460		ADDQ $0x60, SP								
  instance.go:348	0x5c8029		5d			POPQ BP									
  instance.go:348	0x5c802a		c3			RET									
  instance.go:350	0x5c802b		4889c7			MOVQ AX, DI								
  instance.go:350	0x5c802e		4889de			MOVQ BX, SI								
  instance.go:350	0x5c8031		4989c8			MOVQ CX, R8								
  instance.go:350	0x5c8034		488b442478		MOVQ 0x78(SP), AX							
  instance.go:350	0x5c8039		488b9c2480000000	MOVQ 0x80(SP), BX							
  instance.go:350	0x5c8041		89d1			MOVL DX, CX								
  instance.go:350	0x5c8043		e8d8020000		CALL dario.cat/cocoon/rt.unitReplyTail(SB)				
  instance.go:350	0x5c8048		4883c460		ADDQ $0x60, SP								
  instance.go:350	0x5c804c		5d			POPQ BP									
  instance.go:350	0x5c804d		c3			RET									
  instance.go:344	0x5c804e		488b05bb877000		MOVQ dario.cat/cocoon/rt.ErrTooLarge(SB), AX				
  instance.go:344	0x5c8055		488b1dbc877000		MOVQ dario.cat/cocoon/rt.ErrTooLarge+8(SB), BX				
  instance.go:344	0x5c805c		4883c460		ADDQ $0x60, SP								
  instance.go:344	0x5c8060		5d			POPQ BP									
  instance.go:344	0x5c8061		c3			RET									
  instance.go:339	0x5c8062		4889f0			MOVQ SI, AX								
  instance.go:339	0x5c8065		4889fb			MOVQ DI, BX								
  instance.go:339	0x5c8068		4883c460		ADDQ $0x60, SP								
  instance.go:339	0x5c806c		5d			POPQ BP									
  instance.go:339	0x5c806d		c3			RET									
  binary.go:91		0x5c806e		e84d89ecff		CALL runtime.panicBounds(SB)						
  binary.go:91		0x5c8073		e84889ecff		CALL runtime.panicBounds(SB)						
  binary.go:91		0x5c8078		90			NOPL									
  instance.go:335	0x5c8079		4889442408		MOVQ AX, 0x8(SP)							
  instance.go:335	0x5c807e		48895c2410		MOVQ BX, 0x10(SP)							
  instance.go:335	0x5c8083		48894c2418		MOVQ CX, 0x18(SP)							
  instance.go:335	0x5c8088		897c2420		MOVL DI, 0x20(SP)							
  instance.go:335	0x5c808c		e80f6cecff		CALL runtime.morestack_noctxt.abi0(SB)					
  instance.go:335	0x5c8091		488b442408		MOVQ 0x8(SP), AX							
  instance.go:335	0x5c8096		488b5c2410		MOVQ 0x10(SP), BX							
  instance.go:335	0x5c809b		488b4c2418		MOVQ 0x18(SP), CX							
  instance.go:335	0x5c80a0		8b7c2420		MOVL 0x20(SP), DI							
  instance.go:335	0x5c80a4		e917feffff		JMP dario.cat/cocoon/rt.(*Call).ResultUnit(SB)				
