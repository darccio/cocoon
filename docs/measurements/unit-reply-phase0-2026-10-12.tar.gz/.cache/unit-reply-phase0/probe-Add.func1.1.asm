TEXT dario.cat/cocoon/examples/datadog/go/dd.(*Sketch).Add.func1.1(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/cocoon_gen.go
  cocoon_gen.go:583	0x7de9c0		493b6610		CMPQ SP, 0x10(R14)										
  cocoon_gen.go:583	0x7de9c4		7645			JBE 0x7dea0b											
  cocoon_gen.go:583	0x7de9c6		55			PUSHQ BP											
  cocoon_gen.go:583	0x7de9c7		4889e5			MOVQ SP, BP											
  cocoon_gen.go:583	0x7de9ca		4883ec20		SUBQ $0x20, SP											
  cocoon_gen.go:585	0x7de9ce		4889442430		MOVQ AX, 0x30(SP)										
  cocoon_gen.go:583	0x7de9d3		488b5a10		MOVQ 0x10(DX), BX										
  cocoon_gen.go:583	0x7de9d7		f20f104218		MOVSD_XMM 0x18(DX), X0										
  cocoon_gen.go:583	0x7de9dc		488b4a08		MOVQ 0x8(DX), CX										
  cocoon_gen.go:584	0x7de9e0		488b09			MOVQ 0(CX), CX											
  cocoon_gen.go:584	0x7de9e3		488b01			MOVQ 0(CX), AX											
  cocoon_gen.go:584	0x7de9e6		e8757fe7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).Xcocoon_sketch_add(SB)	
  cocoon_gen.go:585	0x7de9eb		488d1d02520f00		LEAQ 0xf5202(IP), BX										
  cocoon_gen.go:585	0x7de9f2		b903000000		MOVL $0x3, CX											
  cocoon_gen.go:585	0x7de9f7		89c7			MOVL AX, DI											
  cocoon_gen.go:585	0x7de9f9		488b442430		MOVQ 0x30(SP), AX										
  cocoon_gen.go:585	0x7de9fe		6690			NOPW												
  cocoon_gen.go:585	0x7dea00		e8bb94deff		CALL dario.cat/cocoon/rt.(*Call).ResultUnit(SB)							
  cocoon_gen.go:585	0x7dea05		4883c420		ADDQ $0x20, SP											
  cocoon_gen.go:585	0x7dea09		5d			POPQ BP												
  cocoon_gen.go:585	0x7dea0a		c3			RET												
  cocoon_gen.go:583	0x7dea0b		4889442408		MOVQ AX, 0x8(SP)										
  cocoon_gen.go:583	0x7dea10		e8eb01cbff		CALL runtime.morestack.abi0(SB)									
  cocoon_gen.go:583	0x7dea15		488b442408		MOVQ 0x8(SP), AX										
  cocoon_gen.go:583	0x7dea1a		eba4			JMP dario.cat/cocoon/examples/datadog/go/dd.(*Sketch).Add.func1.1(SB)				
