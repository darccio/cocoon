package main

import (
	"fmt"
	"os"

	"dario.cat/cocoon/internal/gen/gogen"
	"dario.cat/cocoon/internal/manifest"
)

func main() {
	if len(os.Args) != 3 {
		panic("manifest and output paths required")
	}
	data, err := os.ReadFile(os.Args[1])
	if err != nil {
		panic(err)
	}
	m, err := manifest.Parse(data)
	if err != nil {
		panic(err)
	}
	generated, err := gogen.Facade(m)
	if err != nil {
		panic(err)
	}
	if err := os.WriteFile(os.Args[2], generated, 0o600); err != nil {
		panic(err)
	}
	fmt.Println("Generated", os.Args[2])
}
