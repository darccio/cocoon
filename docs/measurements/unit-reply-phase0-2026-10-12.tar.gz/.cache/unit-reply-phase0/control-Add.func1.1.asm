TEXT dario.cat/cocoon/examples/datadog/go/dd.(*Sketch).Add.func1.1(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/cocoon_gen.go
  cocoon_gen.go:583	0x7de6e0		493b6610		CMPQ SP, 0x10(R14)										
  cocoon_gen.go:583	0x7de6e4		7645			JBE 0x7de72b											
  cocoon_gen.go:583	0x7de6e6		55			PUSHQ BP											
  cocoon_gen.go:583	0x7de6e7		4889e5			MOVQ SP, BP											
  cocoon_gen.go:583	0x7de6ea		4883ec20		SUBQ $0x20, SP											
  cocoon_gen.go:585	0x7de6ee		4889442430		MOVQ AX, 0x30(SP)										
  cocoon_gen.go:583	0x7de6f3		488b5a10		MOVQ 0x10(DX), BX										
  cocoon_gen.go:583	0x7de6f7		f20f104218		MOVSD_XMM 0x18(DX), X0										
  cocoon_gen.go:583	0x7de6fc		488b4a08		MOVQ 0x8(DX), CX										
  cocoon_gen.go:584	0x7de700		488b09			MOVQ 0(CX), CX											
  cocoon_gen.go:584	0x7de703		488b01			MOVQ 0(CX), AX											
  cocoon_gen.go:584	0x7de706		e8757fe7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).Xcocoon_sketch_add(SB)	
  cocoon_gen.go:585	0x7de70b		488d1de2540f00		LEAQ 0xf54e2(IP), BX										
  cocoon_gen.go:585	0x7de712		b903000000		MOVL $0x3, CX											
  cocoon_gen.go:585	0x7de717		89c7			MOVL AX, DI											
  cocoon_gen.go:585	0x7de719		488b442430		MOVQ 0x30(SP), AX										
  cocoon_gen.go:585	0x7de71e		6690			NOPW												
  cocoon_gen.go:585	0x7de720		e89b97deff		CALL dario.cat/cocoon/rt.(*Call).ResultUnit(SB)							
  cocoon_gen.go:585	0x7de725		4883c420		ADDQ $0x20, SP											
  cocoon_gen.go:585	0x7de729		5d			POPQ BP												
  cocoon_gen.go:585	0x7de72a		c3			RET												
  cocoon_gen.go:583	0x7de72b		4889442408		MOVQ AX, 0x8(SP)										
  cocoon_gen.go:583	0x7de730		e8cb04cbff		CALL runtime.morestack.abi0(SB)									
  cocoon_gen.go:583	0x7de735		488b442408		MOVQ 0x8(SP), AX										
  cocoon_gen.go:583	0x7de73a		eba4			JMP dario.cat/cocoon/examples/datadog/go/dd.(*Sketch).Add.func1.1(SB)				
