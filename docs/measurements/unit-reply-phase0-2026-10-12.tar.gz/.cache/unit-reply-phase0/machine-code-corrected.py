from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess

root = Path.cwd()
out = root / '.cache/unit-reply-phase0'
obj = root / '.cache/translation-analysis/objdump'
nm = root / '.cache/translation-analysis/nm'
summary, records = {}, []
for role in ('baseline', 'control', 'probe'):
    binary = out / (role + '.test')
    symbols = subprocess.check_output([str(nm), '-size', str(binary)], text=True)
    (out / (role + '-symbols.txt')).write_text(symbols)
    rows = [row.split() for row in symbols.splitlines()]
    summary[role] = {'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest()}
    for name in ('fn176', 'fn96', 'Xcocoon_sketch_add', 'ResultView', 'ResultUnit', 'unitReplyTail', 'Range', 'Add.func1.1'):
        matches = [row for row in rows if len(row) == 4 and row[2] in ('T', 't') and row[3].endswith('.' + name) and
                   (('/wasm.' in row[3]) if name in ('fn176', 'fn96', 'Xcocoon_sketch_add') else
                    ('dario.cat/cocoon/rt.' in row[3] if name in ('ResultView', 'ResultUnit', 'unitReplyTail', 'Range') else '/dd.' in row[3]))]
        if not matches:
            summary[role][name] = {'scope': 'No independent emitted symbol; no frame/count claim.'}
            continue
        assert len(matches) == 1, (role, name, matches)
        row = matches[0]
        argv = [str(obj), '-s', re.escape(row[3]) + '$', str(binary)]
        asm = subprocess.check_output(argv, text=True)
        assert asm.startswith('TEXT '), (role, name)
        filename = role + '-' + name + '.asm'
        (out / filename).write_text(asm)
        frame = 0
        for line in asm.splitlines():
            match = re.search(r'(SUBQ|ADDQ) \$(-?0x[0-9a-f]+), SP', line)
            if match:
                frame = int(match[2], 16) * (1 if match[1] == 'SUBQ' else -1)
                break
        summary[role][name] = {'text_bytes': int(row[1]), 'frame_bytes': frame,
                               'static_panic_bounds': len(re.findall(r'CALL runtime\.panicBounds', asm)),
                               'instructions': sum(bool(re.search(r'\s0x[0-9a-f]+\s', line)) for line in asm.splitlines())}
        records.append({'argv': argv, 'output': filename, 'sha256': hashlib.sha256(asm.encode()).hexdigest()})
(out / 'machine-code-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
(out / 'machine-code-provenance.json').write_text(json.dumps({'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'records': records, 'tools_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in (obj, nm)},
    'scope': 'Ordinary official Go1.26.8 PGOoff timing binaries. Static frames/instructions are not causal cost attribution. Initial script indentation failure preserved; corrected driver executed before timing.'}, indent=2) + '\n')
print(json.dumps(summary, indent=2), flush=True)
