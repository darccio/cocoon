# Unit-reply phase-0 final executable proof audit

Read-only review; this reviewer ran no proof/build/test/lint/profile/benchmark. Source, recorded commands, exact file hashes and runtime assertion logs were inspected. No tracked files changed.

## Final disposition

No remaining proof/source/plan blocker for isolated timing of this private, whole-source-pinned existing-ABI diagnostic. The applied-overlay review and qualification-plan review remain applicable. Final config must include these notes/final proof metadata and be frozen after all local tools stop. No production/API approval or performance claim follows from this pre-measurement verdict.

The independent runtime oracle compares explicit original ResultView+len shape and ResultUnit for every role, with fixed expected error strings/carriers, health/epoch, owned raw invalid-UTF8 message bytes, stale resources/no next callback, and getter event counts. Reply query counters are reset after initialization. The event oracle demands invoke → memory1 → callback-end → memory2 for ordinary replies, including descriptor/payload faults and statuses. Descriptor logical truncation, zero-size ptr0/ptrlen/ptr>len/maxpointer, uint64 endpoint overflow beyond u32, MaxOutput preceding payload/status/shape, reserved/unknown positive and negative statuses, and nonempty OK errors are executable cases. Alternating distinct backing slices prove the slow status path uses the first captured slice, not a second getter. Getter panic at reply or post-call query yields terminal fault/epoch change and invalidates prior owners. Post-memory growth supersedes success, protocol fault, expected guest error and output-limit error while poisoning. Input reservation resets across expected-error→empty-success; aliases run one destructor; malformed destructor faults stale siblings and repeat Close retains its error.

The fixture proof executes actual generated facades, including ordinary unit methods, generated destructor closure, ownership/home poisoning/replacement, logical unit bounds, expected errors, alias Close and lifecycle drain. Final proof-only unit_fixture_test overlays explicitly retain role-specific GOFLAGS=-overlay in the generated consumer's child Go process. The parent cwd is internal/gen/gogen, so its relative module root resolves to the repository; the child logs show the exact local official Go1.26.8 compiler, role overlay, CGO0 and amd64/386. Canonical timing overlays do not contain either extra-test or changed fixture-test mapping. The old parent-only overlay coverage gap and initial cwd→/home setup failure are preserved under historical directories, not treated as candidate semantics or successful final coverage.

Recorded runtime roles and generated fixture consumers pass natively on amd64 and386. All four mutants fail explicit semantic assertions on both architectures: omitted empty-range guard accepts ptr65/len64; early nonempty rejection loses detailed bounds precedence; second reply getter uses 'othe' and performs three queries; omitted post-memory limit returns healthy nil after growth. The driver requires nonzero plus TestUnitPhase0MutantProbe failure plus 'unit semantic mismatch', so setup/compilation/crash failures cannot count. The archive must keep these source/log/command histories. No native big-endian/arm64 execution is claimed.

All final-provenance identity entries reviewed here match current bytes: 85 hashes covering source, canonical/proof overlays, altered fixtures, mutant sources, native proof binaries and logs. This confirms recorded artifacts rather than independently rerunning them. The ordinary timing binaries still come from the canonical authored-source/facade overlays and unchanged harness; additional proof source is confined to separately compiled proof binaries.

All reviewer tools are stopped after writing this note. Subsequent measurement must use fresh same-toolchain baseline/control/probe/reference, preserve the declared924 samples and all negatives, and apply the strict original-scalar two-control/two-round promotion rule. P16 stream evidence cannot support P1/default-stream equivalence; later production qualification must add that guard. Profile/layer data remain nonadditive and M1 remains unaccepted.

## Reviewed identities

```json
{
  ".cache/unit-reply-phase0/proof/driver.py": "34ad68f192c01dc822879b200b667b3a8dcfea36bd3ff298fc0d40fada5e3d16",
  ".cache/unit-reply-phase0/proof/unit_phase0_extra_test.go": "5ab61d8e075a70c04cb49a0b22d9222e923768502c0d52fe6b8c7393e313782c",
  ".cache/unit-reply-phase0/proof/final-provenance.json": "e1237c541e05afaddfb4c3194ef593485e448fd08fdf13d75581f7df053c8113",
  "internal/gen/gogen/unit_fixture_test.go": "ddf789ab03a5a3932cf20998a9e8f6cb0c2c0aba2d54e5f040116c82079842d8",
  "internal/gen/gogen/testdata/unit/module_test.go": "1053e0de9796f0a6fb63d5b94bf5b21f3709baa8992784afb3757563aa43d122",
  "internal/gen/gogen/testdata/unit/homes_test.go": "ca6058b6e6800627680332f1798cf124b2af8c085829d96174152f04afb6a88e"
}
```
