TEXT dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn176(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/internal/wasm/module.go
  module.go:35694	0x630200		4c8d6424f8		LEAQ -0x8(SP), R12								
  module.go:35694	0x630205		4d3b6610		CMPQ R12, 0x10(R14)								
  module.go:35694	0x630209		0f8617150000		JBE 0x631726									
  module.go:35694	0x63020f		55			PUSHQ BP									
  module.go:35694	0x630210		4889e5			MOVQ SP, BP									
  module.go:35694	0x630213		4883c480		ADDQ $-0x80, SP									
  module.go:35713	0x630217		4889842490000000	MOVQ AX, 0x90(SP)								
  module.go:35713	0x63021f		899c2498000000		MOVL BX, 0x98(SP)								
  module.go:35699	0x630226		8b5050			MOVL 0x50(AX), DX								
  module.go:35699	0x630229		89542434		MOVL DX, 0x34(SP)								
  module.go:35705	0x63022d		448d4ae0		LEAL -0x20(DX), R9								
  module.go:35706	0x630231		44894850		MOVL R9, 0x50(AX)								
  unsafe.go:35		0x630235		66490f7ec2		MOVQ X0, R10									
  module.go:35711	0x63023a		4d89d3			MOVQ R10, R11									
  module.go:35711	0x63023d		490fbaf23f		BTRQ $0x3f, R10									
  module.go:35713	0x630242		4d8d62ff		LEAQ -0x1(R10), R12								
  module.go:35733	0x630246		49bd000000000000f0ff	MOVQ $0xfff0000000000000, R13							
  module.go:35733	0x630250		4d01d5			ADDQ R10, R13									
  module.go:35710	0x630253		90			NOPL										
  module.go:35713	0x630254		49bfffffffffffff0f00	MOVQ $0xfffffffffffff, R15							
  module.go:35713	0x63025e		4d39e7			CMPQ R15, R12									
  module.go:35713	0x630261		410f97c4		SETA R12									
  module.go:35714	0x630265		450fb6e4		MOVZX R12, R12									
  module.go:35717	0x630269		4d85db			TESTQ R11, R11									
  module.go:35717	0x63026c		410f9cc7		SETL R15									
  module.go:35718	0x630270		450fb6ff		MOVZX R15, R15									
  module.go:35721	0x630274		4521fc			ANDL R15, R12									
  module.go:35705	0x630277		4489ce			MOVL R9, SI									
  module.go:35728	0x63027a		49b9000000000000f07f	MOVQ $0x7ff0000000000000, R9							
  module.go:35728	0x630284		4d39d1			CMPQ R9, R10									
  module.go:35723	0x630287		410f94c1		SETE R9										
  module.go:35728	0x63028b		410f92c2		SETB R10									
  module.go:35724	0x63028f		450fb6c9		MOVZX R9, R9									
  module.go:35726	0x630293		4509cc			ORL R9, R12									
  module.go:35729	0x630296		450fb6ca		MOVZX R10, R9									
  module.go:35731	0x63029a		4509cc			ORL R9, R12									
  module.go:35733	0x63029d		49b9000000000000e07f	MOVQ $0x7fe0000000000000, R9							
  module.go:35733	0x6302a7		4d39e9			CMPQ R9, R13									
  module.go:35733	0x6302aa		410f97c1		SETA R9										
  module.go:35734	0x6302ae		450fb6c9		MOVZX R9, R9									
  module.go:35736	0x6302b2		4521f9			ANDL R15, R9									
  module.go:35736	0x6302b5		4509e1			ORL R12, R9									
  module.go:35736	0x6302b8		0f1f840000000000	NOPL 0(AX)(AX*1)								
  module.go:35736	0x6302c0		4585c9			TESTL R9, R9									
  module.go:35736	0x6302c3		0f85f0080000		JNE 0x630bb9									
  module.go:35772	0x6302c9		4c8b4838		MOVQ 0x38(AX), R9								
  module.go:35772	0x6302cd		4189ca			MOVL CX, R10									
  module.go:63009	0x6302d0		4d8d6237		LEAQ 0x37(R10), R12								
  module.go:63009	0x6302d4		4d39e1			CMPQ R9, R12									
  module.go:63009	0x6302d7		0f8641140000		JBE 0x63171e									
  module.go:35772	0x6302dd		4c8b4830		MOVQ 0x30(AX), R9								
  module.go:63010	0x6302e1		4f8b4c0a30		MOVQ 0x30(R10)(R9*1), R9							
  unsafe.go:41		0x6302e6		66490f6ec9		MOVQ R9, X1									
  module.go:35773	0x6302eb		660f2ec8		UCOMISD X0, X1									
  module.go:35773	0x6302ef		0f8779080000		JA 0x630b6e									
  module.go:35774	0x6302f5		4c8b4838		MOVQ 0x38(AX), R9								
  module.go:63009	0x6302f9		4d8d622f		LEAQ 0x2f(R10), R12								
  module.go:63009	0x6302fd		0f1f00			NOPL 0(AX)									
  module.go:63009	0x630300		4d39e1			CMPQ R9, R12									
  module.go:63009	0x630303		0f8610140000		JBE 0x631719									
  module.go:35774	0x630309		4c8b4830		MOVQ 0x30(AX), R9								
  module.go:63010	0x63030d		4f8b4c0a28		MOVQ 0x28(R10)(R9*1), R9							
  module.go:35780	0x630312		49bc0000000000001000	MOVQ $0x10000000000000, R12							
  module.go:35780	0x63031c		0f1f4000		NOPL 0(AX)									
  module.go:35780	0x630320		4d39e3			CMPQ R11, R12									
  module.go:35780	0x630323		7c45			JL 0x63036a									
  module.go:35781	0x630325		49bcffffffffffffef7f	MOVQ $0x7fefffffffffffff, R12							
  module.go:35781	0x63032f		4d39e3			CMPQ R11, R12									
  module.go:35781	0x630332		0f87c2010000		JA 0x6304fa									
  module.go:35785	0x630338		4d89dc			MOVQ R11, R12									
  module.go:35785	0x63033b		49c1eb20		SHRQ $0x20, R11									
  module.go:35785	0x63033f		90			NOPL										
  module.go:35786	0x630340		4981fb0000f03f		CMPQ R11, $0x3ff00000								
  module.go:35786	0x630347		7407			JE 0x630350									
  module.go:35786	0x630349		be01fcffff		MOVL $-0x3ff, SI								
  module.go:35789	0x63034e		eb7b			JMP 0x6303cb									
  module.go:35791	0x630350		4585e4			TESTL R12, R12									
  module.go:35791	0x630353		740d			JE 0x630362									
  module.go:35791	0x630355		41bb0000f03f		MOVL $0x3ff00000, R11								
  module.go:35791	0x63035b		be01fcffff		MOVL $-0x3ff, SI								
  module.go:35793	0x630360		eb69			JMP 0x6303cb									
  module.go:35793	0x630362		0f57c0			XORPS X0, X0									
  module.go:35796	0x630365		e990010000		JMP 0x6304fa									
  module.go:35798	0x63036a		0f10c8			MOVUPS X0, X1									
  module.go:35798	0x63036d		f20f59c0		MULSD X0, X0									
  module.go:35798	0x630371		f20f1015e71d2d00	MOVSD_XMM $f64.bff0000000000000(SB), X2						
  module.go:35798	0x630379		f20f5ed0		DIVSD X0, X2									
  module.go:35799	0x63037d		0f57db			XORPS X3, X3									
  module.go:35799	0x630380		660f2ecb		UCOMISD X3, X1									
  module.go:35799	0x630384		750a			JNE 0x630390									
  module.go:35799	0x630386		7a08			JP 0x630390									
  module.go:35795	0x630388		0f10c2			MOVUPS X2, X0									
  module.go:35801	0x63038b		e96a010000		JMP 0x6304fa									
  module.go:35717	0x630390		4d85db			TESTQ R11, R11									
  module.go:35803	0x630393		7d10			JGE 0x6303a5									
  module.go:35828	0x630395		f20f5cc9		SUBSD X1, X1									
  module.go:35828	0x630399		f20f5ecb		DIVSD X3, X1									
  module.go:35828	0x63039d		0f10c1			MOVUPS X1, X0									
  module.go:35829	0x6303a0		e955010000		JMP 0x6304fa									
  module.go:35807	0x6303a5		f20f1015a31d2d00	MOVSD_XMM $f64.4350000000000000(SB), X2						
  module.go:35807	0x6303ad		f20f59d1		MULSD X1, X2									
  unsafe.go:35		0x6303b1		66490f7ed3		MOVQ X2, R11									
  module.go:35808	0x6303b6		4d89dc			MOVQ R11, R12									
  module.go:35808	0x6303b9		49c1ec20		SHRQ $0x20, R12									
  module.go:35808	0x6303bd		becbfbffff		MOVL $-0x435, SI								
  module.go:35792	0x6303c2		4c89df			MOVQ R11, DI									
  module.go:35792	0x6303c5		4d89e3			MOVQ R12, R11									
  module.go:35807	0x6303c8		4989fc			MOVQ DI, R12									
  module.go:35811	0x6303cb		4181c3625f0900		ADDL $0x95f62, R11								
  module.go:35812	0x6303d2		4589dd			MOVL R11, R13									
  module.go:35812	0x6303d5		41c1eb14		SHRL $0x14, R11									
  module.go:35812	0x6303d9		4101f3			ADDL SI, R11									
  module.go:35812	0x6303dc		0f57d2			XORPS X2, X2									
  module.go:35812	0x6303df		f2410f2ad3		CVTSI2SDL R11, X2								
  module.go:35813	0x6303e4		f20f100d3c1d2d00	MOVSD_XMM $f64.3fe62e42fee00000(SB), X1						
  module.go:35813	0x6303ec		f20f59ca		MULSD X2, X1									
  module.go:35814	0x6303f0		41bbffffffff		MOVL $-0x1, R11									
  module.go:35814	0x6303f6		4d21dc			ANDQ R11, R12									
  module.go:35814	0x6303f9		4181e5ffff0f00		ANDL $0xfffff, R13								
  module.go:35814	0x630400		458d9d9ea0e63f		LEAL 0x3fe6a09e(R13), R11							
  module.go:35814	0x630407		4589db			MOVL R11, R11									
  module.go:35814	0x63040a		49c1e320		SHLQ $0x20, R11									
  module.go:35814	0x63040e		4d09dc			ORQ R11, R12									
  module.go:35816	0x630411		f20f101dcf1c2d00	MOVSD_XMM $f64.3dea39ef35793c76(SB), X3						
  module.go:35816	0x630419		f20f59d3		MULSD X3, X2									
  unsafe.go:41		0x63041d		66490f6edc		MOVQ R12, X3									
  module.go:35814	0x630422		f20f1025361d2d00	MOVSD_XMM $f64.bff0000000000000(SB), X4						
  module.go:35814	0x63042a		f20f58e3		ADDSD X3, X4									
  module.go:35817	0x63042e		f20f101d3a1b2d00	MOVSD_XMM $f64.4000000000000000(SB), X3						
  module.go:35817	0x630436		f20f58dc		ADDSD X4, X3									
  module.go:35817	0x63043a		0f10ec			MOVUPS X4, X5									
  module.go:35817	0x63043d		f20f5ee3		DIVSD X3, X4									
  module.go:35819	0x630441		f20f101da71b2d00	MOVSD_XMM $f64.3fe0000000000000(SB), X3						
  module.go:35819	0x630449		f20f59dd		MULSD X5, X3									
  module.go:35819	0x63044d		f20f59dd		MULSD X5, X3									
  module.go:35821	0x630451		0f10f4			MOVUPS X4, X6									
  module.go:35821	0x630454		f20f59e4		MULSD X4, X4									
  module.go:35822	0x630458		0f10fc			MOVUPS X4, X7									
  module.go:35822	0x63045b		f20f59e4		MULSD X4, X4									
  module.go:35823	0x63045f		f2440f1005901c2d00	MOVSD_XMM $f64.3fc39a09d078c69f(SB), X8						
  module.go:35823	0x630468		f2440f59c4		MULSD X4, X8									
  module.go:35823	0x63046d		f2440f100d921c2d00	MOVSD_XMM $f64.3fcc71c51d8e78af(SB), X9						
  module.go:35823	0x630476		f2450f58c8		ADDSD X8, X9									
  module.go:35823	0x63047b		f2440f59cc		MULSD X4, X9									
  module.go:35823	0x630480		f2440f10058f1c2d00	MOVSD_XMM $f64.3fd999999997fa04(SB), X8						
  module.go:35823	0x630489		f2450f58c1		ADDSD X9, X8									
  module.go:35823	0x63048e		f2440f59c4		MULSD X4, X8									
  module.go:35823	0x630493		f2440f100d541c2d00	MOVSD_XMM $f64.3fc2f112df3e5244(SB), X9						
  module.go:35823	0x63049c		f2440f59cc		MULSD X4, X9									
  module.go:35823	0x6304a1		f2440f1015561c2d00	MOVSD_XMM $f64.3fc7466496cb03de(SB), X10					
  module.go:35823	0x6304aa		f2450f58d1		ADDSD X9, X10									
  module.go:35823	0x6304af		f2440f59d4		MULSD X4, X10									
  module.go:35823	0x6304b4		f2440f100d531c2d00	MOVSD_XMM $f64.3fd2492494229359(SB), X9						
  module.go:35823	0x6304bd		f2450f58ca		ADDSD X10, X9									
  module.go:35823	0x6304c2		f2440f59cc		MULSD X4, X9									
  module.go:35823	0x6304c7		f20f1025511c2d00	MOVSD_XMM $f64.3fe5555555555593(SB), X4						
  module.go:35823	0x6304cf		f2410f58e1		ADDSD X9, X4									
  module.go:35823	0x6304d4		f20f59e7		MULSD X7, X4									
  module.go:35823	0x6304d8		f2440f58c4		ADDSD X4, X8									
  module.go:35823	0x6304dd		f2440f58c3		ADDSD X3, X8									
  module.go:35823	0x6304e2		f2410f59f0		MULSD X8, X6									
  module.go:35823	0x6304e7		f20f58d6		ADDSD X6, X2									
  module.go:35823	0x6304eb		f20f5cd3		SUBSD X3, X2									
  module.go:35823	0x6304ef		f20f58d5		ADDSD X5, X2									
  module.go:35823	0x6304f3		f20f58d1		ADDSD X1, X2									
  module.go:35795	0x6304f7		0f10c2			MOVUPS X2, X0									
  module.go:35832	0x6304fa		4c8b5838		MOVQ 0x38(AX), R11								
  module.go:63009	0x6304fe		4d8d623f		LEAQ 0x3f(R10), R12								
  module.go:63009	0x630502		4d39e3			CMPQ R11, R12									
  module.go:63009	0x630505		0f8609120000		JBE 0x631714									
  module.go:35713	0x63050b		898c249c000000		MOVL CX, 0x9c(SP)								
  module.go:35772	0x630512		4c89542478		MOVQ R10, 0x78(SP)								
  module.go:35832	0x630517		4c8b5830		MOVQ 0x30(AX), R11								
  unsafe.go:41		0x63051b		66490f6ec9		MOVQ R9, X1									
  module.go:35833	0x630520		f20f59c1		MULSD X1, X0									
  module.go:63010	0x630524		4f8b4c1a38		MOVQ 0x38(R10)(R11*1), R9							
  module.go:35832	0x630529		66490f6ec9		MOVQ R9, X1									
  module.go:35833	0x63052e		f20f58c1		ADDSD X1, X0									
  module.go:35833	0x630532		440fb60dda146d00	MOVZX runtime.x86HasSSE41(SB), R9						
  module.go:35833	0x63053a		4585c9			TESTL R9, R9									
  module.go:35833	0x63053d		7408			JE 0x630547									
  module.go:35833	0x63053f		660f3a0bc001		ROUNDSD $0x1, X0, X0								
  module.go:35833	0x630545		eb24			JMP 0x63056b									
  module.go:35833	0x630547		e894aceaff		CALL math.Floor(SB)								
  module.go:35834	0x63054c		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:62984	0x630554		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:35702	0x63055b		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x63055f		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:62983	0x630566		4c8b542478		MOVQ 0x78(SP), R10								
  module.go:63074	0x63056b		f20f100d551c2d00	MOVSD_XMM $f64.c1e0000000000000(SB), X1						
  module.go:63074	0x630573		660f2ec8		UCOMISD X0, X1									
  module.go:63074	0x630577		7209			JB 0x630582									
  module.go:63074	0x630579		41b900000080		MOVL $-0x80000000, R9								
  module.go:63074	0x63057f		90			NOPL										
  module.go:35833	0x630580		eb2a			JMP 0x6305ac									
  module.go:63076	0x630582		f20f100d2e1c2d00	MOVSD_XMM $f64.41dfffffffc00000(SB), X1						
  module.go:63076	0x63058a		660f2ec1		UCOMISD X1, X0									
  module.go:63076	0x63058e		7208			JB 0x630598									
  module.go:63076	0x630590		41b9ffffff7f		MOVL $0x7fffffff, R9								
  module.go:35833	0x630596		eb14			JMP 0x6305ac									
  module.go:63078	0x630598		660f2ec0		UCOMISD X0, X0									
  module.go:63078	0x63059c		7504			JNE 0x6305a2									
  module.go:63078	0x63059e		6690			NOPW										
  module.go:63078	0x6305a0		7b05			JNP 0x6305a7									
  module.go:63078	0x6305a2		4531c9			XORL R9, R9									
  module.go:35833	0x6305a5		eb05			JMP 0x6305ac									
  module.go:63081	0x6305a7		f2440f2cc8		CVTTSD2SIL X0, R9								
  module.go:35834	0x6305ac		4c8b5838		MOVQ 0x38(AX), R11								
  module.go:62983	0x6305b0		4d8d620f		LEAQ 0xf(R10), R12								
  module.go:62983	0x6305b4		4d39e3			CMPQ R11, R12									
  module.go:62983	0x6305b7		0f8652110000		JBE 0x63170f									
  module.go:62983	0x6305bd		4c89642470		MOVQ R12, 0x70(SP)								
  module.go:35834	0x6305c2		4c8b6830		MOVQ 0x30(AX), R13								
  module.go:62984	0x6305c6		478b7c2a0c		MOVL 0xc(R10)(R13*1), R15							
  module.go:35836	0x6305cb		4585ff			TESTL R15, R15									
  module.go:35836	0x6305ce		0f8471040000		JE 0x630a45									
  module.go:62983	0x6305d4		498d7213		LEAQ 0x13(R10), SI								
  module.go:35863	0x6305d8		90			NOPL										
  module.go:35863	0x6305d9		0f1f8000000000		NOPL 0(AX)									
  module.go:62983	0x6305e0		4939f3			CMPQ R11, SI									
  module.go:62983	0x6305e3		0f8621110000		JBE 0x63170a									
  module.go:62983	0x6305e9		4889742468		MOVQ SI, 0x68(SP)								
  module.go:62984	0x6305ee		438b7c2a10		MOVL 0x10(R10)(R13*1), DI							
  module.go:35865	0x6305f3		4139f9			CMPL R9, DI									
  module.go:35865	0x6305f6		0f8cec000000		JL 0x6306e8									
  module.go:35833	0x6305fc		44894c2424		MOVL R9, 0x24(SP)								
  module.go:35867	0x630601		468d043f		LEAL 0(DI)(R15*1), R8								
  module.go:35866	0x630605		4129f9			SUBL DI, R9									
  module.go:35867	0x630608		8b542424		MOVL 0x24(SP), DX								
  module.go:35867	0x63060c		4439c2			CMPL DX, R8									
  module.go:35867	0x63060f		0f8cc7000000		JL 0x6306dc									
  module.go:62983	0x630615		4d8d4217		LEAQ 0x17(R10), R8								
  module.go:35871	0x630619		90			NOPL										
  module.go:35871	0x63061a		660f1f440000		NOPW 0(AX)(AX*1)								
  module.go:62983	0x630620		4d39c3			CMPQ R11, R8									
  module.go:62983	0x630623		0f86dc100000		JBE 0x631705									
  module.go:35870	0x630629		458d4101		LEAL 0x1(R9), R8								
  module.go:62984	0x63062d		438b5c1514		MOVL 0x14(R13)(R10*1), BX							
  module.go:35874	0x630632		4439c3			CMPL BX, R8									
  module.go:35874	0x630635		0f8d6b0b0000		JGE 0x6311a6									
  module.go:35877	0x63063b		4129d9			SUBL BX, R9									
  module.go:35877	0x63063e		458d4101		LEAL 0x1(R9), R8								
  module.go:35878	0x630642		4585c0			TESTL R8, R8									
  module.go:35878	0x630645		7e5e			JLE 0x6306a5									
  module.go:62983	0x630647		498d720b		LEAQ 0xb(R10), SI								
  module.go:35879	0x63064b		90			NOPL										
  module.go:62983	0x63064c		4939f3			CMPQ R11, SI									
  module.go:62983	0x63064f		0f86a9100000		JBE 0x6316fe									
  module.go:35877	0x630655		44894c244c		MOVL R9, 0x4c(SP)								
  module.go:35885	0x63065a		448d1c1f		LEAL 0(DI)(BX*1), R11								
  module.go:63184	0x63065e		89cb			MOVL CX, BX									
  module.go:63184	0x630660		48895c2460		MOVQ BX, 0x60(SP)								
  module.go:35881	0x630665		90			NOPL										
  module.go:35883	0x630666		90			NOPL										
  module.go:62984	0x630667		438b4c1508		MOVL 0x8(R13)(R10*1), CX							
  module.go:63184	0x63066c		478b4c1504		MOVL 0x4(R13)(R10*1), R9							
  module.go:63184	0x630671		458b6c1d00		MOVL 0(R13)(BX*1), R13								
  module.go:35885	0x630676		4439da			CMPL DX, R11									
  module.go:35885	0x630679		750b			JNE 0x630686									
  module.go:36088	0x63067b		4589f8			MOVL R15, R8									
  module.go:36088	0x63067e		0f57c0			XORPS X0, X0									
  module.go:35888	0x630681		e9600e0000		JMP 0x6314e6									
  module.go:62984	0x630686		897c2448		MOVL DI, 0x48(SP)								
  module.go:35891	0x63068a		4589c3			MOVL R8, R11									
  module.go:35891	0x63068d		4181e0feffff7f		ANDL $0x7ffffffe, R8								
  module.go:35952	0x630694		44897c2428		MOVL R15, 0x28(SP)								
  module.go:35952	0x630699		0f57c0			XORPS X0, X0									
  module.go:35952	0x63069c		0f1f4000		NOPL 0(AX)									
  module.go:35894	0x6306a0		e9bd0c0000		JMP 0x631362									
  module.go:62983	0x6306a5		4d8d4207		LEAQ 0x7(R10), R8								
  module.go:35957	0x6306a9		90			NOPL										
  module.go:62983	0x6306aa		4d39c3			CMPQ R11, R8									
  module.go:62983	0x6306ad		0f869c0c0000		JBE 0x63134f									
  module.go:63184	0x6306b3		4189c8			MOVL CX, R8									
  module.go:62983	0x6306b6		498d5a0b		LEAQ 0xb(R10), BX								
  module.go:35959	0x6306ba		90			NOPL										
  module.go:35961	0x6306bb		90			NOPL										
  module.go:62984	0x6306bc		478b641504		MOVL 0x4(R13)(R10*1), R12							
  module.go:63184	0x6306c1		478b440500		MOVL 0(R13)(R8*1), R8								
  module.go:62983	0x6306c6		4939db			CMPQ R11, BX									
  module.go:62983	0x6306c9		0f867b0c0000		JBE 0x63134a									
  module.go:62984	0x6306cf		478b5c1508		MOVL 0x8(R13)(R10*1), R11							
  module.go:62984	0x6306d4		0f57c0			XORPS X0, X0									
  module.go:35964	0x6306d7		e94e0a0000		JMP 0x63112a									
  module.go:35702	0x6306dc		8b542434		MOVL 0x34(SP), DX								
  module.go:36195	0x6306e0		4589f8			MOVL R15, R8									
  module.go:35868	0x6306e3		e987070000		JMP 0x630e6f									
  module.go:62983	0x6306e8		4d8d4217		LEAQ 0x17(R10), R8								
  module.go:35968	0x6306ec		90			NOPL										
  module.go:62983	0x6306ed		4d39c3			CMPQ R11, R8									
  module.go:62983	0x6306f0		0f862f0a0000		JBE 0x631125									
  module.go:35971	0x6306f6		4429cf			SUBL R9, DI									
  module.go:62984	0x6306f9		478b4c1514		MOVL 0x14(R13)(R10*1), R9							
  module.go:35969	0x6306fe		4529f9			SUBL R15, R9									
  module.go:35973	0x630701		4439cf			CMPL DI, R9									
  module.go:35974	0x630704		410f47f9		CMOVA R9, DI									
  module.go:35977	0x630708		458d0c3f		LEAL 0(R15)(DI*1), R9								
  module.go:35978	0x63070c		4439cf			CMPL DI, R9									
  module.go:35973	0x63070f		0f87e4090000		JA 0x6310f9									
  module.go:62983	0x630715		4d8d4203		LEAQ 0x3(R10), R8								
  module.go:35979	0x630719		90			NOPL										
  module.go:35979	0x63071a		660f1f440000		NOPW 0(AX)(AX*1)								
  module.go:62983	0x630720		4d39c3			CMPQ R11, R8									
  module.go:62983	0x630723		0f86cb090000		JBE 0x6310f4									
  module.go:35974	0x630729		897c242c		MOVL DI, 0x2c(SP)								
  module.go:62984	0x63072d		4189cb			MOVL CX, R11									
  module.go:62984	0x630730		4c895c2460		MOVQ R11, 0x60(SP)								
  module.go:62984	0x630735		478b6c1d00		MOVL 0(R13)(R11*1), R13								
  module.go:62984	0x63073a		660f1f440000		NOPW 0(AX)(AX*1)								
  module.go:35982	0x630740		4539cd			CMPL R13, R9									
  module.go:35982	0x630743		0f83e9020000		JAE 0x630a32									
  module.go:35992	0x630749		4589e9			MOVL R13, R9									
  module.go:35992	0x63074c		4529fd			SUBL R15, R13									
  module.go:35994	0x63074f		4439ef			CMPL DI, R13									
  module.go:35994	0x630752		7708			JA 0x63075c									
  module.go:62984	0x630754		4589c8			MOVL R9, R8									
  module.go:35995	0x630757		e98e000000		JMP 0x6307ea									
  module.go:62984	0x63075c		44894c2448		MOVL R9, 0x48(SP)								
  module.go:35997	0x630761		89cb			MOVL CX, BX									
  module.go:35997	0x630763		4489f9			MOVL R15, CX									
  module.go:35997	0x630766		be08000000		MOVL $0x8, SI									
  module.go:35997	0x63076b		4189f0			MOVL SI, R8									
  module.go:35997	0x63076e		e8cdbcf9ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn3(SB)	
  module.go:35998	0x630773		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:35998	0x63077b		488b5038		MOVQ 0x38(AX), DX								
  module.go:62983	0x63077f		4c8b4c2470		MOVQ 0x70(SP), R9								
  module.go:62983	0x630784		4c39ca			CMPQ DX, R9									
  module.go:62983	0x630787		0f8662090000		JBE 0x6310ef									
  module.go:35998	0x63078d		488b5030		MOVQ 0x30(AX), DX								
  module.go:62984	0x630791		488b742478		MOVQ 0x78(SP), SI								
  module.go:62984	0x630796		448b7c160c		MOVL 0xc(SI)(DX*1), R15								
  module.go:36001	0x63079b		448b6c2448		MOVL 0x48(SP), R13								
  module.go:36001	0x6307a0		4589e8			MOVL R13, R8									
  module.go:36001	0x6307a3		4529f8			SUBL R15, R8									
  module.go:63184	0x6307a6		4c8b542460		MOVQ 0x60(SP), R10								
  module.go:63184	0x6307ab		418b1412		MOVL 0(R10)(DX*1), DX								
  module.go:36047	0x6307af		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:63000	0x6307b6		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:62983	0x6307bd		488b742468		MOVQ 0x68(SP), SI								
  module.go:36042	0x6307c2		8b7c242c		MOVL 0x2c(SP), DI								
  module.go:62983	0x6307c6		4c8b542478		MOVQ 0x78(SP), R10								
  module.go:63184	0x6307cb		4c8b5c2460		MOVQ 0x60(SP), R11								
  module.go:63000	0x6307d0		4d89cc			MOVQ R9, R12									
  module.go:36002	0x6307d3		4189d1			MOVL DX, R9									
  module.go:35702	0x6307d6		8b542434		MOVL 0x34(SP), DX								
  module.go:36011	0x6307da		4489c1			MOVL R8, CX									
  module.go:36011	0x6307dd		4589e8			MOVL R13, R8									
  module.go:36002	0x6307e0		4189cd			MOVL CX, R13									
  module.go:36047	0x6307e3		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:36006	0x6307ea		488b5838		MOVQ 0x38(AX), BX								
  module.go:62983	0x6307ee		4d8d5a0b		LEAQ 0xb(R10), R11								
  module.go:62983	0x6307f2		4c39db			CMPQ BX, R11									
  module.go:62983	0x6307f5		0f86ef080000		JBE 0x6310ea									
  module.go:36006	0x6307fb		488b5030		MOVQ 0x30(AX), DX								
  module.go:62984	0x6307ff		418b4c1208		MOVL 0x8(R10)(DX*1), CX								
  module.go:36008	0x630804		4139cd			CMPL R13, CX									
  module.go:36008	0x630807		721f			JB 0x630828									
  module.go:36047	0x630809		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:35702	0x630810		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x630814		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:63184	0x63081b		4c8b5c2460		MOVQ 0x60(SP), R11								
  module.go:36041	0x630820		4589cd			MOVL R9, R13									
  module.go:36009	0x630823		e90a020000		JMP 0x630a32									
  module.go:36002	0x630828		44897c2428		MOVL R15, 0x28(SP)								
  module.go:36002	0x63082d		44894c2438		MOVL R9, 0x38(SP)								
  module.go:36011	0x630832		4589c5			MOVL R8, R13									
  module.go:36011	0x630835		4129c8			SUBL CX, R8									
  module.go:36013	0x630838		4529c7			SUBL R8, R15									
  module.go:36019	0x63083b		4529e9			SUBL R13, R9									
  module.go:36015	0x63083e		4539c7			CMPL R15, R8									
  module.go:36015	0x630841		400f92c6		SETB SI										
  module.go:36016	0x630845		400fb6f6		MOVZX SI, SI									
  module.go:36019	0x630849		4539f9			CMPL R9, R15									
  module.go:36019	0x63084c		410f93c1		SETAE R9									
  module.go:36020	0x630850		450fb6c9		MOVZX R9, R9									
  module.go:36022	0x630854		4485ce			TESTL R9, SI									
  module.go:36022	0x630857		0f85fb000000		JNE 0x630958									
  module.go:36024	0x63085d		4489c6			MOVL R8, SI									
  module.go:36024	0x630860		41c1e003		SHLL $0x3, R8									
  module.go:36023	0x630864		448b4c2438		MOVL 0x38(SP), R9								
  module.go:36023	0x630869		4589cd			MOVL R9, R13									
  module.go:36023	0x63086c		4129f1			SUBL SI, R9									
  module.go:36025	0x63086f		4585c0			TESTL R8, R8									
  module.go:36025	0x630872		0f849e000000		JE 0x630916									
  module.go:62983	0x630878		498d7207		LEAQ 0x7(R10), SI								
  module.go:36026	0x63087c		90			NOPL										
  module.go:36026	0x63087d		0f1f00			NOPL 0(AX)									
  module.go:62983	0x630880		4839f3			CMPQ BX, SI									
  module.go:62983	0x630883		0f865c080000		JBE 0x6310e5									
  module.go:62984	0x630889		428b741204		MOVL 0x4(DX)(R10*1), SI								
  module.go:36028	0x63088e		468d3cce		LEAL 0(SI)(R9*8), R15								
  module.go:36028	0x630892		8d34ce			LEAL 0(SI)(CX*8), SI								
  module.go:63109	0x630895		4589ff			MOVL R15, R15									
  module.go:63110	0x630898		89f6			MOVL SI, SI									
  module.go:63111	0x63089a		4489c1			MOVL R8, CX									
  module.go:63111	0x63089d		4e8d0439		LEAQ 0(CX)(R15*1), R8								
  module.go:63112	0x6308a1		4c8d2431		LEAQ 0(CX)(SI*1), R12								
  module.go:63113	0x6308a5		4c39c3			CMPQ BX, R8									
  module.go:63113	0x6308a8		0f8230080000		JB 0x6310de									
  module.go:63113	0x6308ae		4d89f8			MOVQ R15, R8									
  module.go:63113	0x6308b1		4929df			SUBQ BX, R15									
  module.go:63113	0x6308b4		49c1ff3f		SARQ $0x3f, R15									
  module.go:63113	0x6308b8		4d21f8			ANDQ R15, R8									
  module.go:63113	0x6308bb		4901d0			ADDQ DX, R8									
  module.go:63113	0x6308be		6690			NOPW										
  module.go:63113	0x6308c0		4c39e3			CMPQ BX, R12									
  module.go:63113	0x6308c3		0f8210080000		JB 0x6310d9									
  module.go:63113	0x6308c9		4989f4			MOVQ SI, R12									
  module.go:63113	0x6308cc		4829de			SUBQ BX, SI									
  module.go:63113	0x6308cf		48c1fe3f		SARQ $0x3f, SI									
  module.go:63113	0x6308d3		4921f4			ANDQ SI, R12									
  module.go:63113	0x6308d6		498d1c14		LEAQ 0(R12)(DX*1), BX								
  module.go:63113	0x6308da		4c39c3			CMPQ BX, R8									
  module.go:63113	0x6308dd		7432			JE 0x630911									
  module.go:62983	0x6308df		4c895c2458		MOVQ R11, 0x58(SP)								
  module.go:36023	0x6308e4		44894c2430		MOVL R9, 0x30(SP)								
  module.go:63113	0x6308e9		4c89c0			MOVQ R8, AX									
  module.go:63113	0x6308ec		e86f04e6ff		CALL runtime.memmove(SB)							
  module.go:36030	0x6308f1		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:36042	0x6308f9		8b7c242c		MOVL 0x2c(SP), DI								
  module.go:63001	0x6308fd		448b4c2430		MOVL 0x30(SP), R9								
  module.go:63001	0x630902		4c8b542478		MOVQ 0x78(SP), R10								
  module.go:63000	0x630907		4c8b5c2458		MOVQ 0x58(SP), R11								
  module.go:36041	0x63090c		448b6c2438		MOVL 0x38(SP), R13								
  module.go:63000	0x630911		4c8b642470		MOVQ 0x70(SP), R12								
  module.go:36030	0x630916		488b5038		MOVQ 0x38(AX), DX								
  module.go:36030	0x63091a		660f1f440000		NOPW 0(AX)(AX*1)								
  module.go:63000	0x630920		4c39da			CMPQ DX, R11									
  module.go:63000	0x630923		0f86ab070000		JBE 0x6310d4									
  module.go:36030	0x630929		488b5030		MOVQ 0x30(AX), DX								
  module.go:63001	0x63092d		45894c1208		MOVL R9, 0x8(R10)(DX*1)								
  module.go:36047	0x630932		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:35702	0x630939		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x63093d		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:62983	0x630944		488b742468		MOVQ 0x68(SP), SI								
  module.go:63184	0x630949		4c8b5c2460		MOVQ 0x60(SP), R11								
  module.go:36041	0x63094e		448b7c2428		MOVL 0x28(SP), R15								
  module.go:36031	0x630953		e9da000000		JMP 0x630a32									
  module.go:36033	0x630958		41c1e703		SHLL $0x3, R15									
  module.go:36033	0x63095c		0f1f4000		NOPL 0(AX)									
  module.go:36034	0x630960		4585ff			TESTL R15, R15									
  module.go:36034	0x630963		752b			JNE 0x630990									
  module.go:36047	0x630965		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:35702	0x63096c		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x630970		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:62983	0x630977		488b742468		MOVQ 0x68(SP), SI								
  module.go:63184	0x63097c		4c8b5c2460		MOVQ 0x60(SP), R11								
  module.go:36041	0x630981		448b7c2428		MOVL 0x28(SP), R15								
  module.go:36041	0x630986		448b6c2438		MOVL 0x38(SP), R13								
  module.go:36035	0x63098b		e9a2000000		JMP 0x630a32									
  module.go:62983	0x630990		498d7207		LEAQ 0x7(R10), SI								
  module.go:36037	0x630994		90			NOPL										
  module.go:62983	0x630995		4839f3			CMPQ BX, SI									
  module.go:62983	0x630998		0f8631070000		JBE 0x6310cf									
  module.go:62984	0x63099e		428b741204		MOVL 0x4(DX)(R10*1), SI								
  module.go:36039	0x6309a3		468d04ee		LEAL 0(SI)(R13*8), R8								
  module.go:63109	0x6309a7		4589c0			MOVL R8, R8									
  module.go:63111	0x6309aa		4489f9			MOVL R15, CX									
  module.go:63111	0x6309ad		4e8d0c01		LEAQ 0(CX)(R8*1), R9								
  module.go:63112	0x6309b1		4c8d1c31		LEAQ 0(CX)(SI*1), R11								
  module.go:63113	0x6309b5		4c39cb			CMPQ BX, R9									
  module.go:63113	0x6309b8		0f820c070000		JB 0x6310ca									
  module.go:63113	0x6309be		4d89c1			MOVQ R8, R9									
  module.go:63113	0x6309c1		4929d8			SUBQ BX, R8									
  module.go:63113	0x6309c4		49c1f83f		SARQ $0x3f, R8									
  module.go:63113	0x6309c8		4d21c1			ANDQ R8, R9									
  module.go:63113	0x6309cb		4d8d0411		LEAQ 0(R9)(DX*1), R8								
  module.go:63113	0x6309cf		4c39db			CMPQ BX, R11									
  module.go:63113	0x6309d2		0f82ed060000		JB 0x6310c5									
  module.go:63113	0x6309d8		4189f1			MOVL SI, R9									
  module.go:63113	0x6309db		4829de			SUBQ BX, SI									
  module.go:63113	0x6309de		48c1fe3f		SARQ $0x3f, SI									
  module.go:63113	0x6309e2		4c21ce			ANDQ R9, SI									
  module.go:63113	0x6309e5		488d1c16		LEAQ 0(SI)(DX*1), BX								
  module.go:63113	0x6309e9		4c39c3			CMPQ BX, R8									
  module.go:63113	0x6309ec		741e			JE 0x630a0c									
  module.go:63113	0x6309ee		4c89c0			MOVQ R8, AX									
  module.go:63113	0x6309f1		e86a03e6ff		CALL runtime.memmove(SB)							
  module.go:36055	0x6309f6		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:36042	0x6309fe		8b7c242c		MOVL 0x2c(SP), DI								
  module.go:63001	0x630a02		4c8b542478		MOVQ 0x78(SP), R10								
  module.go:63000	0x630a07		4c8b642470		MOVQ 0x70(SP), R12								
  module.go:36047	0x630a0c		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:35702	0x630a13		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x630a17		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:62983	0x630a1e		488b742468		MOVQ 0x68(SP), SI								
  module.go:63184	0x630a23		4c8b5c2460		MOVQ 0x60(SP), R11								
  module.go:36041	0x630a28		448b7c2428		MOVL 0x28(SP), R15								
  module.go:36041	0x630a2d		448b6c2438		MOVL 0x38(SP), R13								
  module.go:36042	0x630a32		85ff			TESTL DI, DI									
  module.go:36042	0x630a34		0f842b050000		JE 0x630f65									
  module.go:35974	0x630a3a		4189f8			MOVL DI, R8									
  module.go:35974	0x630a3d		0f1f00			NOPL 0(AX)									
  module.go:36044	0x630a40		e95b050000		JMP 0x630fa0									
  module.go:63000	0x630a45		498d7213		LEAQ 0x13(R10), SI								
  module.go:35837	0x630a49		90			NOPL										
  module.go:63000	0x630a4a		4939f3			CMPQ R11, SI									
  module.go:63000	0x630a4d		0f860b050000		JBE 0x630f5e									
  module.go:63001	0x630a53		47894c2a10		MOVL R9, 0x10(R10)(R13*1)							
  module.go:35839	0x630a58		488b7038		MOVQ 0x38(AX), SI								
  module.go:62983	0x630a5c		4d8d4203		LEAQ 0x3(R10), R8								
  module.go:62983	0x630a60		4c39c6			CMPQ SI, R8									
  module.go:62983	0x630a63		0f86f0040000		JBE 0x630f59									
  module.go:35839	0x630a69		488b7030		MOVQ 0x30(AX), SI								
  module.go:62984	0x630a6d		4189c9			MOVL CX, R9									
  module.go:62984	0x630a70		418b3431		MOVL 0(R9)(SI*1), SI								
  module.go:35841	0x630a74		85f6			TESTL SI, SI									
  module.go:35841	0x630a76		7404			JE 0x630a7c									
  module.go:35841	0x630a78		31ff			XORL DI, DI									
  module.go:35841	0x630a7a		eb71			JMP 0x630aed									
  module.go:62983	0x630a7c		4c89442468		MOVQ R8, 0x68(SP)								
  module.go:62984	0x630a81		4c894c2460		MOVQ R9, 0x60(SP)								
  module.go:35842	0x630a86		89cb			MOVL CX, BX									
  module.go:35842	0x630a88		e8d340fbff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn88(SB)	
  module.go:35843	0x630a8d		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:35843	0x630a95		488b4838		MOVQ 0x38(AX), CX								
  module.go:62983	0x630a99		488b542468		MOVQ 0x68(SP), DX								
  module.go:62983	0x630a9e		6690			NOPW										
  module.go:62983	0x630aa0		4839d1			CMPQ CX, DX									
  module.go:62983	0x630aa3		0f86ab040000		JBE 0x630f54									
  module.go:35843	0x630aa9		488b5030		MOVQ 0x30(AX), DX								
  module.go:62984	0x630aad		488b742460		MOVQ 0x60(SP), SI								
  module.go:62984	0x630ab2		8b3416			MOVL 0(SI)(DX*1), SI								
  module.go:62983	0x630ab5		4c8b442470		MOVQ 0x70(SP), R8								
  module.go:62983	0x630aba		660f1f440000		NOPW 0(AX)(AX*1)								
  module.go:62983	0x630ac0		4c39c1			CMPQ CX, R8									
  module.go:62983	0x630ac3		0f8686040000		JBE 0x630f4f									
  module.go:62984	0x630ac9		4c8b4c2478		MOVQ 0x78(SP), R9								
  module.go:62984	0x630ace		418b54110c		MOVL 0xc(R9)(DX*1), DX								
  module.go:63184	0x630ad3		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:63000	0x630ada		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:63001	0x630ae1		4d89ca			MOVQ R9, R10									
  module.go:63000	0x630ae4		4d89c4			MOVQ R8, R12									
  module.go:35845	0x630ae7		89d7			MOVL DX, DI									
  module.go:35702	0x630ae9		8b542434		MOVL 0x34(SP), DX								
  module.go:35850	0x630aed		4c8b4038		MOVQ 0x38(AX), R8								
  module.go:63000	0x630af1		4d39e0			CMPQ R8, R12									
  module.go:63000	0x630af4		0f8650040000		JBE 0x630f4a									
  module.go:35849	0x630afa		448d4701		LEAL 0x1(DI), R8								
  module.go:35850	0x630afe		4c8b4830		MOVQ 0x30(AX), R9								
  module.go:63001	0x630b02		4789440a0c		MOVL R8, 0xc(R10)(R9*1)								
  module.go:35851	0x630b07		4c8b4838		MOVQ 0x38(AX), R9								
  module.go:62983	0x630b0b		4d8d5a07		LEAQ 0x7(R10), R11								
  module.go:62983	0x630b0f		4d39d9			CMPQ R9, R11									
  module.go:62983	0x630b12		0f862d040000		JBE 0x630f45									
  module.go:35851	0x630b18		4c8b5830		MOVQ 0x30(AX), R11								
  module.go:62983	0x630b1c		4d8d620b		LEAQ 0xb(R10), R12								
  module.go:35852	0x630b20		90			NOPL										
  module.go:62984	0x630b21		478b6c1a04		MOVL 0x4(R10)(R11*1), R13							
  module.go:62983	0x630b26		4d39e1			CMPQ R9, R12									
  module.go:62983	0x630b29		0f860e040000		JBE 0x630f3d									
  module.go:62984	0x630b2f		478b641a08		MOVL 0x8(R10)(R11*1), R12							
  module.go:35853	0x630b34		4101fc			ADDL DI, R12									
  module.go:35856	0x630b37		4439e6			CMPL SI, R12									
  module.go:35857	0x630b3a		41bf00000000		MOVL $0x0, R15									
  module.go:35857	0x630b40		440f46fe		CMOVBE SI, R15									
  module.go:35859	0x630b44		4529fc			SUBL R15, R12									
  module.go:35859	0x630b47		438d74e500		LEAL 0(R13)(R12*8), SI								
  module.go:63026	0x630b4c		4189f4			MOVL SI, R12									
  module.go:63026	0x630b4f		4983c407		ADDQ $0x7, R12									
  module.go:63026	0x630b53		4d39e1			CMPQ R9, R12									
  module.go:35856	0x630b56		0f86dc030000		JBE 0x630f38									
  module.go:63027	0x630b5c		89f6			MOVL SI, SI									
  module.go:63027	0x630b5e		49c7043300000000	MOVQ $0x0, 0(R11)(SI*1)								
  module.go:63027	0x630b66		4531c9			XORL R9, R9									
  module.go:35860	0x630b69		e901030000		JMP 0x630e6f									
  module.go:36080	0x630b6e		488b7038		MOVQ 0x38(AX), SI								
  module.go:63009	0x630b72		498d7a1f		LEAQ 0x1f(R10), DI								
  module.go:63009	0x630b76		4839fe			CMPQ SI, DI									
  module.go:63009	0x630b79		0f86eb020000		JBE 0x630e6a									
  module.go:36080	0x630b7f		488b7030		MOVQ 0x30(AX), SI								
  module.go:36081	0x630b83		4c8b4038		MOVQ 0x38(AX), R8								
  module.go:63010	0x630b87		498b743218		MOVQ 0x18(R10)(SI*1), SI							
  unsafe.go:41		0x630b8c		66480f6ec6		MOVQ SI, X0									
  module.go:36081	0x630b91		f20f100dcf132d00	MOVSD_XMM $f64.3ff0000000000000(SB), X1						
  module.go:36081	0x630b99		f20f58c8		ADDSD X0, X1									
  module.go:36081	0x630b9d		0f1f00			NOPL 0(AX)									
  module.go:63026	0x630ba0		4939f8			CMPQ R8, DI									
  module.go:63026	0x630ba3		0f86bc020000		JBE 0x630e65									
  module.go:36081	0x630ba9		488b7030		MOVQ 0x30(AX), SI								
  module.go:63027	0x630bad		f2410f114c3218		MOVSD_XMM X1, 0x18(R10)(SI*1)							
  module.go:36082	0x630bb4		e99f020000		JMP 0x630e58									
  module.go:35705	0x630bb9		8974244c		MOVL SI, 0x4c(SP)								
  module.go:35739	0x630bbd		bb10000000		MOVL $0x10, BX									
  module.go:35739	0x630bc2		b901000000		MOVL $0x1, CX									
  module.go:35739	0x630bc7		e874baf9ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn4(SB)	
  module.go:35741	0x630bcc		85c0			TESTL AX, AX									
  module.go:35741	0x630bce		0f8456020000		JE 0x630e2a									
  module.go:35742	0x630bd4		488b942490000000	MOVQ 0x90(SP), DX								
  module.go:35742	0x630bdc		488b7238		MOVQ 0x38(DX), SI								
  module.go:63109	0x630be0		89c7			MOVL AX, DI									
  module.go:63111	0x630be2		4c8d4710		LEAQ 0x10(DI), R8								
  module.go:63113	0x630be6		4c39c6			CMPQ SI, R8									
  module.go:63113	0x630be9		0f8236020000		JB 0x630e25									
  module.go:35742	0x630bef		4c8b4230		MOVQ 0x30(DX), R8								
  module.go:63113	0x630bf3		4c01c7			ADDQ R8, DI									
  module.go:63113	0x630bf6		660f1f840000000000	NOPW 0(AX)(AX*1)								
  module.go:63113	0x630bff		90			NOPL										
  module.go:63113	0x630c00		4881fe718e1000		CMPQ SI, $0x108e71								
  module.go:63113	0x630c07		0f820c020000		JB 0x630e19									
  module.go:35739	0x630c0d		89442428		MOVL AX, 0x28(SP)								
  module.go:63113	0x630c11		498db0618e1000		LEAQ 0x108e61(R8), SI								
  module.go:63113	0x630c18		4839fe			CMPQ SI, DI									
  module.go:63113	0x630c1b		740b			JE 0x630c28									
  module.go:63113	0x630c1d		410f1080618e1000	MOVUPS 0x108e61(R8), X0								
  module.go:63113	0x630c25		0f1107			MOVUPS X0, 0(DI)								
  module.go:35743	0x630c28		4889d0			MOVQ DX, AX									
  module.go:35743	0x630c2b		bb0c000000		MOVL $0xc, BX									
  module.go:35743	0x630c30		b904000000		MOVL $0x4, CX									
  module.go:35743	0x630c35		e806baf9ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn4(SB)	
  module.go:35743	0x630c3a		660f1f440000		NOPW 0(AX)(AX*1)								
  module.go:35745	0x630c40		85c0			TESTL AX, AX									
  module.go:35745	0x630c42		0f84a7010000		JE 0x630def									
  module.go:35749	0x630c48		488b8c2490000000	MOVQ 0x90(SP), CX								
  module.go:35749	0x630c50		488b5138		MOVQ 0x38(CX), DX								
  module.go:35749	0x630c54		89c3			MOVL AX, BX									
  module.go:63000	0x630c56		488d730b		LEAQ 0xb(BX), SI								
  module.go:63000	0x630c5a		660f1f440000		NOPW 0(AX)(AX*1)								
  module.go:63000	0x630c60		4839f2			CMPQ DX, SI									
  module.go:63000	0x630c63		0f8681010000		JBE 0x630dea									
  module.go:35749	0x630c69		488b5130		MOVQ 0x30(CX), DX								
  module.go:63001	0x630c6d		c744130810000000	MOVL $0x10, 0x8(BX)(DX*1)							
  module.go:35750	0x630c75		488b5138		MOVQ 0x38(CX), DX								
  module.go:63000	0x630c79		488d7307		LEAQ 0x7(BX), SI								
  module.go:63000	0x630c7d		0f1f00			NOPL 0(AX)									
  module.go:63000	0x630c80		4839f2			CMPQ DX, SI									
  module.go:63000	0x630c83		0f865c010000		JBE 0x630de5									
  module.go:35750	0x630c89		488b5130		MOVQ 0x30(CX), DX								
  module.go:63001	0x630c8d		8b742428		MOVL 0x28(SP), SI								
  module.go:63001	0x630c91		89741304		MOVL SI, 0x4(BX)(DX*1)								
  module.go:35751	0x630c95		488b5138		MOVQ 0x38(CX), DX								
  module.go:63000	0x630c99		4883c303		ADDQ $0x3, BX									
  module.go:63000	0x630c9d		0f1f00			NOPL 0(AX)									
  module.go:63000	0x630ca0		4839da			CMPQ DX, BX									
  module.go:63000	0x630ca3		0f8635010000		JBE 0x630dde									
  module.go:35737	0x630ca9		8b542434		MOVL 0x34(SP), DX								
  module.go:35737	0x630cad		8d5ae8			LEAL -0x18(DX), BX								
  module.go:35751	0x630cb0		488b7130		MOVQ 0x30(CX), SI								
  module.go:35752	0x630cb4		89df			MOVL BX, DI									
  module.go:63001	0x630cb6		4189c0			MOVL AX, R8									
  module.go:63001	0x630cb9		42c7040610000000	MOVL $0x10, 0(SI)(R8*1)								
  module.go:35752	0x630cc1		488b7138		MOVQ 0x38(CX), SI								
  module.go:63000	0x630cc5		4c8d4707		LEAQ 0x7(DI), R8								
  module.go:63000	0x630cc9		4c39c6			CMPQ SI, R8									
  module.go:63000	0x630ccc		0f8607010000		JBE 0x630dd9									
  module.go:35752	0x630cd2		488b7130		MOVQ 0x30(CX), SI								
  module.go:63001	0x630cd6		c744370490931000	MOVL $0x109390, 0x4(DI)(SI*1)							
  module.go:35753	0x630cde		488b7138		MOVQ 0x38(CX), SI								
  module.go:63000	0x630ce2		4883c703		ADDQ $0x3, DI									
  module.go:63000	0x630ce6		4839fe			CMPQ SI, DI									
  module.go:63000	0x630ce9		0f86e5000000		JBE 0x630dd4									
  module.go:35753	0x630cef		488b7130		MOVQ 0x30(CX), SI								
  module.go:35755	0x630cf3		8b7c244c		MOVL 0x4c(SP), DI								
  module.go:35755	0x630cf7		89ff			MOVL DI, DI									
  module.go:63001	0x630cf9		89db			MOVL BX, BX									
  module.go:63001	0x630cfb		89041e			MOVL AX, 0(SI)(BX*1)								
  module.go:35755	0x630cfe		488b4138		MOVQ 0x38(CX), AX								
  module.go:62983	0x630d02		488d5f0f		LEAQ 0xf(DI), BX								
  module.go:62983	0x630d06		4839d8			CMPQ AX, BX									
  module.go:62983	0x630d09		0f86c0000000		JBE 0x630dcf									
  module.go:35755	0x630d0f		488b4130		MOVQ 0x30(CX), AX								
  module.go:62984	0x630d13		8b5c070c		MOVL 0xc(DI)(AX*1), BX								
  module.go:63184	0x630d17		8b440708		MOVL 0x8(DI)(AX*1), AX								
  module.go:35702	0x630d1b		8d72f8			LEAL -0x8(DX), SI								
  module.go:36219	0x630d1e		488b7938		MOVQ 0x38(CX), DI								
  module.go:36220	0x630d22		4189f0			MOVL SI, R8									
  module.go:63000	0x630d25		4d8d4807		LEAQ 0x7(R8), R9								
  module.go:63000	0x630d29		4c39cf			CMPQ DI, R9									
  module.go:63000	0x630d2c		0f8698000000		JBE 0x630dca									
  module.go:36219	0x630d32		4c8b4930		MOVQ 0x30(CX), R9								
  module.go:63001	0x630d36		43895c0804		MOVL BX, 0x4(R8)(R9*1)								
  module.go:63000	0x630d3b		498d5803		LEAQ 0x3(R8), BX								
  module.go:36221	0x630d3f		90			NOPL										
  module.go:63000	0x630d40		4839df			CMPQ DI, BX									
  module.go:63000	0x630d43		0f867c000000		JBE 0x630dc5									
  module.go:35700	0x630d49		8d5af0			LEAL -0x10(DX), BX								
  module.go:36226	0x630d4c		89df			MOVL BX, DI									
  module.go:63001	0x630d4e		89f6			MOVL SI, SI									
  module.go:63001	0x630d50		41890431		MOVL AX, 0(R9)(SI*1)								
  module.go:36222	0x630d54		895950			MOVL BX, 0x50(CX)								
  module.go:36226	0x630d57		488b4138		MOVQ 0x38(CX), AX								
  module.go:62983	0x630d5b		488d5f0f		LEAQ 0xf(DI), BX								
  module.go:62983	0x630d5f		90			NOPL										
  module.go:62983	0x630d60		4839d8			CMPQ AX, BX									
  module.go:62983	0x630d63		7657			JBE 0x630dbc									
  module.go:36226	0x630d65		488b5930		MOVQ 0x30(CX), BX								
  module.go:62983	0x630d69		488d770b		LEAQ 0xb(DI), SI								
  module.go:36229	0x630d6d		90			NOPL										
  module.go:62984	0x630d6e		448b441f0c		MOVL 0xc(DI)(BX*1), R8								
  module.go:62983	0x630d73		4839f0			CMPQ AX, SI									
  module.go:62983	0x630d76		763f			JBE 0x630db7									
  module.go:63000	0x630d78		8bb42498000000		MOVL 0x98(SP), SI								
  module.go:63000	0x630d7f		4189f1			MOVL SI, R9									
  module.go:63000	0x630d82		4d8d5103		LEAQ 0x3(R9), R10								
  module.go:36230	0x630d86		90			NOPL										
  module.go:62984	0x630d87		8b7c1f08		MOVL 0x8(DI)(BX*1), DI								
  module.go:63000	0x630d8b		4c39d0			CMPQ AX, R10									
  module.go:63000	0x630d8e		7622			JBE 0x630db2									
  module.go:63001	0x630d90		89f6			MOVL SI, SI									
  module.go:63001	0x630d92		893c33			MOVL DI, 0(BX)(SI*1)								
  module.go:63000	0x630d95		498d7107		LEAQ 0x7(R9), SI								
  module.go:36231	0x630d99		90			NOPL										
  module.go:63000	0x630d9a		4839f0			CMPQ AX, SI									
  module.go:63000	0x630d9d		760e			JBE 0x630dad									
  module.go:63001	0x630d9f		4589441904		MOVL R8, 0x4(R9)(BX*1)								
  module.go:36232	0x630da4		895150			MOVL DX, 0x50(CX)								
  module.go:36233	0x630da7		4883ec80		SUBQ $-0x80, SP									
  module.go:36233	0x630dab		5d			POPQ BP										
  module.go:36233	0x630dac		c3			RET										
  module.go:63000	0x630dad		e80efce5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630db2		e809fce5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630db7		e804fce5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630dbc		0f1f4000		NOPL 0(AX)									
  module.go:62983	0x630dc0		e8fbfbe5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630dc5		e8f6fbe5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630dca		e8f1fbe5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630dcf		e8ecfbe5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630dd4		e8e7fbe5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630dd9		e8e2fbe5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630dde		6690			NOPW										
  module.go:63000	0x630de0		e8dbfbe5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630de5		e8d6fbe5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630dea		e8d1fbe5ff		CALL runtime.panicBounds(SB)							
  module.go:35746	0x630def		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:35746	0x630df7		bb04000000		MOVL $0x4, BX									
  module.go:35746	0x630dfc		b90c000000		MOVL $0xc, CX									
  module.go:35746	0x630e01		e81a3cfaff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn35(SB)	
  module.go:35747	0x630e06		488d05139c2100		LEAQ 0x219c13(IP), AX								
  module.go:35747	0x630e0d		488d1ddc142d00		LEAQ 0x2d14dc(IP), BX								
  module.go:35747	0x630e14		e8c779e5ff		CALL runtime.gopanic(SB)							
  module.go:63113	0x630e19		48c7c0718e1000		MOVQ $0x108e71, AX								
  module.go:63113	0x630e20		e89bfbe5ff		CALL runtime.panicBounds(SB)							
  module.go:63113	0x630e25		e896fbe5ff		CALL runtime.panicBounds(SB)							
  module.go:35762	0x630e2a		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:35762	0x630e32		bb01000000		MOVL $0x1, BX									
  module.go:35762	0x630e37		b910000000		MOVL $0x10, CX									
  module.go:35762	0x630e3c		0f1f4000		NOPL 0(AX)									
  module.go:35762	0x630e40		e87bb5f9ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn2(SB)	
  module.go:35763	0x630e45		488d05d49b2100		LEAQ 0x219bd4(IP), AX								
  module.go:35763	0x630e4c		488d1d9d142d00		LEAQ 0x2d149d(IP), BX								
  module.go:35763	0x630e53		e88879e5ff		CALL runtime.gopanic(SB)							
  module.go:35757	0x630e58		89cb			MOVL CX, BX									
  module.go:36219	0x630e5a		4889c1			MOVQ AX, CX									
  module.go:36219	0x630e5d		31c0			XORL AX, AX									
  module.go:36219	0x630e5f		90			NOPL										
  module.go:36217	0x630e60		e9b6feffff		JMP 0x630d1b									
  module.go:63026	0x630e65		e856fbe5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x630e6a		e851fbe5ff		CALL runtime.panicBounds(SB)							
  module.go:36196	0x630e6f		4539c8			CMPL R8, R9									
  module.go:36196	0x630e72		0f8697000000		JBE 0x630f0f									
  module.go:36200	0x630e78		488b7038		MOVQ 0x38(AX), SI								
  module.go:62983	0x630e7c		498d7a07		LEAQ 0x7(R10), DI								
  module.go:62983	0x630e80		4839fe			CMPQ SI, DI									
  module.go:62983	0x630e83		0f8681000000		JBE 0x630f0a									
  module.go:36200	0x630e89		488b7830		MOVQ 0x30(AX), DI								
  module.go:62983	0x630e8d		4d8d420b		LEAQ 0xb(R10), R8								
  module.go:36201	0x630e91		90			NOPL										
  module.go:62984	0x630e92		458b5c3a04		MOVL 0x4(R10)(DI*1), R11							
  module.go:62983	0x630e97		4c39c6			CMPQ SI, R8									
  module.go:62983	0x630e9a		7669			JBE 0x630f05									
  module.go:62984	0x630e9c		458b443a08		MOVL 0x8(R10)(DI*1), R8								
  module.go:36202	0x630ea1		4501c8			ADDL R9, R8									
  module.go:63184	0x630ea4		89c9			MOVL CX, CX									
  module.go:63184	0x630ea6		8b0c39			MOVL 0(CX)(DI*1), CX								
  module.go:36203	0x630ea9		90			NOPL										
  module.go:36207	0x630eaa		4439c1			CMPL CX, R8									
  module.go:36207	0x630ead		7602			JBE 0x630eb1									
  module.go:36207	0x630eaf		31c9			XORL CX, CX									
  module.go:36210	0x630eb1		4129c8			SUBL CX, R8									
  module.go:36210	0x630eb4		438d0cc3		LEAL 0(R11)(R8*8), CX								
  module.go:63009	0x630eb8		4189c8			MOVL CX, R8									
  module.go:63009	0x630ebb		4983c007		ADDQ $0x7, R8									
  module.go:36211	0x630ebf		90			NOPL										
  module.go:63009	0x630ec0		4c39c6			CMPQ SI, R8									
  module.go:63009	0x630ec3		7636			JBE 0x630efb									
  module.go:36212	0x630ec5		488b7038		MOVQ 0x38(AX), SI								
  module.go:63010	0x630ec9		4189c9			MOVL CX, R9									
  module.go:63010	0x630ecc		498b3c39		MOVQ 0(R9)(DI*1), DI								
  unsafe.go:41		0x630ed0		66480f6ec7		MOVQ DI, X0									
  module.go:36211	0x630ed5		90			NOPL										
  module.go:36212	0x630ed6		f20f100d8a102d00	MOVSD_XMM $f64.3ff0000000000000(SB), X1						
  module.go:36212	0x630ede		f20f58c1		ADDSD X1, X0									
  module.go:63026	0x630ee2		4c39c6			CMPQ SI, R8									
  module.go:63026	0x630ee5		760f			JBE 0x630ef6									
  module.go:36212	0x630ee7		488b7030		MOVQ 0x30(AX), SI								
  module.go:63027	0x630eeb		f2420f11040e		MOVSD_XMM X0, 0(SI)(R9*1)							
  module.go:36215	0x630ef1		e962ffffff		JMP 0x630e58									
  module.go:63026	0x630ef6		e8c5fae5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x630efb		0f1f440000		NOPL 0(AX)(AX*1)								
  module.go:63009	0x630f00		e8bbfae5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630f05		e8b6fae5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630f0a		e8b1fae5ff		CALL runtime.panicBounds(SB)							
  module.go:36197	0x630f0f		bbf88e1000		MOVL $0x108ef8, BX								
  module.go:36197	0x630f14		b914000000		MOVL $0x14, CX									
  module.go:36197	0x630f19		bf0c8f1000		MOVL $0x108f0c, DI								
  module.go:36197	0x630f1e		6690			NOPW										
  module.go:36197	0x630f20		e85bedfaff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn69(SB)	
  module.go:36198	0x630f25		488d05f49a2100		LEAQ 0x219af4(IP), AX								
  module.go:36198	0x630f2c		488d1dbd132d00		LEAQ 0x2d13bd(IP), BX								
  module.go:36198	0x630f33		e8a878e5ff		CALL runtime.gopanic(SB)							
  module.go:63026	0x630f38		e883fae5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630f3d		0f1f00			NOPL 0(AX)									
  module.go:62983	0x630f40		e87bfae5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630f45		e876fae5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630f4a		e871fae5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630f4f		e86cfae5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630f54		e867fae5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630f59		e862fae5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630f5e		6690			NOPW										
  module.go:63000	0x630f60		e85bfae5ff		CALL runtime.panicBounds(SB)							
  module.go:36074	0x630f65		4c8b4038		MOVQ 0x38(AX), R8								
  module.go:62983	0x630f69		4939f0			CMPQ R8, SI									
  module.go:62983	0x630f6c		7617			JBE 0x630f85									
  module.go:36074	0x630f6e		488b7030		MOVQ 0x30(AX), SI								
  module.go:36075	0x630f72		90			NOPL										
  module.go:63001	0x630f73		41297c3210		SUBL DI, 0x10(R10)(SI*1)							
  module.go:63001	0x630f78		4531c9			XORL R9, R9									
  module.go:36195	0x630f7b		4589f8			MOVL R15, R8									
  module.go:36195	0x630f7e		6690			NOPW										
  module.go:36077	0x630f80		e9eafeffff		JMP 0x630e6f									
  module.go:62983	0x630f85		e836fae5ff		CALL runtime.panicBounds(SB)							
  module.go:36068	0x630f8a		ffcf			DECL DI										
  module.go:35702	0x630f8c		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x630f90		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:63184	0x630f97		4c8b5c2460		MOVQ 0x60(SP), R11								
  module.go:36070	0x630f9c		4589cf			MOVL R9, R15									
  module.go:36070	0x630f9f		90			NOPL										
  module.go:36046	0x630fa0		4539ef			CMPL R15, R13									
  module.go:36046	0x630fa3		756a			JNE 0x63100f									
  module.go:36070	0x630fa5		897c244c		MOVL DI, 0x4c(SP)								
  module.go:36047	0x630fa9		89cb			MOVL CX, BX									
  module.go:36047	0x630fab		e8b03bfbff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn88(SB)	
  module.go:36048	0x630fb0		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:36048	0x630fb8		488b4838		MOVQ 0x38(AX), CX								
  module.go:62983	0x630fbc		488b542470		MOVQ 0x70(SP), DX								
  module.go:62983	0x630fc1		4839d1			CMPQ CX, DX									
  module.go:62983	0x630fc4		0f86f2000000		JBE 0x6310bc									
  module.go:36048	0x630fca		488b7030		MOVQ 0x30(AX), SI								
  module.go:36050	0x630fce		90			NOPL										
  module.go:62984	0x630fcf		4c8b442478		MOVQ 0x78(SP), R8								
  module.go:62984	0x630fd4		458b7c300c		MOVL 0xc(R8)(SI*1), R15								
  module.go:63184	0x630fd9		4c8b4c2460		MOVQ 0x60(SP), R9								
  module.go:63184	0x630fde		458b2c31		MOVL 0(R9)(SI*1), R13								
  module.go:36047	0x630fe2		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:35702	0x630fe9		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x630fed		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:62983	0x630ff4		488b742468		MOVQ 0x68(SP), SI								
  module.go:36069	0x630ff9		8b7c244c		MOVL 0x4c(SP), DI								
  module.go:63001	0x630ffd		448b44242c		MOVL 0x2c(SP), R8								
  module.go:63001	0x631002		4c8b542478		MOVQ 0x78(SP), R10								
  module.go:63184	0x631007		4d89cb			MOVQ R9, R11									
  module.go:63000	0x63100a		4c8b642470		MOVQ 0x70(SP), R12								
  module.go:36055	0x63100f		4c8b4838		MOVQ 0x38(AX), R9								
  module.go:63000	0x631013		4d39e1			CMPQ R9, R12									
  module.go:63000	0x631016		0f869b000000		JBE 0x6310b7									
  module.go:36054	0x63101c		458d4f01		LEAL 0x1(R15), R9								
  module.go:36055	0x631020		4c8b7830		MOVQ 0x30(AX), R15								
  module.go:63001	0x631024		47894c3a0c		MOVL R9, 0xc(R10)(R15*1)							
  module.go:36056	0x631029		4c8b7838		MOVQ 0x38(AX), R15								
  module.go:62983	0x63102d		498d5a0b		LEAQ 0xb(R10), BX								
  module.go:62983	0x631031		4939df			CMPQ R15, BX									
  module.go:62983	0x631034		767c			JBE 0x6310b2									
  module.go:36056	0x631036		4c8b7830		MOVQ 0x30(AX), R15								
  module.go:62984	0x63103a		438b5c3a08		MOVL 0x8(R10)(R15*1), BX							
  module.go:36058	0x63103f		448d5bff		LEAL -0x1(BX), R11								
  module.go:36059	0x631043		418d5c1d00		LEAL 0(R13)(BX*1), BX								
  module.go:36059	0x631048		8d5bff			LEAL -0x1(BX), BX								
  module.go:62983	0x63104b		498d5207		LEAQ 0x7(R10), DX								
  module.go:36065	0x63104f		90			NOPL										
  module.go:36061	0x631050		4439db			CMPL BX, R11									
  module.go:36062	0x631053		440f42db		CMOVB BX, R11									
  module.go:63001	0x631057		47895c3a08		MOVL R11, 0x8(R10)(R15*1)							
  module.go:36066	0x63105c		4c8b7838		MOVQ 0x38(AX), R15								
  module.go:62983	0x631060		4939d7			CMPQ R15, DX									
  module.go:62983	0x631063		7648			JBE 0x6310ad									
  module.go:36066	0x631065		488b5030		MOVQ 0x30(AX), DX								
  module.go:62984	0x631069		418b5c1204		MOVL 0x4(R10)(DX*1), BX								
  module.go:36067	0x63106e		468d1cdb		LEAL 0(BX)(R11*8), R11								
  module.go:63026	0x631072		4489db			MOVL R11, BX									
  module.go:63026	0x631075		4883c307		ADDQ $0x7, BX									
  module.go:63026	0x631079		4939df			CMPQ R15, BX									
  module.go:63026	0x63107c		762a			JBE 0x6310a8									
  module.go:63027	0x63107e		4589db			MOVL R11, R11									
  module.go:63027	0x631081		4ac7041a00000000	MOVQ $0x0, 0(DX)(R11*1)								
  module.go:36069	0x631089		83ff01			CMPL DI, $0x1									
  module.go:36069	0x63108c		0f85f8feffff		JNE 0x630f8a									
  module.go:35702	0x631092		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x631096		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:63001	0x63109d		4489c7			MOVL R8, DI									
  module.go:63001	0x6310a0		4589cf			MOVL R9, R15									
  module.go:36069	0x6310a3		e9bdfeffff		JMP 0x630f65									
  module.go:63026	0x6310a8		e813f9e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x6310ad		e80ef9e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x6310b2		e809f9e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x6310b7		e804f9e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x6310bc		0f1f4000		NOPL 0(AX)									
  module.go:62983	0x6310c0		e8fbf8e5ff		CALL runtime.panicBounds(SB)							
  module.go:63113	0x6310c5		e8f6f8e5ff		CALL runtime.panicBounds(SB)							
  module.go:63113	0x6310ca		e8f1f8e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x6310cf		e8ecf8e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x6310d4		e8e7f8e5ff		CALL runtime.panicBounds(SB)							
  module.go:63113	0x6310d9		e8e2f8e5ff		CALL runtime.panicBounds(SB)							
  module.go:63113	0x6310de		6690			NOPW										
  module.go:63113	0x6310e0		e8dbf8e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x6310e5		e8d6f8e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x6310ea		e8d1f8e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x6310ef		e8ccf8e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x6310f4		e8c7f8e5ff		CALL runtime.panicBounds(SB)							
  module.go:35988	0x6310f9		bb508e1000		MOVL $0x108e50, BX								
  module.go:35988	0x6310fe		b911000000		MOVL $0x11, CX									
  module.go:35988	0x631103		bfe88e1000		MOVL $0x108ee8, DI								
  module.go:35988	0x631108		e873ebfaff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn69(SB)	
  module.go:35989	0x63110d		488d050c992100		LEAQ 0x21990c(IP), AX								
  module.go:35989	0x631114		488d1dd5112d00		LEAQ 0x2d11d5(IP), BX								
  module.go:35989	0x63111b		0f1f440000		NOPL 0(AX)(AX*1)								
  module.go:35989	0x631120		e8bb76e5ff		CALL runtime.gopanic(SB)							
  module.go:62983	0x631125		e896f8e5ff		CALL runtime.panicBounds(SB)							
  module.go:36143	0x63112a		4539d8			CMPL R8, R11									
  module.go:36143	0x63112d		7603			JBE 0x631132									
  module.go:36143	0x63112f		4531c0			XORL R8, R8									
  module.go:36146	0x631132		4529c3			SUBL R8, R11									
  module.go:36146	0x631135		478d04dc		LEAL 0(R12)(R11*8), R8								
  module.go:36147	0x631139		4c8b5838		MOVQ 0x38(AX), R11								
  module.go:63009	0x63113d		4589c4			MOVL R8, R12									
  module.go:63009	0x631140		4983c407		ADDQ $0x7, R12									
  module.go:63009	0x631144		4d39e3			CMPQ R11, R12									
  module.go:63009	0x631147		0f86f8010000		JBE 0x631345									
  module.go:36147	0x63114d		4c8b5830		MOVQ 0x30(AX), R11								
  module.go:36148	0x631151		4c8b6838		MOVQ 0x38(AX), R13								
  module.go:63010	0x631155		4589c0			MOVL R8, R8									
  module.go:63010	0x631158		4f8b1c18		MOVQ 0(R8)(R11*1), R11								
  module.go:36147	0x63115c		66490f6ecb		MOVQ R11, X1									
  module.go:36148	0x631161		f20f58c1		ADDSD X1, X0									
  module.go:63026	0x631165		4d39e5			CMPQ R13, R12									
  module.go:63026	0x631168		0f86d0010000		JBE 0x63133e									
  module.go:36148	0x63116e		4c8b5830		MOVQ 0x30(AX), R11								
  module.go:63027	0x631172		f2430f110403		MOVSD_XMM X0, 0(R11)(R8*1)							
  module.go:36153	0x631178		4c8b4038		MOVQ 0x38(AX), R8								
  module.go:36152	0x63117c		468d1c0f		LEAL 0(DI)(R9*1), R11								
  module.go:36152	0x631180		458d0c39		LEAL 0(R9)(DI*1), R9								
  module.go:36152	0x631184		458d4901		LEAL 0x1(R9), R9								
  module.go:63000	0x631188		4939f0			CMPQ R8, SI									
  module.go:63000	0x63118b		0f86a8010000		JBE 0x631339									
  module.go:36153	0x631191		488b7030		MOVQ 0x30(AX), SI								
  module.go:63001	0x631195		45894c3210		MOVL R9, 0x10(R10)(SI*1)							
  module.go:36154	0x63119a		4429da			SUBL R11, DX									
  module.go:36154	0x63119d		448d4aff		LEAL -0x1(DX), R9								
  module.go:63000	0x6311a1		4c8b642470		MOVQ 0x70(SP), R12								
  module.go:36157	0x6311a6		4489ca			MOVL R9, DX									
  module.go:36157	0x6311a9		4529f9			SUBL R15, R9									
  module.go:36157	0x6311ac		4181f9feffff7f		CMPL R9, $0x7ffffffe								
  module.go:36157	0x6311b3		7733			JA 0x6311e8									
  module.go:36161	0x6311b5		488b7038		MOVQ 0x38(AX), SI								
  module.go:62983	0x6311b9		4d8d4203		LEAQ 0x3(R10), R8								
  module.go:62983	0x6311bd		0f1f00			NOPL 0(AX)									
  module.go:62983	0x6311c0		4c39c6			CMPQ SI, R8									
  module.go:62983	0x6311c3		0f866b010000		JBE 0x631334									
  module.go:62983	0x6311c9		4c89442468		MOVQ R8, 0x68(SP)								
  module.go:36154	0x6311ce		8954244c		MOVL DX, 0x4c(SP)								
  module.go:36161	0x6311d2		488b7030		MOVQ 0x30(AX), SI								
  module.go:62984	0x6311d6		4189c9			MOVL CX, R9									
  module.go:62984	0x6311d9		4c894c2460		MOVQ R9, 0x60(SP)								
  module.go:36160	0x6311de		458d5fff		LEAL -0x1(R15), R11								
  module.go:62984	0x6311e2		418b3431		MOVL 0(R9)(SI*1), SI								
  module.go:36163	0x6311e6		eb26			JMP 0x63120e									
  module.go:63000	0x6311e8		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:36076	0x6311ef		4189d1			MOVL DX, R9									
  module.go:36195	0x6311f2		4589f8			MOVL R15, R8									
  module.go:35702	0x6311f5		8b542434		MOVL 0x34(SP), DX								
  module.go:36158	0x6311f9		e971fcffff		JMP 0x630e6f									
  module.go:62983	0x6311fe		4c8b442468		MOVQ 0x68(SP), R8								
  module.go:36191	0x631203		4589ef			MOVL R13, R15									
  module.go:36191	0x631206		4589cb			MOVL R9, R11									
  module.go:62984	0x631209		4c8b4c2460		MOVQ 0x60(SP), R9								
  module.go:36167	0x63120e		4439fe			CMPL SI, R15									
  module.go:36167	0x631211		7570			JNE 0x631283									
  module.go:36191	0x631213		44895c242c		MOVL R11, 0x2c(SP)								
  module.go:36168	0x631218		89cb			MOVL CX, BX									
  module.go:36168	0x63121a		e84139fbff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn88(SB)	
  module.go:36169	0x63121f		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:36169	0x631227		488b4838		MOVQ 0x38(AX), CX								
  module.go:62983	0x63122b		488b542468		MOVQ 0x68(SP), DX								
  module.go:62983	0x631230		4839d1			CMPQ CX, DX									
  module.go:62983	0x631233		0f86f6000000		JBE 0x63132f									
  module.go:36169	0x631239		488b7030		MOVQ 0x30(AX), SI								
  module.go:62984	0x63123d		4c8b442460		MOVQ 0x60(SP), R8								
  module.go:62984	0x631242		458b0c30		MOVL 0(R8)(SI*1), R9								
  module.go:62983	0x631246		4c8b542470		MOVQ 0x70(SP), R10								
  module.go:62983	0x63124b		4c39d1			CMPQ CX, R10									
  module.go:62983	0x63124e		0f86d6000000		JBE 0x63132a									
  module.go:62984	0x631254		4c8b5c2478		MOVQ 0x78(SP), R11								
  module.go:62984	0x631259		458b7c330c		MOVL 0xc(R11)(SI*1), R15							
  module.go:36168	0x63125e		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:36190	0x631265		8b54244c		MOVL 0x4c(SP), DX								
  module.go:62983	0x631269		4c8b442468		MOVQ 0x68(SP), R8								
  module.go:63001	0x63126e		4d89da			MOVQ R11, R10									
  module.go:36189	0x631271		448b5c242c		MOVL 0x2c(SP), R11								
  module.go:63000	0x631276		4c8b642470		MOVQ 0x70(SP), R12								
  module.go:36171	0x63127b		4489ce			MOVL R9, SI									
  module.go:62984	0x63127e		4c8b4c2460		MOVQ 0x60(SP), R9								
  module.go:36178	0x631283		4c8b6838		MOVQ 0x38(AX), R13								
  module.go:63000	0x631287		4d39e5			CMPQ R13, R12									
  module.go:63000	0x63128a		0f8695000000		JBE 0x631325									
  module.go:36177	0x631290		458d6f01		LEAL 0x1(R15), R13								
  module.go:36178	0x631294		488b5830		MOVQ 0x30(AX), BX								
  module.go:63001	0x631298		45896c1a0c		MOVL R13, 0xc(R10)(BX*1)							
  module.go:36179	0x63129d		488b5838		MOVQ 0x38(AX), BX								
  module.go:62983	0x6312a1		498d7a07		LEAQ 0x7(R10), DI								
  module.go:62983	0x6312a5		4839fb			CMPQ BX, DI									
  module.go:62983	0x6312a8		7673			JBE 0x63131d									
  module.go:36179	0x6312aa		488b7830		MOVQ 0x30(AX), DI								
  module.go:62983	0x6312ae		4d8d4a0b		LEAQ 0xb(R10), R9								
  module.go:36180	0x6312b2		90			NOPL										
  module.go:62984	0x6312b3		458b443a04		MOVL 0x4(R10)(DI*1), R8								
  module.go:62983	0x6312b8		4c39cb			CMPQ BX, R9									
  module.go:62983	0x6312bb		765b			JBE 0x631318									
  module.go:62984	0x6312bd		458b4c3a08		MOVL 0x8(R10)(DI*1), R9								
  module.go:36181	0x6312c2		4501f9			ADDL R15, R9									
  module.go:36184	0x6312c5		4439ce			CMPL SI, R9									
  module.go:36185	0x6312c8		41bf00000000		MOVL $0x0, R15									
  module.go:36185	0x6312ce		440f46fe		CMOVBE SI, R15									
  module.go:36187	0x6312d2		4529f9			SUBL R15, R9									
  module.go:36187	0x6312d5		478d04c8		LEAL 0(R8)(R9*8), R8								
  module.go:63026	0x6312d9		4589c1			MOVL R8, R9									
  module.go:63026	0x6312dc		4983c107		ADDQ $0x7, R9									
  module.go:63026	0x6312e0		4c39cb			CMPQ BX, R9									
  module.go:36184	0x6312e3		762e			JBE 0x631313									
  module.go:36189	0x6312e5		458d4b01		LEAL 0x1(R11), R9								
  module.go:63027	0x6312e9		4589c0			MOVL R8, R8									
  module.go:63027	0x6312ec		4ac7040700000000	MOVQ $0x0, 0(DI)(R8*1)								
  module.go:36190	0x6312f4		4439ca			CMPL DX, R9									
  module.go:36190	0x6312f7		0f8501ffffff		JNE 0x6311fe									
  module.go:63000	0x6312fd		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:36076	0x631304		4189d1			MOVL DX, R9									
  module.go:36195	0x631307		4589e8			MOVL R13, R8									
  module.go:35702	0x63130a		8b542434		MOVL 0x34(SP), DX								
  module.go:36190	0x63130e		e95cfbffff		JMP 0x630e6f									
  module.go:63026	0x631313		e8a8f6e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x631318		e8a3f6e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x63131d		0f1f00			NOPL 0(AX)									
  module.go:62983	0x631320		e89bf6e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x631325		e896f6e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x63132a		e891f6e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x63132f		e88cf6e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x631334		e887f6e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x631339		e882f6e5ff		CALL runtime.panicBounds(SB)							
  module.go:63026	0x63133e		6690			NOPW										
  module.go:63026	0x631340		e87bf6e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x631345		e876f6e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x63134a		e871f6e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x63134f		e86cf6e5ff		CALL runtime.panicBounds(SB)							
  module.go:35950	0x631354		4183c0fe		ADDL $-0x2, R8									
  module.go:35952	0x631358		44897c2428		MOVL R15, 0x28(SP)								
  module.go:35952	0x63135d		448b7c2440		MOVL 0x40(SP), R15								
  module.go:35898	0x631362		4585ff			TESTL R15, R15									
  module.go:35898	0x631365		750b			JNE 0x631372									
  module.go:35898	0x631367		4531ff			XORL R15, R15									
  module.go:35898	0x63136a		0f57c9			XORPS X1, X1									
  module.go:35902	0x63136d		e996000000		JMP 0x631408									
  module.go:35906	0x631372		488b5838		MOVQ 0x38(AX), BX								
  module.go:63000	0x631376		4c39e3			CMPQ BX, R12									
  module.go:63000	0x631379		0f867a030000		JBE 0x6316f9									
  module.go:35905	0x63137f		41ffcf			DECL R15									
  module.go:35906	0x631382		488b5830		MOVQ 0x30(AX), BX								
  module.go:63001	0x631386		45897c1a0c		MOVL R15, 0xc(R10)(BX*1)							
  module.go:35908	0x63138b		8d5901			LEAL 0x1(CX), BX								
  module.go:35911	0x63138e		4139dd			CMPL R13, BX									
  module.go:35911	0x631391		7705			JA 0x631398									
  module.go:63184	0x631393		4489eb			MOVL R13, BX									
  module.go:35912	0x631396		eb06			JMP 0x63139e									
  module.go:35938	0x631398		4489eb			MOVL R13, BX									
  module.go:35938	0x63139b		4531ed			XORL R13, R13									
  module.go:35952	0x63139e		894c2430		MOVL CX, 0x30(SP)								
  module.go:35915	0x6313a2		488b5038		MOVQ 0x38(AX), DX								
  module.go:35914	0x6313a6		4429e9			SUBL R13, CX									
  module.go:63000	0x6313a9		4839f2			CMPQ DX, SI									
  module.go:63000	0x6313ac		0f8642030000		JBE 0x6316f4									
  module.go:35914	0x6313b2		8d5101			LEAL 0x1(CX), DX								
  module.go:35915	0x6313b5		4c8b6830		MOVQ 0x30(AX), R13								
  module.go:63001	0x6313b9		4389542a08		MOVL DX, 0x8(R10)(R13*1)							
  module.go:35916	0x6313be		4c8b6838		MOVQ 0x38(AX), R13								
  module.go:35877	0x6313c2		4489d9			MOVL R11, CX									
  module.go:35916	0x6313c5		448b5c2430		MOVL 0x30(SP), R11								
  module.go:35916	0x6313ca		478d1cd9		LEAL 0(R9)(R11*8), R11								
  module.go:63009	0x6313ce		4489df			MOVL R11, DI									
  module.go:63009	0x6313d1		4883c707		ADDQ $0x7, DI									
  module.go:63009	0x6313d5		4939fd			CMPQ R13, DI									
  module.go:63009	0x6313d8		0f8611030000		JBE 0x6316ef									
  module.go:35916	0x6313de		4c8b6830		MOVQ 0x30(AX), R13								
  module.go:63010	0x6313e2		4589db			MOVL R11, R11									
  module.go:63010	0x6313e5		4f8b1c2b		MOVQ 0(R11)(R13*1), R11								
  unsafe.go:41		0x6313e9		66490f6ecb		MOVQ R11, X1									
  module.go:36122	0x6313ee		8b7c2448		MOVL 0x48(SP), DI								
  module.go:36085	0x6313f2		4189cb			MOVL CX, R11									
  module.go:35938	0x6313f5		4189dd			MOVL BX, R13									
  module.go:35916	0x6313f8		89d1			MOVL DX, CX									
  module.go:35916	0x6313fa		44897c2428		MOVL R15, 0x28(SP)								
  module.go:36154	0x6313ff		8b542424		MOVL 0x24(SP), DX								
  module.go:63184	0x631403		488b5c2460		MOVQ 0x60(SP), BX								
  module.go:35922	0x631408		f20f58c8		ADDSD X0, X1									
  module.go:35925	0x63140c		4585ff			TESTL R15, R15									
  module.go:35925	0x63140f		751a			JNE 0x63142b									
  module.go:35925	0x631411		0f57c0			XORPS X0, X0									
  module.go:35943	0x631414		448b7c2428		MOVL 0x28(SP), R15								
  module.go:35943	0x631419		4531ff			XORL R15, R15									
  module.go:35943	0x63141c		44897c2440		MOVL R15, 0x40(SP)								
  module.go:35943	0x631421		448b7c2428		MOVL 0x28(SP), R15								
  module.go:35929	0x631426		e996000000		JMP 0x6314c1									
  module.go:35933	0x63142b		488b5838		MOVQ 0x38(AX), BX								
  module.go:63000	0x63142f		4c39e3			CMPQ BX, R12									
  module.go:63000	0x631432		0f86b2020000		JBE 0x6316ea									
  module.go:35932	0x631438		41ffcf			DECL R15									
  module.go:35933	0x63143b		488b5830		MOVQ 0x30(AX), BX								
  module.go:63001	0x63143f		45897c1a0c		MOVL R15, 0xc(R10)(BX*1)							
  module.go:35935	0x631444		8d5901			LEAL 0x1(CX), BX								
  module.go:35938	0x631447		4139dd			CMPL R13, BX									
  module.go:35938	0x63144a		7705			JA 0x631451									
  module.go:63184	0x63144c		4489eb			MOVL R13, BX									
  module.go:35939	0x63144f		eb06			JMP 0x631457									
  module.go:35911	0x631451		4489eb			MOVL R13, BX									
  module.go:35911	0x631454		4531ed			XORL R13, R13									
  module.go:35916	0x631457		894c2444		MOVL CX, 0x44(SP)								
  module.go:35942	0x63145b		488b5038		MOVQ 0x38(AX), DX								
  module.go:35941	0x63145f		4429e9			SUBL R13, CX									
  module.go:63000	0x631462		4839f2			CMPQ DX, SI									
  module.go:63000	0x631465		0f867a020000		JBE 0x6316e5									
  module.go:35941	0x63146b		8d5101			LEAL 0x1(CX), DX								
  module.go:35942	0x63146e		4c8b6830		MOVQ 0x30(AX), R13								
  module.go:63001	0x631472		4389542a08		MOVL DX, 0x8(R10)(R13*1)							
  module.go:35943	0x631477		4c8b6838		MOVQ 0x38(AX), R13								
  module.go:35877	0x63147b		4489d9			MOVL R11, CX									
  module.go:35943	0x63147e		448b5c2444		MOVL 0x44(SP), R11								
  module.go:35943	0x631483		478d1cd9		LEAL 0(R9)(R11*8), R11								
  module.go:63009	0x631487		4489df			MOVL R11, DI									
  module.go:63009	0x63148a		4883c707		ADDQ $0x7, DI									
  module.go:63009	0x63148e		4939fd			CMPQ R13, DI									
  module.go:63009	0x631491		0f8647020000		JBE 0x6316de									
  module.go:35943	0x631497		4c8b6830		MOVQ 0x30(AX), R13								
  module.go:63010	0x63149b		4589db			MOVL R11, R11									
  module.go:63010	0x63149e		4f8b1c2b		MOVQ 0(R11)(R13*1), R11								
  unsafe.go:41		0x6314a2		66490f6ec3		MOVQ R11, X0									
  module.go:36122	0x6314a7		8b7c2448		MOVL 0x48(SP), DI								
  module.go:36085	0x6314ab		4189cb			MOVL CX, R11									
  module.go:35911	0x6314ae		4189dd			MOVL BX, R13									
  module.go:35943	0x6314b1		89d1			MOVL DX, CX									
  module.go:35943	0x6314b3		44897c2440		MOVL R15, 0x40(SP)								
  module.go:36154	0x6314b8		8b542424		MOVL 0x24(SP), DX								
  module.go:63184	0x6314bc		488b5c2460		MOVQ 0x60(SP), BX								
  module.go:35949	0x6314c1		f20f58c1		ADDSD X1, X0									
  module.go:35951	0x6314c5		4183f802		CMPL R8, $0x2									
  module.go:35951	0x6314c9		0f8585feffff		JNE 0x631354									
  module.go:36085	0x6314cf		410fbae300		BTL $0x0, R11									
  module.go:36085	0x6314d4		7208			JB 0x6314de									
  module.go:36086	0x6314d6		4589f8			MOVL R15, R8									
  module.go:36086	0x6314d9		e9a2000000		JMP 0x631580									
  module.go:36088	0x6314de		4589f8			MOVL R15, R8									
  module.go:36088	0x6314e1		448b7c2440		MOVL 0x40(SP), R15								
  module.go:36089	0x6314e6		4585ff			TESTL R15, R15									
  module.go:36089	0x6314e9		0f848a000000		JE 0x631579									
  module.go:36092	0x6314ef		4c8b4038		MOVQ 0x38(AX), R8								
  module.go:63000	0x6314f3		4d39e0			CMPQ R8, R12									
  module.go:63000	0x6314f6		0f86dd010000		JBE 0x6316d9									
  module.go:36091	0x6314fc		458d47ff		LEAL -0x1(R15), R8								
  module.go:36092	0x631500		4c8b5830		MOVQ 0x30(AX), R11								
  module.go:63001	0x631504		4789441a0c		MOVL R8, 0xc(R10)(R11*1)							
  module.go:36094	0x631509		448d5901		LEAL 0x1(CX), R11								
  module.go:36097	0x63150d		4539dd			CMPL R13, R11									
  module.go:36097	0x631510		7705			JA 0x631517									
  module.go:63184	0x631512		4589eb			MOVL R13, R11									
  module.go:36098	0x631515		eb06			JMP 0x63151d									
  module.go:36112	0x631517		4589eb			MOVL R13, R11									
  module.go:36112	0x63151a		4531ed			XORL R13, R13									
  module.go:36088	0x63151d		894c243c		MOVL CX, 0x3c(SP)								
  module.go:36101	0x631521		4c8b7838		MOVQ 0x38(AX), R15								
  module.go:36100	0x631525		4429e9			SUBL R13, CX									
  module.go:63000	0x631528		4939f7			CMPQ R15, SI									
  module.go:63000	0x63152b		0f86a3010000		JBE 0x6316d4									
  module.go:36100	0x631531		448d6901		LEAL 0x1(CX), R13								
  module.go:36101	0x631535		4c8b7830		MOVQ 0x30(AX), R15								
  module.go:63001	0x631539		47896c3a08		MOVL R13, 0x8(R10)(R15*1)							
  module.go:36102	0x63153e		4c8b7838		MOVQ 0x38(AX), R15								
  module.go:35833	0x631542		89d1			MOVL DX, CX									
  module.go:36102	0x631544		8b54243c		MOVL 0x3c(SP), DX								
  module.go:36102	0x631548		418d14d1		LEAL 0(R9)(DX*8), DX								
  module.go:63009	0x63154c		89d3			MOVL DX, BX									
  module.go:63009	0x63154e		4883c307		ADDQ $0x7, BX									
  module.go:63009	0x631552		4939df			CMPQ R15, BX									
  module.go:63009	0x631555		0f8674010000		JBE 0x6316cf									
  module.go:36102	0x63155b		4c8b7830		MOVQ 0x30(AX), R15								
  module.go:63010	0x63155f		89d2			MOVL DX, DX									
  module.go:63010	0x631561		4a8b143a		MOVQ 0(DX)(R15*1), DX								
  unsafe.go:41		0x631565		66480f6eca		MOVQ DX, X1									
  module.go:36154	0x63156a		89ca			MOVL CX, DX									
  module.go:63184	0x63156c		488b5c2460		MOVQ 0x60(SP), BX								
  module.go:36102	0x631571		4489e9			MOVL R13, CX									
  module.go:36112	0x631574		4589dd			MOVL R11, R13									
  module.go:36104	0x631577		eb03			JMP 0x63157c									
  module.go:36104	0x631579		0f57c9			XORPS X1, X1									
  module.go:36106	0x63157c		f20f58c1		ADDSD X1, X0									
  module.go:36108	0x631580		4585c0			TESTL R8, R8									
  module.go:36108	0x631583		7422			JE 0x6315a7									
  module.go:63000	0x631585		488b742468		MOVQ 0x68(SP), SI								
  module.go:36109	0x63158a		4189cb			MOVL CX, R11									
  module.go:36109	0x63158d		4589c7			MOVL R8, R15									
  module.go:36109	0x631590		4589cc			MOVL R9, R12									
  module.go:62984	0x631593		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:36152	0x63159a		448b4c244c		MOVL 0x4c(SP), R9								
  module.go:36109	0x63159f		4589e8			MOVL R13, R8									
  module.go:36109	0x6315a2		e983fbffff		JMP 0x63112a									
  module.go:36112	0x6315a7		4585ed			TESTL R13, R13									
  module.go:36112	0x6315aa		740b			JE 0x6315b7									
  module.go:36112	0x6315ac		41bb01000000		MOVL $0x1, R11									
  module.go:36112	0x6315b2		e987000000		JMP 0x63163e									
  module.go:62983	0x6315b7		4889742458		MOVQ SI, 0x58(SP)								
  module.go:36086	0x6315bc		f20f11442450		MOVSD_XMM X0, 0x50(SP)								
  module.go:36113	0x6315c2		8b9c249c000000		MOVL 0x9c(SP), BX								
  module.go:36113	0x6315c9		e89235fbff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn88(SB)	
  module.go:36114	0x6315ce		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:36114	0x6315d6		488b4838		MOVQ 0x38(AX), CX								
  module.go:62983	0x6315da		488b542470		MOVQ 0x70(SP), DX								
  module.go:62983	0x6315df		90			NOPL										
  module.go:62983	0x6315e0		4839d1			CMPQ CX, DX									
  module.go:62983	0x6315e3		0f86e1000000		JBE 0x6316ca									
  module.go:36114	0x6315e9		488b7030		MOVQ 0x30(AX), SI								
  module.go:36116	0x6315ed		90			NOPL										
  module.go:62984	0x6315ee		4c8b442478		MOVQ 0x78(SP), R8								
  module.go:62984	0x6315f3		458b4c300c		MOVL 0xc(R8)(SI*1), R9								
  module.go:62983	0x6315f8		4c8b542468		MOVQ 0x68(SP), R10								
  module.go:62983	0x6315fd		0f1f00			NOPL 0(AX)									
  module.go:62983	0x631600		4c39d1			CMPQ CX, R10									
  module.go:62983	0x631603		0f86bc000000		JBE 0x6316c5									
  module.go:36115	0x631609		458d5901		LEAL 0x1(R9), R11								
  module.go:36118	0x63160d		90			NOPL										
  module.go:36120	0x63160e		90			NOPL										
  module.go:62984	0x63160f		418b7c3010		MOVL 0x10(R8)(SI*1), DI								
  module.go:63184	0x631614		458b4c3004		MOVL 0x4(R8)(SI*1), R9								
  module.go:63184	0x631619		4c8b642460		MOVQ 0x60(SP), R12								
  module.go:63184	0x63161e		458b2c34		MOVL 0(R12)(SI*1), R13								
  module.go:63184	0x631622		418b4c3008		MOVL 0x8(R8)(SI*1), CX								
  module.go:36154	0x631627		8b542424		MOVL 0x24(SP), DX								
  module.go:63000	0x63162b		488b742458		MOVQ 0x58(SP), SI								
  module.go:63001	0x631630		4d89c2			MOVQ R8, R10									
  module.go:63000	0x631633		4c8b642470		MOVQ 0x70(SP), R12								
  module.go:63027	0x631638		f20f10442450		MOVSD_XMM 0x50(SP), X0								
  module.go:36125	0x63163e		4c8b4038		MOVQ 0x38(AX), R8								
  module.go:63000	0x631642		4d39e0			CMPQ R8, R12									
  module.go:63000	0x631645		7674			JBE 0x6316bb									
  module.go:36125	0x631647		4c8b4030		MOVQ 0x30(AX), R8								
  module.go:63001	0x63164b		47895c020c		MOVL R11, 0xc(R10)(R8*1)							
  module.go:36128	0x631650		448d41ff		LEAL -0x1(CX), R8								
  module.go:36129	0x631654		458d7c0d00		LEAL 0(R13)(CX*1), R15								
  module.go:36129	0x631659		458d7fff		LEAL -0x1(R15), R15								
  module.go:36135	0x63165d		488b4838		MOVQ 0x38(AX), CX								
  module.go:36131	0x631661		4539fd			CMPL R13, R15									
  module.go:36132	0x631664		450f47c7		CMOVA R15, R8									
  module.go:63000	0x631668		4839f1			CMPQ CX, SI									
  module.go:36131	0x63166b		7649			JBE 0x6316b6									
  module.go:36135	0x63166d		488b7030		MOVQ 0x30(AX), SI								
  module.go:63001	0x631671		4589443208		MOVL R8, 0x8(R10)(SI*1)								
  module.go:36136	0x631676		488b7038		MOVQ 0x38(AX), SI								
  module.go:36136	0x63167a		478d04c1		LEAL 0(R9)(R8*8), R8								
  module.go:63026	0x63167e		4589c1			MOVL R8, R9									
  module.go:63026	0x631681		4983c107		ADDQ $0x7, R9									
  module.go:63026	0x631685		4c39ce			CMPQ SI, R9									
  module.go:63026	0x631688		7627			JBE 0x6316b1									
  module.go:36136	0x63168a		4c8b6830		MOVQ 0x30(AX), R13								
  module.go:63027	0x63168e		4589c0			MOVL R8, R8									
  module.go:63027	0x631691		f2430f11440500		MOVSD_XMM X0, 0(R13)(R8*1)							
  module.go:62984	0x631698		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:63000	0x63169f		488b742468		MOVQ 0x68(SP), SI								
  module.go:36152	0x6316a4		448b4c244c		MOVL 0x4c(SP), R9								
  module.go:36137	0x6316a9		4589df			MOVL R11, R15									
  module.go:36137	0x6316ac		e9c7faffff		JMP 0x631178									
  module.go:63026	0x6316b1		e80af3e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x6316b6		e805f3e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x6316bb		0f1f440000		NOPL 0(AX)(AX*1)								
  module.go:63000	0x6316c0		e8fbf2e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x6316c5		e8f6f2e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x6316ca		e8f1f2e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x6316cf		e8ecf2e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x6316d4		e8e7f2e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x6316d9		e8e2f2e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x6316de		6690			NOPW										
  module.go:63009	0x6316e0		e8dbf2e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x6316e5		e8d6f2e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x6316ea		e8d1f2e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x6316ef		e8ccf2e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x6316f4		e8c7f2e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x6316f9		e8c2f2e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x6316fe		6690			NOPW										
  module.go:62983	0x631700		e8bbf2e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x631705		e8b6f2e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x63170a		e8b1f2e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x63170f		e8acf2e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x631714		e8a7f2e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x631719		e8a2f2e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x63171e		6690			NOPW										
  module.go:63009	0x631720		e89bf2e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x631725		90			NOPL										
  module.go:35694	0x631726		4889442408		MOVQ AX, 0x8(SP)								
  module.go:35694	0x63172b		895c2410		MOVL BX, 0x10(SP)								
  module.go:35694	0x63172f		894c2414		MOVL CX, 0x14(SP)								
  module.go:35694	0x631733		f20f11442418		MOVSD_XMM X0, 0x18(SP)								
  module.go:35694	0x631739		e862d5e5ff		CALL runtime.morestack_noctxt.abi0(SB)						
  module.go:35694	0x63173e		488b442408		MOVQ 0x8(SP), AX								
  module.go:35694	0x631743		8b5c2410		MOVL 0x10(SP), BX								
  module.go:35694	0x631747		8b4c2414		MOVL 0x14(SP), CX								
  module.go:35694	0x63174b		f20f10442418		MOVSD_XMM 0x18(SP), X0								
  module.go:35694	0x631751		e9aaeaffff		JMP dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn176(SB)	
