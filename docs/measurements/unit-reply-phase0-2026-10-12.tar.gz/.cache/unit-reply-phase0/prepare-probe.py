"""Whole-source-pinned authored runtime/emitter diagnostic; no production edits."""
from pathlib import Path
import datetime
import difflib
import hashlib
import json
import os
import re
import subprocess

root = Path.cwd()
out = root / '.cache/unit-reply-phase0'
go = root / '.cache/toolchains/go1.26.8/go/bin/go'
env = dict(os.environ, GOTOOLCHAIN='local', CGO_ENABLED='0', GOAMD64='v1',
           GOCACHE=str(root / '.cache/go'), GOFLAGS='-buildvcs=false')
env['PATH'] = str(go.parent) + ':' + env['PATH']
assert subprocess.check_output([str(go), 'version'], env=env, text=True).strip() == 'go version go1.26.8 linux/amd64'
records = []

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run(name, args):
    item = {'name': name, 'argv': [str(a) for a in args],
            'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    with (out / (name + '.log')).open('x') as log:
        print('COMMAND', json.dumps(item['argv']), file=log, flush=True)
        result = subprocess.run(item['argv'], env=env, stdout=log, stderr=subprocess.STDOUT)
        print('EXIT', result.returncode, file=log, flush=True)
    item.update(exit=result.returncode, completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    records.append(item)
    (out / 'variant-build-records.json').write_text(json.dumps(records, indent=2) + '\n')
    assert result.returncode == 0, name
    print('PASS', name, flush=True)

runtime = root / 'rt/instance.go'
emitter = root / 'internal/gen/gogen/gogen.go'
assert sha(runtime) == '607103f216fb1da1445e705deaea8891f21cbdd04f74e385f4958795ef107d74'
assert sha(emitter) == 'c26dc4d527d70c10a24a67e7b5f10d3414215b6453908192874ae98ac388a1d4'
source = runtime.read_text()
old_unit = re.search(r'func \(c \*Call\) ResultUnit\(op string, status Status\) error \{.*?\n\}', source, re.S).group()
assert source.count(old_unit) == 1 and 'unitReplyTail' not in source
new_unit = '''func (c *Call) ResultUnit(op string, status Status) error {
	memory := c.instance.module.Memory()
	descriptor, err := Range(memory, c.instance.output, 8)
	if err != nil {
		return err
	}
	pointer := binary.LittleEndian.Uint32(descriptor)
	size := binary.LittleEndian.Uint32(descriptor[4:])
	if uint64(size) > c.instance.limits.MaxOutput {
		return ErrTooLarge
	}
	if status == OK && size == 0 {
		_, err := Range(memory, pointer, 0)
		return err
	}
	return unitReplyTail(op, status, memory, pointer, size)
}'''
tail = '''
func unitReplyTail(op string, status Status, memory []byte, pointer, size uint32) error {
	view, err := Range(memory, pointer, size)
	if err != nil {
		return err
	}
	if status != OK {
		if err := FromStatus(op, status, view); err != nil {
			return err
		}
	}
	if len(view) != 0 {
		return ErrProtocol
	}
	return nil
}
'''
probe_runtime = source.replace(old_unit, new_unit, 1) + tail
(out / 'probe-instance.go').write_text(probe_runtime)
(out / 'runtime-probe.patch').write_text(''.join(difflib.unified_diff(source.splitlines(True), probe_runtime.splitlines(True), fromfile='rt/instance.go', tofile='ignored/probe-instance.go')))

generator = emitter.read_text()
old_generator = '''	fmt.Fprintf(b, "_status:=rt.Status(_guest.module.Xcocoon_%s(%s)); _reply,_resultErr:=_call.ResultView(%q,_status); if _resultErr!=nil { return _resultErr };\\n", export, strings.Join(args, ","), function.Name)
	if result == "" {
		b.WriteString("if len(_reply)!=0 { return rt.ErrProtocol }; return nil\\n")
	} else {
		typ := result'''
new_generator = '''	fmt.Fprintf(b, "_status:=rt.Status(_guest.module.Xcocoon_%s(%s));\\n", export, strings.Join(args, ","))
	if result == "" {
		fmt.Fprintf(b, "return _call.ResultUnit(%q,_status)\\n", function.Name)
	} else {
		fmt.Fprintf(b, "_reply,_resultErr:=_call.ResultView(%q,_status); if _resultErr!=nil { return _resultErr };\\n", function.Name)
		typ := result'''
assert generator.count(old_generator) == 1
changed_generator = generator.replace(old_generator, new_generator, 1)
(out / 'unit-gogen.go').write_text(changed_generator)
(out / 'generator-probe.patch').write_text(''.join(difflib.unified_diff(generator.splitlines(True), changed_generator.splitlines(True), fromfile='internal/gen/gogen/gogen.go', tofile='ignored/unit-gogen.go')))
generator_map = {str(emitter): str(out / 'unit-gogen.go')}
(out / 'generator-overlay.json').write_text(json.dumps({'Replace': generator_map}, indent=2) + '\n')
facades = {}
for fixture, package in [('examples/datadog', 'dd'), ('testdata/compute', 'compute'), ('testdata/streaming', 'streaming')]:
    manifest_file = root / fixture / 'cocoon.toml'
    production = root / fixture / 'go' / package / 'cocoon_gen.go'
    baseline = out / (package + '-baseline-facade.go')
    changed = out / (package + '-unit-facade.go')
    run(package + '-baseline-generate', [go, 'run', '-pgo=off', out / 'generate_facade.go', manifest_file, baseline])
    assert baseline.read_bytes() == production.read_bytes(), fixture
    run(package + '-unit-generate', [go, 'run', '-pgo=off', '-overlay=' + str(out / 'generator-overlay.json'), out / 'generate_facade.go', manifest_file, changed])
    facades[str(production)] = str(changed)
    (out / (package + '-facade.patch')).write_text(''.join(difflib.unified_diff(production.read_text().splitlines(True), changed.read_text().splitlines(True), fromfile=str(production.relative_to(root)), tofile='ignored/' + changed.name)))

overlays = {'baseline': {}, 'control': {**generator_map, **facades},
            'probe': {**generator_map, **facades, str(runtime): str(out / 'probe-instance.go')}}
for role, replace in overlays.items():
    (out / (role + '-overlay.json')).write_text(json.dumps({'Replace': replace}, indent=2) + '\n')
inventory = {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
             'authored_source_sha256': {str(p.relative_to(root)): sha(p) for p in (runtime, emitter)},
             'overlays': overlays, 'old_unit_source': old_unit, 'new_unit_source': new_unit, 'tail_source': tail,
             'environment': {key: env.get(key, 'default') for key in ('PATH', 'GOTOOLCHAIN', 'CGO_ENABLED', 'GOAMD64', 'GOCACHE', 'GOFLAGS')},
             'scope': 'Ignored authored-source runtime/emitter overlays with regenerated facades, not retained generated-only edits. Untouched baseline vs same ResultUnit call-shape control vs specialization. Guest/shim/Wasm/Range/ResultView/Call/admission/ownership/reset/poison/drain unchanged. One reply Memory capture and independent post-memory query remain. No new public contract.'}
(out / 'probe-inventory.json').write_text(json.dumps(inventory, indent=2) + '\n')

for role in ('baseline', 'control', 'probe'):
    overlay = [] if role == 'baseline' else ['-overlay=' + str(out / (role + '-overlay.json'))]
    run(role + '-whole-oracles', [go, 'test', '-pgo=off', *overlay, './rt', './internal/gen/gogen', './examples/datadog/go/dd/...', './testdata/compute/go/compute/...', './testdata/streaming/go/streaming/...', '-count=1'])
    run(role + '-compile', [go, 'test', '-pgo=off', '-c', *overlay, '-o', out / (role + '.test'), './examples/datadog/go/dd'])
    run(role + '-runtime-compile', [go, 'test', '-pgo=off', '-c', *overlay, '-o', out / ('runtime-' + role + '.test'), './rt'])
    run(role + '-stream-compile', [go, 'test', '-pgo=off', '-c', *overlay, '-o', out / ('stream-' + role + '.test'), './testdata/streaming/go/streaming'])
records.append({'binaries_sha256': {name: sha(out / (name + '.test')) for name in ('baseline', 'control', 'probe', 'runtime-baseline', 'runtime-control', 'runtime-probe', 'stream-baseline', 'stream-control', 'stream-probe')}})
(out / 'variant-build-records.json').write_text(json.dumps(records, indent=2) + '\n')
print('PASS all authored diagnostic controls/oracles/builds; production unchanged', flush=True)
