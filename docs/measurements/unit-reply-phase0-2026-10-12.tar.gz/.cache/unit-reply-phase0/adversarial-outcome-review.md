# Unit-reply phase-0 outcome audit

Read-only result audit after all timings finished. This reviewer ran no benchmark, profile, build, test, lint, or tracked mutation. Independent data inspection verified the complete plan, raw outputs, source/artifact fingerprints, aliases, medians and reported comparison tables.

## Verdict

NO-GO under the frozen promotion rule. Retain measurement evidence only; do not create/implement a private production pass/specification or new public ABI from this result. The untouched default scalar comparison lacks a detected gain in either round, and repeated SQL losses independently violate the guard. No M1 acceptance, scalar latency claim, check weakening, selective retiming or code-placement rescue follows.

Original SketchAdd is87.41→87.03ns (−0.4347%, p=.456) and88.38→88.59ns (+0.2376%, p=1.000). Probe beats the old ResultUnit call-shape control by1.72%/1.05% (p=.024/.026), but that control itself regresses1.30% versus untouched in both rounds (p=.001/.017). The two-control rule therefore prevents relabeling recovery from an introduced call-shape regression as an improvement to the existing facade. Varied scalar does improve against untouched in both rounds (−1.1775%/−1.1284%, p=.001/.026); preserve that positive result and avoid saying every facade scalar comparison has no benefit.

Varied SQL regresses2.2770%/3.3149% against untouched (p=.001/.003). Its control comparison is+0.6613%, p=.176 then+2.0371%, p=.026: single-round detected loss, not a repeated control loss. Independent SQL holdout regresses2.1751%/2.5319% versus untouched (p=.024/.026) and2.1191%/1.4234% versus control (p=.001/.038). These are repeated negative results, not assumed noise. Ordinary SQL median is unchanged/slightly lower with no detected probe-versus-untouched difference; that cannot excuse the held-out/varied regression. SQL guest/method and ResultView source remain unchanged, so this is an observed linked-binary regression; no particular text layout or cache mechanism has been causally established.

The synthetic direct ReplyUnit component improves8.600→6.990ns and8.684→7.051ns (−18.7209%/−18.8047%, p=.001 both). It omits admission, ownership, guest execution and the full checked boundary, so it is not an18.8% scalar gain nor a removable/additive layer budget. RawGuest improves~.49% in screening (p=.003) but confirmation is undetected (p=.620); it bypasses reply work, so even a repeated difference would require linking/control interpretation. The trace call-shape control repeats regression versus untouched (~3.57%/~1.95%, p=.007/.001), while probe's untouched trace results are undetected. Probe-versus-control trace improvements thus do not establish untouched trace benefit.

Other guards remain contextual: negative-bin scalar and increasing P1 gain in screening but do not repeat against untouched; broad scalar medians rise~.60%/~.28% without detection. Original/matched batch leaves show no repeatable gain or detected probe loss. Screening one-home held-out streaming loses1.4068% against control (p=.002), with untouched p=.710; confirmation control loss does not repeat. The16-home holdout beats control in screening but confirmation is undetected. Confirmation16-home fixed rises4.8896% versus untouched and5.6698% versus control with p=.535/.805; preserve those upward medians and dispersion rather than claiming equivalence. Other confirmation streams are also undetected, including one-home holdout+1.0527% versus untouched. These P16 complete-stream rates do not cover P1/default-stream behavior.

## Completeness and conditions

Independently verified all924 unique raw process outputs, exact anchored selectors/role binary paths/durations/cpu16 arguments, PASS/exit0, every metrics field, seven distinct samples for all role/group/round cells, raw→summary median/delta calculations, and metric-preserving derived aliases. Count is18groups×66processes/pass×14passes. Processor coverage matches the reviewed plan:280 explicit measured-P1 rows,168 explicit measured-P16 streaming rows,476 unchanged framework-P16 rows without leaf metrics. All430 frozen fingerprints match current files and the warm-run frozen copy exactly matches the original snapshot. No raw sample was excluded or reconstructed.

All roles share the official local Go1.26.8 toolchain, CGO0, amd64/v1 and recorded PGO-off. Historical74af... versus freshc73d... relocation is not a timing comparison. Powersave governor, boost1 and affinity0..15 are retained; changing observed frequencies are recorded rather than represented as fixed. Local tools were stopped during the run by root; unrelated external activity cannot be proven absent by this audit. Full gates and repeat proof builds are now sequential post-timing work; their final success must be recorded separately before evidence retention. This note makes no uncompleted gate claim.

The p-values are exploratory/unadjusted with seven samples; nondetection is not equivalence. The decisions use the preregistered two-control/two-round original-scalar condition and same-comparator repeated guard rejection. ReferenceABI2/error/ownership/context/topology/corpus differences remain context, not an interchangeable host-boundary control. Source semantics were separately reviewed: single reply Memory capture, original descriptor/limit/range/status order and independent post-memory check, no public contract or tracked runtime/generator/proof artifact change.

## Complete primary/secondary time comparison inventory

Every row below preserves both rounds; p-values are from the recorded untouched→probe and control→probe benchstat outputs. These are latency deltas (positive means slower), not throughput percentages.

| Workload | Screen baseline→probe ns/op; vs untouched / control | Confirmation baseline→probe ns/op; vs untouched / control |
| --- | --- | --- |
| Original-ObfuscateSQL | 2138→2138; +0.0000% p=0.618 / -1.8816% p=0.006 | 2168→2153; -0.6919% p=0.535 / -2.0473% p=0.318 |
| Original-SketchAdd | 87.41→87.03; -0.4347% p=0.456 / -1.7165% p=0.024 | 88.38→88.59; +0.2376% p=1.000 / -1.0499% p=0.026 |
| Original-SketchAddMany1k | 37976→37854; -0.3213% p=0.902 / -0.3973% p=1.000 | 38132→38276; +0.3776% p=0.209 / -0.0183% p=0.620 |
| Original-ObfuscateTraces1k | 2.56762e+06→2.58494e+06; +0.6745% p=1.000 / -2.7921% p=0.001 | 2.62979e+06→2.61711e+06; -0.4820% p=1.000 / -2.3815% p=0.001 |
| Original-SketchAddVaried | 88.32→87.28; -1.1775% p=0.001 / -2.3604% p=0.001 | 89.51→88.5; -1.1284% p=0.026 / -2.0042% p=0.001 |
| Original-ObfuscateSQLVaried | 2679→2740; +2.2770% p=0.001 / +0.6613% p=0.176 | 2715→2805; +3.3149% p=0.003 / +2.0371% p=0.026 |
| Original-SketchAddNegativeBins | 88.2→87.4; -0.9070% p=0.001 / -2.0948% p=0.001 | 88.88→88.07; -0.9113% p=0.128 / -2.4479% p=0.026 |
| MatchedReference-SQLHoldout | 5471→5590; +2.1751% p=0.024 / +2.1191% p=0.001 | 5490→5629; +2.5319% p=0.026 / +1.4234% p=0.038 |
| MatchedReference-Increasing | 89.3→88.58; -0.8063% p=0.017 / -1.7960% p=0.026 | 89.41→89.6; +0.2125% p=0.710 / -1.0819% p=0.001 |
| MatchedReference-BroadScalar | 88.7→89.23; +0.5975% p=0.259 / -0.7011% p=0.012 | 89.38→89.63; +0.2797% p=0.456 / -0.9285% p=0.073 |
| MatchedReference-Repeated1024 | 38930→39007; +0.1978% p=0.535 / +0.1361% p=0.119 | 39230→39265; +0.0892% p=1.000 / +0.2886% p=0.786 |
| MatchedReference-BroadBatch8192 | 312642→312108; -0.1708% p=0.053 / -0.2477% p=0.073 | 314238→313712; -0.1674% p=0.383 / -0.2848% p=0.535 |
| RawGuest-SketchAdd | 53→52.74; -0.4906% p=0.003 / -0.8460% p=0.001 | 53.3→53.2; -0.1876% p=0.620 / -0.7648% p=0.165 |
| StreamOneHome-Fixed | 189165→188216; -0.5017% p=0.068 / +0.1447% p=0.332 | 193869→193982; +0.0583% p=1.000 / -0.2535% p=1.000 |
| Stream16Homes-Fixed | 24077→23991; -0.3572% p=0.209 / +0.0167% p=0.710 | 27630→28981; +4.8896% p=0.535 / +5.6698% p=0.805 |
| StreamOneHome-Holdout | 227851→228136; +0.1251% p=0.710 / +1.4068% p=0.002 | 232545→234993; +1.0527% p=0.318 / -0.1275% p=0.710 |
| Stream16Homes-Holdout | 32383→31400; -3.0355% p=0.001 / -2.3267% p=0.001 | 36341→34380; -5.3961% p=0.535 / -4.5159% p=0.620 |
| Runtime-ReplyUnit | 8.6→6.99; -18.7209% p=0.001 / -18.5789% p=0.001 | 8.684→7.051; -18.8047% p=0.001 / -18.6548% p=0.001 |

## Audited identities

```json
{
  ".cache/unit-reply-phase0/warm-run/records.jsonl": "2277983de3cfa1b981eccb044ddcf20fa06c290c529c38b9fa20bf1822de4719",
  ".cache/unit-reply-phase0/warm-run/summary.json": "d311cbf1842305ab1b16ad6de0bf89f3e10f9232317234396aa4ed58d6424737",
  ".cache/unit-reply-phase0/warm-run/complete.json": "3fca3e300f1f7546bd251d27e4836b510a0105bd2851537704240d5e7cb74b04",
  ".cache/unit-reply-phase0/warm-run/run-provenance.json": "65f5396ffb31d830664d38fd4d053800a17d0645b832fdba3c11df9f4cbfa849",
  ".cache/unit-reply-phase0/warm-run/frozen.json": "2b886134aae617b317db905d497c16ead3b8e9ce7cd571cc71f81da4f31a473b",
  ".cache/unit-reply-phase0/decision-plan.json": "eafda1565b8beff40b0f3514c4a1cbe911b5a0ce2dc80b79e7f8b8296fc7d49b",
  ".cache/unit-reply-phase0/machine-code-summary.json": "b6f219b9bd7ee96356f2e4b7472348c32add01ebc111d4e0d5894a800ea2133a"
}
```
