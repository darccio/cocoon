TEXT dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).Xcocoon_sketch_add(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/internal/wasm/module.go
  module.go:48457	0x656960		493b6610		CMPQ SP, 0x10(R14)										
  module.go:48457	0x656964		0f86880b0000		JBE 0x6574f2											
  module.go:48457	0x65696a		55			PUSHQ BP											
  module.go:48457	0x65696b		4889e5			MOVQ SP, BP											
  module.go:48457	0x65696e		4883ec70		SUBQ $0x70, SP											
  module.go:48460	0x656972		8b5050			MOVL 0x50(AX), DX										
  module.go:48461	0x656975		448d42f0		LEAL -0x10(DX), R8										
  module.go:48462	0x656979		44894050		MOVL R8, 0x50(AX)										
  module.go:48463	0x65697d		4c8b4838		MOVQ 0x38(AX), R9										
  module.go:48463	0x656981		4981f9b0cf1000		CMPQ R9, $0x10cfb0										
  module.go:48463	0x656988		0f86570b0000		JBE 0x6574e5											
  module.go:48463	0x65698e		4889842480000000	MOVQ AX, 0x80(SP)										
  module.go:48463	0x656996		f20f11842490000000	MOVSD_XMM X0, 0x90(SP)										
  module.go:48460	0x65699f		8954242c		MOVL DX, 0x2c(SP)										
  module.go:48461	0x6569a3		4489442420		MOVL R8, 0x20(SP)										
  module.go:48463	0x6569a8		4c8b4830		MOVQ 0x30(AX), R9										
  module.go:48463	0x6569ac		450fb689b0cf1000	MOVZX 0x10cfb0(R9), R9										
  module.go:48464	0x6569b4		4183f901		CMPL R9, $0x1											
  module.go:48464	0x6569b8		742f			JE 0x6569e9											
  module.go:48463	0x6569ba		48899c2488000000	MOVQ BX, 0x88(SP)										
  module.go:48465	0x6569c2		e8d9f6f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn41(SB)			
  module.go:48468	0x6569c7		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48620	0x6569cf		8b54242c		MOVL 0x2c(SP), DX										
  module.go:48473	0x6569d3		488b9c2488000000	MOVQ 0x88(SP), BX										
  module.go:48474	0x6569db		448b442420		MOVL 0x20(SP), R8										
  unsafe.go:35		0x6569e0		f20f10842490000000	MOVSD_XMM 0x90(SP), X0										
  module.go:48468	0x6569e9		4c8b4838		MOVQ 0x38(AX), R9										
  module.go:62983	0x6569ed		4981f973ce1000		CMPQ R9, $0x10ce73										
  module.go:62983	0x6569f4		0f86de0a0000		JBE 0x6574d8											
  module.go:48468	0x6569fa		4c8b4830		MOVQ 0x30(AX), R9										
  module.go:62984	0x6569fe		4183b970ce100000	CMPL 0x10ce70(R9), $0x0										
  module.go:48469	0x656a06		0f85aa0a0000		JNE 0x6574b6											
  module.go:48470	0x656a0c		90			NOPL												
  module.go:63001	0x656a0d		41c78170ce1000ffffffff	MOVL $-0x1, 0x10ce70(R9)									
  module.go:48471	0x656a18		4c8b4838		MOVQ 0x38(AX), R9										
  module.go:48471	0x656a1c		0f1f4000		NOPL 0(AX)											
  module.go:62983	0x656a20		4981f97fce1000		CMPQ R9, $0x10ce7f										
  module.go:62983	0x656a27		0f867d0a0000		JBE 0x6574aa											
  module.go:48472	0x656a2d		90			NOPL												
  module.go:62983	0x656a2e		4981f983ce1000		CMPQ R9, $0x10ce83										
  module.go:62983	0x656a35		0f86630a0000		JBE 0x65749e											
  module.go:48471	0x656a3b		488b5030		MOVQ 0x30(AX), DX										
  module.go:48474	0x656a3f		4589c1			MOVL R8, R9											
  module.go:48474	0x656a42		4c894c2468		MOVQ R9, 0x68(SP)										
  module.go:62984	0x656a47		8b8a7cce1000		MOVL 0x10ce7c(DX), CX										
  module.go:62984	0x656a4d		8bba80ce1000		MOVL 0x10ce80(DX), DI										
  module.go:48473	0x656a53		4889de			MOVQ BX, SI											
  module.go:48473	0x656a56		4489c3			MOVL R8, BX											
  module.go:48473	0x656a59		e822d0f8ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn84(SB)			
  module.go:48474	0x656a5e		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48474	0x656a66		488b5038		MOVQ 0x38(AX), DX										
  module.go:62983	0x656a6a		4c8b442468		MOVQ 0x68(SP), R8										
  module.go:62983	0x656a6f		4d8d4807		LEAQ 0x7(R8), R9										
  module.go:62983	0x656a73		4c39ca			CMPQ DX, R9											
  module.go:62983	0x656a76		0f861d0a0000		JBE 0x657499											
  module.go:48474	0x656a7c		488b7030		MOVQ 0x30(AX), SI										
  module.go:62983	0x656a80		498d7803		LEAQ 0x3(R8), DI										
  module.go:48481	0x656a84		90			NOPL												
  module.go:62984	0x656a85		418b4c3004		MOVL 0x4(R8)(SI*1), CX										
  module.go:62983	0x656a8a		4839fa			CMPQ DX, DI											
  module.go:62983	0x656a8d		0f86010a0000		JBE 0x657494											
  module.go:62984	0x656a93		8b5c2420		MOVL 0x20(SP), BX										
  module.go:62984	0x656a97		4189da			MOVL BX, R10											
  module.go:62984	0x656a9a		458b1c32		MOVL 0(R10)(SI*1), R11										
  module.go:62984	0x656a9e		6690			NOPW												
  module.go:48483	0x656aa0		4183fbff		CMPL R11, $-0x1											
  module.go:48483	0x656aa4		7418			JE 0x656abe											
  module.go:63009	0x656aa6		4d8d600f		LEAQ 0xf(R8), R12										
  module.go:48484	0x656aaa		90			NOPL												
  module.go:63009	0x656aab		4c39e2			CMPQ DX, R12											
  module.go:63009	0x656aae		0f86db090000		JBE 0x65748f											
  module.go:63010	0x656ab4		498b543008		MOVQ 0x8(R8)(SI*1), DX										
  module.go:48486	0x656ab9		e926070000		JMP 0x6571e4											
  module.go:62983	0x656abe		4c894c2460		MOVQ R9, 0x60(SP)										
  module.go:62983	0x656ac3		48897c2458		MOVQ DI, 0x58(SP)										
  module.go:62984	0x656ac8		4c89542450		MOVQ R10, 0x50(SP)										
  module.go:48488	0x656acd		8b5050			MOVL 0x50(AX), DX										
  module.go:48488	0x656ad0		89542428		MOVL DX, 0x28(SP)										
  module.go:48489	0x656ad4		8d72c0			LEAL -0x40(DX), SI										
  module.go:48490	0x656ad7		897050			MOVL SI, 0x50(AX)										
  unsafe.go:35		0x656ada		f20f10842490000000	MOVSD_XMM 0x90(SP), X0										
  unsafe.go:35		0x656ae3		66490f7ec3		MOVQ X0, R11											
  module.go:48493	0x656ae8		4d89dc			MOVQ R11, R12											
  module.go:48493	0x656aeb		490fbaf33f		BTRQ $0x3f, R11											
  module.go:48499	0x656af0		4d8d6c24ff		LEAQ -0x1(R12), R13										
  module.go:48504	0x656af5		49bf000000000000f0ff	MOVQ $0xfff0000000000000, R15									
  module.go:48504	0x656aff		4d01df			ADDQ R11, R15											
  module.go:48492	0x656b02		90			NOPL												
  module.go:48495	0x656b03		4d85db			TESTQ R11, R11											
  module.go:48495	0x656b06		410f94c3		SETE R11											
  module.go:48498	0x656b0a		450fb6db		MOVZX R11, R11											
  module.go:48499	0x656b0e		49b8ffffffffffff0f00	MOVQ $0xfffffffffffff, R8									
  module.go:48499	0x656b18		4d39e8			CMPQ R8, R13											
  module.go:48499	0x656b1b		410f97c0		SETA R8												
  module.go:48502	0x656b1f		450fb6c0		MOVZX R8, R8											
  module.go:48502	0x656b23		4509c3			ORL R8, R11											
  module.go:48504	0x656b26		49b8000000000000e07f	MOVQ $0x7fe0000000000000, R8									
  module.go:48504	0x656b30		4d39f8			CMPQ R8, R15											
  module.go:48504	0x656b33		410f97c0		SETA R8												
  module.go:48507	0x656b37		450fb6c0		MOVZX R8, R8											
  module.go:48508	0x656b3b		4d85e4			TESTQ R12, R12											
  module.go:48508	0x656b3e		410f9dc4		SETGE R12											
  module.go:48511	0x656b42		450fb6e4		MOVZX R12, R12											
  module.go:48511	0x656b46		4521e0			ANDL R12, R8											
  module.go:48511	0x656b49		4509d8			ORL R11, R8											
  module.go:48511	0x656b4c		4585c0			TESTL R8, R8											
  module.go:48511	0x656b4f		0f8493030000		JE 0x656ee8											
  module.go:48489	0x656b55		89742424		MOVL SI, 0x24(SP)										
  module.go:48535	0x656b59		8d5ac8			LEAL -0x38(DX), BX										
  module.go:48535	0x656b5c		0f1f4000		NOPL 0(AX)											
  module.go:48535	0x656b60		e89b96fdff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn176(SB)			
  module.go:48536	0x656b65		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48536	0x656b6d		488b5038		MOVQ 0x38(AX), DX										
  module.go:48536	0x656b71		8b742424		MOVL 0x24(SP), SI										
  module.go:48536	0x656b75		89f6			MOVL SI, SI											
  module.go:62983	0x656b77		488d7e0b		LEAQ 0xb(SI), DI										
  module.go:62983	0x656b7b		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:62983	0x656b80		4839fa			CMPQ DX, DI											
  module.go:62983	0x656b83		0f8601090000		JBE 0x65748a											
  module.go:48536	0x656b89		488b7830		MOVQ 0x30(AX), DI										
  module.go:62984	0x656b8d		448b443e08		MOVL 0x8(SI)(DI*1), R8										
  module.go:48538	0x656b92		4585c0			TESTL R8, R8											
  module.go:48538	0x656b95		7536			JNE 0x656bcd											
  module.go:48574	0x656b97		90			NOPL												
  module.go:63000	0x656b98		488b4c2458		MOVQ 0x58(SP), CX										
  module.go:63000	0x656b9d		0f1f00			NOPL 0(AX)											
  module.go:63000	0x656ba0		4839ca			CMPQ DX, CX											
  module.go:63000	0x656ba3		0f86dc080000		JBE 0x657485											
  module.go:63001	0x656ba9		488b542450		MOVQ 0x50(SP), DX										
  module.go:63001	0x656bae		c70417ffffffff		MOVL $-0x1, 0(DI)(DX*1)										
  module.go:63009	0x656bb5		488b742468		MOVQ 0x68(SP), SI										
  module.go:62983	0x656bba		488b7c2460		MOVQ 0x60(SP), DI										
  module.go:62983	0x656bbf		4989c8			MOVQ CX, R8											
  module.go:62984	0x656bc2		4989d1			MOVQ DX, R9											
  module.go:48577	0x656bc5		4889c1			MOVQ AX, CX											
  module.go:48577	0x656bc8		e9cf040000		JMP 0x65709c											
  module.go:62983	0x656bcd		4c8d4e0f		LEAQ 0xf(SI), R9										
  module.go:48539	0x656bd1		90			NOPL												
  module.go:62983	0x656bd2		4c39ca			CMPQ DX, R9											
  module.go:62983	0x656bd5		0f86a3080000		JBE 0x65747e											
  module.go:63000	0x656bdb		4c8d4e2b		LEAQ 0x2b(SI), R9										
  module.go:48541	0x656bdf		90			NOPL												
  module.go:62984	0x656be0		448b543e0c		MOVL 0xc(SI)(DI*1), R10										
  module.go:63000	0x656be5		4c39ca			CMPQ DX, R9											
  module.go:63000	0x656be8		0f868b080000		JBE 0x657479											
  module.go:63001	0x656bee		c7443e2800000000	MOVL $0x0, 0x28(SI)(DI*1)									
  module.go:48542	0x656bf6		488b7838		MOVQ 0x38(AX), DI										
  module.go:63026	0x656bfa		4c8d5e27		LEAQ 0x27(SI), R11										
  module.go:63026	0x656bfe		6690			NOPW												
  module.go:63026	0x656c00		4c39df			CMPQ DI, R11											
  module.go:63026	0x656c03		0f866b080000		JBE 0x657474											
  module.go:48542	0x656c09		488b7830		MOVQ 0x30(AX), DI										
  module.go:63027	0x656c0d		49bc0000000001000000	MOVQ $0x100000000, R12										
  module.go:63027	0x656c17		4c89643e20		MOVQ R12, 0x20(SI)(DI*1)									
  module.go:48543	0x656c1c		488b7838		MOVQ 0x38(AX), DI										
  module.go:63000	0x656c20		4c8d6633		LEAQ 0x33(SI), R12										
  module.go:63000	0x656c24		4c39e7			CMPQ DI, R12											
  module.go:63000	0x656c27		0f8642080000		JBE 0x65746f											
  module.go:48543	0x656c2d		488b7830		MOVQ 0x30(AX), DI										
  module.go:63001	0x656c31		c7443e30c81a1000	MOVL $0x101ac8, 0x30(SI)(DI*1)									
  module.go:48544	0x656c39		488b7838		MOVQ 0x38(AX), DI										
  module.go:63026	0x656c3d		4c8d663b		LEAQ 0x3b(SI), R12										
  module.go:63026	0x656c41		4c39e7			CMPQ DI, R12											
  module.go:63026	0x656c44		0f8620080000		JBE 0x65746a											
  module.go:48544	0x656c4a		488b7830		MOVQ 0x30(AX), DI										
  module.go:63027	0x656c4e		48c7443e3420000060	MOVQ $0x60000020, 0x34(SI)(DI*1)								
  module.go:48545	0x656c57		488b7838		MOVQ 0x38(AX), DI										
  module.go:63000	0x656c5b		4c8d662f		LEAQ 0x2f(SI), R12										
  module.go:63000	0x656c5f		90			NOPL												
  module.go:63000	0x656c60		4c39e7			CMPQ DI, R12											
  module.go:63000	0x656c63		0f86fc070000		JBE 0x657465											
  module.go:48545	0x656c69		488b7830		MOVQ 0x30(AX), DI										
  module.go:48545	0x656c6d		8b5c2428		MOVL 0x28(SP), BX										
  module.go:48545	0x656c71		448d63e0		LEAL -0x20(BX), R12										
  module.go:63001	0x656c75		4489643e2c		MOVL R12, 0x2c(SI)(DI*1)									
  module.go:48546	0x656c7a		488b7838		MOVQ 0x38(AX), DI										
  module.go:62983	0x656c7e		4d8d6213		LEAQ 0x13(R10), R12										
  module.go:62983	0x656c82		4c39e7			CMPQ DI, R12											
  module.go:62983	0x656c85		0f86d3070000		JBE 0x65745e											
  module.go:48546	0x656c8b		488b7830		MOVQ 0x30(AX), DI										
  module.go:62984	0x656c8f		498d3c3a		LEAQ 0(R10)(DI*1), DI										
  module.go:62984	0x656c93		488d7f10		LEAQ 0x10(DI), DI										
  module.go:62984	0x656c97		48633f			MOVSXD 0(DI), DI										
  module.go:62984	0x656c9a		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:63164	0x656ca0		48397808		CMPQ 0x8(AX), DI										
  module.go:63164	0x656ca4		0f86a1070000		JBE 0x65744b											
  module.go:48547	0x656caa		48c1e704		SHLQ $0x4, DI											
  module.go:48547	0x656cae		4c8b20			MOVQ 0(AX), R12											
  module.go:48547	0x656cb1		4e8b2c27		MOVQ 0(DI)(R12*1), R13										
  module.go:48547	0x656cb5		4a8b542708		MOVQ 0x8(DI)(R12*1), DX										
  module.go:48547	0x656cba		488d3d9f4a2000		LEAQ 0x204a9f(IP), DI										
  module.go:48547	0x656cc1		4939fd			CMPQ R13, DI											
  module.go:48547	0x656cc4		0f856f070000		JNE 0x657439											
  module.go:48536	0x656cca		4889742448		MOVQ SI, 0x48(SP)										
  module.go:62984	0x656ccf		4489442434		MOVL R8, 0x34(SP)										
  module.go:62984	0x656cd4		4489542430		MOVL R10, 0x30(SP)										
  module.go:63000	0x656cd9		4c894c2440		MOVQ R9, 0x40(SP)										
  module.go:63026	0x656cde		4c895c2438		MOVQ R11, 0x38(SP)										
  module.go:48547	0x656ce3		488b0a			MOVQ 0(DX), CX											
  module.go:48547	0x656ce6		83c3ec			ADDL $-0x14, BX											
  module.go:48547	0x656ce9		4489c0			MOVL R8, AX											
  module.go:48547	0x656cec		ffd1			CALL CX												
  module.go:48548	0x656cee		85c0			TESTL AX, AX											
  module.go:48548	0x656cf0		0f8508070000		JNE 0x6573fe											
  module.go:48552	0x656cf6		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48552	0x656cfe		488b7038		MOVQ 0x38(AX), SI										
  module.go:62983	0x656d02		488b7c2440		MOVQ 0x40(SP), DI										
  module.go:62983	0x656d07		4839fe			CMPQ SI, DI											
  module.go:62983	0x656d0a		0f86e9060000		JBE 0x6573f9											
  module.go:48552	0x656d10		488b7830		MOVQ 0x30(AX), DI										
  module.go:63000	0x656d14		4c8b442448		MOVQ 0x48(SP), R8										
  module.go:63000	0x656d19		4d8d481b		LEAQ 0x1b(R8), R9										
  module.go:48553	0x656d1d		90			NOPL												
  module.go:62984	0x656d1e		458b543828		MOVL 0x28(R8)(DI*1), R10									
  module.go:63000	0x656d23		4c39ce			CMPQ SI, R9											
  module.go:63000	0x656d26		0f86c8060000		JBE 0x6573f4											
  module.go:63001	0x656d2c		4589543818		MOVL R10, 0x18(R8)(DI*1)									
  module.go:48554	0x656d31		488b7038		MOVQ 0x38(AX), SI										
  module.go:63009	0x656d35		488b7c2438		MOVQ 0x38(SP), DI										
  module.go:63009	0x656d3a		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:63009	0x656d40		4839fe			CMPQ SI, DI											
  module.go:63009	0x656d43		0f86a6060000		JBE 0x6573ef											
  module.go:48554	0x656d49		488b7830		MOVQ 0x30(AX), DI										
  module.go:63026	0x656d4d		4d8d5017		LEAQ 0x17(R8), R10										
  module.go:48555	0x656d51		90			NOPL												
  module.go:63010	0x656d52		4d8b5c3820		MOVQ 0x20(R8)(DI*1), R11									
  module.go:63010	0x656d57		660f1f840000000000	NOPW 0(AX)(AX*1)										
  module.go:63026	0x656d60		4c39d6			CMPQ SI, R10											
  module.go:63026	0x656d63		0f8681060000		JBE 0x6573ea											
  module.go:63027	0x656d69		4d895c3810		MOVQ R11, 0x10(R8)(DI*1)									
  module.go:48556	0x656d6e		488b7038		MOVQ 0x38(AX), SI										
  module.go:62983	0x656d72		8b7c2430		MOVL 0x30(SP), DI										
  module.go:62983	0x656d76		4c8d5f03		LEAQ 0x3(DI), R11										
  module.go:62983	0x656d7a		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:62983	0x656d80		4c39de			CMPQ SI, R11											
  module.go:62983	0x656d83		0f865c060000		JBE 0x6573e5											
  module.go:63000	0x656d89		4c894c2440		MOVQ R9, 0x40(SP)										
  module.go:63026	0x656d8e		4c89542438		MOVQ R10, 0x38(SP)										
  module.go:48556	0x656d93		488b7030		MOVQ 0x30(AX), SI										
  module.go:62984	0x656d97		8b3437			MOVL 0(DI)(SI*1), SI										
  module.go:48558	0x656d9a		85f6			TESTL SI, SI											
  module.go:48558	0x656d9c		7451			JE 0x656def											
  module.go:48559	0x656d9e		4863f6			MOVSXD SI, SI											
  module.go:63164	0x656da1		48397008		CMPQ 0x8(AX), SI										
  module.go:63164	0x656da5		0f8622060000		JBE 0x6573cd											
  module.go:48559	0x656dab		48c1e604		SHLQ $0x4, SI											
  module.go:48559	0x656daf		4c8b18			MOVQ 0(AX), R11											
  module.go:48559	0x656db2		4e8b241e		MOVQ 0(SI)(R11*1), R12										
  module.go:48559	0x656db6		4a8b541e08		MOVQ 0x8(SI)(R11*1), DX										
  module.go:48559	0x656dbb		488d1d1e5b1f00		LEAQ 0x1f5b1e(IP), BX										
  module.go:48559	0x656dc2		4939dc			CMPQ R12, BX											
  module.go:48559	0x656dc5		0f85f3050000		JNE 0x6573be											
  module.go:48559	0x656dcb		488b0a			MOVQ 0(DX), CX											
  module.go:48559	0x656dce		8b442434		MOVL 0x34(SP), AX										
  module.go:48559	0x656dd2		ffd1			CALL CX												
  module.go:48561	0x656dd4		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:62983	0x656ddc		8b7c2430		MOVL 0x30(SP), DI										
  module.go:62984	0x656de0		4c8b442448		MOVQ 0x48(SP), R8										
  module.go:62983	0x656de5		4c8b4c2440		MOVQ 0x40(SP), R9										
  module.go:63009	0x656dea		4c8b542438		MOVQ 0x38(SP), R10										
  module.go:48561	0x656def		488b5038		MOVQ 0x38(AX), DX										
  module.go:62983	0x656df3		488d7707		LEAQ 0x7(DI), SI										
  module.go:62983	0x656df7		660f1f840000000000	NOPW 0(AX)(AX*1)										
  module.go:62983	0x656e00		4839f2			CMPQ DX, SI											
  module.go:62983	0x656e03		0f86b0050000		JBE 0x6573b9											
  module.go:48561	0x656e09		488b7030		MOVQ 0x30(AX), SI										
  module.go:62984	0x656e0d		8b4c3704		MOVL 0x4(DI)(SI*1), CX										
  module.go:48563	0x656e11		85c9			TESTL CX, CX											
  module.go:48563	0x656e13		7434			JE 0x656e49											
  module.go:62983	0x656e15		488d770b		LEAQ 0xb(DI), SI										
  module.go:48564	0x656e19		90			NOPL												
  module.go:48564	0x656e1a		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:62983	0x656e20		4839f2			CMPQ DX, SI											
  module.go:62983	0x656e23		0f868b050000		JBE 0x6573b4											
  module.go:48565	0x656e29		8b5c2434		MOVL 0x34(SP), BX										
  module.go:48565	0x656e2d		e88e54f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn1(SB)			
  module.go:48567	0x656e32		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:62984	0x656e3a		4c8b442448		MOVQ 0x48(SP), R8										
  module.go:62983	0x656e3f		4c8b4c2440		MOVQ 0x40(SP), R9										
  module.go:63009	0x656e44		4c8b542438		MOVQ 0x38(SP), R10										
  module.go:48567	0x656e49		488b4838		MOVQ 0x38(AX), CX										
  module.go:62983	0x656e4d		4c39c9			CMPQ CX, R9											
  module.go:62983	0x656e50		0f8659050000		JBE 0x6573af											
  module.go:48567	0x656e56		488b5030		MOVQ 0x30(AX), DX										
  module.go:63000	0x656e5a		488b742468		MOVQ 0x68(SP), SI										
  module.go:63000	0x656e5f		488d7e0b		LEAQ 0xb(SI), DI										
  module.go:48568	0x656e63		90			NOPL												
  module.go:62984	0x656e64		458b4c1018		MOVL 0x18(R8)(DX*1), R9										
  module.go:63000	0x656e69		4839f9			CMPQ CX, DI											
  module.go:63000	0x656e6c		0f8638050000		JBE 0x6573aa											
  module.go:63001	0x656e72		44894c1608		MOVL R9, 0x8(SI)(DX*1)										
  module.go:48569	0x656e77		488b4838		MOVQ 0x38(AX), CX										
  module.go:48569	0x656e7b		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:63009	0x656e80		4c39d1			CMPQ CX, R10											
  module.go:63009	0x656e83		0f861c050000		JBE 0x6573a5											
  module.go:48569	0x656e89		488b5030		MOVQ 0x30(AX), DX										
  module.go:48570	0x656e8d		90			NOPL												
  module.go:63010	0x656e8e		498b7c1010		MOVQ 0x10(R8)(DX*1), DI										
  module.go:63026	0x656e93		4c8b442460		MOVQ 0x60(SP), R8										
  module.go:63026	0x656e98		0f1f840000000000	NOPL 0(AX)(AX*1)										
  module.go:63026	0x656ea0		4c39c1			CMPQ CX, R8											
  module.go:63026	0x656ea3		0f86f5040000		JBE 0x65739e											
  module.go:63027	0x656ea9		488b4c2450		MOVQ 0x50(SP), CX										
  module.go:63027	0x656eae		48893c0a		MOVQ DI, 0(DX)(CX*1)										
  module.go:48571	0x656eb2		488b5038		MOVQ 0x38(AX), DX										
  module.go:63000	0x656eb6		488d7e0f		LEAQ 0xf(SI), DI										
  module.go:63000	0x656eba		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:63000	0x656ec0		4839fa			CMPQ DX, DI											
  module.go:63000	0x656ec3		0f86d0040000		JBE 0x657399											
  module.go:48571	0x656ec9		488b5030		MOVQ 0x30(AX), DX										
  module.go:63001	0x656ecd		c744160c01000000	MOVL $0x1, 0xc(SI)(DX*1)									
  module.go:62983	0x656ed5		4c89c7			MOVQ R8, DI											
  module.go:62983	0x656ed8		4c8b442458		MOVQ 0x58(SP), R8										
  module.go:62984	0x656edd		4989c9			MOVQ CX, R9											
  module.go:48577	0x656ee0		4889c1			MOVQ AX, CX											
  module.go:48572	0x656ee3		e9b4010000		JMP 0x65709c											
  module.go:48512	0x656ee8		bb2c000000		MOVL $0x2c, BX											
  module.go:48512	0x656eed		b901000000		MOVL $0x1, CX											
  module.go:48512	0x656ef2		e84957f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn4(SB)			
  module.go:48514	0x656ef7		85c0			TESTL AX, AX											
  module.go:48514	0x656ef9		0f8470040000		JE 0x65736f											
  module.go:48518	0x656eff		488b8c2480000000	MOVQ 0x80(SP), CX										
  module.go:48518	0x656f07		488b5138		MOVQ 0x38(CX), DX										
  module.go:63026	0x656f0b		488b742468		MOVQ 0x68(SP), SI										
  module.go:63026	0x656f10		488d7e0f		LEAQ 0xf(SI), DI										
  module.go:63026	0x656f14		4839fa			CMPQ DX, DI											
  module.go:63026	0x656f17		0f864d040000		JBE 0x65736a											
  module.go:48518	0x656f1d		488b5130		MOVQ 0x30(CX), DX										
  module.go:63027	0x656f21		48bf2c00000002000000	MOVQ $0x20000002c, DI										
  module.go:63027	0x656f2b		48897c1608		MOVQ DI, 0x8(SI)(DX*1)										
  module.go:48519	0x656f30		488b5138		MOVQ 0x38(CX), DX										
  module.go:63000	0x656f34		488b7c2460		MOVQ 0x60(SP), DI										
  module.go:63000	0x656f39		0f1f8000000000		NOPL 0(AX)											
  module.go:63000	0x656f40		4839fa			CMPQ DX, DI											
  module.go:63000	0x656f43		0f861c040000		JBE 0x657365											
  module.go:48519	0x656f49		488b5130		MOVQ 0x30(CX), DX										
  module.go:63001	0x656f4d		89441604		MOVL AX, 0x4(SI)(DX*1)										
  module.go:48520	0x656f51		488b5138		MOVQ 0x38(CX), DX										
  module.go:63000	0x656f55		4c8b442458		MOVQ 0x58(SP), R8										
  module.go:63000	0x656f5a		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:63000	0x656f60		4c39c2			CMPQ DX, R8											
  module.go:63000	0x656f63		0f86f3030000		JBE 0x65735c											
  module.go:48520	0x656f69		488b5130		MOVQ 0x30(CX), DX										
  module.go:63001	0x656f6d		4c8b4c2450		MOVQ 0x50(SP), R9										
  module.go:63001	0x656f72		42c7040a2c000000	MOVL $0x2c, 0(DX)(R9*1)										
  module.go:48521	0x656f7a		488b5138		MOVQ 0x38(CX), DX										
  module.go:48521	0x656f7e		6690			NOPW												
  module.go:62983	0x656f80		4881fa9b191000		CMPQ DX, $0x10199b										
  module.go:62983	0x656f87		0f86c3030000		JBE 0x657350											
  module.go:48522	0x656f8d		4189c2			MOVL AX, R10											
  module.go:63000	0x656f90		4d8d5a2b		LEAQ 0x2b(R10), R11										
  module.go:63000	0x656f94		4c39da			CMPQ DX, R11											
  module.go:63000	0x656f97		0f86ae030000		JBE 0x65734b											
  module.go:48521	0x656f9d		488b5130		MOVQ 0x30(CX), DX										
  module.go:62984	0x656fa1		448b9a98191000		MOVL 0x101998(DX), R11										
  module.go:63001	0x656fa8		45895c1228		MOVL R11, 0x28(R10)(DX*1)									
  module.go:48523	0x656fad		488b5138		MOVQ 0x38(CX), DX										
  module.go:63009	0x656fb1		4881fa97191000		CMPQ DX, $0x101997										
  module.go:63009	0x656fb8		0f8681030000		JBE 0x65733f											
  module.go:63026	0x656fbe		4d8d5a27		LEAQ 0x27(R10), R11										
  module.go:48524	0x656fc2		90			NOPL												
  module.go:63026	0x656fc3		4c39da			CMPQ DX, R11											
  module.go:63026	0x656fc6		0f866e030000		JBE 0x65733a											
  module.go:48523	0x656fcc		488b5130		MOVQ 0x30(CX), DX										
  module.go:63010	0x656fd0		4c8b9a90191000		MOVQ 0x101990(DX), R11										
  module.go:63027	0x656fd7		4d895c1220		MOVQ R11, 0x20(R10)(DX*1)									
  module.go:48525	0x656fdc		488b5138		MOVQ 0x38(CX), DX										
  module.go:63009	0x656fe0		4881fa8f191000		CMPQ DX, $0x10198f										
  module.go:63009	0x656fe7		0f8641030000		JBE 0x65732e											
  module.go:63026	0x656fed		4d8d5a1f		LEAQ 0x1f(R10), R11										
  module.go:48526	0x656ff1		90			NOPL												
  module.go:63026	0x656ff2		4c39da			CMPQ DX, R11											
  module.go:63026	0x656ff5		0f862e030000		JBE 0x657329											
  module.go:48525	0x656ffb		488b5130		MOVQ 0x30(CX), DX										
  module.go:63010	0x656fff		4c8b9a88191000		MOVQ 0x101988(DX), R11										
  module.go:63027	0x657006		4d895c1218		MOVQ R11, 0x18(R10)(DX*1)									
  module.go:48527	0x65700b		488b5138		MOVQ 0x38(CX), DX										
  module.go:63009	0x65700f		4881fa87191000		CMPQ DX, $0x101987										
  module.go:63009	0x657016		0f8601030000		JBE 0x65731d											
  module.go:63026	0x65701c		4d8d5a17		LEAQ 0x17(R10), R11										
  module.go:48528	0x657020		90			NOPL												
  module.go:63026	0x657021		4c39da			CMPQ DX, R11											
  module.go:63026	0x657024		0f86ee020000		JBE 0x657318											
  module.go:48527	0x65702a		488b5130		MOVQ 0x30(CX), DX										
  module.go:63010	0x65702e		4c8b9a80191000		MOVQ 0x101980(DX), R11										
  module.go:63027	0x657035		4d895c1210		MOVQ R11, 0x10(R10)(DX*1)									
  module.go:48529	0x65703a		488b5138		MOVQ 0x38(CX), DX										
  module.go:48529	0x65703e		6690			NOPW												
  module.go:63009	0x657040		4881fa7f191000		CMPQ DX, $0x10197f										
  module.go:63009	0x657047		0f86bf020000		JBE 0x65730c											
  module.go:63026	0x65704d		4d8d5a0f		LEAQ 0xf(R10), R11										
  module.go:48530	0x657051		90			NOPL												
  module.go:63026	0x657052		4c39da			CMPQ DX, R11											
  module.go:63026	0x657055		0f86ac020000		JBE 0x657307											
  module.go:48529	0x65705b		488b5130		MOVQ 0x30(CX), DX										
  module.go:63010	0x65705f		4c8b9a78191000		MOVQ 0x101978(DX), R11										
  module.go:63027	0x657066		4d895c1208		MOVQ R11, 0x8(R10)(DX*1)									
  module.go:48531	0x65706b		488b5138		MOVQ 0x38(CX), DX										
  module.go:63009	0x65706f		4881fa77191000		CMPQ DX, $0x101977										
  module.go:63009	0x657076		0f867f020000		JBE 0x6572fb											
  module.go:63026	0x65707c		4983c207		ADDQ $0x7, R10											
  module.go:48532	0x657080		90			NOPL												
  module.go:63026	0x657081		4c39d2			CMPQ DX, R10											
  module.go:63026	0x657084		0f866c020000		JBE 0x6572f6											
  module.go:48531	0x65708a		488b5130		MOVQ 0x30(CX), DX										
  module.go:63010	0x65708e		4c8b9270191000		MOVQ 0x101970(DX), R10										
  module.go:63027	0x657095		4189c3			MOVL AX, R11											
  module.go:63027	0x657098		4e89141a		MOVQ R10, 0(DX)(R11*1)										
  module.go:48577	0x65709c		8b542428		MOVL 0x28(SP), DX										
  module.go:48577	0x6570a0		895150			MOVL DX, 0x50(CX)										
  module.go:48580	0x6570a3		488b5138		MOVQ 0x38(CX), DX										
  module.go:62983	0x6570a7		4c39c2			CMPQ DX, R8											
  module.go:62983	0x6570aa		0f8641020000		JBE 0x6572f1											
  module.go:48580	0x6570b0		4c8b5130		MOVQ 0x30(CX), R10										
  module.go:62984	0x6570b4		478b1c11		MOVL 0(R9)(R10*1), R11										
  module.go:62984	0x6570b8		0f1f840000000000	NOPL 0(AX)(AX*1)										
  module.go:48582	0x6570c0		4183fbff		CMPL R11, $-0x1											
  module.go:48582	0x6570c4		0f85e2000000		JNE 0x6571ac											
  module.go:48602	0x6570ca		90			NOPL												
  module.go:62983	0x6570cb		4881fa73ce1000		CMPQ DX, $0x10ce73										
  module.go:62983	0x6570d2		0f860d020000		JBE 0x6572e5											
  module.go:48603	0x6570d8		90			NOPL												
  module.go:63001	0x6570d9		41ff8270ce1000		INCL 0x10ce70(R10)										
  module.go:48604	0x6570e0		488b5138		MOVQ 0x38(CX), DX										
  module.go:48604	0x6570e4		4881fafccf1000		CMPQ DX, $0x10cffc										
  module.go:48604	0x6570eb		0f86e4010000		JBE 0x6572d5											
  module.go:48604	0x6570f1		488b5130		MOVQ 0x30(CX), DX										
  module.go:48604	0x6570f5		0fb692fccf1000		MOVZX 0x10cffc(DX), DX										
  module.go:48604	0x6570fc		0f1f4000		NOPL 0(AX)											
  module.go:48605	0x657100		83fa01			CMPL DX, $0x1											
  module.go:48605	0x657103		7410			JE 0x657115											
  module.go:48606	0x657105		4889c8			MOVQ CX, AX											
  module.go:48606	0x657108		e89306fbff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn105(SB)			
  module.go:48608	0x65710d		488b8c2480000000	MOVQ 0x80(SP), CX										
  module.go:48608	0x657115		488b5138		MOVQ 0x38(CX), DX										
  module.go:48608	0x657119		0f1f8000000000		NOPL 0(AX)											
  module.go:62983	0x657120		4881fad3cf1000		CMPQ DX, $0x10cfd3										
  module.go:62983	0x657127		0f869c010000		JBE 0x6572c9											
  module.go:48608	0x65712d		488b7130		MOVQ 0x30(CX), SI										
  module.go:62984	0x657131		83bed0cf100000		CMPL 0x10cfd0(SI), $0x0										
  module.go:48609	0x657138		0f856b010000		JNE 0x6572a9											
  module.go:48613	0x65713e		90			NOPL												
  module.go:48613	0x65713f		90			NOPL												
  module.go:62983	0x657140		4881fae7cf1000		CMPQ DX, $0x10cfe7										
  module.go:62983	0x657147		0f8650010000		JBE 0x65729d											
  module.go:48614	0x65714d		90			NOPL												
  module.go:63000	0x65714e		4881faefcf1000		CMPQ DX, $0x10cfef										
  module.go:63000	0x657155		0f8636010000		JBE 0x657291											
  module.go:62984	0x65715b		8b96e4cf1000		MOVL 0x10cfe4(SI), DX										
  module.go:63001	0x657161		8996eccf1000		MOVL DX, 0x10cfec(SI)										
  module.go:48615	0x657167		488b5138		MOVQ 0x38(CX), DX										
  module.go:63000	0x65716b		4881faebcf1000		CMPQ DX, $0x10cfeb										
  module.go:63000	0x657172		0f860d010000		JBE 0x657285											
  module.go:48615	0x657178		488b5130		MOVQ 0x30(CX), DX										
  module.go:63001	0x65717c		c782e8cf100000000000	MOVL $0x0, 0x10cfe8(DX)										
  module.go:48616	0x657186		488b5138		MOVQ 0x38(CX), DX										
  module.go:63000	0x65718a		4881faf3cf1000		CMPQ DX, $0x10cff3										
  module.go:63000	0x657191		0f86dd000000		JBE 0x657274											
  module.go:48616	0x657197		488b5130		MOVQ 0x30(CX), DX										
  module.go:63001	0x65719b		c782f0cf100000000000	MOVL $0x0, 0x10cff0(DX)										
  module.go:63001	0x6571a5		31c0			XORL AX, AX											
  module.go:48619	0x6571a7		e996000000		JMP 0x657242											
  module.go:48585	0x6571ac		90			NOPL												
  module.go:62983	0x6571ad		4839fa			CMPQ DX, DI											
  module.go:62983	0x6571b0		0f86b9000000		JBE 0x65726f											
  module.go:63009	0x6571b6		4c8d660f		LEAQ 0xf(SI), R12										
  module.go:48587	0x6571ba		90			NOPL												
  module.go:62984	0x6571bb		468b6c1604		MOVL 0x4(SI)(R10*1), R13									
  module.go:63009	0x6571c0		4c39e2			CMPQ DX, R12											
  module.go:63009	0x6571c3		0f86a1000000		JBE 0x65726a											
  module.go:63010	0x6571c9		4a8b541608		MOVQ 0x8(SI)(R10*1), DX										
  module.go:48592	0x6571ce		4889c8			MOVQ CX, AX											
  module.go:48597	0x6571d1		8b5c2420		MOVL 0x20(SP), BX										
  module.go:63001	0x6571d5		4d89ca			MOVQ R9, R10											
  module.go:48591	0x6571d8		4489e9			MOVL R13, CX											
  module.go:63000	0x6571db		4989f9			MOVQ DI, R9											
  module.go:63000	0x6571de		4c89c7			MOVQ R8, DI											
  module.go:63026	0x6571e1		4989f0			MOVQ SI, R8											
  module.go:48592	0x6571e4		488b7038		MOVQ 0x38(AX), SI										
  module.go:62983	0x6571e8		4881fe73ce1000		CMPQ SI, $0x10ce73										
  module.go:62983	0x6571ef		766d			JBE 0x65725e											
  module.go:48592	0x6571f1		488b7030		MOVQ 0x30(AX), SI										
  module.go:63026	0x6571f5		4d8d600f		LEAQ 0xf(R8), R12										
  module.go:48593	0x6571f9		90			NOPL												
  module.go:63001	0x6571fa		ff8670ce1000		INCL 0x10ce70(SI)										
  module.go:48594	0x657200		488b7038		MOVQ 0x38(AX), SI										
  module.go:63026	0x657204		4c39e6			CMPQ SI, R12											
  module.go:63026	0x657207		7650			JBE 0x657259											
  module.go:48594	0x657209		488b7030		MOVQ 0x30(AX), SI										
  module.go:63027	0x65720d		4989543008		MOVQ DX, 0x8(R8)(SI*1)										
  module.go:48595	0x657212		488b5038		MOVQ 0x38(AX), DX										
  module.go:63000	0x657216		4c39ca			CMPQ DX, R9											
  module.go:63000	0x657219		7639			JBE 0x657254											
  module.go:48595	0x65721b		488b5030		MOVQ 0x30(AX), DX										
  module.go:63001	0x65721f		41894c1004		MOVL CX, 0x4(R8)(DX*1)										
  module.go:48596	0x657224		488b4838		MOVQ 0x38(AX), CX										
  module.go:63000	0x657228		4839f9			CMPQ CX, DI											
  module.go:63000	0x65722b		7622			JBE 0x65724f											
  module.go:48596	0x65722d		488b4830		MOVQ 0x30(AX), CX										
  module.go:63001	0x657231		46891c11		MOVL R11, 0(CX)(R10*1)										
  module.go:48597	0x657235		e8665af8ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn60(SB)			
  module.go:48620	0x65723a		488b8c2480000000	MOVQ 0x80(SP), CX										
  module.go:48620	0x657242		8b54242c		MOVL 0x2c(SP), DX										
  module.go:48620	0x657246		895150			MOVL DX, 0x50(CX)										
  module.go:48621	0x657249		4883c470		ADDQ $0x70, SP											
  module.go:48621	0x65724d		5d			POPQ BP												
  module.go:48621	0x65724e		c3			RET												
  module.go:63000	0x65724f		e86c97e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x657254		e86797e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x657259		e86297e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x65725e		48c7c073ce1000		MOVQ $0x10ce73, AX										
  module.go:62983	0x657265		e85697e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x65726a		e85197e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x65726f		e84c97e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x657274		48c7c0f3cf1000		MOVQ $0x10cff3, AX										
  module.go:63000	0x65727b		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:63000	0x657280		e83b97e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x657285		48c7c0ebcf1000		MOVQ $0x10cfeb, AX										
  module.go:63000	0x65728c		e82f97e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x657291		48c7c0efcf1000		MOVQ $0x10cfef, AX										
  module.go:63000	0x657298		e82397e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x65729d		48c7c0e7cf1000		MOVQ $0x10cfe7, AX										
  module.go:62983	0x6572a4		e81797e3ff		CALL runtime.panicBounds(SB)									
  module.go:48610	0x6572a9		4889c8			MOVQ CX, AX											
  module.go:48610	0x6572ac		bb60171000		MOVL $0x101760, BX										
  module.go:48610	0x6572b1		e80ac0f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn24(SB)			
  module.go:48611	0x6572b6		488d0563371f00		LEAQ 0x1f3763(IP), AX										
  module.go:48611	0x6572bd		488d1d2cb02a00		LEAQ 0x2ab02c(IP), BX										
  module.go:48611	0x6572c4		e81715e3ff		CALL runtime.gopanic(SB)									
  module.go:62983	0x6572c9		48c7c0d3cf1000		MOVQ $0x10cfd3, AX										
  module.go:62983	0x6572d0		e8eb96e3ff		CALL runtime.panicBounds(SB)									
  module.go:48604	0x6572d5		48c7c0fccf1000		MOVQ $0x10cffc, AX										
  module.go:48604	0x6572dc		0f1f4000		NOPL 0(AX)											
  module.go:48604	0x6572e0		e8db96e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x6572e5		48c7c073ce1000		MOVQ $0x10ce73, AX										
  module.go:62983	0x6572ec		e8cf96e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x6572f1		e8ca96e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x6572f6		e8c596e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x6572fb		48c7c077191000		MOVQ $0x101977, AX										
  module.go:63009	0x657302		e8b996e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x657307		e8b496e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x65730c		48c7c07f191000		MOVQ $0x10197f, AX										
  module.go:63009	0x657313		e8a896e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x657318		e8a396e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x65731d		48c7c087191000		MOVQ $0x101987, AX										
  module.go:63009	0x657324		e89796e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x657329		e89296e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x65732e		48c7c08f191000		MOVQ $0x10198f, AX										
  module.go:63009	0x657335		e88696e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x65733a		e88196e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x65733f		48c7c097191000		MOVQ $0x101997, AX										
  module.go:63009	0x657346		e87596e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x65734b		e87096e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x657350		48c7c09b191000		MOVQ $0x10199b, AX										
  module.go:62983	0x657357		e86496e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x65735c		0f1f4000		NOPL 0(AX)											
  module.go:63000	0x657360		e85b96e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x657365		e85696e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x65736a		e85196e3ff		CALL runtime.panicBounds(SB)									
  module.go:48515	0x65736f		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48515	0x657377		bb01000000		MOVL $0x1, BX											
  module.go:48515	0x65737c		b92c000000		MOVL $0x2c, CX											
  module.go:48515	0x657381		e83a50f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn2(SB)			
  module.go:48516	0x657386		488d0593361f00		LEAQ 0x1f3693(IP), AX										
  module.go:48516	0x65738d		488d1d5caf2a00		LEAQ 0x2aaf5c(IP), BX										
  module.go:48516	0x657394		e84714e3ff		CALL runtime.gopanic(SB)									
  module.go:63000	0x657399		e82296e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x65739e		6690			NOPW												
  module.go:63026	0x6573a0		e81b96e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x6573a5		e81696e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x6573aa		e81196e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x6573af		e80c96e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x6573b4		e80796e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x6573b9		e80296e3ff		CALL runtime.panicBounds(SB)									
  module.go:48559	0x6573be		4c89e0			MOVQ R12, AX											
  module.go:48559	0x6573c1		488d0d58472000		LEAQ 0x204758(IP), CX										
  module.go:48559	0x6573c8		e8b36ddcff		CALL runtime.panicdottypeE(SB)									
  module.go:63165	0x6573cd		488d054c361f00		LEAQ 0x1f364c(IP), AX										
  module.go:63165	0x6573d4		488d1d65c62a00		LEAQ 0x2ac665(IP), BX										
  module.go:63165	0x6573db		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:63165	0x6573e0		e8fb13e3ff		CALL runtime.gopanic(SB)									
  module.go:62983	0x6573e5		e8d695e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x6573ea		e8d195e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x6573ef		e8cc95e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x6573f4		e8c795e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x6573f9		e8c295e3ff		CALL runtime.panicBounds(SB)									
  module.go:48549	0x6573fe		8b7c2428		MOVL 0x28(SP), DI										
  module.go:48549	0x657402		ffcf			DECL DI												
  module.go:48549	0x657404		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48549	0x65740c		bbf01a1000		MOVL $0x101af0, BX										
  module.go:48549	0x657411		b937000000		MOVL $0x37, CX											
  module.go:48549	0x657416		bee01a1000		MOVL $0x101ae0, SI										
  module.go:48549	0x65741b		41b8281b1000		MOVL $0x101b28, R8										
  module.go:48549	0x657421		e85ac2f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn27(SB)			
  module.go:48550	0x657426		488d05f3351f00		LEAQ 0x1f35f3(IP), AX										
  module.go:48550	0x65742d		488d1dbcae2a00		LEAQ 0x2aaebc(IP), BX										
  module.go:48550	0x657434		e8a713e3ff		CALL runtime.gopanic(SB)									
  module.go:48547	0x657439		4c89e8			MOVQ R13, AX											
  module.go:48547	0x65743c		4889fb			MOVQ DI, BX											
  module.go:48547	0x65743f		488d0dda462000		LEAQ 0x2046da(IP), CX										
  module.go:48547	0x657446		e8356ddcff		CALL runtime.panicdottypeE(SB)									
  module.go:63165	0x65744b		488d05ce351f00		LEAQ 0x1f35ce(IP), AX										
  module.go:63165	0x657452		488d1de7c52a00		LEAQ 0x2ac5e7(IP), BX										
  module.go:63165	0x657459		e88213e3ff		CALL runtime.gopanic(SB)									
  module.go:62983	0x65745e		6690			NOPW												
  module.go:62983	0x657460		e85b95e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x657465		e85695e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x65746a		e85195e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x65746f		e84c95e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x657474		e84795e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x657479		e84295e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x65747e		6690			NOPW												
  module.go:62983	0x657480		e83b95e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x657485		e83695e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x65748a		e83195e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x65748f		e82c95e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x657494		e82795e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x657499		e82295e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x65749e		48c7c083ce1000		MOVQ $0x10ce83, AX										
  module.go:62983	0x6574a5		e81695e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x6574aa		48c7c07fce1000		MOVQ $0x10ce7f, AX										
  module.go:62983	0x6574b1		e80a95e3ff		CALL runtime.panicBounds(SB)									
  module.go:48623	0x6574b6		bb60171000		MOVL $0x101760, BX										
  module.go:48623	0x6574bb		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:48623	0x6574c0		e8fbbdf7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn24(SB)			
  module.go:48624	0x6574c5		488d0554351f00		LEAQ 0x1f3554(IP), AX										
  module.go:48624	0x6574cc		488d1d1dae2a00		LEAQ 0x2aae1d(IP), BX										
  module.go:48624	0x6574d3		e80813e3ff		CALL runtime.gopanic(SB)									
  module.go:62983	0x6574d8		48c7c073ce1000		MOVQ $0x10ce73, AX										
  module.go:62983	0x6574df		90			NOPL												
  module.go:62983	0x6574e0		e8db94e3ff		CALL runtime.panicBounds(SB)									
  module.go:48463	0x6574e5		48c7c0b0cf1000		MOVQ $0x10cfb0, AX										
  module.go:48463	0x6574ec		e8cf94e3ff		CALL runtime.panicBounds(SB)									
  module.go:48463	0x6574f1		90			NOPL												
  module.go:48457	0x6574f2		4889442408		MOVQ AX, 0x8(SP)										
  module.go:48457	0x6574f7		48895c2410		MOVQ BX, 0x10(SP)										
  module.go:48457	0x6574fc		f20f11442418		MOVSD_XMM X0, 0x18(SP)										
  module.go:48457	0x657502		e89977e3ff		CALL runtime.morestack_noctxt.abi0(SB)								
  module.go:48457	0x657507		488b442408		MOVQ 0x8(SP), AX										
  module.go:48457	0x65750c		488b5c2410		MOVQ 0x10(SP), BX										
  module.go:48457	0x657511		f20f10442418		MOVSD_XMM 0x18(SP), X0										
  module.go:48457	0x657517		e944f4ffff		JMP dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).Xcocoon_sketch_add(SB)	
