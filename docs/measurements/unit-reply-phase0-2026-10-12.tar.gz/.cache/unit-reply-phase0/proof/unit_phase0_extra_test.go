package rt_test

import (
	"encoding/binary"
	"errors"
	"fmt"
	"math"
	"os"
	"reflect"
	"slices"
	"strings"
	"testing"

	"dario.cat/cocoon/rt"
)

type unitPhaseModule struct {
	*module
	views       [][]byte
	events      []string
	output      uint32
	memoryCalls int
	outputCalls int
	panicAt     int
}

func (m *unitPhaseModule) Memory() []byte {
	m.memoryCalls++
	m.events = append(m.events, fmt.Sprintf("memory%d", m.memoryCalls))
	if m.memoryCalls == m.panicAt {
		panic("deliberate unit phase Memory panic")
	}
	if len(m.views) != 0 {
		return m.views[(m.memoryCalls-1)%len(m.views)]
	}
	return m.memory
}

func (m *unitPhaseModule) Output() uint32 {
	m.outputCalls++
	return m.output
}

func unitPhaseInstance(t *testing.T, output uint32, maxMemory uint64) (*unitPhaseModule, *rt.Instance) {
	t.Helper()
	m := &unitPhaseModule{module: newModule(), output: output}
	i, err := rt.NewInstance(m, 7, rt.Limits{MaxInput: 16, MaxOutput: 32, MaxMemory: maxMemory})
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(i.Close)
	if m.outputCalls != 1 {
		t.Fatalf("output address resolved %d times", m.outputCalls)
	}
	m.memoryCalls, m.events = 0, nil
	return m, i
}

func unitPhaseReply(memory []byte, output, pointer, size uint32, message []byte) {
	// Setup uses full backing; cases may subsequently hide part of it by length.
	backing := memory[:cap(memory)]
	binary.LittleEndian.PutUint32(backing[output:], pointer)
	binary.LittleEndian.PutUint32(backing[output+4:], size)
	if uint64(pointer)+uint64(len(message)) <= uint64(len(backing)) {
		copy(backing[pointer:], message)
	}
}

func unitPhaseValidate(call *rt.Call, status rt.Status, resultUnit bool) error {
	if resultUnit {
		return call.ResultUnit("phase-unit", status)
	}
	view, err := call.ResultView("phase-unit", status)
	if err != nil {
		return err
	}
	if len(view) != 0 {
		return rt.ErrProtocol
	}
	return nil
}

type unitPhaseCase struct {
	want          error
	name          string
	diagnostic    string
	message       []byte
	pointer, size uint32
	output        uint32
	length        int
	status        rt.Status
	poison        bool
}

func unitPhaseCases() []unitPhaseCase {
	protocol := "cocoon: invalid guest reply"
	limit := "cocoon: size limit exceeded"
	return []unitPhaseCase{
		{name: "empty-zero", length: 64},
		{name: "empty-end", pointer: 64, length: 64},
		{name: "empty-internal", pointer: 16, length: 64},
		{name: "descriptor-exact-end", output: 56, pointer: 64, length: 64},
		{rt.ErrProtocol, "empty-outside-logical", protocol + ": memory range [65,65) exceeds 64", nil, 65, 0, 0, 64, rt.OK, true},
		{rt.ErrProtocol, "empty-max-pointer", protocol + ": memory range [4294967295,4294967295) exceeds 64", nil, math.MaxUint32, 0, 0, 64, rt.OK, true},
		{rt.ErrProtocol, "nonempty-valid", protocol, nil, 16, 1, 0, 64, rt.OK, true},
		{rt.ErrProtocol, "nonempty-invalid", protocol + ": memory range [63,65) exceeds 64", nil, 63, 2, 0, 64, rt.OK, true},
		{rt.ErrProtocol, "nonempty-wrap", protocol + ": memory range [4294967295,4294967297) exceeds 64", nil, math.MaxUint32, 2, 0, 64, rt.OK, true},
		{rt.ErrProtocol, "descriptor-truncated", protocol + ": memory range [48,56) exceeds 55", nil, math.MaxUint32, 33, 48, 55, rt.Pending, true},
		{rt.ErrProtocol, "descriptor-length-zero", protocol + ": memory range [0,8) exceeds 0", nil, 0, 0, 0, 0, rt.OK, true},
		{rt.ErrTooLarge, "limit-before-shape", limit, nil, 16, 33, 0, 64, rt.OK, false},
		{rt.ErrTooLarge, "limit-before-bounds", limit, nil, math.MaxUint32, 33, 0, 64, rt.OK, false},
		{rt.ErrTooLarge, "limit-before-argument", limit, nil, math.MaxUint32, 33, 0, 64, rt.ErrArg, false},
		{rt.ErrTooLarge, "limit-before-pending", limit, nil, math.MaxUint32, 33, 0, 64, rt.Pending, false},
		{rt.ErrTooLarge, "limit-before-unknown", limit, nil, math.MaxUint32, 33, 0, 64, rt.Status(6), false},
		{rt.ErrProtocol, "bounds-before-argument", protocol + ": memory range [63,65) exceeds 64", nil, 63, 2, 0, 64, rt.ErrArg, true},
		{rt.ErrProtocol, "bounds-before-pending", protocol + ": memory range [65,65) exceeds 64", nil, 65, 0, 0, 64, rt.Pending, true},
		{rt.ErrProtocol, "bounds-before-unknown", protocol + ": memory range [63,65) exceeds 64", nil, 63, 2, 0, 64, rt.Status(6), true},
		{rt.ErrProtocol, "pending-before-shape", "phase-unit: " + protocol + ": async status in synchronous operation", nil, 16, 1, 0, 64, rt.Pending, true},
		{rt.ErrProtocol, "unknown-before-shape", "phase-unit: " + protocol + ": unknown status 6", nil, 16, 1, 0, 64, rt.Status(6), true},
		{rt.ErrProtocol, "negative-status", "phase-unit: " + protocol + ": unknown status -1", nil, 16, 0, 0, 64, rt.Status(-1), true},
		{name: "empty-application", pointer: 64, length: 64, status: rt.ErrApp, diagnostic: "phase-unit: "},
		{name: "empty-argument", pointer: 64, length: 64, status: rt.ErrArg, diagnostic: "phase-unit: "},
		{name: "empty-handle", pointer: 64, length: 64, status: rt.ErrHandle, diagnostic: "phase-unit: invalid handle: "},
		{rt.ErrTooLarge, "empty-limit", "phase-unit: " + limit + ": ", nil, 64, 0, 0, 64, rt.ErrLimit, false},
		{name: "argument-payload", pointer: 16, size: 3, length: 64, status: rt.ErrArg, message: []byte("bad"), diagnostic: "phase-unit: bad"},
		{name: "application-raw-bytes", pointer: 16, size: 4, length: 64, status: rt.ErrApp, message: []byte{'x', 0, 0xff, 0xc0}, diagnostic: "phase-unit: x\x00\xff\xc0"},
		{name: "handle-raw-bytes", pointer: 16, size: 4, length: 64, status: rt.ErrHandle, message: []byte{'x', 0, 0xff, 0xc0}, diagnostic: "phase-unit: invalid handle: x\x00\xff\xc0"},
		{rt.ErrTooLarge, "limit-raw-bytes", "phase-unit: " + limit + ": x\x00\xff\xc0", []byte{'x', 0, 0xff, 0xc0}, 16, 4, 0, 64, rt.ErrLimit, false},
	}
}

func unitPhaseExpectedError(t *testing.T, test unitPhaseCase, err error) {
	t.Helper()
	if test.diagnostic == "" {
		if err != nil {
			t.Fatalf("unit semantic mismatch: %s returned %v", test.name, err)
		}
		return
	}
	if err == nil || err.Error() != test.diagnostic || test.want != nil && !errors.Is(err, test.want) {
		t.Fatalf("unit semantic mismatch: %s error=%v want=%q", test.name, err, test.diagnostic)
	}
	switch test.status {
	case rt.ErrApp, rt.ErrArg:
		if test.want == nil {
			var app *rt.AppError
			if !errors.As(err, &app) || app.Op != "phase-unit" || app.Status != test.status || app.Message != string(test.message) {
				t.Fatalf("unit semantic mismatch: %s concrete application error=%#v", test.name, err)
			}
		}
	case rt.ErrHandle:
		if test.want == nil {
			var handle *rt.HandleError
			if !errors.As(err, &handle) || handle.Op != "phase-unit" || handle.Reason != string(test.message) {
				t.Fatalf("unit semantic mismatch: %s concrete handle error=%#v", test.name, err)
			}
		}
	case rt.OK, rt.Pending, rt.ErrLimit:
	}
}

func unitPhaseAssertCase(t *testing.T, test unitPhaseCase, resultUnit bool) {
	t.Helper()
	m, i := unitPhaseInstance(t, test.output, 128)
	unitPhaseReply(m.memory, test.output, test.pointer, test.size, test.message)
	m.memory = m.memory[:test.length]
	epoch := i.Epoch()
	owner, err := rt.NewResource[unitPhaseModule](i, 1, func(uint64) error { return nil })
	if err != nil {
		t.Fatal(err)
	}
	err = i.Call("phase-unit", func(call *rt.Call) error {
		m.events = append(m.events, "invoke")
		result := unitPhaseValidate(call, test.status, resultUnit)
		m.events = append(m.events, "callback-end")
		return result
	})
	unitPhaseExpectedError(t, test, err)
	if got, want := m.events, []string{"invoke", "memory1", "callback-end", "memory2"}; !slices.Equal(got, want) {
		t.Fatalf("unit semantic mismatch: %s query/evaluation order=%v want=%v", test.name, got, want)
	}
	if i.Healthy() == test.poison || (i.Epoch() != epoch) != test.poison || m.outputCalls != 1 {
		t.Fatalf("unit semantic mismatch: %s health=%v epoch=%d original=%d outputCalls=%d", test.name, i.Healthy(), i.Epoch(), epoch, m.outputCalls)
	}
	if err != nil {
		before := err.Error()
		clear(m.memory[:cap(m.memory)])
		if err.Error() != before {
			t.Fatal("unit semantic mismatch: error retained guest message backing")
		}
	}
	executed := false
	useErr := owner.Use("later", func(*rt.Instance, uint64) error { executed = true; return nil })
	if executed == test.poison || (useErr != nil) != test.poison {
		t.Fatalf("unit semantic mismatch: %s prior live ownership executed=%v error=%v", test.name, executed, useErr)
	}
	if test.poison {
		err = i.Call("later", func(*rt.Call) error { t.Fatal("poisoned second callback executed"); return nil })
		if !errors.Is(err, rt.ErrPoisoned) || m.memoryCalls != 2 {
			t.Fatalf("unit semantic mismatch: poisoned later call=%v queries=%d", err, m.memoryCalls)
		}
	}
	if err := owner.Close(); err != nil {
		t.Fatal(err)
	}
}

func TestUnitPhase0WireAndBoundary(t *testing.T) {
	for _, resultUnit := range []bool{false, true} {
		t.Run(fmt.Sprintf("ResultUnit=%v", resultUnit), func(t *testing.T) {
			for _, test := range unitPhaseCases() {
				t.Run(test.name, func(t *testing.T) { unitPhaseAssertCase(t, test, resultUnit) })
			}
		})
	}
}

func TestUnitPhase0CapturedMemory(t *testing.T) {
	for _, resultUnit := range []bool{false, true} {
		m, i := unitPhaseInstance(t, 0, 128)
		first, second := make([]byte, 64, 128), make([]byte, 64, 128)
		unitPhaseReply(first, 0, 16, 4, []byte("first"))
		unitPhaseReply(second, 0, 16, 4, []byte("other"))
		m.views = [][]byte{first, second}
		err := i.Call("phase-unit", func(call *rt.Call) error { return unitPhaseValidate(call, rt.ErrArg, resultUnit) })
		var app *rt.AppError
		if !errors.As(err, &app) || app.Message != "firs" || m.memoryCalls != 2 || !i.Healthy() {
			t.Fatalf("unit semantic mismatch: captured-memory error=%v calls=%d healthy=%v", err, m.memoryCalls, i.Healthy())
		}
		clear(first)
		clear(second)
		if app.Message != "firs" {
			t.Fatal("unit semantic mismatch: captured message is not owned")
		}
	}
}

func TestUnitPhase0MemoryPanics(t *testing.T) {
	for _, resultUnit := range []bool{false, true} {
		for _, panicAt := range []int{1, 2} {
			m, i := unitPhaseInstance(t, 0, 128)
			epoch := i.Epoch()
			owner, err := rt.NewResource[unitPhaseModule](i, 1, func(uint64) error { return nil })
			if err != nil {
				t.Fatal(err)
			}
			m.panicAt = panicAt
			err = i.Call("phase-unit", func(call *rt.Call) error { return unitPhaseValidate(call, rt.OK, resultUnit) })
			var fault *rt.FaultError
			if !errors.As(err, &fault) || fault.Op != "phase-unit" || !strings.Contains(fault.Detail, "deliberate unit phase Memory panic") ||
				i.Healthy() || i.Epoch() != epoch+1 || m.memoryCalls != panicAt {
				t.Fatalf("unit semantic mismatch: Memory panic fault=%v health=%v epoch=%d queries=%d", err, i.Healthy(), i.Epoch(), m.memoryCalls)
			}
			if err := i.Call("second", func(*rt.Call) error { t.Fatal("Memory fault reran callback"); return nil }); !errors.Is(err, rt.ErrPoisoned) {
				t.Fatal(err)
			}
			if err := owner.Use("after-fault", func(*rt.Instance, uint64) error { t.Fatal("Memory fault retained ownership"); return nil }); err == nil {
				t.Fatal("unit semantic mismatch: Memory fault retained ownership")
			}
			if err := owner.Close(); err != nil {
				t.Fatal(err)
			}
		}
	}
}

func TestUnitPhase0PostMemoryPriority(t *testing.T) {
	for _, resultUnit := range []bool{false, true} {
		for _, test := range []struct {
			pointer, size uint32
			status        rt.Status
		}{{16, 0, rt.OK}, {65, 0, rt.OK}, {16, 3, rt.ErrArg}, {math.MaxUint32, 33, rt.Pending}} {
			m, i := unitPhaseInstance(t, 0, 64)
			first, grown := make([]byte, 64, 128), make([]byte, 128)
			unitPhaseReply(first, 0, test.pointer, test.size, []byte("bad"))
			m.views = [][]byte{first, grown}
			epoch := i.Epoch()
			owner, err := rt.NewResource[unitPhaseModule](i, 1, func(uint64) error { return nil })
			if err != nil {
				t.Fatal(err)
			}
			err = i.Call("phase-unit", func(call *rt.Call) error { return unitPhaseValidate(call, test.status, resultUnit) })
			if !errors.Is(err, rt.ErrTooLarge) || errors.Is(err, rt.ErrProtocol) ||
				err.Error() != "phase-unit: cocoon: size limit exceeded: linear memory exceeded maximum" ||
				i.Healthy() || i.Epoch() != epoch+1 || m.memoryCalls != 2 {
				t.Fatalf("unit semantic mismatch: post-memory precedence error=%v health=%v epoch=%d queries=%d", err, i.Healthy(), i.Epoch(), m.memoryCalls)
			}
			if err := owner.Use("after-growth", func(*rt.Instance, uint64) error { t.Fatal("growth-invalidated resource executed"); return nil }); err == nil {
				t.Fatal("unit semantic mismatch: growth retained ownership")
			}
			if err := i.Call("second", func(*rt.Call) error { t.Fatal("growth reran callback"); return nil }); !errors.Is(err, rt.ErrPoisoned) || m.memoryCalls != 2 {
				t.Fatal("unit semantic mismatch: growth allowed later execution", err)
			}
			if err := owner.Close(); err != nil {
				t.Fatal(err)
			}
		}
	}
}

func TestUnitPhase0ResetAndClose(t *testing.T) {
	for _, resultUnit := range []bool{false, true} {
		m, i := unitPhaseInstance(t, 0, 128)
		unitPhaseReply(m.memory, 0, 16, 4, []byte("bad\x00"))
		if err := i.Call("phase-unit", func(call *rt.Call) error {
			if err := call.PrepareInput(4); err != nil {
				return err
			}
			if _, err := call.PutString("bad\x00"); err != nil {
				return err
			}
			return unitPhaseValidate(call, rt.ErrArg, resultUnit)
		}); err == nil || !i.Healthy() {
			t.Fatal("unit semantic mismatch: expected first argument error", err)
		}
		unitPhaseReply(m.memory, 0, 64, 0, nil)
		if err := i.Call("phase-unit", func(call *rt.Call) error {
			pointer, err := call.PutBytes(nil)
			if err != nil || pointer != 0 {
				t.Fatalf("unit semantic mismatch: reservation did not reset: %d %v", pointer, err)
			}
			return unitPhaseValidate(call, rt.OK, resultUnit)
		}); err != nil {
			t.Fatal("unit semantic mismatch: error-to-empty-success transition", err)
		}
		if err := i.Call("phase-unit", func(call *rt.Call) error { _, err := call.PutBytes([]byte{1}); return err }); !errors.Is(err, rt.ErrTooLarge) || !i.Healthy() {
			t.Fatal("unit semantic mismatch: reservation capacity leaked", err)
		}
		drops := 0
		owner, err := rt.NewResource[unitPhaseModule](i, 1, func(uint64) error {
			drops++
			return i.Call("phase-unit", func(call *rt.Call) error { return unitPhaseValidate(call, rt.OK, resultUnit) })
		})
		if err != nil {
			t.Fatal(err)
		}
		copyValue := reflect.New(reflect.TypeOf(owner).Elem())
		copyValue.Elem().Set(reflect.ValueOf(owner).Elem())
		alias := copyValue.Interface().(*rt.Resource[unitPhaseModule])
		if err := owner.Close(); err != nil {
			t.Fatal(err)
		}
		if err := alias.Close(); err != nil || drops != 1 {
			t.Fatalf("unit semantic mismatch: alias destructor err=%v drops=%d", err, drops)
		}
		if err := alias.Use("closed", func(*rt.Instance, uint64) error { t.Fatal("closed alias executed"); return nil }); err == nil {
			t.Fatal("unit semantic mismatch: closed alias stayed live")
		}
		i.Close()
		if err := i.Call("closed", func(*rt.Call) error { t.Fatal("closed instance executed"); return nil }); !errors.Is(err, rt.ErrClosed) {
			t.Fatal("unit semantic mismatch: terminal close", err)
		}
	}
}

func TestUnitPhase0DestructorFault(t *testing.T) {
	for _, resultUnit := range []bool{false, true} {
		m, i := unitPhaseInstance(t, 0, 128)
		epoch := i.Epoch()
		unitPhaseReply(m.memory, 0, 65, 0, nil)
		drops := 0
		owner, err := rt.NewResource[unitPhaseModule](i, 1, func(uint64) error {
			drops++
			return i.Call("phase-unit", func(call *rt.Call) error { return unitPhaseValidate(call, rt.OK, resultUnit) })
		})
		if err != nil {
			t.Fatal(err)
		}
		sibling, err := rt.NewResource[unitPhaseModule](i, 2, func(uint64) error { return nil })
		if err != nil {
			t.Fatal(err)
		}
		first, second := owner.Close(), owner.Close()
		if !errors.Is(first, rt.ErrProtocol) || first != second || drops != 1 || i.Healthy() || i.Epoch() != epoch+1 {
			t.Fatalf("unit semantic mismatch: destructor fault first=%v second=%v drops=%d health=%v epoch=%d", first, second, drops, i.Healthy(), i.Epoch())
		}
		if err := sibling.Use("after-drop-fault", func(*rt.Instance, uint64) error { t.Fatal("destructor fault retained sibling ownership"); return nil }); err == nil {
			t.Fatal("unit semantic mismatch: destructor fault retained sibling")
		}
		if err := sibling.Close(); err != nil {
			t.Fatal(err)
		}
	}
}

func TestUnitPhase0MutantProbe(t *testing.T) {
	switch mutant := os.Getenv("UNIT_PHASE0_MUTANT"); mutant {
	case "":
		t.Skip("only executed by the semantic-mutant driver")
	case "skip-empty-range":
		for _, test := range unitPhaseCases() {
			if test.name == "empty-outside-logical" {
				unitPhaseAssertCase(t, test, true)
				return
			}
		}
	case "nonempty-early":
		for _, test := range unitPhaseCases() {
			if test.name == "nonempty-invalid" {
				unitPhaseAssertCase(t, test, true)
				return
			}
		}
	case "second-memory-fallback":
		TestUnitPhase0CapturedMemory(t)
		return
	case "skip-post-memory":
		TestUnitPhase0PostMemoryPriority(t)
		return
	}
	t.Fatal("unit semantic mismatch: unknown/unselected mutant")
}
