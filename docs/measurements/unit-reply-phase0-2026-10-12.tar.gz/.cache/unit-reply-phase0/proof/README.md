# Ignored existing-ABI unit-reply runtime oracle

This is functional evidence for the three phase-zero roles, not performance
samples or a production/public-contract specification. All authored additions
are under this ignored directory. Canonical timing overlays and tracked files
are unchanged. `unit_phase0_extra_test.go` is supplied through a proof-only
virtual `rt/unit_phase0_extra_test.go` entry in each `*-extra-overlay.json`.

The runtime oracle uses both the actual original ResultView-plus-empty-check
callback and ResultUnit against independent expected outcomes in every role.
The public mock ABI Memory method counts events, returns alternating views and
can panic after initialization. Setup queries are reset; each ordinary reply
validation must query Memory once, then Instance.Call independently queries it
for the post-operation limit. It must not query Output again.

Thirty named wire scenarios assert concrete diagnostics and status-specific
owned error fields: valid zero/internal/end pointers, exact descriptor endpoint,
truncated/empty descriptors with spare backing, nonempty success and invalid
range, widened wasm32 overflow, MaxOutput before bounds/status/shape, bounds
before status, status before unit shape, Pending/unknown/negative codes, and
all expected empty/error replies. Raw NUL and invalid UTF8 message bytes remain
owned after clearing guest memory. Prior live resources and epochs prove
protocol poisoning and prevention of later callbacks; expected errors stay
healthy. Additional tests cover alternating-memory fallback, Memory panic at
validation/post-check, post-MaxMemory precedence over success/protocol/expected
errors, reservation reset/error-to-success, aliases, once-only destruction,
destructor protocol faults invalidating a sibling, and terminal Close.

Four safe ignored candidate-source mutants must fail explicit semantic tests:
skipping the empty payload range, rejecting nonempty success before its payload
range, rereading Memory in the tail, and skipping post-operation MaxMemory
enforcement. The final mutant preserves the Memory query itself so a query-count
failure cannot stand in for its priority/poisoning oracle. The driver first
requires successful compilation, then requires nonzero test execution plus
`--- FAIL: TestUnitPhase0MutantProbe` and `unit semantic mismatch`; compile or
startup errors cannot satisfy rejection. Exact failed stdout is preserved.

## Generated consumer runtime coverage

The existing gogen fixture overrides child GOFLAGS and would otherwise lose the
parent overlay. Proof-only role copies of `unit_fixture_test.go` propagate the
matching `*-extra-overlay.json` in that existing GOFLAGS entry. The original
test/environment logic is preserved; added logging records the resolved child
compiler, argv, directory, role overlay, CGO and GOARCH, plus raw child output.
This gives the actual generated consumer its role's runtime body, rather than
claiming candidate coverage from a parent-only generator test. Canonical
timing JSONs are not modified by this propagation.
The parent's earlier unpropagated fixture run could regenerate a unit facade
with the candidate generator while compiling its child against the original
runtime. Those successful parent checks are not claimed as dynamic candidate
runtime coverage. This is an explicitly recorded procedural coverage gap,
separate from the later cwd setup failure; the final propagated three-role
child proofs resolve it. No raw failure is invented for a coverage gap.

The compiled parent must run with cwd `internal/gen/gogen`, matching go test's
normal package working directory. The initial proof driver used repo root, so
the fixture's existing `filepath.Abs("../../..")` produced `/home`; its child
failed module setup before compiling a consumer. That raw failed log, driver
snapshot and command/provenance records are retained under
`fixture-cwd-setup-failure/`. It is a procedural negative, not a candidate
semantic failure or performance sample. Earlier passing runtime-only proof
stage records are in `before-fixture-overlay/`. The driver cwd was corrected
and every final generated consumer passed.

## Commands, hashes and native scope

`driver.py` rejects drift from the exact original runtime, probe runtime and
authored gogen fixture before copying overlays/mutants. Original runtime SHA is
`607103f216fb1da1445e705deaea8891f21cbdd04f74e385f4958795ef107d74`;
probe SHA is `bea19308a873061507dc0032df77378bbfb7f5f58550d7db62d0622c2d3952f6`.
The final owned oracle SHA is
`5ab61d8e075a70c04cb49a0b22d9222e923768502c0d52fe6b8c7393e313782c`.
`final-provenance.json` records original timing-overlay hashes, proof overlays,
fixture/mutant sources, owned files, all20 built binaries and raw log hashes.

All three runtime oracles and all three generated unit-consumer fixtures pass
on native amd64 and native386. All four semantic mutants are rejected on both.
Builds use the downloaded pinned Go1.26.8 at
`.cache/toolchains/go1.26.8/go/bin/go`, CGO0 and explicit parent `-pgo=off`.
PATH prepends that toolchain for the fixture child; raw child logs confirm its
resolved compiler and GOARCH. Native386 binaries are actually executed with
sandbox escalation, not a cross `-exec=true` check. No known sandbox SIGSYS
attempt was repeated. There is no native arm64 execution or performance claim.

Exact compiler/execution argv, cwd, selected environment, return codes,
timestamps and raw log hashes are in `command-records.jsonl`. The driver
operations performed are:

```text
.cache/toolchains/go1.26.8/go/bin/gofmt -w .cache/unit-reply-phase0/proof/unit_phase0_extra_test.go
python3 .cache/unit-reply-phase0/proof/driver.py prepare
python3 .cache/unit-reply-phase0/proof/driver.py build-run-amd64
python3 .cache/unit-reply-phase0/proof/driver.py build-386
# After correcting only the fixture-parent cwd:
python3 .cache/unit-reply-phase0/proof/driver.py run-fixtures-amd64
# sandbox escalation; already built native386 parents execute their consumers:
python3 .cache/unit-reply-phase0/proof/driver.py run-386
```

The runtime proof uses synthetic Module replies and a separately generated
mock unit consumer. It does not change or establish the real payload's guest
semantics, current Wasm hash, state evolution, context/admission cost or a
scalar saving. Parent-run original-Wasm/DD/compute/stream contracts and the
later isolated matrix remain separate evidence. No benchmark or profile was
run by this proof driver.
