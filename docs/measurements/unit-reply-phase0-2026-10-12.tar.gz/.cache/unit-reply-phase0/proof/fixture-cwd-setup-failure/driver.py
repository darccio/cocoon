#!/usr/bin/env python3
"""Build/run ignored functional proofs; never benchmark or edit production."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
ROUND = HERE.parent
GO = ROOT / '.cache/toolchains/go1.26.8/go/bin/go'
PINNED_PROBE = 'bea19308a873061507dc0032df77378bbfb7f5f58550d7db62d0622c2d3952f6'
PINNED_ORIGINAL = '607103f216fb1da1445e705deaea8891f21cbdd04f74e385f4958795ef107d74'
PINNED_FIXTURE = 'ddf789ab03a5a3932cf20998a9e8f6cb0c2c0aba2d54e5f040116c82079842d8'
ROLES = ['baseline', 'control', 'probe']
MUTANTS = ['skip-empty-range', 'nonempty-early', 'second-memory-fallback', 'skip-post-memory']

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def prepare():
    original = ROOT / 'rt/instance.go'
    probe = ROUND / 'probe-instance.go'
    assert sha(original) == PINNED_ORIGINAL, 'original runtime drift'
    assert sha(probe) == PINNED_PROBE, 'probe runtime drift'
    fixture_path = ROOT/'internal/gen/gogen/unit_fixture_test.go'
    assert sha(fixture_path) == PINNED_FIXTURE, 'unit fixture drift'
    fixture = fixture_path.read_text()
    inventory = {'pinned_original': PINNED_ORIGINAL, 'pinned_probe': PINNED_PROBE,
                 'pinned_fixture': PINNED_FIXTURE,
                 'virtual_test': str(ROOT/'rt/unit_phase0_extra_test.go'),
                 'test_sha256': sha(HERE/'unit_phase0_extra_test.go'),
                 'canonical_overlay_sha256': {}, 'proof_overlay_sha256': {},
                 'mutant_source_sha256': {}, 'fixture_overlay_source_sha256': {}}
    overlays = {}
    for role in ROLES:
        canonical = ROUND / f'{role}-overlay.json'
        overlay = json.loads(canonical.read_text())
        overlay['Replace'][str(ROOT/'rt/unit_phase0_extra_test.go')] = str(HERE/'unit_phase0_extra_test.go')
        path = HERE / f'{role}-extra-overlay.json'
        assert fixture.count('"GOFLAGS=-buildvcs=false"') == 1
        altered_fixture = fixture.replace('"GOFLAGS=-buildvcs=false"', '"GOFLAGS=-buildvcs=false -overlay='+str(path)+'"')
        output_line = '\toutput, err := command.CombinedOutput()'
        assert altered_fixture.count(output_line) == 1
        altered_fixture = altered_fixture.replace(output_line,
            '\tt.Logf("unit phase0 child compiler=%q argv=%q directory=%q overlay=%q CGO_ENABLED=%q GOARCH=%q", command.Path, command.Args, command.Dir, "'+str(path)+'", cgo, os.Getenv("GOARCH"))\n'+output_line+'\n\tt.Logf("unit phase0 child raw output:\\n%s", output)')
        altered_path = HERE/f'{role}-unit_fixture_test.go'
        altered_path.write_text(altered_fixture)
        overlay['Replace'][str(fixture_path)] = str(altered_path)
        path.write_text(json.dumps(overlay, indent=2)+'\n')
        inventory['canonical_overlay_sha256'][role] = sha(canonical)
        inventory['proof_overlay_sha256'][role] = sha(path)
        inventory['fixture_overlay_source_sha256'][role] = sha(altered_path)
        overlays[role] = overlay
    source = probe.read_text()
    empty = '\tif status == OK && size == 0 {\n\t\t_, err := Range(memory, pointer, 0)\n\t\treturn err\n\t}'
    tail = '\treturn unitReplyTail(op, status, memory, pointer, size)'
    post = '\tif uint64(len(i.module.Memory())) > i.limits.MaxMemory {\n\t\ti.poison()\n\t\treturn fmt.Errorf("%s: %w: linear memory exceeded maximum", op, ErrTooLarge)\n\t}'
    assert source.count(empty) == source.count(tail) == 1
    assert source.count(post) == 2
    mutated = {
        'skip-empty-range': source.replace(empty, '\tif status == OK && size == 0 {\n\t\treturn nil\n\t}'),
        'nonempty-early': source.replace(empty, '\tif status == OK && size != 0 {\n\t\treturn ErrProtocol\n\t}\n'+empty),
        'second-memory-fallback': source.replace(tail, '\treturn unitReplyTail(op, status, c.instance.module.Memory(), pointer, size)'),
        'skip-post-memory': source.replace(post, '\t_ = i.module.Memory()'),
    }
    for name, text in mutated.items():
        path = HERE / f'{name}-instance.go'
        path.write_text(text)
        overlay = json.loads(json.dumps(overlays['probe']))
        overlay['Replace'][str(original)] = str(path)
        overlay_path = HERE / f'{name}-extra-overlay.json'
        overlay_path.write_text(json.dumps(overlay,indent=2)+'\n')
        inventory['mutant_source_sha256'][name] = sha(path)
        inventory['proof_overlay_sha256'][name] = sha(overlay_path)
    (HERE/'source-provenance.json').write_text(json.dumps(inventory,indent=2)+'\n')

def environment(arch):
    env = os.environ.copy()
    env.update({'CGO_ENABLED':'0', 'GOTOOLCHAIN':'local', 'GOARCH':arch,
                'GOCACHE':str(ROOT/'.cache/go'), 'PATH':str(GO.parent)+':'+env.get('PATH','')})
    env.pop('UNIT_PHASE0_MUTANT',None)
    return env

def execute(argv, env, log, expect=None):
    result = subprocess.run(argv,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (HERE/log).write_bytes(result.stdout)
    record = {'utc':datetime.now(timezone.utc).isoformat(), 'argv':list(map(str,argv)),
              'cwd':str(ROOT), 'env':{key:env[key] for key in ['CGO_ENABLED','GOTOOLCHAIN','GOARCH','GOCACHE','PATH']},
              'mutant':env.get('UNIT_PHASE0_MUTANT'), 'exit':result.returncode, 'log':log,
              'raw_sha256':sha(HERE/log)}
    with (HERE/'command-records.jsonl').open('a') as output:
        output.write(json.dumps(record)+'\n')
    if expect == 'semantic-failure':
        assert result.returncode != 0 and b'--- FAIL: TestUnitPhase0MutantProbe' in result.stdout and b'unit semantic mismatch' in result.stdout, (log,result.returncode)
    else:
        assert result.returncode == 0, (log,result.returncode)
    print('PASS',log,'expected semantic rejection' if expect else '',flush=True)

def build(arch):
    env = environment(arch)
    for role in ROLES+MUTANTS:
        execute([str(GO),'test','-c','-pgo=off','-overlay='+str(HERE/f'{role}-extra-overlay.json'),
                 '-o',str(HERE/f'{role}-{arch}.test'),'./rt'],env,f'{role}-{arch}-build.log')
    for role in ROLES:
        execute([str(GO),'test','-c','-pgo=off','-overlay='+str(HERE/f'{role}-extra-overlay.json'),
                 '-o',str(HERE/f'{role}-fixture-{arch}.test'),'./internal/gen/gogen'],
                env,f'{role}-fixture-{arch}-build.log')

def run(arch):
    for role in ROLES:
        execute([str(HERE/f'{role}-{arch}.test'),'-test.run=^TestUnitPhase0','-test.v'],
                environment(arch),f'{role}-{arch}.log')
    for role in MUTANTS:
        env = environment(arch)
        env['UNIT_PHASE0_MUTANT'] = role
        execute([str(HERE/f'{role}-{arch}.test'),'-test.run=^TestUnitPhase0MutantProbe$','-test.v'],
                env,f'{role}-{arch}.log','semantic-failure')
    for role in ROLES:
        execute([str(HERE/f'{role}-fixture-{arch}.test'),'-test.run=^TestGeneratedUnitReplyFixture$','-test.v'],
                environment(arch),f'{role}-fixture-{arch}.log')

mode = sys.argv[1]
if mode == 'prepare':
    prepare()
elif mode == 'build-run-amd64':
    build('amd64'); run('amd64')
elif mode == 'build-386':
    build('386')
elif mode == 'run-386':
    run('386')
else:
    raise SystemExit('unknown mode: '+mode)
