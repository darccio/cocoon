# Unit-reply phase-0 applied overlay audit

Read-only review of the ignored authored runtime/generator overlays at merged head 6be39801bd208e74416578912e9344be06e856b6. No build, test, lint, profile, benchmark, tracked-source edit, or production design performed by this reviewer.

## Disposition

No source-level semantic blocker for this narrowly pinned diagnostic. This is not approval for production retention or a new ABI. Executable proof/query/error/lifetime instrumentation and the frozen measurement matrix still need final review before timing.

The runtime probe differs from the original solely in the existing ResultUnit body and the appended private unitReplyTail. Range, ResultView, public locked Call, held-lock checked, Instance/Call layout, input machinery, reset, post-memory check, poisoning and Close are exact original bytes. The fast empty-OK path preserves the logical-memory zero-size Range check. Both paths query module.Memory once, before descriptor validation. The cold tail receives that same slice and has no module/interface access or receiver. Descriptor Range8, little-endian fields, MaxOutput, payload Range, status translation, then nonempty successful-unit rejection retain their order and error carriers. FromStatus remains unchanged and owns expected-error text; it intentionally does not add UTF-8 validation. The independent post-call Memory query is preserved.

All three baseline facades reproduce tracked bytes. A direct source substitution check proves the control facades differ only in two DD unit method tails (Add and AddMany), one compute unit tail (TestTrap), and one streaming unit tail (Fault). All change ResultView plus empty-unit validation to the existing ResultUnit call. Non-unit decode, constructors, already-ResultUnit destructor callbacks, variable input validation/reservation/encoding, lifetime admission, resource ownership and checked Batch stay exact. Canonical timing overlays contain only the authored gogen mapping, these facades, and (probe only) the runtime mapping. Proof instrumentation must remain outside these maps. The runtime baseline and runtime control compiled hashes are identical in the recorded build log; the reviewed log reports zero exits for the three whole-oracle suites and nine compiled binaries. This reviewer did not run those commands.

The three-way comparison is necessary: ordinary facade baseline, changed ResultUnit call-shape control with original runtime, and the same facade with specialized ResultUnit. A probe-versus-baseline difference alone conflates call shape and specialization; probe-versus-control includes code layout effects and is not a precise additive attribution. Component/profile fractions are not nanosecond ceilings for the full facade. The 1e9 iteration component cap corresponds to about 8.6 seconds, not a completed requested 10 seconds.

The fresh official Go 1.26.8 archive is recorded at d0f743b33e8d8945e6b1f432edd15785c70507121d6e2a723b21285eddf8b57b. Historical 74af... and fresh c73d... baselines differ after GOROOT/compiler distribution relocation with prior source identities checked; all primary comparisons must use these same freshly matched compiler inputs. The system Go 1.26.9 preflight is excluded and retained as provenance; quality Go 1.27.2 is separate.

## Remaining pre-freeze checks

Require exact one captured reply-memory query (plus the original independent post-memory query) including slow/error paths, alternating-memory/getter-panic tests with initialization counter reset, descriptor and zero-size logical bounds, limit/range/status/nonempty error precedence, owned invalid-UTF8 expected-error messages after overwrite, post-memory superseding-error poisoning, stale/panic call-state reset, resource aliases and Close drain. Mutants must fail semantic assertions. Require both source/build controls and actual measured-leaf processor settings across scalar/corpora/SQL/batch/trace/streaming/fresh-reference roles; preserve all samples and guard negatives. No additive profile subtraction, historical-linked-binary gain, scalar claim, or M1 acceptance follows from the current evidence.

## Reviewed identities

```json
{
  "rt/instance.go": "607103f216fb1da1445e705deaea8891f21cbdd04f74e385f4958795ef107d74",
  "internal/gen/gogen/gogen.go": "c26dc4d527d70c10a24a67e7b5f10d3414215b6453908192874ae98ac388a1d4",
  ".cache/unit-reply-phase0/prepare-probe.py": "077a8c24ee371121504e347f19ed20599139f480dda4145a58a81411d549e2b9",
  ".cache/unit-reply-phase0/generate_facade.go": "0befa83aaa4754a7687d206075ae3d3adb64282b03f6ec73709aacd06c047462",
  ".cache/unit-reply-phase0/probe-instance.go": "bea19308a873061507dc0032df77378bbfb7f5f58550d7db62d0622c2d3952f6",
  ".cache/unit-reply-phase0/unit-gogen.go": "86bc72bc044dfa521afad5e5d09735fb6e9d25e7d0f93c39b104b13c7069300b",
  ".cache/unit-reply-phase0/baseline-overlay.json": "b3d17abb4df6e7981bbacf51ccb3040f509add6a7f642d3f8daa35a54c7c8484",
  ".cache/unit-reply-phase0/control-overlay.json": "07ddf147fdcf1025890879ff96bfebcbf30cedacf580646a24b8167be4a1eb44",
  ".cache/unit-reply-phase0/probe-overlay.json": "7c4dc75db04b5d176cc592c4cf57cd76f42d95ea2b2c3532080879be5b4d95fc",
  ".cache/unit-reply-phase0/dd-baseline-facade.go": "3d5aeacda6069a347a0e91e7840792ec194b0cdfd414f3c33328ec037231d672",
  ".cache/unit-reply-phase0/dd-unit-facade.go": "c5dd266c5e5bc03afe72f8a1778dbbfc46d074acfc25e2e9a0f1a8b507881f24",
  ".cache/unit-reply-phase0/compute-baseline-facade.go": "708d440a9d1f7b2bc50c70210865aa8f32ae19ec84cd2d97dff6d70d1f305e7a",
  ".cache/unit-reply-phase0/compute-unit-facade.go": "e93e89a120eb1d70f8aca546b38f48cbcdd78535c29298982fea226b9782405f",
  ".cache/unit-reply-phase0/streaming-baseline-facade.go": "b95c42a8c5ba4dfd0c08f8838dbb3ad99699c98f7c85bbba08ce437e8482c725",
  ".cache/unit-reply-phase0/streaming-unit-facade.go": "7c85bc8083af54924e6d5eefe4955050100247df2f24886f64889e8391e38f6e"
}
```
