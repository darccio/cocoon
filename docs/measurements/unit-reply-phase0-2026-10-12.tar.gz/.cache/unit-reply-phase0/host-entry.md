# Host entry: checked unit replies, existing ABI phase 0

Read-only audit at clean merged main `6be39801bd208e74416578912e9344be06e856b6`,
local task/unit-reply-phase0, 2026-10-12. No builds, tests, lint, profiles or
benchmarks. This ignored note is the only write; tools stop after the note.

## Existing behavior and exact observation order

Generated ordinary unit methods call the real typed guest export, then
`ResultView(op,status)`, then reject a nonempty success with `ErrProtocol`.
Generated destructor closures already use `ResultUnit`; that method is currently
ResultView plus the same empty-shape check. Scalar Sketch.Add has NO Reserve,
input copy, pool borrow, or Trim; AddMany still reserves/encodes variable input
before invoking its export. Constructors decode a u64 handle, not a unit reply.
Typed Batch owns reply-byte accounting through ResultView and must remain
outside this unit emitter experiment.

ResultView performs these operations, in this order:

1. Obtain CURRENT `module.Memory()` exactly once for this reply.
2. Bound the cached fixed descriptor address's eight bytes by LOGICAL length,
   using widened uint64 addition, and read little-endian pointer and size.
3. Reject size above MaxOutput with ErrTooLarge.
4. Bound the ENTIRE payload pointer/size by this same captured memory view.
   Pointer equal to len is valid for size0; pointer beyond len is invalid even
   for size0. Spare backing capacity does not make an address legal.
5. Decode non-OK status with FromStatus and owned error text. Pending/unknown/
   negative statuses are protocol faults; ErrApp/ErrArg/ErrHandle/ErrLimit remain
   healthy when their descriptor/payload and post-call memory are valid.
6. For a unit operation, reject nonempty successful payload with ErrProtocol.

Thus descriptor bounds win over MaxOutput, MaxOutput wins over payload bounds
and status, payload bounds win over status/unit shape, and valid expected errors
win over unit empty-shape checking. Do not reject a nonempty unit immediately
after reading size: it skips payload validation/error detail and can change
precedence. A size33/MaxOutput32 + bad pointer + Pending result returns healthy
ErrTooLarge, not a protocol error; the authored fixture tests this exact case.

Memory is an interface method, not a declared pure accessor. A naive ResultUnit
that reads Memory, then calls ResultView for a cold case, observes it twice and
may validate a different backing/header, trigger a different panic, or produce
a different error. Capturing one view then rereading it through `Call.Range`
has the same defect. A fast/slow split must pass the captured memory and decoded
descriptor to the cold path, without another Memory call or descriptor reread.
No view may survive another guest invocation, growth, or execution lock release.
Do not cache memory or descriptor contents across calls.

## Checked boundary and lifetime invariants

Instance.Call remains unchanged: execution mutex, closed/poisoned checks,
deferred direct recovery, host panic clearing, FULL Call state reset, invoke,
separate CURRENT post-call Memory observation/MaxMemory check, protocol poison.
The post-call memory read is additional to the reply's one read; preserve it.
For normal successful/error-returning scalar calls this is one reply query plus
one post-call query. Panic paths unwind through recovery and have their own
original query counts/order; preserve rather than invent a uniform total.
If post-memory exceeds MaxMemory, ErrTooLarge and poisoning override a prior
callback error. Immediate protocol poisoning invalidates epochs/aliases; healthy
expected errors and reply-output-limit errors must not poison on their own.

Library admission/draining Close, resource cell lock/alive/epoch validation,
KeepAlive, once-only destructor result identity, cancellation and terminal
admission remain unchanged. Destructors intentionally use owner.Close without
new lifecycle admission and still execute their checked Call. Per-slot poisoned
home replacement never migrates handles or invalidates unrelated homes/pool.
Do not add PrepareInput(0), fuse callbacks, change shared checked adapters,
or weaken any check to improve the diagnostic.

## Narrow ignored prototype and controls

Freeze complete current `rt/instance.go`, generator emitter and generated DD
facade source hashes, expected shapes/replacement counts and unchanged Wasm.
Use ignored overlays only. Keep public ResultView/Range/Call bodies byte-for-byte
unchanged if possible; source/assembly placement is still a measured confound.
Keep generated unit methods' nil/admission/ownership/export shape intact.

Three roles are needed:

- Untouched generated ResultView-plus-unit-check baseline.
- Same generated unit call sites switched to EXISTING unchanged ResultUnit,
  retaining its ResultView-plus-length body. This is the call-shape control,
  including existing destructor use and helpers' compiler/frame/linkage effects.
- Identical unit call sites but ignored ResultUnit specialization. Read Memory
  once, check/parse the descriptor, enforce MaxOutput, and only for OK+size0
  validate Range(capturedMemory,pointer,0) then return. For all other cases a
  private cold helper receives capturedMemory/pointer/size and performs original
  payload Range, FromStatus, and empty-unit shape checks in their original order.
  It must not reacquire Memory or reread the descriptor. This can avoid returning
  a borrowed slice on the common unit path without removing ABI3 validation.

This phase-0 duplicated/pinned cold logic is diagnostic, not a retained second
hand-maintained validation policy. A credible ceiling would precede a separately
committed private generic specification with shared authored policy/drift proof.
No production specification/implementation or public ABI change is authorized
by this experiment. If it fails, park it and retain evidence rather than broaden
the scope/choose new benchmarks. Versioned payload-free typed returns are a
different contract requiring compatibility design and explicit operator approval.

## Existing proof and missing adversarial observations

The compiled generated unit fixture exercises ordinary resource+stateless unit
methods, real generated destructor closures, canonical empty at len, nonempty
success, logical descriptor shrink, empty/payload out-of-bounds, uint32 overflow,
reserved/unknown/negative status, invalid expected-error payload, output-limit
precedence, owned error text after memory mutation, once-only alias Close,
home replacement/siblings, pool reuse, and draining terminal Close. Runtime
tests independently replace the backing store and shrink logical len below a
cached descriptor while retaining cap. Execute these existing authored proofs
against every role before any measurements; retained generated artifacts alone
would not prove emitter behavior.

Add ignored exact observation-count adversaries for the prototype: reset query
counters after initialization; successful unit, healthy expected error, output
limit, malformed descriptor/payload, invalid status, nonempty success and Memory
panic. An adversarial Memory returns a different valid view or shrinks/replaces
on its SECOND query; the original result must depend on the FIRST reply query,
while the separate post-memory check still sees the second. Verify error type,
message/ownership, exact Memory query events, poison/epoch, guest export counts
and recovery on the next healthy call. Include zero-length logical memory with
spare cap and pointer0/len/len+1/MaxUint32. No borrowed slice escapes or survives
another export. GC/lifetime tests must create only the resources under test;
unrelated discarded resource cleanup previously caused a fixture flake.

## Measurement/decision limits

The last matching scalar profile attributes10.42% cumulatively to ResultView.
It overlaps other frames and includes mandatory work; it is not additive to
guest/admission shares and does not predict a10.42% saving. Fresh matching
profiles/ordinary optimized assembly must show the actual helper/caller shape.
Do not time SSA/profile binaries or mix timing with builds/tests/review tools.

Fresh identical-harness alternating/reversed qualification should compare full
generated scalar against BOTH untouched and call-shape controls, preserve
negative/increasing/broad scalar, original/varied/held-out SQL, all batch/trace
and P16 complete-lifetime stream controls, current memory/growth and allocations,
independent fresh reference/M1 limits, and all negative directions. Original
layer leaves require explicit framework policy; matched P1/P16 leaves report
actual processor count after the timer. Profile shares and separately calibrated
layers remain nonadditive; state trajectories/calibrated prefixes differ.
Helper placement has shifted unrelated SQL/scalar before. Prior ResultView/Call
factoring/reset/recovery shapes repeatedly regressed scalar, so keep those
boundaries unchanged and include shape/control comparisons. No raw/unit-only
microbenchmark result or nondetection accepts M1 or proves facade equivalence.
