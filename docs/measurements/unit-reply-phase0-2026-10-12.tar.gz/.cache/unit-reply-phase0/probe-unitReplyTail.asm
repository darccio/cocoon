TEXT dario.cat/cocoon/rt.unitReplyTail(SB) /home/dario/Code/cocoon/rt/instance.go
  instance.go:379	0x5c8320		493b6610		CMPQ SP, 0x10(R14)							
  instance.go:379	0x5c8324		0f86fc000000		JBE 0x5c8426								
  instance.go:379	0x5c832a		55			PUSHQ BP								
  instance.go:379	0x5c832b		4889e5			MOVQ SP, BP								
  instance.go:379	0x5c832e		4883ec40		SUBQ $0x40, SP								
  instance.go:379	0x5c8332		4889442450		MOVQ AX, 0x50(SP)							
  instance.go:379	0x5c8337		48897c2468		MOVQ DI, 0x68(SP)							
  instance.go:71	0x5c833c		4489ca			MOVL R9, DX								
  instance.go:71	0x5c833f		4589d2			MOVL R10, R10								
  instance.go:71	0x5c8342		4c01d2			ADDQ R10, DX								
  instance.go:72	0x5c8345		4839d6			CMPQ SI, DX								
  instance.go:72	0x5c8348		721d			JB 0x5c8367								
  instance.go:75	0x5c834a		4589c9			MOVL R9, R9								
  instance.go:75	0x5c834d		4c29ca			SUBQ R9, DX								
  instance.go:75	0x5c8350		4989d2			MOVQ DX, R10								
  instance.go:75	0x5c8353		48f7da			NEGQ DX									
  instance.go:75	0x5c8356		48c1fa3f		SARQ $0x3f, DX								
  instance.go:75	0x5c835a		4921d1			ANDQ DX, R9								
  instance.go:75	0x5c835d		4a8d140f		LEAQ 0(DI)(R9*1), DX							
  instance.go:75	0x5c8361		31f6			XORL SI, SI								
  instance.go:75	0x5c8363		31ff			XORL DI, DI								
  instance.go:380	0x5c8365		eb64			JMP 0x5c83cb								
  instance.go:72	0x5c8367		894c2460		MOVL CX, 0x60(SP)							
  instance.go:72	0x5c836b		44898c2480000000	MOVL R9, 0x80(SP)							
  instance.go:71	0x5c8373		4889542438		MOVQ DX, 0x38(SP)							
  instance.go:72	0x5c8378		48895c2458		MOVQ BX, 0x58(SP)							
  instance.go:72	0x5c837d		4889742470		MOVQ SI, 0x70(SP)							
  instance.go:72	0x5c8382		4889442450		MOVQ AX, 0x50(SP)							
  instance.go:73	0x5c8387		488d05128f2c00		LEAQ 0x2c8f12(IP), AX							
  instance.go:73	0x5c838e		e88d9ee5ff		CALL runtime.newobject(SB)						
  instance.go:73	0x5c8393		8b8c2480000000		MOVL 0x80(SP), CX							
  instance.go:73	0x5c839a		894810			MOVL CX, 0x10(AX)							
  instance.go:73	0x5c839d		488b4c2438		MOVQ 0x38(SP), CX							
  instance.go:73	0x5c83a2		488908			MOVQ CX, 0(AX)								
  instance.go:73	0x5c83a5		488b4c2470		MOVQ 0x70(SP), CX							
  instance.go:73	0x5c83aa		48894808		MOVQ CX, 0x8(AX)							
  instance.go:384	0x5c83ae		8b4c2460		MOVL 0x60(SP), CX							
  instance.go:385	0x5c83b2		488b5c2458		MOVQ 0x58(SP), BX							
  instance.go:385	0x5c83b7		488d35e2d03300		LEAQ go:itab.*dario.cat/cocoon/rt.memoryRangeError,error(SB), SI	
  instance.go:385	0x5c83be		4531d2			XORL R10, R10								
  instance.go:385	0x5c83c1		31d2			XORL DX, DX								
  instance.go:380	0x5c83c3		4889c7			MOVQ AX, DI								
  instance.go:385	0x5c83c6		488b442450		MOVQ 0x50(SP), AX							
  instance.go:381	0x5c83cb		4885f6			TESTQ SI, SI								
  instance.go:381	0x5c83ce		754a			JNE 0x5c841a								
  instance.go:384	0x5c83d0		85c9			TESTL CX, CX								
  instance.go:384	0x5c83d2		741d			JE 0x5c83f1								
  instance.go:380	0x5c83d4		4c89542430		MOVQ R10, 0x30(SP)							
  instance.go:385	0x5c83d9		4889d7			MOVQ DX, DI								
  instance.go:385	0x5c83dc		4c89d6			MOVQ R10, SI								
  instance.go:385	0x5c83df		4989f0			MOVQ SI, R8								
  instance.go:385	0x5c83e2		e859dfffff		CALL dario.cat/cocoon/rt.FromStatus(SB)					
  instance.go:385	0x5c83e7		4885c0			TESTQ AX, AX								
  instance.go:385	0x5c83ea		7528			JNE 0x5c8414								
  instance.go:389	0x5c83ec		4c8b542430		MOVQ 0x30(SP), R10							
  instance.go:389	0x5c83f1		4d85d2			TESTQ R10, R10								
  instance.go:389	0x5c83f4		7414			JE 0x5c840a								
  instance.go:390	0x5c83f6		488b0543847000		MOVQ dario.cat/cocoon/rt.ErrProtocol(SB), AX				
  instance.go:390	0x5c83fd		488b1d44847000		MOVQ dario.cat/cocoon/rt.ErrProtocol+8(SB), BX				
  instance.go:390	0x5c8404		4883c440		ADDQ $0x40, SP								
  instance.go:390	0x5c8408		5d			POPQ BP									
  instance.go:390	0x5c8409		c3			RET									
  instance.go:392	0x5c840a		31c0			XORL AX, AX								
  instance.go:392	0x5c840c		31db			XORL BX, BX								
  instance.go:392	0x5c840e		4883c440		ADDQ $0x40, SP								
  instance.go:392	0x5c8412		5d			POPQ BP									
  instance.go:392	0x5c8413		c3			RET									
  instance.go:386	0x5c8414		4883c440		ADDQ $0x40, SP								
  instance.go:386	0x5c8418		5d			POPQ BP									
  instance.go:386	0x5c8419		c3			RET									
  instance.go:382	0x5c841a		4889f0			MOVQ SI, AX								
  instance.go:382	0x5c841d		4889fb			MOVQ DI, BX								
  instance.go:382	0x5c8420		4883c440		ADDQ $0x40, SP								
  instance.go:382	0x5c8424		5d			POPQ BP									
  instance.go:382	0x5c8425		c3			RET									
  instance.go:379	0x5c8426		4889442408		MOVQ AX, 0x8(SP)							
  instance.go:379	0x5c842b		48895c2410		MOVQ BX, 0x10(SP)							
  instance.go:379	0x5c8430		894c2418		MOVL CX, 0x18(SP)							
  instance.go:379	0x5c8434		48897c2420		MOVQ DI, 0x20(SP)							
  instance.go:379	0x5c8439		4889742428		MOVQ SI, 0x28(SP)							
  instance.go:379	0x5c843e		4c89442430		MOVQ R8, 0x30(SP)							
  instance.go:379	0x5c8443		44894c2438		MOVL R9, 0x38(SP)							
  instance.go:379	0x5c8448		448954243c		MOVL R10, 0x3c(SP)							
  instance.go:379	0x5c844d		e84e68ecff		CALL runtime.morestack_noctxt.abi0(SB)					
  instance.go:379	0x5c8452		488b442408		MOVQ 0x8(SP), AX							
  instance.go:379	0x5c8457		488b5c2410		MOVQ 0x10(SP), BX							
  instance.go:379	0x5c845c		8b4c2418		MOVL 0x18(SP), CX							
  instance.go:379	0x5c8460		488b7c2420		MOVQ 0x20(SP), DI							
  instance.go:379	0x5c8465		488b742428		MOVQ 0x28(SP), SI							
  instance.go:379	0x5c846a		4c8b442430		MOVQ 0x30(SP), R8							
  instance.go:379	0x5c846f		448b4c2438		MOVL 0x38(SP), R9							
  instance.go:379	0x5c8474		448b54243c		MOVL 0x3c(SP), R10							
  instance.go:379	0x5c8479		e9a2feffff		JMP dario.cat/cocoon/rt.unitReplyTail(SB)				
