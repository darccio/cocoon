# Guest outcome audit: descending store32 phase zero

**Verdict: strict no-go for production consideration.** The primary original
checked scalar does not improve against untouched baseline in both rounds.
Its screen is 87.81→88.03 ns/op (+0.25%, p=.620); confirmation is
88.02→86.71 ns/op (−1.49%, p=.005). The repeated original-workload criterion
fails even though probe beats copied-check control in both rounds
(−1.47%, p=.007; −2.25%, p=.002). This is uncertainty in the primary screen,
not proof that the transformation universally has no benefit.

Values checked against `outcome-table.md`, `paired/summary.json`, and primary
probe/control time-benchstat files. Increasing P1 has repeated detected wins
versus baseline (−2.55%, p=.001; −1.28%, p=.001) and copied-check control
(−1.76%, p=.005; −1.25%, p=.001). Repeated batch1024 beats baseline twice
(−1.05%, p=.011; −1.18%, p=.029), but its copied-check confirmation is
−0.63%, p=.073. Raw guest is −1.34%, p=.097 then −1.01%, p=.005 versus
baseline, so it also does not provide a repeated primary gain. These positives
must remain in the record; they do not override the predeclared original
scalar requirement.

The scalar, increasing, repeated-batch, and raw-guest medians retain zero Go
allocation bytes/count. P1 increasing and repeated-batch medians report
1,179,648 guest bytes and zero measured guest-memory growth in all three
roles. Zero memory growth does not make the state immutable: sketch counts
and bin weights continue to evolve. Other scalar/broad/SQL/batch/trace and
stream controls do not establish a repeated baseline regression or a general
speedup. The negative-bin screen p=.053 and varied-scalar confirmation p=.073
are undetected results. Large streaming point deltas with high p-values must
be retained as uncertain observations; unchanged streaming role binaries
cannot establish a guest-store optimization effect there.

## Actual experiment and machine scope

The ignored SHA-pinned postpass selects **exactly two calls**: the lower
captured publication store in fn176 at source line 36221, and the lower metadata
store in Xcocoon_sketch_add at line 48615. It does not select all three literal
metadata triples mentioned in the entry review, nor preserve store-to-load
facts, nor implement a generic structural predicate. The control and probe
modules route those same calls to `cocoonStore32InKnownRange`; their sole
source difference is restoration/deletion of the copied unsafe-path
`_ = mem[uint64(addr)+3]`. Original first checks, later new-maximum checks,
all stores, addresses, values, fallback bounds checks, endian conversion,
signature, and nosplit remain. Current probe helper/module pin matches the
proof metadata (module 999dc659…, helper 0f01eba8…).

Machine summary confirms one fewer static panic-bounds site in each selected
method: fn176 78→77 and scalar export 57→56. Both method text sizes and frames
are unchanged (5462 B/128 B and 3004 B/112 B). Instruction counts change
1309→1307 and 642→643. This is not a proven register-spill/frame reduction or
proof that every timing difference is caused by the two deleted guards.
The copied-check control has the original selected-method sizes/counts but a
different linked binary; source-equivalent controls do not cancel every
placement effect. SQL fn96 and host reply/Range/Add callback sizes/counts are
unchanged in the summary, so unrelated control movements are not evidence of
a rewritten SQL/reply algorithm.

## Proof scope and limitations

Actual helper text is completely pinned against canonical store32 with only
rename plus the single unsafe endpoint deletion. Independent explicit logical
range and byte encoding check full current/old backing, values/evaluation
events, trap stage, and completed-write prefix. The retained logs demonstrate
28 models, two carrier controls, seven direct typed caller cases, four
separately labelled fallback/byte-swap controls, and five bounded semantic
mutants. Both real native amd64 and native 386 pass with official Go1.26.8,
CGO disabled/PGO off; 386 executes the built binary with escalation. A host-toolchain
`go version` string says linux/amd64 even when compiling GOARCH=386: the
recorded GOARCH build command and native executable run establish that scope.

The five mutants require a nonzero child exit plus an explicit failing test
and `store-prefix mismatch`, rather than accepting compiler/setup failures.
Spare backing bounds the unchecked mutant addresses safely. Native canonical
oracle is always Wasm LittleEndian; simulated byte-swap tests do not establish
actual big-endian support. Header/import/impure-value examples model barriers,
and extra overlap models are not additional selected sites. This is a bounded
native helper/caller proof, not WAT-to-Go eligibility, ownership acceptance on
arbitrary translated input, or a generic hardener/effect-system proof. Parent
guest differential/contract oracles are separate evidence.

The parent reports 966 retained timing rows and 411 unchanged frozen hashes.
Quality gates are running separately after timing; this note does not claim
their completion. Retain measurements/proof/provenance and negative findings
only. No production pass, generic specification, public contract, standalone
latency improvement, or M1 acceptance follows. No builds, tests, profiles,
measurements, or tracked edits were performed during this final audit.
