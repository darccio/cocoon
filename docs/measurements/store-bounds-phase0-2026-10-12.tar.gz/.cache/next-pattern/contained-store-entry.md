# Host source/ordinary-assembly finding: contained store32 checks

2026-10-12, read-only at clean4f9276a; no builds, tests, profiling or timing.
Only this ignored note is written. Existing .cache/unit-reply-phase0 ordinary
baseline artifacts use the pinned official Go1.26.8 toolchain and unchanged
production module626550ca…. Their source still matches this docs-only HEAD,
but fresh matching profiling/assembly is required before a new performance claim.

## Positive machine finding, with two distinct publication sites

There ARE surviving covered store32 checks. Keep terminology precise:

1. Scalar export's HOT successful unit publication is source48613–48616:

   ```go
   t42 := int32(load32(m.memory, uint32(i32(1101796))))
   store32(m.memory, uint32(i32(1101804)), uint32(t42))
   store32(m.memory, uint32(i32(1101800)), uint32(i32(0)))
   store32(m.memory, uint32(i32(1101808)), uint32(i32(0)))
   ```

   Output export returns1101804 (source48640), so canonical descriptor pointer
   word is1101804 and size word1101808. The intervening lower1101800 store is
   buffer metadata, not the second descriptor word. Store endpoints, in order,
   are1101807,1101803,1101811. The MIDDLE endpoint is covered by the FIRST;
   the LAST is a new maximum and MUST retain its check. This publication has
   no retained slice capture in current source: memory headers reload between
   stores. It is not accurate to describe all three stores as descending, or
   to remove the descriptor-size store's new-maximum guard.

   Existing baseline-Xcocoon_sketch_add.asm shows:

   -0x656e6e CMPQ DX,$0x10cfef;0x656e75 JBE0x656fb1: first endpoint.
   -0x656e81 MOVL DX,0x10cfec(SI): FIRST actual write.
   -0x656e87 MOVQ0x38(CX),DX: header length reloaded after first store.
   -0x656e8b CMPQ DX,$0x10cfeb;0x656e92 JBE0x656fa5: redundant middle endpoint.
   -0x656e9c MOVL$0,0x10cfe8(DX): MIDDLE actual write.
   -0x656eaa CMPQ DX,$0x10cff3;0x656eb1 JBE0x656f94: required new maximum.
   -0x656ebb MOVL$0,0x10cff0(DX): LAST actual write.

   This is successful scalar return branch l5, after actualfn176 and the
   initialized output-buffer state check; it executes for normal unit success.
   All calls/branches before publication still bound the region.

2. fn176's existing captured INTERNAL result tail, source36219–36223:

   ```go
   cocoonMemoryView2 = m.memory
   store32(cocoonMemoryView2, uint64(uint32(v13))+4, uint32(v3))
   store32(cocoonMemoryView2, uint32(v13), uint32(v1))
   m.g0 = v11 + i32(16)
   goto l24
   ```

   Same captured slice, same bound int32 basev13: first endpoint is base+7,
   second base+3. The second check survives even though the header is captured:
   baseline-fn176.asm0x630a45 LEAQ7(R8),R9;0x630a49 CMPQ DI,R9;
   0x630a4c JBE0x630aea;first write0x630a56 MOVL BX,4(R8)(R9*1).
   Then0x630a5b LEAQ3(R8),BX;0x630a60 CMPQ DI,BX;
   0x630a63 JBE0x630ae5;second write0x630a70 MOVL AX,0(R9)(SI*1).
   The compiler did NOT eliminate the lower endpoint proof here.

   This is guest-internal return publication inside the real scalar path, not
   the canonical host descriptor at1101804. Existing preceding-round source
   profiles sample both tail stores in scalar/rawguest, so it is not merely
   an uncalled source pattern. Source-position attribution may cover nearby
   inlined helper instructions; it does not quantify removable ns. The common
   final fn176 tail source36230/base then36231/base+4 instead has RISING store
   endpoints; both store checks remain under a store-only rule.

These are genuinely STORE→covered STORE proofs. No numeric load64→same-address
store64 guard is removed, no old failing scalar pattern is revived. Earlier
publication memory views changed header access, but retained these store checks;
this new fact is about check containment, not recapturing/caching the header.

## Narrow defensible diagnostic

An ignored source/shape-pinned store32-only probe is justified for an attainable
ceiling, subject to fresh hotness. Preserve actual writes, original operands and
their evaluation position, first and every NEW-MAXIMUM checks. Derive a private
helper from the COMPLETE validated canonical store32 body and directives,
deleting only the unsafe branch endpoint check; preserve endian conversion,
nosplit, live unsafe write and checked unaligned fallback. No write fusion,
width change, reordering, read forwarding, store64 selection or public API.

Within a single straight-line region, prove one logical slice header stable and
one unchanged bound base (or exact zero-extended constant address expression).
Canonical stores mutate separately owned backing bytes, not Module/header,
under existing constructor/helper/host ownership proofs. Captured publication
views have their original assignment as a header snapshot but cannot survive
unproved calls/control joins; unknown aliases/imports/growth/header writes/base
rebind/escape/labels reset facts. For direct receiver.memory stores, do not infer
header stability solely from its spelling: retain complete canonical helper
effects, separate Module/backing construction and serialized trusted host proof.
Keep all full ABI3 admission/ownership/current-memory/reply/MaxMemory/poison/reset/
drain behavior unchanged. Nothing permits skipping host descriptor validation.

Test a first high store trapping BEFORE any lower write when logical memory is
short, first successful/second overlapping live writes, lower covered middle
write followed by NEW-MAXIMUM trap with original partial bytes retained, zero/
spare-cap native headers, highbit/widened-width arithmetic, endian/unaligned
fallbacks, import shrink/replace, labels/branches/base/alias rebinding and impure
or shadowed helper/conversion bindings. The two descriptor words must remain
canonical and guest errors/recovery retain exact host classification. Original
Wasm full memory/values/traps/events and nativeamd64/386 should reject mutants
dropping first/new-max checks, reordering writes or crossing header mutation.

Use untouched baseline, ignored probe and COPIED-CHECK restoration control with
the same selected store helper inventory. Profile/SSA and ordinary source/ASM
comparison precede isolated paired timing. Include supported scalar and negative/
increasing/broad holds, SQL/varied/held-out, batches, trace and P1/P16 complete
stream lifetime/topology guards; retain all negative directions/allocations/
current memory/growth and fresh independent reference. No broad pass/spec before
a demonstrated end-to-end ceiling, no addition of old gains, no M1 acceptance.
