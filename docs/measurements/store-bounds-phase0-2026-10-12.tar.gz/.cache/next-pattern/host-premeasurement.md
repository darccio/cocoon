# Final host/control audit before phase-0 freeze

2026-10-12, read-only source/artifact review; no build, tests, profiles or timings.
Only this ignored note is authored. Verdict: READY for the predeclared isolated
phase-0 matrix, with the limitations below. Tools stop after writing this note.

## Actual source/control identities

Verified all three fixture inventory byte hashes against actual files. Baseline
modules equal committed production bytes. Compute and streaming baseline/control/
probe modules are all byte-identical; only DD changes. The authored ignored
hardener postpass pins COMPLETE DD source SHA626550cafa323c490a6a2ec6b2b341656c40e223c7c84701e414078633dcc298
and exact two method/store sequences; nonmatching sources remain untouched.
This is a hash/shape-pinned diagnostic, not generic selection or a production
specification. Runtime/facade/shim/guest Wasm remain unchanged.

Control and probe have the same two private helper call sites and identical
prefix before the appended helper. Their ENTIRE appended-helper diff is only:

```diff
- _ = mem[uint64(addr)+3]
```

Canonical copied store32 retains nosplit, builtin address width, endian handling,
checked portable unaligned fallback, value evaluation and actual unsafe write.
The original318 retained contained-load call sites remain318 in every DD role.
No load64/store64 or unit-return experiment is revived. First/new-maximum
stores still call the original checked helper; every original write is present.

The captured fn176 pair keeps checked base+4 then unchecked-covered base; base+7
successful endpoint proves lower base+3. Actual export triple keeps checked
1101804, rewrites ONLY middle1101800, keeps checked NEW-MAXIMUM1101808. Their
inclusive endpoints1101807/1101803/1101811 stay ordered. Middle1101800 is buffer
metadata, not descriptor size: Output returns1101804 and descriptor size is1101808.
No first/high check is hoisted before a write, and later rising checks remain.

The existing whole-module construction/helper proof establishes separately owned
Module/header/backing and canonical byte stores. Stores can alter overlapping
backing bytes, but no selected call changes the header or local base. Captured
view2 remains the same local slice across its two stores; receiver triple has
no call/import/growth/header mutation between stores. Trusted native hosts must
not race or fabricate a Module/backing alias. Logical length, not cap, remains
the bounds source; width endpoint addition stays widened, not wrapped. All
operand/value evaluation and partial-memory trap order remain original. Native
amd64/386 contracts/differential/bulk and independently rejected mutants are
prerequisites, not claims of generic predicate proof.

## Host boundary unchanged

No public API/schema/ABI change. Nil/context/lifecycle admission and draining
Close, resource cell mutex/alive/epoch/KeepAlive, execution mutex/state checks,
full Call reset, direct deferred recovery/host panic, canonical reply descriptor/
MaxOutput/current-memory payload/status/type checks, separate post-call Memory/
MaxMemory observation and immediate trap/protocol poisoning remain intact.
Expected guest errors remain owned/healthy; once-only aliases and exact home
identity/invalidation/replacement never migrate old handles or affect sibling
homes/pool. No guest slice escapes a call. No R1–R7/R11 runtime reshaping.

## Machine-control limits

Existing machine-code audit reports encoded-byte AND instruction equality for
baseline/control fn176, fn96, Add export, ResultView/ResultUnit/Range and Add inner
callback. This strengthens the copied-check control but is not full executable/
metadata equality. Probe retains their frame/text byte sizes. fn176 static
panic-bounds sites78→77 and instructions1309→1307; export57→56 sites but642→643
instructions. fn96 and runtime methods' counts remain unchanged. One removed
source guard does not guarantee fewer total machine instructions or a removable
ns/share. Changed data/debug/linker/code placement elsewhere and compiler
scheduling remain plausible confounders; all roles stay in final comparisons.

All three actual stream ELFs SHAa2076ad9349c334f028e1c73cc166004c15da1debab79e8d2c349d851bc373bf
are byte-identical. Stream roles are scheduling/bracket controls for unchanged
production, unlike the prior unit-return round's actual changed destructors.
No candidate stream gain or regression resolution may be inferred from labels.

## Qualification matrix and decision

Verified19 groups/69 processes per sample pass. Seven alternating500ms passes
then seven reversed1s passes produce966 rows. Original/matched12 leaves include
untouched/probe/copied-check/fresh independent reference; rawGuest has three
roles; six stream leaves have three identical-binary roles. Required metric
cases per pass are26 actualP1 and12 actualP16, predicting364/168 metric rows;
remaining434 original/raw rows lack in-window metrics. Framework16 and recorded
argv/environment are policy, not a metric from those434 rows.

Streams now include P1 default one-home Fixed/Holdout AND P16 one-home/16-home
Fixed/Holdout, full16KiB New/Write/End/Close lifetimes with nominal64B writes and
Retain32 owned output groups. Complete counts/custom raw writes/s and allocations
must be consumed and actual processor policy bracketed in each measured leaf.
Topology is independently bounded resource homes, with an independent one-slot
pool; no processRSS/fairness/strict-ceiling inference follows from rates.

All binary build argv use exact official pinned Go1.26.8, CGO0/GOAMD64v1/PGOoff;
fresh reference's56 own-source bytes/snapshots and ten command/48 functional
oracle results are preserved. Its own ABI2/context/ownership/four-instance and
original batch/trace input differences remain contextual, not equivalent
contracts. The fresh official reference binary5c4f361a… reproduces; no old
systemGo1.26.8/1.26.9 measurements or ELF hashes are forced into comparison.

Decision rule is sound: original DEFAULT supported scalar must show gains
against BOTH untouched and copied-check controls in BOTH planned rounds, with
no repeated same-comparator scalar/SQL/batch/trace/P1/P16 guard loss. RawGuest,
static guards or profile shares cannot substitute for it. Retain all negatives,
single-round detections, allocations/current guest memory/growth, independent
reference/M1 limits and complete raw samples; unadjusted exploratory p-values,
independent processes and nondetection/equivalence limits stay explicit. No
selected retiming, source-layout tuning, widened selection or dropped safety
checks after failure. A positive ceiling precedes a SEPARATE committed private
generic production specification/proof/qualification; phase0 does not accept M1.
