# Descending store32 phase-0 result audit

Read-only review after all966 timing rows completed. No timing/profile/build/test/lint or tracked edit by this reviewer. Independent raw/statistic/alias/fingerprint inspection; production remains unchanged at the4f9276a documentation entry over merged6be3980 code. Root's quality gates/reproductions are separate sequential post-timing work; no unfinished gate is reported passed here.

## Verdict

Strict NO-GO under the frozen promotion criterion. Original/default scalar had to gain against untouched and copied-check controls in both rounds. Screening87.81→88.03ns is+0.2505%, p=.620; confirmation88.02→86.71ns is−1.4883%, p=.005. Probe beats copied-check control in both (−1.4663% p=.007 /−2.2545% p=.002), but the missing screening untouched gain still fails the conjunction. Evidence-only retention is justified; no production predicate/specification/implementation, contract change, code-layout rescue or selected retiming follows. Do not change the primary to another positive workload after measurement. This rejects the declared evidence threshold, not a proof that a general descending-store optimization can never help.

No repeated detected probe guard loss against either consistent comparator was found in the19 groups. Do not invent a repeated candidate regression as the no-go reason. Upward medians and nondetections remain uncertainty rather than equivalence. The unchanged copied-check trace control does regress2.5615%/4.0378% versus untouched (p=.001 both), while probe-versus-untouched trace differences are undetected(.805/.259). Probe/control trace−2.4925%/−4.9031% cannot be claimed as untouched trace gains or two-store causal savings. Sampled baseline/control encoded instruction bytes are equal despite debug-linked ELF differences; that does not prove the entire executable's placement/runtime equivalence or explain this trace negative.

Matched IncreasingP1 gains against untouched in both (−2.5451%/−1.2821%, p=.001 both) and copied-check in both (−1.7624% p=.005 /−1.2490% p=.001). Preserve this real workload-specific positive result. Repeated1024 batch gains versus untouched both rounds(−1.0469% p=.011 /−1.1819% p=.029), but control confirmation−0.6250% p=.073 is undetected. Varied scalar gains against untouched only in screening(−3.1050% p=.011; confirm−2.2554% p=.073), though it beats control in both. Negative bins/rawGuest are confirmation-only detected gains; their screening p=.053/.097 versus untouched and .073/.073 versus control do not meet repeat detection. SQL/variedSQL/SQLholdout, original batch and broadscalar/batch show no repeated detected probe change. They are not proved equivalent or guaranteed nonregressing.

Every stream role executes the byte-identicala2076ad9349c334f028e1c73cc166004c15da1debab79e8d2c349d851bc373bf binary. All primary/secondary/baseline-control stream comparisons are undetected. Fixed16homes nonetheless has probe median+10.9613%/+3.2541% versus nominal baseline and+8.6854%/+2.6114% versus nominal control. OnehomeP16 holdout screening+4.4423%/+8.5515% and16home holdout+6.1799%/+5.7611% are also visible. P1 fixed median+0.5361%/+0.9612% versus baseline is likewise retained. These are bracket/process/system observations, not effects caused by unchanged DD-only code or a verified streaming gain/regression/equivalence. Distinguish full16KiB New/Write/End/Close/Retain32 P1/P16 lifetime cost from isolated writes. P1 andP16 are now covered, but native module-growth/ownership/drain contracts still require separate proof, not a throughput inference.

## Current production M1 context

Untouched original scalar confirmation88.02ns exceeds55.44ns absolute and fresh110%cap61.358ns from55.78ns reference. Screening87.81ns similarly exceeds fresh61.688ns from56.08ns reference. Confirmation SQL2173ns meets2215.4ns absolute but exceeds fresh1962×1.1=2158.2ns cap by14.8ns; screening2164ns is below its fresh2005×1.1=2205.5ns cap. Do not carry prior narrow SQL median acceptance into this session or use rejected probe outcomes as production. ReferenceABI2/lifetime/ownership/context/corpus differences remain explicit. M1 remains unaccepted.

## Coverage and semantics boundary

Independently verified966 unique complete successful raw process logs, exact row names/binary/selectors/durations/cpu16 commands, iterations/allocation/all custom metrics,138 role/round cells with seven unique samples each, raw→summary medians/samples and metric-preserving normalized aliases. Plan has19 groups as scope;69 processes/pass×14 passes=966, not19×69×14. Metric coverage is364 actualP1(280matchedDD+84defaultP1stream),168 actualP16stream and434 unmodifiedframeworkP16 rows without leaf metrics. Testing suffix16 is not an actualP1 assertion or scalar contention guarantee. All411 frozen current inputs match, and original/paired freeze bytes are identical. No raw rows, outliers, failures or comparisons were selected away. Confirmation is independently reversed-order/longer processes; benchstat tests are exploratory/unadjusted, not paired-statistic causal estimates.

Only the two exact selected lowerstore32 guards differ in the private probe; checked first/newmaximum stores, every write/value/evaluation, pinned owned backing and header, old318 contained reads, scalar arithmetic, guestWasm, runtime/facade/safety and all harness/corpus code remain original. Direct semantic/native helper proofs and actual original-Wasm/full guest oracle suites were reviewed before timing. Function IDs/literal addresses and full source hash remain private diagnostic selectors, not a generic production binding/effect proof. Store check counts each decreaseone, but export instruction count642→643 increases and frames/text remain fixed. Retain that negative machine shape and avoid deriving nanosecond ceilings by adding profile percentages, oldphase0 gains or static instruction counts. A future source-independent pass would require a separately justified spec, WAT/binding/alias/overflow/control proof, authored cause+three proofs/locks, exactstaged/darna/gates+integration/reproductions and fresh qualification.

All local reviewers/builds/tests/fuzz/profiles stopped during root's isolated run; unrelated externalwork cannot be proven absent. Fresh ordinary roles/reference share the official localGo1.26.8, CGO0, amd64v1, PGOoff and frozen conditions. The upcoming evidence archive must retain every raw row, source/proof/reference bytes, failed startup preparation, reviews and post-timing gates; final archive/prose audits are separate. No new production work is justified by this verdict.

## Complete primary/secondary time inventory

Positive latency deltas mean slower; these are not throughput percentages. Each retained comparison is listed without excluding inconclusive or adverse medians.

| Workload | Screen baseline→probe ns/op; vs baseline / control (time delta, p) | Confirm baseline→probe ns/op; vs baseline / control (time delta, p) |
| --- | --- | --- |
| Original-ObfuscateSQL | 2164→2183; +0.8780% p=0.594 / +1.0180% p=0.685 | 2173→2165; -0.3682% p=0.837 / +0.1851% p=0.559 |
| Original-SketchAdd | 87.81→88.03; +0.2505% p=0.620 / -1.4663% p=0.007 | 88.02→86.71; -1.4883% p=0.005 / -2.2545% p=0.002 |
| Original-SketchAddMany1k | 38387→38246; -0.3673% p=0.710 / +0.3095% p=0.535 | 38397→38112; -0.7422% p=0.318 / -0.4259% p=1.000 |
| Original-ObfuscateTraces1k | 2.61694e+06→2.61707e+06; +0.0052% p=0.805 / -2.4925% p=0.001 | 2.60632e+06→2.57861e+06; -1.0633% p=0.259 / -4.9031% p=0.001 |
| Original-SketchAddVaried | 90.5→87.69; -3.1050% p=0.011 / -1.1944% p=0.026 | 89.12→87.11; -2.2554% p=0.073 / -2.7899% p=0.007 |
| Original-ObfuscateSQLVaried | 2701→2726; +0.9256% p=0.737 / -0.1831% p=0.645 | 2708→2712; +0.1477% p=0.902 / +0.2588% p=0.902 |
| Original-SketchAddNegativeBins | 89.35→87.84; -1.6900% p=0.053 / -1.7120% p=0.073 | 88.72→86.71; -2.2656% p=0.017 / -1.8229% p=0.016 |
| MatchedReference-SQLHoldout | 5497→5581; +1.5281% p=0.273 / +1.1967% p=0.274 | 5501→5502; +0.0182% p=1.000 / +0.6586% p=0.274 |
| MatchedReference-Increasing | 90.37→88.07; -2.5451% p=0.001 / -1.7624% p=0.005 | 89.7→88.55; -1.2821% p=0.001 / -1.2490% p=0.001 |
| MatchedReference-BroadScalar | 90.54→89.88; -0.7290% p=0.259 / +0.8075% p=0.559 | 89.65→89.87; +0.2454% p=0.592 / +0.5595% p=0.510 |
| MatchedReference-Repeated1024 | 39165→38755; -1.0469% p=0.011 / -1.9481% p=0.002 | 39258→38794; -1.1819% p=0.029 / -0.6250% p=0.073 |
| MatchedReference-BroadBatch8192 | 314219→316178; +0.6235% p=0.902 / -0.3360% p=0.805 | 314165→313636; -0.1684% p=1.000 / -0.0605% p=1.000 |
| RawGuest-SketchAdd | 53.6→52.88; -1.3433% p=0.097 / -1.0849% p=0.073 | 53.64→53.1; -1.0067% p=0.005 / -1.1909% p=0.002 |
| StreamOneHome-Fixed | 195606→199049; +1.7602% p=0.535 / +1.0652% p=0.902 | 195745→193676; -1.0570% p=0.710 / +0.5926% p=0.902 |
| Stream16Homes-Fixed | 27077→30045; +10.9613% p=0.456 / +8.6854% p=0.383 | 26981→27859; +3.2541% p=0.620 / +2.6114% p=0.620 |
| StreamOneHome-Holdout | 239359→249992; +4.4423% p=0.902 / +8.5515% p=0.620 | 234636→234597; -0.0166% p=1.000 / +0.1913% p=0.805 |
| Stream16Homes-Holdout | 35599→37799; +6.1799% p=0.805 / +5.7611% p=0.383 | 36824→34812; -5.4638% p=1.000 / -2.7353% p=1.000 |
| StreamP1-OneHome-Fixed | 164152→165032; +0.5361% p=0.710 / -1.6935% p=1.000 | 161362→162913; +0.9612% p=0.620 / +1.1649% p=0.456 |
| StreamP1-OneHome-Holdout | 203266→201710; -0.7655% p=0.209 / +0.5453% p=0.620 | 200551→199419; -0.5644% p=0.805 / -0.3209% p=0.805 |

## Audited identities

```json
{
  ".cache/next-pattern/paired/records.jsonl": "669927624d9d8fc275c2e2186aa2a253f67271d7b0c9ba396f7e951d6c743f21",
  ".cache/next-pattern/paired/summary.json": "2381750d2a2b9cf9b2884a07db0cc74ba9128c3c806e374e1ac64c4f15105b22",
  ".cache/next-pattern/paired/complete.json": "8ce918675341a45aa93b607fb291f2dab33dc5b724cc471b13a6aa67f8cb67eb",
  ".cache/next-pattern/paired/run-provenance.json": "c0f78359290bf4d636e08a58e907c0509161206de9c95514645fcc156bc8cb61",
  ".cache/next-pattern/paired/frozen.json": "5998a252da87928e681f3f9357dfadec4a457d7a830b6512f79d29ee2b14da5c",
  ".cache/next-pattern/decision-plan.json": "4bd25e381860631580f7fb3b7d59f2d3a3c03e2c790110a10583ff32d732b7ee",
  ".cache/next-pattern/outcome-table.md": "1cf2130202015317997b6360b0b545fb675adaf28a78d02e8a876949226c1cd6",
  ".cache/next-pattern/machine-code-summary.json": "b591a9c5d4f3500b9ceeecd3e47accd3914870653f3f98679ac8fc6515adb3de",
  ".cache/next-pattern/machine-code-control-audit.json": "c18cbdf5e3b9e5fbfa12cfc4134505a4d68b7106bcd758f2e81efee7ee033841"
}
```
