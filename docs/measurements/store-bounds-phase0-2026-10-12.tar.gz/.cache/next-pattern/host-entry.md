# Host entry: containment facts across checked stores

2026-10-12, read-only source/prior-artifact audit from clean4f9276a (docs only
above merged6be3980). No builds, tests, lint, profiles or timings. This ignored
note is the only write; tools stop after the note for fresh isolated profiling.

## Assessment and precise distinction

The existing contained-load pass deliberately clears ALL endpoint facts for
every expression statement, including canonical store32/store64 calls. Its
facts describe a successful logical-length bound for an unchanged Go local
address base; they do not describe the contents read from Wasm memory.
Allowing a completely proved checked store to PRESERVE such existing facts is
therefore a different effect-analysis hypothesis from removing the three
adjacent load64/store64 guards rejected by the prior scalar round. Keep every
store, store bounds check, read and original evaluation order; replace only a
later load32 endpoint check already covered by an earlier checked load32.

Under the existing whole-module ownership proof, canonical scalar helpers have
their complete declaration/body/directives/import/builtin bindings validated.
They receive the slice header by value and mutate separately allocated backing
bytes; they cannot shrink, replace or fabricate Module.memory, rebind a Go local,
or invoke an import/callback. The checked facade serializes the module. Hence
a successful canonical store can change even OVERLAPPING loaded bytes without
invalidating a bound on logical memory length and unchanged local base. This
is valid only because future reads still execute against LIVE current memory.
No loaded-value forwarding or inferred address disjointness is justified.

Do NOT silently extend the hypothesis to learning new facts FROM stores. The
long fn96 initializer is mostly stores before any load and then nested blocks:
mere preservation of earlier-load facts does not qualify those initializer
loads. Learning store endpoints, crossing blocks, local-copy/base equivalence,
general memory operations or header caching are separate patterns requiring
their own measured rationale/proof/spec. Start with exact bound store32 ExprStmt
on receiver.memory and proved scalar address/value operands; keep store64/16,
byte indexing, aliases and every unsupported effect as barriers unless an
explicitly bounded diagnostic chooses and proves them before measurement.

## Source/machine observations and uncertainty

Current authored containedBlock accepts single local assignments only;
nonassignments clear facts. It uses per-binding declaration+name keys, explicit
builtin int32 bases, widened zero-extended addresses, first/new-maximum checks,
destination invalidation after RHS evaluation, whole-method nonescape, and
control-flow/block barriers. These constraints must remain unchanged while
testing only the store-effect exception.

Prior ordinary Go1.26.8 matching assembly still reloads memory header/guards
after stores, e.g. fn176 source35850 store32 followed by35851/35852 load32.
However source-level adjacency is NOT proof those loads are eligible: the
preceding fact often belongs to a nested block/branch, the store uses an inferred
copy t32/t60/t103, and the following offsets form rising maxima. fn176's hot
final bin update is load64 then store64, the already rejected route. Many other
fn176 store/load neighborhoods are separated by branches, labels, calls or
block boundaries. I did not establish a hot fn176 load→store→covered-load32
region for this stricter preservation-only rule. Do not claim a scalar ceiling
from the visible duplicate header reloads or expand barriers to force one.

A concrete same-block source opportunity exists in fn84 error construction:
load32(v4+20) → store32(v4+4) → load32(v4+16), with v4 unchanged and no call
between the two loads. The v4+20 check covers the later v4+16 read even though
the intermediate store writes the same memory. But this branch follows invalid
handle paths, so it is an eligibility/proof example, not an established hot
successful-scalar optimization. Fresh inventory/profile may identify useful
SQL/batch/trace regions; absent a hot covered-load inventory, preservation-only
should be reported as a negative rather than promoted.

The last ordinary scalar profile (merged6be3980, module626550ca…, official pinned
Go1.26.8) reports fn17632.67% flat/41.00% cumulative, scalar export55.58%
cumulative and ResultView11.17% cumulative. load32 attributed flat samples
overlap fn176/export attribution and include first/rising mandatory checks.
These are prior matching context, not additive shares or predicted removable
ns. New profiles must match the exact current ordinary binary; do not time
profile/SSA builds. The old log polynomial is register-resident; there is no
fresh justification for approximate arithmetic, cache reuse or host factoring.

## Fail-closed effect/predicate requirements

- Validate actual helper binding AND its complete checked scalar body, directives,
  byte-slice parameter ownership and canonical endian/unaligned fallback. A
  shadowed local/impure conversion/helper or same-named wrapper is a barrier.
- Require receiver.memory exactly, same receiver binding, no variadic spread,
  pure scalar operands and no closure/index/pointer/address-taking side effect.
  Keep operand evaluation at the original store position, including any numeric
  arithmetic trap. Preserve all original store endpoint checks/partial effects.
- Preserve facts only for actual unchanged/nonescaped local bindings. After
  any later scalar assignment still invalidate its bound destination, including
  grouped declarations. A store may alter bytes used by a subsequent load whose
  destination becomes a base; that later Go assignment invalidates its old fact.
- Calls/imports/growth/trim/bulk operations/header writes, any other receiver or
  memory alias, declarations/control flow/labels/gotos/joins, defer/go, escaped
  locals and unsupported statements retain existing barriers. Never carry facts
  into a new block merely because its storage remains readable.
- Canonical New separately allocates Module and backing; native trusted hosts
  may shrink/replace the exposed header ONLY at import boundaries without racing.
  Keep full construction/nonescape proof and logical len, not cap, semantics.
  Width endpoints and base+offset use the original widened nonwrapping arithmetic.

Required semantic probes include overlapping store then weighted live reload,
store to a different in-bounds region, store trapping before a covered read,
partial writes before a later store trap, zero/short logical len with spare cap,
unaligned/high-bit/widened-overflow addresses, impure/shadowed store/conversion,
base rebind/escape/grouped bindings, labels/nested/control entry, imports shrinking/
replacing memory, growth and forbidden Module/backing alias construction.
Independent wazero full memory/value/trap/event comparisons and native amd64/386
must reject mutants that forward stale data, cross imports or drop store checks.

## Host contract and measurement plan

Leave ABI3 and full generated standalone facade unchanged: nil/admission/context,
ownership cell mutex/alive/epoch and KeepAlive, Instance execution lock, direct
recovery/host panic handling, FULL Call reset, canonical reply descriptor bounds/
MaxOutput/payload/status/type checks, separate CURRENT post-call Memory/MaxMemory
observation and immediate protocol/trap poison. Draining Close waits admitted
calls, alias destructor runs once and retains result, poisoned home replacement
never migrates old handles or damages sibling homes/pool. Guest reads/writes
must not escape the checked operation. No runtime R1-R7/R11 factoring, new
callback fusion, PrepareInput(0), public API/ABI or defaultPGO change.

First measure one ignored whole-source/hash/shape-pinned structural diagnostic
with an exact selection inventory: untouched baseline, effect-extension probe
and copied-check restoration control. Keep original Wasm, authored pipeline
cause/harness, every operand/access/first/new maximum and errors. All changes
remain ignored until a credible fresh ceiling precedes a separate committed
private spec and a full generic production/proof round; never optimize generated
modules alone for retention. Call/helper/frame/placement changes need ordinary
assembly and static inventory accounting, not assumed attribution.

Qualification needs original/varied/negative-bin scalar, matched repeated/
increasing/broad scalar, original/varied/held-out SQL, original/repeated/broad
batch and trace, actualP1 standalone default streaming fixed/holdout plus actualP16
one/sixteen resource homes. Include typed Batch and mixed/fairness streaming
guards when a production pass affects those modules. Full finite stream lifetimes
must include New/Write/End/Close, owned output retention/counts and topology;
P16-only phases do not establish P1/default equivalence. Report all allocations,
current guest memory/growth, negative directions, exact raw custom write rates,
fresh independent reference/M1 limits and single-round detections. P1/P16 counts
must be set/asserted in measured leaves, since Go resets processors at each leaf.
Profile shares/layers are nonadditive; state trajectories/calibrated prefixes
differ. Paired alternating/reversed samples run only with all build/test/lint/
profile/reviewer tools idle. No failed ceiling is rescued by choosing inputs,
filtering samples, source-layout tuning or weakening checks.

The recent existing-ABI unit experiment improved unsupported unit-only validation
about18.8% but failed original scalar and repeatedly regressed varied/held-out SQL.
Three adjacent read64/store64 guards had only a tiny raw gain. Those negatives
and prior default small-stream cost stay in durable interpretation; no apparent
raw/component/source benefit accepts M1 or justifies changing checked ownership.
