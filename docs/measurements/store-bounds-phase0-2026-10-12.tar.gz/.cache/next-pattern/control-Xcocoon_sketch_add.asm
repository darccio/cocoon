TEXT dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).Xcocoon_sketch_add(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/internal/wasm/module.go
  module.go:48457	0x656680		493b6610		CMPQ SP, 0x10(R14)										
  module.go:48457	0x656684		0f86880b0000		JBE 0x657212											
  module.go:48457	0x65668a		55			PUSHQ BP											
  module.go:48457	0x65668b		4889e5			MOVQ SP, BP											
  module.go:48457	0x65668e		4883ec70		SUBQ $0x70, SP											
  module.go:48460	0x656692		8b5050			MOVL 0x50(AX), DX										
  module.go:48461	0x656695		448d42f0		LEAL -0x10(DX), R8										
  module.go:48462	0x656699		44894050		MOVL R8, 0x50(AX)										
  module.go:48463	0x65669d		4c8b4838		MOVQ 0x38(AX), R9										
  module.go:48463	0x6566a1		4981f9b0cf1000		CMPQ R9, $0x10cfb0										
  module.go:48463	0x6566a8		0f86570b0000		JBE 0x657205											
  module.go:48463	0x6566ae		4889842480000000	MOVQ AX, 0x80(SP)										
  module.go:48463	0x6566b6		f20f11842490000000	MOVSD_XMM X0, 0x90(SP)										
  module.go:48460	0x6566bf		8954242c		MOVL DX, 0x2c(SP)										
  module.go:48461	0x6566c3		4489442420		MOVL R8, 0x20(SP)										
  module.go:48463	0x6566c8		4c8b4830		MOVQ 0x30(AX), R9										
  module.go:48463	0x6566cc		450fb689b0cf1000	MOVZX 0x10cfb0(R9), R9										
  module.go:48464	0x6566d4		4183f901		CMPL R9, $0x1											
  module.go:48464	0x6566d8		742f			JE 0x656709											
  module.go:48463	0x6566da		48899c2488000000	MOVQ BX, 0x88(SP)										
  module.go:48465	0x6566e2		e8d9f6f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn41(SB)			
  module.go:48468	0x6566e7		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48620	0x6566ef		8b54242c		MOVL 0x2c(SP), DX										
  module.go:48473	0x6566f3		488b9c2488000000	MOVQ 0x88(SP), BX										
  module.go:48474	0x6566fb		448b442420		MOVL 0x20(SP), R8										
  unsafe.go:35		0x656700		f20f10842490000000	MOVSD_XMM 0x90(SP), X0										
  module.go:48468	0x656709		4c8b4838		MOVQ 0x38(AX), R9										
  module.go:62983	0x65670d		4981f973ce1000		CMPQ R9, $0x10ce73										
  module.go:62983	0x656714		0f86de0a0000		JBE 0x6571f8											
  module.go:48468	0x65671a		4c8b4830		MOVQ 0x30(AX), R9										
  module.go:62984	0x65671e		4183b970ce100000	CMPL 0x10ce70(R9), $0x0										
  module.go:48469	0x656726		0f85aa0a0000		JNE 0x6571d6											
  module.go:48470	0x65672c		90			NOPL												
  module.go:63001	0x65672d		41c78170ce1000ffffffff	MOVL $-0x1, 0x10ce70(R9)									
  module.go:48471	0x656738		4c8b4838		MOVQ 0x38(AX), R9										
  module.go:48471	0x65673c		0f1f4000		NOPL 0(AX)											
  module.go:62983	0x656740		4981f97fce1000		CMPQ R9, $0x10ce7f										
  module.go:62983	0x656747		0f867d0a0000		JBE 0x6571ca											
  module.go:48472	0x65674d		90			NOPL												
  module.go:62983	0x65674e		4981f983ce1000		CMPQ R9, $0x10ce83										
  module.go:62983	0x656755		0f86630a0000		JBE 0x6571be											
  module.go:48471	0x65675b		488b5030		MOVQ 0x30(AX), DX										
  module.go:48474	0x65675f		4589c1			MOVL R8, R9											
  module.go:48474	0x656762		4c894c2468		MOVQ R9, 0x68(SP)										
  module.go:62984	0x656767		8b8a7cce1000		MOVL 0x10ce7c(DX), CX										
  module.go:62984	0x65676d		8bba80ce1000		MOVL 0x10ce80(DX), DI										
  module.go:48473	0x656773		4889de			MOVQ BX, SI											
  module.go:48473	0x656776		4489c3			MOVL R8, BX											
  module.go:48473	0x656779		e822d0f8ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn84(SB)			
  module.go:48474	0x65677e		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48474	0x656786		488b5038		MOVQ 0x38(AX), DX										
  module.go:62983	0x65678a		4c8b442468		MOVQ 0x68(SP), R8										
  module.go:62983	0x65678f		4d8d4807		LEAQ 0x7(R8), R9										
  module.go:62983	0x656793		4c39ca			CMPQ DX, R9											
  module.go:62983	0x656796		0f861d0a0000		JBE 0x6571b9											
  module.go:48474	0x65679c		488b7030		MOVQ 0x30(AX), SI										
  module.go:62983	0x6567a0		498d7803		LEAQ 0x3(R8), DI										
  module.go:48481	0x6567a4		90			NOPL												
  module.go:62984	0x6567a5		418b4c3004		MOVL 0x4(R8)(SI*1), CX										
  module.go:62983	0x6567aa		4839fa			CMPQ DX, DI											
  module.go:62983	0x6567ad		0f86010a0000		JBE 0x6571b4											
  module.go:62984	0x6567b3		8b5c2420		MOVL 0x20(SP), BX										
  module.go:62984	0x6567b7		4189da			MOVL BX, R10											
  module.go:62984	0x6567ba		458b1c32		MOVL 0(R10)(SI*1), R11										
  module.go:62984	0x6567be		6690			NOPW												
  module.go:48483	0x6567c0		4183fbff		CMPL R11, $-0x1											
  module.go:48483	0x6567c4		7418			JE 0x6567de											
  module.go:63009	0x6567c6		4d8d600f		LEAQ 0xf(R8), R12										
  module.go:48484	0x6567ca		90			NOPL												
  module.go:63009	0x6567cb		4c39e2			CMPQ DX, R12											
  module.go:63009	0x6567ce		0f86db090000		JBE 0x6571af											
  module.go:63010	0x6567d4		498b543008		MOVQ 0x8(R8)(SI*1), DX										
  module.go:48486	0x6567d9		e926070000		JMP 0x656f04											
  module.go:62983	0x6567de		4c894c2460		MOVQ R9, 0x60(SP)										
  module.go:62983	0x6567e3		48897c2458		MOVQ DI, 0x58(SP)										
  module.go:62984	0x6567e8		4c89542450		MOVQ R10, 0x50(SP)										
  module.go:48488	0x6567ed		8b5050			MOVL 0x50(AX), DX										
  module.go:48488	0x6567f0		89542428		MOVL DX, 0x28(SP)										
  module.go:48489	0x6567f4		8d72c0			LEAL -0x40(DX), SI										
  module.go:48490	0x6567f7		897050			MOVL SI, 0x50(AX)										
  unsafe.go:35		0x6567fa		f20f10842490000000	MOVSD_XMM 0x90(SP), X0										
  unsafe.go:35		0x656803		66490f7ec3		MOVQ X0, R11											
  module.go:48493	0x656808		4d89dc			MOVQ R11, R12											
  module.go:48493	0x65680b		490fbaf33f		BTRQ $0x3f, R11											
  module.go:48499	0x656810		4d8d6c24ff		LEAQ -0x1(R12), R13										
  module.go:48504	0x656815		49bf000000000000f0ff	MOVQ $0xfff0000000000000, R15									
  module.go:48504	0x65681f		4d01df			ADDQ R11, R15											
  module.go:48492	0x656822		90			NOPL												
  module.go:48495	0x656823		4d85db			TESTQ R11, R11											
  module.go:48495	0x656826		410f94c3		SETE R11											
  module.go:48498	0x65682a		450fb6db		MOVZX R11, R11											
  module.go:48499	0x65682e		49b8ffffffffffff0f00	MOVQ $0xfffffffffffff, R8									
  module.go:48499	0x656838		4d39e8			CMPQ R8, R13											
  module.go:48499	0x65683b		410f97c0		SETA R8												
  module.go:48502	0x65683f		450fb6c0		MOVZX R8, R8											
  module.go:48502	0x656843		4509c3			ORL R8, R11											
  module.go:48504	0x656846		49b8000000000000e07f	MOVQ $0x7fe0000000000000, R8									
  module.go:48504	0x656850		4d39f8			CMPQ R8, R15											
  module.go:48504	0x656853		410f97c0		SETA R8												
  module.go:48507	0x656857		450fb6c0		MOVZX R8, R8											
  module.go:48508	0x65685b		4d85e4			TESTQ R12, R12											
  module.go:48508	0x65685e		410f9dc4		SETGE R12											
  module.go:48511	0x656862		450fb6e4		MOVZX R12, R12											
  module.go:48511	0x656866		4521e0			ANDL R12, R8											
  module.go:48511	0x656869		4509d8			ORL R11, R8											
  module.go:48511	0x65686c		4585c0			TESTL R8, R8											
  module.go:48511	0x65686f		0f8493030000		JE 0x656c08											
  module.go:48489	0x656875		89742424		MOVL SI, 0x24(SP)										
  module.go:48535	0x656879		8d5ac8			LEAL -0x38(DX), BX										
  module.go:48535	0x65687c		0f1f4000		NOPL 0(AX)											
  module.go:48535	0x656880		e89b96fdff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn176(SB)			
  module.go:48536	0x656885		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48536	0x65688d		488b5038		MOVQ 0x38(AX), DX										
  module.go:48536	0x656891		8b742424		MOVL 0x24(SP), SI										
  module.go:48536	0x656895		89f6			MOVL SI, SI											
  module.go:62983	0x656897		488d7e0b		LEAQ 0xb(SI), DI										
  module.go:62983	0x65689b		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:62983	0x6568a0		4839fa			CMPQ DX, DI											
  module.go:62983	0x6568a3		0f8601090000		JBE 0x6571aa											
  module.go:48536	0x6568a9		488b7830		MOVQ 0x30(AX), DI										
  module.go:62984	0x6568ad		448b443e08		MOVL 0x8(SI)(DI*1), R8										
  module.go:48538	0x6568b2		4585c0			TESTL R8, R8											
  module.go:48538	0x6568b5		7536			JNE 0x6568ed											
  module.go:48574	0x6568b7		90			NOPL												
  module.go:63000	0x6568b8		488b4c2458		MOVQ 0x58(SP), CX										
  module.go:63000	0x6568bd		0f1f00			NOPL 0(AX)											
  module.go:63000	0x6568c0		4839ca			CMPQ DX, CX											
  module.go:63000	0x6568c3		0f86dc080000		JBE 0x6571a5											
  module.go:63001	0x6568c9		488b542450		MOVQ 0x50(SP), DX										
  module.go:63001	0x6568ce		c70417ffffffff		MOVL $-0x1, 0(DI)(DX*1)										
  module.go:63009	0x6568d5		488b742468		MOVQ 0x68(SP), SI										
  module.go:62983	0x6568da		488b7c2460		MOVQ 0x60(SP), DI										
  module.go:62983	0x6568df		4989c8			MOVQ CX, R8											
  module.go:62984	0x6568e2		4989d1			MOVQ DX, R9											
  module.go:48577	0x6568e5		4889c1			MOVQ AX, CX											
  module.go:48577	0x6568e8		e9cf040000		JMP 0x656dbc											
  module.go:62983	0x6568ed		4c8d4e0f		LEAQ 0xf(SI), R9										
  module.go:48539	0x6568f1		90			NOPL												
  module.go:62983	0x6568f2		4c39ca			CMPQ DX, R9											
  module.go:62983	0x6568f5		0f86a3080000		JBE 0x65719e											
  module.go:63000	0x6568fb		4c8d4e2b		LEAQ 0x2b(SI), R9										
  module.go:48541	0x6568ff		90			NOPL												
  module.go:62984	0x656900		448b543e0c		MOVL 0xc(SI)(DI*1), R10										
  module.go:63000	0x656905		4c39ca			CMPQ DX, R9											
  module.go:63000	0x656908		0f868b080000		JBE 0x657199											
  module.go:63001	0x65690e		c7443e2800000000	MOVL $0x0, 0x28(SI)(DI*1)									
  module.go:48542	0x656916		488b7838		MOVQ 0x38(AX), DI										
  module.go:63026	0x65691a		4c8d5e27		LEAQ 0x27(SI), R11										
  module.go:63026	0x65691e		6690			NOPW												
  module.go:63026	0x656920		4c39df			CMPQ DI, R11											
  module.go:63026	0x656923		0f866b080000		JBE 0x657194											
  module.go:48542	0x656929		488b7830		MOVQ 0x30(AX), DI										
  module.go:63027	0x65692d		49bc0000000001000000	MOVQ $0x100000000, R12										
  module.go:63027	0x656937		4c89643e20		MOVQ R12, 0x20(SI)(DI*1)									
  module.go:48543	0x65693c		488b7838		MOVQ 0x38(AX), DI										
  module.go:63000	0x656940		4c8d6633		LEAQ 0x33(SI), R12										
  module.go:63000	0x656944		4c39e7			CMPQ DI, R12											
  module.go:63000	0x656947		0f8642080000		JBE 0x65718f											
  module.go:48543	0x65694d		488b7830		MOVQ 0x30(AX), DI										
  module.go:63001	0x656951		c7443e30c81a1000	MOVL $0x101ac8, 0x30(SI)(DI*1)									
  module.go:48544	0x656959		488b7838		MOVQ 0x38(AX), DI										
  module.go:63026	0x65695d		4c8d663b		LEAQ 0x3b(SI), R12										
  module.go:63026	0x656961		4c39e7			CMPQ DI, R12											
  module.go:63026	0x656964		0f8620080000		JBE 0x65718a											
  module.go:48544	0x65696a		488b7830		MOVQ 0x30(AX), DI										
  module.go:63027	0x65696e		48c7443e3420000060	MOVQ $0x60000020, 0x34(SI)(DI*1)								
  module.go:48545	0x656977		488b7838		MOVQ 0x38(AX), DI										
  module.go:63000	0x65697b		4c8d662f		LEAQ 0x2f(SI), R12										
  module.go:63000	0x65697f		90			NOPL												
  module.go:63000	0x656980		4c39e7			CMPQ DI, R12											
  module.go:63000	0x656983		0f86fc070000		JBE 0x657185											
  module.go:48545	0x656989		488b7830		MOVQ 0x30(AX), DI										
  module.go:48545	0x65698d		8b5c2428		MOVL 0x28(SP), BX										
  module.go:48545	0x656991		448d63e0		LEAL -0x20(BX), R12										
  module.go:63001	0x656995		4489643e2c		MOVL R12, 0x2c(SI)(DI*1)									
  module.go:48546	0x65699a		488b7838		MOVQ 0x38(AX), DI										
  module.go:62983	0x65699e		4d8d6213		LEAQ 0x13(R10), R12										
  module.go:62983	0x6569a2		4c39e7			CMPQ DI, R12											
  module.go:62983	0x6569a5		0f86d3070000		JBE 0x65717e											
  module.go:48546	0x6569ab		488b7830		MOVQ 0x30(AX), DI										
  module.go:62984	0x6569af		498d3c3a		LEAQ 0(R10)(DI*1), DI										
  module.go:62984	0x6569b3		488d7f10		LEAQ 0x10(DI), DI										
  module.go:62984	0x6569b7		48633f			MOVSXD 0(DI), DI										
  module.go:62984	0x6569ba		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:63164	0x6569c0		48397808		CMPQ 0x8(AX), DI										
  module.go:63164	0x6569c4		0f86a1070000		JBE 0x65716b											
  module.go:48547	0x6569ca		48c1e704		SHLQ $0x4, DI											
  module.go:48547	0x6569ce		4c8b20			MOVQ 0(AX), R12											
  module.go:48547	0x6569d1		4e8b2c27		MOVQ 0(DI)(R12*1), R13										
  module.go:48547	0x6569d5		4a8b542708		MOVQ 0x8(DI)(R12*1), DX										
  module.go:48547	0x6569da		488d3d7f4d2000		LEAQ 0x204d7f(IP), DI										
  module.go:48547	0x6569e1		4939fd			CMPQ R13, DI											
  module.go:48547	0x6569e4		0f856f070000		JNE 0x657159											
  module.go:48536	0x6569ea		4889742448		MOVQ SI, 0x48(SP)										
  module.go:62984	0x6569ef		4489442434		MOVL R8, 0x34(SP)										
  module.go:62984	0x6569f4		4489542430		MOVL R10, 0x30(SP)										
  module.go:63000	0x6569f9		4c894c2440		MOVQ R9, 0x40(SP)										
  module.go:63026	0x6569fe		4c895c2438		MOVQ R11, 0x38(SP)										
  module.go:48547	0x656a03		488b0a			MOVQ 0(DX), CX											
  module.go:48547	0x656a06		83c3ec			ADDL $-0x14, BX											
  module.go:48547	0x656a09		4489c0			MOVL R8, AX											
  module.go:48547	0x656a0c		ffd1			CALL CX												
  module.go:48548	0x656a0e		85c0			TESTL AX, AX											
  module.go:48548	0x656a10		0f8508070000		JNE 0x65711e											
  module.go:48552	0x656a16		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48552	0x656a1e		488b7038		MOVQ 0x38(AX), SI										
  module.go:62983	0x656a22		488b7c2440		MOVQ 0x40(SP), DI										
  module.go:62983	0x656a27		4839fe			CMPQ SI, DI											
  module.go:62983	0x656a2a		0f86e9060000		JBE 0x657119											
  module.go:48552	0x656a30		488b7830		MOVQ 0x30(AX), DI										
  module.go:63000	0x656a34		4c8b442448		MOVQ 0x48(SP), R8										
  module.go:63000	0x656a39		4d8d481b		LEAQ 0x1b(R8), R9										
  module.go:48553	0x656a3d		90			NOPL												
  module.go:62984	0x656a3e		458b543828		MOVL 0x28(R8)(DI*1), R10									
  module.go:63000	0x656a43		4c39ce			CMPQ SI, R9											
  module.go:63000	0x656a46		0f86c8060000		JBE 0x657114											
  module.go:63001	0x656a4c		4589543818		MOVL R10, 0x18(R8)(DI*1)									
  module.go:48554	0x656a51		488b7038		MOVQ 0x38(AX), SI										
  module.go:63009	0x656a55		488b7c2438		MOVQ 0x38(SP), DI										
  module.go:63009	0x656a5a		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:63009	0x656a60		4839fe			CMPQ SI, DI											
  module.go:63009	0x656a63		0f86a6060000		JBE 0x65710f											
  module.go:48554	0x656a69		488b7830		MOVQ 0x30(AX), DI										
  module.go:63026	0x656a6d		4d8d5017		LEAQ 0x17(R8), R10										
  module.go:48555	0x656a71		90			NOPL												
  module.go:63010	0x656a72		4d8b5c3820		MOVQ 0x20(R8)(DI*1), R11									
  module.go:63010	0x656a77		660f1f840000000000	NOPW 0(AX)(AX*1)										
  module.go:63026	0x656a80		4c39d6			CMPQ SI, R10											
  module.go:63026	0x656a83		0f8681060000		JBE 0x65710a											
  module.go:63027	0x656a89		4d895c3810		MOVQ R11, 0x10(R8)(DI*1)									
  module.go:48556	0x656a8e		488b7038		MOVQ 0x38(AX), SI										
  module.go:62983	0x656a92		8b7c2430		MOVL 0x30(SP), DI										
  module.go:62983	0x656a96		4c8d5f03		LEAQ 0x3(DI), R11										
  module.go:62983	0x656a9a		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:62983	0x656aa0		4c39de			CMPQ SI, R11											
  module.go:62983	0x656aa3		0f865c060000		JBE 0x657105											
  module.go:63000	0x656aa9		4c894c2440		MOVQ R9, 0x40(SP)										
  module.go:63026	0x656aae		4c89542438		MOVQ R10, 0x38(SP)										
  module.go:48556	0x656ab3		488b7030		MOVQ 0x30(AX), SI										
  module.go:62984	0x656ab7		8b3437			MOVL 0(DI)(SI*1), SI										
  module.go:48558	0x656aba		85f6			TESTL SI, SI											
  module.go:48558	0x656abc		7451			JE 0x656b0f											
  module.go:48559	0x656abe		4863f6			MOVSXD SI, SI											
  module.go:63164	0x656ac1		48397008		CMPQ 0x8(AX), SI										
  module.go:63164	0x656ac5		0f8622060000		JBE 0x6570ed											
  module.go:48559	0x656acb		48c1e604		SHLQ $0x4, SI											
  module.go:48559	0x656acf		4c8b18			MOVQ 0(AX), R11											
  module.go:48559	0x656ad2		4e8b241e		MOVQ 0(SI)(R11*1), R12										
  module.go:48559	0x656ad6		4a8b541e08		MOVQ 0x8(SI)(R11*1), DX										
  module.go:48559	0x656adb		488d1dfe5d1f00		LEAQ 0x1f5dfe(IP), BX										
  module.go:48559	0x656ae2		4939dc			CMPQ R12, BX											
  module.go:48559	0x656ae5		0f85f3050000		JNE 0x6570de											
  module.go:48559	0x656aeb		488b0a			MOVQ 0(DX), CX											
  module.go:48559	0x656aee		8b442434		MOVL 0x34(SP), AX										
  module.go:48559	0x656af2		ffd1			CALL CX												
  module.go:48561	0x656af4		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:62983	0x656afc		8b7c2430		MOVL 0x30(SP), DI										
  module.go:62984	0x656b00		4c8b442448		MOVQ 0x48(SP), R8										
  module.go:62983	0x656b05		4c8b4c2440		MOVQ 0x40(SP), R9										
  module.go:63009	0x656b0a		4c8b542438		MOVQ 0x38(SP), R10										
  module.go:48561	0x656b0f		488b5038		MOVQ 0x38(AX), DX										
  module.go:62983	0x656b13		488d7707		LEAQ 0x7(DI), SI										
  module.go:62983	0x656b17		660f1f840000000000	NOPW 0(AX)(AX*1)										
  module.go:62983	0x656b20		4839f2			CMPQ DX, SI											
  module.go:62983	0x656b23		0f86b0050000		JBE 0x6570d9											
  module.go:48561	0x656b29		488b7030		MOVQ 0x30(AX), SI										
  module.go:62984	0x656b2d		8b4c3704		MOVL 0x4(DI)(SI*1), CX										
  module.go:48563	0x656b31		85c9			TESTL CX, CX											
  module.go:48563	0x656b33		7434			JE 0x656b69											
  module.go:62983	0x656b35		488d770b		LEAQ 0xb(DI), SI										
  module.go:48564	0x656b39		90			NOPL												
  module.go:48564	0x656b3a		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:62983	0x656b40		4839f2			CMPQ DX, SI											
  module.go:62983	0x656b43		0f868b050000		JBE 0x6570d4											
  module.go:48565	0x656b49		8b5c2434		MOVL 0x34(SP), BX										
  module.go:48565	0x656b4d		e88e54f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn1(SB)			
  module.go:48567	0x656b52		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:62984	0x656b5a		4c8b442448		MOVQ 0x48(SP), R8										
  module.go:62983	0x656b5f		4c8b4c2440		MOVQ 0x40(SP), R9										
  module.go:63009	0x656b64		4c8b542438		MOVQ 0x38(SP), R10										
  module.go:48567	0x656b69		488b4838		MOVQ 0x38(AX), CX										
  module.go:62983	0x656b6d		4c39c9			CMPQ CX, R9											
  module.go:62983	0x656b70		0f8659050000		JBE 0x6570cf											
  module.go:48567	0x656b76		488b5030		MOVQ 0x30(AX), DX										
  module.go:63000	0x656b7a		488b742468		MOVQ 0x68(SP), SI										
  module.go:63000	0x656b7f		488d7e0b		LEAQ 0xb(SI), DI										
  module.go:48568	0x656b83		90			NOPL												
  module.go:62984	0x656b84		458b4c1018		MOVL 0x18(R8)(DX*1), R9										
  module.go:63000	0x656b89		4839f9			CMPQ CX, DI											
  module.go:63000	0x656b8c		0f8638050000		JBE 0x6570ca											
  module.go:63001	0x656b92		44894c1608		MOVL R9, 0x8(SI)(DX*1)										
  module.go:48569	0x656b97		488b4838		MOVQ 0x38(AX), CX										
  module.go:48569	0x656b9b		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:63009	0x656ba0		4c39d1			CMPQ CX, R10											
  module.go:63009	0x656ba3		0f861c050000		JBE 0x6570c5											
  module.go:48569	0x656ba9		488b5030		MOVQ 0x30(AX), DX										
  module.go:48570	0x656bad		90			NOPL												
  module.go:63010	0x656bae		498b7c1010		MOVQ 0x10(R8)(DX*1), DI										
  module.go:63026	0x656bb3		4c8b442460		MOVQ 0x60(SP), R8										
  module.go:63026	0x656bb8		0f1f840000000000	NOPL 0(AX)(AX*1)										
  module.go:63026	0x656bc0		4c39c1			CMPQ CX, R8											
  module.go:63026	0x656bc3		0f86f5040000		JBE 0x6570be											
  module.go:63027	0x656bc9		488b4c2450		MOVQ 0x50(SP), CX										
  module.go:63027	0x656bce		48893c0a		MOVQ DI, 0(DX)(CX*1)										
  module.go:48571	0x656bd2		488b5038		MOVQ 0x38(AX), DX										
  module.go:63000	0x656bd6		488d7e0f		LEAQ 0xf(SI), DI										
  module.go:63000	0x656bda		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:63000	0x656be0		4839fa			CMPQ DX, DI											
  module.go:63000	0x656be3		0f86d0040000		JBE 0x6570b9											
  module.go:48571	0x656be9		488b5030		MOVQ 0x30(AX), DX										
  module.go:63001	0x656bed		c744160c01000000	MOVL $0x1, 0xc(SI)(DX*1)									
  module.go:62983	0x656bf5		4c89c7			MOVQ R8, DI											
  module.go:62983	0x656bf8		4c8b442458		MOVQ 0x58(SP), R8										
  module.go:62984	0x656bfd		4989c9			MOVQ CX, R9											
  module.go:48577	0x656c00		4889c1			MOVQ AX, CX											
  module.go:48572	0x656c03		e9b4010000		JMP 0x656dbc											
  module.go:48512	0x656c08		bb2c000000		MOVL $0x2c, BX											
  module.go:48512	0x656c0d		b901000000		MOVL $0x1, CX											
  module.go:48512	0x656c12		e84957f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn4(SB)			
  module.go:48514	0x656c17		85c0			TESTL AX, AX											
  module.go:48514	0x656c19		0f8470040000		JE 0x65708f											
  module.go:48518	0x656c1f		488b8c2480000000	MOVQ 0x80(SP), CX										
  module.go:48518	0x656c27		488b5138		MOVQ 0x38(CX), DX										
  module.go:63026	0x656c2b		488b742468		MOVQ 0x68(SP), SI										
  module.go:63026	0x656c30		488d7e0f		LEAQ 0xf(SI), DI										
  module.go:63026	0x656c34		4839fa			CMPQ DX, DI											
  module.go:63026	0x656c37		0f864d040000		JBE 0x65708a											
  module.go:48518	0x656c3d		488b5130		MOVQ 0x30(CX), DX										
  module.go:63027	0x656c41		48bf2c00000002000000	MOVQ $0x20000002c, DI										
  module.go:63027	0x656c4b		48897c1608		MOVQ DI, 0x8(SI)(DX*1)										
  module.go:48519	0x656c50		488b5138		MOVQ 0x38(CX), DX										
  module.go:63000	0x656c54		488b7c2460		MOVQ 0x60(SP), DI										
  module.go:63000	0x656c59		0f1f8000000000		NOPL 0(AX)											
  module.go:63000	0x656c60		4839fa			CMPQ DX, DI											
  module.go:63000	0x656c63		0f861c040000		JBE 0x657085											
  module.go:48519	0x656c69		488b5130		MOVQ 0x30(CX), DX										
  module.go:63001	0x656c6d		89441604		MOVL AX, 0x4(SI)(DX*1)										
  module.go:48520	0x656c71		488b5138		MOVQ 0x38(CX), DX										
  module.go:63000	0x656c75		4c8b442458		MOVQ 0x58(SP), R8										
  module.go:63000	0x656c7a		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:63000	0x656c80		4c39c2			CMPQ DX, R8											
  module.go:63000	0x656c83		0f86f3030000		JBE 0x65707c											
  module.go:48520	0x656c89		488b5130		MOVQ 0x30(CX), DX										
  module.go:63001	0x656c8d		4c8b4c2450		MOVQ 0x50(SP), R9										
  module.go:63001	0x656c92		42c7040a2c000000	MOVL $0x2c, 0(DX)(R9*1)										
  module.go:48521	0x656c9a		488b5138		MOVQ 0x38(CX), DX										
  module.go:48521	0x656c9e		6690			NOPW												
  module.go:62983	0x656ca0		4881fa9b191000		CMPQ DX, $0x10199b										
  module.go:62983	0x656ca7		0f86c3030000		JBE 0x657070											
  module.go:48522	0x656cad		4189c2			MOVL AX, R10											
  module.go:63000	0x656cb0		4d8d5a2b		LEAQ 0x2b(R10), R11										
  module.go:63000	0x656cb4		4c39da			CMPQ DX, R11											
  module.go:63000	0x656cb7		0f86ae030000		JBE 0x65706b											
  module.go:48521	0x656cbd		488b5130		MOVQ 0x30(CX), DX										
  module.go:62984	0x656cc1		448b9a98191000		MOVL 0x101998(DX), R11										
  module.go:63001	0x656cc8		45895c1228		MOVL R11, 0x28(R10)(DX*1)									
  module.go:48523	0x656ccd		488b5138		MOVQ 0x38(CX), DX										
  module.go:63009	0x656cd1		4881fa97191000		CMPQ DX, $0x101997										
  module.go:63009	0x656cd8		0f8681030000		JBE 0x65705f											
  module.go:63026	0x656cde		4d8d5a27		LEAQ 0x27(R10), R11										
  module.go:48524	0x656ce2		90			NOPL												
  module.go:63026	0x656ce3		4c39da			CMPQ DX, R11											
  module.go:63026	0x656ce6		0f866e030000		JBE 0x65705a											
  module.go:48523	0x656cec		488b5130		MOVQ 0x30(CX), DX										
  module.go:63010	0x656cf0		4c8b9a90191000		MOVQ 0x101990(DX), R11										
  module.go:63027	0x656cf7		4d895c1220		MOVQ R11, 0x20(R10)(DX*1)									
  module.go:48525	0x656cfc		488b5138		MOVQ 0x38(CX), DX										
  module.go:63009	0x656d00		4881fa8f191000		CMPQ DX, $0x10198f										
  module.go:63009	0x656d07		0f8641030000		JBE 0x65704e											
  module.go:63026	0x656d0d		4d8d5a1f		LEAQ 0x1f(R10), R11										
  module.go:48526	0x656d11		90			NOPL												
  module.go:63026	0x656d12		4c39da			CMPQ DX, R11											
  module.go:63026	0x656d15		0f862e030000		JBE 0x657049											
  module.go:48525	0x656d1b		488b5130		MOVQ 0x30(CX), DX										
  module.go:63010	0x656d1f		4c8b9a88191000		MOVQ 0x101988(DX), R11										
  module.go:63027	0x656d26		4d895c1218		MOVQ R11, 0x18(R10)(DX*1)									
  module.go:48527	0x656d2b		488b5138		MOVQ 0x38(CX), DX										
  module.go:63009	0x656d2f		4881fa87191000		CMPQ DX, $0x101987										
  module.go:63009	0x656d36		0f8601030000		JBE 0x65703d											
  module.go:63026	0x656d3c		4d8d5a17		LEAQ 0x17(R10), R11										
  module.go:48528	0x656d40		90			NOPL												
  module.go:63026	0x656d41		4c39da			CMPQ DX, R11											
  module.go:63026	0x656d44		0f86ee020000		JBE 0x657038											
  module.go:48527	0x656d4a		488b5130		MOVQ 0x30(CX), DX										
  module.go:63010	0x656d4e		4c8b9a80191000		MOVQ 0x101980(DX), R11										
  module.go:63027	0x656d55		4d895c1210		MOVQ R11, 0x10(R10)(DX*1)									
  module.go:48529	0x656d5a		488b5138		MOVQ 0x38(CX), DX										
  module.go:48529	0x656d5e		6690			NOPW												
  module.go:63009	0x656d60		4881fa7f191000		CMPQ DX, $0x10197f										
  module.go:63009	0x656d67		0f86bf020000		JBE 0x65702c											
  module.go:63026	0x656d6d		4d8d5a0f		LEAQ 0xf(R10), R11										
  module.go:48530	0x656d71		90			NOPL												
  module.go:63026	0x656d72		4c39da			CMPQ DX, R11											
  module.go:63026	0x656d75		0f86ac020000		JBE 0x657027											
  module.go:48529	0x656d7b		488b5130		MOVQ 0x30(CX), DX										
  module.go:63010	0x656d7f		4c8b9a78191000		MOVQ 0x101978(DX), R11										
  module.go:63027	0x656d86		4d895c1208		MOVQ R11, 0x8(R10)(DX*1)									
  module.go:48531	0x656d8b		488b5138		MOVQ 0x38(CX), DX										
  module.go:63009	0x656d8f		4881fa77191000		CMPQ DX, $0x101977										
  module.go:63009	0x656d96		0f867f020000		JBE 0x65701b											
  module.go:63026	0x656d9c		4983c207		ADDQ $0x7, R10											
  module.go:48532	0x656da0		90			NOPL												
  module.go:63026	0x656da1		4c39d2			CMPQ DX, R10											
  module.go:63026	0x656da4		0f866c020000		JBE 0x657016											
  module.go:48531	0x656daa		488b5130		MOVQ 0x30(CX), DX										
  module.go:63010	0x656dae		4c8b9270191000		MOVQ 0x101970(DX), R10										
  module.go:63027	0x656db5		4189c3			MOVL AX, R11											
  module.go:63027	0x656db8		4e89141a		MOVQ R10, 0(DX)(R11*1)										
  module.go:48577	0x656dbc		8b542428		MOVL 0x28(SP), DX										
  module.go:48577	0x656dc0		895150			MOVL DX, 0x50(CX)										
  module.go:48580	0x656dc3		488b5138		MOVQ 0x38(CX), DX										
  module.go:62983	0x656dc7		4c39c2			CMPQ DX, R8											
  module.go:62983	0x656dca		0f8641020000		JBE 0x657011											
  module.go:48580	0x656dd0		4c8b5130		MOVQ 0x30(CX), R10										
  module.go:62984	0x656dd4		478b1c11		MOVL 0(R9)(R10*1), R11										
  module.go:62984	0x656dd8		0f1f840000000000	NOPL 0(AX)(AX*1)										
  module.go:48582	0x656de0		4183fbff		CMPL R11, $-0x1											
  module.go:48582	0x656de4		0f85e2000000		JNE 0x656ecc											
  module.go:48602	0x656dea		90			NOPL												
  module.go:62983	0x656deb		4881fa73ce1000		CMPQ DX, $0x10ce73										
  module.go:62983	0x656df2		0f860d020000		JBE 0x657005											
  module.go:48603	0x656df8		90			NOPL												
  module.go:63001	0x656df9		41ff8270ce1000		INCL 0x10ce70(R10)										
  module.go:48604	0x656e00		488b5138		MOVQ 0x38(CX), DX										
  module.go:48604	0x656e04		4881fafccf1000		CMPQ DX, $0x10cffc										
  module.go:48604	0x656e0b		0f86e4010000		JBE 0x656ff5											
  module.go:48604	0x656e11		488b5130		MOVQ 0x30(CX), DX										
  module.go:48604	0x656e15		0fb692fccf1000		MOVZX 0x10cffc(DX), DX										
  module.go:48604	0x656e1c		0f1f4000		NOPL 0(AX)											
  module.go:48605	0x656e20		83fa01			CMPL DX, $0x1											
  module.go:48605	0x656e23		7410			JE 0x656e35											
  module.go:48606	0x656e25		4889c8			MOVQ CX, AX											
  module.go:48606	0x656e28		e89306fbff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn105(SB)			
  module.go:48608	0x656e2d		488b8c2480000000	MOVQ 0x80(SP), CX										
  module.go:48608	0x656e35		488b5138		MOVQ 0x38(CX), DX										
  module.go:48608	0x656e39		0f1f8000000000		NOPL 0(AX)											
  module.go:62983	0x656e40		4881fad3cf1000		CMPQ DX, $0x10cfd3										
  module.go:62983	0x656e47		0f869c010000		JBE 0x656fe9											
  module.go:48608	0x656e4d		488b7130		MOVQ 0x30(CX), SI										
  module.go:62984	0x656e51		83bed0cf100000		CMPL 0x10cfd0(SI), $0x0										
  module.go:48609	0x656e58		0f856b010000		JNE 0x656fc9											
  module.go:48613	0x656e5e		90			NOPL												
  module.go:48613	0x656e5f		90			NOPL												
  module.go:62983	0x656e60		4881fae7cf1000		CMPQ DX, $0x10cfe7										
  module.go:62983	0x656e67		0f8650010000		JBE 0x656fbd											
  module.go:48614	0x656e6d		90			NOPL												
  module.go:63000	0x656e6e		4881faefcf1000		CMPQ DX, $0x10cfef										
  module.go:63000	0x656e75		0f8636010000		JBE 0x656fb1											
  module.go:62984	0x656e7b		8b96e4cf1000		MOVL 0x10cfe4(SI), DX										
  module.go:63001	0x656e81		8996eccf1000		MOVL DX, 0x10cfec(SI)										
  module.go:48615	0x656e87		488b5138		MOVQ 0x38(CX), DX										
  module.go:63200	0x656e8b		4881faebcf1000		CMPQ DX, $0x10cfeb										
  module.go:63200	0x656e92		0f860d010000		JBE 0x656fa5											
  module.go:48615	0x656e98		488b5130		MOVQ 0x30(CX), DX										
  module.go:63201	0x656e9c		c782e8cf100000000000	MOVL $0x0, 0x10cfe8(DX)										
  module.go:48616	0x656ea6		488b5138		MOVQ 0x38(CX), DX										
  module.go:63000	0x656eaa		4881faf3cf1000		CMPQ DX, $0x10cff3										
  module.go:63000	0x656eb1		0f86dd000000		JBE 0x656f94											
  module.go:48616	0x656eb7		488b5130		MOVQ 0x30(CX), DX										
  module.go:63001	0x656ebb		c782f0cf100000000000	MOVL $0x0, 0x10cff0(DX)										
  module.go:63001	0x656ec5		31c0			XORL AX, AX											
  module.go:48619	0x656ec7		e996000000		JMP 0x656f62											
  module.go:48585	0x656ecc		90			NOPL												
  module.go:62983	0x656ecd		4839fa			CMPQ DX, DI											
  module.go:62983	0x656ed0		0f86b9000000		JBE 0x656f8f											
  module.go:63009	0x656ed6		4c8d660f		LEAQ 0xf(SI), R12										
  module.go:48587	0x656eda		90			NOPL												
  module.go:62984	0x656edb		468b6c1604		MOVL 0x4(SI)(R10*1), R13									
  module.go:63009	0x656ee0		4c39e2			CMPQ DX, R12											
  module.go:63009	0x656ee3		0f86a1000000		JBE 0x656f8a											
  module.go:63010	0x656ee9		4a8b541608		MOVQ 0x8(SI)(R10*1), DX										
  module.go:48592	0x656eee		4889c8			MOVQ CX, AX											
  module.go:48597	0x656ef1		8b5c2420		MOVL 0x20(SP), BX										
  module.go:63001	0x656ef5		4d89ca			MOVQ R9, R10											
  module.go:48591	0x656ef8		4489e9			MOVL R13, CX											
  module.go:63000	0x656efb		4989f9			MOVQ DI, R9											
  module.go:63000	0x656efe		4c89c7			MOVQ R8, DI											
  module.go:63026	0x656f01		4989f0			MOVQ SI, R8											
  module.go:48592	0x656f04		488b7038		MOVQ 0x38(AX), SI										
  module.go:62983	0x656f08		4881fe73ce1000		CMPQ SI, $0x10ce73										
  module.go:62983	0x656f0f		766d			JBE 0x656f7e											
  module.go:48592	0x656f11		488b7030		MOVQ 0x30(AX), SI										
  module.go:63026	0x656f15		4d8d600f		LEAQ 0xf(R8), R12										
  module.go:48593	0x656f19		90			NOPL												
  module.go:63001	0x656f1a		ff8670ce1000		INCL 0x10ce70(SI)										
  module.go:48594	0x656f20		488b7038		MOVQ 0x38(AX), SI										
  module.go:63026	0x656f24		4c39e6			CMPQ SI, R12											
  module.go:63026	0x656f27		7650			JBE 0x656f79											
  module.go:48594	0x656f29		488b7030		MOVQ 0x30(AX), SI										
  module.go:63027	0x656f2d		4989543008		MOVQ DX, 0x8(R8)(SI*1)										
  module.go:48595	0x656f32		488b5038		MOVQ 0x38(AX), DX										
  module.go:63000	0x656f36		4c39ca			CMPQ DX, R9											
  module.go:63000	0x656f39		7639			JBE 0x656f74											
  module.go:48595	0x656f3b		488b5030		MOVQ 0x30(AX), DX										
  module.go:63001	0x656f3f		41894c1004		MOVL CX, 0x4(R8)(DX*1)										
  module.go:48596	0x656f44		488b4838		MOVQ 0x38(AX), CX										
  module.go:63000	0x656f48		4839f9			CMPQ CX, DI											
  module.go:63000	0x656f4b		7622			JBE 0x656f6f											
  module.go:48596	0x656f4d		488b4830		MOVQ 0x30(AX), CX										
  module.go:63001	0x656f51		46891c11		MOVL R11, 0(CX)(R10*1)										
  module.go:48597	0x656f55		e8665af8ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn60(SB)			
  module.go:48620	0x656f5a		488b8c2480000000	MOVQ 0x80(SP), CX										
  module.go:48620	0x656f62		8b54242c		MOVL 0x2c(SP), DX										
  module.go:48620	0x656f66		895150			MOVL DX, 0x50(CX)										
  module.go:48621	0x656f69		4883c470		ADDQ $0x70, SP											
  module.go:48621	0x656f6d		5d			POPQ BP												
  module.go:48621	0x656f6e		c3			RET												
  module.go:63000	0x656f6f		e84c9ae3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x656f74		e8479ae3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x656f79		e8429ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x656f7e		48c7c073ce1000		MOVQ $0x10ce73, AX										
  module.go:62983	0x656f85		e8369ae3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x656f8a		e8319ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x656f8f		e82c9ae3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x656f94		48c7c0f3cf1000		MOVQ $0x10cff3, AX										
  module.go:63000	0x656f9b		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:63000	0x656fa0		e81b9ae3ff		CALL runtime.panicBounds(SB)									
  module.go:63200	0x656fa5		48c7c0ebcf1000		MOVQ $0x10cfeb, AX										
  module.go:63200	0x656fac		e80f9ae3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x656fb1		48c7c0efcf1000		MOVQ $0x10cfef, AX										
  module.go:63000	0x656fb8		e8039ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x656fbd		48c7c0e7cf1000		MOVQ $0x10cfe7, AX										
  module.go:62983	0x656fc4		e8f799e3ff		CALL runtime.panicBounds(SB)									
  module.go:48610	0x656fc9		4889c8			MOVQ CX, AX											
  module.go:48610	0x656fcc		bb60171000		MOVL $0x101760, BX										
  module.go:48610	0x656fd1		e80ac0f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn24(SB)			
  module.go:48611	0x656fd6		488d05433a1f00		LEAQ 0x1f3a43(IP), AX										
  module.go:48611	0x656fdd		488d1d0cb32a00		LEAQ 0x2ab30c(IP), BX										
  module.go:48611	0x656fe4		e8f717e3ff		CALL runtime.gopanic(SB)									
  module.go:62983	0x656fe9		48c7c0d3cf1000		MOVQ $0x10cfd3, AX										
  module.go:62983	0x656ff0		e8cb99e3ff		CALL runtime.panicBounds(SB)									
  module.go:48604	0x656ff5		48c7c0fccf1000		MOVQ $0x10cffc, AX										
  module.go:48604	0x656ffc		0f1f4000		NOPL 0(AX)											
  module.go:48604	0x657000		e8bb99e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x657005		48c7c073ce1000		MOVQ $0x10ce73, AX										
  module.go:62983	0x65700c		e8af99e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x657011		e8aa99e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x657016		e8a599e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x65701b		48c7c077191000		MOVQ $0x101977, AX										
  module.go:63009	0x657022		e89999e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x657027		e89499e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x65702c		48c7c07f191000		MOVQ $0x10197f, AX										
  module.go:63009	0x657033		e88899e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x657038		e88399e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x65703d		48c7c087191000		MOVQ $0x101987, AX										
  module.go:63009	0x657044		e87799e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x657049		e87299e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x65704e		48c7c08f191000		MOVQ $0x10198f, AX										
  module.go:63009	0x657055		e86699e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x65705a		e86199e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x65705f		48c7c097191000		MOVQ $0x101997, AX										
  module.go:63009	0x657066		e85599e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x65706b		e85099e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x657070		48c7c09b191000		MOVQ $0x10199b, AX										
  module.go:62983	0x657077		e84499e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x65707c		0f1f4000		NOPL 0(AX)											
  module.go:63000	0x657080		e83b99e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x657085		e83699e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x65708a		e83199e3ff		CALL runtime.panicBounds(SB)									
  module.go:48515	0x65708f		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48515	0x657097		bb01000000		MOVL $0x1, BX											
  module.go:48515	0x65709c		b92c000000		MOVL $0x2c, CX											
  module.go:48515	0x6570a1		e83a50f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn2(SB)			
  module.go:48516	0x6570a6		488d0573391f00		LEAQ 0x1f3973(IP), AX										
  module.go:48516	0x6570ad		488d1d3cb22a00		LEAQ 0x2ab23c(IP), BX										
  module.go:48516	0x6570b4		e82717e3ff		CALL runtime.gopanic(SB)									
  module.go:63000	0x6570b9		e80299e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x6570be		6690			NOPW												
  module.go:63026	0x6570c0		e8fb98e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x6570c5		e8f698e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x6570ca		e8f198e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x6570cf		e8ec98e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x6570d4		e8e798e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x6570d9		e8e298e3ff		CALL runtime.panicBounds(SB)									
  module.go:48559	0x6570de		4c89e0			MOVQ R12, AX											
  module.go:48559	0x6570e1		488d0d384a2000		LEAQ 0x204a38(IP), CX										
  module.go:48559	0x6570e8		e89370dcff		CALL runtime.panicdottypeE(SB)									
  module.go:63165	0x6570ed		488d052c391f00		LEAQ 0x1f392c(IP), AX										
  module.go:63165	0x6570f4		488d1d45c92a00		LEAQ 0x2ac945(IP), BX										
  module.go:63165	0x6570fb		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:63165	0x657100		e8db16e3ff		CALL runtime.gopanic(SB)									
  module.go:62983	0x657105		e8b698e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x65710a		e8b198e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x65710f		e8ac98e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x657114		e8a798e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x657119		e8a298e3ff		CALL runtime.panicBounds(SB)									
  module.go:48549	0x65711e		8b7c2428		MOVL 0x28(SP), DI										
  module.go:48549	0x657122		ffcf			DECL DI												
  module.go:48549	0x657124		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48549	0x65712c		bbf01a1000		MOVL $0x101af0, BX										
  module.go:48549	0x657131		b937000000		MOVL $0x37, CX											
  module.go:48549	0x657136		bee01a1000		MOVL $0x101ae0, SI										
  module.go:48549	0x65713b		41b8281b1000		MOVL $0x101b28, R8										
  module.go:48549	0x657141		e85ac2f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn27(SB)			
  module.go:48550	0x657146		488d05d3381f00		LEAQ 0x1f38d3(IP), AX										
  module.go:48550	0x65714d		488d1d9cb12a00		LEAQ 0x2ab19c(IP), BX										
  module.go:48550	0x657154		e88716e3ff		CALL runtime.gopanic(SB)									
  module.go:48547	0x657159		4c89e8			MOVQ R13, AX											
  module.go:48547	0x65715c		4889fb			MOVQ DI, BX											
  module.go:48547	0x65715f		488d0dba492000		LEAQ 0x2049ba(IP), CX										
  module.go:48547	0x657166		e81570dcff		CALL runtime.panicdottypeE(SB)									
  module.go:63165	0x65716b		488d05ae381f00		LEAQ 0x1f38ae(IP), AX										
  module.go:63165	0x657172		488d1dc7c82a00		LEAQ 0x2ac8c7(IP), BX										
  module.go:63165	0x657179		e86216e3ff		CALL runtime.gopanic(SB)									
  module.go:62983	0x65717e		6690			NOPW												
  module.go:62983	0x657180		e83b98e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x657185		e83698e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x65718a		e83198e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x65718f		e82c98e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x657194		e82798e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x657199		e82298e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x65719e		6690			NOPW												
  module.go:62983	0x6571a0		e81b98e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x6571a5		e81698e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x6571aa		e81198e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x6571af		e80c98e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x6571b4		e80798e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x6571b9		e80298e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x6571be		48c7c083ce1000		MOVQ $0x10ce83, AX										
  module.go:62983	0x6571c5		e8f697e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x6571ca		48c7c07fce1000		MOVQ $0x10ce7f, AX										
  module.go:62983	0x6571d1		e8ea97e3ff		CALL runtime.panicBounds(SB)									
  module.go:48623	0x6571d6		bb60171000		MOVL $0x101760, BX										
  module.go:48623	0x6571db		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:48623	0x6571e0		e8fbbdf7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn24(SB)			
  module.go:48624	0x6571e5		488d0534381f00		LEAQ 0x1f3834(IP), AX										
  module.go:48624	0x6571ec		488d1dfdb02a00		LEAQ 0x2ab0fd(IP), BX										
  module.go:48624	0x6571f3		e8e815e3ff		CALL runtime.gopanic(SB)									
  module.go:62983	0x6571f8		48c7c073ce1000		MOVQ $0x10ce73, AX										
  module.go:62983	0x6571ff		90			NOPL												
  module.go:62983	0x657200		e8bb97e3ff		CALL runtime.panicBounds(SB)									
  module.go:48463	0x657205		48c7c0b0cf1000		MOVQ $0x10cfb0, AX										
  module.go:48463	0x65720c		e8af97e3ff		CALL runtime.panicBounds(SB)									
  module.go:48463	0x657211		90			NOPL												
  module.go:48457	0x657212		4889442408		MOVQ AX, 0x8(SP)										
  module.go:48457	0x657217		48895c2410		MOVQ BX, 0x10(SP)										
  module.go:48457	0x65721c		f20f11442418		MOVSD_XMM X0, 0x18(SP)										
  module.go:48457	0x657222		e8797ae3ff		CALL runtime.morestack_noctxt.abi0(SB)								
  module.go:48457	0x657227		488b442408		MOVQ 0x8(SP), AX										
  module.go:48457	0x65722c		488b5c2410		MOVQ 0x10(SP), BX										
  module.go:48457	0x657231		f20f10442418		MOVSD_XMM 0x18(SP), X0										
  module.go:48457	0x657237		e944f4ffff		JMP dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).Xcocoon_sketch_add(SB)	
