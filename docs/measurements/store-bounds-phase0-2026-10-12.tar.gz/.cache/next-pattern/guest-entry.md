# Guest entry review: completed stores and bounds facts

Read-only source/machine review at clean documentation-only HEAD `4f9276a`, above merged `6be3980`. No production edits, compilation, test, profiling, or measurement commands were run for this review. This ignored note is the only authored artifact.

## Verdict

Consider a phase-zero **descending store32 bounds-check** diagnostic. The default successful scalar export has a checked store at a higher constant address followed by a lower checked store. Existing optimized SSA and ordinary assembly retain the lower bounds check. This is a new write-to-write containment hypothesis, not the rejected adjacent load64/store64 probe, numeric shortcut, or host unit-reply rewrite. There is no measured gain and no predicted percentage.

Do not force a preservation-only store-to-load32 experiment into the warmed scalar workload: the exact same-explicit-base opportunity found in fn176 is initial-empty-store work.

## Source and compiler evidence

Generated source: `examples/datadog/go/dd/internal/wasm/module.go`, SHA-256 `626550cafa323c490a6a2ec6b2b341656c40e223c7c84701e414078633dcc298`.

The successful unit Add path at lines 48613–48616 is:

```go
t42 := int32(load32(m.memory, uint32(i32(1101796))))
store32(m.memory, uint32(i32(1101804)), uint32(t42))
store32(m.memory, uint32(i32(1101800)), uint32(i32(0)))
store32(m.memory, uint32(i32(1101808)), uint32(i32(0)))
```

The first store checks inclusive endpoint 1101807. Once it completes, the lower second store's inclusive endpoint 1101803 is in the same logical memory. The third store has a new maximum endpoint 1101811: its original check and position must remain. Keep all three stores, operands, values, and evaluation order.

There are three occurrences of this exact literal-address descending triple: Sketch.Close at 48122–48124, Sketch.AddMany at 48426–48428, and Sketch.Add at 48614–48616. This is a literal-source occurrence count, not a generic eligibility inventory or dynamic cost estimate. The retained publication-view rule covers exact two-store same-base offsets 0/4 plus narrow restoration/exit structure; it does not capture this three-store sequence.

Existing ordinary Go1.26.8 baseline assembly from the last unit-reply round, `.cache/unit-reply-phase0/baseline-Xcocoon_sketch_add.asm`, SHA-256 `1a1d9622fdeb21f35add3dd2fc5dff2a7905a4c38ab4ecee6c5d652e05f51c9c`, has:

```text
0x656e6e CMPQ DX, $0x10cfef   first store endpoint
0x656e75 JBE ...              first store trap
0x656e81 MOVL DX, 0x10cfec(SI) first store
0x656e87 MOVQ 0x38(CX), DX     reload memory length
0x656e8b CMPQ DX, $0x10cfeb   lower second endpoint remains
0x656e92 JBE ...              second store trap
0x656e9c MOVL $0, 0x10cfe8(DX) second store
0x656ea6 MOVQ 0x38(CX), DX
0x656eaa CMPQ DX, $0x10cff3   new maximum: retain
0x656eb1 JBE ...
0x656ebb MOVL $0, 0x10cff0(DX) third store
```

Prior optimized SSA for the same unchanged guest source, `.cache/scalar-next/ssa/baseline/(*Module).Xcocoon_sketch_add_01__opt.dump`, SHA-256 `20f5207b64cc018745d7f7638de8c4222c756821dd5cbc7d3a47ad7b95f24a60`, lines 1325–1370, retains endpoint constants 1101807/1101803/1101811 and three `IsInBounds`/`PanicBounds` pairs. After the first store (`v2286`), it reloads the Module slice (`v2297`) and checks 1101803 (`v2306`), rather than retaining the former memory-length fact. That round's recorded SSA command used `/usr/lib64/go/1.26/bin/go` as then installed; its provenance remains in `.cache/scalar-next/ssa-provenance.json`. Fresh current pinned-toolchain SSA/profile confirmation remains the parent's responsibility; this review does not rebuild or relabel old output as fresh evidence.

## Store-to-load32 result

`internal/harden/contained_loads.go:136–174` currently clears its fact map on non-assignment statements, including canonical store calls. A successful owned, canonical store can semantically preserve slice-header/length facts, even when its backing-byte write overlaps a later load. The later load must reread the changed bytes; this is not value forwarding.

fn176 lines 35837–35839 contains a checked store at `uint64(uint32(v3))+16`, a pure local zero assignment, then a checked load32 at `uint32(v3)`. The successful store establishes endpoint base+19, sufficient for the subsequent base+3 load. Existing ordinary `.cache/unit-reply-phase0/baseline-fn176.asm` retains both bounds checks and the intervening header reload. However, the sequence is under `if v6 == 0`, the empty-store path. The warmed default repeated scalar's bin-update path is elsewhere. A nearby store via inferred copy `t32 := v3` followed by loads via `v3` is not the same explicit binding and crosses a preceding conditional join; do not relax type/copy/CFG rules merely to select it. The warmed l7 branch already benefits from retained contained load32 checks before its conditional/base reassignment, followed by the previously rejected load64/store64 pair.

## Semantic requirements

The credible store hypothesis depends on complete existing helper/type/binding and owned-construction proofs, not the function names or constants in the Datadog module. Canonical store32 writes owned backing bytes; it does not alter the receiver's memory slice header or scalar local bindings. A trusted nonconcurrent native host may replace memory at a guest import, so imports, growth, header writes, receiver/base rebinding, control joins, labels, and unproved calls remain fact barriers. Unsafe fabricated backing aliases into the Module object are outside the existing ownership proof and must remain ineligible.

Prove **both address and value expressions pure**. Go evaluates the `m.memory` argument before address/value arguments. An impure value expression could replace the header after the old slice was captured; then a successful store into the old slice does not establish bounds for a later access through the new header. Numeric builtin conversions and complete-body-validated i32/i64 identities are suitable; name-only matching, shadowing, pointer operations, and unproved methods are not.

Facts become available only after the original store completes. Preserve all original first/new-maximum guards and their exact execution positions, byte writes, values, and argument evaluation. The lower guard may disappear only after the higher completed access. Do not hoist a later maximum check: a trap before the preceding stores changes visible partial writes. Do not merge stores, forward loads, or reorder descriptor publication.

Use logical length, including len<cap. Restrict addresses to independently proved zero-extended u32 or widened u32-plus-u32-literal domains with nonoverflowing endpoints, including on native 386 before any uintptr conversion. Canonical helper fallback, endian reversal, signatures, and nosplit directive stay unchanged. The normal helper oracle is Wasm little endian on every actual native architecture; mutable-flag simulations on little endian must remain separately labelled.

Constant-address facts are a distinct structural possibility from the retained explicit-base-local load rule. Any later generic predicate must validate the full bound expression/type and collision/shadowing/ownership scope; do not produce a payload/export/line-number whitelist. Production eligibility is not proved by a SHA-pinned phase-zero exact-site overlay.

## Smallest honest diagnostic and proof

Use untouched, copied-check helper, and guard-deleted helper controls, all full-source SHA-pinned. Initially change only the lower second store's unsafe-path endpoint check at the exact literal triples, using a copied canonical store32 with complete fallback/endian body unchanged. Keep the first and new-maximum third store checked. Do not add a slice-header view in this first diagnostic: that would combine two compiler hypotheses. The copied-check control is necessary because helper placement/inlining can change machine layout despite unchanged behavior.

Before timing, independent executable proof must compare complete relevant bytes, argument/value/import event order, exact trap position, and partial writes. Important cases are first-store-short logical memory, exact first-store endpoint success, and length sufficient for first/lower but too short for the third/new maximum: in that last case the first and second writes must be visible when the third traps. Include len<cap, misalignment, overlapping writes, subsequent loads seeing changed bytes, native 32-bit widened/high addresses, wrap versus widening, header shrinking/import effects in operands, labels/loops/gotos, and builtin/helper/type shadowing. Deleting the first/new-maximum checks, skipping a store, or crossing a header-changing call must be rejected by executable semantic mutants with bounded physical backing. WAT/native comparisons and actual amd64/386 execution prove a bounded scope; mutable fallback modes do not prove a native big-endian port or a generic hardener predicate.

Fresh scalar profiles should establish execution frequency; existing assembly only establishes an unoptimized guard, not an attainable saving. Qualification should retain the ordinary checked façade and compare default scalar plus negative/increasing/broad holdouts, SQL, batch, trace, and streaming controls. A raw export win alone is insufficient. Frame, instruction, register-allocation, and linked placement observations are supporting evidence, not causal attribution for unrelated workloads. No public-contract, guest-math, or M1-performance claim is warranted from this entry review.

All review tool activity stopped after writing this note and reporting it to the parent.
