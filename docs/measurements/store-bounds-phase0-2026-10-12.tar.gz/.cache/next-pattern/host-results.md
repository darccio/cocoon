# Host results audit: two contained-store checks, phase 0

2026-10-12. Read-only review of paired/summary.json, records, full benchstat,
outcome-table, frozen hashes and independent reference provenance. No build,
tests, profiles or timings run here; only this ignored note is written.
Verdict: strict NO-GO under the predeclared default-scalar rule. Retain exact
evidence/docs only; no generic production specification/implementation or API/ABI
change. Quality gates are subsequent work, not claimed passed by this audit.

## Provenance and scope

All411 frozen hashes match at audit.966 raw rows split483 per round, with
baseline/probe/control266 each and independent reference168. Seven alternating
500ms process samples and seven reversed1s samples retain every row.364 rows
report actualP1 (280 matched DD +84 P1 streams);168 report actualP16 streams;
434 original/raw rows lack an in-window processor metric. Recorded framework16/
environment policy is not itself a metric from those434 rows. Official pinned
Go1.26.8, CGO0, GOAMD64v1 and PGOoff are used, with default GC/memory/debug/
experiment settings. Powersave/boost/frequency snapshots and full affinity are
provenance, not a fixed-clock/absence-of-external-work guarantee. All local
build/test/lint/fuzz/profile/reviewer work stopped before timing.

Clean4f9276a has unchanged production runtime/facades/shim/Wasm. The ignored
whole-source-pinned authored hardener postpass selects ONLY fn176 captured lower
store32 and Add's middle absolute metadata store32; it retains all writes,
first/new-maximum guards, endian/portable fallback, evaluation and partial-trap
order. Probe/control differ only by one guard line in the copied helper (two
calls); all318 existing contained-load calls remain. This is source-specific
ceiling evidence, not a generic predicate. Static site removal and unchanged
frames do not establish per-check causal cost: the export's instruction count
even rises642→643 while losing its redundant guard.

Fresh independent reference preserves56 unchanged authored inputs and their exact
copied bytes, ten actual command boundaries and48 successful functional1x oracle
leaves. Wasm8bda5ff7…/own hardened module5ff25314…/officialGo binary5c4f361a…
reproduce prior corrected-toolchain hashes. Own ABI2 borrowed-input/background-
context/four-instance ownership and original batch/trace input differences remain
context limits; success corpus matching is not contract equivalence. No Cocoon
implementation is transplanted, no reference source is edited, and functional1x
rows are excluded from qualified samples. Old systemGo distribution/ELF/session
times are not mixed into this run.

## Strict disposition and retained positives/negatives

Original default scalar87.81→88.03 ns(+0.251%,p=.620) SCREENING fails the required
gain against untouched production. Confirmation88.02→86.71 ns(-1.488%,p=.005)
does detect a gain, as do probe/control89.34→88.03 and88.71→86.71 ns
(-1.466/-2.255%,p=.007/.002). Those positives do not satisfy BOTH comparators in
BOTH preplanned rounds. Do not call the original scalar result repeatable or
retime a selected comparison to rescue it.

Increasing P1 scalar repeats gains against baseline AND control; repeated1024
batch repeats smaller primary gains but its confirmation versus control is
undetected(.073). Varied scalar primary screening gain does not confirm(.073),
negative-bin screening .053 is undetected while confirmation .017 detects a gain.
Broad scalar primary trends-0.73/+0.25%, both undetected, and is SLOWER than
control by+0.81/+0.56%, undetected. RawGuest's-1.34/-1.01% detects only in
confirmation(.097/.005), with the same screening-only limitation against control
(.073/.002). These workload/context outcomes do not replace original default
scalar promotion.

Original SQL+0.88/-0.37%, varied SQL+0.93/+0.15% and SQL holdout+1.53/+0.02%
have no detected primary differences; their upward medians remain visible.
Original batch-0.37/-0.74% is undetected; broad8192 batch+0.62/-0.17% is
undetected. Trace+0.005/-1.06% is undetected against baseline despite detected
probe/control gains. Changes in untouched/control SQL/trace functions, source/
helper/debug/linkage placement, frequencies and state calibration remain
confounders; do not attribute unrelated movements to the two removed store
checks or add earlier gains. Unadjusted exploratory p-values and nondetection
are not equivalence. No repeated detected same-comparator guard loss rescues
the already-failed promotion rule.

All supported scalar/batch/raw rows allocate zero. SQL and trace supported roles
have one timed Go allocation; B/op differences include setup/calibration
amortization and do not establish retained/processRSS savings. Matched supported
scalar/repeated batch observe1,179,648 logical guestB, broad8192 batch1,441,792,
with zero timed growth. These reported per-module observations exclude unrelated
homes, pool/test/process allocations and reference memory where unreported.

## Current M1 limits: baseline, not rejected probe

Absolute limits remain55.44 ns scalar and2215.4 ns SQL. Fresh reference×1.10 is
session-specific and applies to the ORIGINAL pair, not arbitrary holdouts.

| Scope | Baseline screen / confirm | Fresh reference screen / confirm | Fresh110% limits |
| --- | ---: | ---: | ---: |
| Scalar |87.81 /88.02 ns|56.08 /55.78 ns|61.688 /61.358 ns|
| SQL |2.164 /2.173 µs|2.005 /1.962 µs|2.2055 /2.1582 µs|

Scalar overhead versus reference is56.580/57.798%; it misses fresh limits by
26.122/26.662 ns and absolute by32.370/32.580 ns. SQL overhead is7.930/10.754%:
screening meets fresh median cap by41.5 ns, but CONFIRMATION FAILS by14.8 ns;
both meet absolute by51.4/42.4 ns. Do not carry the previous round's narrow SQL
fresh-limit pass forward as current acceptance. Rejected probe88.03/86.71 ns
still misses both scalar limits; its2183/2165 ns SQL also misses confirmation
fresh2158.2 ns by6.8 ns. M1 remains unaccepted regardless of scope-positive rows.

## Six identical-binary stream brackets

All three stream ELFs are BYTE-IDENTICAL SHAa2076ad9349c334f028e1c73cc166004c15da1debab79e8d2c349d851bc373bf.
Labels baseline/control/probe identify scheduling positions in this guest-only
experiment; there is NO changed streaming implementation. All252 raw stream
rows verify actual processors (84 P1,168 P16), allocations, outputs, bytes and
groups. One complete operation is a16KiB NewStream/Write/End/Close lifetime;
Open/home warmup, corpus/full oracle are outside timing. Nominal Chunk64,
Retain32 finite owned-output groups, timed construction/owned replies/disposal
are shared. Fixed has256 writes+End; holdout averages343.5 varied/empty writes+
End across four patterns. Raw custom writes/s EXCLUDES End and is not a ratio
reconstructed from rounded ns/op. StandaloneHomesP denotes standalone methods,
not typed Batch. Independent pool1 is not another resource execution lane.

| Scope | Screen baseline / control / probe writes/s | Confirm baseline / control / probe writes/s |
| --- | ---: | ---: |
|P1 one home, Fixed|1,559,534 /1,524,947 /1,551,217|1,586,497 /1,589,702 /1,571,390|
|P1 one home, Holdout|1,689,905 /1,712,223 /1,702,940|1,712,783 /1,716,978 /1,722,506|
|P16 one home, Fixed|1,308,753 /1,299,817 /1,286,113|1,307,826 /1,329,628 /1,321,795|
|P16 sixteen homes, Fixed|9,454,382 /9,260,722 /8,520,591|9,488,334 /9,429,231 /9,189,025|
|P16 one home, Holdout|1,435,080 /1,491,548 /1,374,046|1,463,971 /1,467,015 /1,464,211|
|P16 sixteen homes, Holdout|9,649,156 /9,611,213 /9,087,597|9,328,274 /9,597,516 /9,867,149|

| Scope | Screen baseline / control / probe complete streams/s | Confirm baseline / control / probe complete streams/s |
| --- | ---: | ---: |
|P1 one home, Fixed|6,092 /5,957 /6,059|6,197 /6,210 /6,138|
|P1 one home, Holdout|4,920 /4,985 /4,958|4,986 /4,998 /5,015|
|P16 one home, Fixed|5,112 /5,077 /5,024|5,109 /5,194 /5,163|
|P16 sixteen homes, Fixed|36,931 /36,175 /33,284|37,064 /36,833 /35,895|
|P16 one home, Holdout|4,178 /4,342 /4,000|4,262 /4,271 /4,263|
|P16 sixteen homes, Holdout|28,091 /27,980 /26,456|27,157 /27,940 /28,725|

Every fixed row250 Go allocations,257 outputs,16,392 ownedB and9 groups per
complete stream; every holdout268 allocations,344.5 outputs,16,390 ownedB and11
groups. P1/16-home fixedB/op17,496 and holdout19,604; defaultP16 reports small
calibration-dependent additions (about17,508–17,516 and19,616–19,624 medianB/op).
Sixteen-home leaves explicitly report configured-homes16/configured-pool1;
default leaves use ResourceInstances default1/Instances1. Configured counts
are not proof of retained live homes/resources or total host/guest heap bounds.

Keep adverse identical-binary medians visible. Probe-labelled versus baseline:

| Scope | Screen / confirm latency deltas | p-values |
| --- | ---: | ---: |
|P1 one home, Fixed|+0.54% /+0.96%|.710 /.620|
|P1 one home, Holdout|-0.77% /-0.56%|.209 /.805|
|P16 one home, Fixed|+1.76% /-1.06%|.535 /.710|
|P16 sixteen homes, Fixed|+10.96% /+3.25%|.456 /.620|
|P16 one home, Holdout|+4.44% /-0.02%|.902 /1.000|
|P16 sixteen homes, Holdout|+6.18% /-5.46%|.805 /1.000|

All stream primary/secondary differences are undetected in both rounds, including
sixteen-home Fixed+8.69/+2.61% versus control. Large point estimates despite
identical bytes demonstrate residual run variability, not candidate effects.
Nondetection does not establish stream equivalence or resolve the historical
default small-stream overhead. Rates are OBSERVED full-lifetime throughput under
one/sixteen serialized homes, not strict ceilings, fairness, processRSS or maximum
capacity bounds. P1 coverage improves this phase0's controls, but a future actual
generic production pass still requires newly regenerated modules/proofs and a
separate broad default/sharded/Batch/mixed streaming qualification.

The checked ABI3 ownership/admission/reset/current-memory/reply/MaxMemory/poison/
drain contract remains unchanged in every role; performance failure is not
permission to relax it. Original default scalar screening alone triggers the
recorded no-go, so retain the measured positives/negatives, proofs/provenance and
all raw bytes without broadening selection, tuning source layout or retiming
chosen subsets. No production contract or generic pass is retained.
