from pathlib import Path
import os,json,subprocess,datetime
root=Path.cwd();out=root/'.cache/next-pattern';go=root/'.cache/toolchains/go1.26.8/go/bin/go';env=dict(os.environ,PATH=str(go.parent)+':'+os.environ['PATH'],GOTOOLCHAIN='local',CGO_ENABLED='0',GOARCH='386',GOAMD64='v1',GOCACHE=str(root/'.cache/go'),GOFLAGS='-buildvcs=false');records=[]
for role in ('baseline','control','probe'):
 argv=[str(go),'test','-pgo=off',*(['-overlay='+str(out/(role+'-overlay.json'))] if role!='baseline' else []),'./rt','./examples/datadog/go/dd/...','./testdata/compute/go/compute/...','./testdata/streaming/go/streaming/...','-count=1'];name=role+'-native386.log'
 with (out/name).open('x') as log:
  print('COMMAND',json.dumps(argv),file=log,flush=True);r=subprocess.run(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT);print('EXIT',r.returncode,file=log)
 records.append({'role':role,'argv':argv,'cwd':str(root),'environment':{k:env[k] for k in ('PATH','GOTOOLCHAIN','CGO_ENABLED','GOARCH','GOAMD64','GOCACHE','GOFLAGS')},'exit':r.returncode,'log':name,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()});(out/'native386-records.json').write_text(json.dumps(records,indent=2)+'\n');assert r.returncode==0,name;print('PASS',role,'native386 runtime/all3consumer contracts/differential/bulk-memory',flush=True)
