# Descending store32: applied private phase-0 review

Read-only audit at clean4f9276a2736a02ff454609c80fcc09d047d1160b. No compilation, tests, profiles, benchmarks, tracked changes or generic production specification by this reviewer. Current source/proof/artifacts/plan and recorded logs inspected only. All reviewer tools stop after this note before root refreshes/finalizes config and freezes.

## Disposition

No remaining source/proof/matrix blocker for the declared isolated966-sample diagnostic. This is approval to measure this exact source-pinned two-site ceiling, not to retain implementation, broaden the existing publication/contained-load predicate, or claim a scalar/M1 improvement. Generic binding/eligibility/maintainability proof and a separately committed private spec must precede any later production implementation; any new public ABI still needs explicit operator approval.

## Exact source/control semantics

The ignored hardener cause differs from production harden.go only by invoking phase0DescendingStores on final rewritten/formatted bytes. Existing publication capture, contained-load selection/helper, bulk hardening and other checks remain unchanged. Probe/control postpasses differ only in phase0CheckedStore false/true. A whole-module SHA626550cafa323c490a6a2ec6b2b341656c40e223c7c84701e414078633dcc298 pins all bindings, types, construction/backing preconditions, globals, canonical helper/directives and selected adjacency. Function IDs and literal addresses are deliberate diagnostic selectors, not proposed production eligibility. Nonmatching modules return unchanged bytes. No generic binding proof follows from the AST parser/string selection.

Only two callee identifiers change, with a distinct private appended canonical store32 copy. In fn176, the existing fresh cocoonMemoryView2 capture precedes checked offset4 store and then the changed loweroffset0 store. Earlier checked endpointuint64(uint32(v13))+7 proves loweruint32(v13)+3; this domain cannot uint64-overflow, and a386 unsafe pointer cannot be reached when its original first guard rejects the large address. v13 is a stable primitive local in these adjacent stores, valuesuint32(v3)/uint32(v1) have no calls/imports/header effects. The first store writes bytes in separately owned backing and cannot mutate the local captured slice header/base under the existing trusted-host precondition. The later write still executes with exactly its original value and byte address.

In Xcocoon_sketch_add, checked literal1101804 store dominates changed1101800 store, followed by checked newmaximum1101808 store. These literalu32 addresses do not wrap; the first logical endpoint1101807 covers middle1101803. Exact identity i32 wrappers and primitive t42/zero values are pure, with no call/label/header update between the three stores. The final endpoint1101811 stays checked, retaining the visible first/middle writes when it traps. The preceding t42 load remains checked/in place. No write/order/value/trap-prefix/guest-state change or header capture is introduced. First/newmaximum guards remain exactly positioned.

The copied helper retains exact generic widths, nosplit, big-endian reversal, unsafe write and checked unaligned fallback; probe deletes only mem[uint64(addr)+3] in its unsafe branch. Control copies the complete original helper under the same new name. Direct byte checks prove control→probe differs only by that one helper statement, not by restoring the old contained-load helper. All318 existing DD cocoonLoad32InRange sites and helper bytes remain untouched. The three baseline regenerated modules equal committed bytes; allcompute/streaming variants also equal committed bytes. Timing overlays map only regenerated modules; runtime, facade, shim, input/reply/ownership/reset/poison/drain and benchmark harness source remain original. The separate authored hardener/emitter overlays retain the generation cause and procedural startup failure, rather than an isolated generated-only implementation.

## Compiler and executable proof evidence

Ordinary code summary shows fn176 static panic-bounds78→77 with frame128/text5462 fixed and instructions1309→1307. Scalar export has57→56 checks with frame112/text3004 fixed, but instruction count642→643 increases: retain that negative shape result; a removed source check is not a proved latency saving. fn96/runtime/facade sampled shapes stay unchanged. The recorded control audit compares exact local instruction encodings and instructions for baseline/control fn176,fn96,export,ResultView,ResultUnit,Range and facade closure as equal even though debug-linked ELF hashes differ. This controls the copied-check shape without isolating per-check causal nanoseconds.

The independent helper/caller proof pins its actual normalized helper against the probe body. Source-provenance hashes match current proof .go/.py/.mod bytes. Its subtraction-based logical oracle compares all value/address events, write counts/trap stage and full current/old backing bytes; it does not invoke the unsafe endpoint implementation. Twenty-eight scenarios plus two carrier controls and seven direct typed fragments cover actual metadata1101800, captured widenedfirst/u32lower carriers, first/newmaximum short/zero/exact boundaries, length<capacity, unaligned/high-bit/wrapped bases, overlap and header shrink/replace/growth/impure-value/captured-old-view models. Header/overlap extras are semantic models, not more selected sites or a generic exclusion predicate. Both recorded nativeamd64/386 final logs pass and include five required semantic child rejections: missing first guard, missing newmaximum guard, crossing header barrier, reordered writes and changed lower value. The parent requires named assertion failure plus store-prefix mismatch/nonzero; compile/startup failures cannot satisfy it. Mutant unchecked targets stay within accessible spare backing. Four endian/unaligned controls are explicitly simulations; canonical oracle alwaysLE and no realbig-endian/arm64 claim follows. No WAT generic-predicate proof is claimed by this bounded helper-only fixture; actual variant guest suites provide current original-Wasm/differential contracts, and a later generic production pass would need authoredWAT proof.

Recorded all-three ordinary variants' whole runtime/hardener/three-consumer oracle commands succeed, with actual native386 DD/proof coverage disclosed. This reviewer did not execute them. Baseline DD binary exactly reproducesc73daeca03069285b5b26701646ac0c94ece1a80c62c5905eff795324db3d3d0. Allthree stream binaries are byte-identicala2076ad9349c334f028e1c73cc166004c15da1debab79e8d2c349d851bc373bf; timing those as named roles is a bracket/system-variation control only. A stream gain or regression cannot be attributed to this DD-only source experiment. Functional1x runs/initial go-run .go argument startup failure are excluded from performance samples and retained as preparation/procedural evidence.

## Measurement and retention boundary

Plan checks match19 groups; 69 processes/pass ×14passes=966 raw rows:12 original/matchedDD leaves×4roles, rawGuest×3, six full-stream leaves×3. Role coverage is364 measuredP1 rows (280matchedDD+84defaultP1stream),168 measuredP16stream,434 unchangedframeworkP16 rows without leaf metrics. P1/P16 stream selectors correctly use full16KiB New/Write/End/Close nominal64B/Retain32 fixed/variable-empty holdout, defaultonehome atboth and16homes atP16. Measured leaf setters/assertions/custom metrics are unchanged; testing suffix16 does not by itself establishP1 or scalar parallel contention. Scalar original increasing calibrated prefixes, cyclic matched workloads and independent reference remain distinct state/corpus/contracts.

All fresh ordinary roles and reference use the same official local Go1.26.8, CGO0, amd64v1, PGOoff and unchanged corpora/harnesses. Source/control/helper/binary/proof/reference/driver identities must be frozen after this final note. Seven interleaved500ms passes plus independent reversed1s sevenpasses preserve all rows, metrics, negatives and exploratory unadjusted p-values. All local tool activity stops during timing; root cannot prove absence of unrelated external work.

Preregistered promotion is strict: original/default checked-facade scalar must improve versus untouched and copied-check control in both rounds, with no repeated detected same-comparator scalar/SQL/batch/trace/P1/P16stream guard loss. Failed primary/guard/proof=>evidence-only; no source-order rescue, altered corpus/holdout/function-ID targeting, selected retiming or additive profile/old-no-go gains. Positive rawGuest or other workloads alone cannot substitute for defaultscalar. Unchanged-byte stream variation remains visible as a bracket rather than causalguard effect; any later generic pass requires real regenerated P1/P16 stream qualification. A positive two-site diagnostic only supports drafting a private source-independent predicate and further proofs; allthreeproofs/locks, staged/darna/gates+integration/repeat builds and fresh production pairs remain separate. No implementation commit or M1 acceptance is yet justified.

## Reviewed identities

```json
{
  ".cache/next-pattern/probe-stores.go": "8fd899a5022637bc46c73a98f88a5b0d9b0e4f91345aacd0b4046f479cb4d1ea",
  ".cache/next-pattern/recheck-stores.go": "a823f6c66c9aeeea697567a59e0a5cdd779a11db6dd31a5cd21f0fef07e9df49",
  ".cache/next-pattern/probe-harden.go": "fdcb0c788d2aeceaedd270415e3e316b567ebd20bae5e90b67fdf827c708dfe0",
  ".cache/next-pattern/prepare-probe.py": "14d4f82e74e75c0b5a25416b5230d72cb051199f401151358fcafa11778e1967",
  ".cache/next-pattern/generate_modules.go": "aed861193f8548401f53b1d44cfa9242c59173e31727f420a71a10e4eac4f0f3",
  ".cache/next-pattern/dd-baseline-module.go": "626550cafa323c490a6a2ec6b2b341656c40e223c7c84701e414078633dcc298",
  ".cache/next-pattern/dd-control-module.go": "dcd55a3ee9e78af66cd4ad1c433121acb3bd35e55ad77898ee3014e1a5a01017",
  ".cache/next-pattern/dd-probe-module.go": "999dc659125729f0413b6526dd8412e493970409598ce9a3142db9c6be0b7a0c",
  ".cache/next-pattern/probe-inventory.json": "3993af6a34948b5554174812e64bab5b0382097eaca641d7b4d5b8ed0490944f",
  ".cache/next-pattern/qualification-plan.json": "f06b9ff3e4c4cf2efaf1891bb500aaf8ba0e92e8237fb018ce24e7b847f44d1c",
  ".cache/next-pattern/decision-plan.json": "4bd25e381860631580f7fb3b7d59f2d3a3c03e2c790110a10583ff32d732b7ee",
  ".cache/next-pattern/qualification-config.json": "563017c995a0e0701694264407f6a5b18b1ffaf13750d9725560f1f1e570f6f8",
  ".cache/next-pattern/machine-code-summary.json": "b591a9c5d4f3500b9ceeecd3e47accd3914870653f3f98679ac8fc6515adb3de",
  ".cache/next-pattern/machine-code-control-audit.json": "c18cbdf5e3b9e5fbfa12cfc4134505a4d68b7106bcd758f2e81efee7ee033841",
  ".cache/next-pattern/proof/prepare.py": "fbd6a1bf57bbd93f43683e61e539b37e449becd749cf1c6a75446f06340f8026",
  ".cache/next-pattern/proof/proof_test.go": "7152fc526ae359343e4d64e95ebf6ae054e8fd0455d983c12e6e592adee8def7",
  ".cache/next-pattern/proof/helpers.go": "1e6102d8e4ccd247748a58233ff932643e7d1f0d8d9ec527461228b6062bc721",
  ".cache/next-pattern/proof/branch_helpers.go": "8fc7bebc3e165521883e8649d6b9ce881faffef1069da9b691eeb9d7ed0f76d5",
  ".cache/next-pattern/proof/source-provenance.json": "f83bf6a7011b2444136c304dd1590f6435072f87b83e9608cb40b2f855b3315a",
  ".cache/next-pattern/proof/README.md": "dc3aa6c5aa1337e57f5be362b179d256f558ae24c54d455dbf40ceb6d4b48b4d"
}
```
