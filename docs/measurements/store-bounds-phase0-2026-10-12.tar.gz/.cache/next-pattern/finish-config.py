from pathlib import Path
import json
root=Path.cwd();out=root/'.cache/next-pattern';config=json.loads((out/'qualification-config.json').read_text())
for p in out.rglob('*'):
 if p.is_file() and p.suffix in {'.go','.json','.jsonl','.py','.asm','.md','.dump','.wat','.log','.cpu','.txt','.wasm','.mod','.sum','.sh','.patch','.test','.emitter'} and 'reference-rust' not in p.parts and '__pycache__' not in p.parts and p.name!='frozen.json':
  config['artifacts'].append(str(p.relative_to(root)))
config['artifacts']=sorted(set(config['artifacts']));(out/'qualification-config.json').write_text(json.dumps(config,indent=2)+'\n');print('PASS',len(config['artifacts']),'files/tool inputs selected before freeze')
