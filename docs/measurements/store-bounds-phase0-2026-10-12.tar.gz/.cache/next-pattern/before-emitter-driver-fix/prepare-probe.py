"""Regenerate all three modules through authored phase-zero hardener overlays."""
from pathlib import Path
import datetime, difflib, hashlib, json, os, subprocess
root=Path.cwd(); out=root/'.cache/next-pattern'; go=root/'.cache/toolchains/go1.26.8/go/bin/go'
env=dict(os.environ,GOTOOLCHAIN='local',CGO_ENABLED='0',GOAMD64='v1',GOCACHE=str(root/'.cache/go'),GOFLAGS='-buildvcs=false')
env['PATH']=str(go.parent)+':'+env['PATH']
assert subprocess.check_output([str(go),'version'],env=env,text=True).strip()=='go version go1.26.8 linux/amd64'
records=[]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,args):
    rec={'name':name,'argv':[str(a) for a in args],'cwd':str(root),'environment':{k:env.get(k,'default') for k in ('PATH','GOTOOLCHAIN','CGO_ENABLED','GOAMD64','GOCACHE','GOFLAGS')},'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    with (out/(name+'.log')).open('x') as log:
        print('COMMAND',json.dumps(rec['argv']),file=log,flush=True)
        r=subprocess.run(rec['argv'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
        print('EXIT',r.returncode,file=log)
    rec.update(exit=r.returncode,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());records.append(rec)
    (out/'variant-build-records.json').write_text(json.dumps(records,indent=2)+'\n')
    assert r.returncode==0,name
    print('PASS',name,flush=True)
overlays={r:{} for r in ('baseline','control','probe')}; inventory=[]
for prefix,pkg in [('examples/datadog','dd'),('testdata/compute','compute'),('testdata/streaming','streaming')]:
    directory=root/prefix/'go'/pkg; raw=out/(pkg+'-raw-module.go'); production=directory/'internal/wasm/module.go'; wasm=directory/'testdata/module.wasm'
    run(pkg+'-translate',[go,'tool','wasm2go','-unsafe','-pkg','wasm','-o',raw,wasm])
    variants={}
    for role in ('baseline','control','probe'):
        emission='recheck' if role=='control' else role
        target=out/(pkg+'-'+role+'-module.go')
        run(pkg+'-'+role+'-generate',[go,'run','-pgo=off','-overlay='+str(out/(emission+'-emitter-overlay.json')),out/'generate_modules.go',raw,target])
        variants[role]={'path':str(target),'sha256':sha(target)}
        overlays[role][str(production)]=str(target)
        if role=='baseline' or pkg!='dd': assert target.read_bytes()==production.read_bytes(),(pkg,role,'baseline generation drift')
        (out/(pkg+'-'+role+'-module.patch')).write_text(''.join(difflib.unified_diff(production.read_text().splitlines(True),target.read_text().splitlines(True),fromfile=str(production.relative_to(root)),tofile='ignored/'+target.name)))
    if pkg=='dd':
        probe=(out/'dd-probe-module.go').read_text();control=(out/'dd-control-module.go').read_text()
        assert control.replace('\t_ = mem[uint64(addr)+3]\n','',1)!=probe # canonical first guard is retained
        idx=control.index('func cocoonStore32InKnownRange[')
        assert control[:idx]+control[idx:].replace('\t_ = mem[uint64(addr)+3]\n','',1)==probe
        assert probe.count('cocoonStore32InKnownRange(')==2
    inventory.append({'fixture':prefix,'package':pkg,'wasm':str(wasm),'wasm_sha256':sha(wasm),'production_module':str(production),'production_sha256':sha(production),'variants':variants})
for role,replace in overlays.items(): (out/(role+'-overlay.json')).write_text(json.dumps({'Replace':replace},indent=2)+'\n')
(out/'probe-inventory.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'fixtures':inventory,'overlays':overlays,'scope':'Two exact source-pinned descending store guards; all writes and first/newmaximum guards retained. No tracked production edit. All three regenerated from committed Wasm using authored hardener variants; control only restores the two new helper guards. Existing contained-load checks unchanged.'},indent=2)+'\n')
for role in ('baseline','control','probe'):
    overlay=[] if role=='baseline' else ['-overlay='+str(out/(role+'-overlay.json'))]
    run(role+'-whole-oracles',[go,'test','-pgo=off',*overlay,'./rt','./internal/harden','./examples/datadog/go/dd/...','./testdata/compute/go/compute/...','./testdata/streaming/go/streaming/...','-count=1'])
    run(role+'-compile',[go,'test','-pgo=off','-c',*overlay,'-o',out/(role+'.test'),'./examples/datadog/go/dd'])
    run(role+'-stream-compile',[go,'test','-pgo=off','-c',*overlay,'-o',out/('stream-'+role+'.test'),'./testdata/streaming/go/streaming'])
assert sha(out/'baseline.test')=='c73daeca03069285b5b26701646ac0c94ece1a80c62c5905eff795324db3d3d0'
records.append({'binaries_sha256':{name:sha(out/(name+'.test')) for name in ('baseline','control','probe','stream-baseline','stream-control','stream-probe')}})
(out/'variant-build-records.json').write_text(json.dumps(records,indent=2)+'\n')
print('PASS all regenerated overlays/oracles/ordinary binaries; tracked production unchanged',flush=True)
