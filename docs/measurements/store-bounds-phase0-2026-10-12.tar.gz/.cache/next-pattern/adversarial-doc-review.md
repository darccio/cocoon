# Covered store32 phase-0 final prose audit

Read-only review before packaging/staging; no builds/tests/lint/profiles/timers or tracked edits. Documentation reviewed against completed raw/statistic evidence and recorded quality commands.

## Verdict

Approve evidence-only prose retention, pending independent final compressed archive audit and separate exact staged validation. No substantive numerical, causal, contract, gate or M1 blocker remains. The final numerator clarity correction is applied in the narrative/report: writes/s counts Write calls only, excluding End, with complete New/Write/End/Close lifetime in the denominator. This changes no reported rate or disposition.

Direct checks verify all19 time rows in both rounds: medians, time deltas and untouched/control p-values agree with raw-derived summary and benchstat. All12 untouched stream rates match direct custom-metric medians. report.md matches the new performance narrative. Profile31.75%flat/40.83%cum fn176,56.08%cum export,8.92%ResultView agree with the fresh CPU report and are described nonadditively. Both two-site helpers and exact guards remain diagnostic, with no source-independent/generic proof claim. All318 previous contained reads, host/runtime/facade boundaries and originalWasm stay unchanged. Numeric addresses are guest metadata rather than the host reply-size contract.

The no-go reason is the defaultscalar screening untouched comparison's nondetection, not an invented probe guard regression. Confirmation−1.49% and both control-comparison gains remain visible; IncreasingP1 repeat gains and repeated-batch baseline gains do not replace the declared originalscalar conjunction. Varied/negative/rawGuest one-round outcomes, broad upward medians and repeated copied-check trace regression have correct limits. The copied-check trace loss has no established causal explanation despite sampled instruction-byte equality. No new spec/implementation, selected retiming, source-layout rescue, public ABI or M1 acceptance follows.

P1/P16 streaming binaries are explicitly byte-identical brackets. Their undetected comparisons and adverse16-home medians are preserved without asserting causal guest gain/loss or equivalence. Full16KiB lifetime/ownedRetain32 and configured-home topology/grouping are clear; no Batch session equivalence, strict capacity bound, fairness/RSS or causal home-only decomposition is introduced. FrameworkP16 is distinguished from actual364P1/168P16 measured rows, with434 unchangedframework16 rows. Current production scalar remains above55.44ns and fresh61.688/61.358ns; SQL meets2215.4ns absolute but confirmation2173ns exceeds2158.2ns fresh cap by14.8ns. Rejected probe times and old gains are not production outcomes. Fresh reference's56 selected sources, clean upstream identity and ABI2/context/lifetime/corpus limits remain disclosed.

Independently reverified all411 frozen and61 committed-entry proof/runtime/harness fingerprints after quality/reproduction. All15 recorded successful exits/logs match seven gate commands plus two complete compute/DD/stream/runtime repetitions, and first quality timestamp follows completed timing. Compiler split is accurately described: official1.26.8 for measurement/check/lint, system1.27.2 for otherGoquality; pinned golangci2.13.1 export-reader issue is attributed to the prior round rather than a new patch. Native amd64/386 proofs, truthful endian simulations, five semantic mutants and provisional/startup preparation scope are accurate. Exact staged-snapshot/darna/SSH-sign workflow remains future required work, not falsely completed validation.

Roadmap changed paragraphs match the result and link to the correct covered-store32 heading anchor. Intended readable/archive/SHA links are consistent but final artifacts await root assembly and a byte/member/coverage audit. Only docs/evidence are eligible for retention; track3 stays completed under its prior approved throughput scope, with existing broader predicates unchanged.

## Reviewed identities

```json
{
  "docs/performance.md": "797484b5d4df6955608f923885924b41a654197c207d05cea74381f4a5d6ccf4",
  "docs/roadmap.md": "af3943f02e4d91454bcf3a8adf61c50be8bea65c5ef4eb80f1c7f38752b16762",
  ".cache/next-pattern/report.md": "27f332b9942cfc2567c337c68733a8fc25ba97c5c5df7f0dabec109e9271a7fa",
  ".cache/next-pattern/after-qualification-audit.json": "609e9e06b9019c831ded453de93cab3ad97f6d987d1067073a20c21d483bf39e",
  ".cache/next-pattern/qualification-command-records.json": "e24153cb9cb0ffeeb9a27aa82c4fead7392668fddc55b41263a608d3c933c750"
}
```
