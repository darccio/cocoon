"""Derive readable time comparisons from complete immutable samples."""
import json
from pathlib import Path
import re

out = Path(__file__).resolve().parent
run = out / 'paired'
plan = json.loads((out / 'qualification-plan.json').read_text())
summary = json.loads((run / 'summary.json').read_text())
names = {
    'Original-ObfuscateSQL': 'Original SQL',
    'Original-SketchAdd': 'Original scalar',
    'Original-SketchAddMany1k': 'Original batch 1k',
    'Original-ObfuscateTraces1k': 'Original trace 1k',
    'Original-SketchAddVaried': 'Varied scalar',
    'Original-ObfuscateSQLVaried': 'Varied SQL',
    'Original-SketchAddNegativeBins': 'Negative bins',
    'MatchedReference-SQLHoldout': 'SQL holdout P1',
    'MatchedReference-Increasing': 'Increasing P1',
    'MatchedReference-BroadScalar': 'Broad scalar P1',
    'MatchedReference-Repeated1024': 'Repeated batch 1024 P1',
    'MatchedReference-BroadBatch8192': 'Broad batch 8192 P1',
    'RawGuest-SketchAdd': 'Raw guest diagnostic',
    'StreamOneHome-Fixed': 'Fixed stream, one home P16',
    'Stream16Homes-Fixed': 'Fixed stream, 16 homes P16',
    'StreamOneHome-Holdout': 'Holdout stream, one home P16',
    'Stream16Homes-Holdout': 'Holdout stream, 16 homes P16',
    'StreamP1-OneHome-Fixed': 'Fixed stream, one home P1',
    'StreamP1-OneHome-Holdout': 'Holdout stream, one home P1',
}

def pvalues(filename):
    rows = [row for row in filename.read_text().splitlines() if row.startswith('Comparison/')]
    assert len(rows) == 1
    return re.findall(r'p=([0-9.]+)', rows[0])

def value(number):
    return f'{number:,.3f}'.rstrip('0').rstrip('.')

lines = ['| Workload | Screen baseline → probe, ns/op | Δ; p | Confirm baseline → probe, ns/op | Δ; p | Probe/control screen; confirm (Δ, p) |',
         '| --- | ---: | ---: | ---: | ---: | ---: |']
for group in plan['comparisons']:
    key = group['key']
    cells = [names[key]]
    secondary = []
    for rd in ('screen', 'confirm'):
        roles = summary[rd][key]['roles']
        baseline = roles['baseline']['medians']['ns/op']
        probe = roles['probe']['medians']['ns/op']
        ps = pvalues(run / f'{rd}-{key}-time-benchstat.txt')
        assert len(ps) == len(group['cases']) - 1
        probe_index = [case['role'] for case in group['cases']].index('probe')
        assert probe_index > 0
        cells += [value(baseline) + ' → ' + value(probe), f"{roles['probe']['delta_percent_ns']:+.2f}%; {ps[probe_index-1]}"]
        report = group['secondary_comparisons'][0]['key']
        control_ps = pvalues(run / f'{rd}-{report}-time-benchstat.txt')
        assert len(control_ps) == 1
        secondary.append(f"{100*(probe/roles['control']['medians']['ns/op']-1):+.2f}%, {control_ps[0]}")
    cells.append('; '.join(secondary))
    lines.append('| ' + ' | '.join(cells) + ' |')
(out / 'outcome-table.md').write_text('\n'.join(lines) + '\n')
print('Derived all19 time rows, including both comparator p-values')
