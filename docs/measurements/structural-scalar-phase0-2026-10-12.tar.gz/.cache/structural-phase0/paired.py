"""Execute only frozen diagnostic cases; retain complete raw process output."""
from pathlib import Path
import argparse
import collections
import datetime
import json
import os
import re
import subprocess
import sys

from common import ENV_KEYS, ROOT, cpu_policy, expected_count, parse_row, path, validate_plan, verify


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("snapshot", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--mode", choices=("warm", "startup"), default="warm")
    parser.add_argument("--execute-isolated", action="store_true")
    args = parser.parse_args()
    if not args.execute_isolated:
        parser.error("no timings without --execute-isolated after root authorizes and stops all build/test/reviewer tools")
    snapshot_file = args.snapshot.resolve()
    snapshot = json.loads(snapshot_file.read_text())
    verify(snapshot)
    plan, config = snapshot["plan"], snapshot["config"]
    validate_plan(plan)
    groups = [g for g in plan["comparisons"] if (g["kind"] == "startup") == (args.mode == "startup")]
    assert groups
    args.output.mkdir(parents=True, exist_ok=False)
    (args.output / "frozen.json").write_text(snapshot_file.read_text())
    env = dict(os.environ, GOTOOLCHAIN="local", CGO_ENABLED="0", GOAMD64="v1", GOMAXPROCS=str(plan["framework_procs"]))
    reset_defaults = {key: env.pop(key) for key in ("GOGC", "GOMEMLIMIT", "GODEBUG") if key in env}
    conditions = {"started_utc": now(), "mode": args.mode, "affinity": sorted(os.sched_getaffinity(0)),
                  "environment": {key: env.get(key, "default") for key in ENV_KEYS},
                  "reset_to_agreed_default": reset_defaults,
                  "cpu_policy": cpu_policy(), "cpu_frequencies": cpu_policy(include_frequencies=True),
                  "snapshot": str(snapshot_file), "command": sys.argv,
                  "isolation": "Root stopped all local build/test/lint/fuzz/profile/reviewer tools before timing; driver cannot prove absence of unrelated external work."}
    assert conditions["affinity"] == snapshot["affinity"]
    assert conditions["cpu_policy"] == snapshot["cpu_policy"], "governor/boost changed since freeze"
    (args.output / "run-provenance.json").write_text(json.dumps(conditions, indent=2) + "\n")
    rounds = plan["rounds"] if args.mode == "warm" else plan["startup_rounds"]
    samples = plan["samples"] if args.mode == "warm" else plan["startup_trials_per_round"]
    counts = collections.Counter()
    with (args.output / "records.jsonl").open("x") as records:
        for rd in rounds:
            ordered = list(reversed(groups)) if rd["reverse"] else groups
            for sample in range(1, samples + 1):
                for index, group in enumerate(ordered):
                    cases = group["cases"][::]
                    if sample % 2 == 0:
                        cases.reverse()
                    if rd["reverse"]:
                        cases.reverse()
                    for case in cases:
                        case_env=dict(env,**case.get("environment",{}))
                        duration=group.get("durations",{}).get(rd["name"],rd["duration"])
                        query = "/".join("^" + re.escape(part) + "$" for part in case["parts"])
                        command = [str(path(config["binaries"][case["binary"]])), "-test.run=^$", "-test.bench=" + query,
                                   "-test.benchtime=" + duration, "-test.count=1", "-test.benchmem", "-test.cpu=" + str(plan["framework_procs"])]
                        filename = args.output / f"{rd['name']}-{sample:02}-{index:02}-{case['role']}.txt"
                        started = now()
                        with filename.open("x") as raw:
                            raw.write("START " + started + "\nCOMMAND " + json.dumps(command) + "\nCASE_ENV " + json.dumps(case.get("environment",{})) + "\n")
                            raw.flush()
                            result = subprocess.run(command, cwd=ROOT, env=case_env, stdout=raw, stderr=subprocess.STDOUT, text=True)
                            raw.write("\nEND " + now() + "\nEXIT " + str(result.returncode) + "\n")
                        if result.returncode:
                            raise RuntimeError(f"case failed; complete raw failure preserved at {filename}")
                        parsed = parse_row(filename.read_text(), case, plan)
                        if duration.endswith("x"):
                            assert parsed["iterations"]==int(duration[:-1]),parsed
                        if args.mode == "startup":
                            assert parsed["iterations"] == 1, parsed
                        record = {"round": rd["name"], "sample": sample, "comparison": group["key"],
                                  "kind": group["kind"], "role": case["role"], "binary": case["binary"],
                                  "parts": case["parts"], "case_environment":case.get("environment",{}), "duration":duration, "raw": filename.name, "started_utc": started, **parsed}
                        records.write(json.dumps(record) + "\n")
                        records.flush()
                        counts[(rd["name"], group["key"], case["role"])] += 1
                print("PASS", rd["name"], sample, flush=True)
            verify(snapshot)
            assert cpu_policy() == snapshot["cpu_policy"], "governor/boost changed during measurements"
            for group in groups:
                for case in group["cases"]:
                    assert counts[(rd["name"], group["key"], case["role"])] == samples
    expected = expected_count(plan, args.mode)
    assert sum(counts.values()) == expected
    verify(snapshot)
    (args.output / "complete.json").write_text(json.dumps({"completed_utc": now(), "rows": expected, "mode": args.mode,
                                                          "cpu_policy": cpu_policy(), "cpu_frequencies": cpu_policy(include_frequencies=True)}, indent=2) + "\n")
    print("PASS", expected, "raw rows preserved; frozen hashes unchanged", flush=True)


if __name__ == "__main__":
    main()
