# Adversarial structural-ceiling result review

Verdict: the preregistered primary phase-0 criterion PASSES. Retain the measured evidence and consider separately scoped bounded-interval feasibility proof work. Do not retain the outline/oracle as production, infer cache feasibility, approve a new public contract, claim standalone production latency gain or mark M1 accepted. This reviewer performed only read-only source/data/hash checks, no builds/tests/lints/profiles/benchmarks; root's sequential quality gates are still outside this result audit.

## Completeness and decision

Independently verified all1,232raw records against exact benchmark lines/iterations/metrics/PASS/exit/case-env;176round/group/role cells each contain seven unique samples. Derived summary medians/samples and176normalized aliases preserve exact raw metrics. All520frozen file hashes match current bytes after timing, including the real table, timed/control/proof executables and authored sources. Both7-pass sets completed. This is19groups;88freshprocesses/pass*14passes. No row exclusion or selected retiming was identified. Exploratory p-values are unadjusted; non-detection is not equivalence and the seven-sample dispersion matters.

Primary Original-SketchAdd-FixedN screeningN4,194,304: untouched87.49ns -> oracle70.26ns, -19.693679%TIME (17.23ns); same-ELF false90.43ns ->70.26ns, -22.304545% (20.17ns). ConfirmationN8,388,608: untouched87.74ns ->70.74ns, -19.375427%TIME (17.00ns); false90.37ns ->70.74ns, -21.721810% (19.63ns). All FOUR benchstat comparisons reportp=.001,n=7, meeting >=10%median TIME+p<.05 in both sets against both comparators, exactly as decision-plan required before timing. Equivalent throughput increases are24.52/24.03%vsuntouched, not19.69/19.38%; time and throughput must not be conflated. Confirmation oracle and reference benchstat dispersion is +/-14%, retained rather than filtered. Different N lengths are matched-prefix treatments within each set, not identical evolving state across both sets.

This establishes useful synthetic end-to-end headroom when substituting a64MiB precomputed exact-log oracle. It does not quantify pure log cost by subtracting layers or promise a deployable17ns saving. Same-ELF false/true share allocation/init/file/flag scaffolding and make a stronger control than untouched. Baseline/outline do not allocate the table; live-heap/GC/cache/power/startup and linking effects remain for those comparisons. The false path itself is slower than untouched (3.36/3.00%primary), and pure-outline is slower (2.46/1.63%,bothp=.001). The primary positive is genuinely required against both comparators; neither penalty is hidden in the conclusion.

## Other workloads and negatives

Repeated detected oracle TIME gains versus untouched: Increasing-FixedN17.27/16.74%, originalbatch1k38.16/38.37%, matchedRepeated1024batch37.84/38.54%, rawGuest-FixedN36.21/36.17% (allp=.001). The raw scope omits ABI3 host checks and cannot be promoted into a full-facade saving or added to other retained gains. Cyclic repeated batches are favorable covered inputs; they do not predict miss-heavy performance or SDK traffic.

Repeated detected oracle losses versus UNTOUCHED:

- Negative logical bins (valid positive point inputs), +2.867/3.449%,bothp=.001.
- BroadScalar-FixedN, +3.403/2.547%,bothp=.001.
- BroadBatch8192, +10.148/9.509%,bothp=.001.
- SQLHoldout, +1.711/1.491%,p=.004/.001.

VariedSQL is also upward in both sets: +1.347%,p=.058 screening and +1.504%,p=.001 confirmation. Preserve the unconfirmed first-set detection rather than dismissing or declaring equivalent. OrdinarySQL oracle comparisons are undetected in both sets (medians-.375/-.611%,p=.222/.198); variedscalar is undetected (-1.319/-.283%,p=.363/.119). Trace confirmation is-1.444%,p=.002 versus untouched, but screening is-.713%,p=.318 and both same-ELF false-control comparisons are undetected. Do not infer a repeatable log-driven trace gain. SQL/trace are unrelated arithmetic paths, so observed changes cannot be explained by log elimination itself without independent attribution.

For miss-heavy losses, oracle versus same-ELF false control is undetected in both sets (negativebins,p=.221/.971; BroadScalar,.805/.128; BroadBatch,.097/.710; SQLHoldout,.456/.646; variedSQL,.902/.172). This limits causal attribution to the true lookup flag. It does not make fallback cheap/equivalent or waive the genuine observed cost versus production. Oracle versus pure-outline repeatedly loses negativebins+.78/1.26%, BroadScalar+2.46/2.44%, BroadBatch+6.82/6.58%, SQLHoldout+1.45/1.40% (allp=.001), reinforcing the unsupported scaffold's limitations.

Pure-outline should NOT be promoted: repeated losses versus untouched in originalscalar+2.46/1.63%, negativebins+2.07/2.16%, rawGuest+3.09/2.52%, variedSQL+1.05/1.05%, broadbatch+3.12/2.75% (all detected). Confirmation-only originalSQL+1.27%,p=.024; variedscalar+1.62%,p=.001; Increasing+1.50%,p=.001; screening-only BroadScalar+.92%,p=.001 are also retained. The larger native frame128->136 is a reported negative, not a spill-count or faster-shape claim. False-table control incurs repeated losses across originalscalar, varied/negative/broadscalar, Increasing, original/repeated/broadbatch and SQLholdout/variedSQL; the table/flag scaffold is not a neutral cost-free implementation.

All six stream oracle-versus-untouched and oracle-versus-false comparisons are undetected. Adverse P16one-home Fixed confirmation+.564%,p=.053 (screen+.156%,p=.902), P16one-home holdout+.317/.274%, P1holdout+.592/.149%, and noisy multihome directions remain in raw evidence. The three stream ELFs are byte-identical a2076ad9349c334f028e1c73cc166004c15da1debab79e8d2c349d851bc373bf; their labels are environmental brackets, not genuine candidates. The tiny confirmation-only pure-outline-labelled P1Fixed-.203%,p=.038 is also not a production effect. No stream gain/equivalence/ceiling can be inferred from these unchanged bytes.

## Proof, memory and acceptance limits

All8,388,608table/wrapper entries and1,764bit edge cases match mechanically reconstructed ORIGINAL Go kernel; safe domain conversion, signedzero, nonfinite/fractional and upper-bound fallback are tested. Mechanical source equality/liveness establishes scoped unchanged caller/evaluation/effects. Independent originalWasm evidence covers COMPLETE SIX FINITE histories (16kprefix/warmed,4M/8Mboundary/tail samples, broad/nearby/negativezero), not an every-input4M/8MWasm replay. RawGuest post-loop Count validates its fullNGo state; bare originalscalar harness remains unchanged without post-loop Count/protobuf. The mutable entry sentinel proves actual flag paths; four semantic mutants fail on actual nativeamd64/386. These are sufficient diagnostic proofs, not interval certification or generalproduction proof.

The64MiB host table is loaded/retained outside timing, with initialization/I/O and ReadFile overhead uncounted by warm allocations. One external1x observation per role reports maxRSS13.02/13.55/79.59/79.70MiB, not repeated startup qualification or guest-memory size. It is not a bounded small cache. Sequential integer walks are favorable locality; broad/fractional contexts largely fall back. No representative private SDK application/profile was available.

FixedN is not adaptive-original M1 acceptance. Even the hypothetical scalar70.26/70.74ns remains above55.44ns absolute and this round's fixed-prefix fresh-reference110%caps60.907/60.698ns (ref55.37/55.18). This is context only; no production path changed or qualified. Current adaptive originalSQL baseline2131/2126ns is below this round's freshcaps2150.5/2130.7ns, but earlier rounds crossed that mutable comparator; do not attribute this unchanged-binary observation to optimization or declare overall M1 accepted. Public-ABI safety/reference differences remain explicit. Historical linked/profile/phase0 gains are nonadditive.

## Minimum bounded-interval feasibility work justified next

1. Write a PRIVATE feasibility scope before any implementation: whether a certificate covers all positive finitefloat64values or a deliberately restricted discrete domain; exact resource mapping parameter identities, threshold/zero behavior, bounds/endpoints, ownership/abandonment and memory budget. Keep arbitrary other values on the exact current kernel. A new public contract requires operator approval. The hash/function-ID-pinned diagnostic is not a generic authored compiler predicate.
2. First build an OFFLINE executable certificate, not a cache. Certify the actual rounded IEEE operations/branches and affine/floor/saturating mapping for every allowed value inside each accepted interval. Endpoints, oracle samples, expected monotonicity or a real-number ln bound alone do not certify the current finite-precision program. Conservative outward enclosures plus subdivision and fallback on ambiguity are possible proof techniques, not established solutions. A discrete-domain option needs an exact runtime eligibility guard and exhaustive coverage of that domain, and cannot claim continuum membership.
3. Make intervals/key scope and limits explicit: exact mapping parameter bits, threshold/range state assumptions and generation invalidate entries when relevant state differs. Bound count/bytes and working memory independent of stream history; quantify miss construction/check overhead. Preserve original memory-read/check/import/trap/write order and all Count/protobuf/collapse/invalid-tail atomicity and host ABI3 semantics. Returning a constant certified bin is a different future algorithm than this exact-log lookup; it needs its own proof that only the certified bin is observable at that substitution point.
4. Test certificates with independent originalWasm/native histories, adversarial adjacent representable boundaries/gaps/overlaps/empty/negative/nonfinite/parameter-change cases and semantic mutants. Random/boundary tests complement universal certification rather than replacing it. Add no payload-ID or heldout-specific targeting and do not broaden current retained translation predicates.
5. Only after proof, measure small bounded storage/lookup/construction plus complete checkedscalar, exact misses/unique/broad/negative/cyclic patterns, adaptive originalscalar/SQL/batch/trace, independent holdouts and genuine changed-build P1/P16complete stream lifetimes. Pair untouched and real scaffolding controls, predeclare hit/miss/byte bounds and guard rejection criteria, expose startup/code/memory costs and representative-workload absence. If no bounded certificate or end-to-end win without productionguard regressions is attained, park it rather than promote the64MiB oracle or pureoutline.

This is the minimum further proof question warranted by a positive structural ceiling. It does not claim any of those steps were attained, specify/approve a production cache, or authorize production changes by inference. Root owns durable docs/archive and quality/staged validation; results may be retained as evidence only now.

## Evidence identities

```json
{
  "decision-plan.json": "eb274cbe5581211e984aa424564d501f227619bc3280b1c0851d58a270b72cde",
  "qualification-plan.json": "8a2df3a689e450fe3983412de0abdf8dc3f8304de116d35061c2817e645bebb0",
  "frozen.json": "300e14d735ab57b353dcf8520bc5b4adc5a88210250625bc74060577a37208fc",
  "paired/frozen.json": "300e14d735ab57b353dcf8520bc5b4adc5a88210250625bc74060577a37208fc",
  "paired/summary.json": "8f52e359d25b3da3b10a6ab7524639e57f5138e6e700e7f3ce828a0c27632a26",
  "paired/records.jsonl": "3b3e52f0bc974c21533e97f34c08248e96bd8f0f7a4fe3fbb3f5c6680876aa34",
  "paired/complete.json": "2315353e896cfb1b36ba4ceec47f7340f7537a617c524522a1c16e1995f780bf",
  "paired/run-provenance.json": "ae63c8933e453dddae1a4076ebde754db97740621112d469ff10342b8542b7c2",
  "paired/comparison-aliases.json": "b4b4f28c0071d265a1c11c5d8d0d5331bec9f48834155b5927d5bde33258965c",
  "adversarial-premeasurement.md": "ea1a96abe49ee9a66734b0bc24cb041cbbcf832ea69a19a2417360820b408d9c",
  "adversarial-ready.md": "54109bd4f4b234ba5cdbb47d0488ff797a9cf7242f74c23739b0fdee89a67f2c"
}
```
