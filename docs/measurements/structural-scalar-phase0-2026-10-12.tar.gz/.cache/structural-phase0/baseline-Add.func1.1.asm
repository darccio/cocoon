TEXT dario.cat/cocoon/examples/datadog/go/dd.(*Sketch).Add.func1.1(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/cocoon_gen.go
  cocoon_gen.go:583	0x7de6e0		493b6610		CMPQ SP, 0x10(R14)										
  cocoon_gen.go:583	0x7de6e4		7673			JBE 0x7de759											
  cocoon_gen.go:583	0x7de6e6		55			PUSHQ BP											
  cocoon_gen.go:583	0x7de6e7		4889e5			MOVQ SP, BP											
  cocoon_gen.go:583	0x7de6ea		4883ec20		SUBQ $0x20, SP											
  cocoon_gen.go:586	0x7de6ee		4889442430		MOVQ AX, 0x30(SP)										
  cocoon_gen.go:583	0x7de6f3		488b5a10		MOVQ 0x10(DX), BX										
  cocoon_gen.go:583	0x7de6f7		f20f104218		MOVSD_XMM 0x18(DX), X0										
  cocoon_gen.go:583	0x7de6fc		488b4a08		MOVQ 0x8(DX), CX										
  cocoon_gen.go:584	0x7de700		488b09			MOVQ 0(CX), CX											
  cocoon_gen.go:584	0x7de703		488b01			MOVQ 0(CX), AX											
  cocoon_gen.go:584	0x7de706		e8757fe7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).Xcocoon_sketch_add(SB)	
  cocoon_gen.go:585	0x7de70b		488d1de2540f00		LEAQ 0xf54e2(IP), BX										
  cocoon_gen.go:585	0x7de712		b903000000		MOVL $0x3, CX											
  cocoon_gen.go:585	0x7de717		89c7			MOVL AX, DI											
  cocoon_gen.go:585	0x7de719		488b442430		MOVQ 0x30(SP), AX										
  cocoon_gen.go:585	0x7de71e		6690			NOPW												
  cocoon_gen.go:585	0x7de720		e81b98deff		CALL dario.cat/cocoon/rt.(*Call).ResultView(SB)							
  cocoon_gen.go:586	0x7de725		4885ff			TESTQ DI, DI											
  cocoon_gen.go:586	0x7de728		7523			JNE 0x7de74d											
  cocoon_gen.go:589	0x7de72a		4885db			TESTQ BX, BX											
  cocoon_gen.go:589	0x7de72d		7414			JE 0x7de743											
  cocoon_gen.go:590	0x7de72f		488b050a214f00		MOVQ dario.cat/cocoon/rt.ErrProtocol(SB), AX							
  cocoon_gen.go:590	0x7de736		488b1d0b214f00		MOVQ dario.cat/cocoon/rt.ErrProtocol+8(SB), BX							
  cocoon_gen.go:590	0x7de73d		4883c420		ADDQ $0x20, SP											
  cocoon_gen.go:590	0x7de741		5d			POPQ BP												
  cocoon_gen.go:590	0x7de742		c3			RET												
  cocoon_gen.go:592	0x7de743		31c0			XORL AX, AX											
  cocoon_gen.go:592	0x7de745		31db			XORL BX, BX											
  cocoon_gen.go:592	0x7de747		4883c420		ADDQ $0x20, SP											
  cocoon_gen.go:592	0x7de74b		5d			POPQ BP												
  cocoon_gen.go:592	0x7de74c		c3			RET												
  cocoon_gen.go:587	0x7de74d		4889f8			MOVQ DI, AX											
  cocoon_gen.go:587	0x7de750		4889f3			MOVQ SI, BX											
  cocoon_gen.go:587	0x7de753		4883c420		ADDQ $0x20, SP											
  cocoon_gen.go:587	0x7de757		5d			POPQ BP												
  cocoon_gen.go:587	0x7de758		c3			RET												
  cocoon_gen.go:583	0x7de759		4889442408		MOVQ AX, 0x8(SP)										
  cocoon_gen.go:583	0x7de75e		6690			NOPW												
  cocoon_gen.go:583	0x7de760		e89b04cbff		CALL runtime.morestack.abi0(SB)									
  cocoon_gen.go:583	0x7de765		488b442408		MOVQ 0x8(SP), AX										
  cocoon_gen.go:583	0x7de76a		e971ffffff		JMP dario.cat/cocoon/examples/datadog/go/dd.(*Sketch).Add.func1.1(SB)				
