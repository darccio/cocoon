# Guest structural entry review

Read-only review of current authored/build/translation sources and the last
matching `.cache/next-pattern` text profiles/ordinary assembly. No compilation,
tests, profiling, timing, tracked edits, or new public specification. This note
is the only authored artifact.

## Decision

Do not pursue another small bounds helper. The only demonstrated contiguous
guest region with enough sampled full-scalar mass for a materially larger
ceiling is the exact existing logarithm/mapping computation inside fn176.
Investigate a **pure-log-only outlining** control or a clearly unsupported
oracle ceiling for bypassing that computation, before any production design.
Current evidence does not establish that outlining itself can improve full
scalar by 10%. If the exact outlining control cannot meet the declared large
gain bar, stop rather than interpreting a prettier CFG as success.

The last checked scalar profile is 12 seconds, original binary c73daeca….
fn176 is31.75% flat/40.83% cumulative; the scalar export is9.17% flat/56.08%
cumulative; fn84 is2.92% flat/4.17% cumulative. The dense log expression at
source35823 has1.80s flat, and its square term at35819 has680ms flat. These are
disjoint source-line sample attributions within the same profile (20.67% of
total together), not isolated costs or removable latency. SQL remains dominated
by fn96 (47.32% flat/77.55% cumulative). The ordinary log polynomial contains
register-register MULSD/ADDSD operations without polynomial spills or helper
calls. Its region therefore has significant sampled mass, but no established
arithmetic redundancy or 10% exact outlining gain.

## Compiler/build comparison

Current shim Cargo release is opt-level3, LTO=true, one codegen unit,
panic=abort, stripped symbols. `internal/build/pipeline.go:117–157` builds
Rust1.97.0 with `--locked -Zbuild-std=std,panic_abort`, then pinned Binaryen133
metaDCE and O3, and wasm2go0.4.16 `-unsafe`. Current Rust flags add the memory
cap, source remapping, and metadata normalization; no omitted optimization
level was found. The independent captured reference also declares opt-level3,
LTO=true, one codegen unit and uses the same std/panic_abort/optimizer/translator
pipeline. Its manifest differs in panic/debug entries, but its captured build
commands govern actual flags. The libdatadog workspace's own size profile does
not override either independent shim workspace's release profile.

The two guests share pinned libdatadog payload semantics but different guest
contracts/dependencies/wrappers. Reference Add at reference-module61562 directly
validates a slab slot then calls fn181. Current Add at current-module48457 calls
fn84, consumes a memory-backed Result, validates the point, calls fn176, consumes
another memory-backed Result, and publishes ABI3 canonical unit/error data.
The reference is not evidence that current resource generation, error text,
RefCell re-entry, or canonical reply work may be removed. Its simpler shape is
a useful attribution clue, not an implementation source or like-for-like cost.

Prior Binaryen O4, O3 without StackIR, and convergence did not establish scalar
benefit (`docs/performance.md` multi-agent rounds5–7). A flags sweep repeating
those experiments is not the requested new mechanism. Pinned wasm2go already
materializes effectful/trapping expressions in `fncompiler.go:223`, defers pure
expressions, emits Go block-result variables/gotos, and runs goto/switch/block
simplification passes. Lexical nesting alone does not prove a runtime dispatch
loop. Current native assembly has ordinary direct branches/calls, not a Wasm
interpreter dispatcher.

## Exact outlining: prior experiment and genuinely narrower delta

**Full mapping outlining has already been tried.** `.cache/bin-reuse/prepare.py`
extracts source t16 through v7 (ln plus affine transform, floor, saturation) into
`BinReuseOriginalMapping`, with untouched/extracted/cache1/cache64 controls.
Extraction adds a Module slice field even in no-cache mode, passes `[4]uint64`
parameters, and eagerly loads the offset at56 together with multiplier at40.
It therefore combines call shape, field layout, parameter carriage, and placement.
Durable no-go records no repeated scalar gain; Increasing extraction's screen
cost is11.46% without confirmation; matched holdout extraction loses4.94%/7.56%.
Do not call exact outlining wholly untried or dismiss these negatives.

The distinct possible control extracts **only** the pure block that computes
p17 at current module35775–35831. Keep the multiplier t16 memory load before
the helper and the offset t27 memory load after it at their original positions.
Keep the affine/floor/saturation statement and all subsequent store/collapse
work unchanged. The helper receives the current point by value and returns
only p17. No Module fields, input/parameter arrays, caches, alternate logarithm,
changed casts, coefficient changes, contraction, or reordered arithmetic.

Current written-local liveness supports that signature:

| Written local | Why its log-block value is dead after p17 |
| --- | --- |
| v1 | Empty-store path assigns0 at35838; high-side store branch assigns v7−v9 at35866; other branch assigns at35969 before using it. |
| v6 | Every path unconditionally replaces it with t28 at35835. |
| v2 | Later collapse paths initialize it to0 at35887/35892/35963 before their first accumulation/use. Noncollapse/zero-count paths do not use its reduced-log value. |
| v16 | Its only suffix reads follow fresh0 or bin-load assignments at35900/35917/35926/35944. |
| v17/v19/v20 | No suffix use within fn176. |
| p17 | Live into v7's unchanged affine/floor/saturation computation. |

All jumps to l3/l4/l5/l6 are inside this pure region; extraction must rename
or internalize these labels rather than leaving cross-function control. Locals
and helper bindings remain full-source pinned in a phase-zero diagnostic.
Preserve every float operation and explicit conversion: source-identical pure
math does not authorize FMA or reassociation. IEEE floating zero divisions
remain the same floating operations, not Go integer traps. Preserve arbitrary
NaN/signed-zero/result bits in an independent exact-copy oracle, as well as
the original guest's actual validated point domain. A helper call adds its own
register/stack boundary; assess matching ordinary SSA/assembly, live values,
frames, native stack traffic, and whole-function layout instead of assuming
the larger CFG's pressure disappears.

## Stack promotion and certification limits

fn84 writes resource Result slots through a caller-supplied linear-memory
pointer; fn176 likewise writes through v0 after nested stack frames. Current
ordinary Add assembly retains direct calls, native SP saves/restores, guest
slice-header reloads, checked result-slot loads, and guest g0 restoration.
These are two different stacks. Frame size or SP operand count is not a spill
count or an optimization saving.

The result addresses cross calls and error/growth paths. Stack arithmetic does
not prove nonescape or disjointness: arbitrary result pointers can alias
resource records, stack slots, or later reads. Generic forwarding/promotion
needs interprocedural read/write/import/growth summaries, alias proof and
preservation of original logical checks and partial effects. Existing retained
header/contained-load predicates deliberately do not provide that proof.
This route could target several boundaries together, but it is not a safe
shortcut to a 10% claim and is substantially more work than exact outlining.

Certified interval membership is distinct from rejected exact-value caching.
The old locality evidence (8192 distinct increasing-cycle values in377 bins)
motivates measuring an interval hit ceiling. It does not certify any interval.
Pinned floating-point branch reductions, every rounded operation, mapping
parameters, threshold/zero cases, floor/saturation, and boundary fallbacks all
matter. Endpoint oracle agreement or assumed monotonicity is insufficient.
Any continuum certificate needs conservative outward enclosures of the exact
current algorithm, with fallback wherever a single logical bin cannot be
proved. Counter/collapse updates remain ordered. This is an expensive proof
question, not a production proposal in this review.

An oracle bypass diagnostic is admissible only as an unsupported upper bound:
precompute exact current outcomes outside timing, retain all ordinary checked
facade/resource/guest state updates, and clearly describe which computation
and lookup costs it substitutes. No cache hit policy or continuum guarantee
is inferred from finite-corpus answers. Repeated scalar, nonrepeating/increasing,
near-boundary, negative-bin and broad corpora must remain distinct. Pair controls
against untouched and code-shape scaffolding, then use complete Count/protobuf
histories, expected errors, zero/invalid inputs and malformed/stale handles.

Previously rejected exact-value caches, range/bit classifiers, saturated
conversion shortcuts, host unit decoding/recovery rewrites, adjacent
read64/store64 and descending-store probes are excluded. No guest math
approximation, reference code transplant, public ABI change, default PGO,
architecture requirement or backend replacement is proposed. All tools stop
after this note/report for the parent's isolated work.

## Agreed phase-zero ceiling scope and proof prerequisites

The parent's next controls are untouched, pure-log-only outlined, and a
dynamic table-enabled/table-disabled pair. The table contains exact copied
current-kernel result bits for integer inputs 0 through 2^23−1; unsupported
inputs execute the unchanged kernel. Both table roles initialize identical
storage outside timing. Untouched and pure-outlined roles carry no table.
This is an unsupported perfect-log counterfactual, not a cache implementation,
certified interval, payload change, or production contract. The proposed fixed
4-million/8-million prefix runs stay within that table's coverage when starting
at zero; integer coverage must be asserted from actual input bits rather than
assumed from a benchmark name.

Before final timing, independent proof should establish:

- Full source/hash and region reconstruction: original pure kernel operations,
  casts, coefficients, labels/branches and helper bindings are unchanged;
  outlined result is p17 only. Keep the multiplier load before and offset load
  after the call, then unchanged floor/saturation and ordered state mutation.
- Direct original-versus-outline-versus-table **log result bits**, not just
  equal final bins. Cover every precomputed integer or retain explicit exhaustive
  table-verification provenance, plus signed zero, subnormal/normal thresholds,
  reduction branch boundaries, values adjacent to1, maximum finite, negative,
  NaN payloads and infinity as isolated kernel probes. Outer guest validation
  remains authoritative for whether those points may reach real sketch mutation.
- Exact upper table boundary and representable fractional inputs just inside/
  outside range use the intended fallback. Guard negative/nonfinite/out-of-range
  inputs before indexing or unsafe integer conversion. Dynamic false/true roles
  must actually exercise both paths, with counters outside measured acceptance.
- Complete current original-Wasm oracle outputs and Count/protobuf state
  histories for ordered scalar/batch traffic, partial states and subsequent
  mutations, not count alone. Include zero count, negative logical bins,
  collapse-heavy/broad traffic, finite boundary values, invalid scalar/batch
  error status/messages and atomic batch failure, stale/reused/zero handles,
  lifecycle faults, and per-operation memory-limit/poison behavior.
- Run these functional comparisons on native amd64 and native386 with pinned
  official Go1.26.8/CGO disabled. A moderate functional prefix may prove complete
  protobuf/Count equality; exact table coverage and frozen 4M/8M timed inputs
  are separate assertions. Child semantic mutants should demonstrate that
  changed result bits, omitted fallback, or moved memory checks cannot pass
  through shared implementation bugs or setup/compile failures.

The uint64 result table alone occupies64MiB of Go host storage per table,
outside guest logical memory. Initialization, retention/lifetime, lookup
conditions, runtime GC context, and whether the table is global/shared or
module-owned must be documented from actual source. Untimed initialization
and zero warmed allocation metrics do not demonstrate memory efficiency.
Compare table-enabled against its table-disabled scaffold as well as untouched;
pure outlining against untouched remains a separate question. An oracle ceiling
win only establishes headroom for bypassed computation under covered inputs,
not feasibility of an exact cheap replacement on arbitrary request values.
