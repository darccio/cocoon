TEXT dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.cocoonPhase0OriginalLog(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/internal/wasm/module.go
  module.go:63137	0x691360		90			NOPL						
  unsafe.go:35		0x691361		66480f7ec0		MOVQ X0, AX					
  module.go:63145	0x691366		90			NOPL						
  module.go:63146	0x691367		48b90000000000001000	MOVQ $0x10000000000000, CX			
  module.go:63146	0x691371		4839c8			CMPQ AX, CX					
  module.go:63146	0x691374		7c42			JL 0x6913b8					
  module.go:63147	0x691376		48b9ffffffffffffef7f	MOVQ $0x7fefffffffffffff, CX			
  module.go:63147	0x691380		4839c8			CMPQ AX, CX					
  module.go:63147	0x691383		0f87b5010000		JA 0x69153e					
  module.go:63151	0x691389		4889c1			MOVQ AX, CX					
  module.go:63151	0x69138c		48c1e820		SHRQ $0x20, AX					
  module.go:63152	0x691390		483d0000f03f		CMPQ AX, $0x3ff00000				
  module.go:63152	0x691396		7408			JE 0x6913a0					
  module.go:63152	0x691398		ba01fcffff		MOVL $-0x3ff, DX				
  module.go:63155	0x69139d		eb7c			JMP 0x69141b					
  module.go:63155	0x69139f		90			NOPL						
  module.go:63157	0x6913a0		85c9			TESTL CX, CX					
  module.go:63157	0x6913a2		740c			JE 0x6913b0					
  module.go:63157	0x6913a4		b80000f03f		MOVL $0x3ff00000, AX				
  module.go:63157	0x6913a9		ba01fcffff		MOVL $-0x3ff, DX				
  module.go:63159	0x6913ae		eb6b			JMP 0x69141b					
  module.go:63159	0x6913b0		0f57c0			XORPS X0, X0					
  module.go:63162	0x6913b3		e986010000		JMP 0x69153e					
  module.go:63164	0x6913b8		0f10c8			MOVUPS X0, X1					
  module.go:63164	0x6913bb		f20f59c0		MULSD X0, X0					
  module.go:63164	0x6913bf		f20f1015e10d2700	MOVSD_XMM $f64.bff0000000000000(SB), X2		
  module.go:63164	0x6913c7		f20f5ed0		DIVSD X0, X2					
  module.go:63165	0x6913cb		0f57db			XORPS X3, X3					
  module.go:63165	0x6913ce		660f2ecb		UCOMISD X3, X1					
  module.go:63165	0x6913d2		750c			JNE 0x6913e0					
  module.go:63165	0x6913d4		7a0a			JP 0x6913e0					
  module.go:63198	0x6913d6		0f10c2			MOVUPS X2, X0					
  module.go:63167	0x6913d9		e960010000		JMP 0x69153e					
  module.go:63167	0x6913de		6690			NOPW						
  module.go:63169	0x6913e0		4885c0			TESTQ AX, AX					
  module.go:63169	0x6913e3		7d10			JGE 0x6913f5					
  module.go:63194	0x6913e5		f20f5cc9		SUBSD X1, X1					
  module.go:63194	0x6913e9		f20f5ecb		DIVSD X3, X1					
  module.go:63196	0x6913ed		0f10c1			MOVUPS X1, X0					
  module.go:63195	0x6913f0		e949010000		JMP 0x69153e					
  module.go:63173	0x6913f5		f20f10159b0d2700	MOVSD_XMM $f64.4350000000000000(SB), X2		
  module.go:63173	0x6913fd		f20f59d1		MULSD X1, X2					
  unsafe.go:35		0x691401		66480f7ed0		MOVQ X2, AX					
  module.go:63174	0x691406		4889c1			MOVQ AX, CX					
  module.go:63174	0x691409		48c1e920		SHRQ $0x20, CX					
  module.go:63174	0x69140d		bacbfbffff		MOVL $-0x435, DX				
  module.go:63177	0x691412		4889c3			MOVQ AX, BX					
  module.go:63177	0x691415		4889c8			MOVQ CX, AX					
  module.go:63177	0x691418		4889d9			MOVQ BX, CX					
  module.go:63177	0x69141b		05625f0900		ADDL $0x95f62, AX				
  module.go:63178	0x691420		89c3			MOVL AX, BX					
  module.go:63178	0x691422		c1e814			SHRL $0x14, AX					
  module.go:63178	0x691425		01d0			ADDL DX, AX					
  module.go:63178	0x691427		0f57d2			XORPS X2, X2					
  module.go:63178	0x69142a		f20f2ad0		CVTSI2SDL AX, X2				
  module.go:63179	0x69142e		f20f100d3a0d2700	MOVSD_XMM $f64.3fe62e42fee00000(SB), X1		
  module.go:63179	0x691436		f20f59ca		MULSD X2, X1					
  module.go:63180	0x69143a		b8ffffffff		MOVL $-0x1, AX					
  module.go:63180	0x69143f		4821c1			ANDQ AX, CX					
  module.go:63180	0x691442		81e3ffff0f00		ANDL $0xfffff, BX				
  module.go:63180	0x691448		8d839ea0e63f		LEAL 0x3fe6a09e(BX), AX				
  module.go:63180	0x69144e		89c0			MOVL AX, AX					
  module.go:63180	0x691450		48c1e020		SHLQ $0x20, AX					
  module.go:63180	0x691454		4809c1			ORQ AX, CX					
  module.go:63182	0x691457		f20f101dd10c2700	MOVSD_XMM $f64.3dea39ef35793c76(SB), X3		
  module.go:63182	0x69145f		f20f59d3		MULSD X3, X2					
  unsafe.go:41		0x691463		66480f6ed9		MOVQ CX, X3					
  module.go:63180	0x691468		f20f1025380d2700	MOVSD_XMM $f64.bff0000000000000(SB), X4		
  module.go:63180	0x691470		f20f58dc		ADDSD X4, X3					
  module.go:63183	0x691474		f20f10253c0b2700	MOVSD_XMM $f64.4000000000000000(SB), X4		
  module.go:63183	0x69147c		f20f58e3		ADDSD X3, X4					
  module.go:63183	0x691480		0f10eb			MOVUPS X3, X5					
  module.go:63183	0x691483		f20f5edc		DIVSD X4, X3					
  module.go:63185	0x691487		f20f1025a90b2700	MOVSD_XMM $f64.3fe0000000000000(SB), X4		
  module.go:63185	0x69148f		f20f59e5		MULSD X5, X4					
  module.go:63185	0x691493		f20f59e5		MULSD X5, X4					
  module.go:63187	0x691497		0f10f3			MOVUPS X3, X6					
  module.go:63187	0x69149a		f20f59db		MULSD X3, X3					
  module.go:63188	0x69149e		0f10fb			MOVUPS X3, X7					
  module.go:63188	0x6914a1		f20f59db		MULSD X3, X3					
  module.go:63189	0x6914a5		f2440f1005920c2700	MOVSD_XMM $f64.3fc39a09d078c69f(SB), X8		
  module.go:63189	0x6914ae		f2440f59c3		MULSD X3, X8					
  module.go:63189	0x6914b3		f2440f100d940c2700	MOVSD_XMM $f64.3fcc71c51d8e78af(SB), X9		
  module.go:63189	0x6914bc		f2450f58c8		ADDSD X8, X9					
  module.go:63189	0x6914c1		f2440f59cb		MULSD X3, X9					
  module.go:63189	0x6914c6		f2440f1005910c2700	MOVSD_XMM $f64.3fd999999997fa04(SB), X8		
  module.go:63189	0x6914cf		f2450f58c1		ADDSD X9, X8					
  module.go:63189	0x6914d4		f2440f59c3		MULSD X3, X8					
  module.go:63189	0x6914d9		f2440f100d560c2700	MOVSD_XMM $f64.3fc2f112df3e5244(SB), X9		
  module.go:63189	0x6914e2		f2440f59cb		MULSD X3, X9					
  module.go:63189	0x6914e7		f2440f1015580c2700	MOVSD_XMM $f64.3fc7466496cb03de(SB), X10	
  module.go:63189	0x6914f0		f2450f58d1		ADDSD X9, X10					
  module.go:63189	0x6914f5		f2440f59d3		MULSD X3, X10					
  module.go:63189	0x6914fa		f2440f100d550c2700	MOVSD_XMM $f64.3fd2492494229359(SB), X9		
  module.go:63189	0x691503		f2450f58ca		ADDSD X10, X9					
  module.go:63189	0x691508		f2440f59cb		MULSD X3, X9					
  module.go:63189	0x69150d		f20f101d530c2700	MOVSD_XMM $f64.3fe5555555555593(SB), X3		
  module.go:63189	0x691515		f2410f58d9		ADDSD X9, X3					
  module.go:63189	0x69151a		f20f59df		MULSD X7, X3					
  module.go:63189	0x69151e		f2410f58d8		ADDSD X8, X3					
  module.go:63189	0x691523		f20f58dc		ADDSD X4, X3					
  module.go:63189	0x691527		f20f59f3		MULSD X3, X6					
  module.go:63189	0x69152b		f20f58d6		ADDSD X6, X2					
  module.go:63189	0x69152f		f20f5cd4		SUBSD X4, X2					
  module.go:63189	0x691533		f20f58d5		ADDSD X5, X2					
  module.go:63189	0x691537		f20f58d1		ADDSD X1, X2					
  module.go:63198	0x69153b		0f10c2			MOVUPS X2, X0					
  module.go:63198	0x69153e		c3			RET						
