from pathlib import Path
import json,subprocess,os,datetime
root=Path.cwd();out=root/'.cache/structural-phase0';go=root/'.cache/toolchains/go1.26.8/go/bin/go';env=dict(os.environ,PATH=str(go.parent)+':'+os.environ['PATH'],GOTOOLCHAIN='local',CGO_ENABLED='0',GOAMD64='v1',GOCACHE=str(root/'.cache/go'),GOFLAGS='-buildvcs=false',COCOON_PHASE0_LOG_ORACLE_TABLE=str(out/'table.bin'));records=[]
for mode in ('0','1'):
 args=[str(go),'test','-pgo=off','-overlay='+str(out/'oracle-overlay.json'),'./rt','./examples/datadog/go/dd/...','./testdata/compute/go/compute/...','./testdata/streaming/go/streaming/...','-count=1'];caseenv=dict(env,COCOON_PHASE0_LOG_ORACLE=mode);target=out/('oracle-mode'+mode+'-whole.log')
 with target.open('x') as log:
  print('COMMAND',json.dumps(args),'ENV',json.dumps({k:caseenv[k] for k in ('PATH','GOTOOLCHAIN','CGO_ENABLED','GOAMD64','GOFLAGS','COCOON_PHASE0_LOG_ORACLE_TABLE','COCOON_PHASE0_LOG_ORACLE')}),file=log,flush=True);r=subprocess.run(args,cwd=root,env=caseenv,stdout=log,stderr=subprocess.STDOUT);print('EXIT',r.returncode,file=log)
 records.append({'argv':args,'mode':mode,'log':target.name,'exit':r.returncode,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()});(out/'actual-mode-whole-records.json').write_text(json.dumps(records,indent=2)+'\n');assert r.returncode==0,target;print('PASS actualmode',mode,'all3fixtures/runtime/contracts/differential/bulk',flush=True)
