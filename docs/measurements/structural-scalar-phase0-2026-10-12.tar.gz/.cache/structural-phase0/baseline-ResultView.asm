TEXT dario.cat/cocoon/rt.(*Call).ResultView(SB) /home/dario/Code/cocoon/rt/instance.go
  instance.go:349	0x5c7f40		493b6610		CMPQ SP, 0x10(R14)							
  instance.go:349	0x5c7f44		0f8621020000		JBE 0x5c816b								
  instance.go:349	0x5c7f4a		55			PUSHQ BP								
  instance.go:349	0x5c7f4b		4889e5			MOVQ SP, BP								
  instance.go:349	0x5c7f4e		4883ec68		SUBQ $0x68, SP								
  instance.go:72	0x5c7f52		4889442478		MOVQ AX, 0x78(SP)							
  instance.go:72	0x5c7f57		89bc2490000000		MOVL DI, 0x90(SP)							
  instance.go:72	0x5c7f5e		48898c2488000000	MOVQ CX, 0x88(SP)							
  instance.go:72	0x5c7f66		48899c2480000000	MOVQ BX, 0x80(SP)							
  instance.go:350	0x5c7f6e		488b08			MOVQ 0(AX), CX								
  instance.go:350	0x5c7f71		488b11			MOVQ 0(CX), DX								
  instance.go:350	0x5c7f74		488b4108		MOVQ 0x8(CX), AX							
  instance.go:350	0x5c7f78		488b4a20		MOVQ 0x20(DX), CX							
  instance.go:350	0x5c7f7c		ffd1			CALL CX									
  instance.go:350	0x5c7f7e		48895c2440		MOVQ BX, 0x40(SP)							
  instance.go:351	0x5c7f83		488b4c2478		MOVQ 0x78(SP), CX							
  instance.go:351	0x5c7f88		488b11			MOVQ 0(CX), DX								
  instance.go:351	0x5c7f8b		8b5260			MOVL 0x60(DX), DX							
  instance.go:71	0x5c7f8e		488d7208		LEAQ 0x8(DX), SI							
  instance.go:72	0x5c7f92		4839f3			CMPQ BX, SI								
  instance.go:72	0x5c7f95		7221			JB 0x5c7fb8								
  instance.go:75	0x5c7f97		4189d1			MOVL DX, R9								
  instance.go:75	0x5c7f9a		4829d2			SUBQ DX, DX								
  instance.go:75	0x5c7f9d		4883c208		ADDQ $0x8, DX								
  instance.go:75	0x5c7fa1		4989d2			MOVQ DX, R10								
  instance.go:75	0x5c7fa4		48f7da			NEGQ DX									
  instance.go:75	0x5c7fa7		48c1fa3f		SARQ $0x3f, DX								
  instance.go:75	0x5c7fab		4921d1			ANDQ DX, R9								
  instance.go:75	0x5c7fae		4a8d1408		LEAQ 0(AX)(R9*1), DX							
  instance.go:75	0x5c7fb2		31f6			XORL SI, SI								
  instance.go:75	0x5c7fb4		31ff			XORL DI, DI								
  instance.go:351	0x5c7fb6		eb50			JMP 0x5c8008								
  instance.go:351	0x5c7fb8		89542430		MOVL DX, 0x30(SP)							
  instance.go:71	0x5c7fbc		4889742450		MOVQ SI, 0x50(SP)							
  instance.go:350	0x5c7fc1		4889442460		MOVQ AX, 0x60(SP)							
  instance.go:73	0x5c7fc6		488d05d3922c00		LEAQ 0x2c92d3(IP), AX							
  instance.go:73	0x5c7fcd		e84ea2e5ff		CALL runtime.newobject(SB)						
  instance.go:73	0x5c7fd2		8b4c2430		MOVL 0x30(SP), CX							
  instance.go:73	0x5c7fd6		894810			MOVL CX, 0x10(AX)							
  instance.go:73	0x5c7fd9		488b4c2450		MOVQ 0x50(SP), CX							
  instance.go:73	0x5c7fde		488908			MOVQ CX, 0(AX)								
  instance.go:73	0x5c7fe1		488b4c2440		MOVQ 0x40(SP), CX							
  instance.go:73	0x5c7fe6		48894808		MOVQ CX, 0x8(AX)							
  instance.go:357	0x5c7fea		488b4c2478		MOVQ 0x78(SP), CX							
  instance.go:72	0x5c7fef		488b5c2440		MOVQ 0x40(SP), BX							
  instance.go:72	0x5c7ff4		488d35a5d43300		LEAQ go:itab.*dario.cat/cocoon/rt.memoryRangeError,error(SB), SI	
  instance.go:72	0x5c7ffb		4531d2			XORL R10, R10								
  instance.go:72	0x5c7ffe		31d2			XORL DX, DX								
  instance.go:351	0x5c8000		4889c7			MOVQ AX, DI								
  instance.go:75	0x5c8003		488b442460		MOVQ 0x60(SP), AX							
  instance.go:352	0x5c8008		4885f6			TESTQ SI, SI								
  instance.go:352	0x5c800b		0f8537010000		JNE 0x5c8148								
  instance.go:355	0x5c8011		90			NOPL									
  binary.go:91		0x5c8012		4983fa03		CMPQ R10, $0x3								
  binary.go:91		0x5c8016		0f8649010000		JBE 0x5c8165								
  instance.go:356	0x5c801c		4d8d4afc		LEAQ -0x4(R10), R9							
  binary.go:91		0x5c8020		4983f903		CMPQ R9, $0x3								
  binary.go:91		0x5c8024		0f8634010000		JBE 0x5c815e								
  instance.go:356	0x5c802a		49f7d9			NEGQ R9									
  instance.go:356	0x5c802d		49c1f93f		SARQ $0x3f, R9								
  instance.go:356	0x5c8031		4183e104		ANDL $0x4, R9								
  instance.go:357	0x5c8035		4c8b11			MOVQ 0(CX), R10								
  binary.go:92		0x5c8038		468b0c0a		MOVL 0(DX)(R9*1), R9							
  binary.go:92		0x5c803c		0f1f4000		NOPL 0(AX)								
  instance.go:357	0x5c8040		4d394a38		CMPQ 0x38(R10), R9							
  instance.go:357	0x5c8044		0f82e3000000		JB 0x5c812d								
  binary.go:92		0x5c804a		8b12			MOVL 0(DX), DX								
  instance.go:71	0x5c804c		4901d1			ADDQ DX, R9								
  instance.go:72	0x5c804f		4c39cb			CMPQ BX, R9								
  instance.go:72	0x5c8052		7219			JB 0x5c806d								
  instance.go:75	0x5c8054		4929d1			SUBQ DX, R9								
  instance.go:75	0x5c8057		4d89ca			MOVQ R9, R10								
  instance.go:75	0x5c805a		49f7d9			NEGQ R9									
  instance.go:75	0x5c805d		49c1f93f		SARQ $0x3f, R9								
  instance.go:75	0x5c8061		4c21ca			ANDQ R9, DX								
  instance.go:75	0x5c8064		4801c2			ADDQ AX, DX								
  instance.go:75	0x5c8067		31c0			XORL AX, AX								
  instance.go:75	0x5c8069		31c9			XORL CX, CX								
  instance.go:360	0x5c806b		eb3f			JMP 0x5c80ac								
  instance.go:71	0x5c806d		4c894c2448		MOVQ R9, 0x48(SP)							
  binary.go:92		0x5c8072		89542434		MOVL DX, 0x34(SP)							
  instance.go:73	0x5c8076		488d0523922c00		LEAQ 0x2c9223(IP), AX							
  instance.go:73	0x5c807d		0f1f00			NOPL 0(AX)								
  instance.go:73	0x5c8080		e89ba1e5ff		CALL runtime.newobject(SB)						
  instance.go:73	0x5c8085		8b4c2434		MOVL 0x34(SP), CX							
  instance.go:73	0x5c8089		894810			MOVL CX, 0x10(AX)							
  instance.go:73	0x5c808c		488b4c2448		MOVQ 0x48(SP), CX							
  instance.go:73	0x5c8091		488908			MOVQ CX, 0(AX)								
  instance.go:73	0x5c8094		488b4c2440		MOVQ 0x40(SP), CX							
  instance.go:73	0x5c8099		48894808		MOVQ CX, 0x8(AX)							
  instance.go:73	0x5c809d		4531d2			XORL R10, R10								
  instance.go:73	0x5c80a0		31d2			XORL DX, DX								
  instance.go:360	0x5c80a2		4889c1			MOVQ AX, CX								
  instance.go:360	0x5c80a5		488d05f4d33300		LEAQ go:itab.*dario.cat/cocoon/rt.memoryRangeError,error(SB), AX	
  instance.go:361	0x5c80ac		4885c0			TESTQ AX, AX								
  instance.go:361	0x5c80af		7569			JNE 0x5c811a								
  instance.go:364	0x5c80b1		8b8c2490000000		MOVL 0x90(SP), CX							
  instance.go:364	0x5c80b8		85c9			TESTL CX, CX								
  instance.go:364	0x5c80ba		7438			JE 0x5c80f4								
  instance.go:360	0x5c80bc		4c89542438		MOVQ R10, 0x38(SP)							
  instance.go:360	0x5c80c1		4889542458		MOVQ DX, 0x58(SP)							
  instance.go:365	0x5c80c6		488b842480000000	MOVQ 0x80(SP), AX							
  instance.go:365	0x5c80ce		488b9c2488000000	MOVQ 0x88(SP), BX							
  instance.go:365	0x5c80d6		4889d7			MOVQ DX, DI								
  instance.go:365	0x5c80d9		4c89d6			MOVQ R10, SI								
  instance.go:365	0x5c80dc		4989f0			MOVQ SI, R8								
  instance.go:365	0x5c80df		90			NOPL									
  instance.go:365	0x5c80e0		e85be2ffff		CALL dario.cat/cocoon/rt.FromStatus(SB)					
  instance.go:365	0x5c80e5		4885c0			TESTQ AX, AX								
  instance.go:365	0x5c80e8		751d			JNE 0x5c8107								
  instance.go:369	0x5c80ea		488b542458		MOVQ 0x58(SP), DX							
  instance.go:369	0x5c80ef		4c8b542438		MOVQ 0x38(SP), R10							
  instance.go:369	0x5c80f4		4889d0			MOVQ DX, AX								
  instance.go:369	0x5c80f7		4c89d3			MOVQ R10, BX								
  instance.go:369	0x5c80fa		4889d9			MOVQ BX, CX								
  instance.go:369	0x5c80fd		31ff			XORL DI, DI								
  instance.go:369	0x5c80ff		31f6			XORL SI, SI								
  instance.go:369	0x5c8101		4883c468		ADDQ $0x68, SP								
  instance.go:369	0x5c8105		5d			POPQ BP									
  instance.go:369	0x5c8106		c3			RET									
  instance.go:366	0x5c8107		31c9			XORL CX, CX								
  instance.go:366	0x5c8109		4889c7			MOVQ AX, DI								
  instance.go:366	0x5c810c		4889de			MOVQ BX, SI								
  instance.go:366	0x5c810f		31c0			XORL AX, AX								
  instance.go:366	0x5c8111		4889cb			MOVQ CX, BX								
  instance.go:366	0x5c8114		4883c468		ADDQ $0x68, SP								
  instance.go:366	0x5c8118		5d			POPQ BP									
  instance.go:366	0x5c8119		c3			RET									
  instance.go:362	0x5c811a		31db			XORL BX, BX								
  instance.go:362	0x5c811c		4889c7			MOVQ AX, DI								
  instance.go:362	0x5c811f		4889ce			MOVQ CX, SI								
  instance.go:362	0x5c8122		31c0			XORL AX, AX								
  instance.go:362	0x5c8124		4889d9			MOVQ BX, CX								
  instance.go:362	0x5c8127		4883c468		ADDQ $0x68, SP								
  instance.go:362	0x5c812b		5d			POPQ BP									
  instance.go:362	0x5c812c		c3			RET									
  instance.go:358	0x5c812d		488b3ddc867000		MOVQ dario.cat/cocoon/rt.ErrTooLarge(SB), DI				
  instance.go:358	0x5c8134		488b35dd867000		MOVQ dario.cat/cocoon/rt.ErrTooLarge+8(SB), SI				
  instance.go:358	0x5c813b		31c0			XORL AX, AX								
  instance.go:358	0x5c813d		31db			XORL BX, BX								
  instance.go:358	0x5c813f		4889d9			MOVQ BX, CX								
  instance.go:358	0x5c8142		4883c468		ADDQ $0x68, SP								
  instance.go:358	0x5c8146		5d			POPQ BP									
  instance.go:358	0x5c8147		c3			RET									
  instance.go:353	0x5c8148		31c0			XORL AX, AX								
  instance.go:353	0x5c814a		31db			XORL BX, BX								
  instance.go:353	0x5c814c		4889d9			MOVQ BX, CX								
  instance.go:351	0x5c814f		4889fa			MOVQ DI, DX								
  instance.go:353	0x5c8152		4889f7			MOVQ SI, DI								
  instance.go:353	0x5c8155		4889d6			MOVQ DX, SI								
  instance.go:353	0x5c8158		4883c468		ADDQ $0x68, SP								
  instance.go:353	0x5c815c		5d			POPQ BP									
  instance.go:353	0x5c815d		c3			RET									
  binary.go:91		0x5c815e		6690			NOPW									
  binary.go:91		0x5c8160		e85b88ecff		CALL runtime.panicBounds(SB)						
  binary.go:91		0x5c8165		e85688ecff		CALL runtime.panicBounds(SB)						
  binary.go:91		0x5c816a		90			NOPL									
  instance.go:349	0x5c816b		4889442408		MOVQ AX, 0x8(SP)							
  instance.go:349	0x5c8170		48895c2410		MOVQ BX, 0x10(SP)							
  instance.go:349	0x5c8175		48894c2418		MOVQ CX, 0x18(SP)							
  instance.go:349	0x5c817a		897c2420		MOVL DI, 0x20(SP)							
  instance.go:349	0x5c817e		6690			NOPW									
  instance.go:349	0x5c8180		e81b6becff		CALL runtime.morestack_noctxt.abi0(SB)					
  instance.go:349	0x5c8185		488b442408		MOVQ 0x8(SP), AX							
  instance.go:349	0x5c818a		488b5c2410		MOVQ 0x10(SP), BX							
  instance.go:349	0x5c818f		488b4c2418		MOVQ 0x18(SP), CX							
  instance.go:349	0x5c8194		8b7c2420		MOVL 0x20(SP), DI							
  instance.go:349	0x5c8198		e9a3fdffff		JMP dario.cat/cocoon/rt.(*Call).ResultView(SB)				
