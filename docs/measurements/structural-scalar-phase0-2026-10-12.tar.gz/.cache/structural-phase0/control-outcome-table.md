| Workload | Outline/baseline screen; confirm (Δ; p) | Disabled/baseline screen; confirm (Δ; p) |
| --- | ---: | ---: |
| Original-ObfuscateSQL | +0.89%; 0.209; +1.27%; 0.024 | -0.61%; 0.165; -0.94%; 0.035 |
| Original-SketchAdd-FixedN | +2.46%; 0.001; +1.63%; 0.001 | +3.36%; 0.001; +3.00%; 0.001 |
| Original-SketchAddMany1k | +0.24%; 0.620; -0.18%; 0.456 | +9.92%; 0.001; +9.89%; 0.001 |
| Original-ObfuscateTraces1k | -0.94%; 0.209; -0.37%; 0.902 | -0.29%; 0.902; -1.77%; 0.097 |
| Original-SketchAddVaried | +0.58%; 0.334; +1.62%; 0.001 | +4.01%; 0.016; +5.41%; 0.001 |
| Original-ObfuscateSQLVaried | +1.05%; 0.017; +1.05%; 0.002 | +1.01%; 0.028; +0.86%; 0.004 |
| Original-SketchAddNegativeBins | +2.07%; 0.001; +2.16%; 0.001 | +3.48%; 0.001; +3.43%; 0.001 |
| MatchedReference-SQLHoldout | +0.26%; 0.383; +0.09%; 0.402 | +1.89%; 0.001; +1.73%; 0.001 |
| MatchedReference-Increasing-FixedN | +0.97%; 0.435; +1.50%; 0.001 | +4.35%; 0.026; +4.95%; 0.001 |
| MatchedReference-BroadScalar-FixedN | +0.92%; 0.001; +0.10%; 0.175 | +3.16%; 0.001; +3.22%; 0.001 |
| MatchedReference-Repeated1024 | +0.55%; 0.209; -0.24%; 0.902 | +10.70%; 0.017; +10.08%; 0.001 |
| MatchedReference-BroadBatch8192 | +3.12%; 0.001; +2.75%; 0.001 | +9.87%; 0.001; +9.50%; 0.001 |
| RawGuest-SketchAdd-FixedN | +3.09%; 0.001; +2.52%; 0.001 | +6.47%; 0.001; +7.32%; 0.001 |
| StreamOneHome-Fixed | -0.01%; 0.456; -0.15%; 0.318 | -0.27%; 0.209; -0.02%; 0.710 |
| Stream16Homes-Fixed | -1.87%; 0.710; -0.19%; 1.000 | -1.79%; 0.710; -0.26%; 1.000 |
| StreamOneHome-Holdout | +0.62%; 0.165; +0.19%; 0.318 | +0.33%; 0.259; +0.32%; 0.259 |
| Stream16Homes-Holdout | -0.51%; 0.902; +0.69%; 0.620 | +0.58%; 0.259; +0.35%; 0.710 |
| StreamP1-OneHome-Fixed | +0.33%; 0.832; -0.20%; 0.038 | -0.38%; 0.097; +0.00%; 0.383 |
| StreamP1-OneHome-Holdout | +0.50%; 0.209; -0.48%; 0.535 | +0.66%; 0.259; -0.16%; 0.902 |
