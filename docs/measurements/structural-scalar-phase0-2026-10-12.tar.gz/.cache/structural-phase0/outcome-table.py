"""Derive all diagnostic comparisons and apply the recorded decision rule."""
import json
from pathlib import Path
import re

out = Path(__file__).resolve().parent
run = out / 'paired'
plan = json.loads((out / 'qualification-plan.json').read_text())
summary = json.loads((run / 'summary.json').read_text())

def pvalues(filename):
    rows = [row for row in filename.read_text().splitlines() if row.startswith('Comparison/')]
    assert len(rows) == 1
    return [float(p) for p in re.findall(r'p=([0-9.]+)', rows[0])]

def value(number):
    return f'{number:,.3f}'.rstrip('0').rstrip('.')

records = []
lines = ['| Workload | Screen baseline → oracle, ns/op | Δ; p | Confirm baseline → oracle, ns/op | Δ; p | Oracle/disabled screen; confirm (Δ; p) |',
         '| --- | ---: | ---: | ---: | ---: | ---: |']
controls = ['| Workload | Outline/baseline screen; confirm (Δ; p) | Disabled/baseline screen; confirm (Δ; p) |',
            '| --- | ---: | ---: |']
for group in plan['comparisons']:
    key = group['key']
    cells, secondary, control_cells = [key], [], [key]
    outline_cells, disabled_cells = [], []
    for rd in ('screen', 'confirm'):
        roles = summary[rd][key]['roles']
        baseline = roles['baseline']['medians']['ns/op']
        oracle = roles['oracle']['medians']['ns/op']
        disabled = roles['oracle-control']['medians']['ns/op']
        ps = pvalues(run / f'{rd}-{key}-time-benchstat.txt')
        order = [case['role'] for case in group['cases']]
        assert len(ps) == len(order) - 1 and order[0] == 'baseline'
        primary_p = ps[order.index('oracle') - 1]
        reports = {c['roles'][0]: c['key'] for c in group['secondary_comparisons']}
        control_ps = pvalues(run / f"{rd}-{reports['oracle-control']}-time-benchstat.txt")
        outline_ps = pvalues(run / f"{rd}-{reports['outline']}-time-benchstat.txt")
        assert len(control_ps) == len(outline_ps) == 1
        control_delta = 100 * (oracle / disabled - 1)
        cells += [value(baseline) + ' → ' + value(oracle), f"{roles['oracle']['delta_percent_ns']:+.2f}%; {primary_p:.3f}"]
        secondary.append(f'{control_delta:+.2f}%; {control_ps[0]:.3f}')
        outline_cells.append(f"{roles['outline']['delta_percent_ns']:+.2f}%; {ps[order.index('outline') - 1]:.3f}")
        disabled_cells.append(f"{roles['oracle-control']['delta_percent_ns']:+.2f}%; {ps[order.index('oracle-control') - 1]:.3f}")
        records.append({'round': rd, 'comparison': key, 'baseline_ns': baseline, 'oracle_ns': oracle,
                        'delta_vs_baseline_percent': roles['oracle']['delta_percent_ns'], 'p_vs_baseline': primary_p,
                        'disabled_ns': disabled, 'delta_vs_disabled_percent': control_delta, 'p_vs_disabled': control_ps[0],
                        'outline_ns': roles['outline']['medians']['ns/op'],
                        'delta_vs_outline_percent': 100 * (oracle / roles['outline']['medians']['ns/op'] - 1),
                        'p_vs_outline': outline_ps[0],
                        'outline_delta_vs_baseline_percent': roles['outline']['delta_percent_ns'],
                        'outline_p_vs_baseline': ps[order.index('outline') - 1],
                        'disabled_delta_vs_baseline_percent': roles['oracle-control']['delta_percent_ns'],
                        'disabled_p_vs_baseline': ps[order.index('oracle-control') - 1]})
    cells.append('; '.join(secondary))
    lines.append('| ' + ' | '.join(cells) + ' |')
    controls.append('| ' + ' | '.join(control_cells + ['; '.join(outline_cells), '; '.join(disabled_cells)]) + ' |')
primary = [row for row in records if row['comparison'] == 'Original-SketchAdd-FixedN']
assert len(primary) == 2 and {r['round'] for r in primary} == {'screen', 'confirm'}
decision = {'rule_source': 'decision-plan.json', 'primary': primary,
            'meets_preregistered_ceiling_rule': all(r['delta_vs_baseline_percent'] <= -10 and r['delta_vs_disabled_percent'] <= -10
                                                   and r['p_vs_baseline'] < .05 and r['p_vs_disabled'] < .05 for r in primary),
            'conclusion': 'Justifies separately specified certified-interval feasibility proof only; no bounded implementation established, no production promotion, no M1 acceptance.',
            'all_time_comparisons': records}
for filename, data in [('outcome-table.md', '\n'.join(lines) + '\n'),
                       ('control-outcome-table.md', '\n'.join(controls) + '\n'),
                       ('decision-outcome.json', json.dumps(decision, indent=2) + '\n')]:
    with (out / filename).open('x') as f:
        f.write(data)
print('Derived all19 rows and control negatives; ceiling rule:', decision['meets_preregistered_ceiling_rule'])
