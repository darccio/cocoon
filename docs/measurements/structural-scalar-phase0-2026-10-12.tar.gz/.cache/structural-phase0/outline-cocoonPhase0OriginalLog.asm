TEXT dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.cocoonPhase0OriginalLog(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/internal/wasm/module.go
  module.go:63136	0x6912a0		90			NOPL						
  unsafe.go:35		0x6912a1		66480f7ec0		MOVQ X0, AX					
  module.go:63144	0x6912a6		90			NOPL						
  module.go:63145	0x6912a7		48b90000000000001000	MOVQ $0x10000000000000, CX			
  module.go:63145	0x6912b1		4839c8			CMPQ AX, CX					
  module.go:63145	0x6912b4		7c42			JL 0x6912f8					
  module.go:63146	0x6912b6		48b9ffffffffffffef7f	MOVQ $0x7fefffffffffffff, CX			
  module.go:63146	0x6912c0		4839c8			CMPQ AX, CX					
  module.go:63146	0x6912c3		0f87b5010000		JA 0x69147e					
  module.go:63150	0x6912c9		4889c1			MOVQ AX, CX					
  module.go:63150	0x6912cc		48c1e820		SHRQ $0x20, AX					
  module.go:63151	0x6912d0		483d0000f03f		CMPQ AX, $0x3ff00000				
  module.go:63151	0x6912d6		7408			JE 0x6912e0					
  module.go:63151	0x6912d8		ba01fcffff		MOVL $-0x3ff, DX				
  module.go:63154	0x6912dd		eb7c			JMP 0x69135b					
  module.go:63154	0x6912df		90			NOPL						
  module.go:63156	0x6912e0		85c9			TESTL CX, CX					
  module.go:63156	0x6912e2		740c			JE 0x6912f0					
  module.go:63156	0x6912e4		b80000f03f		MOVL $0x3ff00000, AX				
  module.go:63156	0x6912e9		ba01fcffff		MOVL $-0x3ff, DX				
  module.go:63158	0x6912ee		eb6b			JMP 0x69135b					
  module.go:63158	0x6912f0		0f57c0			XORPS X0, X0					
  module.go:63161	0x6912f3		e986010000		JMP 0x69147e					
  module.go:63163	0x6912f8		0f10c8			MOVUPS X0, X1					
  module.go:63163	0x6912fb		f20f59c0		MULSD X0, X0					
  module.go:63163	0x6912ff		f20f1015590e2700	MOVSD_XMM $f64.bff0000000000000(SB), X2		
  module.go:63163	0x691307		f20f5ed0		DIVSD X0, X2					
  module.go:63164	0x69130b		0f57db			XORPS X3, X3					
  module.go:63164	0x69130e		660f2ecb		UCOMISD X3, X1					
  module.go:63164	0x691312		750c			JNE 0x691320					
  module.go:63164	0x691314		7a0a			JP 0x691320					
  module.go:63197	0x691316		0f10c2			MOVUPS X2, X0					
  module.go:63166	0x691319		e960010000		JMP 0x69147e					
  module.go:63166	0x69131e		6690			NOPW						
  module.go:63168	0x691320		4885c0			TESTQ AX, AX					
  module.go:63168	0x691323		7d10			JGE 0x691335					
  module.go:63193	0x691325		f20f5cc9		SUBSD X1, X1					
  module.go:63193	0x691329		f20f5ecb		DIVSD X3, X1					
  module.go:63195	0x69132d		0f10c1			MOVUPS X1, X0					
  module.go:63194	0x691330		e949010000		JMP 0x69147e					
  module.go:63172	0x691335		f20f1015130e2700	MOVSD_XMM $f64.4350000000000000(SB), X2		
  module.go:63172	0x69133d		f20f59d1		MULSD X1, X2					
  unsafe.go:35		0x691341		66480f7ed0		MOVQ X2, AX					
  module.go:63173	0x691346		4889c1			MOVQ AX, CX					
  module.go:63173	0x691349		48c1e920		SHRQ $0x20, CX					
  module.go:63173	0x69134d		bacbfbffff		MOVL $-0x435, DX				
  module.go:63176	0x691352		4889c3			MOVQ AX, BX					
  module.go:63176	0x691355		4889c8			MOVQ CX, AX					
  module.go:63176	0x691358		4889d9			MOVQ BX, CX					
  module.go:63176	0x69135b		05625f0900		ADDL $0x95f62, AX				
  module.go:63177	0x691360		89c3			MOVL AX, BX					
  module.go:63177	0x691362		c1e814			SHRL $0x14, AX					
  module.go:63177	0x691365		01d0			ADDL DX, AX					
  module.go:63177	0x691367		0f57d2			XORPS X2, X2					
  module.go:63177	0x69136a		f20f2ad0		CVTSI2SDL AX, X2				
  module.go:63178	0x69136e		f20f100db20d2700	MOVSD_XMM $f64.3fe62e42fee00000(SB), X1		
  module.go:63178	0x691376		f20f59ca		MULSD X2, X1					
  module.go:63179	0x69137a		b8ffffffff		MOVL $-0x1, AX					
  module.go:63179	0x69137f		4821c1			ANDQ AX, CX					
  module.go:63179	0x691382		81e3ffff0f00		ANDL $0xfffff, BX				
  module.go:63179	0x691388		8d839ea0e63f		LEAL 0x3fe6a09e(BX), AX				
  module.go:63179	0x69138e		89c0			MOVL AX, AX					
  module.go:63179	0x691390		48c1e020		SHLQ $0x20, AX					
  module.go:63179	0x691394		4809c1			ORQ AX, CX					
  module.go:63181	0x691397		f20f101d490d2700	MOVSD_XMM $f64.3dea39ef35793c76(SB), X3		
  module.go:63181	0x69139f		f20f59d3		MULSD X3, X2					
  unsafe.go:41		0x6913a3		66480f6ed9		MOVQ CX, X3					
  module.go:63179	0x6913a8		f20f1025b00d2700	MOVSD_XMM $f64.bff0000000000000(SB), X4		
  module.go:63179	0x6913b0		f20f58dc		ADDSD X4, X3					
  module.go:63182	0x6913b4		f20f1025b40b2700	MOVSD_XMM $f64.4000000000000000(SB), X4		
  module.go:63182	0x6913bc		f20f58e3		ADDSD X3, X4					
  module.go:63182	0x6913c0		0f10eb			MOVUPS X3, X5					
  module.go:63182	0x6913c3		f20f5edc		DIVSD X4, X3					
  module.go:63184	0x6913c7		f20f1025210c2700	MOVSD_XMM $f64.3fe0000000000000(SB), X4		
  module.go:63184	0x6913cf		f20f59e5		MULSD X5, X4					
  module.go:63184	0x6913d3		f20f59e5		MULSD X5, X4					
  module.go:63186	0x6913d7		0f10f3			MOVUPS X3, X6					
  module.go:63186	0x6913da		f20f59db		MULSD X3, X3					
  module.go:63187	0x6913de		0f10fb			MOVUPS X3, X7					
  module.go:63187	0x6913e1		f20f59db		MULSD X3, X3					
  module.go:63188	0x6913e5		f2440f10050a0d2700	MOVSD_XMM $f64.3fc39a09d078c69f(SB), X8		
  module.go:63188	0x6913ee		f2440f59c3		MULSD X3, X8					
  module.go:63188	0x6913f3		f2440f100d0c0d2700	MOVSD_XMM $f64.3fcc71c51d8e78af(SB), X9		
  module.go:63188	0x6913fc		f2450f58c8		ADDSD X8, X9					
  module.go:63188	0x691401		f2440f59cb		MULSD X3, X9					
  module.go:63188	0x691406		f2440f1005090d2700	MOVSD_XMM $f64.3fd999999997fa04(SB), X8		
  module.go:63188	0x69140f		f2450f58c1		ADDSD X9, X8					
  module.go:63188	0x691414		f2440f59c3		MULSD X3, X8					
  module.go:63188	0x691419		f2440f100dce0c2700	MOVSD_XMM $f64.3fc2f112df3e5244(SB), X9		
  module.go:63188	0x691422		f2440f59cb		MULSD X3, X9					
  module.go:63188	0x691427		f2440f1015d00c2700	MOVSD_XMM $f64.3fc7466496cb03de(SB), X10	
  module.go:63188	0x691430		f2450f58d1		ADDSD X9, X10					
  module.go:63188	0x691435		f2440f59d3		MULSD X3, X10					
  module.go:63188	0x69143a		f2440f100dcd0c2700	MOVSD_XMM $f64.3fd2492494229359(SB), X9		
  module.go:63188	0x691443		f2450f58ca		ADDSD X10, X9					
  module.go:63188	0x691448		f2440f59cb		MULSD X3, X9					
  module.go:63188	0x69144d		f20f101dcb0c2700	MOVSD_XMM $f64.3fe5555555555593(SB), X3		
  module.go:63188	0x691455		f2410f58d9		ADDSD X9, X3					
  module.go:63188	0x69145a		f20f59df		MULSD X7, X3					
  module.go:63188	0x69145e		f2410f58d8		ADDSD X8, X3					
  module.go:63188	0x691463		f20f58dc		ADDSD X4, X3					
  module.go:63188	0x691467		f20f59f3		MULSD X3, X6					
  module.go:63188	0x69146b		f20f58d6		ADDSD X6, X2					
  module.go:63188	0x69146f		f20f5cd4		SUBSD X4, X2					
  module.go:63188	0x691473		f20f58d5		ADDSD X5, X2					
  module.go:63188	0x691477		f20f58d1		ADDSD X1, X2					
  module.go:63197	0x69147b		0f10c2			MOVUPS X2, X0					
  module.go:63197	0x69147e		c3			RET						
