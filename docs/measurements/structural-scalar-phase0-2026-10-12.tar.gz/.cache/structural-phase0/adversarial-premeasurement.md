# Adversarial applied-source and premeasurement review

Reviewed the ignored authored hardener postpasses, regeneration cause, generated module patches, offline table generator/provenance, decision/qualification plans, freeze helpers and process driver. This review ran only source/data reads and SHA checks; no builds, tests, lint, profiles or timing. Tracked production was not edited.

Disposition: the exact source-pinned extraction, lookup and declared matrix have no identified semantic or fairness blocker for an unsupported phase-0 avoided-computation diagnostic. Final timing readiness remains conditional on the guest's completed actual-table-mode/high-prefix original-Wasm proof and the final config/freeze including all reviewed table/source/binary/proof/reference inputs. This note does not approve any production predicate, interval cache or public contract.

## Source, effects and numerical scope

The hardener cause adds only calls to phase0OutlineLog after the existing retained hardening/formatting paths. Its full current DD module SHA pins the selected function/labels/local names; this is deliberately not generic binding or eligibility proof. Generated DD patches remove the pure p17 region and dead v17 declaration, keep all fn176 text outside that region, and append the copied kernel plus role-specific wrapper. t16's memory load remains before the call and t27's after; the affine/floor/saturation statement and all existing memory accesses, checks, stores, state updates and labels outside the pure region remain ordered. The captured region contains pure arithmetic/bit conversions only. Its scratch v1/v6/v2/v16 are overwritten on every later path before their first use; v17/v19/v20 have no suffix reads. p17 is the sole live-out. The source-exact nested float casts, constants and branches are retained, not replaced by another ln or reassociated polynomial.

The table wrapper guards value>=0 and value<2^23 before uint32 conversion; therefore int(offset) and offset+8 fit on native386 as well as amd64. Fractional/negative/NaN/infinite/out-of-range values fall back. Both zero signs satisfy eligibility, but the copied zero branch computes -1/(v2*v2), producing the same -Inf for both; direct signed-zero bit tests still belong in final proof. Table entries preserve copied-kernel float bits. Frozen file length/hash rather than the initializer alone establishes content identity: init validates length, not SHA. Table corruption during timing is outside this diagnostic's frozen-input assumptions. Nil-table setup is healthy fallback, so ordinary initial no-table tests alone do not prove the actual enabled path.

A separate pure-outline role is necessary because extraction changes native call/frame/register/code placement even when numeric work is unchanged. Reported static fn176 frame128->136 is a negative, not a spill or latency saving; unchanged panic counts are not a substitute for executable trap-order proof. Original result ownership, reply checks, host imports/ABI3, immediate poison, per-call current memory cap, resource aliases/epochs and drain policy are unchanged sources. The raw logical-header trap test is intentionally not a valid Wasm shrink history and must retain that label.

## Table and setup controls

I independently verified table.bin is67,108,864 bytes with SHA48f45a3568b4ad0862e748c11372f46cc46fe3fcf80236965e11f7990d15314a. It is precomputed offline from the copied current kernel, so measured processes do not execute millions of untimed log computations. False/true use the identical oracle ELF bf491aa076c5f80e572404ca22db8ec1395d86b0b99128df103b2a92df191974 and the identical path/file/init/retention, differing only by runtime os.Getenv flag. The initializer's mutable global is runtime data; the mode is not a compiler constant. The false mode pays the same eligibility arithmetic before falling back, as shown by source.

Untouched and outline carry no table. Setting the table env var for them does not allocate it. Thus baseline comparisons remain confounded by 64MiB host live heap/file I/O/GC/power/cache setup; the same-ELF false comparison is the stronger isolation control. Do not claim these confounds removed or subtract startup/memory/lookup costs. ReadFile may allocate capacity/padding above logical64MiB. Zero warmed allocation metrics do not measure that retained setup, guest memory, RSS or native executable memory. The table is global per process, not a per-module guest resource, not a realistic cache, and not free production storage. Integer sequential prefixes are favorable synthetic locality, with no representative private SDK profile.

## Driver and matrix

The actual plan has19groups;88freshprocesses/pass*14passes=1232raw rows:12DDleaves*5roles (including freshly own-built independent reference), rawGuest*4 and6unchangedstream brackets*4. Both round/sample/group order reversals are explicit. Runtime case env is supplied and recorded per raw process and derived row. Driver requires one exact selector row, positive finite metrics, PASS, matching actual-procs for metric-bearing leaves, and exact parsed iterations for durations ending x. GOMAXPROCS16 and -test.cpu16 apply to unchanged original leaves; existing P1/P16 leaf setters/assertions/custom metrics remain required for matched and stream leaves. No new timed harness was added.

Four groups explicitly labelled FixedN use N4,194,304 in screening and N8,388,608 in independent reversed confirmation: original checked scalar, rawGuest, Increasing and BroadScalar. Each role receives the same prefix within a set; different set lengths are different evolving state/table coverage. Original/raw start1, giving no short misses and one long miss (input8,388,608). Increasing warms8192 then starts8193, giving8193long misses. BroadScalar cycles its own warmed finite corpus and is not an increasing-domain or representative workload. All other leaves use declared500ms/1s durations and seven samples; calibrated prefixes can still differ there. Fixed counts are diagnostic original selectors, not original adaptive M1 acceptance.

The corrected decision plan now requires >=10% median TIME reduction AND unadjusted p<.05 in all four primary comparisons: against untouched and same-ELF false control in each fixedN set. This is pinned before timing. No selected retiming, source-layout rescue, outlier exclusion, aggregate component subtraction or post-results change of comparator/threshold is permitted. RawGuest omits checks; profile fractions overlap; neither is an additive attainable host floor. Fresh reference retains its own ABI2/safety/corpus/compiled shape limitations. Successful primary evidence only justifies separately specified certified-interval feasibility work, not a production saving or M1.

All regenerated compute/stream module SHA identities match production; the three stream ELFs are byte-identical a2076ad9349c334f028e1c73cc166004c15da1debab79e8d2c349d851bc373bf. Six P1/P16 complete-lifetime streams are therefore environmental brackets, with every observed adverse median retained; they cannot establish candidate stream gain or equivalence. Baseline DD ELF c73daeca03069285b5b26701646ac0c94ece1a80c62c5905eff795324db3d3d0 reproduces the ordinary current baseline. Historical differently linked adaptive benchmark results must not enter these paired estimates.

## Pending final-readiness evidence

Final guest proof must demonstrate actual dynamic table false/true paths (e.g. a mutated entry used only by true), exhaustive table/copied-original-region bit identity plus sign/fractional/nonfinite/boundary fallback, scoped caller reconstruction, originalWasm complete Count/protobuf histories for both high prefixes and continued state use, partial read/trap order, and expected semantic mutant rejection. Original-region mechanical reconstruction is independent of the overlay extraction utility, but is not an independent ln implementation; originalWasm whole-caller/state comparisons supply the independent guest semantics. Nativeamd64/386 proof labels must match actual executions; no real big-endian claim.

Final config must pin table, all runtime modes/ELF identities, authoring hardener/utility/source patches, unchanged production/harness/compiler/dependency sources, proof scripts/tests/overlays/logs and fresh own reference inputs. Frozen clean state and all hashes are checked before/after timing, CPU/affinity/GC conditions recorded, all local reviewer/build/test/profile/lint/fuzz work stopped before isolation. Driver correctly limits its isolation statement to local tools; absence of unrelated external work is not proved. All failures and startup/setup/memory negatives remain durable evidence.

## Reviewed source identities

```json
{
  "harden.go": "ac8215c6da96bd92b82a9ef563e6efc553911f1d56e753a12ac033a7dcf0f4e9",
  "outline-postpass.go": "8415d7083adc39b2802019944b355648819aad3cc451d7c449681a8ca77aa272",
  "oracle-postpass.go": "3d0c271f19d3f55e7a1032abe96d2b236b13f528ff3f9e067c3d6bafda770759",
  "prepare-probe.py": "2ec24216e9e6ad078f7435517505b433ba9693151761e89e3a190235540f7c94",
  "probe-inventory.json": "43fc375e7a78c1503b25ca0c61a4183ae8b0190b96b1df1ab77fb0db10c30909",
  "dd-outline-module.go": "ab6398810809d3158246b9c4207b50ed698d0cc35b8a4707234c94fd2e09fc0a",
  "dd-oracle-module.go": "0bf35323079b011a6022e2c4b6e89a153fb79be13d3c55aa73ec1da5235f90c7",
  "table-generator.py": "2fb4be3876f38b01b0b8a5ba8cc7e6e99bbc637242226ba8b513fe000ae9f7fb",
  "table-generator_test.go": "16d58755568c9744a521d8a4a2f8f50dba6d99e42d70b4296683150692a25dfb",
  "table-provenance.json": "676fd7d946ed111f442bdb3c9f1d6c4f6fc9b5827914dc218a23d1c5f202362e",
  "decision-plan.json": "6fb4604b4fbe89c5b666b2170277a74c8ed0828f6b52f84f6bfd0b98b53a94e8",
  "qualification-plan.json": "8a2df3a689e450fe3983412de0abdf8dc3f8304de116d35061c2817e645bebb0",
  "paired.py": "23d38370a14da8ee259c87f0604aec389ec51ef41f396dd3f8967efa62115e43",
  "common.py": "15b03b50c3f1cb8afd06083076999784ec06c5636429c5d36b5b974d9fa98dd2",
  "freeze.py": "84adfba85bc938af744277d2e1683dd2cd4928213051b0c1fdb1f491711d4072"
}
```
