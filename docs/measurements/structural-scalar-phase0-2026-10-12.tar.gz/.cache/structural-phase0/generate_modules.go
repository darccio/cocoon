package main

import (
	"fmt"
	"os"

	"dario.cat/cocoon/internal/harden"
)

func main() {
	source, err := os.ReadFile(os.Args[1])
	must(err)
	required, err := harden.Required(source)
	must(err)
	output, err := harden.Rewrite(source, required)
	must(err)
	must(os.WriteFile(os.Args[2], output, 0o600))
}

func must(err error) {
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
