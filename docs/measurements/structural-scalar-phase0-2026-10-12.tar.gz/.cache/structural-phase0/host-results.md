# Host outcome audit: structural numeric-work ceiling

Read-only audit after all qualified measurements. The only writes are this ignored note and host-results-audit.json. No new builds, tests, benchmarks or profiles. Parent reports seven quality gates running after timing; this note does not assert their completion or production retention.

## Disposition

The preregistered avoided-log ceiling passes its narrow decision rule. Original checked scalar fixed-prefix time falls 87.49→70.26 ns (−19.6937%) in screening and 87.74→70.74 ns (−19.3754%) in reversed confirmation; both p=.001. Against the identical oracle ELF with its runtime flag false, it falls 90.43→70.26 ns (−22.3045%) and 90.37→70.74 ns (−21.7218%); both p=.001. All four exceed the declared 10% time-reduction threshold. This justifies a separately specified, bounded numerical feasibility proof. It does not justify production outlining, a cache, a generic translator predicate, a public contract, an actual attainable saving, or M1 acceptance.

Exact outlining alone regresses the primary 87.49→89.64 ns (+2.4574%, p=.001) and 87.74→89.17 ns (+1.6298%, p=.001). Its fn176 frame is128→136 B, local text5462→4886 B, original log helper479 B/frame0. The oracle caller frame is also136 B; its lookup helper170 B/frame8. All78 original guest bounds sites remain. These static facts accompany the negatives but do not prove causation, a spill count, or a removable cost. RawGuest loses3.086%/2.515% under outlining and gains36.206%/36.167% under the oracle relative to its own baseline, all p=.001; RawGuest omits the checked host boundary. Do not subtract raw/checked means or overlapping profile percentages to invent an additive host floor.

## Process/input and identity audit

Independent audit verifies1,232 raw rows/raw files,19 declared groups,7 rows per case/round,520 current frozen hashes, and176 summary role/round cells from the raw metrics. Every row matches its declared binary, selector, duration, runtime oracle flag and table path; raw text contains its unchanged benchmark row and PASS. Metric-bearing leaves provide462 actual-P1 rows and224 actual-P16 rows. Four fixed-prefix groups have133 rows each at N4,194,304 and N8,388,608. No timed harness source was added. Frozen ordinary Go1.26.8/CGO0/GOAMD64v1/-pgo=off inputs, CPU governor/boost/frequencies and local-tool isolation provenance remain intact. CPU powersave/boost1 are recorded conditions, not fixed frequency or absence of unrelated external work guarantees.

The original scalar and RawGuest selectors run one benchmark goroutine with process/framework GOMAXPROCS16 and -test.cpu16; they do not emit an actual-P1 metric. The Increasing/BroadScalar matched leaves explicitly verify P1. Keep these policies separate when describing the ceiling. Original and RawGuest use values1..N; the long set misses the oracle once at8,388,608. Matched Increasing warms8192 values and then uses8193..N+8192, giving8193 long-set fallbacks. Other guards use500ms/1s adaptive durations; their evolving input prefixes are not necessarily equal, and the broad matched corpora are finite cycles, not nonrepeating application traffic.

Untouched DD ELF reproduces c73daeca03069285b5b26701646ac0c94ece1a80c62c5905eff795324db3d3d0. Outline ELF is5e68bdaea326b3ce7fef9352d21c1ba8a099a503f18fdf4cc1be4d14f8f4adc3. Both oracle roles use bf491aa076c5f80e572404ca22db8ec1395d86b0b99128df103b2a92df191974; only the runtime environment flag differs. All three authored hardener causes regenerated all three proof modules; only DD bytes change. Runtime, generated facades, guest Wasm and compute/streaming modules remain exact production sources. This is not optimization of a generated module alone and still supplies only full-source-pinned diagnostic eligibility.

## Numerical, ownership and memory scope

The64MiB table is67,108,864 LE bytes,8,388,608 exact float64 log bit patterns for integer inputs0..8,388,607, SHA48f45a3568b4ad0862e748c11372f46cc46fe3fcf80236965e11f7990d15314a. It is precomputed offline and read/retained before timing in BOTH oracle modes. False mode executes eligibility then the copied log; true mode looks up covered integers, otherwise uses that same copied log. Positive fractional, negative, nonfinite and out-of-range inputs fall back. Source-exact operations/casts/branches and current sole live-out p17 support semantic equivalence in the pinned region; exhaustive bit equality is against an exact-source reconstruction, not an independently verified logarithm algorithm. Original-Wasm complete state/protobuf/error/lifetime histories and high-prefix boundary/tail samples provide independent caller evidence, not exhaustive Wasm replay of every timed integer.

The multiplier memory load before the replaced region and offset load after it remain in their original positions. All current guest memory accesses/checks, trap precedence, stores/collapse/counter mutations, canonical replies and lifetime policy remain unchanged. Host admission, shared resource ownership/epoch, execution locks, per-call reset/recovery, host panic propagation, reply/status/unit shape, current-memory MaxMemory checks, immediate poison and draining Close are unchanged authored sources. No resource handle, pointer, slice view or instance state is stored in the oracle: it supplies a pure log result only, followed by original guest work.

The table is process-global host storage, outside guest logical MaxMemory and Batch byte accounting, and cannot be advertised as a bounded production cache. ReadFile may allocate capacity beyond the logical64MiB. Zero warmed Go allocations per scalar/batch exclude table setup/retention and do not measure RSS, executable memory or guest heap. Single functional external-time maximum-RSS observations were13,328 KiB baseline,13,876 KiB outline,81,496 KiB false oracle and81,612 KiB true oracle; these are setup context, not repeated memory guarantees or qualified startup performance. Untouched/outline do not allocate the table, so comparisons to them retain GC/cache/power/memory/setup differences. Same-ELF false/true removes source/linkage and equalizes table retention, but does not make the arithmetic difference a separately measured exact log cost.

No representative local private SDK/embedding profile was available. These are synthetic public Datadog payload/corpora and a favorable integer table domain. The table win is an observed counterfactual opportunity, not a general strict upper capacity bound or a claim about that private consumer.

## Guard negatives and limits

Do not waive broad-input/miss losses because the ceiling rule passed. Oracle versus untouched loses negative-bin scalar+2.8665%/+3.4487%, broad scalar+3.4033%/+2.5475%, broad batch+10.148%/+9.5092% and SQL holdout+1.7108%/+1.4909%, all detected in both sets. Varied SQL points lose+1.3473% (p=.058) and+1.5043% (p=.001). Outline itself loses negative bins+2.0734%/+2.1625%, broad batch+3.1175%/+2.7515%, varied SQL+1.0479%/+1.0530% (detected both), broad scalar+.9210% screen only, varied scalar+1.6178% confirmation only, Increasing+1.4954% confirmation only and original SQL+1.2700% confirmation only. The false oracle scaffold costs roughly3% primary scalar and10% batches. Its miss/layout/setup penalties are part of the evidence, not overhead one may silently remove from an expected production gain.

Oracle gains original batch−38.161%/−38.371% and matched repeated1024−37.840%/−38.538%, p=.001 both; against same-ELF false they gain43.742%/43.920% and43.850%/44.168%. Original varied scalar has no detected gain versus untouched, but−5.126%/−5.399% versus false, p=.001. Broad scalar/batch and negative bins do not demonstrate a repeated benefit versus false. SQL/trace observations are not caused by selected log work merely because they occur in the same binary; body identity, process/table context and placement controls limit attribution. Oracle trace−.713% screen (p=.318),−1.444% confirmation (p=.002) is not a repeated payload gain.

All p-values are unadjusted exploratory benchstat comparisons with n7; absence of detection is not equivalence. Full tables below retain point estimates and exact p-values rather than selecting significant favorable cells.

## Fresh reference and M1 context

Fresh independent own locked Rust1.97/O3/own-hardener reference starts from an absent target. Ten actual commands passed; all56 authored sources/copies match before/after/previous. Own package/Wasm/corpus tests and48 functional1x leaves pass. Final Wasm/module/ELF reproduce prior controls8bda5ff7…/5ff25314…/5c4f361a…. These1x values are excluded from qualification. Reference ABI2 borrowed inputs/background contexts/four-instance original facade and original batch/trace workload differences remain; no Cocoon implementation was transplanted.

Fresh fixed-prefix scalar reference55.37/55.18 ns gives110% limits60.907/60.698 ns. Baseline87.49/87.74 and oracle70.26/70.74 exceed both those contextual limits and absolute55.44 ns. Fixed-N diagnostic inputs are not the original adaptive acceptance protocol, so neither favorable SQL medians nor an oracle result may mark M1 accepted. Original SQL baseline2131/2126 ns versus fresh1955/1937 gives contextual110% limits2150.5/2130.7 ns; these baseline points are below those and absolute2215.4 ns, with scope and qualification limits above.

## Streaming brackets

All three streaming ELFs are byte-identical a2076ad9349c334f028e1c73cc166004c15da1debab79e8d2c349d851bc373bf, with four named roles per six P1/P16 lifetime leaves. They do not contain or initialize the DD oracle. Changes are process/context brackets, not numeric-candidate stream gains, regressions, scalar equivalence, or a new topology design. Every adverse median must remain visible: oracle versus baseline P16 one-home Fixed+.1561% screen (p=.902),+.5640% confirm (p=.053); P16 one-home Holdout+.3174%/+.2738%; P16 sixteen-home Fixed+.5306% screen then−1.7784%; sixteen-home Holdout+.8264% screen then−.5149%; P1 Holdout+.5917%/+.1493%. No oracle-versus-baseline streaming comparison detects a change; outline P1 Fixed−.203% confirmation p=.038 is a one-set identical-binary bracket, not an optimization.

These are complete observed New/Write/End/Close stream lifetimes for16KiB at nominalChunk64, with output references retained/disposed in groups32. Fixed streams have256 writes+End,257 outputs,16,392 owned bytes,9 groups and250 Go allocations per stream; holdouts average343.5 writes+End,344.5 outputs,16,390 owned bytes,11 groups and268 allocations. Writes/s excludes End, stream rate includes the full lifecycle, and raw custom metric medians are reported independently (do not derive them from rounded ns/op). One-home serialization and opted-in16-home round-robin run with independent stateless pool1; P1/P16 differ both scheduling and contention. The observed rates below are not strict throughput/RSS/fairness bounds, real injector performance, or isolation of home-lock cost from the rest of the lifecycle.

## Modest next feasibility step

Authorize only a separately written private numerical proof experiment, not a cache or public API implementation: freeze ONE exact current mapping configuration/kernel and attempt conservative certified intervals for the logical integer bin. Specify a small fixed host-storage and construction-work cap before experimenting. First establish whether a useful handful of intervals can be certified cheaply under the exact binary64 operations/branch reduction, affine parameters, floor and saturation; allow an explicit negative result.

A sound certificate must cover every admitted float64 in an interval, using outward bounds/error analysis of the actual operations or another mechanically justified certificate. Checking endpoints, ordinary log monotonicity, sampled original-Wasm agreement or a finite table alone does not prove the rounded translated mapping constant throughout. Retreat/fallback for any uncertified boundary or unsupported parameter/input. Test nextafter neighbors, reduction/normal-subnormal thresholds, signed zero, finite extremes, negative-bin inputs, NaN/Inf/error paths and all actual mapping-parameter identities. Keep candidate certificates local/pure with logical values only, no guest pointer/view/descriptor caching. Any future instance-local mutable memoization needs its own instance/parameter/reset/lifetime proof, rather than inheriting safety from this global pure-log oracle.

Measure certification startup/storage separately and cap it; measure realistic lookup hit AND miss costs, nearby-unique/broad/mostly-unique/phase-hot-cold inputs, per-instance churn, scalar+batches, all existing guard matrices, and complete Count/protobuf state histories. Preserve original memory reads, checks and ordered updates even if membership succeeds. Start with an ignored pure proof helper and untouched/matching-scaffold controls, then decide whether its attainable full checked-call ceiling merits any production specification. If storage, construction cost, coverage or misses fail, park the approach. The old exact-value cache miss losses and this round's broad losses are explicit constraints, not permission to claim a working range cache from a perfect-log table.

The translator-noopt alternate hypothesis and corrected historical wasm2go-version/cache failure remain in unchanged host-entry.md for future optional investigation; no such experiment ran in this round.

## Complete diagnostic comparisons

Time medians are ns/op; delta/p is each role versus untouched baseline. Reference medians are shown for context only.

### screen

| Workload | Baseline | Outline (delta; p) | False oracle (delta; p) | True oracle (delta; p) | Reference |
|---|---:|---:|---:|---:|---:|
| Original-ObfuscateSQL | 2131 | 2150 (+0.8916%; 0.209) | 2118 (-0.6100%; 0.165) | 2123 (-0.3754%; 0.222) | 1955 |
| Original-SketchAdd-FixedN | 87.49 | 89.64 (+2.4574%; 0.001) | 90.43 (+3.3604%; 0.001) | 70.26 (-19.6937%; 0.001) | 55.37 |
| Original-SketchAddMany1k | 38159 | 38249 (+0.2359%; 0.620) | 41944 (+9.9190%; 0.001) | 23597 (-38.1614%; 0.001) | 35458 |
| Original-ObfuscateTraces1k | 2.57546e+06 | 2.55138e+06 (-0.9351%; 0.209) | 2.56797e+06 (-0.2909%; 0.902) | 2.55708e+06 (-0.7134%; 0.318) | 2.02786e+06 |
| Original-SketchAddVaried | 89.47 | 89.99 (+0.5812%; 0.334) | 93.06 (+4.0125%; 0.016) | 88.29 (-1.3189%; 0.363) | 55.39 |
| Original-ObfuscateSQLVaried | 2672 | 2700 (+1.0479%; 0.017) | 2699 (+1.0105%; 0.028) | 2708 (+1.3473%; 0.058) | 2496 |
| Original-SketchAddNegativeBins | 88.26 | 90.09 (+2.0734%; 0.001) | 91.33 (+3.4784%; 0.001) | 90.79 (+2.8665%; 0.001) | 55.38 |
| MatchedReference-SQLHoldout | 5436 | 5450 (+0.2575%; 0.383) | 5539 (+1.8948%; 0.001) | 5529 (+1.7108%; 0.004) | 5085 |
| MatchedReference-Increasing-FixedN | 89.36 | 90.23 (+0.9736%; 0.435) | 93.25 (+4.3532%; 0.026) | 73.93 (-17.2672%; 0.001) | 56.49 |
| MatchedReference-BroadScalar-FixedN | 89.03 | 89.85 (+0.9210%; 0.001) | 91.84 (+3.1562%; 0.001) | 92.06 (+3.4033%; 0.001) | 57.53 |
| MatchedReference-Repeated1024 | 38776 | 38988 (+0.5467%; 0.209) | 42926 (+10.7025%; 0.017) | 24103 (-37.8404%; 0.001) | 36328 |
| MatchedReference-BroadBatch8192 | 312656 | 322403 (+3.1175%; 0.001) | 343507 (+9.8674%; 0.001) | 344384 (+10.1479%; 0.001) | 296892 |
| RawGuest-SketchAdd-FixedN | 53.14 | 54.78 (+3.0862%; 0.001) | 56.58 (+6.4735%; 0.001) | 33.9 (-36.2062%; 0.001) | — |
| StreamOneHome-Fixed | 189002 | 188991 (-0.0058%; 0.456) | 188490 (-0.2709%; 0.209) | 189297 (+0.1561%; 0.902) | — |
| Stream16Homes-Fixed | 25442 | 24965 (-1.8749%; 0.710) | 24987 (-1.7884%; 0.710) | 25577 (+0.5306%; 0.805) | — |
| StreamOneHome-Holdout | 226861 | 228277 (+0.6242%; 0.165) | 227618 (+0.3337%; 0.259) | 227581 (+0.3174%; 0.456) | — |
| Stream16Homes-Holdout | 33033 | 32863 (-0.5146%; 0.902) | 33224 (+0.5782%; 0.259) | 33306 (+0.8264%; 0.383) | — |
| StreamP1-OneHome-Fixed | 160594 | 161122 (+0.3288%; 0.832) | 159985 (-0.3792%; 0.097) | 160528 (-0.0411%; 0.902) | — |
| StreamP1-OneHome-Holdout | 196714 | 197707 (+0.5048%; 0.209) | 198014 (+0.6609%; 0.259) | 197878 (+0.5917%; 0.128) | — |

True oracle versus the identical false-flag ELF:

| Workload | Delta time | p |
|---|---:|---:|
| Original-ObfuscateSQL | +0.2361% | 0.710 |
| Original-SketchAdd-FixedN | -22.3045% | 0.001 |
| Original-SketchAddMany1k | -43.7417% | 0.001 |
| Original-ObfuscateTraces1k | -0.4237% | 0.456 |
| Original-SketchAddVaried | -5.1257% | 0.001 |
| Original-ObfuscateSQLVaried | +0.3335% | 0.902 |
| Original-SketchAddNegativeBins | -0.5913% | 0.221 |
| MatchedReference-SQLHoldout | -0.1805% | 0.456 |
| MatchedReference-Increasing-FixedN | -20.7185% | 0.001 |
| MatchedReference-BroadScalar-FixedN | +0.2395% | 0.805 |
| MatchedReference-Repeated1024 | -43.8499% | 0.001 |
| MatchedReference-BroadBatch8192 | +0.2553% | 0.097 |
| RawGuest-SketchAdd-FixedN | -40.0848% | 0.001 |
| StreamOneHome-Fixed | +0.4281% | 0.097 |
| Stream16Homes-Fixed | +2.3612% | 0.902 |
| StreamOneHome-Holdout | -0.0163% | 0.710 |
| Stream16Homes-Holdout | +0.2468% | 0.902 |
| StreamP1-OneHome-Fixed | +0.3394% | 0.053 |
| StreamP1-OneHome-Holdout | -0.0687% | 0.710 |

### confirm

| Workload | Baseline | Outline (delta; p) | False oracle (delta; p) | True oracle (delta; p) | Reference |
|---|---:|---:|---:|---:|---:|
| Original-ObfuscateSQL | 2126 | 2153 (+1.2700%; 0.024) | 2106 (-0.9407%; 0.035) | 2113 (-0.6115%; 0.198) | 1937 |
| Original-SketchAdd-FixedN | 87.74 | 89.17 (+1.6298%; 0.001) | 90.37 (+2.9975%; 0.001) | 70.74 (-19.3754%; 0.001) | 55.18 |
| Original-SketchAddMany1k | 37990 | 37923 (-0.1764%; 0.456) | 41749 (+9.8947%; 0.001) | 23413 (-38.3706%; 0.001) | 35421 |
| Original-ObfuscateTraces1k | 2.54512e+06 | 2.5357e+06 (-0.3702%; 0.902) | 2.5e+06 (-1.7727%; 0.097) | 2.50837e+06 (-1.4439%; 0.002) | 2.01734e+06 |
| Original-SketchAddVaried | 88.39 | 89.82 (+1.6178%; 0.001) | 93.17 (+5.4079%; 0.001) | 88.14 (-0.2828%; 0.119) | 55.42 |
| Original-ObfuscateSQLVaried | 2659 | 2687 (+1.0530%; 0.002) | 2682 (+0.8650%; 0.004) | 2699 (+1.5043%; 0.001) | 2492 |
| Original-SketchAddNegativeBins | 87.86 | 89.76 (+2.1625%; 0.001) | 90.87 (+3.4259%; 0.001) | 90.89 (+3.4487%; 0.001) | 55.41 |
| MatchedReference-SQLHoldout | 5433 | 5438 (+0.0920%; 0.402) | 5527 (+1.7302%; 0.001) | 5514 (+1.4909%; 0.001) | 5021 |
| MatchedReference-Increasing-FixedN | 88.94 | 90.27 (+1.4954%; 0.001) | 93.34 (+4.9472%; 0.001) | 74.05 (-16.7416%; 0.001) | 56.5 |
| MatchedReference-BroadScalar-FixedN | 89.5 | 89.59 (+0.1006%; 0.175) | 92.38 (+3.2179%; 0.001) | 91.78 (+2.5475%; 0.001) | 57.52 |
| MatchedReference-Repeated1024 | 38964 | 38871 (-0.2387%; 0.902) | 42893 (+10.0837%; 0.001) | 23948 (-38.5381%; 0.001) | 36291 |
| MatchedReference-BroadBatch8192 | 313865 | 322501 (+2.7515%; 0.001) | 343693 (+9.5034%; 0.001) | 343709 (+9.5085%; 0.001) | 297367 |
| RawGuest-SketchAdd-FixedN | 53.28 | 54.62 (+2.5150%; 0.001) | 57.18 (+7.3198%; 0.001) | 34.01 (-36.1674%; 0.001) | — |
| StreamOneHome-Fixed | 189172 | 188894 (-0.1470%; 0.318) | 189142 (-0.0159%; 0.710) | 190239 (+0.5640%; 0.053) | — |
| Stream16Homes-Fixed | 25472 | 25423 (-0.1924%; 1.000) | 25407 (-0.2552%; 1.000) | 25019 (-1.7784%; 0.383) | — |
| StreamOneHome-Holdout | 226842 | 227270 (+0.1887%; 0.318) | 227569 (+0.3205%; 0.259) | 227463 (+0.2738%; 0.902) | — |
| Stream16Homes-Holdout | 32820 | 33048 (+0.6947%; 0.620) | 32935 (+0.3504%; 0.710) | 32651 (-0.5149%; 1.000) | — |
| StreamP1-OneHome-Fixed | 159400 | 159077 (-0.2026%; 0.038) | 159403 (+0.0019%; 0.383) | 159316 (-0.0527%; 0.902) | — |
| StreamP1-OneHome-Holdout | 197645 | 196696 (-0.4802%; 0.535) | 197332 (-0.1584%; 0.902) | 197940 (+0.1493%; 0.902) | — |

True oracle versus the identical false-flag ELF:

| Workload | Delta time | p |
|---|---:|---:|
| Original-ObfuscateSQL | +0.3324% | 0.240 |
| Original-SketchAdd-FixedN | -21.7218% | 0.001 |
| Original-SketchAddMany1k | -43.9196% | 0.001 |
| Original-ObfuscateTraces1k | +0.3347% | 0.710 |
| Original-SketchAddVaried | -5.3987% | 0.001 |
| Original-ObfuscateSQLVaried | +0.6339% | 0.172 |
| Original-SketchAddNegativeBins | +0.0220% | 0.971 |
| MatchedReference-SQLHoldout | -0.2352% | 0.646 |
| MatchedReference-Increasing-FixedN | -20.6664% | 0.001 |
| MatchedReference-BroadScalar-FixedN | -0.6495% | 0.128 |
| MatchedReference-Repeated1024 | -44.1680% | 0.001 |
| MatchedReference-BroadBatch8192 | +0.0047% | 0.710 |
| RawGuest-SketchAdd-FixedN | -40.5212% | 0.001 |
| StreamOneHome-Fixed | +0.5800% | 0.073 |
| Stream16Homes-Fixed | -1.5271% | 0.318 |
| StreamOneHome-Holdout | -0.0466% | 0.259 |
| Stream16Homes-Holdout | -0.8623% | 0.383 |
| StreamP1-OneHome-Fixed | -0.0546% | 0.710 |
| StreamP1-OneHome-Holdout | +0.3081% | 0.620 |

## Streaming raw-rate medians

Each cell is raw writes/s; raw streams/s. All four role medians retained.

### screen

| Workload | Baseline | Outline | False | True |
|---|---:|---:|---:|---:|
| StreamOneHome-Fixed | 1,354,485; 5,291 | 1,354,562; 5,291 | 1,358,164; 5,305 | 1,352,373; 5,283 |
| Stream16Homes-Fixed | 10,062,211; 39,306 | 10,254,255; 40,056 | 10,245,431; 40,021 | 10,009,136; 39,098 |
| StreamOneHome-Holdout | 1,514,144; 4,408 | 1,504,751; 4,381 | 1,509,107; 4,393 | 1,509,350; 4,394 |
| Stream16Homes-Holdout | 10,398,785; 30,273 | 10,452,451; 30,429 | 10,338,883; 30,099 | 10,313,381; 30,024 |
| StreamP1-OneHome-Fixed | 1,594,080; 6,227 | 1,588,855; 6,206 | 1,600,147; 6,251 | 1,594,736; 6,229 |
| StreamP1-OneHome-Holdout | 1,746,190; 5,084 | 1,737,419; 5,058 | 1,734,727; 5,050 | 1,735,919; 5,054 |

### confirm

| Workload | Baseline | Outline | False | True |
|---|---:|---:|---:|---:|
| StreamOneHome-Fixed | 1,353,262; 5,286 | 1,355,254; 5,294 | 1,353,480; 5,287 | 1,345,675; 5,257 |
| Stream16Homes-Fixed | 10,050,428; 39,259 | 10,069,793; 39,335 | 10,075,864; 39,359 | 10,232,145; 39,969 |
| StreamOneHome-Holdout | 1,514,270; 4,408 | 1,511,418; 4,400 | 1,509,434; 4,394 | 1,510,131; 4,396 |
| Stream16Homes-Holdout | 10,466,220; 30,469 | 10,394,013; 30,259 | 10,429,586; 30,363 | 10,520,217; 30,627 |
| StreamP1-OneHome-Fixed | 1,606,022; 6,274 | 1,609,285; 6,286 | 1,605,996; 6,273 | 1,606,874; 6,277 |
| StreamP1-OneHome-Holdout | 1,737,961; 5,060 | 1,746,347; 5,084 | 1,740,723; 5,068 | 1,735,375; 5,052 |
