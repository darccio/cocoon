# Adversarial final documentation review

Disposition: APPROVE retaining evidence/documentation only, subject to the separately requested final archive identity audit and root's exact-stage validation. No numerical, proof-scope, promotion-policy, quality-scope or public-contract blocker remains in the reviewed prose. This reviewer did no builds/tests/lints/profiles/benchmarks or tracked edits.

Reviewed docs/performance.md's new structural scalar section, changed roadmap paragraphs and archive-summary.md against the previously independently verified1,232raw rows/176seven-sample cells, summary/aliases/benchstat, frozen source/proof/table/control identities and completed quality provenance. The readable archive and compressed bundle do not exist at this review point; their identity/member/exclusion completeness is a subsequent audit, not claimed here.

All19time-table rows match exact baseline/oracle medians, rounded delta percentages and reported exploratory p-values. The same-ELF disabled-control comparisons preserve raw estimates and p-values; scalar vsuntouched19.69/19.38%TIME and vsfalse22.30/21.72%,allp=.001, meet the explicit >=10%median TIME AND p<.05 rule for both comparators/both fixedNsets. Text correctly treats this as an unsupported avoided-computation diagnostic sufficient only to justify separately specified bounded feasibility work. It does not promote the64MiB table, pure-outline shape, interval cache or generic private/public transform. Type-I/multiplicity limits remain explicit through exploratory unadjustedp-values, no selected retiming, preserved samples, non-detection not equivalence and confirmation oracle/reference +/-14%intervals.

Primary and guard negatives remain visible: pure-outline repeatedscalar/raw/negativebins/variedSQL/broadbatch regressions plus confirmationIncreasing/SQL/variedscalar and screeningBroadScalar; disabledcontrol repeatedcosts across scalar/originalbatch/negative/broadscalar/broadbatch/SQLholdout plus variedscalar/Increasing/rawGuest/variedSQL. Enabled miss-heavy negativebins+2.87/+3.45%, broadscalar+3.40/+2.55%, broadbatch+10.15/+9.51%, SQLholdout+1.71/+1.49% repeat against untouched. VariedSQL's+.058screeningp and confirmed+.001loss remain in the table. Miss comparisons being undetected against disabled limit attribution, not regressions versusproduction or fallback costs. The trace confirmation-only baseline gain lacks same-ELF corroboration and is not claimed as a log-driven repeat win.

The scope distinction is accurate: exact original-current source/kernel/liveness, every8Mtable/wrapper entry and1,764edgebit checks; six COMPLETE FINITE originalWasmCount/protobuf/state/error histories including16Kprefix/high4M/8Mboundary tails; NO full4M/8MWasmreplay or independently exported/intermediate ln arithmetic. RawGuest validates full timedGoCount, bare originalscalar remains unchanged. Four mutants compile and fail runtime assertions on actual nativeamd64/386. No generic interval proof, realbigendian execution or arbitrary continuous membership is asserted. The next private feasibility work requires exact current rounded pipeline membership/fallback and parameter/read/check/state/lifetime barriers; endpoints and mathematical monotonicity alone are rejected.

Memory/setup scope is precise: table64MiBlogicalhostbytes/8Mentries, exactSHA48f45a..., offline generation and sameELFfalse/true file/load/init/retention; no millions-of-kernel evaluations in measuredprocesses. Baseline/outline lack the allocation, so startup/GC/cache/power/linking confounds remain. Four single-process1xRSSobservations use actualKiB values13328/13876/81496/81612, not qualified RSS/isolatedguest/peropmemory. Source/table-generator/officialtoolchain/overlays/commandrecords permit reproduction; archive-summary explicitly omits table.bin and executables/redundantreference module, retaining exacthashes and source/build recipes. Added explicit table reproduction uses new/tmpoutput names and adapts absoluteoverlaypaths, preserving archivedexclusive-openlogs. Compressed artifact availability/hash/member contents are still pending.

Framework/actualprocs counts match the matrix462P1metricrows+224P16metricrows+546unchangedoriginal/rawframeworkP16=1232. FourFixedNdiagnostics useN4,194,304and8,388,608matchedprefixes per role/set, with original1longfallback and warmedIncreasing8193. DifferentNsets are not identical evolving states. FixedN does not replace adaptive M1 acceptance or predict the absent representative privateSDK. Reused profile source/ELF identity is explicit and not relabelled fresh, removable or additive. Fresh own-reference semantics/compiled-path differences remain contextual.

Allstreamroles run identicalELF bytes and are environmental brackets. Oracle baseline/false comparisons are allundetected; adverseP16onehomefixed+.16/+.56%,p.053confirmation staysvisible. Confirmation-only outline-labelledP1Fixed-.20%,p.038 is runvariation, not a source gain. Allsixreportedbaseline write rates match raw custommetric medians. Write-only numerator excludesEnd and complete16KiBNew/Write/End/Close denominator is now explicit; Open/warmup/oraclesuntimed. Rates are workloadobservations rather than strictcapacity/causalguest/session/scalar equivalence.

M1 remains unaccepted. Even hypothetical70.74ns exceeds55.44absolute and60.698fixed-prefix fresh-referencecontextualcap. Unchanged adaptiveSQL2126ns narrowly belowcurrentcaps is not attributed to this optimization or overallacceptance. Production/generatedartifacts/locks and publicABI/API/schema remain unchanged. Roadmap preserves previousnogos while making boundedcertification/measurement the nextproof question, with publiccontractapproval still mandatory.

Independently checked all15quality/reproductioncommandrecords/logs exit0 and strictsequentialtimestamps after timing: sevenmakecommands plus twoall3proof/runtime repetitions. proof-before.json==proof-after.json for61fingerprints. Final wording explicitly says makegates qualify UNCHANGEDPRODUCTION, while ignoreddiagnostic overlays get separateactualmode fixture/runtime/nativeproofs and are not production-qualified by those gates. Go1.26.8officialcheck/pinnedlint2.13.1 and system1.27.2otherGo/Rust1.97/Binaryen133 labels are accurate. Exactstage/darna/signature work follows packaging; those futurelogs are not self-embedded or claimed complete by this audit.

Archive links and roadmap section anchor use the intended structural-scalar filenames/heading; no stale production-retention or acceptance claim remains. Future archive audit must verify immutable raw/code/proof/reference/manifest bytes and declaredomissions, not execute archived scripts.

Reviewed identities:

```json
{
  "docs/performance.md": "b18834c085a39fac4d1a33633b56f04966e66f1820d600bfc32cca4355fae6c4",
  "docs/roadmap.md": "dd2124c6d58a73635f99de94770369514bdc085b0a130f515ba339259c871091",
  "archive-summary.md": "05f98ef6202b83a651243edc020a86d21888da1734f72ae3098349d9b16e8aa0",
  "qualification-command-records.json": "aed5240c7118ca2d079217f0f953bd096fdc985ca7d9eea2e76c62c6aabd64e1",
  "proof-before.json": "631fd913881463db507451cdfd8fd6cc78b4b9b999c359c20d4ffbb90bf056af",
  "proof-after.json": "631fd913881463db507451cdfd8fd6cc78b4b9b999c359c20d4ffbb90bf056af",
  "adversarial-results.md": "e163855e835e9c6d6d556835dbb4476cb2a0a6c5fab5251609cf7cadd4a88eae"
}
```
