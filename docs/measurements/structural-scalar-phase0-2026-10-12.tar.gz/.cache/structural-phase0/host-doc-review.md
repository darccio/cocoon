# Host documentation review: structural scalar phase0

Read-only review of docs/performance.md top structural section, docs/roadmap.md structural resume/track2 note, and archive-summary.md before packaging. Only this ignored review note was written. No build, test, benchmark, profiler or tracked edit.

Verdict: no measurement, host-contract or public-scope blocker. Approve evidence-only retention after the two small wording/reproduction clarifications below. No production outline, oracle table/cache, generic interval predicate, public ABI/API contract or M1 acceptance is approved.

The four primary median/p=.001 claims match the independently audited summary/raw rows: original fixedN87.49→70.26 /87.74→70.74 ns and same-ELF false90.43→70.26 /90.37→70.74. Complete enabled outcomes and secondary false/true p-values match all19 groups. The repeated broad/negative-bin/batch/SQL-holdout losses are prominent; outline scalar/raw/negative/variedSQL/broadBatch losses and caller128→136B frame growth are retained. The archive will preserve all omitted control comparisons and raw allocations. FixedN and adaptive acceptance remain separate; fresh reference/absolute scalar limits are accurate and M1 stays unaccepted.

Matrix identity and units are accurate:1232 rows,520 hashes,462 actualP1/224 actualP16 and546 unchanged frameworkP16 rows; fixed iteration counts/input coverage and long fallback counts; exact officialGo1.26.8 CGO0PGOoff; seven alternating500ms/reversed1s sets except fixedN. Baseline ordinary ELF reproduces old profile identity; no fresh-profile or additive cost-floor claim. No representative private SDK profile is claimed; local original external workspaces are absent. Runtime/facade/Wasm/compute/stream bytes and original ABI3 ownership/reset/memory/reply/poison/epoch/drain policy are unchanged. All318 existing contained-load sites and78 fn176 bounds sites remain.

The64MiB table is exactly67108864LE bytes/8388608 entries with recorded48f45a35… hash, loaded equally before timing in one ELF for both flags. It is global host storage outside per-call guest MaxMemory; per-operation allocations exclude retained setup. Original/outline allocation/setup confounds and single functional maxRSS scope are explicit. Exact source reconstruction, arbitrary-f64 edge coverage, finite original-Wasm state/protobuf histories and4M/8M replay limitations are correctly distinguished from a continuum certificate. No endpoint/assumed mathematical-monotonicity shortcut is approved. Next private proof specification precedes its implementation; new public contracts require operator approval.

Streaming uses one identical ELF and six full-lifetime leaves. Rates are raw observed complete-lifecycle write/stream metrics, not strict ceilings, per-write latency, cause-specific home-lock estimates, ABI equality or real-payload results. Adverse+.56% one-home Fixed confirmation p=.053 and outline-only−.20% P1 confirmation p=.038 are retained; oracle comparisons versus untouched/false are all undetected. P1/P16 one/16-home rates match the raw custom medians; nondetection remains nonequivalence.

I read seven gate log exits and qualification-command-records.json: all zero, all after paired completion. Two compute/DD/stream/runtime repeat command sets also exited0, and61 before/after fingerprints compare exactly. Go1.26.8 check/pinned2.13.1/49-linter wording and other-gatesGo1.27.2/Rust1.97/Binaryen133 are consistent with records. Native386 proof is executed, cross compilation does not imply native target performance. Staged snapshot/commit verification remains an upcoming step outside self-embedded evidence.

## Requested clarifications before packaging

1. In performance prose, qualify the statement “Streaming comparisons versus baseline and disabled are all undetected” as “Oracle streaming comparisons …”. The unqualified wording could include outlining, whose following sentence reports p=.038. The existing next sentence makes the intent recoverable, so this is clarity rather than evidence invalidation.
2. In the readable archive summary, add direct reproduction argv/env (or an exact pointer to table-generator-records.json) for the omitted table. Calling table-generator.py in an extracted evidence tree fails its exclusive existing-log opens. Do not tell readers to delete original archived logs. Build the generator with the recorded officialGo test -pgo=off -c overlay argv, then run the recorded TestPhase0WriteLogOracle command with the output env, and verify length67108864 and SHA48f45a3568b4ad0862e748c11372f46cc46fe3fcf80236965e11f7990d15314a. These are reproduction instructions only; no regeneration was executed during review. Absolute overlay paths need the recorded repository path or explicit path adaptation in a separate reproduction workspace.

Example direct commands from the recorded build/run inputs, run from the restored frozen repository with the archived overlay/source present (do not execute while measuring):

```sh
GOTOOLCHAIN=local CGO_ENABLED=0 GOAMD64=v1 GOCACHE="$PWD/.cache/go" GOFLAGS=-buildvcs=false \
  .cache/toolchains/go1.26.8/go/bin/go test -pgo=off -c \
  -overlay="$PWD/.cache/structural-phase0/table-generator-overlay.json" \
  -o="$PWD/.cache/structural-phase0/table-generator.test" \
  ./examples/datadog/go/dd/internal/wasm
COCOON_PHASE0_CREATE_LOG_ORACLE_OUTPUT="$PWD/.cache/structural-phase0/table.bin" \
  .cache/structural-phase0/table-generator.test \
  '-test.run=^TestPhase0WriteLogOracle$' -test.v
sha256sum .cache/structural-phase0/table.bin
```

All correct numerical claims above remain valid before those wording changes. No tracked changes or publication performed by this reviewer.

## Reviewed bytes

```json
{
  "docs/performance.md": "8e99b2fa307632a24a3978aa409a1a4c689599a2c83dcd545454d59012b49884",
  "docs/roadmap.md": "03b581e463c4ed1c78c3c18eaa040ded7657bc788f7f126c19d47a033042a2d6",
  ".cache/structural-phase0/archive-summary.md": "c571caf0b4b8fc6352d08f65b08c56c271e2f87ba9ce4b78004a2f0439774633"
}
```
