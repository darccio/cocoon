"""Freeze reviewed role identities and sources; never compile or benchmark."""
from pathlib import Path
import argparse
import datetime
import json
import os
import platform
import subprocess

from common import DIRECTORY, ENV_KEYS, ROOT, cpu_policy, digest, path, validate_plan


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("config", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    config_file = args.config.resolve()
    config = json.loads(config_file.read_text())
    plan_file = path(config["plan"])
    plan = json.loads(plan_file.read_text())
    validate_plan(plan)
    pinned = config["production_sha256"]
    for filename, expected in pinned.items():
        assert digest(path(filename)) == expected, "pinned same-Wasm production input changed: " + filename
    selected = {case["binary"] for group in plan["comparisons"] for case in group["cases"]}
    assert selected == set(config["binaries"]) == set(config["build_records"])
    files = {config_file, plan_file, *(DIRECTORY / name for name in ("common.py", "freeze.py", "paired.py", "summarize.py"))}
    files.update(path(value) for value in config["artifacts"])
    files.update(path(value) for value in config["binaries"].values())
    for filename in tuple(files):
        if filename.suffix == ".json":
            metadata = json.loads(filename.read_text())
            if isinstance(metadata, dict) and "Replace" in metadata:
                assert isinstance(metadata["Replace"], dict)
                files.update(path(value) for value in metadata["Replace"].values() if value)
    for record in config["build_records"].values():
        assert set(record) >= {"command", "cwd", "source_identity"}
        encoded = json.dumps(record)
        assert "FILL" not in encoded and "-pgo=off" in encoded

    baseline_harness, added_harness = {}, {}
    allowed = set(config.get("added_harness", []))
    for directory in ("examples/datadog/go/dd", "testdata/streaming/go/streaming"):
        for filename in sorted(path(directory).glob("*bench_test.go")):
            relative = str(filename.relative_to(ROOT))
            prior = subprocess.run(["git", "show", plan["baseline_revision"] + ":" + relative], cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            if prior.returncode:
                assert relative in allowed, f"undeclared added harness: {relative}"
                added_harness[relative] = digest(filename)
            else:
                assert prior.stdout == filename.read_bytes(), f"existing harness changed: {relative}"
                baseline_harness[relative] = digest(filename)
            files.add(filename)
    assert set(added_harness) == allowed
    for directory in ("rt", "internal/harden", "cocoontest", "examples/datadog/go/dd", "testdata/compute/go/compute", "testdata/streaming/go/streaming"):
        files.update(path(directory).rglob("*.go"))
    assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=ROOT).strip(), "freeze clean authored production and ignored phase-zero overlays"
    build_info = {}
    for role, value in config["binaries"].items():
        info = subprocess.check_output([plan["measurement_go"], "version", "-m", str(path(value))], text=True)
        for required in (plan["measurement_go_version"], "CGO_ENABLED=0", "GOARCH=amd64", "GOOS=linux", "GOAMD64=v1"):
            assert required in info, (role, required, info)
        build_info[role] = info
    snapshot = {
        "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
        "git_status": subprocess.check_output(["git", "status", "--short"], cwd=ROOT, text=True),
        "platform": platform.platform(), "uname": list(platform.uname()),
        "affinity": sorted(os.sched_getaffinity(0)), "cpuinfo": Path("/proc/cpuinfo").read_text(),
        "cpu_policy": cpu_policy(), "cpu_frequencies": cpu_policy(include_frequencies=True),
        "go_version": subprocess.check_output([plan["measurement_go"], "version"], text=True).strip(),
        "build_info": build_info, "config": config, "plan": plan, "pinned_production": pinned,
        "baseline_harness": baseline_harness, "added_harness": added_harness,
        "inherited_environment": {key: os.environ.get(key, "default") for key in ENV_KEYS},
        "sha256": {str(filename.resolve()): digest(filename) for filename in sorted(files)},
        "notes": "Freeze performs no builds/timings. Unchanged authored production baseline plus ignored whole-source-pinned authored hardener postpass and regenerated module overlays; no production candidate implemented. Originalbenchmarkharness unchanged. Explicit PGO-off requires recorded argv; build info does not establish every flag. External process isolation is independently required.",
    }
    with args.output.open("x") as output:
        json.dump(snapshot, output, indent=2)
        output.write("\n")
    print("Frozen", len(files), "files; no builds or benchmarks run.")


if __name__ == "__main__":
    main()
