TEXT dario.cat/cocoon/rt.(*Call).Range(SB) /home/dario/Code/cocoon/rt/instance.go
  instance.go:321	0x5c7de0		493b6610		CMPQ SP, 0x10(R14)							
  instance.go:321	0x5c7de4		0f86a3000000		JBE 0x5c7e8d								
  instance.go:321	0x5c7dea		55			PUSHQ BP								
  instance.go:321	0x5c7deb		4889e5			MOVQ SP, BP								
  instance.go:321	0x5c7dee		4883ec20		SUBQ $0x20, SP								
  instance.go:72	0x5c7df2		895c2438		MOVL BX, 0x38(SP)							
  instance.go:72	0x5c7df6		894c243c		MOVL CX, 0x3c(SP)							
  instance.go:322	0x5c7dfa		488b08			MOVQ 0(AX), CX								
  instance.go:322	0x5c7dfd		488b11			MOVQ 0(CX), DX								
  instance.go:322	0x5c7e00		488b4108		MOVQ 0x8(CX), AX							
  instance.go:322	0x5c7e04		488b4a20		MOVQ 0x20(DX), CX							
  instance.go:322	0x5c7e08		ffd1			CALL CX									
  instance.go:71	0x5c7e0a		8b4c2438		MOVL 0x38(SP), CX							
  instance.go:71	0x5c7e0e		89ca			MOVL CX, DX								
  instance.go:71	0x5c7e10		8b74243c		MOVL 0x3c(SP), SI							
  instance.go:71	0x5c7e14		89f6			MOVL SI, SI								
  instance.go:71	0x5c7e16		4801f2			ADDQ SI, DX								
  instance.go:72	0x5c7e19		4839d3			CMPQ BX, DX								
  instance.go:72	0x5c7e1c		721d			JB 0x5c7e3b								
  instance.go:75	0x5c7e1e		4189c8			MOVL CX, R8								
  instance.go:75	0x5c7e21		4c29c2			SUBQ R8, DX								
  instance.go:75	0x5c7e24		4989d1			MOVQ DX, R9								
  instance.go:75	0x5c7e27		48f7da			NEGQ DX									
  instance.go:75	0x5c7e2a		48c1fa3f		SARQ $0x3f, DX								
  instance.go:75	0x5c7e2e		4921d0			ANDQ DX, R8								
  instance.go:75	0x5c7e31		4a8d1400		LEAQ 0(AX)(R8*1), DX							
  instance.go:75	0x5c7e35		31c0			XORL AX, AX								
  instance.go:75	0x5c7e37		31c9			XORL CX, CX								
  instance.go:322	0x5c7e39		eb3d			JMP 0x5c7e78								
  instance.go:71	0x5c7e3b		4889542418		MOVQ DX, 0x18(SP)							
  instance.go:322	0x5c7e40		48895c2410		MOVQ BX, 0x10(SP)							
  instance.go:73	0x5c7e45		488d0554942c00		LEAQ 0x2c9454(IP), AX							
  instance.go:73	0x5c7e4c		e8cfa3e5ff		CALL runtime.newobject(SB)						
  instance.go:73	0x5c7e51		8b4c2438		MOVL 0x38(SP), CX							
  instance.go:73	0x5c7e55		894810			MOVL CX, 0x10(AX)							
  instance.go:73	0x5c7e58		488b4c2418		MOVQ 0x18(SP), CX							
  instance.go:73	0x5c7e5d		488908			MOVQ CX, 0(AX)								
  instance.go:73	0x5c7e60		488b4c2410		MOVQ 0x10(SP), CX							
  instance.go:73	0x5c7e65		48894808		MOVQ CX, 0x8(AX)							
  instance.go:73	0x5c7e69		4531c9			XORL R9, R9								
  instance.go:73	0x5c7e6c		31d2			XORL DX, DX								
  instance.go:322	0x5c7e6e		4889c1			MOVQ AX, CX								
  instance.go:322	0x5c7e71		488d0568d63300		LEAQ go:itab.*dario.cat/cocoon/rt.memoryRangeError,error(SB), AX	
  instance.go:322	0x5c7e78		4c89cb			MOVQ R9, BX								
  instance.go:322	0x5c7e7b		4889c7			MOVQ AX, DI								
  instance.go:322	0x5c7e7e		4889ce			MOVQ CX, SI								
  instance.go:322	0x5c7e81		4889d0			MOVQ DX, AX								
  instance.go:322	0x5c7e84		4889d9			MOVQ BX, CX								
  instance.go:322	0x5c7e87		4883c420		ADDQ $0x20, SP								
  instance.go:322	0x5c7e8b		5d			POPQ BP									
  instance.go:322	0x5c7e8c		c3			RET									
  instance.go:321	0x5c7e8d		4889442408		MOVQ AX, 0x8(SP)							
  instance.go:321	0x5c7e92		895c2410		MOVL BX, 0x10(SP)							
  instance.go:321	0x5c7e96		894c2414		MOVL CX, 0x14(SP)							
  instance.go:321	0x5c7e9a		e8016eecff		CALL runtime.morestack_noctxt.abi0(SB)					
  instance.go:321	0x5c7e9f		488b442408		MOVQ 0x8(SP), AX							
  instance.go:321	0x5c7ea4		8b5c2410		MOVL 0x10(SP), BX							
  instance.go:321	0x5c7ea8		8b4c2414		MOVL 0x14(SP), CX							
  instance.go:321	0x5c7eac		e92fffffff		JMP dario.cat/cocoon/rt.(*Call).Range(SB)				
