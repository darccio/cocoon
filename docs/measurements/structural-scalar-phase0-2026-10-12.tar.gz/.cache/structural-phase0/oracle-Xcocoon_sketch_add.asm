TEXT dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).Xcocoon_sketch_add(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/internal/wasm/module.go
  module.go:48403	0x656500		493b6610		CMPQ SP, 0x10(R14)										
  module.go:48403	0x656504		0f86880b0000		JBE 0x657092											
  module.go:48403	0x65650a		55			PUSHQ BP											
  module.go:48403	0x65650b		4889e5			MOVQ SP, BP											
  module.go:48403	0x65650e		4883ec70		SUBQ $0x70, SP											
  module.go:48406	0x656512		8b5050			MOVL 0x50(AX), DX										
  module.go:48407	0x656515		448d42f0		LEAL -0x10(DX), R8										
  module.go:48408	0x656519		44894050		MOVL R8, 0x50(AX)										
  module.go:48409	0x65651d		4c8b4838		MOVQ 0x38(AX), R9										
  module.go:48409	0x656521		4981f9b0cf1000		CMPQ R9, $0x10cfb0										
  module.go:48409	0x656528		0f86570b0000		JBE 0x657085											
  module.go:48409	0x65652e		4889842480000000	MOVQ AX, 0x80(SP)										
  module.go:48409	0x656536		f20f11842490000000	MOVSD_XMM X0, 0x90(SP)										
  module.go:48406	0x65653f		8954242c		MOVL DX, 0x2c(SP)										
  module.go:48407	0x656543		4489442420		MOVL R8, 0x20(SP)										
  module.go:48409	0x656548		4c8b4830		MOVQ 0x30(AX), R9										
  module.go:48409	0x65654c		450fb689b0cf1000	MOVZX 0x10cfb0(R9), R9										
  module.go:48410	0x656554		4183f901		CMPL R9, $0x1											
  module.go:48410	0x656558		742f			JE 0x656589											
  module.go:48409	0x65655a		48899c2488000000	MOVQ BX, 0x88(SP)										
  module.go:48411	0x656562		e839f9f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn41(SB)			
  module.go:48414	0x656567		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48566	0x65656f		8b54242c		MOVL 0x2c(SP), DX										
  module.go:48419	0x656573		488b9c2488000000	MOVQ 0x88(SP), BX										
  module.go:48420	0x65657b		448b442420		MOVL 0x20(SP), R8										
  unsafe.go:35		0x656580		f20f10842490000000	MOVSD_XMM 0x90(SP), X0										
  module.go:48414	0x656589		4c8b4838		MOVQ 0x38(AX), R9										
  module.go:62929	0x65658d		4981f973ce1000		CMPQ R9, $0x10ce73										
  module.go:62929	0x656594		0f86de0a0000		JBE 0x657078											
  module.go:48414	0x65659a		4c8b4830		MOVQ 0x30(AX), R9										
  module.go:62930	0x65659e		4183b970ce100000	CMPL 0x10ce70(R9), $0x0										
  module.go:48415	0x6565a6		0f85aa0a0000		JNE 0x657056											
  module.go:48416	0x6565ac		90			NOPL												
  module.go:62947	0x6565ad		41c78170ce1000ffffffff	MOVL $-0x1, 0x10ce70(R9)									
  module.go:48417	0x6565b8		4c8b4838		MOVQ 0x38(AX), R9										
  module.go:48417	0x6565bc		0f1f4000		NOPL 0(AX)											
  module.go:62929	0x6565c0		4981f97fce1000		CMPQ R9, $0x10ce7f										
  module.go:62929	0x6565c7		0f867d0a0000		JBE 0x65704a											
  module.go:48418	0x6565cd		90			NOPL												
  module.go:62929	0x6565ce		4981f983ce1000		CMPQ R9, $0x10ce83										
  module.go:62929	0x6565d5		0f86630a0000		JBE 0x65703e											
  module.go:48417	0x6565db		488b5030		MOVQ 0x30(AX), DX										
  module.go:48420	0x6565df		4589c1			MOVL R8, R9											
  module.go:48420	0x6565e2		4c894c2468		MOVQ R9, 0x68(SP)										
  module.go:62930	0x6565e7		8b8a7cce1000		MOVL 0x10ce7c(DX), CX										
  module.go:62930	0x6565ed		8bba80ce1000		MOVL 0x10ce80(DX), DI										
  module.go:48419	0x6565f3		4889de			MOVQ BX, SI											
  module.go:48419	0x6565f6		4489c3			MOVL R8, BX											
  module.go:48419	0x6565f9		e882d2f8ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn84(SB)			
  module.go:48420	0x6565fe		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48420	0x656606		488b5038		MOVQ 0x38(AX), DX										
  module.go:62929	0x65660a		4c8b442468		MOVQ 0x68(SP), R8										
  module.go:62929	0x65660f		4d8d4807		LEAQ 0x7(R8), R9										
  module.go:62929	0x656613		4c39ca			CMPQ DX, R9											
  module.go:62929	0x656616		0f861d0a0000		JBE 0x657039											
  module.go:48420	0x65661c		488b7030		MOVQ 0x30(AX), SI										
  module.go:62929	0x656620		498d7803		LEAQ 0x3(R8), DI										
  module.go:48427	0x656624		90			NOPL												
  module.go:62930	0x656625		418b4c3004		MOVL 0x4(R8)(SI*1), CX										
  module.go:62929	0x65662a		4839fa			CMPQ DX, DI											
  module.go:62929	0x65662d		0f86010a0000		JBE 0x657034											
  module.go:62930	0x656633		8b5c2420		MOVL 0x20(SP), BX										
  module.go:62930	0x656637		4189da			MOVL BX, R10											
  module.go:62930	0x65663a		458b1c32		MOVL 0(R10)(SI*1), R11										
  module.go:62930	0x65663e		6690			NOPW												
  module.go:48429	0x656640		4183fbff		CMPL R11, $-0x1											
  module.go:48429	0x656644		7418			JE 0x65665e											
  module.go:62955	0x656646		4d8d600f		LEAQ 0xf(R8), R12										
  module.go:48430	0x65664a		90			NOPL												
  module.go:62955	0x65664b		4c39e2			CMPQ DX, R12											
  module.go:62955	0x65664e		0f86db090000		JBE 0x65702f											
  module.go:62956	0x656654		498b543008		MOVQ 0x8(R8)(SI*1), DX										
  module.go:48432	0x656659		e926070000		JMP 0x656d84											
  module.go:62929	0x65665e		4c894c2460		MOVQ R9, 0x60(SP)										
  module.go:62929	0x656663		48897c2458		MOVQ DI, 0x58(SP)										
  module.go:62930	0x656668		4c89542450		MOVQ R10, 0x50(SP)										
  module.go:48434	0x65666d		8b5050			MOVL 0x50(AX), DX										
  module.go:48434	0x656670		89542428		MOVL DX, 0x28(SP)										
  module.go:48435	0x656674		8d72c0			LEAL -0x40(DX), SI										
  module.go:48436	0x656677		897050			MOVL SI, 0x50(AX)										
  unsafe.go:35		0x65667a		f20f10842490000000	MOVSD_XMM 0x90(SP), X0										
  unsafe.go:35		0x656683		66490f7ec3		MOVQ X0, R11											
  module.go:48439	0x656688		4d89dc			MOVQ R11, R12											
  module.go:48439	0x65668b		490fbaf33f		BTRQ $0x3f, R11											
  module.go:48445	0x656690		4d8d6c24ff		LEAQ -0x1(R12), R13										
  module.go:48450	0x656695		49bf000000000000f0ff	MOVQ $0xfff0000000000000, R15									
  module.go:48450	0x65669f		4d01df			ADDQ R11, R15											
  module.go:48438	0x6566a2		90			NOPL												
  module.go:48441	0x6566a3		4d85db			TESTQ R11, R11											
  module.go:48441	0x6566a6		410f94c3		SETE R11											
  module.go:48444	0x6566aa		450fb6db		MOVZX R11, R11											
  module.go:48445	0x6566ae		49b8ffffffffffff0f00	MOVQ $0xfffffffffffff, R8									
  module.go:48445	0x6566b8		4d39e8			CMPQ R8, R13											
  module.go:48445	0x6566bb		410f97c0		SETA R8												
  module.go:48448	0x6566bf		450fb6c0		MOVZX R8, R8											
  module.go:48448	0x6566c3		4509c3			ORL R8, R11											
  module.go:48450	0x6566c6		49b8000000000000e07f	MOVQ $0x7fe0000000000000, R8									
  module.go:48450	0x6566d0		4d39f8			CMPQ R8, R15											
  module.go:48450	0x6566d3		410f97c0		SETA R8												
  module.go:48453	0x6566d7		450fb6c0		MOVZX R8, R8											
  module.go:48454	0x6566db		4d85e4			TESTQ R12, R12											
  module.go:48454	0x6566de		410f9dc4		SETGE R12											
  module.go:48457	0x6566e2		450fb6e4		MOVZX R12, R12											
  module.go:48457	0x6566e6		4521e0			ANDL R12, R8											
  module.go:48457	0x6566e9		4509d8			ORL R11, R8											
  module.go:48457	0x6566ec		4585c0			TESTL R8, R8											
  module.go:48457	0x6566ef		0f8493030000		JE 0x656a88											
  module.go:48435	0x6566f5		89742424		MOVL SI, 0x24(SP)										
  module.go:48481	0x6566f9		8d5ac8			LEAL -0x38(DX), BX										
  module.go:48481	0x6566fc		0f1f4000		NOPL 0(AX)											
  module.go:48481	0x656700		e8fb98fdff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn176(SB)			
  module.go:48482	0x656705		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48482	0x65670d		488b5038		MOVQ 0x38(AX), DX										
  module.go:48482	0x656711		8b742424		MOVL 0x24(SP), SI										
  module.go:48482	0x656715		89f6			MOVL SI, SI											
  module.go:62929	0x656717		488d7e0b		LEAQ 0xb(SI), DI										
  module.go:62929	0x65671b		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:62929	0x656720		4839fa			CMPQ DX, DI											
  module.go:62929	0x656723		0f8601090000		JBE 0x65702a											
  module.go:48482	0x656729		488b7830		MOVQ 0x30(AX), DI										
  module.go:62930	0x65672d		448b443e08		MOVL 0x8(SI)(DI*1), R8										
  module.go:48484	0x656732		4585c0			TESTL R8, R8											
  module.go:48484	0x656735		7536			JNE 0x65676d											
  module.go:48520	0x656737		90			NOPL												
  module.go:62946	0x656738		488b4c2458		MOVQ 0x58(SP), CX										
  module.go:62946	0x65673d		0f1f00			NOPL 0(AX)											
  module.go:62946	0x656740		4839ca			CMPQ DX, CX											
  module.go:62946	0x656743		0f86dc080000		JBE 0x657025											
  module.go:62947	0x656749		488b542450		MOVQ 0x50(SP), DX										
  module.go:62947	0x65674e		c70417ffffffff		MOVL $-0x1, 0(DI)(DX*1)										
  module.go:62955	0x656755		488b742468		MOVQ 0x68(SP), SI										
  module.go:62929	0x65675a		488b7c2460		MOVQ 0x60(SP), DI										
  module.go:62929	0x65675f		4989c8			MOVQ CX, R8											
  module.go:62930	0x656762		4989d1			MOVQ DX, R9											
  module.go:48523	0x656765		4889c1			MOVQ AX, CX											
  module.go:48523	0x656768		e9cf040000		JMP 0x656c3c											
  module.go:62929	0x65676d		4c8d4e0f		LEAQ 0xf(SI), R9										
  module.go:48485	0x656771		90			NOPL												
  module.go:62929	0x656772		4c39ca			CMPQ DX, R9											
  module.go:62929	0x656775		0f86a3080000		JBE 0x65701e											
  module.go:62946	0x65677b		4c8d4e2b		LEAQ 0x2b(SI), R9										
  module.go:48487	0x65677f		90			NOPL												
  module.go:62930	0x656780		448b543e0c		MOVL 0xc(SI)(DI*1), R10										
  module.go:62946	0x656785		4c39ca			CMPQ DX, R9											
  module.go:62946	0x656788		0f868b080000		JBE 0x657019											
  module.go:62947	0x65678e		c7443e2800000000	MOVL $0x0, 0x28(SI)(DI*1)									
  module.go:48488	0x656796		488b7838		MOVQ 0x38(AX), DI										
  module.go:62972	0x65679a		4c8d5e27		LEAQ 0x27(SI), R11										
  module.go:62972	0x65679e		6690			NOPW												
  module.go:62972	0x6567a0		4c39df			CMPQ DI, R11											
  module.go:62972	0x6567a3		0f866b080000		JBE 0x657014											
  module.go:48488	0x6567a9		488b7830		MOVQ 0x30(AX), DI										
  module.go:62973	0x6567ad		49bc0000000001000000	MOVQ $0x100000000, R12										
  module.go:62973	0x6567b7		4c89643e20		MOVQ R12, 0x20(SI)(DI*1)									
  module.go:48489	0x6567bc		488b7838		MOVQ 0x38(AX), DI										
  module.go:62946	0x6567c0		4c8d6633		LEAQ 0x33(SI), R12										
  module.go:62946	0x6567c4		4c39e7			CMPQ DI, R12											
  module.go:62946	0x6567c7		0f8642080000		JBE 0x65700f											
  module.go:48489	0x6567cd		488b7830		MOVQ 0x30(AX), DI										
  module.go:62947	0x6567d1		c7443e30c81a1000	MOVL $0x101ac8, 0x30(SI)(DI*1)									
  module.go:48490	0x6567d9		488b7838		MOVQ 0x38(AX), DI										
  module.go:62972	0x6567dd		4c8d663b		LEAQ 0x3b(SI), R12										
  module.go:62972	0x6567e1		4c39e7			CMPQ DI, R12											
  module.go:62972	0x6567e4		0f8620080000		JBE 0x65700a											
  module.go:48490	0x6567ea		488b7830		MOVQ 0x30(AX), DI										
  module.go:62973	0x6567ee		48c7443e3420000060	MOVQ $0x60000020, 0x34(SI)(DI*1)								
  module.go:48491	0x6567f7		488b7838		MOVQ 0x38(AX), DI										
  module.go:62946	0x6567fb		4c8d662f		LEAQ 0x2f(SI), R12										
  module.go:62946	0x6567ff		90			NOPL												
  module.go:62946	0x656800		4c39e7			CMPQ DI, R12											
  module.go:62946	0x656803		0f86fc070000		JBE 0x657005											
  module.go:48491	0x656809		488b7830		MOVQ 0x30(AX), DI										
  module.go:48491	0x65680d		8b5c2428		MOVL 0x28(SP), BX										
  module.go:48491	0x656811		448d63e0		LEAL -0x20(BX), R12										
  module.go:62947	0x656815		4489643e2c		MOVL R12, 0x2c(SI)(DI*1)									
  module.go:48492	0x65681a		488b7838		MOVQ 0x38(AX), DI										
  module.go:62929	0x65681e		4d8d6213		LEAQ 0x13(R10), R12										
  module.go:62929	0x656822		4c39e7			CMPQ DI, R12											
  module.go:62929	0x656825		0f86d3070000		JBE 0x656ffe											
  module.go:48492	0x65682b		488b7830		MOVQ 0x30(AX), DI										
  module.go:62930	0x65682f		498d3c3a		LEAQ 0(R10)(DI*1), DI										
  module.go:62930	0x656833		488d7f10		LEAQ 0x10(DI), DI										
  module.go:62930	0x656837		48633f			MOVSXD 0(DI), DI										
  module.go:62930	0x65683a		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:63110	0x656840		48397808		CMPQ 0x8(AX), DI										
  module.go:63110	0x656844		0f86a1070000		JBE 0x656feb											
  module.go:48493	0x65684a		48c1e704		SHLQ $0x4, DI											
  module.go:48493	0x65684e		4c8b20			MOVQ 0(AX), R12											
  module.go:48493	0x656851		4e8b2c27		MOVQ 0(DI)(R12*1), R13										
  module.go:48493	0x656855		4a8b542708		MOVQ 0x8(DI)(R12*1), DX										
  module.go:48493	0x65685a		488d3dff4e2000		LEAQ 0x204eff(IP), DI										
  module.go:48493	0x656861		4939fd			CMPQ R13, DI											
  module.go:48493	0x656864		0f856f070000		JNE 0x656fd9											
  module.go:48482	0x65686a		4889742448		MOVQ SI, 0x48(SP)										
  module.go:62930	0x65686f		4489442434		MOVL R8, 0x34(SP)										
  module.go:62930	0x656874		4489542430		MOVL R10, 0x30(SP)										
  module.go:62946	0x656879		4c894c2440		MOVQ R9, 0x40(SP)										
  module.go:62972	0x65687e		4c895c2438		MOVQ R11, 0x38(SP)										
  module.go:48493	0x656883		488b0a			MOVQ 0(DX), CX											
  module.go:48493	0x656886		83c3ec			ADDL $-0x14, BX											
  module.go:48493	0x656889		4489c0			MOVL R8, AX											
  module.go:48493	0x65688c		ffd1			CALL CX												
  module.go:48494	0x65688e		85c0			TESTL AX, AX											
  module.go:48494	0x656890		0f8508070000		JNE 0x656f9e											
  module.go:48498	0x656896		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48498	0x65689e		488b7038		MOVQ 0x38(AX), SI										
  module.go:62929	0x6568a2		488b7c2440		MOVQ 0x40(SP), DI										
  module.go:62929	0x6568a7		4839fe			CMPQ SI, DI											
  module.go:62929	0x6568aa		0f86e9060000		JBE 0x656f99											
  module.go:48498	0x6568b0		488b7830		MOVQ 0x30(AX), DI										
  module.go:62946	0x6568b4		4c8b442448		MOVQ 0x48(SP), R8										
  module.go:62946	0x6568b9		4d8d481b		LEAQ 0x1b(R8), R9										
  module.go:48499	0x6568bd		90			NOPL												
  module.go:62930	0x6568be		458b543828		MOVL 0x28(R8)(DI*1), R10									
  module.go:62946	0x6568c3		4c39ce			CMPQ SI, R9											
  module.go:62946	0x6568c6		0f86c8060000		JBE 0x656f94											
  module.go:62947	0x6568cc		4589543818		MOVL R10, 0x18(R8)(DI*1)									
  module.go:48500	0x6568d1		488b7038		MOVQ 0x38(AX), SI										
  module.go:62955	0x6568d5		488b7c2438		MOVQ 0x38(SP), DI										
  module.go:62955	0x6568da		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:62955	0x6568e0		4839fe			CMPQ SI, DI											
  module.go:62955	0x6568e3		0f86a6060000		JBE 0x656f8f											
  module.go:48500	0x6568e9		488b7830		MOVQ 0x30(AX), DI										
  module.go:62972	0x6568ed		4d8d5017		LEAQ 0x17(R8), R10										
  module.go:48501	0x6568f1		90			NOPL												
  module.go:62956	0x6568f2		4d8b5c3820		MOVQ 0x20(R8)(DI*1), R11									
  module.go:62956	0x6568f7		660f1f840000000000	NOPW 0(AX)(AX*1)										
  module.go:62972	0x656900		4c39d6			CMPQ SI, R10											
  module.go:62972	0x656903		0f8681060000		JBE 0x656f8a											
  module.go:62973	0x656909		4d895c3810		MOVQ R11, 0x10(R8)(DI*1)									
  module.go:48502	0x65690e		488b7038		MOVQ 0x38(AX), SI										
  module.go:62929	0x656912		8b7c2430		MOVL 0x30(SP), DI										
  module.go:62929	0x656916		4c8d5f03		LEAQ 0x3(DI), R11										
  module.go:62929	0x65691a		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:62929	0x656920		4c39de			CMPQ SI, R11											
  module.go:62929	0x656923		0f865c060000		JBE 0x656f85											
  module.go:62946	0x656929		4c894c2440		MOVQ R9, 0x40(SP)										
  module.go:62972	0x65692e		4c89542438		MOVQ R10, 0x38(SP)										
  module.go:48502	0x656933		488b7030		MOVQ 0x30(AX), SI										
  module.go:62930	0x656937		8b3437			MOVL 0(DI)(SI*1), SI										
  module.go:48504	0x65693a		85f6			TESTL SI, SI											
  module.go:48504	0x65693c		7451			JE 0x65698f											
  module.go:48505	0x65693e		4863f6			MOVSXD SI, SI											
  module.go:63110	0x656941		48397008		CMPQ 0x8(AX), SI										
  module.go:63110	0x656945		0f8622060000		JBE 0x656f6d											
  module.go:48505	0x65694b		48c1e604		SHLQ $0x4, SI											
  module.go:48505	0x65694f		4c8b18			MOVQ 0(AX), R11											
  module.go:48505	0x656952		4e8b241e		MOVQ 0(SI)(R11*1), R12										
  module.go:48505	0x656956		4a8b541e08		MOVQ 0x8(SI)(R11*1), DX										
  module.go:48505	0x65695b		488d1d7e5f1f00		LEAQ 0x1f5f7e(IP), BX										
  module.go:48505	0x656962		4939dc			CMPQ R12, BX											
  module.go:48505	0x656965		0f85f3050000		JNE 0x656f5e											
  module.go:48505	0x65696b		488b0a			MOVQ 0(DX), CX											
  module.go:48505	0x65696e		8b442434		MOVL 0x34(SP), AX										
  module.go:48505	0x656972		ffd1			CALL CX												
  module.go:48507	0x656974		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:62929	0x65697c		8b7c2430		MOVL 0x30(SP), DI										
  module.go:62930	0x656980		4c8b442448		MOVQ 0x48(SP), R8										
  module.go:62929	0x656985		4c8b4c2440		MOVQ 0x40(SP), R9										
  module.go:62955	0x65698a		4c8b542438		MOVQ 0x38(SP), R10										
  module.go:48507	0x65698f		488b5038		MOVQ 0x38(AX), DX										
  module.go:62929	0x656993		488d7707		LEAQ 0x7(DI), SI										
  module.go:62929	0x656997		660f1f840000000000	NOPW 0(AX)(AX*1)										
  module.go:62929	0x6569a0		4839f2			CMPQ DX, SI											
  module.go:62929	0x6569a3		0f86b0050000		JBE 0x656f59											
  module.go:48507	0x6569a9		488b7030		MOVQ 0x30(AX), SI										
  module.go:62930	0x6569ad		8b4c3704		MOVL 0x4(DI)(SI*1), CX										
  module.go:48509	0x6569b1		85c9			TESTL CX, CX											
  module.go:48509	0x6569b3		7434			JE 0x6569e9											
  module.go:62929	0x6569b5		488d770b		LEAQ 0xb(DI), SI										
  module.go:48510	0x6569b9		90			NOPL												
  module.go:48510	0x6569ba		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:62929	0x6569c0		4839f2			CMPQ DX, SI											
  module.go:62929	0x6569c3		0f868b050000		JBE 0x656f54											
  module.go:48511	0x6569c9		8b5c2434		MOVL 0x34(SP), BX										
  module.go:48511	0x6569cd		e8ee56f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn1(SB)			
  module.go:48513	0x6569d2		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:62930	0x6569da		4c8b442448		MOVQ 0x48(SP), R8										
  module.go:62929	0x6569df		4c8b4c2440		MOVQ 0x40(SP), R9										
  module.go:62955	0x6569e4		4c8b542438		MOVQ 0x38(SP), R10										
  module.go:48513	0x6569e9		488b4838		MOVQ 0x38(AX), CX										
  module.go:62929	0x6569ed		4c39c9			CMPQ CX, R9											
  module.go:62929	0x6569f0		0f8659050000		JBE 0x656f4f											
  module.go:48513	0x6569f6		488b5030		MOVQ 0x30(AX), DX										
  module.go:62946	0x6569fa		488b742468		MOVQ 0x68(SP), SI										
  module.go:62946	0x6569ff		488d7e0b		LEAQ 0xb(SI), DI										
  module.go:48514	0x656a03		90			NOPL												
  module.go:62930	0x656a04		458b4c1018		MOVL 0x18(R8)(DX*1), R9										
  module.go:62946	0x656a09		4839f9			CMPQ CX, DI											
  module.go:62946	0x656a0c		0f8638050000		JBE 0x656f4a											
  module.go:62947	0x656a12		44894c1608		MOVL R9, 0x8(SI)(DX*1)										
  module.go:48515	0x656a17		488b4838		MOVQ 0x38(AX), CX										
  module.go:48515	0x656a1b		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:62955	0x656a20		4c39d1			CMPQ CX, R10											
  module.go:62955	0x656a23		0f861c050000		JBE 0x656f45											
  module.go:48515	0x656a29		488b5030		MOVQ 0x30(AX), DX										
  module.go:48516	0x656a2d		90			NOPL												
  module.go:62956	0x656a2e		498b7c1010		MOVQ 0x10(R8)(DX*1), DI										
  module.go:62972	0x656a33		4c8b442460		MOVQ 0x60(SP), R8										
  module.go:62972	0x656a38		0f1f840000000000	NOPL 0(AX)(AX*1)										
  module.go:62972	0x656a40		4c39c1			CMPQ CX, R8											
  module.go:62972	0x656a43		0f86f5040000		JBE 0x656f3e											
  module.go:62973	0x656a49		488b4c2450		MOVQ 0x50(SP), CX										
  module.go:62973	0x656a4e		48893c0a		MOVQ DI, 0(DX)(CX*1)										
  module.go:48517	0x656a52		488b5038		MOVQ 0x38(AX), DX										
  module.go:62946	0x656a56		488d7e0f		LEAQ 0xf(SI), DI										
  module.go:62946	0x656a5a		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:62946	0x656a60		4839fa			CMPQ DX, DI											
  module.go:62946	0x656a63		0f86d0040000		JBE 0x656f39											
  module.go:48517	0x656a69		488b5030		MOVQ 0x30(AX), DX										
  module.go:62947	0x656a6d		c744160c01000000	MOVL $0x1, 0xc(SI)(DX*1)									
  module.go:62929	0x656a75		4c89c7			MOVQ R8, DI											
  module.go:62929	0x656a78		4c8b442458		MOVQ 0x58(SP), R8										
  module.go:62930	0x656a7d		4989c9			MOVQ CX, R9											
  module.go:48523	0x656a80		4889c1			MOVQ AX, CX											
  module.go:48518	0x656a83		e9b4010000		JMP 0x656c3c											
  module.go:48458	0x656a88		bb2c000000		MOVL $0x2c, BX											
  module.go:48458	0x656a8d		b901000000		MOVL $0x1, CX											
  module.go:48458	0x656a92		e8a959f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn4(SB)			
  module.go:48460	0x656a97		85c0			TESTL AX, AX											
  module.go:48460	0x656a99		0f8470040000		JE 0x656f0f											
  module.go:48464	0x656a9f		488b8c2480000000	MOVQ 0x80(SP), CX										
  module.go:48464	0x656aa7		488b5138		MOVQ 0x38(CX), DX										
  module.go:62972	0x656aab		488b742468		MOVQ 0x68(SP), SI										
  module.go:62972	0x656ab0		488d7e0f		LEAQ 0xf(SI), DI										
  module.go:62972	0x656ab4		4839fa			CMPQ DX, DI											
  module.go:62972	0x656ab7		0f864d040000		JBE 0x656f0a											
  module.go:48464	0x656abd		488b5130		MOVQ 0x30(CX), DX										
  module.go:62973	0x656ac1		48bf2c00000002000000	MOVQ $0x20000002c, DI										
  module.go:62973	0x656acb		48897c1608		MOVQ DI, 0x8(SI)(DX*1)										
  module.go:48465	0x656ad0		488b5138		MOVQ 0x38(CX), DX										
  module.go:62946	0x656ad4		488b7c2460		MOVQ 0x60(SP), DI										
  module.go:62946	0x656ad9		0f1f8000000000		NOPL 0(AX)											
  module.go:62946	0x656ae0		4839fa			CMPQ DX, DI											
  module.go:62946	0x656ae3		0f861c040000		JBE 0x656f05											
  module.go:48465	0x656ae9		488b5130		MOVQ 0x30(CX), DX										
  module.go:62947	0x656aed		89441604		MOVL AX, 0x4(SI)(DX*1)										
  module.go:48466	0x656af1		488b5138		MOVQ 0x38(CX), DX										
  module.go:62946	0x656af5		4c8b442458		MOVQ 0x58(SP), R8										
  module.go:62946	0x656afa		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:62946	0x656b00		4c39c2			CMPQ DX, R8											
  module.go:62946	0x656b03		0f86f3030000		JBE 0x656efc											
  module.go:48466	0x656b09		488b5130		MOVQ 0x30(CX), DX										
  module.go:62947	0x656b0d		4c8b4c2450		MOVQ 0x50(SP), R9										
  module.go:62947	0x656b12		42c7040a2c000000	MOVL $0x2c, 0(DX)(R9*1)										
  module.go:48467	0x656b1a		488b5138		MOVQ 0x38(CX), DX										
  module.go:48467	0x656b1e		6690			NOPW												
  module.go:62929	0x656b20		4881fa9b191000		CMPQ DX, $0x10199b										
  module.go:62929	0x656b27		0f86c3030000		JBE 0x656ef0											
  module.go:48468	0x656b2d		4189c2			MOVL AX, R10											
  module.go:62946	0x656b30		4d8d5a2b		LEAQ 0x2b(R10), R11										
  module.go:62946	0x656b34		4c39da			CMPQ DX, R11											
  module.go:62946	0x656b37		0f86ae030000		JBE 0x656eeb											
  module.go:48467	0x656b3d		488b5130		MOVQ 0x30(CX), DX										
  module.go:62930	0x656b41		448b9a98191000		MOVL 0x101998(DX), R11										
  module.go:62947	0x656b48		45895c1228		MOVL R11, 0x28(R10)(DX*1)									
  module.go:48469	0x656b4d		488b5138		MOVQ 0x38(CX), DX										
  module.go:62955	0x656b51		4881fa97191000		CMPQ DX, $0x101997										
  module.go:62955	0x656b58		0f8681030000		JBE 0x656edf											
  module.go:62972	0x656b5e		4d8d5a27		LEAQ 0x27(R10), R11										
  module.go:48470	0x656b62		90			NOPL												
  module.go:62972	0x656b63		4c39da			CMPQ DX, R11											
  module.go:62972	0x656b66		0f866e030000		JBE 0x656eda											
  module.go:48469	0x656b6c		488b5130		MOVQ 0x30(CX), DX										
  module.go:62956	0x656b70		4c8b9a90191000		MOVQ 0x101990(DX), R11										
  module.go:62973	0x656b77		4d895c1220		MOVQ R11, 0x20(R10)(DX*1)									
  module.go:48471	0x656b7c		488b5138		MOVQ 0x38(CX), DX										
  module.go:62955	0x656b80		4881fa8f191000		CMPQ DX, $0x10198f										
  module.go:62955	0x656b87		0f8641030000		JBE 0x656ece											
  module.go:62972	0x656b8d		4d8d5a1f		LEAQ 0x1f(R10), R11										
  module.go:48472	0x656b91		90			NOPL												
  module.go:62972	0x656b92		4c39da			CMPQ DX, R11											
  module.go:62972	0x656b95		0f862e030000		JBE 0x656ec9											
  module.go:48471	0x656b9b		488b5130		MOVQ 0x30(CX), DX										
  module.go:62956	0x656b9f		4c8b9a88191000		MOVQ 0x101988(DX), R11										
  module.go:62973	0x656ba6		4d895c1218		MOVQ R11, 0x18(R10)(DX*1)									
  module.go:48473	0x656bab		488b5138		MOVQ 0x38(CX), DX										
  module.go:62955	0x656baf		4881fa87191000		CMPQ DX, $0x101987										
  module.go:62955	0x656bb6		0f8601030000		JBE 0x656ebd											
  module.go:62972	0x656bbc		4d8d5a17		LEAQ 0x17(R10), R11										
  module.go:48474	0x656bc0		90			NOPL												
  module.go:62972	0x656bc1		4c39da			CMPQ DX, R11											
  module.go:62972	0x656bc4		0f86ee020000		JBE 0x656eb8											
  module.go:48473	0x656bca		488b5130		MOVQ 0x30(CX), DX										
  module.go:62956	0x656bce		4c8b9a80191000		MOVQ 0x101980(DX), R11										
  module.go:62973	0x656bd5		4d895c1210		MOVQ R11, 0x10(R10)(DX*1)									
  module.go:48475	0x656bda		488b5138		MOVQ 0x38(CX), DX										
  module.go:48475	0x656bde		6690			NOPW												
  module.go:62955	0x656be0		4881fa7f191000		CMPQ DX, $0x10197f										
  module.go:62955	0x656be7		0f86bf020000		JBE 0x656eac											
  module.go:62972	0x656bed		4d8d5a0f		LEAQ 0xf(R10), R11										
  module.go:48476	0x656bf1		90			NOPL												
  module.go:62972	0x656bf2		4c39da			CMPQ DX, R11											
  module.go:62972	0x656bf5		0f86ac020000		JBE 0x656ea7											
  module.go:48475	0x656bfb		488b5130		MOVQ 0x30(CX), DX										
  module.go:62956	0x656bff		4c8b9a78191000		MOVQ 0x101978(DX), R11										
  module.go:62973	0x656c06		4d895c1208		MOVQ R11, 0x8(R10)(DX*1)									
  module.go:48477	0x656c0b		488b5138		MOVQ 0x38(CX), DX										
  module.go:62955	0x656c0f		4881fa77191000		CMPQ DX, $0x101977										
  module.go:62955	0x656c16		0f867f020000		JBE 0x656e9b											
  module.go:62972	0x656c1c		4983c207		ADDQ $0x7, R10											
  module.go:48478	0x656c20		90			NOPL												
  module.go:62972	0x656c21		4c39d2			CMPQ DX, R10											
  module.go:62972	0x656c24		0f866c020000		JBE 0x656e96											
  module.go:48477	0x656c2a		488b5130		MOVQ 0x30(CX), DX										
  module.go:62956	0x656c2e		4c8b9270191000		MOVQ 0x101970(DX), R10										
  module.go:62973	0x656c35		4189c3			MOVL AX, R11											
  module.go:62973	0x656c38		4e89141a		MOVQ R10, 0(DX)(R11*1)										
  module.go:48523	0x656c3c		8b542428		MOVL 0x28(SP), DX										
  module.go:48523	0x656c40		895150			MOVL DX, 0x50(CX)										
  module.go:48526	0x656c43		488b5138		MOVQ 0x38(CX), DX										
  module.go:62929	0x656c47		4c39c2			CMPQ DX, R8											
  module.go:62929	0x656c4a		0f8641020000		JBE 0x656e91											
  module.go:48526	0x656c50		4c8b5130		MOVQ 0x30(CX), R10										
  module.go:62930	0x656c54		478b1c11		MOVL 0(R9)(R10*1), R11										
  module.go:62930	0x656c58		0f1f840000000000	NOPL 0(AX)(AX*1)										
  module.go:48528	0x656c60		4183fbff		CMPL R11, $-0x1											
  module.go:48528	0x656c64		0f85e2000000		JNE 0x656d4c											
  module.go:48548	0x656c6a		90			NOPL												
  module.go:62929	0x656c6b		4881fa73ce1000		CMPQ DX, $0x10ce73										
  module.go:62929	0x656c72		0f860d020000		JBE 0x656e85											
  module.go:48549	0x656c78		90			NOPL												
  module.go:62947	0x656c79		41ff8270ce1000		INCL 0x10ce70(R10)										
  module.go:48550	0x656c80		488b5138		MOVQ 0x38(CX), DX										
  module.go:48550	0x656c84		4881fafccf1000		CMPQ DX, $0x10cffc										
  module.go:48550	0x656c8b		0f86e4010000		JBE 0x656e75											
  module.go:48550	0x656c91		488b5130		MOVQ 0x30(CX), DX										
  module.go:48550	0x656c95		0fb692fccf1000		MOVZX 0x10cffc(DX), DX										
  module.go:48550	0x656c9c		0f1f4000		NOPL 0(AX)											
  module.go:48551	0x656ca0		83fa01			CMPL DX, $0x1											
  module.go:48551	0x656ca3		7410			JE 0x656cb5											
  module.go:48552	0x656ca5		4889c8			MOVQ CX, AX											
  module.go:48552	0x656ca8		e8f308fbff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn105(SB)			
  module.go:48554	0x656cad		488b8c2480000000	MOVQ 0x80(SP), CX										
  module.go:48554	0x656cb5		488b5138		MOVQ 0x38(CX), DX										
  module.go:48554	0x656cb9		0f1f8000000000		NOPL 0(AX)											
  module.go:62929	0x656cc0		4881fad3cf1000		CMPQ DX, $0x10cfd3										
  module.go:62929	0x656cc7		0f869c010000		JBE 0x656e69											
  module.go:48554	0x656ccd		488b7130		MOVQ 0x30(CX), SI										
  module.go:62930	0x656cd1		83bed0cf100000		CMPL 0x10cfd0(SI), $0x0										
  module.go:48555	0x656cd8		0f856b010000		JNE 0x656e49											
  module.go:48559	0x656cde		90			NOPL												
  module.go:48559	0x656cdf		90			NOPL												
  module.go:62929	0x656ce0		4881fae7cf1000		CMPQ DX, $0x10cfe7										
  module.go:62929	0x656ce7		0f8650010000		JBE 0x656e3d											
  module.go:48560	0x656ced		90			NOPL												
  module.go:62946	0x656cee		4881faefcf1000		CMPQ DX, $0x10cfef										
  module.go:62946	0x656cf5		0f8636010000		JBE 0x656e31											
  module.go:62930	0x656cfb		8b96e4cf1000		MOVL 0x10cfe4(SI), DX										
  module.go:62947	0x656d01		8996eccf1000		MOVL DX, 0x10cfec(SI)										
  module.go:48561	0x656d07		488b5138		MOVQ 0x38(CX), DX										
  module.go:62946	0x656d0b		4881faebcf1000		CMPQ DX, $0x10cfeb										
  module.go:62946	0x656d12		0f860d010000		JBE 0x656e25											
  module.go:48561	0x656d18		488b5130		MOVQ 0x30(CX), DX										
  module.go:62947	0x656d1c		c782e8cf100000000000	MOVL $0x0, 0x10cfe8(DX)										
  module.go:48562	0x656d26		488b5138		MOVQ 0x38(CX), DX										
  module.go:62946	0x656d2a		4881faf3cf1000		CMPQ DX, $0x10cff3										
  module.go:62946	0x656d31		0f86dd000000		JBE 0x656e14											
  module.go:48562	0x656d37		488b5130		MOVQ 0x30(CX), DX										
  module.go:62947	0x656d3b		c782f0cf100000000000	MOVL $0x0, 0x10cff0(DX)										
  module.go:62947	0x656d45		31c0			XORL AX, AX											
  module.go:48565	0x656d47		e996000000		JMP 0x656de2											
  module.go:48531	0x656d4c		90			NOPL												
  module.go:62929	0x656d4d		4839fa			CMPQ DX, DI											
  module.go:62929	0x656d50		0f86b9000000		JBE 0x656e0f											
  module.go:62955	0x656d56		4c8d660f		LEAQ 0xf(SI), R12										
  module.go:48533	0x656d5a		90			NOPL												
  module.go:62930	0x656d5b		468b6c1604		MOVL 0x4(SI)(R10*1), R13									
  module.go:62955	0x656d60		4c39e2			CMPQ DX, R12											
  module.go:62955	0x656d63		0f86a1000000		JBE 0x656e0a											
  module.go:62956	0x656d69		4a8b541608		MOVQ 0x8(SI)(R10*1), DX										
  module.go:48538	0x656d6e		4889c8			MOVQ CX, AX											
  module.go:48543	0x656d71		8b5c2420		MOVL 0x20(SP), BX										
  module.go:62947	0x656d75		4d89ca			MOVQ R9, R10											
  module.go:48537	0x656d78		4489e9			MOVL R13, CX											
  module.go:62946	0x656d7b		4989f9			MOVQ DI, R9											
  module.go:62946	0x656d7e		4c89c7			MOVQ R8, DI											
  module.go:62972	0x656d81		4989f0			MOVQ SI, R8											
  module.go:48538	0x656d84		488b7038		MOVQ 0x38(AX), SI										
  module.go:62929	0x656d88		4881fe73ce1000		CMPQ SI, $0x10ce73										
  module.go:62929	0x656d8f		766d			JBE 0x656dfe											
  module.go:48538	0x656d91		488b7030		MOVQ 0x30(AX), SI										
  module.go:62972	0x656d95		4d8d600f		LEAQ 0xf(R8), R12										
  module.go:48539	0x656d99		90			NOPL												
  module.go:62947	0x656d9a		ff8670ce1000		INCL 0x10ce70(SI)										
  module.go:48540	0x656da0		488b7038		MOVQ 0x38(AX), SI										
  module.go:62972	0x656da4		4c39e6			CMPQ SI, R12											
  module.go:62972	0x656da7		7650			JBE 0x656df9											
  module.go:48540	0x656da9		488b7030		MOVQ 0x30(AX), SI										
  module.go:62973	0x656dad		4989543008		MOVQ DX, 0x8(R8)(SI*1)										
  module.go:48541	0x656db2		488b5038		MOVQ 0x38(AX), DX										
  module.go:62946	0x656db6		4c39ca			CMPQ DX, R9											
  module.go:62946	0x656db9		7639			JBE 0x656df4											
  module.go:48541	0x656dbb		488b5030		MOVQ 0x30(AX), DX										
  module.go:62947	0x656dbf		41894c1004		MOVL CX, 0x4(R8)(DX*1)										
  module.go:48542	0x656dc4		488b4838		MOVQ 0x38(AX), CX										
  module.go:62946	0x656dc8		4839f9			CMPQ CX, DI											
  module.go:62946	0x656dcb		7622			JBE 0x656def											
  module.go:48542	0x656dcd		488b4830		MOVQ 0x30(AX), CX										
  module.go:62947	0x656dd1		46891c11		MOVL R11, 0(CX)(R10*1)										
  module.go:48543	0x656dd5		e8c65cf8ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn60(SB)			
  module.go:48566	0x656dda		488b8c2480000000	MOVQ 0x80(SP), CX										
  module.go:48566	0x656de2		8b54242c		MOVL 0x2c(SP), DX										
  module.go:48566	0x656de6		895150			MOVL DX, 0x50(CX)										
  module.go:48567	0x656de9		4883c470		ADDQ $0x70, SP											
  module.go:48567	0x656ded		5d			POPQ BP												
  module.go:48567	0x656dee		c3			RET												
  module.go:62946	0x656def		e8cc9be3ff		CALL runtime.panicBounds(SB)									
  module.go:62946	0x656df4		e8c79be3ff		CALL runtime.panicBounds(SB)									
  module.go:62972	0x656df9		e8c29be3ff		CALL runtime.panicBounds(SB)									
  module.go:62929	0x656dfe		48c7c073ce1000		MOVQ $0x10ce73, AX										
  module.go:62929	0x656e05		e8b69be3ff		CALL runtime.panicBounds(SB)									
  module.go:62955	0x656e0a		e8b19be3ff		CALL runtime.panicBounds(SB)									
  module.go:62929	0x656e0f		e8ac9be3ff		CALL runtime.panicBounds(SB)									
  module.go:62946	0x656e14		48c7c0f3cf1000		MOVQ $0x10cff3, AX										
  module.go:62946	0x656e1b		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:62946	0x656e20		e89b9be3ff		CALL runtime.panicBounds(SB)									
  module.go:62946	0x656e25		48c7c0ebcf1000		MOVQ $0x10cfeb, AX										
  module.go:62946	0x656e2c		e88f9be3ff		CALL runtime.panicBounds(SB)									
  module.go:62946	0x656e31		48c7c0efcf1000		MOVQ $0x10cfef, AX										
  module.go:62946	0x656e38		e8839be3ff		CALL runtime.panicBounds(SB)									
  module.go:62929	0x656e3d		48c7c0e7cf1000		MOVQ $0x10cfe7, AX										
  module.go:62929	0x656e44		e8779be3ff		CALL runtime.panicBounds(SB)									
  module.go:48556	0x656e49		4889c8			MOVQ CX, AX											
  module.go:48556	0x656e4c		bb60171000		MOVL $0x101760, BX										
  module.go:48556	0x656e51		e86ac2f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn24(SB)			
  module.go:48557	0x656e56		488d05c33b1f00		LEAQ 0x1f3bc3(IP), AX										
  module.go:48557	0x656e5d		488d1dccb42a00		LEAQ 0x2ab4cc(IP), BX										
  module.go:48557	0x656e64		e87719e3ff		CALL runtime.gopanic(SB)									
  module.go:62929	0x656e69		48c7c0d3cf1000		MOVQ $0x10cfd3, AX										
  module.go:62929	0x656e70		e84b9be3ff		CALL runtime.panicBounds(SB)									
  module.go:48550	0x656e75		48c7c0fccf1000		MOVQ $0x10cffc, AX										
  module.go:48550	0x656e7c		0f1f4000		NOPL 0(AX)											
  module.go:48550	0x656e80		e83b9be3ff		CALL runtime.panicBounds(SB)									
  module.go:62929	0x656e85		48c7c073ce1000		MOVQ $0x10ce73, AX										
  module.go:62929	0x656e8c		e82f9be3ff		CALL runtime.panicBounds(SB)									
  module.go:62929	0x656e91		e82a9be3ff		CALL runtime.panicBounds(SB)									
  module.go:62972	0x656e96		e8259be3ff		CALL runtime.panicBounds(SB)									
  module.go:62955	0x656e9b		48c7c077191000		MOVQ $0x101977, AX										
  module.go:62955	0x656ea2		e8199be3ff		CALL runtime.panicBounds(SB)									
  module.go:62972	0x656ea7		e8149be3ff		CALL runtime.panicBounds(SB)									
  module.go:62955	0x656eac		48c7c07f191000		MOVQ $0x10197f, AX										
  module.go:62955	0x656eb3		e8089be3ff		CALL runtime.panicBounds(SB)									
  module.go:62972	0x656eb8		e8039be3ff		CALL runtime.panicBounds(SB)									
  module.go:62955	0x656ebd		48c7c087191000		MOVQ $0x101987, AX										
  module.go:62955	0x656ec4		e8f79ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62972	0x656ec9		e8f29ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62955	0x656ece		48c7c08f191000		MOVQ $0x10198f, AX										
  module.go:62955	0x656ed5		e8e69ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62972	0x656eda		e8e19ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62955	0x656edf		48c7c097191000		MOVQ $0x101997, AX										
  module.go:62955	0x656ee6		e8d59ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62946	0x656eeb		e8d09ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62929	0x656ef0		48c7c09b191000		MOVQ $0x10199b, AX										
  module.go:62929	0x656ef7		e8c49ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62946	0x656efc		0f1f4000		NOPL 0(AX)											
  module.go:62946	0x656f00		e8bb9ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62946	0x656f05		e8b69ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62972	0x656f0a		e8b19ae3ff		CALL runtime.panicBounds(SB)									
  module.go:48461	0x656f0f		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48461	0x656f17		bb01000000		MOVL $0x1, BX											
  module.go:48461	0x656f1c		b92c000000		MOVL $0x2c, CX											
  module.go:48461	0x656f21		e89a52f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn2(SB)			
  module.go:48462	0x656f26		488d05f33a1f00		LEAQ 0x1f3af3(IP), AX										
  module.go:48462	0x656f2d		488d1dfcb32a00		LEAQ 0x2ab3fc(IP), BX										
  module.go:48462	0x656f34		e8a718e3ff		CALL runtime.gopanic(SB)									
  module.go:62946	0x656f39		e8829ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62972	0x656f3e		6690			NOPW												
  module.go:62972	0x656f40		e87b9ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62955	0x656f45		e8769ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62946	0x656f4a		e8719ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62929	0x656f4f		e86c9ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62929	0x656f54		e8679ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62929	0x656f59		e8629ae3ff		CALL runtime.panicBounds(SB)									
  module.go:48505	0x656f5e		4c89e0			MOVQ R12, AX											
  module.go:48505	0x656f61		488d0db84b2000		LEAQ 0x204bb8(IP), CX										
  module.go:48505	0x656f68		e81372dcff		CALL runtime.panicdottypeE(SB)									
  module.go:63111	0x656f6d		488d05ac3a1f00		LEAQ 0x1f3aac(IP), AX										
  module.go:63111	0x656f74		488d1d15cb2a00		LEAQ 0x2acb15(IP), BX										
  module.go:63111	0x656f7b		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:63111	0x656f80		e85b18e3ff		CALL runtime.gopanic(SB)									
  module.go:62929	0x656f85		e8369ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62972	0x656f8a		e8319ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62955	0x656f8f		e82c9ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62946	0x656f94		e8279ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62929	0x656f99		e8229ae3ff		CALL runtime.panicBounds(SB)									
  module.go:48495	0x656f9e		8b7c2428		MOVL 0x28(SP), DI										
  module.go:48495	0x656fa2		ffcf			DECL DI												
  module.go:48495	0x656fa4		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48495	0x656fac		bbf01a1000		MOVL $0x101af0, BX										
  module.go:48495	0x656fb1		b937000000		MOVL $0x37, CX											
  module.go:48495	0x656fb6		bee01a1000		MOVL $0x101ae0, SI										
  module.go:48495	0x656fbb		41b8281b1000		MOVL $0x101b28, R8										
  module.go:48495	0x656fc1		e8bac4f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn27(SB)			
  module.go:48496	0x656fc6		488d05533a1f00		LEAQ 0x1f3a53(IP), AX										
  module.go:48496	0x656fcd		488d1d5cb32a00		LEAQ 0x2ab35c(IP), BX										
  module.go:48496	0x656fd4		e80718e3ff		CALL runtime.gopanic(SB)									
  module.go:48493	0x656fd9		4c89e8			MOVQ R13, AX											
  module.go:48493	0x656fdc		4889fb			MOVQ DI, BX											
  module.go:48493	0x656fdf		488d0d3a4b2000		LEAQ 0x204b3a(IP), CX										
  module.go:48493	0x656fe6		e89571dcff		CALL runtime.panicdottypeE(SB)									
  module.go:63111	0x656feb		488d052e3a1f00		LEAQ 0x1f3a2e(IP), AX										
  module.go:63111	0x656ff2		488d1d97ca2a00		LEAQ 0x2aca97(IP), BX										
  module.go:63111	0x656ff9		e8e217e3ff		CALL runtime.gopanic(SB)									
  module.go:62929	0x656ffe		6690			NOPW												
  module.go:62929	0x657000		e8bb99e3ff		CALL runtime.panicBounds(SB)									
  module.go:62946	0x657005		e8b699e3ff		CALL runtime.panicBounds(SB)									
  module.go:62972	0x65700a		e8b199e3ff		CALL runtime.panicBounds(SB)									
  module.go:62946	0x65700f		e8ac99e3ff		CALL runtime.panicBounds(SB)									
  module.go:62972	0x657014		e8a799e3ff		CALL runtime.panicBounds(SB)									
  module.go:62946	0x657019		e8a299e3ff		CALL runtime.panicBounds(SB)									
  module.go:62929	0x65701e		6690			NOPW												
  module.go:62929	0x657020		e89b99e3ff		CALL runtime.panicBounds(SB)									
  module.go:62946	0x657025		e89699e3ff		CALL runtime.panicBounds(SB)									
  module.go:62929	0x65702a		e89199e3ff		CALL runtime.panicBounds(SB)									
  module.go:62955	0x65702f		e88c99e3ff		CALL runtime.panicBounds(SB)									
  module.go:62929	0x657034		e88799e3ff		CALL runtime.panicBounds(SB)									
  module.go:62929	0x657039		e88299e3ff		CALL runtime.panicBounds(SB)									
  module.go:62929	0x65703e		48c7c083ce1000		MOVQ $0x10ce83, AX										
  module.go:62929	0x657045		e87699e3ff		CALL runtime.panicBounds(SB)									
  module.go:62929	0x65704a		48c7c07fce1000		MOVQ $0x10ce7f, AX										
  module.go:62929	0x657051		e86a99e3ff		CALL runtime.panicBounds(SB)									
  module.go:48569	0x657056		bb60171000		MOVL $0x101760, BX										
  module.go:48569	0x65705b		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:48569	0x657060		e85bc0f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn24(SB)			
  module.go:48570	0x657065		488d05b4391f00		LEAQ 0x1f39b4(IP), AX										
  module.go:48570	0x65706c		488d1dbdb22a00		LEAQ 0x2ab2bd(IP), BX										
  module.go:48570	0x657073		e86817e3ff		CALL runtime.gopanic(SB)									
  module.go:62929	0x657078		48c7c073ce1000		MOVQ $0x10ce73, AX										
  module.go:62929	0x65707f		90			NOPL												
  module.go:62929	0x657080		e83b99e3ff		CALL runtime.panicBounds(SB)									
  module.go:48409	0x657085		48c7c0b0cf1000		MOVQ $0x10cfb0, AX										
  module.go:48409	0x65708c		e82f99e3ff		CALL runtime.panicBounds(SB)									
  module.go:48409	0x657091		90			NOPL												
  module.go:48403	0x657092		4889442408		MOVQ AX, 0x8(SP)										
  module.go:48403	0x657097		48895c2410		MOVQ BX, 0x10(SP)										
  module.go:48403	0x65709c		f20f11442418		MOVSD_XMM X0, 0x18(SP)										
  module.go:48403	0x6570a2		e8f97be3ff		CALL runtime.morestack_noctxt.abi0(SB)								
  module.go:48403	0x6570a7		488b442408		MOVQ 0x8(SP), AX										
  module.go:48403	0x6570ac		488b5c2410		MOVQ 0x10(SP), BX										
  module.go:48403	0x6570b1		f20f10442418		MOVSD_XMM 0x18(SP), X0										
  module.go:48403	0x6570b7		e944f4ffff		JMP dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).Xcocoon_sketch_add(SB)	
