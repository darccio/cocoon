TEXT dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).Xcocoon_sketch_add(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/internal/wasm/module.go
  module.go:48402	0x656440		493b6610		CMPQ SP, 0x10(R14)										
  module.go:48402	0x656444		0f86880b0000		JBE 0x656fd2											
  module.go:48402	0x65644a		55			PUSHQ BP											
  module.go:48402	0x65644b		4889e5			MOVQ SP, BP											
  module.go:48402	0x65644e		4883ec70		SUBQ $0x70, SP											
  module.go:48405	0x656452		8b5050			MOVL 0x50(AX), DX										
  module.go:48406	0x656455		448d42f0		LEAL -0x10(DX), R8										
  module.go:48407	0x656459		44894050		MOVL R8, 0x50(AX)										
  module.go:48408	0x65645d		4c8b4838		MOVQ 0x38(AX), R9										
  module.go:48408	0x656461		4981f9b0cf1000		CMPQ R9, $0x10cfb0										
  module.go:48408	0x656468		0f86570b0000		JBE 0x656fc5											
  module.go:48408	0x65646e		4889842480000000	MOVQ AX, 0x80(SP)										
  module.go:48408	0x656476		f20f11842490000000	MOVSD_XMM X0, 0x90(SP)										
  module.go:48405	0x65647f		8954242c		MOVL DX, 0x2c(SP)										
  module.go:48406	0x656483		4489442420		MOVL R8, 0x20(SP)										
  module.go:48408	0x656488		4c8b4830		MOVQ 0x30(AX), R9										
  module.go:48408	0x65648c		450fb689b0cf1000	MOVZX 0x10cfb0(R9), R9										
  module.go:48409	0x656494		4183f901		CMPL R9, $0x1											
  module.go:48409	0x656498		742f			JE 0x6564c9											
  module.go:48408	0x65649a		48899c2488000000	MOVQ BX, 0x88(SP)										
  module.go:48410	0x6564a2		e819f9f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn41(SB)			
  module.go:48413	0x6564a7		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48565	0x6564af		8b54242c		MOVL 0x2c(SP), DX										
  module.go:48418	0x6564b3		488b9c2488000000	MOVQ 0x88(SP), BX										
  module.go:48419	0x6564bb		448b442420		MOVL 0x20(SP), R8										
  unsafe.go:35		0x6564c0		f20f10842490000000	MOVSD_XMM 0x90(SP), X0										
  module.go:48413	0x6564c9		4c8b4838		MOVQ 0x38(AX), R9										
  module.go:62928	0x6564cd		4981f973ce1000		CMPQ R9, $0x10ce73										
  module.go:62928	0x6564d4		0f86de0a0000		JBE 0x656fb8											
  module.go:48413	0x6564da		4c8b4830		MOVQ 0x30(AX), R9										
  module.go:62929	0x6564de		4183b970ce100000	CMPL 0x10ce70(R9), $0x0										
  module.go:48414	0x6564e6		0f85aa0a0000		JNE 0x656f96											
  module.go:48415	0x6564ec		90			NOPL												
  module.go:62946	0x6564ed		41c78170ce1000ffffffff	MOVL $-0x1, 0x10ce70(R9)									
  module.go:48416	0x6564f8		4c8b4838		MOVQ 0x38(AX), R9										
  module.go:48416	0x6564fc		0f1f4000		NOPL 0(AX)											
  module.go:62928	0x656500		4981f97fce1000		CMPQ R9, $0x10ce7f										
  module.go:62928	0x656507		0f867d0a0000		JBE 0x656f8a											
  module.go:48417	0x65650d		90			NOPL												
  module.go:62928	0x65650e		4981f983ce1000		CMPQ R9, $0x10ce83										
  module.go:62928	0x656515		0f86630a0000		JBE 0x656f7e											
  module.go:48416	0x65651b		488b5030		MOVQ 0x30(AX), DX										
  module.go:48419	0x65651f		4589c1			MOVL R8, R9											
  module.go:48419	0x656522		4c894c2468		MOVQ R9, 0x68(SP)										
  module.go:62929	0x656527		8b8a7cce1000		MOVL 0x10ce7c(DX), CX										
  module.go:62929	0x65652d		8bba80ce1000		MOVL 0x10ce80(DX), DI										
  module.go:48418	0x656533		4889de			MOVQ BX, SI											
  module.go:48418	0x656536		4489c3			MOVL R8, BX											
  module.go:48418	0x656539		e862d2f8ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn84(SB)			
  module.go:48419	0x65653e		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48419	0x656546		488b5038		MOVQ 0x38(AX), DX										
  module.go:62928	0x65654a		4c8b442468		MOVQ 0x68(SP), R8										
  module.go:62928	0x65654f		4d8d4807		LEAQ 0x7(R8), R9										
  module.go:62928	0x656553		4c39ca			CMPQ DX, R9											
  module.go:62928	0x656556		0f861d0a0000		JBE 0x656f79											
  module.go:48419	0x65655c		488b7030		MOVQ 0x30(AX), SI										
  module.go:62928	0x656560		498d7803		LEAQ 0x3(R8), DI										
  module.go:48426	0x656564		90			NOPL												
  module.go:62929	0x656565		418b4c3004		MOVL 0x4(R8)(SI*1), CX										
  module.go:62928	0x65656a		4839fa			CMPQ DX, DI											
  module.go:62928	0x65656d		0f86010a0000		JBE 0x656f74											
  module.go:62929	0x656573		8b5c2420		MOVL 0x20(SP), BX										
  module.go:62929	0x656577		4189da			MOVL BX, R10											
  module.go:62929	0x65657a		458b1c32		MOVL 0(R10)(SI*1), R11										
  module.go:62929	0x65657e		6690			NOPW												
  module.go:48428	0x656580		4183fbff		CMPL R11, $-0x1											
  module.go:48428	0x656584		7418			JE 0x65659e											
  module.go:62954	0x656586		4d8d600f		LEAQ 0xf(R8), R12										
  module.go:48429	0x65658a		90			NOPL												
  module.go:62954	0x65658b		4c39e2			CMPQ DX, R12											
  module.go:62954	0x65658e		0f86db090000		JBE 0x656f6f											
  module.go:62955	0x656594		498b543008		MOVQ 0x8(R8)(SI*1), DX										
  module.go:48431	0x656599		e926070000		JMP 0x656cc4											
  module.go:62928	0x65659e		4c894c2460		MOVQ R9, 0x60(SP)										
  module.go:62928	0x6565a3		48897c2458		MOVQ DI, 0x58(SP)										
  module.go:62929	0x6565a8		4c89542450		MOVQ R10, 0x50(SP)										
  module.go:48433	0x6565ad		8b5050			MOVL 0x50(AX), DX										
  module.go:48433	0x6565b0		89542428		MOVL DX, 0x28(SP)										
  module.go:48434	0x6565b4		8d72c0			LEAL -0x40(DX), SI										
  module.go:48435	0x6565b7		897050			MOVL SI, 0x50(AX)										
  unsafe.go:35		0x6565ba		f20f10842490000000	MOVSD_XMM 0x90(SP), X0										
  unsafe.go:35		0x6565c3		66490f7ec3		MOVQ X0, R11											
  module.go:48438	0x6565c8		4d89dc			MOVQ R11, R12											
  module.go:48438	0x6565cb		490fbaf33f		BTRQ $0x3f, R11											
  module.go:48444	0x6565d0		4d8d6c24ff		LEAQ -0x1(R12), R13										
  module.go:48449	0x6565d5		49bf000000000000f0ff	MOVQ $0xfff0000000000000, R15									
  module.go:48449	0x6565df		4d01df			ADDQ R11, R15											
  module.go:48437	0x6565e2		90			NOPL												
  module.go:48440	0x6565e3		4d85db			TESTQ R11, R11											
  module.go:48440	0x6565e6		410f94c3		SETE R11											
  module.go:48443	0x6565ea		450fb6db		MOVZX R11, R11											
  module.go:48444	0x6565ee		49b8ffffffffffff0f00	MOVQ $0xfffffffffffff, R8									
  module.go:48444	0x6565f8		4d39e8			CMPQ R8, R13											
  module.go:48444	0x6565fb		410f97c0		SETA R8												
  module.go:48447	0x6565ff		450fb6c0		MOVZX R8, R8											
  module.go:48447	0x656603		4509c3			ORL R8, R11											
  module.go:48449	0x656606		49b8000000000000e07f	MOVQ $0x7fe0000000000000, R8									
  module.go:48449	0x656610		4d39f8			CMPQ R8, R15											
  module.go:48449	0x656613		410f97c0		SETA R8												
  module.go:48452	0x656617		450fb6c0		MOVZX R8, R8											
  module.go:48453	0x65661b		4d85e4			TESTQ R12, R12											
  module.go:48453	0x65661e		410f9dc4		SETGE R12											
  module.go:48456	0x656622		450fb6e4		MOVZX R12, R12											
  module.go:48456	0x656626		4521e0			ANDL R12, R8											
  module.go:48456	0x656629		4509d8			ORL R11, R8											
  module.go:48456	0x65662c		4585c0			TESTL R8, R8											
  module.go:48456	0x65662f		0f8493030000		JE 0x6569c8											
  module.go:48434	0x656635		89742424		MOVL SI, 0x24(SP)										
  module.go:48480	0x656639		8d5ac8			LEAL -0x38(DX), BX										
  module.go:48480	0x65663c		0f1f4000		NOPL 0(AX)											
  module.go:48480	0x656640		e8db98fdff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn176(SB)			
  module.go:48481	0x656645		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48481	0x65664d		488b5038		MOVQ 0x38(AX), DX										
  module.go:48481	0x656651		8b742424		MOVL 0x24(SP), SI										
  module.go:48481	0x656655		89f6			MOVL SI, SI											
  module.go:62928	0x656657		488d7e0b		LEAQ 0xb(SI), DI										
  module.go:62928	0x65665b		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:62928	0x656660		4839fa			CMPQ DX, DI											
  module.go:62928	0x656663		0f8601090000		JBE 0x656f6a											
  module.go:48481	0x656669		488b7830		MOVQ 0x30(AX), DI										
  module.go:62929	0x65666d		448b443e08		MOVL 0x8(SI)(DI*1), R8										
  module.go:48483	0x656672		4585c0			TESTL R8, R8											
  module.go:48483	0x656675		7536			JNE 0x6566ad											
  module.go:48519	0x656677		90			NOPL												
  module.go:62945	0x656678		488b4c2458		MOVQ 0x58(SP), CX										
  module.go:62945	0x65667d		0f1f00			NOPL 0(AX)											
  module.go:62945	0x656680		4839ca			CMPQ DX, CX											
  module.go:62945	0x656683		0f86dc080000		JBE 0x656f65											
  module.go:62946	0x656689		488b542450		MOVQ 0x50(SP), DX										
  module.go:62946	0x65668e		c70417ffffffff		MOVL $-0x1, 0(DI)(DX*1)										
  module.go:62954	0x656695		488b742468		MOVQ 0x68(SP), SI										
  module.go:62928	0x65669a		488b7c2460		MOVQ 0x60(SP), DI										
  module.go:62928	0x65669f		4989c8			MOVQ CX, R8											
  module.go:62929	0x6566a2		4989d1			MOVQ DX, R9											
  module.go:48522	0x6566a5		4889c1			MOVQ AX, CX											
  module.go:48522	0x6566a8		e9cf040000		JMP 0x656b7c											
  module.go:62928	0x6566ad		4c8d4e0f		LEAQ 0xf(SI), R9										
  module.go:48484	0x6566b1		90			NOPL												
  module.go:62928	0x6566b2		4c39ca			CMPQ DX, R9											
  module.go:62928	0x6566b5		0f86a3080000		JBE 0x656f5e											
  module.go:62945	0x6566bb		4c8d4e2b		LEAQ 0x2b(SI), R9										
  module.go:48486	0x6566bf		90			NOPL												
  module.go:62929	0x6566c0		448b543e0c		MOVL 0xc(SI)(DI*1), R10										
  module.go:62945	0x6566c5		4c39ca			CMPQ DX, R9											
  module.go:62945	0x6566c8		0f868b080000		JBE 0x656f59											
  module.go:62946	0x6566ce		c7443e2800000000	MOVL $0x0, 0x28(SI)(DI*1)									
  module.go:48487	0x6566d6		488b7838		MOVQ 0x38(AX), DI										
  module.go:62971	0x6566da		4c8d5e27		LEAQ 0x27(SI), R11										
  module.go:62971	0x6566de		6690			NOPW												
  module.go:62971	0x6566e0		4c39df			CMPQ DI, R11											
  module.go:62971	0x6566e3		0f866b080000		JBE 0x656f54											
  module.go:48487	0x6566e9		488b7830		MOVQ 0x30(AX), DI										
  module.go:62972	0x6566ed		49bc0000000001000000	MOVQ $0x100000000, R12										
  module.go:62972	0x6566f7		4c89643e20		MOVQ R12, 0x20(SI)(DI*1)									
  module.go:48488	0x6566fc		488b7838		MOVQ 0x38(AX), DI										
  module.go:62945	0x656700		4c8d6633		LEAQ 0x33(SI), R12										
  module.go:62945	0x656704		4c39e7			CMPQ DI, R12											
  module.go:62945	0x656707		0f8642080000		JBE 0x656f4f											
  module.go:48488	0x65670d		488b7830		MOVQ 0x30(AX), DI										
  module.go:62946	0x656711		c7443e30c81a1000	MOVL $0x101ac8, 0x30(SI)(DI*1)									
  module.go:48489	0x656719		488b7838		MOVQ 0x38(AX), DI										
  module.go:62971	0x65671d		4c8d663b		LEAQ 0x3b(SI), R12										
  module.go:62971	0x656721		4c39e7			CMPQ DI, R12											
  module.go:62971	0x656724		0f8620080000		JBE 0x656f4a											
  module.go:48489	0x65672a		488b7830		MOVQ 0x30(AX), DI										
  module.go:62972	0x65672e		48c7443e3420000060	MOVQ $0x60000020, 0x34(SI)(DI*1)								
  module.go:48490	0x656737		488b7838		MOVQ 0x38(AX), DI										
  module.go:62945	0x65673b		4c8d662f		LEAQ 0x2f(SI), R12										
  module.go:62945	0x65673f		90			NOPL												
  module.go:62945	0x656740		4c39e7			CMPQ DI, R12											
  module.go:62945	0x656743		0f86fc070000		JBE 0x656f45											
  module.go:48490	0x656749		488b7830		MOVQ 0x30(AX), DI										
  module.go:48490	0x65674d		8b5c2428		MOVL 0x28(SP), BX										
  module.go:48490	0x656751		448d63e0		LEAL -0x20(BX), R12										
  module.go:62946	0x656755		4489643e2c		MOVL R12, 0x2c(SI)(DI*1)									
  module.go:48491	0x65675a		488b7838		MOVQ 0x38(AX), DI										
  module.go:62928	0x65675e		4d8d6213		LEAQ 0x13(R10), R12										
  module.go:62928	0x656762		4c39e7			CMPQ DI, R12											
  module.go:62928	0x656765		0f86d3070000		JBE 0x656f3e											
  module.go:48491	0x65676b		488b7830		MOVQ 0x30(AX), DI										
  module.go:62929	0x65676f		498d3c3a		LEAQ 0(R10)(DI*1), DI										
  module.go:62929	0x656773		488d7f10		LEAQ 0x10(DI), DI										
  module.go:62929	0x656777		48633f			MOVSXD 0(DI), DI										
  module.go:62929	0x65677a		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:63109	0x656780		48397808		CMPQ 0x8(AX), DI										
  module.go:63109	0x656784		0f86a1070000		JBE 0x656f2b											
  module.go:48492	0x65678a		48c1e704		SHLQ $0x4, DI											
  module.go:48492	0x65678e		4c8b20			MOVQ 0(AX), R12											
  module.go:48492	0x656791		4e8b2c27		MOVQ 0(DI)(R12*1), R13										
  module.go:48492	0x656795		4a8b542708		MOVQ 0x8(DI)(R12*1), DX										
  module.go:48492	0x65679a		488d3dbf4f2000		LEAQ 0x204fbf(IP), DI										
  module.go:48492	0x6567a1		4939fd			CMPQ R13, DI											
  module.go:48492	0x6567a4		0f856f070000		JNE 0x656f19											
  module.go:48481	0x6567aa		4889742448		MOVQ SI, 0x48(SP)										
  module.go:62929	0x6567af		4489442434		MOVL R8, 0x34(SP)										
  module.go:62929	0x6567b4		4489542430		MOVL R10, 0x30(SP)										
  module.go:62945	0x6567b9		4c894c2440		MOVQ R9, 0x40(SP)										
  module.go:62971	0x6567be		4c895c2438		MOVQ R11, 0x38(SP)										
  module.go:48492	0x6567c3		488b0a			MOVQ 0(DX), CX											
  module.go:48492	0x6567c6		83c3ec			ADDL $-0x14, BX											
  module.go:48492	0x6567c9		4489c0			MOVL R8, AX											
  module.go:48492	0x6567cc		ffd1			CALL CX												
  module.go:48493	0x6567ce		85c0			TESTL AX, AX											
  module.go:48493	0x6567d0		0f8508070000		JNE 0x656ede											
  module.go:48497	0x6567d6		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48497	0x6567de		488b7038		MOVQ 0x38(AX), SI										
  module.go:62928	0x6567e2		488b7c2440		MOVQ 0x40(SP), DI										
  module.go:62928	0x6567e7		4839fe			CMPQ SI, DI											
  module.go:62928	0x6567ea		0f86e9060000		JBE 0x656ed9											
  module.go:48497	0x6567f0		488b7830		MOVQ 0x30(AX), DI										
  module.go:62945	0x6567f4		4c8b442448		MOVQ 0x48(SP), R8										
  module.go:62945	0x6567f9		4d8d481b		LEAQ 0x1b(R8), R9										
  module.go:48498	0x6567fd		90			NOPL												
  module.go:62929	0x6567fe		458b543828		MOVL 0x28(R8)(DI*1), R10									
  module.go:62945	0x656803		4c39ce			CMPQ SI, R9											
  module.go:62945	0x656806		0f86c8060000		JBE 0x656ed4											
  module.go:62946	0x65680c		4589543818		MOVL R10, 0x18(R8)(DI*1)									
  module.go:48499	0x656811		488b7038		MOVQ 0x38(AX), SI										
  module.go:62954	0x656815		488b7c2438		MOVQ 0x38(SP), DI										
  module.go:62954	0x65681a		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:62954	0x656820		4839fe			CMPQ SI, DI											
  module.go:62954	0x656823		0f86a6060000		JBE 0x656ecf											
  module.go:48499	0x656829		488b7830		MOVQ 0x30(AX), DI										
  module.go:62971	0x65682d		4d8d5017		LEAQ 0x17(R8), R10										
  module.go:48500	0x656831		90			NOPL												
  module.go:62955	0x656832		4d8b5c3820		MOVQ 0x20(R8)(DI*1), R11									
  module.go:62955	0x656837		660f1f840000000000	NOPW 0(AX)(AX*1)										
  module.go:62971	0x656840		4c39d6			CMPQ SI, R10											
  module.go:62971	0x656843		0f8681060000		JBE 0x656eca											
  module.go:62972	0x656849		4d895c3810		MOVQ R11, 0x10(R8)(DI*1)									
  module.go:48501	0x65684e		488b7038		MOVQ 0x38(AX), SI										
  module.go:62928	0x656852		8b7c2430		MOVL 0x30(SP), DI										
  module.go:62928	0x656856		4c8d5f03		LEAQ 0x3(DI), R11										
  module.go:62928	0x65685a		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:62928	0x656860		4c39de			CMPQ SI, R11											
  module.go:62928	0x656863		0f865c060000		JBE 0x656ec5											
  module.go:62945	0x656869		4c894c2440		MOVQ R9, 0x40(SP)										
  module.go:62971	0x65686e		4c89542438		MOVQ R10, 0x38(SP)										
  module.go:48501	0x656873		488b7030		MOVQ 0x30(AX), SI										
  module.go:62929	0x656877		8b3437			MOVL 0(DI)(SI*1), SI										
  module.go:48503	0x65687a		85f6			TESTL SI, SI											
  module.go:48503	0x65687c		7451			JE 0x6568cf											
  module.go:48504	0x65687e		4863f6			MOVSXD SI, SI											
  module.go:63109	0x656881		48397008		CMPQ 0x8(AX), SI										
  module.go:63109	0x656885		0f8622060000		JBE 0x656ead											
  module.go:48504	0x65688b		48c1e604		SHLQ $0x4, SI											
  module.go:48504	0x65688f		4c8b18			MOVQ 0(AX), R11											
  module.go:48504	0x656892		4e8b241e		MOVQ 0(SI)(R11*1), R12										
  module.go:48504	0x656896		4a8b541e08		MOVQ 0x8(SI)(R11*1), DX										
  module.go:48504	0x65689b		488d1d3e601f00		LEAQ 0x1f603e(IP), BX										
  module.go:48504	0x6568a2		4939dc			CMPQ R12, BX											
  module.go:48504	0x6568a5		0f85f3050000		JNE 0x656e9e											
  module.go:48504	0x6568ab		488b0a			MOVQ 0(DX), CX											
  module.go:48504	0x6568ae		8b442434		MOVL 0x34(SP), AX										
  module.go:48504	0x6568b2		ffd1			CALL CX												
  module.go:48506	0x6568b4		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:62928	0x6568bc		8b7c2430		MOVL 0x30(SP), DI										
  module.go:62929	0x6568c0		4c8b442448		MOVQ 0x48(SP), R8										
  module.go:62928	0x6568c5		4c8b4c2440		MOVQ 0x40(SP), R9										
  module.go:62954	0x6568ca		4c8b542438		MOVQ 0x38(SP), R10										
  module.go:48506	0x6568cf		488b5038		MOVQ 0x38(AX), DX										
  module.go:62928	0x6568d3		488d7707		LEAQ 0x7(DI), SI										
  module.go:62928	0x6568d7		660f1f840000000000	NOPW 0(AX)(AX*1)										
  module.go:62928	0x6568e0		4839f2			CMPQ DX, SI											
  module.go:62928	0x6568e3		0f86b0050000		JBE 0x656e99											
  module.go:48506	0x6568e9		488b7030		MOVQ 0x30(AX), SI										
  module.go:62929	0x6568ed		8b4c3704		MOVL 0x4(DI)(SI*1), CX										
  module.go:48508	0x6568f1		85c9			TESTL CX, CX											
  module.go:48508	0x6568f3		7434			JE 0x656929											
  module.go:62928	0x6568f5		488d770b		LEAQ 0xb(DI), SI										
  module.go:48509	0x6568f9		90			NOPL												
  module.go:48509	0x6568fa		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:62928	0x656900		4839f2			CMPQ DX, SI											
  module.go:62928	0x656903		0f868b050000		JBE 0x656e94											
  module.go:48510	0x656909		8b5c2434		MOVL 0x34(SP), BX										
  module.go:48510	0x65690d		e8ce56f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn1(SB)			
  module.go:48512	0x656912		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:62929	0x65691a		4c8b442448		MOVQ 0x48(SP), R8										
  module.go:62928	0x65691f		4c8b4c2440		MOVQ 0x40(SP), R9										
  module.go:62954	0x656924		4c8b542438		MOVQ 0x38(SP), R10										
  module.go:48512	0x656929		488b4838		MOVQ 0x38(AX), CX										
  module.go:62928	0x65692d		4c39c9			CMPQ CX, R9											
  module.go:62928	0x656930		0f8659050000		JBE 0x656e8f											
  module.go:48512	0x656936		488b5030		MOVQ 0x30(AX), DX										
  module.go:62945	0x65693a		488b742468		MOVQ 0x68(SP), SI										
  module.go:62945	0x65693f		488d7e0b		LEAQ 0xb(SI), DI										
  module.go:48513	0x656943		90			NOPL												
  module.go:62929	0x656944		458b4c1018		MOVL 0x18(R8)(DX*1), R9										
  module.go:62945	0x656949		4839f9			CMPQ CX, DI											
  module.go:62945	0x65694c		0f8638050000		JBE 0x656e8a											
  module.go:62946	0x656952		44894c1608		MOVL R9, 0x8(SI)(DX*1)										
  module.go:48514	0x656957		488b4838		MOVQ 0x38(AX), CX										
  module.go:48514	0x65695b		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:62954	0x656960		4c39d1			CMPQ CX, R10											
  module.go:62954	0x656963		0f861c050000		JBE 0x656e85											
  module.go:48514	0x656969		488b5030		MOVQ 0x30(AX), DX										
  module.go:48515	0x65696d		90			NOPL												
  module.go:62955	0x65696e		498b7c1010		MOVQ 0x10(R8)(DX*1), DI										
  module.go:62971	0x656973		4c8b442460		MOVQ 0x60(SP), R8										
  module.go:62971	0x656978		0f1f840000000000	NOPL 0(AX)(AX*1)										
  module.go:62971	0x656980		4c39c1			CMPQ CX, R8											
  module.go:62971	0x656983		0f86f5040000		JBE 0x656e7e											
  module.go:62972	0x656989		488b4c2450		MOVQ 0x50(SP), CX										
  module.go:62972	0x65698e		48893c0a		MOVQ DI, 0(DX)(CX*1)										
  module.go:48516	0x656992		488b5038		MOVQ 0x38(AX), DX										
  module.go:62945	0x656996		488d7e0f		LEAQ 0xf(SI), DI										
  module.go:62945	0x65699a		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:62945	0x6569a0		4839fa			CMPQ DX, DI											
  module.go:62945	0x6569a3		0f86d0040000		JBE 0x656e79											
  module.go:48516	0x6569a9		488b5030		MOVQ 0x30(AX), DX										
  module.go:62946	0x6569ad		c744160c01000000	MOVL $0x1, 0xc(SI)(DX*1)									
  module.go:62928	0x6569b5		4c89c7			MOVQ R8, DI											
  module.go:62928	0x6569b8		4c8b442458		MOVQ 0x58(SP), R8										
  module.go:62929	0x6569bd		4989c9			MOVQ CX, R9											
  module.go:48522	0x6569c0		4889c1			MOVQ AX, CX											
  module.go:48517	0x6569c3		e9b4010000		JMP 0x656b7c											
  module.go:48457	0x6569c8		bb2c000000		MOVL $0x2c, BX											
  module.go:48457	0x6569cd		b901000000		MOVL $0x1, CX											
  module.go:48457	0x6569d2		e88959f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn4(SB)			
  module.go:48459	0x6569d7		85c0			TESTL AX, AX											
  module.go:48459	0x6569d9		0f8470040000		JE 0x656e4f											
  module.go:48463	0x6569df		488b8c2480000000	MOVQ 0x80(SP), CX										
  module.go:48463	0x6569e7		488b5138		MOVQ 0x38(CX), DX										
  module.go:62971	0x6569eb		488b742468		MOVQ 0x68(SP), SI										
  module.go:62971	0x6569f0		488d7e0f		LEAQ 0xf(SI), DI										
  module.go:62971	0x6569f4		4839fa			CMPQ DX, DI											
  module.go:62971	0x6569f7		0f864d040000		JBE 0x656e4a											
  module.go:48463	0x6569fd		488b5130		MOVQ 0x30(CX), DX										
  module.go:62972	0x656a01		48bf2c00000002000000	MOVQ $0x20000002c, DI										
  module.go:62972	0x656a0b		48897c1608		MOVQ DI, 0x8(SI)(DX*1)										
  module.go:48464	0x656a10		488b5138		MOVQ 0x38(CX), DX										
  module.go:62945	0x656a14		488b7c2460		MOVQ 0x60(SP), DI										
  module.go:62945	0x656a19		0f1f8000000000		NOPL 0(AX)											
  module.go:62945	0x656a20		4839fa			CMPQ DX, DI											
  module.go:62945	0x656a23		0f861c040000		JBE 0x656e45											
  module.go:48464	0x656a29		488b5130		MOVQ 0x30(CX), DX										
  module.go:62946	0x656a2d		89441604		MOVL AX, 0x4(SI)(DX*1)										
  module.go:48465	0x656a31		488b5138		MOVQ 0x38(CX), DX										
  module.go:62945	0x656a35		4c8b442458		MOVQ 0x58(SP), R8										
  module.go:62945	0x656a3a		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:62945	0x656a40		4c39c2			CMPQ DX, R8											
  module.go:62945	0x656a43		0f86f3030000		JBE 0x656e3c											
  module.go:48465	0x656a49		488b5130		MOVQ 0x30(CX), DX										
  module.go:62946	0x656a4d		4c8b4c2450		MOVQ 0x50(SP), R9										
  module.go:62946	0x656a52		42c7040a2c000000	MOVL $0x2c, 0(DX)(R9*1)										
  module.go:48466	0x656a5a		488b5138		MOVQ 0x38(CX), DX										
  module.go:48466	0x656a5e		6690			NOPW												
  module.go:62928	0x656a60		4881fa9b191000		CMPQ DX, $0x10199b										
  module.go:62928	0x656a67		0f86c3030000		JBE 0x656e30											
  module.go:48467	0x656a6d		4189c2			MOVL AX, R10											
  module.go:62945	0x656a70		4d8d5a2b		LEAQ 0x2b(R10), R11										
  module.go:62945	0x656a74		4c39da			CMPQ DX, R11											
  module.go:62945	0x656a77		0f86ae030000		JBE 0x656e2b											
  module.go:48466	0x656a7d		488b5130		MOVQ 0x30(CX), DX										
  module.go:62929	0x656a81		448b9a98191000		MOVL 0x101998(DX), R11										
  module.go:62946	0x656a88		45895c1228		MOVL R11, 0x28(R10)(DX*1)									
  module.go:48468	0x656a8d		488b5138		MOVQ 0x38(CX), DX										
  module.go:62954	0x656a91		4881fa97191000		CMPQ DX, $0x101997										
  module.go:62954	0x656a98		0f8681030000		JBE 0x656e1f											
  module.go:62971	0x656a9e		4d8d5a27		LEAQ 0x27(R10), R11										
  module.go:48469	0x656aa2		90			NOPL												
  module.go:62971	0x656aa3		4c39da			CMPQ DX, R11											
  module.go:62971	0x656aa6		0f866e030000		JBE 0x656e1a											
  module.go:48468	0x656aac		488b5130		MOVQ 0x30(CX), DX										
  module.go:62955	0x656ab0		4c8b9a90191000		MOVQ 0x101990(DX), R11										
  module.go:62972	0x656ab7		4d895c1220		MOVQ R11, 0x20(R10)(DX*1)									
  module.go:48470	0x656abc		488b5138		MOVQ 0x38(CX), DX										
  module.go:62954	0x656ac0		4881fa8f191000		CMPQ DX, $0x10198f										
  module.go:62954	0x656ac7		0f8641030000		JBE 0x656e0e											
  module.go:62971	0x656acd		4d8d5a1f		LEAQ 0x1f(R10), R11										
  module.go:48471	0x656ad1		90			NOPL												
  module.go:62971	0x656ad2		4c39da			CMPQ DX, R11											
  module.go:62971	0x656ad5		0f862e030000		JBE 0x656e09											
  module.go:48470	0x656adb		488b5130		MOVQ 0x30(CX), DX										
  module.go:62955	0x656adf		4c8b9a88191000		MOVQ 0x101988(DX), R11										
  module.go:62972	0x656ae6		4d895c1218		MOVQ R11, 0x18(R10)(DX*1)									
  module.go:48472	0x656aeb		488b5138		MOVQ 0x38(CX), DX										
  module.go:62954	0x656aef		4881fa87191000		CMPQ DX, $0x101987										
  module.go:62954	0x656af6		0f8601030000		JBE 0x656dfd											
  module.go:62971	0x656afc		4d8d5a17		LEAQ 0x17(R10), R11										
  module.go:48473	0x656b00		90			NOPL												
  module.go:62971	0x656b01		4c39da			CMPQ DX, R11											
  module.go:62971	0x656b04		0f86ee020000		JBE 0x656df8											
  module.go:48472	0x656b0a		488b5130		MOVQ 0x30(CX), DX										
  module.go:62955	0x656b0e		4c8b9a80191000		MOVQ 0x101980(DX), R11										
  module.go:62972	0x656b15		4d895c1210		MOVQ R11, 0x10(R10)(DX*1)									
  module.go:48474	0x656b1a		488b5138		MOVQ 0x38(CX), DX										
  module.go:48474	0x656b1e		6690			NOPW												
  module.go:62954	0x656b20		4881fa7f191000		CMPQ DX, $0x10197f										
  module.go:62954	0x656b27		0f86bf020000		JBE 0x656dec											
  module.go:62971	0x656b2d		4d8d5a0f		LEAQ 0xf(R10), R11										
  module.go:48475	0x656b31		90			NOPL												
  module.go:62971	0x656b32		4c39da			CMPQ DX, R11											
  module.go:62971	0x656b35		0f86ac020000		JBE 0x656de7											
  module.go:48474	0x656b3b		488b5130		MOVQ 0x30(CX), DX										
  module.go:62955	0x656b3f		4c8b9a78191000		MOVQ 0x101978(DX), R11										
  module.go:62972	0x656b46		4d895c1208		MOVQ R11, 0x8(R10)(DX*1)									
  module.go:48476	0x656b4b		488b5138		MOVQ 0x38(CX), DX										
  module.go:62954	0x656b4f		4881fa77191000		CMPQ DX, $0x101977										
  module.go:62954	0x656b56		0f867f020000		JBE 0x656ddb											
  module.go:62971	0x656b5c		4983c207		ADDQ $0x7, R10											
  module.go:48477	0x656b60		90			NOPL												
  module.go:62971	0x656b61		4c39d2			CMPQ DX, R10											
  module.go:62971	0x656b64		0f866c020000		JBE 0x656dd6											
  module.go:48476	0x656b6a		488b5130		MOVQ 0x30(CX), DX										
  module.go:62955	0x656b6e		4c8b9270191000		MOVQ 0x101970(DX), R10										
  module.go:62972	0x656b75		4189c3			MOVL AX, R11											
  module.go:62972	0x656b78		4e89141a		MOVQ R10, 0(DX)(R11*1)										
  module.go:48522	0x656b7c		8b542428		MOVL 0x28(SP), DX										
  module.go:48522	0x656b80		895150			MOVL DX, 0x50(CX)										
  module.go:48525	0x656b83		488b5138		MOVQ 0x38(CX), DX										
  module.go:62928	0x656b87		4c39c2			CMPQ DX, R8											
  module.go:62928	0x656b8a		0f8641020000		JBE 0x656dd1											
  module.go:48525	0x656b90		4c8b5130		MOVQ 0x30(CX), R10										
  module.go:62929	0x656b94		478b1c11		MOVL 0(R9)(R10*1), R11										
  module.go:62929	0x656b98		0f1f840000000000	NOPL 0(AX)(AX*1)										
  module.go:48527	0x656ba0		4183fbff		CMPL R11, $-0x1											
  module.go:48527	0x656ba4		0f85e2000000		JNE 0x656c8c											
  module.go:48547	0x656baa		90			NOPL												
  module.go:62928	0x656bab		4881fa73ce1000		CMPQ DX, $0x10ce73										
  module.go:62928	0x656bb2		0f860d020000		JBE 0x656dc5											
  module.go:48548	0x656bb8		90			NOPL												
  module.go:62946	0x656bb9		41ff8270ce1000		INCL 0x10ce70(R10)										
  module.go:48549	0x656bc0		488b5138		MOVQ 0x38(CX), DX										
  module.go:48549	0x656bc4		4881fafccf1000		CMPQ DX, $0x10cffc										
  module.go:48549	0x656bcb		0f86e4010000		JBE 0x656db5											
  module.go:48549	0x656bd1		488b5130		MOVQ 0x30(CX), DX										
  module.go:48549	0x656bd5		0fb692fccf1000		MOVZX 0x10cffc(DX), DX										
  module.go:48549	0x656bdc		0f1f4000		NOPL 0(AX)											
  module.go:48550	0x656be0		83fa01			CMPL DX, $0x1											
  module.go:48550	0x656be3		7410			JE 0x656bf5											
  module.go:48551	0x656be5		4889c8			MOVQ CX, AX											
  module.go:48551	0x656be8		e8d308fbff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn105(SB)			
  module.go:48553	0x656bed		488b8c2480000000	MOVQ 0x80(SP), CX										
  module.go:48553	0x656bf5		488b5138		MOVQ 0x38(CX), DX										
  module.go:48553	0x656bf9		0f1f8000000000		NOPL 0(AX)											
  module.go:62928	0x656c00		4881fad3cf1000		CMPQ DX, $0x10cfd3										
  module.go:62928	0x656c07		0f869c010000		JBE 0x656da9											
  module.go:48553	0x656c0d		488b7130		MOVQ 0x30(CX), SI										
  module.go:62929	0x656c11		83bed0cf100000		CMPL 0x10cfd0(SI), $0x0										
  module.go:48554	0x656c18		0f856b010000		JNE 0x656d89											
  module.go:48558	0x656c1e		90			NOPL												
  module.go:48558	0x656c1f		90			NOPL												
  module.go:62928	0x656c20		4881fae7cf1000		CMPQ DX, $0x10cfe7										
  module.go:62928	0x656c27		0f8650010000		JBE 0x656d7d											
  module.go:48559	0x656c2d		90			NOPL												
  module.go:62945	0x656c2e		4881faefcf1000		CMPQ DX, $0x10cfef										
  module.go:62945	0x656c35		0f8636010000		JBE 0x656d71											
  module.go:62929	0x656c3b		8b96e4cf1000		MOVL 0x10cfe4(SI), DX										
  module.go:62946	0x656c41		8996eccf1000		MOVL DX, 0x10cfec(SI)										
  module.go:48560	0x656c47		488b5138		MOVQ 0x38(CX), DX										
  module.go:62945	0x656c4b		4881faebcf1000		CMPQ DX, $0x10cfeb										
  module.go:62945	0x656c52		0f860d010000		JBE 0x656d65											
  module.go:48560	0x656c58		488b5130		MOVQ 0x30(CX), DX										
  module.go:62946	0x656c5c		c782e8cf100000000000	MOVL $0x0, 0x10cfe8(DX)										
  module.go:48561	0x656c66		488b5138		MOVQ 0x38(CX), DX										
  module.go:62945	0x656c6a		4881faf3cf1000		CMPQ DX, $0x10cff3										
  module.go:62945	0x656c71		0f86dd000000		JBE 0x656d54											
  module.go:48561	0x656c77		488b5130		MOVQ 0x30(CX), DX										
  module.go:62946	0x656c7b		c782f0cf100000000000	MOVL $0x0, 0x10cff0(DX)										
  module.go:62946	0x656c85		31c0			XORL AX, AX											
  module.go:48564	0x656c87		e996000000		JMP 0x656d22											
  module.go:48530	0x656c8c		90			NOPL												
  module.go:62928	0x656c8d		4839fa			CMPQ DX, DI											
  module.go:62928	0x656c90		0f86b9000000		JBE 0x656d4f											
  module.go:62954	0x656c96		4c8d660f		LEAQ 0xf(SI), R12										
  module.go:48532	0x656c9a		90			NOPL												
  module.go:62929	0x656c9b		468b6c1604		MOVL 0x4(SI)(R10*1), R13									
  module.go:62954	0x656ca0		4c39e2			CMPQ DX, R12											
  module.go:62954	0x656ca3		0f86a1000000		JBE 0x656d4a											
  module.go:62955	0x656ca9		4a8b541608		MOVQ 0x8(SI)(R10*1), DX										
  module.go:48537	0x656cae		4889c8			MOVQ CX, AX											
  module.go:48542	0x656cb1		8b5c2420		MOVL 0x20(SP), BX										
  module.go:62946	0x656cb5		4d89ca			MOVQ R9, R10											
  module.go:48536	0x656cb8		4489e9			MOVL R13, CX											
  module.go:62945	0x656cbb		4989f9			MOVQ DI, R9											
  module.go:62945	0x656cbe		4c89c7			MOVQ R8, DI											
  module.go:62971	0x656cc1		4989f0			MOVQ SI, R8											
  module.go:48537	0x656cc4		488b7038		MOVQ 0x38(AX), SI										
  module.go:62928	0x656cc8		4881fe73ce1000		CMPQ SI, $0x10ce73										
  module.go:62928	0x656ccf		766d			JBE 0x656d3e											
  module.go:48537	0x656cd1		488b7030		MOVQ 0x30(AX), SI										
  module.go:62971	0x656cd5		4d8d600f		LEAQ 0xf(R8), R12										
  module.go:48538	0x656cd9		90			NOPL												
  module.go:62946	0x656cda		ff8670ce1000		INCL 0x10ce70(SI)										
  module.go:48539	0x656ce0		488b7038		MOVQ 0x38(AX), SI										
  module.go:62971	0x656ce4		4c39e6			CMPQ SI, R12											
  module.go:62971	0x656ce7		7650			JBE 0x656d39											
  module.go:48539	0x656ce9		488b7030		MOVQ 0x30(AX), SI										
  module.go:62972	0x656ced		4989543008		MOVQ DX, 0x8(R8)(SI*1)										
  module.go:48540	0x656cf2		488b5038		MOVQ 0x38(AX), DX										
  module.go:62945	0x656cf6		4c39ca			CMPQ DX, R9											
  module.go:62945	0x656cf9		7639			JBE 0x656d34											
  module.go:48540	0x656cfb		488b5030		MOVQ 0x30(AX), DX										
  module.go:62946	0x656cff		41894c1004		MOVL CX, 0x4(R8)(DX*1)										
  module.go:48541	0x656d04		488b4838		MOVQ 0x38(AX), CX										
  module.go:62945	0x656d08		4839f9			CMPQ CX, DI											
  module.go:62945	0x656d0b		7622			JBE 0x656d2f											
  module.go:48541	0x656d0d		488b4830		MOVQ 0x30(AX), CX										
  module.go:62946	0x656d11		46891c11		MOVL R11, 0(CX)(R10*1)										
  module.go:48542	0x656d15		e8a65cf8ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn60(SB)			
  module.go:48565	0x656d1a		488b8c2480000000	MOVQ 0x80(SP), CX										
  module.go:48565	0x656d22		8b54242c		MOVL 0x2c(SP), DX										
  module.go:48565	0x656d26		895150			MOVL DX, 0x50(CX)										
  module.go:48566	0x656d29		4883c470		ADDQ $0x70, SP											
  module.go:48566	0x656d2d		5d			POPQ BP												
  module.go:48566	0x656d2e		c3			RET												
  module.go:62945	0x656d2f		e88c9ce3ff		CALL runtime.panicBounds(SB)									
  module.go:62945	0x656d34		e8879ce3ff		CALL runtime.panicBounds(SB)									
  module.go:62971	0x656d39		e8829ce3ff		CALL runtime.panicBounds(SB)									
  module.go:62928	0x656d3e		48c7c073ce1000		MOVQ $0x10ce73, AX										
  module.go:62928	0x656d45		e8769ce3ff		CALL runtime.panicBounds(SB)									
  module.go:62954	0x656d4a		e8719ce3ff		CALL runtime.panicBounds(SB)									
  module.go:62928	0x656d4f		e86c9ce3ff		CALL runtime.panicBounds(SB)									
  module.go:62945	0x656d54		48c7c0f3cf1000		MOVQ $0x10cff3, AX										
  module.go:62945	0x656d5b		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:62945	0x656d60		e85b9ce3ff		CALL runtime.panicBounds(SB)									
  module.go:62945	0x656d65		48c7c0ebcf1000		MOVQ $0x10cfeb, AX										
  module.go:62945	0x656d6c		e84f9ce3ff		CALL runtime.panicBounds(SB)									
  module.go:62945	0x656d71		48c7c0efcf1000		MOVQ $0x10cfef, AX										
  module.go:62945	0x656d78		e8439ce3ff		CALL runtime.panicBounds(SB)									
  module.go:62928	0x656d7d		48c7c0e7cf1000		MOVQ $0x10cfe7, AX										
  module.go:62928	0x656d84		e8379ce3ff		CALL runtime.panicBounds(SB)									
  module.go:48555	0x656d89		4889c8			MOVQ CX, AX											
  module.go:48555	0x656d8c		bb60171000		MOVL $0x101760, BX										
  module.go:48555	0x656d91		e84ac2f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn24(SB)			
  module.go:48556	0x656d96		488d05833c1f00		LEAQ 0x1f3c83(IP), AX										
  module.go:48556	0x656d9d		488d1d4cb52a00		LEAQ 0x2ab54c(IP), BX										
  module.go:48556	0x656da4		e8371ae3ff		CALL runtime.gopanic(SB)									
  module.go:62928	0x656da9		48c7c0d3cf1000		MOVQ $0x10cfd3, AX										
  module.go:62928	0x656db0		e80b9ce3ff		CALL runtime.panicBounds(SB)									
  module.go:48549	0x656db5		48c7c0fccf1000		MOVQ $0x10cffc, AX										
  module.go:48549	0x656dbc		0f1f4000		NOPL 0(AX)											
  module.go:48549	0x656dc0		e8fb9be3ff		CALL runtime.panicBounds(SB)									
  module.go:62928	0x656dc5		48c7c073ce1000		MOVQ $0x10ce73, AX										
  module.go:62928	0x656dcc		e8ef9be3ff		CALL runtime.panicBounds(SB)									
  module.go:62928	0x656dd1		e8ea9be3ff		CALL runtime.panicBounds(SB)									
  module.go:62971	0x656dd6		e8e59be3ff		CALL runtime.panicBounds(SB)									
  module.go:62954	0x656ddb		48c7c077191000		MOVQ $0x101977, AX										
  module.go:62954	0x656de2		e8d99be3ff		CALL runtime.panicBounds(SB)									
  module.go:62971	0x656de7		e8d49be3ff		CALL runtime.panicBounds(SB)									
  module.go:62954	0x656dec		48c7c07f191000		MOVQ $0x10197f, AX										
  module.go:62954	0x656df3		e8c89be3ff		CALL runtime.panicBounds(SB)									
  module.go:62971	0x656df8		e8c39be3ff		CALL runtime.panicBounds(SB)									
  module.go:62954	0x656dfd		48c7c087191000		MOVQ $0x101987, AX										
  module.go:62954	0x656e04		e8b79be3ff		CALL runtime.panicBounds(SB)									
  module.go:62971	0x656e09		e8b29be3ff		CALL runtime.panicBounds(SB)									
  module.go:62954	0x656e0e		48c7c08f191000		MOVQ $0x10198f, AX										
  module.go:62954	0x656e15		e8a69be3ff		CALL runtime.panicBounds(SB)									
  module.go:62971	0x656e1a		e8a19be3ff		CALL runtime.panicBounds(SB)									
  module.go:62954	0x656e1f		48c7c097191000		MOVQ $0x101997, AX										
  module.go:62954	0x656e26		e8959be3ff		CALL runtime.panicBounds(SB)									
  module.go:62945	0x656e2b		e8909be3ff		CALL runtime.panicBounds(SB)									
  module.go:62928	0x656e30		48c7c09b191000		MOVQ $0x10199b, AX										
  module.go:62928	0x656e37		e8849be3ff		CALL runtime.panicBounds(SB)									
  module.go:62945	0x656e3c		0f1f4000		NOPL 0(AX)											
  module.go:62945	0x656e40		e87b9be3ff		CALL runtime.panicBounds(SB)									
  module.go:62945	0x656e45		e8769be3ff		CALL runtime.panicBounds(SB)									
  module.go:62971	0x656e4a		e8719be3ff		CALL runtime.panicBounds(SB)									
  module.go:48460	0x656e4f		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48460	0x656e57		bb01000000		MOVL $0x1, BX											
  module.go:48460	0x656e5c		b92c000000		MOVL $0x2c, CX											
  module.go:48460	0x656e61		e87a52f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn2(SB)			
  module.go:48461	0x656e66		488d05b33b1f00		LEAQ 0x1f3bb3(IP), AX										
  module.go:48461	0x656e6d		488d1d7cb42a00		LEAQ 0x2ab47c(IP), BX										
  module.go:48461	0x656e74		e86719e3ff		CALL runtime.gopanic(SB)									
  module.go:62945	0x656e79		e8429be3ff		CALL runtime.panicBounds(SB)									
  module.go:62971	0x656e7e		6690			NOPW												
  module.go:62971	0x656e80		e83b9be3ff		CALL runtime.panicBounds(SB)									
  module.go:62954	0x656e85		e8369be3ff		CALL runtime.panicBounds(SB)									
  module.go:62945	0x656e8a		e8319be3ff		CALL runtime.panicBounds(SB)									
  module.go:62928	0x656e8f		e82c9be3ff		CALL runtime.panicBounds(SB)									
  module.go:62928	0x656e94		e8279be3ff		CALL runtime.panicBounds(SB)									
  module.go:62928	0x656e99		e8229be3ff		CALL runtime.panicBounds(SB)									
  module.go:48504	0x656e9e		4c89e0			MOVQ R12, AX											
  module.go:48504	0x656ea1		488d0d784c2000		LEAQ 0x204c78(IP), CX										
  module.go:48504	0x656ea8		e8d372dcff		CALL runtime.panicdottypeE(SB)									
  module.go:63110	0x656ead		488d056c3b1f00		LEAQ 0x1f3b6c(IP), AX										
  module.go:63110	0x656eb4		488d1d85cb2a00		LEAQ 0x2acb85(IP), BX										
  module.go:63110	0x656ebb		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:63110	0x656ec0		e81b19e3ff		CALL runtime.gopanic(SB)									
  module.go:62928	0x656ec5		e8f69ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62971	0x656eca		e8f19ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62954	0x656ecf		e8ec9ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62945	0x656ed4		e8e79ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62928	0x656ed9		e8e29ae3ff		CALL runtime.panicBounds(SB)									
  module.go:48494	0x656ede		8b7c2428		MOVL 0x28(SP), DI										
  module.go:48494	0x656ee2		ffcf			DECL DI												
  module.go:48494	0x656ee4		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48494	0x656eec		bbf01a1000		MOVL $0x101af0, BX										
  module.go:48494	0x656ef1		b937000000		MOVL $0x37, CX											
  module.go:48494	0x656ef6		bee01a1000		MOVL $0x101ae0, SI										
  module.go:48494	0x656efb		41b8281b1000		MOVL $0x101b28, R8										
  module.go:48494	0x656f01		e89ac4f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn27(SB)			
  module.go:48495	0x656f06		488d05133b1f00		LEAQ 0x1f3b13(IP), AX										
  module.go:48495	0x656f0d		488d1ddcb32a00		LEAQ 0x2ab3dc(IP), BX										
  module.go:48495	0x656f14		e8c718e3ff		CALL runtime.gopanic(SB)									
  module.go:48492	0x656f19		4c89e8			MOVQ R13, AX											
  module.go:48492	0x656f1c		4889fb			MOVQ DI, BX											
  module.go:48492	0x656f1f		488d0dfa4b2000		LEAQ 0x204bfa(IP), CX										
  module.go:48492	0x656f26		e85572dcff		CALL runtime.panicdottypeE(SB)									
  module.go:63110	0x656f2b		488d05ee3a1f00		LEAQ 0x1f3aee(IP), AX										
  module.go:63110	0x656f32		488d1d07cb2a00		LEAQ 0x2acb07(IP), BX										
  module.go:63110	0x656f39		e8a218e3ff		CALL runtime.gopanic(SB)									
  module.go:62928	0x656f3e		6690			NOPW												
  module.go:62928	0x656f40		e87b9ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62945	0x656f45		e8769ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62971	0x656f4a		e8719ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62945	0x656f4f		e86c9ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62971	0x656f54		e8679ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62945	0x656f59		e8629ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62928	0x656f5e		6690			NOPW												
  module.go:62928	0x656f60		e85b9ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62945	0x656f65		e8569ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62928	0x656f6a		e8519ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62954	0x656f6f		e84c9ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62928	0x656f74		e8479ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62928	0x656f79		e8429ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62928	0x656f7e		48c7c083ce1000		MOVQ $0x10ce83, AX										
  module.go:62928	0x656f85		e8369ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62928	0x656f8a		48c7c07fce1000		MOVQ $0x10ce7f, AX										
  module.go:62928	0x656f91		e82a9ae3ff		CALL runtime.panicBounds(SB)									
  module.go:48568	0x656f96		bb60171000		MOVL $0x101760, BX										
  module.go:48568	0x656f9b		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:48568	0x656fa0		e83bc0f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn24(SB)			
  module.go:48569	0x656fa5		488d05743a1f00		LEAQ 0x1f3a74(IP), AX										
  module.go:48569	0x656fac		488d1d3db32a00		LEAQ 0x2ab33d(IP), BX										
  module.go:48569	0x656fb3		e82818e3ff		CALL runtime.gopanic(SB)									
  module.go:62928	0x656fb8		48c7c073ce1000		MOVQ $0x10ce73, AX										
  module.go:62928	0x656fbf		90			NOPL												
  module.go:62928	0x656fc0		e8fb99e3ff		CALL runtime.panicBounds(SB)									
  module.go:48408	0x656fc5		48c7c0b0cf1000		MOVQ $0x10cfb0, AX										
  module.go:48408	0x656fcc		e8ef99e3ff		CALL runtime.panicBounds(SB)									
  module.go:48408	0x656fd1		90			NOPL												
  module.go:48402	0x656fd2		4889442408		MOVQ AX, 0x8(SP)										
  module.go:48402	0x656fd7		48895c2410		MOVQ BX, 0x10(SP)										
  module.go:48402	0x656fdc		f20f11442418		MOVSD_XMM X0, 0x18(SP)										
  module.go:48402	0x656fe2		e8b97ce3ff		CALL runtime.morestack_noctxt.abi0(SB)								
  module.go:48402	0x656fe7		488b442408		MOVQ 0x8(SP), AX										
  module.go:48402	0x656fec		488b5c2410		MOVQ 0x10(SP), BX										
  module.go:48402	0x656ff1		f20f10442418		MOVSD_XMM 0x18(SP), X0										
  module.go:48402	0x656ff7		e944f4ffff		JMP dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).Xcocoon_sketch_add(SB)	
