# Adversarial final proof and timing readiness

Verdict: READY for the narrowly declared unsupported phase-0 avoided-computation diagnostic, after the root refreshes the final config with this note and every completed proof/input and freezes/reverifies it. No remaining extraction, index/domain, mode-control, executable-proof or measurement-plan blocker was identified. This is not production qualification, a generic transform proof, a certified interval/cache design, public-contract approval or M1 acceptance. This reviewer ran only source/data reads and hash checks; no builds/tests/lints/profiles/benchmarks or tracked edits.

## Completed evidence and precise proof scope

The mechanical original-source reconstruction requires the entire copied pure-kernel formatted text to equal the original fn176 region and requires caller text outside that region/dead v17 declaration to equal original. Its log-bit reference is a separate extraction utility operating on immutable original source, not an independent ln algorithm or a Wasm intermediate export. Current only-p17-live-out analysis and untouched surrounding state/effect code support this exact source-pinned substitution; no generic or continuum claim follows.

Both oracle modes on native amd64 and actual native386 verify all8,388,608 table entries and the actual wrapper against that reconstructed kernel, plus1,764 edge/broad bit cases including both zero signs, subnormal/normal thresholds, NaN payloads/infinities, fractions/reduction boundaries and table endpoints. A changed in-memory entry42 is observed only with runtime flag1 and restored at cleanup; flag0 still returns original kernel bits. Fractional, negative and high-domain values retain fallback. This proves actual dynamic path selection, not only equal outputs from two unexercised branches. The table file remains SHA48f45a3568b4ad0862e748c11372f46cc46fe3fcf80236965e11f7990d15314a and67,108,864 bytes.

Coverage scans explicitly enumerate the four original/warmed fixed-N input domains and verify0/1/0/8193miss counts. These scans check eligibility, not full Wasm state. Independent ORIGINAL Wasm comparisons replay COMPLETE SIX FINITE histories:16,384ascending points,16,384points starting8193, sampled4M/8Mboundary plus8Khigh/fallback tail, broad-collapse corpus, nearby unique points, negative logical bins/signedzero/subnormals. Every operation status/unit and full Count/protobuf checkpoint matches; invalid scalar and atomic invalid batch preserve complete state, valid recovery and stale/zero/generation handle cases are checked. Facade histories additionally cover Count/protobuf, shared aliases/closure, real guest reserve trap, epoch poison/no subsequent callback, fresh-home replacement, cancellation/library closure and actual memory-cap growth/poison. The native raw56-byte logical-header trap model preserves original offset-read endpoint63, no guest byte writes and expected stack value; it is explicitly not a valid Wasm shrink history.

There was NO every-input4M/8M original-Wasm replay. These are high-prefix BOUNDARY HISTORIES, not full-fixed-N independent Wasm qualification. RawGuest's timed harness checks Count=b.N after the full Go prefix, while bare original scalar retains its unchanged harness and has no post-loop Count/protobuf assertion. This precision is now pinned in decision-plan proof_scope before timing. For this unsupported diagnostic, exhaustive exact-kernel/table identity plus scoped unchanged caller/liveness and finite independent engine histories are sufficient; no additional millions-of-input Wasm replay is required. Any later production implementation needs its own authored predicate, complete safety/semantic proof and qualified guards.

All four functional configurations (baseline, outline, same oracle binary flag0/flag1), both packages and native amd64/actual386 pass. All FOUR rewritten-source mutants compile and then fail explicit named TestStructural semantic assertions on BOTH architectures: kernel bit, fallback, table bit, removed original offset read. Failure markers are structural-log mismatch or structural-caller mismatch; compiler/startup failure is not counted as successful mutant rejection. The final source-provenance hashes for38proof artifacts and20proof executables all independently match current bytes. Native386 run/build records are actual direct execution; no arm64 or real big-endian execution is claimed. Fixture expectation corrections and their failed logs remain preserved.

Root's actual-mode-whole records/logs show both flags0/1 run the ordinary runtime/all3fixture contracts/differential/bulk packages with exit0. Preflight contains88functional1x rows, all exit0, excluded from performance qualification. These prior correctness/preflight processes are not part of the1232timing samples.

## Reference, modes and conditions

All56selected fresh own-reference original authored source hashes and56copied source hashes match current bytes. Fresh own target/build/test provenance records successful locked Rust1.97/Binaryen133/wasm2go0.4.16 and official Go1.26.8 ordinary consumer build; reference Wasm/module/ELF SHA identities independently match reference-audit.json. Reproduction of earlier identities does not make historical samples current. Reference ABI2, background/context/ownership/pool/error/result/corpus differences remain attribution limits, not a checked host-cost floor. No implementation was transplanted.

The canonical timing overlays contain only ignored regenerated module replacements; proof overlays add virtual tests separately. Untouched DD remains c73daeca03069285b5b26701646ac0c94ece1a80c62c5905eff795324db3d3d0. Oracle-control/true select the same ELF bf491aa076c5f80e572404ca22db8ec1395d86b0b99128df103b2a92df191974, same table/file/init/setup, differing only runtime case-env flag. Compute/stream regenerated bytes remain production-identical; all three stream ELFs are a2076ad9349c334f028e1c73cc166004c15da1debab79e8d2c349d851bc373bf and the six lifetime stream groups are environmental brackets only.

The table consumes64MiB logical HOST bytes, plus ReadFile allocation overhead, before timing. Untouched/outline do not load it despite receiving the env path. Thus untouched comparisons retain setup/live-heap/GC/cache/power confounds; same-ELF false-mode is the stronger matching control. Offline computation avoids millions of role-local untimed log evaluations; it does not make startup/table memory free. One external-time functional1x process per role observes RSS13328/13876/81496/81612kbytes, respectively13.02/13.55/79.59/79.70MiB (or13.328/13.876/81.496/81.612MB decimal). These are single whole-process context observations, not repeated startup qualification, isolated guest memory or per-operation allocations. Wall times rounded0.00/0.01s do not justify finer startup latency claims.

Plan and driver remain reviewed:19groups;88processes/pass*14passes=1232raw rows. Original checked scalar/rawGuest/Increasing/BroadScalar fixed-count groups explicitly say FixedN; screening4,194,304and independent reversed confirmation8,388,608match prefixes among roles per set. All other groups use7alternating500ms and7reversed1s. Case mode/path is supplied and recorded, exact fixed iteration counts enforced, benchmark selectors/rows/metrics/PASS validated, leaf GOMAX/custom metrics preserved. FixedN is synthetic evolving-prefix diagnostic, not adaptive original M1 acceptance or private SDK traffic. Primary promotion requires>=10%median TIME reduction with unadjustedp<.05 against BOTH untouched and false-mode control in BOTH sets. Every negative/sample/control is retained. Successful ceiling evidence could justify only separately specified certified-interval feasibility work.

## Final config/freeze requirement

The current initial qualification-config still lists54artifacts and predates completed proof files; root explicitly will refresh it after reviewer notes. Before executing paired.py, refreshed config/frozen.json must contain table.bin, all20proof executables/source/tests/scripts/metadata/logs, allcanonical/proof overlays and authoring causes, plans/driver/freeze/reporting scripts, reviewed notes, actual-mode/preflight/startup provenance, fresh-reference56sources/build/oracle inputs, compiler/dependencies/production/harness identities and every timed ELF. Runtime flags are pinned case data in the frozen plan, not new executables. Freeze should verify unchanged clean tracked production, toolchain/build flags and all file hashes, with matching CPU/affinity/defaultGC conditions recorded; verify again during/after both rounds. No local reviewer/build/test/lint/fuzz/profile tools may overlap timing. External unrelated workload absence cannot be proven. Root owns that final refresh/freeze and isolation after this note; no further reviewer tooling is needed unless root requests a narrow input check.

All my tools are STOPPED after saving this verdict.

## Final reviewed identities

```json
{
  "decision-plan.json": "eb274cbe5581211e984aa424564d501f227619bc3280b1c0851d58a270b72cde",
  "qualification-plan.json": "8a2df3a689e450fe3983412de0abdf8dc3f8304de116d35061c2817e645bebb0",
  "paired.py": "23d38370a14da8ee259c87f0604aec389ec51ef41f396dd3f8967efa62115e43",
  "proof/README.md": "9e7f45b0b29b9049b244fdf8b6220d981c1934165162df21835ec4e40e88d94c",
  "proof/prepare.py": "ad075f1571bbcb43f9602bf349049223ea5dc95c54fd64b0e1a69aaf4e7e71de",
  "proof/bits_test.go": "1230942eb79ecdbd54fb7324f50e18b3e60685daacac94c1974992a6e1d55536",
  "proof/state_test.go": "83c3896cffe1dd2e4219750489094cdcfc69558a9c84f100fb71856a46cdb62f",
  "proof/source-provenance.json": "c9190c6a2450faf6b5fb543bccc91bb163ca8941cb4661000d0d795fa7b5145f",
  "proof/native-build-run-provenance.json": "909b08c0f7607992e58f60965a8a5666e0cfe1e1b4a5f926342db560d7997fd1",
  "proof/run-native-386.sh": "448c297d9a407ec17374294fd1690f9047006373259c7a1cecc630ae643b7262",
  "proof/native-386-run.log": "702a901ede29920cf704ba290e38e7db69ec113e4a5525999451853b5eceb8fc",
  "actual-mode-whole.py": "72a756d3d00bd39a13dadcb4afa842aea342a8be8eeba36398b0a868f39a948b",
  "actual-mode-whole-records.json": "09cb89cd9d2516d7a0cbd70bc0080472acceeb2ffbef710b81219f785790b958",
  "reference-audit.json": "6cd47d64ddaf24b08a2255aa8e63fce55e50900a29bd3ef8aa72519ea03049bc",
  "reference-source-copy-manifest.json": "b27a1674dea66ede171f80b09cbb59d5de584d1c1fead732442704a0257475a3",
  "startup-memory-records.json": "356a6ea59daff54cb8defd75278ee6ce5d34bf8862e7f985dad6f08701866ec0"
}
```
