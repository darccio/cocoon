TEXT dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn176(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/internal/wasm/module.go
  module.go:35695	0x630000		4c8d6424f0		LEAQ -0x10(SP), R12									
  module.go:35695	0x630005		4d3b6610		CMPQ R12, 0x10(R14)									
  module.go:35695	0x630009		0f86b7120000		JBE 0x6312c6										
  module.go:35695	0x63000f		55			PUSHQ BP										
  module.go:35695	0x630010		4889e5			MOVQ SP, BP										
  module.go:35695	0x630013		4881ec88000000		SUBQ $0x88, SP										
  module.go:35714	0x63001a		4889842498000000	MOVQ AX, 0x98(SP)									
  module.go:35714	0x630022		899c24a0000000		MOVL BX, 0xa0(SP)									
  module.go:35700	0x630029		8b5050			MOVL 0x50(AX), DX									
  module.go:35700	0x63002c		89542430		MOVL DX, 0x30(SP)									
  module.go:35706	0x630030		8d72e0			LEAL -0x20(DX), SI									
  module.go:35707	0x630033		897050			MOVL SI, 0x50(AX)									
  unsafe.go:35		0x630036		66480f7ec7		MOVQ X0, DI										
  module.go:35712	0x63003b		4989f8			MOVQ DI, R8										
  module.go:35712	0x63003e		480fbaf73f		BTRQ $0x3f, DI										
  module.go:35714	0x630043		4c8d4fff		LEAQ -0x1(DI), R9									
  module.go:35734	0x630047		49ba000000000000f0ff	MOVQ $0xfff0000000000000, R10								
  module.go:35734	0x630051		4901fa			ADDQ DI, R10										
  module.go:35711	0x630054		90			NOPL											
  module.go:35714	0x630055		49bbffffffffffff0f00	MOVQ $0xfffffffffffff, R11								
  module.go:35714	0x63005f		4d39cb			CMPQ R11, R9										
  module.go:35714	0x630062		410f97c1		SETA R9											
  module.go:35715	0x630066		450fb6c9		MOVZX R9, R9										
  module.go:35718	0x63006a		4d85c0			TESTQ R8, R8										
  module.go:35718	0x63006d		410f9cc0		SETL R8											
  module.go:35719	0x630071		450fb6c0		MOVZX R8, R8										
  module.go:35722	0x630075		4521c1			ANDL R8, R9										
  module.go:35729	0x630078		49bb000000000000f07f	MOVQ $0x7ff0000000000000, R11								
  module.go:35729	0x630082		4939fb			CMPQ R11, DI										
  module.go:35724	0x630085		400f94c7		SETE DI											
  module.go:35729	0x630089		410f92c3		SETB R11										
  module.go:35725	0x63008d		400fb6ff		MOVZX DI, DI										
  module.go:35727	0x630091		4109f9			ORL DI, R9										
  module.go:35730	0x630094		410fb6fb		MOVZX R11, DI										
  module.go:35732	0x630098		4109f9			ORL DI, R9										
  module.go:35734	0x63009b		48bf000000000000e07f	MOVQ $0x7fe0000000000000, DI								
  module.go:35734	0x6300a5		4c39d7			CMPQ DI, R10										
  module.go:35734	0x6300a8		400f97c7		SETA DI											
  module.go:35735	0x6300ac		400fb6ff		MOVZX DI, DI										
  module.go:35737	0x6300b0		4421c7			ANDL R8, DI										
  module.go:35737	0x6300b3		4409cf			ORL R9, DI										
  module.go:35737	0x6300b6		85ff			TESTL DI, DI										
  module.go:35737	0x6300b8		0f85ba060000		JNE 0x630778										
  module.go:35773	0x6300be		488b7038		MOVQ 0x38(AX), SI									
  module.go:35773	0x6300c2		89cf			MOVL CX, DI										
  module.go:62955	0x6300c4		4c8d4737		LEAQ 0x37(DI), R8									
  module.go:62955	0x6300c8		4c39c6			CMPQ SI, R8										
  module.go:62955	0x6300cb		0f86ed110000		JBE 0x6312be										
  module.go:35773	0x6300d1		488b7030		MOVQ 0x30(AX), SI									
  module.go:62956	0x6300d5		488b743730		MOVQ 0x30(DI)(SI*1), SI									
  unsafe.go:41		0x6300da		66480f6ece		MOVQ SI, X1										
  module.go:35774	0x6300df		660f2ec8		UCOMISD X0, X1										
  module.go:35774	0x6300e3		0f8742060000		JA 0x63072b										
  module.go:35775	0x6300e9		488b7038		MOVQ 0x38(AX), SI									
  module.go:62955	0x6300ed		4c8d472f		LEAQ 0x2f(DI), R8									
  module.go:62955	0x6300f1		4c39c6			CMPQ SI, R8										
  module.go:62955	0x6300f4		0f86bf110000		JBE 0x6312b9										
  module.go:35714	0x6300fa		898c24a4000000		MOVL CX, 0xa4(SP)									
  module.go:35773	0x630101		4889bc2480000000	MOVQ DI, 0x80(SP)									
  module.go:35775	0x630109		488b4030		MOVQ 0x30(AX), AX									
  module.go:62955	0x63010d		488d4f3f		LEAQ 0x3f(DI), CX									
  module.go:62955	0x630111		48894c2478		MOVQ CX, 0x78(SP)									
  module.go:62956	0x630116		488b440728		MOVQ 0x28(DI)(AX*1), AX									
  module.go:62956	0x63011b		4889442450		MOVQ AX, 0x50(SP)									
  module.go:35777	0x630120		e81b140600		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.cocoonPhase0PinnedLog(SB)	
  module.go:35778	0x630125		488b842498000000	MOVQ 0x98(SP), AX									
  module.go:35778	0x63012d		488b4838		MOVQ 0x38(AX), CX									
  module.go:62955	0x630131		488b542478		MOVQ 0x78(SP), DX									
  module.go:62955	0x630136		4839d1			CMPQ CX, DX										
  module.go:62955	0x630139		0f8675110000		JBE 0x6312b4										
  module.go:35778	0x63013f		488b5030		MOVQ 0x30(AX), DX									
  unsafe.go:41		0x630143		4c8b4c2450		MOVQ 0x50(SP), R9									
  unsafe.go:41		0x630148		66490f6ec9		MOVQ R9, X1										
  module.go:35779	0x63014d		f20f59c1		MULSD X1, X0										
  module.go:62956	0x630151		4c8b8c2480000000	MOVQ 0x80(SP), R9									
  module.go:62956	0x630159		498b541138		MOVQ 0x38(R9)(DX*1), DX									
  module.go:35778	0x63015e		66480f6eca		MOVQ DX, X1										
  module.go:35779	0x630163		f20f58c1		ADDSD X1, X0										
  module.go:35779	0x630167		0fb615c6186d00		MOVZX runtime.x86HasSSE41(SB), DX							
  module.go:35779	0x63016e		85d2			TESTL DX, DX										
  module.go:35779	0x630170		7408			JE 0x63017a										
  module.go:35779	0x630172		660f3a0bc001		ROUNDSD $0x1, X0, X0									
  module.go:35779	0x630178		eb15			JMP 0x63018f										
  module.go:35779	0x63017a		e861b0eaff		CALL math.Floor(SB)									
  module.go:35780	0x63017f		488b842498000000	MOVQ 0x98(SP), AX									
  module.go:62929	0x630187		4c8b8c2480000000	MOVQ 0x80(SP), R9									
  module.go:63020	0x63018f		f20f100d79202d00	MOVSD_XMM $f64.c1e0000000000000(SB), X1							
  module.go:63020	0x630197		660f2ec8		UCOMISD X0, X1										
  module.go:63020	0x63019b		7207			JB 0x6301a4										
  module.go:63020	0x63019d		ba00000080		MOVL $-0x80000000, DX									
  module.go:35779	0x6301a2		eb26			JMP 0x6301ca										
  module.go:63022	0x6301a4		f20f100d54202d00	MOVSD_XMM $f64.41dfffffffc00000(SB), X1							
  module.go:63022	0x6301ac		660f2ec1		UCOMISD X1, X0										
  module.go:63022	0x6301b0		7207			JB 0x6301b9										
  module.go:63022	0x6301b2		baffffff7f		MOVL $0x7fffffff, DX									
  module.go:35779	0x6301b7		eb11			JMP 0x6301ca										
  module.go:63024	0x6301b9		660f2ec0		UCOMISD X0, X0										
  module.go:63024	0x6301bd		7503			JNE 0x6301c2										
  module.go:63024	0x6301bf		90			NOPL											
  module.go:63024	0x6301c0		7b04			JNP 0x6301c6										
  module.go:63024	0x6301c2		31d2			XORL DX, DX										
  module.go:35779	0x6301c4		eb04			JMP 0x6301ca										
  module.go:63027	0x6301c6		f20f2cd0		CVTTSD2SIL X0, DX									
  module.go:35780	0x6301ca		4c8b5038		MOVQ 0x38(AX), R10									
  module.go:62929	0x6301ce		4d8d590f		LEAQ 0xf(R9), R11									
  module.go:62929	0x6301d2		4d39da			CMPQ R10, R11										
  module.go:62929	0x6301d5		0f86d4100000		JBE 0x6312af										
  module.go:62929	0x6301db		4c895c2478		MOVQ R11, 0x78(SP)									
  module.go:35780	0x6301e0		4c8b6030		MOVQ 0x30(AX), R12									
  module.go:62930	0x6301e4		438b4c210c		MOVL 0xc(R9)(R12*1), CX									
  module.go:35782	0x6301e9		85c9			TESTL CX, CX										
  module.go:35782	0x6301eb		0f841e040000		JE 0x63060f										
  module.go:62929	0x6301f1		4d8d6913		LEAQ 0x13(R9), R13									
  module.go:35809	0x6301f5		90			NOPL											
  module.go:62929	0x6301f6		4d39ea			CMPQ R10, R13										
  module.go:62929	0x6301f9		0f86ab100000		JBE 0x6312aa										
  module.go:62929	0x6301ff		4c896c2470		MOVQ R13, 0x70(SP)									
  module.go:62930	0x630204		438b7c2110		MOVL 0x10(R9)(R12*1), DI								
  module.go:35811	0x630209		39fa			CMPL DX, DI										
  module.go:35811	0x63020b		0f8cf6000000		JL 0x630307										
  module.go:35813	0x630211		8d3439			LEAL 0(CX)(DI*1), SI									
  module.go:35812	0x630214		4189d0			MOVL DX, R8										
  module.go:35812	0x630217		29fa			SUBL DI, DX										
  module.go:35812	0x630219		0f1f8000000000		NOPL 0(AX)										
  module.go:35813	0x630220		4139f0			CMPL R8, SI										
  module.go:35813	0x630223		0f8cd0000000		JL 0x6302f9										
  module.go:62929	0x630229		498d7117		LEAQ 0x17(R9), SI									
  module.go:35817	0x63022d		90			NOPL											
  module.go:62929	0x63022e		4939f2			CMPQ R10, SI										
  module.go:62929	0x630231		0f866e100000		JBE 0x6312a5										
  module.go:35816	0x630237		8d7201			LEAL 0x1(DX), SI									
  module.go:62930	0x63023a		478b7c0c14		MOVL 0x14(R12)(R9*1), R15								
  module.go:62930	0x63023f		90			NOPL											
  module.go:35820	0x630240		4139f7			CMPL R15, SI										
  module.go:35820	0x630243		7c0c			JL 0x630251										
  module.go:62930	0x630245		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:35821	0x63024c		e9f30a0000		JMP 0x630d44										
  module.go:35823	0x630251		4429fa			SUBL R15, DX										
  module.go:35823	0x630254		8d7201			LEAL 0x1(DX), SI									
  module.go:35824	0x630257		85f6			TESTL SI, SI										
  module.go:35824	0x630259		7e63			JLE 0x6302be										
  module.go:62929	0x63025b		498d590b		LEAQ 0xb(R9), BX									
  module.go:35825	0x63025f		90			NOPL											
  module.go:62929	0x630260		4939da			CMPQ R10, BX										
  module.go:62929	0x630263		0f8635100000		JBE 0x63129e										
  module.go:35823	0x630269		8954244c		MOVL DX, 0x4c(SP)									
  module.go:35779	0x63026d		4489442448		MOVL R8, 0x48(SP)									
  module.go:35831	0x630272		468d143f		LEAL 0(DI)(R15*1), R10									
  module.go:63130	0x630276		448bbc24a4000000	MOVL 0xa4(SP), R15									
  module.go:63130	0x63027e		4589ff			MOVL R15, R15										
  module.go:63130	0x630281		4c897c2468		MOVQ R15, 0x68(SP)									
  module.go:35827	0x630286		90			NOPL											
  module.go:35829	0x630287		90			NOPL											
  module.go:62930	0x630288		478b6c0c08		MOVL 0x8(R12)(R9*1), R13								
  module.go:63130	0x63028d		438b540c04		MOVL 0x4(R12)(R9*1), DX									
  module.go:63130	0x630292		478b243c		MOVL 0(R12)(R15*1), R12									
  module.go:35831	0x630296		4539d0			CMPL R8, R10										
  module.go:35831	0x630299		750a			JNE 0x6302a5										
  module.go:36034	0x63029b		89ce			MOVL CX, SI										
  module.go:36034	0x63029d		0f57c0			XORPS X0, X0										
  module.go:35834	0x6302a0		e9dc0d0000		JMP 0x631081										
  module.go:62930	0x6302a5		897c2444		MOVL DI, 0x44(SP)									
  module.go:35837	0x6302a9		4189f2			MOVL SI, R10										
  module.go:35837	0x6302ac		81e6feffff7f		ANDL $0x7ffffffe, SI									
  module.go:35898	0x6302b2		894c2420		MOVL CX, 0x20(SP)									
  module.go:35898	0x6302b6		0f57c0			XORPS X0, X0										
  module.go:35840	0x6302b9		e9460c0000		JMP 0x630f04										
  module.go:62929	0x6302be		498d7107		LEAQ 0x7(R9), SI									
  module.go:35903	0x6302c2		90			NOPL											
  module.go:62929	0x6302c3		4939f2			CMPQ R10, SI										
  module.go:62929	0x6302c6		0f86280c0000		JBE 0x630ef4										
  module.go:63130	0x6302cc		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:63130	0x6302d3		89de			MOVL BX, SI										
  module.go:62929	0x6302d5		4d8d790b		LEAQ 0xb(R9), R15									
  module.go:35905	0x6302d9		90			NOPL											
  module.go:62930	0x6302da		478b5c0c04		MOVL 0x4(R12)(R9*1), R11								
  module.go:63130	0x6302df		418b3434		MOVL 0(R12)(SI*1), SI									
  module.go:62929	0x6302e3		4d39fa			CMPQ R10, R15										
  module.go:62929	0x6302e6		0f86030c0000		JBE 0x630eef										
  module.go:62930	0x6302ec		478b540c08		MOVL 0x8(R12)(R9*1), R10								
  module.go:62930	0x6302f1		0f57c0			XORPS X0, X0										
  module.go:35910	0x6302f4		e9d8090000		JMP 0x630cd1										
  module.go:63130	0x6302f9		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:36141	0x630300		89ce			MOVL CX, SI										
  module.go:35814	0x630302		e928070000		JMP 0x630a2f										
  module.go:62929	0x630307		4d8d7917		LEAQ 0x17(R9), R15									
  module.go:35914	0x63030b		90			NOPL											
  module.go:62929	0x63030c		4d39fa			CMPQ R10, R15										
  module.go:62929	0x63030f		0f86b7090000		JBE 0x630ccc										
  module.go:35917	0x630315		29d7			SUBL DX, DI										
  module.go:62930	0x630317		438b540c14		MOVL 0x14(R12)(R9*1), DX								
  module.go:35915	0x63031c		29ca			SUBL CX, DX										
  module.go:35919	0x63031e		39d7			CMPL DI, DX										
  module.go:35920	0x630320		0f47fa			CMOVA DX, DI										
  module.go:35923	0x630323		8d140f			LEAL 0(DI)(CX*1), DX									
  module.go:35924	0x630326		39d7			CMPL DI, DX										
  module.go:35919	0x630328		0f8777090000		JA 0x630ca5										
  module.go:62929	0x63032e		4d8d7903		LEAQ 0x3(R9), R15									
  module.go:35925	0x630332		90			NOPL											
  module.go:62929	0x630333		4d39fa			CMPQ R10, R15										
  module.go:62929	0x630336		0f8662090000		JBE 0x630c9e										
  module.go:35920	0x63033c		897c2424		MOVL DI, 0x24(SP)									
  module.go:62930	0x630340		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:62930	0x630347		4189da			MOVL BX, R10										
  module.go:62930	0x63034a		4c89542468		MOVQ R10, 0x68(SP)									
  module.go:62930	0x63034f		478b2414		MOVL 0(R12)(R10*1), R12									
  module.go:35928	0x630353		4139d4			CMPL R12, DX										
  module.go:35928	0x630356		0f83a4020000		JAE 0x630600										
  module.go:35938	0x63035c		4489e2			MOVL R12, DX										
  module.go:35938	0x63035f		4129cc			SUBL CX, R12										
  module.go:35940	0x630362		4439e7			CMPL DI, R12										
  module.go:35940	0x630365		7704			JA 0x63036b										
  module.go:62930	0x630367		89d6			MOVL DX, SI										
  module.go:35941	0x630369		eb72			JMP 0x6303dd										
  module.go:62930	0x63036b		89542444		MOVL DX, 0x44(SP)									
  module.go:35943	0x63036f		be08000000		MOVL $0x8, SI										
  module.go:35943	0x630374		4189f0			MOVL SI, R8										
  module.go:35943	0x630377		e8c4bef9ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn3(SB)		
  module.go:35944	0x63037c		488b842498000000	MOVQ 0x98(SP), AX									
  module.go:35944	0x630384		488b5038		MOVQ 0x38(AX), DX									
  module.go:62929	0x630388		4c8b4c2478		MOVQ 0x78(SP), R9									
  module.go:62929	0x63038d		4c39ca			CMPQ DX, R9										
  module.go:62929	0x630390		0f8603090000		JBE 0x630c99										
  module.go:35944	0x630396		488b5030		MOVQ 0x30(AX), DX									
  module.go:62930	0x63039a		488bb42480000000	MOVQ 0x80(SP), SI									
  module.go:62930	0x6303a2		8b4c160c		MOVL 0xc(SI)(DX*1), CX									
  module.go:35947	0x6303a6		448b642444		MOVL 0x44(SP), R12									
  module.go:35947	0x6303ab		4589e0			MOVL R12, R8										
  module.go:35947	0x6303ae		4129c8			SUBL CX, R8										
  module.go:63130	0x6303b1		4c8b542468		MOVQ 0x68(SP), R10									
  module.go:63130	0x6303b6		418b1412		MOVL 0(R10)(DX*1), DX									
  module.go:35993	0x6303ba		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:35957	0x6303c1		4489e6			MOVL R12, SI										
  module.go:35988	0x6303c4		8b7c2424		MOVL 0x24(SP), DI									
  module.go:62929	0x6303c8		4c8b8c2480000000	MOVQ 0x80(SP), R9									
  module.go:62946	0x6303d0		4c8b5c2478		MOVQ 0x78(SP), R11									
  module.go:62929	0x6303d5		4c8b6c2470		MOVQ 0x70(SP), R13									
  module.go:35948	0x6303da		4589c4			MOVL R8, R12										
  module.go:35952	0x6303dd		4c8b4038		MOVQ 0x38(AX), R8									
  module.go:62929	0x6303e1		4d8d790b		LEAQ 0xb(R9), R15									
  module.go:62929	0x6303e5		4d39f8			CMPQ R8, R15										
  module.go:62929	0x6303e8		0f86a6080000		JBE 0x630c94										
  module.go:35952	0x6303ee		4c8b5030		MOVQ 0x30(AX), R10									
  module.go:62930	0x6303f2		438b5c1108		MOVL 0x8(R9)(R10*1), BX									
  module.go:35954	0x6303f7		4139dc			CMPL R12, BX										
  module.go:35954	0x6303fa		7214			JB 0x630410										
  module.go:35993	0x6303fc		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:63130	0x630403		4c8b542468		MOVQ 0x68(SP), R10									
  module.go:35987	0x630408		4189d4			MOVL DX, R12										
  module.go:35955	0x63040b		e9f0010000		JMP 0x630600										
  module.go:35948	0x630410		894c2420		MOVL CX, 0x20(SP)									
  module.go:35948	0x630414		89542434		MOVL DX, 0x34(SP)									
  module.go:35957	0x630418		4189f4			MOVL SI, R12										
  module.go:35957	0x63041b		29de			SUBL BX, SI										
  module.go:35959	0x63041d		29f1			SUBL SI, CX										
  module.go:35965	0x63041f		4429e2			SUBL R12, DX										
  module.go:35961	0x630422		39f1			CMPL CX, SI										
  module.go:35961	0x630424		410f92c5		SETB R13										
  module.go:35962	0x630428		450fb6ed		MOVZX R13, R13										
  module.go:35965	0x63042c		39ca			CMPL DX, CX										
  module.go:35965	0x63042e		0f93c2			SETAE DL										
  module.go:35966	0x630431		0fb6d2			MOVZX DL, DX										
  module.go:35968	0x630434		4185d5			TESTL DX, R13										
  module.go:35968	0x630437		0f85f4000000		JNE 0x630531										
  module.go:35970	0x63043d		89f2			MOVL SI, DX										
  module.go:35970	0x63043f		c1e603			SHLL $0x3, SI										
  module.go:35969	0x630442		448b642434		MOVL 0x34(SP), R12									
  module.go:35969	0x630447		4589e5			MOVL R12, R13										
  module.go:35969	0x63044a		4129d4			SUBL DX, R12										
  module.go:35971	0x63044d		85f6			TESTL SI, SI										
  module.go:35971	0x63044f		0f84a7000000		JE 0x6304fc										
  module.go:62929	0x630455		498d5107		LEAQ 0x7(R9), DX									
  module.go:35972	0x630459		90			NOPL											
  module.go:35972	0x63045a		660f1f440000		NOPW 0(AX)(AX*1)									
  module.go:62929	0x630460		4939d0			CMPQ R8, DX										
  module.go:62929	0x630463		0f8626080000		JBE 0x630c8f										
  module.go:62930	0x630469		438b540a04		MOVL 0x4(R10)(R9*1), DX									
  module.go:35974	0x63046e		428d0ce2		LEAL 0(DX)(R12*8), CX									
  module.go:35974	0x630472		8d14da			LEAL 0(DX)(BX*8), DX									
  module.go:63055	0x630475		89c9			MOVL CX, CX										
  module.go:63056	0x630477		89d2			MOVL DX, DX										
  module.go:63057	0x630479		89f6			MOVL SI, SI										
  module.go:63057	0x63047b		488d1c0e		LEAQ 0(SI)(CX*1), BX									
  module.go:63058	0x63047f		4c8d1c16		LEAQ 0(SI)(DX*1), R11									
  module.go:63059	0x630483		4939d8			CMPQ R8, BX										
  module.go:63059	0x630486		0f82fe070000		JB 0x630c8a										
  module.go:63059	0x63048c		4889cb			MOVQ CX, BX										
  module.go:63059	0x63048f		4c29c1			SUBQ R8, CX										
  module.go:63059	0x630492		48c1f93f		SARQ $0x3f, CX										
  module.go:63059	0x630496		4821cb			ANDQ CX, BX										
  module.go:63059	0x630499		4a8d0c13		LEAQ 0(BX)(R10*1), CX									
  module.go:63059	0x63049d		0f1f00			NOPL 0(AX)										
  module.go:63059	0x6304a0		4d39d8			CMPQ R8, R11										
  module.go:63059	0x6304a3		0f82dc070000		JB 0x630c85										
  module.go:63059	0x6304a9		4989d3			MOVQ DX, R11										
  module.go:63059	0x6304ac		4c29c2			SUBQ R8, DX										
  module.go:63059	0x6304af		48c1fa3f		SARQ $0x3f, DX										
  module.go:63059	0x6304b3		4921d3			ANDQ DX, R11										
  module.go:63059	0x6304b6		4b8d1c13		LEAQ 0(R11)(R10*1), BX									
  module.go:63059	0x6304ba		4839cb			CMPQ BX, CX										
  module.go:63059	0x6304bd		7438			JE 0x6304f7										
  module.go:62929	0x6304bf		4c897c2460		MOVQ R15, 0x60(SP)									
  module.go:35969	0x6304c4		4489642428		MOVL R12, 0x28(SP)									
  module.go:63059	0x6304c9		4889c8			MOVQ CX, AX										
  module.go:63059	0x6304cc		4889f1			MOVQ SI, CX										
  module.go:63059	0x6304cf		e88c08e6ff		CALL runtime.memmove(SB)								
  module.go:35976	0x6304d4		488b842498000000	MOVQ 0x98(SP), AX									
  module.go:35988	0x6304dc		8b7c2424		MOVL 0x24(SP), DI									
  module.go:62947	0x6304e0		4c8b8c2480000000	MOVQ 0x80(SP), R9									
  module.go:62947	0x6304e8		448b642428		MOVL 0x28(SP), R12									
  module.go:35987	0x6304ed		448b6c2434		MOVL 0x34(SP), R13									
  module.go:62946	0x6304f2		4c8b7c2460		MOVQ 0x60(SP), R15									
  module.go:62946	0x6304f7		4c8b5c2478		MOVQ 0x78(SP), R11									
  module.go:35976	0x6304fc		488b5038		MOVQ 0x38(AX), DX									
  module.go:62946	0x630500		4c39fa			CMPQ DX, R15										
  module.go:62946	0x630503		0f8675070000		JBE 0x630c7e										
  module.go:35976	0x630509		488b5030		MOVQ 0x30(AX), DX									
  module.go:62947	0x63050d		4589641108		MOVL R12, 0x8(R9)(DX*1)									
  module.go:35993	0x630512		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:63130	0x630519		4c8b542468		MOVQ 0x68(SP), R10									
  module.go:62929	0x63051e		4c8b6c2470		MOVQ 0x70(SP), R13									
  module.go:35987	0x630523		8b4c2420		MOVL 0x20(SP), CX									
  module.go:35987	0x630527		448b642434		MOVL 0x34(SP), R12									
  module.go:35977	0x63052c		e9cf000000		JMP 0x630600										
  module.go:35979	0x630531		c1e103			SHLL $0x3, CX										
  module.go:35980	0x630534		85c9			TESTL CX, CX										
  module.go:35980	0x630536		751f			JNE 0x630557										
  module.go:35993	0x630538		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:63130	0x63053f		4c8b542468		MOVQ 0x68(SP), R10									
  module.go:62929	0x630544		4c8b6c2470		MOVQ 0x70(SP), R13									
  module.go:35987	0x630549		8b4c2420		MOVL 0x20(SP), CX									
  module.go:35987	0x63054d		448b642434		MOVL 0x34(SP), R12									
  module.go:35981	0x630552		e9a9000000		JMP 0x630600										
  module.go:62929	0x630557		498d5107		LEAQ 0x7(R9), DX									
  module.go:35983	0x63055b		90			NOPL											
  module.go:35983	0x63055c		0f1f4000		NOPL 0(AX)										
  module.go:62929	0x630560		4939d0			CMPQ R8, DX										
  module.go:62929	0x630563		0f8610070000		JBE 0x630c79										
  module.go:62930	0x630569		438b540a04		MOVL 0x4(R10)(R9*1), DX									
  module.go:35985	0x63056e		428d34e2		LEAL 0(DX)(R12*8), SI									
  module.go:63055	0x630572		89f6			MOVL SI, SI										
  module.go:63057	0x630574		89c9			MOVL CX, CX										
  module.go:63057	0x630576		4c8d2431		LEAQ 0(CX)(SI*1), R12									
  module.go:63058	0x63057a		4c8d2c11		LEAQ 0(CX)(DX*1), R13									
  module.go:63058	0x63057e		6690			NOPW											
  module.go:63059	0x630580		4d39e0			CMPQ R8, R12										
  module.go:63059	0x630583		0f82eb060000		JB 0x630c74										
  module.go:63059	0x630589		4989f4			MOVQ SI, R12										
  module.go:63059	0x63058c		4c29c6			SUBQ R8, SI										
  module.go:63059	0x63058f		48c1fe3f		SARQ $0x3f, SI										
  module.go:63059	0x630593		4921f4			ANDQ SI, R12										
  module.go:63059	0x630596		4b8d3414		LEAQ 0(R12)(R10*1), SI									
  module.go:63059	0x63059a		660f1f440000		NOPW 0(AX)(AX*1)									
  module.go:63059	0x6305a0		4d39e8			CMPQ R8, R13										
  module.go:63059	0x6305a3		0f82c6060000		JB 0x630c6f										
  module.go:63059	0x6305a9		4189d4			MOVL DX, R12										
  module.go:63059	0x6305ac		4c29c2			SUBQ R8, DX										
  module.go:63059	0x6305af		48c1fa3f		SARQ $0x3f, DX										
  module.go:63059	0x6305b3		4c21e2			ANDQ R12, DX										
  module.go:63059	0x6305b6		4a8d1c12		LEAQ 0(DX)(R10*1), BX									
  module.go:63059	0x6305ba		4839f3			CMPQ BX, SI										
  module.go:63059	0x6305bd		7421			JE 0x6305e0										
  module.go:63059	0x6305bf		4889f0			MOVQ SI, AX										
  module.go:63059	0x6305c2		e89907e6ff		CALL runtime.memmove(SB)								
  module.go:36001	0x6305c7		488b842498000000	MOVQ 0x98(SP), AX									
  module.go:35988	0x6305cf		8b7c2424		MOVL 0x24(SP), DI									
  module.go:62947	0x6305d3		4c8b8c2480000000	MOVQ 0x80(SP), R9									
  module.go:62946	0x6305db		4c8b5c2478		MOVQ 0x78(SP), R11									
  module.go:35993	0x6305e0		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:63130	0x6305e7		4c8b542468		MOVQ 0x68(SP), R10									
  module.go:62929	0x6305ec		4c8b6c2470		MOVQ 0x70(SP), R13									
  module.go:35987	0x6305f1		8b4c2420		MOVL 0x20(SP), CX									
  module.go:35987	0x6305f5		448b642434		MOVL 0x34(SP), R12									
  module.go:35987	0x6305fa		660f1f440000		NOPW 0(AX)(AX*1)									
  module.go:35988	0x630600		85ff			TESTL DI, DI										
  module.go:35988	0x630602		0f8427050000		JE 0x630b2f										
  module.go:35920	0x630608		89fa			MOVL DI, DX										
  module.go:35990	0x63060a		e94a050000		JMP 0x630b59										
  module.go:62946	0x63060f		498d7113		LEAQ 0x13(R9), SI									
  module.go:35783	0x630613		90			NOPL											
  module.go:62946	0x630614		4939f2			CMPQ R10, SI										
  module.go:62946	0x630617		0f860d050000		JBE 0x630b2a										
  module.go:62947	0x63061d		4389542110		MOVL DX, 0x10(R9)(R12*1)								
  module.go:35785	0x630622		488b5038		MOVQ 0x38(AX), DX									
  module.go:62929	0x630626		498d7103		LEAQ 0x3(R9), SI									
  module.go:62929	0x63062a		4839f2			CMPQ DX, SI										
  module.go:62929	0x63062d		0f86f2040000		JBE 0x630b25										
  module.go:35785	0x630633		488b5030		MOVQ 0x30(AX), DX									
  module.go:62930	0x630637		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:62930	0x63063e		4189d8			MOVL BX, R8										
  module.go:62930	0x630641		418b1410		MOVL 0(R8)(DX*1), DX									
  module.go:35787	0x630645		85d2			TESTL DX, DX										
  module.go:35787	0x630647		7405			JE 0x63064e										
  module.go:35787	0x630649		4531d2			XORL R10, R10										
  module.go:35787	0x63064c		eb5c			JMP 0x6306aa										
  module.go:62929	0x63064e		4889742470		MOVQ SI, 0x70(SP)									
  module.go:62930	0x630653		4c89442468		MOVQ R8, 0x68(SP)									
  module.go:35788	0x630658		e80343fbff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn88(SB)		
  module.go:35789	0x63065d		488b842498000000	MOVQ 0x98(SP), AX									
  module.go:35789	0x630665		488b4838		MOVQ 0x38(AX), CX									
  module.go:62929	0x630669		488b542470		MOVQ 0x70(SP), DX									
  module.go:62929	0x63066e		4839d1			CMPQ CX, DX										
  module.go:62929	0x630671		0f86a7040000		JBE 0x630b1e										
  module.go:35789	0x630677		488b5030		MOVQ 0x30(AX), DX									
  module.go:62930	0x63067b		488b742468		MOVQ 0x68(SP), SI									
  module.go:62930	0x630680		8b3416			MOVL 0(SI)(DX*1), SI									
  module.go:62929	0x630683		4c8b442478		MOVQ 0x78(SP), R8									
  module.go:62929	0x630688		4c39c1			CMPQ CX, R8										
  module.go:62929	0x63068b		0f8688040000		JBE 0x630b19										
  module.go:62930	0x630691		4c8b8c2480000000	MOVQ 0x80(SP), R9									
  module.go:62930	0x630699		458b54110c		MOVL 0xc(R9)(DX*1), R10									
  module.go:63130	0x63069e		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:62946	0x6306a5		4d89c3			MOVQ R8, R11										
  module.go:35791	0x6306a8		89f2			MOVL SI, DX										
  module.go:35796	0x6306aa		488b7038		MOVQ 0x38(AX), SI									
  module.go:62946	0x6306ae		4c39de			CMPQ SI, R11										
  module.go:62946	0x6306b1		0f865d040000		JBE 0x630b14										
  module.go:35795	0x6306b7		418d7201		LEAL 0x1(R10), SI									
  module.go:35796	0x6306bb		4c8b4030		MOVQ 0x30(AX), R8									
  module.go:62947	0x6306bf		438974010c		MOVL SI, 0xc(R9)(R8*1)									
  module.go:35797	0x6306c4		4c8b4038		MOVQ 0x38(AX), R8									
  module.go:62929	0x6306c8		4d8d5907		LEAQ 0x7(R9), R11									
  module.go:62929	0x6306cc		4d39d8			CMPQ R8, R11										
  module.go:62929	0x6306cf		0f863a040000		JBE 0x630b0f										
  module.go:35797	0x6306d5		4c8b5830		MOVQ 0x30(AX), R11									
  module.go:62929	0x6306d9		4d8d610b		LEAQ 0xb(R9), R12									
  module.go:35798	0x6306dd		90			NOPL											
  module.go:62930	0x6306de		478b6c1904		MOVL 0x4(R9)(R11*1), R13								
  module.go:62929	0x6306e3		4d39e0			CMPQ R8, R12										
  module.go:62929	0x6306e6		0f861e040000		JBE 0x630b0a										
  module.go:62930	0x6306ec		478b641908		MOVL 0x8(R9)(R11*1), R12								
  module.go:35799	0x6306f1		4501e2			ADDL R12, R10										
  module.go:35802	0x6306f4		4439d2			CMPL DX, R10										
  module.go:35803	0x6306f7		41bc00000000		MOVL $0x0, R12										
  module.go:35803	0x6306fd		440f46e2		CMOVBE DX, R12										
  module.go:35805	0x630701		4529e2			SUBL R12, R10										
  module.go:35805	0x630704		438d54d500		LEAL 0(R13)(R10*8), DX									
  module.go:62972	0x630709		4189d2			MOVL DX, R10										
  module.go:62972	0x63070c		4983c207		ADDQ $0x7, R10										
  module.go:62972	0x630710		4d39d0			CMPQ R8, R10										
  module.go:35802	0x630713		0f86ec030000		JBE 0x630b05										
  module.go:62973	0x630719		4189d0			MOVL DX, R8										
  module.go:62973	0x63071c		4bc7040300000000	MOVQ $0x0, 0(R11)(R8*1)									
  module.go:62973	0x630724		31d2			XORL DX, DX										
  module.go:35806	0x630726		e904030000		JMP 0x630a2f										
  module.go:36026	0x63072b		488b7038		MOVQ 0x38(AX), SI									
  module.go:62955	0x63072f		4c8d471f		LEAQ 0x1f(DI), R8									
  module.go:62955	0x630733		4c39c6			CMPQ SI, R8										
  module.go:62955	0x630736		0f86ee020000		JBE 0x630a2a										
  module.go:36026	0x63073c		488b7030		MOVQ 0x30(AX), SI									
  module.go:36027	0x630740		4c8b4838		MOVQ 0x38(AX), R9									
  module.go:62956	0x630744		488b743718		MOVQ 0x18(DI)(SI*1), SI									
  unsafe.go:41		0x630749		66480f6ec6		MOVQ SI, X0										
  module.go:36027	0x63074e		f20f100d5a182d00	MOVSD_XMM $f64.3ff0000000000000(SB), X1							
  module.go:36027	0x630756		f20f58c8		ADDSD X0, X1										
  module.go:36027	0x63075a		660f1f440000		NOPW 0(AX)(AX*1)									
  module.go:62972	0x630760		4d39c1			CMPQ R9, R8										
  module.go:62972	0x630763		0f86bc020000		JBE 0x630a25										
  module.go:36027	0x630769		488b7030		MOVQ 0x30(AX), SI									
  module.go:62973	0x63076d		f20f114c3718		MOVSD_XMM X1, 0x18(DI)(SI*1)								
  module.go:36028	0x630773		e9a0020000		JMP 0x630a18										
  module.go:35706	0x630778		8974242c		MOVL SI, 0x2c(SP)									
  module.go:35740	0x63077c		bb10000000		MOVL $0x10, BX										
  module.go:35740	0x630781		b901000000		MOVL $0x1, CX										
  module.go:35740	0x630786		e8b5bcf9ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn4(SB)		
  module.go:35742	0x63078b		85c0			TESTL AX, AX										
  module.go:35742	0x63078d		0f8457020000		JE 0x6309ea										
  module.go:35743	0x630793		488b942498000000	MOVQ 0x98(SP), DX									
  module.go:35743	0x63079b		488b7238		MOVQ 0x38(DX), SI									
  module.go:63055	0x63079f		89c7			MOVL AX, DI										
  module.go:63057	0x6307a1		4c8d4710		LEAQ 0x10(DI), R8									
  module.go:63059	0x6307a5		4c39c6			CMPQ SI, R8										
  module.go:63059	0x6307a8		0f8237020000		JB 0x6309e5										
  module.go:35743	0x6307ae		4c8b4230		MOVQ 0x30(DX), R8									
  module.go:63059	0x6307b2		4c01c7			ADDQ R8, DI										
  module.go:63059	0x6307b5		660f1f840000000000	NOPW 0(AX)(AX*1)									
  module.go:63059	0x6307be		6690			NOPW											
  module.go:63059	0x6307c0		4881fe718e1000		CMPQ SI, $0x108e71									
  module.go:63059	0x6307c7		0f820c020000		JB 0x6309d9										
  module.go:35740	0x6307cd		89442420		MOVL AX, 0x20(SP)									
  module.go:63059	0x6307d1		498db0618e1000		LEAQ 0x108e61(R8), SI									
  module.go:63059	0x6307d8		4839fe			CMPQ SI, DI										
  module.go:63059	0x6307db		740b			JE 0x6307e8										
  module.go:63059	0x6307dd		410f1080618e1000	MOVUPS 0x108e61(R8), X0									
  module.go:63059	0x6307e5		0f1107			MOVUPS X0, 0(DI)									
  module.go:35744	0x6307e8		4889d0			MOVQ DX, AX										
  module.go:35744	0x6307eb		bb0c000000		MOVL $0xc, BX										
  module.go:35744	0x6307f0		b904000000		MOVL $0x4, CX										
  module.go:35744	0x6307f5		e846bcf9ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn4(SB)		
  module.go:35744	0x6307fa		660f1f440000		NOPW 0(AX)(AX*1)									
  module.go:35746	0x630800		85c0			TESTL AX, AX										
  module.go:35746	0x630802		0f84a7010000		JE 0x6309af										
  module.go:35750	0x630808		488b8c2498000000	MOVQ 0x98(SP), CX									
  module.go:35750	0x630810		488b5138		MOVQ 0x38(CX), DX									
  module.go:35750	0x630814		89c3			MOVL AX, BX										
  module.go:62946	0x630816		488d730b		LEAQ 0xb(BX), SI									
  module.go:62946	0x63081a		660f1f440000		NOPW 0(AX)(AX*1)									
  module.go:62946	0x630820		4839f2			CMPQ DX, SI										
  module.go:62946	0x630823		0f8681010000		JBE 0x6309aa										
  module.go:35750	0x630829		488b5130		MOVQ 0x30(CX), DX									
  module.go:62947	0x63082d		c744130810000000	MOVL $0x10, 0x8(BX)(DX*1)								
  module.go:35751	0x630835		488b5138		MOVQ 0x38(CX), DX									
  module.go:62946	0x630839		488d7307		LEAQ 0x7(BX), SI									
  module.go:62946	0x63083d		0f1f00			NOPL 0(AX)										
  module.go:62946	0x630840		4839f2			CMPQ DX, SI										
  module.go:62946	0x630843		0f865c010000		JBE 0x6309a5										
  module.go:35751	0x630849		488b5130		MOVQ 0x30(CX), DX									
  module.go:62947	0x63084d		8b742420		MOVL 0x20(SP), SI									
  module.go:62947	0x630851		89741304		MOVL SI, 0x4(BX)(DX*1)									
  module.go:35752	0x630855		488b5138		MOVQ 0x38(CX), DX									
  module.go:62946	0x630859		4883c303		ADDQ $0x3, BX										
  module.go:62946	0x63085d		0f1f00			NOPL 0(AX)										
  module.go:62946	0x630860		4839da			CMPQ DX, BX										
  module.go:62946	0x630863		0f8635010000		JBE 0x63099e										
  module.go:35738	0x630869		8b542430		MOVL 0x30(SP), DX									
  module.go:35738	0x63086d		8d5ae8			LEAL -0x18(DX), BX									
  module.go:35752	0x630870		488b7130		MOVQ 0x30(CX), SI									
  module.go:35753	0x630874		89df			MOVL BX, DI										
  module.go:62947	0x630876		4189c0			MOVL AX, R8										
  module.go:62947	0x630879		42c7040610000000	MOVL $0x10, 0(SI)(R8*1)									
  module.go:35753	0x630881		488b7138		MOVQ 0x38(CX), SI									
  module.go:62946	0x630885		4c8d4707		LEAQ 0x7(DI), R8									
  module.go:62946	0x630889		4c39c6			CMPQ SI, R8										
  module.go:62946	0x63088c		0f8607010000		JBE 0x630999										
  module.go:35753	0x630892		488b7130		MOVQ 0x30(CX), SI									
  module.go:62947	0x630896		c744370490931000	MOVL $0x109390, 0x4(DI)(SI*1)								
  module.go:35754	0x63089e		488b7138		MOVQ 0x38(CX), SI									
  module.go:62946	0x6308a2		4883c703		ADDQ $0x3, DI										
  module.go:62946	0x6308a6		4839fe			CMPQ SI, DI										
  module.go:62946	0x6308a9		0f86e5000000		JBE 0x630994										
  module.go:35754	0x6308af		488b7130		MOVQ 0x30(CX), SI									
  module.go:35756	0x6308b3		8b7c242c		MOVL 0x2c(SP), DI									
  module.go:35756	0x6308b7		89ff			MOVL DI, DI										
  module.go:62947	0x6308b9		89db			MOVL BX, BX										
  module.go:62947	0x6308bb		89041e			MOVL AX, 0(SI)(BX*1)									
  module.go:35756	0x6308be		488b4138		MOVQ 0x38(CX), AX									
  module.go:62929	0x6308c2		488d5f0f		LEAQ 0xf(DI), BX									
  module.go:62929	0x6308c6		4839d8			CMPQ AX, BX										
  module.go:62929	0x6308c9		0f86c0000000		JBE 0x63098f										
  module.go:35756	0x6308cf		488b4130		MOVQ 0x30(CX), AX									
  module.go:62930	0x6308d3		8b5c070c		MOVL 0xc(DI)(AX*1), BX									
  module.go:63130	0x6308d7		8b440708		MOVL 0x8(DI)(AX*1), AX									
  module.go:35703	0x6308db		8d72f8			LEAL -0x8(DX), SI									
  module.go:36165	0x6308de		488b7938		MOVQ 0x38(CX), DI									
  module.go:36166	0x6308e2		4189f0			MOVL SI, R8										
  module.go:62946	0x6308e5		4d8d4807		LEAQ 0x7(R8), R9									
  module.go:62946	0x6308e9		4c39cf			CMPQ DI, R9										
  module.go:62946	0x6308ec		0f8698000000		JBE 0x63098a										
  module.go:36165	0x6308f2		4c8b4930		MOVQ 0x30(CX), R9									
  module.go:62947	0x6308f6		43895c0804		MOVL BX, 0x4(R8)(R9*1)									
  module.go:62946	0x6308fb		498d5803		LEAQ 0x3(R8), BX									
  module.go:36167	0x6308ff		90			NOPL											
  module.go:62946	0x630900		4839df			CMPQ DI, BX										
  module.go:62946	0x630903		0f867c000000		JBE 0x630985										
  module.go:35701	0x630909		8d5af0			LEAL -0x10(DX), BX									
  module.go:36172	0x63090c		89df			MOVL BX, DI										
  module.go:62947	0x63090e		89f6			MOVL SI, SI										
  module.go:62947	0x630910		41890431		MOVL AX, 0(R9)(SI*1)									
  module.go:36168	0x630914		895950			MOVL BX, 0x50(CX)									
  module.go:36172	0x630917		488b4138		MOVQ 0x38(CX), AX									
  module.go:62929	0x63091b		488d5f0f		LEAQ 0xf(DI), BX									
  module.go:62929	0x63091f		90			NOPL											
  module.go:62929	0x630920		4839d8			CMPQ AX, BX										
  module.go:62929	0x630923		765a			JBE 0x63097f										
  module.go:36172	0x630925		488b5930		MOVQ 0x30(CX), BX									
  module.go:62929	0x630929		488d770b		LEAQ 0xb(DI), SI									
  module.go:36175	0x63092d		90			NOPL											
  module.go:62930	0x63092e		448b441f0c		MOVL 0xc(DI)(BX*1), R8									
  module.go:62929	0x630933		4839f0			CMPQ AX, SI										
  module.go:62929	0x630936		7642			JBE 0x63097a										
  module.go:62946	0x630938		8bb424a0000000		MOVL 0xa0(SP), SI									
  module.go:62946	0x63093f		4189f1			MOVL SI, R9										
  module.go:62946	0x630942		4d8d5103		LEAQ 0x3(R9), R10									
  module.go:36176	0x630946		90			NOPL											
  module.go:62930	0x630947		8b7c1f08		MOVL 0x8(DI)(BX*1), DI									
  module.go:62946	0x63094b		4c39d0			CMPQ AX, R10										
  module.go:62946	0x63094e		7625			JBE 0x630975										
  module.go:62947	0x630950		89f6			MOVL SI, SI										
  module.go:62947	0x630952		893c33			MOVL DI, 0(BX)(SI*1)									
  module.go:62946	0x630955		498d7107		LEAQ 0x7(R9), SI									
  module.go:36177	0x630959		90			NOPL											
  module.go:62946	0x63095a		4839f0			CMPQ AX, SI										
  module.go:62946	0x63095d		7611			JBE 0x630970										
  module.go:62947	0x63095f		4589441904		MOVL R8, 0x4(R9)(BX*1)									
  module.go:36178	0x630964		895150			MOVL DX, 0x50(CX)									
  module.go:36179	0x630967		4881c488000000		ADDQ $0x88, SP										
  module.go:36179	0x63096e		5d			POPQ BP											
  module.go:36179	0x63096f		c3			RET											
  module.go:62946	0x630970		e84b00e6ff		CALL runtime.panicBounds(SB)								
  module.go:62946	0x630975		e84600e6ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x63097a		e84100e6ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x63097f		90			NOPL											
  module.go:62929	0x630980		e83b00e6ff		CALL runtime.panicBounds(SB)								
  module.go:62946	0x630985		e83600e6ff		CALL runtime.panicBounds(SB)								
  module.go:62946	0x63098a		e83100e6ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x63098f		e82c00e6ff		CALL runtime.panicBounds(SB)								
  module.go:62946	0x630994		e82700e6ff		CALL runtime.panicBounds(SB)								
  module.go:62946	0x630999		e82200e6ff		CALL runtime.panicBounds(SB)								
  module.go:62946	0x63099e		6690			NOPW											
  module.go:62946	0x6309a0		e81b00e6ff		CALL runtime.panicBounds(SB)								
  module.go:62946	0x6309a5		e81600e6ff		CALL runtime.panicBounds(SB)								
  module.go:62946	0x6309aa		e81100e6ff		CALL runtime.panicBounds(SB)								
  module.go:35747	0x6309af		488b842498000000	MOVQ 0x98(SP), AX									
  module.go:35747	0x6309b7		bb04000000		MOVL $0x4, BX										
  module.go:35747	0x6309bc		b90c000000		MOVL $0xc, CX										
  module.go:35747	0x6309c1		e85a3efaff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn35(SB)		
  module.go:35748	0x6309c6		488d0553a02100		LEAQ 0x21a053(IP), AX									
  module.go:35748	0x6309cd		488d1d5c192d00		LEAQ 0x2d195c(IP), BX									
  module.go:35748	0x6309d4		e8077ee5ff		CALL runtime.gopanic(SB)								
  module.go:63059	0x6309d9		48c7c0718e1000		MOVQ $0x108e71, AX									
  module.go:63059	0x6309e0		e8dbffe5ff		CALL runtime.panicBounds(SB)								
  module.go:63059	0x6309e5		e8d6ffe5ff		CALL runtime.panicBounds(SB)								
  module.go:35763	0x6309ea		488b842498000000	MOVQ 0x98(SP), AX									
  module.go:35763	0x6309f2		bb01000000		MOVL $0x1, BX										
  module.go:35763	0x6309f7		b910000000		MOVL $0x10, CX										
  module.go:35763	0x6309fc		0f1f4000		NOPL 0(AX)										
  module.go:35763	0x630a00		e8bbb7f9ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn2(SB)		
  module.go:35764	0x630a05		488d0514a02100		LEAQ 0x21a014(IP), AX									
  module.go:35764	0x630a0c		488d1d1d192d00		LEAQ 0x2d191d(IP), BX									
  module.go:35764	0x630a13		e8c87de5ff		CALL runtime.gopanic(SB)								
  module.go:35758	0x630a18		89cb			MOVL CX, BX										
  module.go:36165	0x630a1a		4889c1			MOVQ AX, CX										
  module.go:36165	0x630a1d		31c0			XORL AX, AX										
  module.go:36165	0x630a1f		90			NOPL											
  module.go:36163	0x630a20		e9b6feffff		JMP 0x6308db										
  module.go:62972	0x630a25		e896ffe5ff		CALL runtime.panicBounds(SB)								
  module.go:62955	0x630a2a		e891ffe5ff		CALL runtime.panicBounds(SB)								
  module.go:36142	0x630a2f		39d6			CMPL SI, DX										
  module.go:36142	0x630a31		0f86a2000000		JBE 0x630ad9										
  module.go:36146	0x630a37		488b4838		MOVQ 0x38(AX), CX									
  module.go:62929	0x630a3b		498d7107		LEAQ 0x7(R9), SI									
  module.go:62929	0x630a3f		90			NOPL											
  module.go:62929	0x630a40		4839f1			CMPQ CX, SI										
  module.go:62929	0x630a43		0f868b000000		JBE 0x630ad4										
  module.go:36146	0x630a49		488b7030		MOVQ 0x30(AX), SI									
  module.go:62929	0x630a4d		498d790b		LEAQ 0xb(R9), DI									
  module.go:36147	0x630a51		90			NOPL											
  module.go:62930	0x630a52		458b443104		MOVL 0x4(R9)(SI*1), R8									
  module.go:62929	0x630a57		4839f9			CMPQ CX, DI										
  module.go:62929	0x630a5a		7673			JBE 0x630acf										
  module.go:62930	0x630a5c		418b7c3108		MOVL 0x8(R9)(SI*1), DI									
  module.go:36148	0x630a61		01fa			ADDL DI, DX										
  module.go:63130	0x630a63		89db			MOVL BX, BX										
  module.go:63130	0x630a65		8b1c33			MOVL 0(BX)(SI*1), BX									
  module.go:36149	0x630a68		90			NOPL											
  module.go:36153	0x630a69		39d3			CMPL BX, DX										
  module.go:36153	0x630a6b		7602			JBE 0x630a6f										
  module.go:36153	0x630a6d		31db			XORL BX, BX										
  module.go:36156	0x630a6f		29da			SUBL BX, DX										
  module.go:36156	0x630a71		418d14d0		LEAL 0(R8)(DX*8), DX									
  module.go:62955	0x630a75		89d3			MOVL DX, BX										
  module.go:62955	0x630a77		4883c307		ADDQ $0x7, BX										
  module.go:36157	0x630a7b		90			NOPL											
  module.go:36157	0x630a7c		0f1f4000		NOPL 0(AX)										
  module.go:62955	0x630a80		4839d9			CMPQ CX, BX										
  module.go:62955	0x630a83		7645			JBE 0x630aca										
  module.go:36158	0x630a85		488b4838		MOVQ 0x38(AX), CX									
  module.go:62956	0x630a89		89d7			MOVL DX, DI										
  module.go:62956	0x630a8b		488b3437		MOVQ 0(DI)(SI*1), SI									
  unsafe.go:41		0x630a8f		66480f6ec6		MOVQ SI, X0										
  module.go:36157	0x630a94		90			NOPL											
  module.go:36158	0x630a95		f20f100d13152d00	MOVSD_XMM $f64.3ff0000000000000(SB), X1							
  module.go:36158	0x630a9d		f20f58c1		ADDSD X1, X0										
  module.go:62972	0x630aa1		4839d9			CMPQ CX, BX										
  module.go:62972	0x630aa4		761f			JBE 0x630ac5										
  module.go:36158	0x630aa6		488b7030		MOVQ 0x30(AX), SI									
  module.go:62973	0x630aaa		f20f11043e		MOVSD_XMM X0, 0(SI)(DI*1)								
  module.go:62946	0x630aaf		8b9c24a0000000		MOVL 0xa0(SP), BX									
  module.go:36160	0x630ab6		89d1			MOVL DX, CX										
  module.go:35703	0x630ab8		8b542430		MOVL 0x30(SP), DX									
  module.go:35703	0x630abc		0f1f4000		NOPL 0(AX)										
  module.go:36161	0x630ac0		e953ffffff		JMP 0x630a18										
  module.go:62972	0x630ac5		e8f6fee5ff		CALL runtime.panicBounds(SB)								
  module.go:62955	0x630aca		e8f1fee5ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x630acf		e8ecfee5ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x630ad4		e8e7fee5ff		CALL runtime.panicBounds(SB)								
  module.go:36143	0x630ad9		bbf88e1000		MOVL $0x108ef8, BX									
  module.go:36143	0x630ade		b914000000		MOVL $0x14, CX										
  module.go:36143	0x630ae3		bf0c8f1000		MOVL $0x108f0c, DI									
  module.go:36143	0x630ae8		e893effaff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn69(SB)		
  module.go:36144	0x630aed		488d052c9f2100		LEAQ 0x219f2c(IP), AX									
  module.go:36144	0x630af4		488d1d35182d00		LEAQ 0x2d1835(IP), BX									
  module.go:36144	0x630afb		0f1f440000		NOPL 0(AX)(AX*1)									
  module.go:36144	0x630b00		e8db7ce5ff		CALL runtime.gopanic(SB)								
  module.go:62972	0x630b05		e8b6fee5ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x630b0a		e8b1fee5ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x630b0f		e8acfee5ff		CALL runtime.panicBounds(SB)								
  module.go:62946	0x630b14		e8a7fee5ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x630b19		e8a2fee5ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x630b1e		6690			NOPW											
  module.go:62929	0x630b20		e89bfee5ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x630b25		e896fee5ff		CALL runtime.panicBounds(SB)								
  module.go:62946	0x630b2a		e891fee5ff		CALL runtime.panicBounds(SB)								
  module.go:36020	0x630b2f		488b5038		MOVQ 0x38(AX), DX									
  module.go:62929	0x630b33		4c39ea			CMPQ DX, R13										
  module.go:62929	0x630b36		7613			JBE 0x630b4b										
  module.go:36020	0x630b38		4c8b4030		MOVQ 0x30(AX), R8									
  module.go:36021	0x630b3c		90			NOPL											
  module.go:62947	0x630b3d		43297c0110		SUBL DI, 0x10(R9)(R8*1)									
  module.go:62947	0x630b42		31d2			XORL DX, DX										
  module.go:36141	0x630b44		89ce			MOVL CX, SI										
  module.go:36023	0x630b46		e9e4feffff		JMP 0x630a2f										
  module.go:62929	0x630b4b		e870fee5ff		CALL runtime.panicBounds(SB)								
  module.go:36014	0x630b50		ffcf			DECL DI											
  module.go:63130	0x630b52		4c8b542468		MOVQ 0x68(SP), R10									
  module.go:36016	0x630b57		89f1			MOVL SI, CX										
  module.go:35992	0x630b59		4439e1			CMPL CX, R12										
  module.go:35992	0x630b5c		7567			JNE 0x630bc5										
  module.go:36016	0x630b5e		897c244c		MOVL DI, 0x4c(SP)									
  module.go:35993	0x630b62		e8f93dfbff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn88(SB)		
  module.go:35994	0x630b67		488b842498000000	MOVQ 0x98(SP), AX									
  module.go:35994	0x630b6f		488b4838		MOVQ 0x38(AX), CX									
  module.go:62929	0x630b73		488b542478		MOVQ 0x78(SP), DX									
  module.go:62929	0x630b78		0f1f840000000000	NOPL 0(AX)(AX*1)									
  module.go:62929	0x630b80		4839d1			CMPQ CX, DX										
  module.go:62929	0x630b83		0f86e1000000		JBE 0x630c6a										
  module.go:35994	0x630b89		488b7030		MOVQ 0x30(AX), SI									
  module.go:35996	0x630b8d		90			NOPL											
  module.go:62930	0x630b8e		4c8b842480000000	MOVQ 0x80(SP), R8									
  module.go:62930	0x630b96		418b4c300c		MOVL 0xc(R8)(SI*1), CX									
  module.go:63130	0x630b9b		4c8b4c2468		MOVQ 0x68(SP), R9									
  module.go:63130	0x630ba0		458b2431		MOVL 0(R9)(SI*1), R12									
  module.go:62947	0x630ba4		8b542424		MOVL 0x24(SP), DX									
  module.go:35993	0x630ba8		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:36015	0x630baf		8b7c244c		MOVL 0x4c(SP), DI									
  module.go:62947	0x630bb3		4d89c1			MOVQ R8, R9										
  module.go:63130	0x630bb6		4c8b542468		MOVQ 0x68(SP), R10									
  module.go:62946	0x630bbb		4c8b5c2478		MOVQ 0x78(SP), R11									
  module.go:62929	0x630bc0		4c8b6c2470		MOVQ 0x70(SP), R13									
  module.go:36001	0x630bc5		488b7038		MOVQ 0x38(AX), SI									
  module.go:62946	0x630bc9		4c39de			CMPQ SI, R11										
  module.go:62946	0x630bcc		0f8693000000		JBE 0x630c65										
  module.go:36000	0x630bd2		8d7101			LEAL 0x1(CX), SI									
  module.go:36001	0x630bd5		4c8b4030		MOVQ 0x30(AX), R8									
  module.go:62947	0x630bd9		438974010c		MOVL SI, 0xc(R9)(R8*1)									
  module.go:36002	0x630bde		4c8b4038		MOVQ 0x38(AX), R8									
  module.go:62929	0x630be2		4d8d790b		LEAQ 0xb(R9), R15									
  module.go:62929	0x630be6		4d39f8			CMPQ R8, R15										
  module.go:62929	0x630be9		7671			JBE 0x630c5c										
  module.go:36002	0x630beb		4c8b4030		MOVQ 0x30(AX), R8									
  module.go:62930	0x630bef		478b7c0108		MOVL 0x8(R9)(R8*1), R15									
  module.go:36004	0x630bf4		418d4fff		LEAL -0x1(R15), CX									
  module.go:36005	0x630bf8		478d3c3c		LEAL 0(R12)(R15*1), R15									
  module.go:36005	0x630bfc		458d7fff		LEAL -0x1(R15), R15									
  module.go:62929	0x630c00		4d8d5107		LEAQ 0x7(R9), R10									
  module.go:36011	0x630c04		90			NOPL											
  module.go:36007	0x630c05		4139cf			CMPL R15, CX										
  module.go:36008	0x630c08		410f42cf		CMOVB R15, CX										
  module.go:62947	0x630c0c		43894c0108		MOVL CX, 0x8(R9)(R8*1)									
  module.go:36012	0x630c11		4c8b4038		MOVQ 0x38(AX), R8									
  module.go:62929	0x630c15		4d39d0			CMPQ R8, R10										
  module.go:62929	0x630c18		763d			JBE 0x630c57										
  module.go:36012	0x630c1a		4c8b5030		MOVQ 0x30(AX), R10									
  module.go:62930	0x630c1e		478b7c1104		MOVL 0x4(R9)(R10*1), R15								
  module.go:36013	0x630c23		458d3ccf		LEAL 0(R15)(CX*8), R15									
  module.go:62972	0x630c27		4489f9			MOVL R15, CX										
  module.go:62972	0x630c2a		4883c107		ADDQ $0x7, CX										
  module.go:62972	0x630c2e		4939c8			CMPQ R8, CX										
  module.go:62972	0x630c31		761f			JBE 0x630c52										
  module.go:62973	0x630c33		4589f8			MOVL R15, R8										
  module.go:62973	0x630c36		4bc7040200000000	MOVQ $0x0, 0(R10)(R8*1)									
  module.go:62973	0x630c3e		6690			NOPW											
  module.go:36015	0x630c40		83ff01			CMPL DI, $0x1										
  module.go:36015	0x630c43		0f8507ffffff		JNE 0x630b50										
  module.go:62947	0x630c49		89d7			MOVL DX, DI										
  module.go:62947	0x630c4b		89f1			MOVL SI, CX										
  module.go:36015	0x630c4d		e9ddfeffff		JMP 0x630b2f										
  module.go:62972	0x630c52		e869fde5ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x630c57		e864fde5ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x630c5c		0f1f4000		NOPL 0(AX)										
  module.go:62929	0x630c60		e85bfde5ff		CALL runtime.panicBounds(SB)								
  module.go:62946	0x630c65		e856fde5ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x630c6a		e851fde5ff		CALL runtime.panicBounds(SB)								
  module.go:63059	0x630c6f		e84cfde5ff		CALL runtime.panicBounds(SB)								
  module.go:63059	0x630c74		e847fde5ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x630c79		e842fde5ff		CALL runtime.panicBounds(SB)								
  module.go:62946	0x630c7e		6690			NOPW											
  module.go:62946	0x630c80		e83bfde5ff		CALL runtime.panicBounds(SB)								
  module.go:63059	0x630c85		e836fde5ff		CALL runtime.panicBounds(SB)								
  module.go:63059	0x630c8a		e831fde5ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x630c8f		e82cfde5ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x630c94		e827fde5ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x630c99		e822fde5ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x630c9e		6690			NOPW											
  module.go:62929	0x630ca0		e81bfde5ff		CALL runtime.panicBounds(SB)								
  module.go:35934	0x630ca5		bb508e1000		MOVL $0x108e50, BX									
  module.go:35934	0x630caa		b911000000		MOVL $0x11, CX										
  module.go:35934	0x630caf		bfe88e1000		MOVL $0x108ee8, DI									
  module.go:35934	0x630cb4		e8c7edfaff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn69(SB)		
  module.go:35935	0x630cb9		488d05609d2100		LEAQ 0x219d60(IP), AX									
  module.go:35935	0x630cc0		488d1d69162d00		LEAQ 0x2d1669(IP), BX									
  module.go:35935	0x630cc7		e8147be5ff		CALL runtime.gopanic(SB)								
  module.go:62929	0x630ccc		e8effce5ff		CALL runtime.panicBounds(SB)								
  module.go:36089	0x630cd1		4439d6			CMPL SI, R10										
  module.go:36089	0x630cd4		7602			JBE 0x630cd8										
  module.go:36089	0x630cd6		31f6			XORL SI, SI										
  module.go:36092	0x630cd8		4129f2			SUBL SI, R10										
  module.go:36092	0x630cdb		438d34d3		LEAL 0(R11)(R10*8), SI									
  module.go:36093	0x630cdf		4c8b5038		MOVQ 0x38(AX), R10									
  module.go:62955	0x630ce3		4189f3			MOVL SI, R11										
  module.go:62955	0x630ce6		4983c307		ADDQ $0x7, R11										
  module.go:62955	0x630cea		4d39da			CMPQ R10, R11										
  module.go:62955	0x630ced		0f86f7010000		JBE 0x630eea										
  module.go:36093	0x630cf3		4c8b5030		MOVQ 0x30(AX), R10									
  module.go:36094	0x630cf7		4c8b6038		MOVQ 0x38(AX), R12									
  module.go:62956	0x630cfb		89f6			MOVL SI, SI										
  module.go:62956	0x630cfd		4e8b1416		MOVQ 0(SI)(R10*1), R10									
  module.go:36093	0x630d01		66490f6eca		MOVQ R10, X1										
  module.go:36094	0x630d06		f20f58c1		ADDSD X1, X0										
  module.go:62972	0x630d0a		4d39dc			CMPQ R12, R11										
  module.go:62972	0x630d0d		0f86d2010000		JBE 0x630ee5										
  module.go:36094	0x630d13		4c8b5030		MOVQ 0x30(AX), R10									
  module.go:62973	0x630d17		f2410f110432		MOVSD_XMM X0, 0(R10)(SI*1)								
  module.go:36099	0x630d1d		488b7038		MOVQ 0x38(AX), SI									
  module.go:36098	0x630d21		448d143a		LEAL 0(DX)(DI*1), R10									
  module.go:36098	0x630d25		8d143a			LEAL 0(DX)(DI*1), DX									
  module.go:36098	0x630d28		8d5201			LEAL 0x1(DX), DX									
  module.go:62946	0x630d2b		4c39ee			CMPQ SI, R13										
  module.go:62946	0x630d2e		0f86aa010000		JBE 0x630ede										
  module.go:36099	0x630d34		488b7030		MOVQ 0x30(AX), SI									
  module.go:62947	0x630d38		4189543110		MOVL DX, 0x10(R9)(SI*1)									
  module.go:36100	0x630d3d		4529d0			SUBL R10, R8										
  module.go:36100	0x630d40		418d50ff		LEAL -0x1(R8), DX									
  module.go:36103	0x630d44		89d6			MOVL DX, SI										
  module.go:36103	0x630d46		29ca			SUBL CX, DX										
  module.go:36103	0x630d48		81fafeffff7f		CMPL DX, $0x7ffffffe									
  module.go:36103	0x630d4e		773d			JA 0x630d8d										
  module.go:36107	0x630d50		488b5038		MOVQ 0x38(AX), DX									
  module.go:62929	0x630d54		4d8d4103		LEAQ 0x3(R9), R8									
  module.go:62929	0x630d58		0f1f840000000000	NOPL 0(AX)(AX*1)									
  module.go:62929	0x630d60		4c39c2			CMPQ DX, R8										
  module.go:62929	0x630d63		0f8670010000		JBE 0x630ed9										
  module.go:62929	0x630d69		4c89442470		MOVQ R8, 0x70(SP)									
  module.go:36100	0x630d6e		8974244c		MOVL SI, 0x4c(SP)									
  module.go:36107	0x630d72		488b5030		MOVQ 0x30(AX), DX									
  module.go:62930	0x630d76		4189da			MOVL BX, R10										
  module.go:62930	0x630d79		4c89542468		MOVQ R10, 0x68(SP)									
  module.go:36106	0x630d7e		448d59ff		LEAL -0x1(CX), R11									
  module.go:62930	0x630d82		418b1412		MOVL 0(R10)(DX*1), DX									
  module.go:36109	0x630d86		4c8b642478		MOVQ 0x78(SP), R12									
  module.go:36109	0x630d8b		eb21			JMP 0x630dae										
  module.go:36022	0x630d8d		89f2			MOVL SI, DX										
  module.go:36141	0x630d8f		89ce			MOVL CX, SI										
  module.go:36104	0x630d91		e999fcffff		JMP 0x630a2f										
  module.go:62929	0x630d96		4c8b442470		MOVQ 0x70(SP), R8									
  module.go:62930	0x630d9b		4c8b542468		MOVQ 0x68(SP), R10									
  module.go:36137	0x630da0		4489e9			MOVL R13, CX										
  module.go:36137	0x630da3		4589cb			MOVL R9, R11										
  module.go:62947	0x630da6		4c8b8c2480000000	MOVQ 0x80(SP), R9									
  module.go:36113	0x630dae		39ca			CMPL DX, CX										
  module.go:36113	0x630db0		7574			JNE 0x630e26										
  module.go:36137	0x630db2		44895c2424		MOVL R11, 0x24(SP)									
  module.go:36114	0x630db7		e8a43bfbff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn88(SB)		
  module.go:36115	0x630dbc		488b842498000000	MOVQ 0x98(SP), AX									
  module.go:36115	0x630dc4		488b4838		MOVQ 0x38(AX), CX									
  module.go:62929	0x630dc8		488b542470		MOVQ 0x70(SP), DX									
  module.go:62929	0x630dcd		4839d1			CMPQ CX, DX										
  module.go:62929	0x630dd0		0f86fe000000		JBE 0x630ed4										
  module.go:36115	0x630dd6		488b7030		MOVQ 0x30(AX), SI									
  module.go:62930	0x630dda		4c8b442468		MOVQ 0x68(SP), R8									
  module.go:62930	0x630ddf		458b0c30		MOVL 0(R8)(SI*1), R9									
  module.go:62929	0x630de3		4c8b542478		MOVQ 0x78(SP), R10									
  module.go:62929	0x630de8		4c39d1			CMPQ CX, R10										
  module.go:62929	0x630deb		0f86de000000		JBE 0x630ecf										
  module.go:62930	0x630df1		4c8b9c2480000000	MOVQ 0x80(SP), R11									
  module.go:62930	0x630df9		418b4c330c		MOVL 0xc(R11)(SI*1), CX									
  module.go:36114	0x630dfe		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:36136	0x630e05		8b74244c		MOVL 0x4c(SP), SI									
  module.go:62929	0x630e09		4989d0			MOVQ DX, R8										
  module.go:62930	0x630e0c		4c8b542468		MOVQ 0x68(SP), R10									
  module.go:36135	0x630e11		448b5c2424		MOVL 0x24(SP), R11									
  module.go:62946	0x630e16		4c8b642478		MOVQ 0x78(SP), R12									
  module.go:36117	0x630e1b		4489ca			MOVL R9, DX										
  module.go:62947	0x630e1e		4c8b8c2480000000	MOVQ 0x80(SP), R9									
  module.go:36124	0x630e26		4c8b6838		MOVQ 0x38(AX), R13									
  module.go:62946	0x630e2a		4d39e5			CMPQ R13, R12										
  module.go:62946	0x630e2d		0f8697000000		JBE 0x630eca										
  module.go:36123	0x630e33		448d6901		LEAL 0x1(CX), R13									
  module.go:36124	0x630e37		4c8b7830		MOVQ 0x30(AX), R15									
  module.go:62947	0x630e3b		47896c390c		MOVL R13, 0xc(R9)(R15*1)								
  module.go:36125	0x630e40		4c8b7838		MOVQ 0x38(AX), R15									
  module.go:62929	0x630e44		498d7907		LEAQ 0x7(R9), DI									
  module.go:62929	0x630e48		4939ff			CMPQ R15, DI										
  module.go:62929	0x630e4b		7678			JBE 0x630ec5										
  module.go:36125	0x630e4d		488b7830		MOVQ 0x30(AX), DI									
  module.go:62929	0x630e51		4d8d510b		LEAQ 0xb(R9), R10									
  module.go:36126	0x630e55		90			NOPL											
  module.go:62930	0x630e56		458b443904		MOVL 0x4(R9)(DI*1), R8									
  module.go:62930	0x630e5b		0f1f440000		NOPL 0(AX)(AX*1)									
  module.go:62929	0x630e60		4d39d7			CMPQ R15, R10										
  module.go:62929	0x630e63		7656			JBE 0x630ebb										
  module.go:62930	0x630e65		458b543908		MOVL 0x8(R9)(DI*1), R10									
  module.go:36127	0x630e6a		4101ca			ADDL CX, R10										
  module.go:36130	0x630e6d		4439d2			CMPL DX, R10										
  module.go:35773	0x630e70		4c89c9			MOVQ R9, CX										
  module.go:36131	0x630e73		41b900000000		MOVL $0x0, R9										
  module.go:36131	0x630e79		440f46ca		CMOVBE DX, R9										
  module.go:36133	0x630e7d		4529ca			SUBL R9, R10										
  module.go:36133	0x630e80		478d04d0		LEAL 0(R8)(R10*8), R8									
  module.go:62972	0x630e84		4589c1			MOVL R8, R9										
  module.go:62972	0x630e87		4983c107		ADDQ $0x7, R9										
  module.go:62972	0x630e8b		4d39cf			CMPQ R15, R9										
  module.go:36130	0x630e8e		7626			JBE 0x630eb6										
  module.go:36135	0x630e90		458d4b01		LEAL 0x1(R11), R9									
  module.go:62973	0x630e94		4589c0			MOVL R8, R8										
  module.go:62973	0x630e97		4ac7040700000000	MOVQ $0x0, 0(DI)(R8*1)									
  module.go:62973	0x630e9f		90			NOPL											
  module.go:36136	0x630ea0		4439ce			CMPL SI, R9										
  module.go:36136	0x630ea3		0f85edfeffff		JNE 0x630d96										
  module.go:62929	0x630ea9		4989c9			MOVQ CX, R9										
  module.go:36022	0x630eac		89f2			MOVL SI, DX										
  module.go:36141	0x630eae		4489ee			MOVL R13, SI										
  module.go:36136	0x630eb1		e979fbffff		JMP 0x630a2f										
  module.go:62972	0x630eb6		e805fbe5ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x630ebb		0f1f440000		NOPL 0(AX)(AX*1)									
  module.go:62929	0x630ec0		e8fbfae5ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x630ec5		e8f6fae5ff		CALL runtime.panicBounds(SB)								
  module.go:62946	0x630eca		e8f1fae5ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x630ecf		e8ecfae5ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x630ed4		e8e7fae5ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x630ed9		e8e2fae5ff		CALL runtime.panicBounds(SB)								
  module.go:62946	0x630ede		6690			NOPW											
  module.go:62946	0x630ee0		e8dbfae5ff		CALL runtime.panicBounds(SB)								
  module.go:62972	0x630ee5		e8d6fae5ff		CALL runtime.panicBounds(SB)								
  module.go:62955	0x630eea		e8d1fae5ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x630eef		e8ccfae5ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x630ef4		e8c7fae5ff		CALL runtime.panicBounds(SB)								
  module.go:35896	0x630ef9		83c6fe			ADDL $-0x2, SI										
  module.go:35898	0x630efc		894c2420		MOVL CX, 0x20(SP)									
  module.go:35898	0x630f00		8b4c243c		MOVL 0x3c(SP), CX									
  module.go:35844	0x630f04		85c9			TESTL CX, CX										
  module.go:35844	0x630f06		750a			JNE 0x630f12										
  module.go:35844	0x630f08		31c9			XORL CX, CX										
  module.go:35844	0x630f0a		0f57c9			XORPS X1, X1										
  module.go:35848	0x630f0d		e998000000		JMP 0x630faa										
  module.go:35852	0x630f12		4c8b7838		MOVQ 0x38(AX), R15									
  module.go:62946	0x630f16		4d39df			CMPQ R15, R11										
  module.go:62946	0x630f19		0f867a030000		JBE 0x631299										
  module.go:35851	0x630f1f		448d79ff		LEAL -0x1(CX), R15									
  module.go:35852	0x630f23		488b4830		MOVQ 0x30(AX), CX									
  module.go:62947	0x630f27		45897c090c		MOVL R15, 0xc(R9)(CX*1)									
  module.go:35854	0x630f2c		418d4d01		LEAL 0x1(R13), CX									
  module.go:35857	0x630f30		4139cc			CMPL R12, CX										
  module.go:35857	0x630f33		7705			JA 0x630f3a										
  module.go:63130	0x630f35		4489e1			MOVL R12, CX										
  module.go:35858	0x630f38		eb06			JMP 0x630f40										
  module.go:35884	0x630f3a		4489e1			MOVL R12, CX										
  module.go:35884	0x630f3d		4531e4			XORL R12, R12										
  module.go:35898	0x630f40		44896c2428		MOVL R13, 0x28(SP)									
  module.go:35861	0x630f45		4c8b4038		MOVQ 0x38(AX), R8									
  module.go:35860	0x630f49		4529e5			SUBL R12, R13										
  module.go:62946	0x630f4c		4939d8			CMPQ R8, BX										
  module.go:62946	0x630f4f		0f863f030000		JBE 0x631294										
  module.go:35860	0x630f55		458d4501		LEAL 0x1(R13), R8									
  module.go:35861	0x630f59		4c8b6030		MOVQ 0x30(AX), R12									
  module.go:62947	0x630f5d		4789442108		MOVL R8, 0x8(R9)(R12*1)									
  module.go:35862	0x630f62		4c8b6038		MOVQ 0x38(AX), R12									
  module.go:35862	0x630f66		448b6c2428		MOVL 0x28(SP), R13									
  module.go:35862	0x630f6b		468d2cea		LEAL 0(DX)(R13*8), R13									
  module.go:62955	0x630f6f		4489ef			MOVL R13, DI										
  module.go:62955	0x630f72		4883c707		ADDQ $0x7, DI										
  module.go:62955	0x630f76		4939fc			CMPQ R12, DI										
  module.go:62955	0x630f79		0f8610030000		JBE 0x63128f										
  module.go:35862	0x630f7f		4c8b6030		MOVQ 0x30(AX), R12									
  module.go:62956	0x630f83		4489ef			MOVL R13, DI										
  module.go:62956	0x630f86		4e8b2427		MOVQ 0(DI)(R12*1), R12									
  unsafe.go:41		0x630f8a		66490f6ecc		MOVQ R12, X1										
  module.go:36068	0x630f8f		8b7c2444		MOVL 0x44(SP), DI									
  module.go:35884	0x630f93		4189cc			MOVL CX, R12										
  module.go:35862	0x630f96		4489f9			MOVL R15, CX										
  module.go:35862	0x630f99		4589c5			MOVL R8, R13										
  module.go:35862	0x630f9c		894c2420		MOVL CX, 0x20(SP)									
  module.go:36100	0x630fa0		448b442448		MOVL 0x48(SP), R8									
  module.go:63130	0x630fa5		4c8b7c2468		MOVQ 0x68(SP), R15									
  module.go:35868	0x630faa		f20f58c8		ADDSD X0, X1										
  module.go:35871	0x630fae		85c9			TESTL CX, CX										
  module.go:35871	0x630fb0		7516			JNE 0x630fc8										
  module.go:35871	0x630fb2		0f57c0			XORPS X0, X0										
  module.go:35889	0x630fb5		8b4c2420		MOVL 0x20(SP), CX									
  module.go:35889	0x630fb9		31c9			XORL CX, CX										
  module.go:35889	0x630fbb		894c243c		MOVL CX, 0x3c(SP)									
  module.go:35889	0x630fbf		8b4c2420		MOVL 0x20(SP), CX									
  module.go:35875	0x630fc3		e998000000		JMP 0x631060										
  module.go:35879	0x630fc8		4c8b7838		MOVQ 0x38(AX), R15									
  module.go:62946	0x630fcc		4d39df			CMPQ R15, R11										
  module.go:62946	0x630fcf		0f86b5020000		JBE 0x63128a										
  module.go:35878	0x630fd5		448d79ff		LEAL -0x1(CX), R15									
  module.go:35879	0x630fd9		488b4830		MOVQ 0x30(AX), CX									
  module.go:62947	0x630fdd		45897c090c		MOVL R15, 0xc(R9)(CX*1)									
  module.go:35881	0x630fe2		418d4d01		LEAL 0x1(R13), CX									
  module.go:35884	0x630fe6		4139cc			CMPL R12, CX										
  module.go:35884	0x630fe9		7705			JA 0x630ff0										
  module.go:63130	0x630feb		4489e1			MOVL R12, CX										
  module.go:35885	0x630fee		eb06			JMP 0x630ff6										
  module.go:35857	0x630ff0		4489e1			MOVL R12, CX										
  module.go:35857	0x630ff3		4531e4			XORL R12, R12										
  module.go:35862	0x630ff6		44896c2440		MOVL R13, 0x40(SP)									
  module.go:35888	0x630ffb		4c8b4038		MOVQ 0x38(AX), R8									
  module.go:35887	0x630fff		4529e5			SUBL R12, R13										
  module.go:62946	0x631002		4939d8			CMPQ R8, BX										
  module.go:62946	0x631005		0f867a020000		JBE 0x631285										
  module.go:35887	0x63100b		458d4501		LEAL 0x1(R13), R8									
  module.go:35888	0x63100f		4c8b6030		MOVQ 0x30(AX), R12									
  module.go:62947	0x631013		4789442108		MOVL R8, 0x8(R9)(R12*1)									
  module.go:35889	0x631018		4c8b6038		MOVQ 0x38(AX), R12									
  module.go:35889	0x63101c		448b6c2440		MOVL 0x40(SP), R13									
  module.go:35889	0x631021		468d2cea		LEAL 0(DX)(R13*8), R13									
  module.go:62955	0x631025		4489ef			MOVL R13, DI										
  module.go:62955	0x631028		4883c707		ADDQ $0x7, DI										
  module.go:62955	0x63102c		4939fc			CMPQ R12, DI										
  module.go:62955	0x63102f		0f8649020000		JBE 0x63127e										
  module.go:35889	0x631035		4c8b6030		MOVQ 0x30(AX), R12									
  module.go:62956	0x631039		4489ef			MOVL R13, DI										
  module.go:62956	0x63103c		4e8b2427		MOVQ 0(DI)(R12*1), R12									
  unsafe.go:41		0x631040		66490f6ec4		MOVQ R12, X0										
  module.go:36068	0x631045		8b7c2444		MOVL 0x44(SP), DI									
  module.go:35857	0x631049		4189cc			MOVL CX, R12										
  module.go:35889	0x63104c		4589c5			MOVL R8, R13										
  module.go:35889	0x63104f		4489f9			MOVL R15, CX										
  module.go:35889	0x631052		894c243c		MOVL CX, 0x3c(SP)									
  module.go:36100	0x631056		448b442448		MOVL 0x48(SP), R8									
  module.go:63130	0x63105b		4c8b7c2468		MOVQ 0x68(SP), R15									
  module.go:35895	0x631060		f20f58c1		ADDSD X1, X0										
  module.go:35897	0x631064		83fe02			CMPL SI, $0x2										
  module.go:35897	0x631067		0f858cfeffff		JNE 0x630ef9										
  module.go:36031	0x63106d		410fbae200		BTL $0x0, R10										
  module.go:36031	0x631072		7207			JB 0x63107b										
  module.go:36032	0x631074		89ce			MOVL CX, SI										
  module.go:36032	0x631076		e99e000000		JMP 0x631119										
  module.go:36034	0x63107b		89ce			MOVL CX, SI										
  module.go:36034	0x63107d		8b4c243c		MOVL 0x3c(SP), CX									
  module.go:36035	0x631081		85c9			TESTL CX, CX										
  module.go:36035	0x631083		0f8489000000		JE 0x631112										
  module.go:36038	0x631089		488b7038		MOVQ 0x38(AX), SI									
  module.go:62946	0x63108d		4c39de			CMPQ SI, R11										
  module.go:62946	0x631090		0f86e3010000		JBE 0x631279										
  module.go:36037	0x631096		8d71ff			LEAL -0x1(CX), SI									
  module.go:36038	0x631099		4c8b5030		MOVQ 0x30(AX), R10									
  module.go:62947	0x63109d		438974110c		MOVL SI, 0xc(R9)(R10*1)									
  module.go:36040	0x6310a2		458d5501		LEAL 0x1(R13), R10									
  module.go:36043	0x6310a6		4539d4			CMPL R12, R10										
  module.go:36043	0x6310a9		7705			JA 0x6310b0										
  module.go:63130	0x6310ab		4489e1			MOVL R12, CX										
  module.go:36044	0x6310ae		eb06			JMP 0x6310b6										
  module.go:36058	0x6310b0		4489e1			MOVL R12, CX										
  module.go:36058	0x6310b3		4531e4			XORL R12, R12										
  module.go:36034	0x6310b6		44896c2438		MOVL R13, 0x38(SP)									
  module.go:36047	0x6310bb		4c8b5038		MOVQ 0x38(AX), R10									
  module.go:36046	0x6310bf		4529e5			SUBL R12, R13										
  module.go:62946	0x6310c2		4939da			CMPQ R10, BX										
  module.go:62946	0x6310c5		0f86a9010000		JBE 0x631274										
  module.go:36046	0x6310cb		458d5501		LEAL 0x1(R13), R10									
  module.go:36047	0x6310cf		4c8b6030		MOVQ 0x30(AX), R12									
  module.go:62947	0x6310d3		4789542108		MOVL R10, 0x8(R9)(R12*1)								
  module.go:36048	0x6310d8		4c8b6038		MOVQ 0x38(AX), R12									
  module.go:36048	0x6310dc		448b6c2438		MOVL 0x38(SP), R13									
  module.go:36048	0x6310e1		468d2cea		LEAL 0(DX)(R13*8), R13									
  module.go:62955	0x6310e5		4589ef			MOVL R13, R15										
  module.go:62955	0x6310e8		4983c707		ADDQ $0x7, R15										
  module.go:62955	0x6310ec		4d39fc			CMPQ R12, R15										
  module.go:62955	0x6310ef		0f867a010000		JBE 0x63126f										
  module.go:36048	0x6310f5		4c8b6030		MOVQ 0x30(AX), R12									
  module.go:62956	0x6310f9		4589ef			MOVL R13, R15										
  module.go:62956	0x6310fc		4f8b2427		MOVQ 0(R15)(R12*1), R12									
  unsafe.go:41		0x631100		66490f6ecc		MOVQ R12, X1										
  module.go:36058	0x631105		4189cc			MOVL CX, R12										
  module.go:63130	0x631108		4c8b7c2468		MOVQ 0x68(SP), R15									
  module.go:36048	0x63110d		4589d5			MOVL R10, R13										
  module.go:36050	0x631110		eb03			JMP 0x631115										
  module.go:36050	0x631112		0f57c9			XORPS X1, X1										
  module.go:36052	0x631115		f20f58c1		ADDSD X1, X0										
  module.go:36054	0x631119		85f6			TESTL SI, SI										
  module.go:36054	0x63111b		7423			JE 0x631140										
  module.go:62930	0x63111d		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:35907	0x631124		4589ea			MOVL R13, R10										
  module.go:36055	0x631127		89f1			MOVL SI, CX										
  module.go:36055	0x631129		4189d3			MOVL DX, R11										
  module.go:36098	0x63112c		8b54244c		MOVL 0x4c(SP), DX									
  module.go:62946	0x631130		4c8b6c2470		MOVQ 0x70(SP), R13									
  module.go:36055	0x631135		4489e6			MOVL R12, SI										
  module.go:36055	0x631138		e994fbffff		JMP 0x630cd1										
  module.go:36055	0x63113d		0f1f00			NOPL 0(AX)										
  module.go:36058	0x631140		4585e4			TESTL R12, R12										
  module.go:36058	0x631143		740a			JE 0x63114f										
  module.go:36058	0x631145		b901000000		MOVL $0x1, CX										
  module.go:36058	0x63114a		e99a000000		JMP 0x6311e9										
  module.go:62929	0x63114f		48895c2460		MOVQ BX, 0x60(SP)									
  module.go:36032	0x631154		f20f11442458		MOVSD_XMM X0, 0x58(SP)									
  module.go:36059	0x63115a		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:36059	0x631161		e8fa37fbff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn88(SB)		
  module.go:36060	0x631166		488b842498000000	MOVQ 0x98(SP), AX									
  module.go:36060	0x63116e		488b4838		MOVQ 0x38(AX), CX									
  module.go:62929	0x631172		488b542478		MOVQ 0x78(SP), DX									
  module.go:62929	0x631177		660f1f840000000000	NOPW 0(AX)(AX*1)									
  module.go:62929	0x631180		4839d1			CMPQ CX, DX										
  module.go:62929	0x631183		0f86e1000000		JBE 0x63126a										
  module.go:36060	0x631189		488b7030		MOVQ 0x30(AX), SI									
  module.go:36062	0x63118d		90			NOPL											
  module.go:62930	0x63118e		4c8b842480000000	MOVQ 0x80(SP), R8									
  module.go:62930	0x631196		458b4c300c		MOVL 0xc(R8)(SI*1), R9									
  module.go:62929	0x63119b		4c8b542470		MOVQ 0x70(SP), R10									
  module.go:62929	0x6311a0		4c39d1			CMPQ CX, R10										
  module.go:62929	0x6311a3		0f86bc000000		JBE 0x631265										
  module.go:36061	0x6311a9		41ffc1			INCL R9											
  module.go:36064	0x6311ac		90			NOPL											
  module.go:36066	0x6311ad		90			NOPL											
  module.go:62930	0x6311ae		418b7c3010		MOVL 0x10(R8)(SI*1), DI									
  module.go:63130	0x6311b3		458b5c3004		MOVL 0x4(R8)(SI*1), R11									
  module.go:63130	0x6311b8		4c8b7c2468		MOVQ 0x68(SP), R15									
  module.go:63130	0x6311bd		458b2437		MOVL 0(R15)(SI*1), R12									
  module.go:63130	0x6311c1		458b6c3008		MOVL 0x8(R8)(SI*1), R13									
  module.go:62946	0x6311c6		488b5c2460		MOVQ 0x60(SP), BX									
  module.go:36100	0x6311cb		448b442448		MOVL 0x48(SP), R8									
  module.go:62973	0x6311d0		f20f10442458		MOVSD_XMM 0x58(SP), X0									
  module.go:36068	0x6311d6		4489c9			MOVL R9, CX										
  module.go:36068	0x6311d9		4489da			MOVL R11, DX										
  module.go:62947	0x6311dc		4c8b8c2480000000	MOVQ 0x80(SP), R9									
  module.go:62946	0x6311e4		4c8b5c2478		MOVQ 0x78(SP), R11									
  module.go:36071	0x6311e9		488b7038		MOVQ 0x38(AX), SI									
  module.go:62946	0x6311ed		4c39de			CMPQ SI, R11										
  module.go:62946	0x6311f0		766c			JBE 0x63125e										
  module.go:36071	0x6311f2		488b7030		MOVQ 0x30(AX), SI									
  module.go:62947	0x6311f6		41894c310c		MOVL CX, 0xc(R9)(SI*1)									
  module.go:36074	0x6311fb		418d75ff		LEAL -0x1(R13), SI									
  module.go:36075	0x6311ff		478d142c		LEAL 0(R12)(R13*1), R10									
  module.go:36075	0x631203		458d52ff		LEAL -0x1(R10), R10									
  module.go:36081	0x631207		4c8b6838		MOVQ 0x38(AX), R13									
  module.go:36077	0x63120b		4539d4			CMPL R12, R10										
  module.go:36078	0x63120e		410f47f2		CMOVA R10, SI										
  module.go:62946	0x631212		4939dd			CMPQ R13, BX										
  module.go:36077	0x631215		7642			JBE 0x631259										
  module.go:36081	0x631217		4c8b5030		MOVQ 0x30(AX), R10									
  module.go:62947	0x63121b		4389741108		MOVL SI, 0x8(R9)(R10*1)									
  module.go:36082	0x631220		4c8b5038		MOVQ 0x38(AX), R10									
  module.go:36082	0x631224		8d14f2			LEAL 0(DX)(SI*8), DX									
  module.go:62972	0x631227		89d6			MOVL DX, SI										
  module.go:62972	0x631229		4883c607		ADDQ $0x7, SI										
  module.go:62972	0x63122d		4939f2			CMPQ R10, SI										
  module.go:62972	0x631230		7622			JBE 0x631254										
  module.go:36082	0x631232		488b7030		MOVQ 0x30(AX), SI									
  module.go:62973	0x631236		4189d2			MOVL DX, R10										
  module.go:62973	0x631239		f2420f110416		MOVSD_XMM X0, 0(SI)(R10*1)								
  module.go:36098	0x63123f		8b54244c		MOVL 0x4c(SP), DX									
  module.go:62930	0x631243		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:62946	0x63124a		4c8b6c2470		MOVQ 0x70(SP), R13									
  module.go:36083	0x63124f		e9c9faffff		JMP 0x630d1d										
  module.go:62972	0x631254		e867f7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62946	0x631259		e862f7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62946	0x63125e		6690			NOPW											
  module.go:62946	0x631260		e85bf7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x631265		e856f7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x63126a		e851f7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62955	0x63126f		e84cf7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62946	0x631274		e847f7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62946	0x631279		e842f7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62955	0x63127e		6690			NOPW											
  module.go:62955	0x631280		e83bf7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62946	0x631285		e836f7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62946	0x63128a		e831f7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62955	0x63128f		e82cf7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62946	0x631294		e827f7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62946	0x631299		e822f7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x63129e		6690			NOPW											
  module.go:62929	0x6312a0		e81bf7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x6312a5		e816f7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x6312aa		e811f7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62929	0x6312af		e80cf7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62955	0x6312b4		e807f7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62955	0x6312b9		e802f7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62955	0x6312be		6690			NOPW											
  module.go:62955	0x6312c0		e8fbf6e5ff		CALL runtime.panicBounds(SB)								
  module.go:62955	0x6312c5		90			NOPL											
  module.go:35695	0x6312c6		4889442408		MOVQ AX, 0x8(SP)									
  module.go:35695	0x6312cb		895c2410		MOVL BX, 0x10(SP)									
  module.go:35695	0x6312cf		894c2414		MOVL CX, 0x14(SP)									
  module.go:35695	0x6312d3		f20f11442418		MOVSD_XMM X0, 0x18(SP)									
  module.go:35695	0x6312d9		e8c2d9e5ff		CALL runtime.morestack_noctxt.abi0(SB)							
  module.go:35695	0x6312de		488b442408		MOVQ 0x8(SP), AX									
  module.go:35695	0x6312e3		8b5c2410		MOVL 0x10(SP), BX									
  module.go:35695	0x6312e7		8b4c2414		MOVL 0x14(SP), CX									
  module.go:35695	0x6312eb		f20f10442418		MOVSD_XMM 0x18(SP), X0									
  module.go:35695	0x6312f1		e90aedffff		JMP dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn176(SB)		
