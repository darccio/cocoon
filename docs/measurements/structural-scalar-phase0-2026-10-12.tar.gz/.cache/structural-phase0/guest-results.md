# Guest result audit: structural pure-log ceiling

**Positive ceiling; reject outlining as an implementation candidate.** The
preregistered ≥10% original checked fixed-prefix requirement is met against
untouched baseline and the byte-identical false-flag control in both sets:

| Comparison | Screen | Confirmation |
| --- | --- | --- |
| Baseline→oracle | 87.49→70.26 ns, −19.69%, p=.001 | 87.74→70.74 ns, −19.38%, p=.001 |
| Same ELF flag0→flag1 | 90.43→70.26 ns, −22.30%, p=.001 | 90.37→70.74 ns, −21.72%, p=.001 |
| Baseline→pure outline | 87.49→89.64 ns, +2.46%, p=.001 | 87.74→89.17 ns, +1.63%, p=.001 |

Checked against `paired/summary.json`, primary time-benchstat and secondary
OracleVsControl reports. This establishes materially larger full-call headroom
for bypassing the exact log kernel on covered integer inputs. It is not a
deployable optimization, cache/interval implementation, arbitrary-input result,
or adaptive original-benchmark/M1 qualification. The unchanged source harness
is run with fixed N=2^22 and2^23, so confirmation extends the input prefix rather
than repeating the same-length input history. No selected retiming occurred.

The same-ELF flag pair holds binary, table file, initialization and retention
fixed. It reduces a major layout confound; it does not make lookup/branch/cache/
power behavior an isolated logarithm-component measurement. Both control and
oracle already differ from untouched: their disabled original scalar costs
3.36%/3.00%. Do not subtract that penalty to manufacture removable per-check
nanoseconds or claim all table gain would transfer to another mechanism.

Increasing P1 improves17.27%/16.74% versus baseline and20.72%/20.67% versus
control (all p=.001). Original batch improves38.16%/38.37% versus baseline;
raw guest36.21%/36.17%. These are complete, different workload scopes, not
additive pieces of the primary gain. Raw guest cannot replace full checked
scalar evidence. Even hypothetical confirmation70.74 ns exceeds the original
55.44 ns limit and the fresh fixed-prefix reference55.18 ns (about28.2% slower).
Reference ABI2 ownership/reply/borrowing/context differences remain; M1 is open.

## Negatives and fallback limitations

The perfect-log table is not a default candidate: negative-bin scalar loses
2.87%/3.45%, broad scalar3.40%/2.55%, and broad batch10.15%/9.51% versus
untouched (all p=.001). Those oracle/control differences are undetected, so
the losses largely coexist with the shared scaffold/fallback path rather than
proving that enabling table reads alone causes them. That still leaves real
complete-workload losses. Pure outlining additionally loses negative-bin
scalar2.07%/2.16%, broad batch3.12%/2.75%, and varied SQL1.05%/1.05%.

SQL holdout oracle costs1.71%/1.49% (p=.004/.001), also close to its disabled
control's1.89%/1.73% losses. Varied SQL oracle screening+1.35% is undetected
(p=.058), while confirmation+1.50% is detected. Source/machine summaries show
the parser/host reply paths unchanged; do not attribute their movements to a
rewritten SQL algorithm or isolate layout/GC causality from these samples.
Trace confirmation gain alone and unchanged-binary streaming shifts provide
no general benefit or equivalence claim. Preserve every negative/raw sample.

Matched scalar/batch medians retain zero Go allocations, guest memory1,179,648
bytes and zero reported growth. This excludes the process-global table:
67,108,864 bytes of Go data shared by DD module instances, allocator/file/page
cache overhead, and untimed file loading/retention. Zero warmed B/op is not
memory efficiency. Baseline/outline have no table; both oracle flags load the
same file before timing. Counters/bin weights evolve despite stable guest size.

Inputs1..N have exactly one long-prefix fallback at2^23. Warmed Increasing uses
8193..N+8192 and has8193 long-prefix fallbacks. Fractional/out-of-range/broad
inputs use the original kernel; this cheap perfect integer domain is artificial
and not representative of unknown application traffic.

## Proof and machine scope

The actual source-pinned transformation removes only the pure p17 computation
from fn176, leaving multiplier read before the call and offset read afterward,
then unchanged affine/floor/saturation, validation, store/collapse and result
publication. Complete mechanical reconstruction checks the original caller
except this region/dead v17 declaration. Scratch liveness is reviewed; no
memory-backed temporary promotion or resource/instance migration is inferred.

Native amd64 and386 functional proofs cover both oracle flags in the same ELF,
all8,388,608 table entries/wrapper outputs,1764 bit cases, actual caller read
traps/byte prefix/stack state, six finite Wasm histories including16k prefixes
and high/fallback windows, actual façade state/errors, resource/lifetime/epoch
faults and guest-memory limits. Four postrewrite semantic mutants compile then
fail explicit assertions on both architectures. The bit reference mechanically
copies original operations; it is not an independent ln algorithm or Wasm
intermediate export. Original unchanged Wasm supplies independent complete
state/status/output comparisons, but does not replay every4M/8M timed point.
The raw timed control's full-N Count is a separate check. No native arm64 or
big-endian execution is claimed.

Outlining shrinks fn176 text5462→4886 B but grows its frame128→136 B; the
separate exact-log helper is479 B/zero frame. Oracle fn176 is4854 B/136 B and
its wrapper170 B/8 B, with one wrapper bounds site. All original fn17678 and
export57 static guest bounds sites remain. This does not establish reduced
spills/register pressure. The source-identical register-resident polynomial
has not acquired an exact arithmetic simplification.

## Permitted next question

The result justifies separately bounded **certified interval feasibility**
work, not a cache specification or implementation yet. Before design, establish
whether conservative intervals can be certified cheaply enough and cover useful
traffic without reproducing the fallbacks' losses. A certificate must enclose
the exact pinned reduction branches and every rounded binary64 operation,
affine/floor/saturated mapping, with outward bounds and exact fallback whenever
one logical result cannot be proved. Sampled endpoints or assumed monotonicity
are not certification.

Any later mechanism must preserve current parameter reads/bits, threshold/zero
and invalid cases, error atomicity, ordered counter/store/collapse updates,
memory checks/trap prefixes, host containment and resource epochs. Cache only a
logical certified result, never a mutable store offset or resource pointer.
Host storage/certificate work/miss cost must be bounded and reported; same-bin
locality does not promise a cheap certificate. Large/broad holdouts and current
negative-bin/SQL regressions remain mandatory future guards. The present table
lookup has no continuum, arbitrary-input, resource-locality or deployment proof.

Parent reports 1,232 completed rows and 520 unchanged frozen hashes, followed
by passing check, race, rust, cross, smoke, fuzz and integration on unchanged
production, plus two matching 61-file proof/runtime rebuilds. This audit did not
rerun those commands. The diagnostic overlays have their separate actual-mode
fixture/runtime tests and native proofs; passing unchanged-production gates
does not qualify an overlay for production.

## Durable documentation verdict

The new performance section, structural roadmap resume and archive summary
accurately distinguish the positive unsupported ceiling from a deployable
optimization. They disclose pure outlining's losses, disabled scaffold costs,
fallback-heavy and SQL negatives, table storage outside guest limits and warmed
allocation metrics, fixed-prefix versus adaptive M1 scope, and confirmation's
wide sample intervals. The finite original-Wasm histories are independent
complete-state comparisons; the exhaustive log-bit reference reconstructs the
original source and is not an independent logarithm algorithm or exported Wasm
intermediate. The text correctly avoids an 8M whole-Wasm replay claim.

Two minor prose suggestions were sent to the parent: describe scratch liveness
as reviewed alongside mechanical source reconstruction, and update older
roadmap immediate-next-pattern pointers to agree with the new bounded
feasibility resume. Neither changes the proof or outcome verdict.

Retain diagnostic evidence/proofs only. No public contract, production/generated
artifact change, default PGO, backend replacement or M1 acceptance follows.
No tests, builds, profiles or timing were run for this read-only audit.
