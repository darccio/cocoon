TEXT dario.cat/cocoon/rt.(*Call).ResultUnit(SB) /home/dario/Code/cocoon/rt/instance.go
  instance.go:335	0x5c7ec0		493b6610		CMPQ SP, 0x10(R14)				
  instance.go:335	0x5c7ec4		7649			JBE 0x5c7f0f					
  instance.go:335	0x5c7ec6		55			PUSHQ BP					
  instance.go:335	0x5c7ec7		4889e5			MOVQ SP, BP					
  instance.go:335	0x5c7eca		4883ec20		SUBQ $0x20, SP					
  instance.go:335	0x5c7ece		48895c2438		MOVQ BX, 0x38(SP)				
  instance.go:336	0x5c7ed3		e868000000		CALL dario.cat/cocoon/rt.(*Call).ResultView(SB)	
  instance.go:337	0x5c7ed8		4885ff			TESTQ DI, DI					
  instance.go:337	0x5c7edb		7526			JNE 0x5c7f03					
  instance.go:337	0x5c7edd		0f1f00			NOPL 0(AX)					
  instance.go:340	0x5c7ee0		4885db			TESTQ BX, BX					
  instance.go:340	0x5c7ee3		7414			JE 0x5c7ef9					
  instance.go:341	0x5c7ee5		488b0554897000		MOVQ dario.cat/cocoon/rt.ErrProtocol(SB), AX	
  instance.go:341	0x5c7eec		488b1d55897000		MOVQ dario.cat/cocoon/rt.ErrProtocol+8(SB), BX	
  instance.go:341	0x5c7ef3		4883c420		ADDQ $0x20, SP					
  instance.go:341	0x5c7ef7		5d			POPQ BP						
  instance.go:341	0x5c7ef8		c3			RET						
  instance.go:343	0x5c7ef9		31c0			XORL AX, AX					
  instance.go:343	0x5c7efb		31db			XORL BX, BX					
  instance.go:343	0x5c7efd		4883c420		ADDQ $0x20, SP					
  instance.go:343	0x5c7f01		5d			POPQ BP						
  instance.go:343	0x5c7f02		c3			RET						
  instance.go:338	0x5c7f03		4889f8			MOVQ DI, AX					
  instance.go:338	0x5c7f06		4889f3			MOVQ SI, BX					
  instance.go:338	0x5c7f09		4883c420		ADDQ $0x20, SP					
  instance.go:338	0x5c7f0d		5d			POPQ BP						
  instance.go:338	0x5c7f0e		c3			RET						
  instance.go:335	0x5c7f0f		4889442408		MOVQ AX, 0x8(SP)				
  instance.go:335	0x5c7f14		48895c2410		MOVQ BX, 0x10(SP)				
  instance.go:335	0x5c7f19		48894c2418		MOVQ CX, 0x18(SP)				
  instance.go:335	0x5c7f1e		897c2420		MOVL DI, 0x20(SP)				
  instance.go:335	0x5c7f22		e8796decff		CALL runtime.morestack_noctxt.abi0(SB)		
  instance.go:335	0x5c7f27		488b442408		MOVQ 0x8(SP), AX				
  instance.go:335	0x5c7f2c		488b5c2410		MOVQ 0x10(SP), BX				
  instance.go:335	0x5c7f31		488b4c2418		MOVQ 0x18(SP), CX				
  instance.go:335	0x5c7f36		8b7c2420		MOVL 0x20(SP), DI				
  instance.go:335	0x5c7f3a		eb84			JMP dario.cat/cocoon/rt.(*Call).ResultUnit(SB)	
