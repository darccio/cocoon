package harden

import (
 "bytes"
 "crypto/sha256"
 "fmt"
 "go/ast"
 "go/format"
 "go/parser"
 "go/token"
 "regexp"
)

const phase0LogMode = "oracle"

// Complete-source identity and exact local region pin this diagnostic only.
// This is not generic production eligibility or an interval-cache proof.
func phase0OutlineLog(source []byte) ([]byte,error) {
 if fmt.Sprintf("%x",sha256.Sum256(source))!="626550cafa323c490a6a2ec6b2b341656c40e223c7c84701e414078633dcc298" {return source,nil}
 if bytes.Contains(source,[]byte("cocoonPhase0")) {return nil,fmt.Errorf("phase0 name collision")}
 set:=token.NewFileSet();file,err:=parser.ParseFile(set,"phase0.go",source,parser.ParseComments);if err!=nil{return nil,err}
 var fn *ast.FuncDecl
 for _,node:=range file.Decls {if candidate,ok:=node.(*ast.FuncDecl);ok && candidate.Name.Name=="fn176" {fn=candidate}}
 if fn==nil || fn.Recv==nil {return nil,fmt.Errorf("phase0 selected method missing")}
 begin,end:=set.Position(fn.Pos()).Offset,set.Position(fn.End()).Offset
 body:=source[begin:end]
 marker:=[]byte("var p18 int32");if bytes.Count(body,marker)!=1 {return nil,fmt.Errorf("phase0 log marker drift")}
 variable:=bytes.Index(body,marker);line:=bytes.LastIndex(body[:variable],[]byte("\n"))+1
 start:=bytes.LastIndex(body[:line-1],[]byte("\n"))+1
 if string(bytes.TrimSpace(body[start:line]))!="{" {return nil,fmt.Errorf("phase0 log block drift")}
 label:=regexp.MustCompile(`(?m)^\t*l5:\n`).FindIndex(body)
 if label==nil || label[0]<start {return nil,fmt.Errorf("phase0 log join drift")}
 pure:=body[start:label[1]]
 if bytes.Contains(pure,[]byte("m.")) || bytes.Contains(pure,[]byte("load")) || bytes.Contains(pure,[]byte("store")) {return nil,fmt.Errorf("phase0 impure log region")}
 // Only p17 lives out; current whole-function control-flow audit establishes
 // every other written scratch local is overwritten before any later read.
 replacement:=[]byte("p17 = cocoonPhase0PinnedLog(v2)\n")
 changed:=append(append(append([]byte{},body[:start]...),replacement...),body[label[1]:]...)
 old:=[]byte("var v16, v17, v18 float64");if bytes.Count(changed,old)!=1{return nil,fmt.Errorf("phase0 scratch declaration drift")}
 changed=bytes.Replace(changed,old,[]byte("var v16, v18 float64"),1)
 kernel:=[]byte("\nfunc cocoonPhase0OriginalLog(v2 float64) float64 {\nvar v1,v6 int32\nvar v16,v17 float64\nvar v19,v20 int64\nvar p17 float64\n")
 kernel=append(kernel,pure...);kernel=append(kernel,[]byte("return p17\n}\n")...)
 result:=append(append(append([]byte{},source[:begin]...),changed...),source[end:]...)
 result=append(result,kernel...)
 if phase0LogMode=="outline" {result=append(result,[]byte("\nfunc cocoonPhase0PinnedLog(value float64) float64 { return cocoonPhase0OriginalLog(value) }\n")...)} else if phase0LogMode=="oracle" {result=append(result,[]byte(phase0OracleSource)...)} else {return nil,fmt.Errorf("phase0 unknown role")}
 parsed,err:=parser.ParseFile(set,"phase0-result.go",result,parser.ParseComments);if err!=nil{return nil,err}
 if phase0LogMode=="oracle" {
  declaration,ok:=parsed.Decls[0].(*ast.GenDecl);if !ok || declaration.Tok!=token.IMPORT{return nil,fmt.Errorf("phase0 import shape drift")}
  declaration.Specs=append(declaration.Specs,&ast.ImportSpec{Path:&ast.BasicLit{Kind:token.STRING,Value:`"os"`}})
 }
 var output bytes.Buffer;if err:=format.Node(&output,set,parsed);err!=nil{return nil,err};return output.Bytes(),nil
}

const phase0OracleSource = `
// This large offline oracle is an unsupported diagnostic, not a cache.
var cocoonPhase0OracleEnabled = os.Getenv("COCOON_PHASE0_LOG_ORACLE") == "1"
var cocoonPhase0OracleBytes = func() []byte {
 path:=os.Getenv("COCOON_PHASE0_LOG_ORACLE_TABLE")
 if path=="" {return nil}
 data,err:=os.ReadFile(path);if err!=nil {panic(err)}
 if len(data)!=8*(1<<23) {panic("phase0 oracle length")}
 return data
}()
func cocoonPhase0PinnedLog(value float64) float64 {
 if value>=0 && value<float64(len(cocoonPhase0OracleBytes)/8) {
  integer:=uint32(value)
  if float64(integer)==value && cocoonPhase0OracleEnabled {
   offset:=int(integer)*8
   return math.Float64frombits(binary.LittleEndian.Uint64(cocoonPhase0OracleBytes[offset:offset+8]))
  }
 }
 return cocoonPhase0OriginalLog(value)
}
`
