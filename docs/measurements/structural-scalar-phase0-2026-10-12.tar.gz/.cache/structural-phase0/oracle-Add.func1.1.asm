TEXT dario.cat/cocoon/examples/datadog/go/dd.(*Sketch).Add.func1.1(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/cocoon_gen.go
  cocoon_gen.go:583	0x7de800		493b6610		CMPQ SP, 0x10(R14)										
  cocoon_gen.go:583	0x7de804		7673			JBE 0x7de879											
  cocoon_gen.go:583	0x7de806		55			PUSHQ BP											
  cocoon_gen.go:583	0x7de807		4889e5			MOVQ SP, BP											
  cocoon_gen.go:583	0x7de80a		4883ec20		SUBQ $0x20, SP											
  cocoon_gen.go:586	0x7de80e		4889442430		MOVQ AX, 0x30(SP)										
  cocoon_gen.go:583	0x7de813		488b5a10		MOVQ 0x10(DX), BX										
  cocoon_gen.go:583	0x7de817		f20f104218		MOVSD_XMM 0x18(DX), X0										
  cocoon_gen.go:583	0x7de81c		488b4a08		MOVQ 0x8(DX), CX										
  cocoon_gen.go:584	0x7de820		488b09			MOVQ 0(CX), CX											
  cocoon_gen.go:584	0x7de823		488b01			MOVQ 0(CX), AX											
  cocoon_gen.go:584	0x7de826		e8d57ce7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).Xcocoon_sketch_add(SB)	
  cocoon_gen.go:585	0x7de82b		488d1dc2530f00		LEAQ 0xf53c2(IP), BX										
  cocoon_gen.go:585	0x7de832		b903000000		MOVL $0x3, CX											
  cocoon_gen.go:585	0x7de837		89c7			MOVL AX, DI											
  cocoon_gen.go:585	0x7de839		488b442430		MOVQ 0x30(SP), AX										
  cocoon_gen.go:585	0x7de83e		6690			NOPW												
  cocoon_gen.go:585	0x7de840		e8fb96deff		CALL dario.cat/cocoon/rt.(*Call).ResultView(SB)							
  cocoon_gen.go:586	0x7de845		4885ff			TESTQ DI, DI											
  cocoon_gen.go:586	0x7de848		7523			JNE 0x7de86d											
  cocoon_gen.go:589	0x7de84a		4885db			TESTQ BX, BX											
  cocoon_gen.go:589	0x7de84d		7414			JE 0x7de863											
  cocoon_gen.go:590	0x7de84f		488b05ea1f4f00		MOVQ dario.cat/cocoon/rt.ErrProtocol(SB), AX							
  cocoon_gen.go:590	0x7de856		488b1deb1f4f00		MOVQ dario.cat/cocoon/rt.ErrProtocol+8(SB), BX							
  cocoon_gen.go:590	0x7de85d		4883c420		ADDQ $0x20, SP											
  cocoon_gen.go:590	0x7de861		5d			POPQ BP												
  cocoon_gen.go:590	0x7de862		c3			RET												
  cocoon_gen.go:592	0x7de863		31c0			XORL AX, AX											
  cocoon_gen.go:592	0x7de865		31db			XORL BX, BX											
  cocoon_gen.go:592	0x7de867		4883c420		ADDQ $0x20, SP											
  cocoon_gen.go:592	0x7de86b		5d			POPQ BP												
  cocoon_gen.go:592	0x7de86c		c3			RET												
  cocoon_gen.go:587	0x7de86d		4889f8			MOVQ DI, AX											
  cocoon_gen.go:587	0x7de870		4889f3			MOVQ SI, BX											
  cocoon_gen.go:587	0x7de873		4883c420		ADDQ $0x20, SP											
  cocoon_gen.go:587	0x7de877		5d			POPQ BP												
  cocoon_gen.go:587	0x7de878		c3			RET												
  cocoon_gen.go:583	0x7de879		4889442408		MOVQ AX, 0x8(SP)										
  cocoon_gen.go:583	0x7de87e		6690			NOPW												
  cocoon_gen.go:583	0x7de880		e87b03cbff		CALL runtime.morestack.abi0(SB)									
  cocoon_gen.go:583	0x7de885		488b442408		MOVQ 0x8(SP), AX										
  cocoon_gen.go:583	0x7de88a		e971ffffff		JMP dario.cat/cocoon/examples/datadog/go/dd.(*Sketch).Add.func1.1(SB)				
