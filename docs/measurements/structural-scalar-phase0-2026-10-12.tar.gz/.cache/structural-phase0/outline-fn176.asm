TEXT dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn176(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/internal/wasm/module.go
  module.go:35694	0x62ff20		4c8d6424f0		LEAQ -0x10(SP), R12									
  module.go:35694	0x62ff25		4d3b6610		CMPQ R12, 0x10(R14)									
  module.go:35694	0x62ff29		0f86d7120000		JBE 0x631206										
  module.go:35694	0x62ff2f		55			PUSHQ BP										
  module.go:35694	0x62ff30		4889e5			MOVQ SP, BP										
  module.go:35694	0x62ff33		4881ec88000000		SUBQ $0x88, SP										
  module.go:35713	0x62ff3a		4889842498000000	MOVQ AX, 0x98(SP)									
  module.go:35713	0x62ff42		899c24a0000000		MOVL BX, 0xa0(SP)									
  module.go:35699	0x62ff49		8b5050			MOVL 0x50(AX), DX									
  module.go:35699	0x62ff4c		89542430		MOVL DX, 0x30(SP)									
  module.go:35705	0x62ff50		8d72e0			LEAL -0x20(DX), SI									
  module.go:35706	0x62ff53		897050			MOVL SI, 0x50(AX)									
  unsafe.go:35		0x62ff56		66480f7ec7		MOVQ X0, DI										
  module.go:35711	0x62ff5b		4989f8			MOVQ DI, R8										
  module.go:35711	0x62ff5e		480fbaf73f		BTRQ $0x3f, DI										
  module.go:35713	0x62ff63		4c8d4fff		LEAQ -0x1(DI), R9									
  module.go:35733	0x62ff67		49ba000000000000f0ff	MOVQ $0xfff0000000000000, R10								
  module.go:35733	0x62ff71		4901fa			ADDQ DI, R10										
  module.go:35710	0x62ff74		90			NOPL											
  module.go:35713	0x62ff75		49bbffffffffffff0f00	MOVQ $0xfffffffffffff, R11								
  module.go:35713	0x62ff7f		4d39cb			CMPQ R11, R9										
  module.go:35713	0x62ff82		410f97c1		SETA R9											
  module.go:35714	0x62ff86		450fb6c9		MOVZX R9, R9										
  module.go:35717	0x62ff8a		4d85c0			TESTQ R8, R8										
  module.go:35717	0x62ff8d		410f9cc0		SETL R8											
  module.go:35718	0x62ff91		450fb6c0		MOVZX R8, R8										
  module.go:35721	0x62ff95		4521c1			ANDL R8, R9										
  module.go:35728	0x62ff98		49bb000000000000f07f	MOVQ $0x7ff0000000000000, R11								
  module.go:35728	0x62ffa2		4939fb			CMPQ R11, DI										
  module.go:35723	0x62ffa5		400f94c7		SETE DI											
  module.go:35728	0x62ffa9		410f92c3		SETB R11										
  module.go:35724	0x62ffad		400fb6ff		MOVZX DI, DI										
  module.go:35726	0x62ffb1		4109f9			ORL DI, R9										
  module.go:35729	0x62ffb4		410fb6fb		MOVZX R11, DI										
  module.go:35731	0x62ffb8		4109f9			ORL DI, R9										
  module.go:35733	0x62ffbb		48bf000000000000e07f	MOVQ $0x7fe0000000000000, DI								
  module.go:35733	0x62ffc5		4c39d7			CMPQ DI, R10										
  module.go:35733	0x62ffc8		400f97c7		SETA DI											
  module.go:35734	0x62ffcc		400fb6ff		MOVZX DI, DI										
  module.go:35736	0x62ffd0		4421c7			ANDL R8, DI										
  module.go:35736	0x62ffd3		4409cf			ORL R9, DI										
  module.go:35736	0x62ffd6		85ff			TESTL DI, DI										
  module.go:35736	0x62ffd8		0f85da060000		JNE 0x6306b8										
  module.go:35772	0x62ffde		488b7038		MOVQ 0x38(AX), SI									
  module.go:35772	0x62ffe2		89cf			MOVL CX, DI										
  module.go:62954	0x62ffe4		4c8d4737		LEAQ 0x37(DI), R8									
  module.go:62954	0x62ffe8		4c39c6			CMPQ SI, R8										
  module.go:62954	0x62ffeb		0f860d120000		JBE 0x6311fe										
  module.go:35772	0x62fff1		488b7030		MOVQ 0x30(AX), SI									
  module.go:62955	0x62fff5		488b743730		MOVQ 0x30(DI)(SI*1), SI									
  unsafe.go:41		0x62fffa		66480f6ece		MOVQ SI, X1										
  module.go:35773	0x62ffff		660f2ec8		UCOMISD X0, X1										
  module.go:35773	0x630003		0f8762060000		JA 0x63066b										
  module.go:35774	0x630009		488b7038		MOVQ 0x38(AX), SI									
  module.go:62954	0x63000d		4c8d472f		LEAQ 0x2f(DI), R8									
  module.go:62954	0x630011		4c39c6			CMPQ SI, R8										
  module.go:62954	0x630014		0f86df110000		JBE 0x6311f9										
  module.go:35713	0x63001a		898c24a4000000		MOVL CX, 0xa4(SP)									
  module.go:35772	0x630021		4889bc2480000000	MOVQ DI, 0x80(SP)									
  module.go:35774	0x630029		488b4030		MOVQ 0x30(AX), AX									
  module.go:62954	0x63002d		488d4f3f		LEAQ 0x3f(DI), CX									
  module.go:62954	0x630031		48894c2478		MOVQ CX, 0x78(SP)									
  module.go:35776	0x630036		90			NOPL											
  module.go:62955	0x630037		488b440728		MOVQ 0x28(DI)(AX*1), AX									
  module.go:62955	0x63003c		4889442450		MOVQ AX, 0x50(SP)									
  module.go:63200	0x630041		e85a120600		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.cocoonPhase0OriginalLog(SB)	
  module.go:35777	0x630046		488b842498000000	MOVQ 0x98(SP), AX									
  module.go:35777	0x63004e		488b4838		MOVQ 0x38(AX), CX									
  module.go:62954	0x630052		488b542478		MOVQ 0x78(SP), DX									
  module.go:62954	0x630057		660f1f840000000000	NOPW 0(AX)(AX*1)									
  module.go:62954	0x630060		4839d1			CMPQ CX, DX										
  module.go:62954	0x630063		0f868b110000		JBE 0x6311f4										
  module.go:35777	0x630069		488b5030		MOVQ 0x30(AX), DX									
  unsafe.go:41		0x63006d		4c8b4c2450		MOVQ 0x50(SP), R9									
  unsafe.go:41		0x630072		66490f6ec9		MOVQ R9, X1										
  module.go:35778	0x630077		f20f59c1		MULSD X1, X0										
  module.go:62955	0x63007b		4c8b8c2480000000	MOVQ 0x80(SP), R9									
  module.go:62955	0x630083		498b541138		MOVQ 0x38(R9)(DX*1), DX									
  module.go:35777	0x630088		66480f6eca		MOVQ DX, X1										
  module.go:35778	0x63008d		f20f58c1		ADDSD X1, X0										
  module.go:35778	0x630091		0fb6157c196d00		MOVZX runtime.x86HasSSE41(SB), DX							
  module.go:35778	0x630098		85d2			TESTL DX, DX										
  module.go:35778	0x63009a		7408			JE 0x6300a4										
  module.go:35778	0x63009c		660f3a0bc001		ROUNDSD $0x1, X0, X0									
  module.go:35778	0x6300a2		eb15			JMP 0x6300b9										
  module.go:35778	0x6300a4		e837b1eaff		CALL math.Floor(SB)									
  module.go:35779	0x6300a9		488b842498000000	MOVQ 0x98(SP), AX									
  module.go:62928	0x6300b1		4c8b8c2480000000	MOVQ 0x80(SP), R9									
  module.go:63019	0x6300b9		f20f100d07212d00	MOVSD_XMM $f64.c1e0000000000000(SB), X1							
  module.go:63019	0x6300c1		660f2ec8		UCOMISD X0, X1										
  module.go:63019	0x6300c5		7207			JB 0x6300ce										
  module.go:63019	0x6300c7		ba00000080		MOVL $-0x80000000, DX									
  module.go:35778	0x6300cc		eb25			JMP 0x6300f3										
  module.go:63021	0x6300ce		f20f100de2202d00	MOVSD_XMM $f64.41dfffffffc00000(SB), X1							
  module.go:63021	0x6300d6		660f2ec1		UCOMISD X1, X0										
  module.go:63021	0x6300da		7207			JB 0x6300e3										
  module.go:63021	0x6300dc		baffffff7f		MOVL $0x7fffffff, DX									
  module.go:35778	0x6300e1		eb10			JMP 0x6300f3										
  module.go:63023	0x6300e3		660f2ec0		UCOMISD X0, X0										
  module.go:63023	0x6300e7		7502			JNE 0x6300eb										
  module.go:63023	0x6300e9		7b04			JNP 0x6300ef										
  module.go:63023	0x6300eb		31d2			XORL DX, DX										
  module.go:35778	0x6300ed		eb04			JMP 0x6300f3										
  module.go:63026	0x6300ef		f20f2cd0		CVTTSD2SIL X0, DX									
  module.go:35779	0x6300f3		4c8b5038		MOVQ 0x38(AX), R10									
  module.go:62928	0x6300f7		4d8d590f		LEAQ 0xf(R9), R11									
  module.go:62928	0x6300fb		0f1f440000		NOPL 0(AX)(AX*1)									
  module.go:62928	0x630100		4d39da			CMPQ R10, R11										
  module.go:62928	0x630103		0f86e6100000		JBE 0x6311ef										
  module.go:62928	0x630109		4c895c2478		MOVQ R11, 0x78(SP)									
  module.go:35779	0x63010e		4c8b6030		MOVQ 0x30(AX), R12									
  module.go:62929	0x630112		438b4c210c		MOVL 0xc(R9)(R12*1), CX									
  module.go:35781	0x630117		85c9			TESTL CX, CX										
  module.go:35781	0x630119		0f8430040000		JE 0x63054f										
  module.go:62928	0x63011f		4d8d6913		LEAQ 0x13(R9), R13									
  module.go:35808	0x630123		90			NOPL											
  module.go:62928	0x630124		4d39ea			CMPQ R10, R13										
  module.go:62928	0x630127		0f86bd100000		JBE 0x6311ea										
  module.go:62928	0x63012d		4c896c2470		MOVQ R13, 0x70(SP)									
  module.go:62929	0x630132		438b7c2110		MOVL 0x10(R9)(R12*1), DI								
  module.go:35810	0x630137		39fa			CMPL DX, DI										
  module.go:35810	0x630139		0f8cf4000000		JL 0x630233										
  module.go:35812	0x63013f		8d3439			LEAL 0(CX)(DI*1), SI									
  module.go:35811	0x630142		4189d0			MOVL DX, R8										
  module.go:35811	0x630145		29fa			SUBL DI, DX										
  module.go:35812	0x630147		4139f0			CMPL R8, SI										
  module.go:35812	0x63014a		0f8cd5000000		JL 0x630225										
  module.go:62928	0x630150		498d7117		LEAQ 0x17(R9), SI									
  module.go:35816	0x630154		90			NOPL											
  module.go:62928	0x630155		4939f2			CMPQ R10, SI										
  module.go:62928	0x630158		0f8687100000		JBE 0x6311e5										
  module.go:35815	0x63015e		8d7201			LEAL 0x1(DX), SI									
  module.go:62929	0x630161		478b7c0c14		MOVL 0x14(R12)(R9*1), R15								
  module.go:35819	0x630166		4139f7			CMPL R15, SI										
  module.go:35819	0x630169		7c0c			JL 0x630177										
  module.go:62929	0x63016b		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:35820	0x630172		e90d0b0000		JMP 0x630c84										
  module.go:35822	0x630177		4429fa			SUBL R15, DX										
  module.go:35822	0x63017a		8d7201			LEAL 0x1(DX), SI									
  module.go:35822	0x63017d		0f1f00			NOPL 0(AX)										
  module.go:35823	0x630180		85f6			TESTL SI, SI										
  module.go:35823	0x630182		7e64			JLE 0x6301e8										
  module.go:62928	0x630184		498d590b		LEAQ 0xb(R9), BX									
  module.go:35824	0x630188		90			NOPL											
  module.go:62928	0x630189		4939da			CMPQ R10, BX										
  module.go:62928	0x63018c		0f864c100000		JBE 0x6311de										
  module.go:35822	0x630192		8954244c		MOVL DX, 0x4c(SP)									
  module.go:35778	0x630196		4489442448		MOVL R8, 0x48(SP)									
  module.go:35830	0x63019b		468d143f		LEAL 0(DI)(R15*1), R10									
  module.go:63129	0x63019f		448bbc24a4000000	MOVL 0xa4(SP), R15									
  module.go:63129	0x6301a7		4589ff			MOVL R15, R15										
  module.go:63129	0x6301aa		4c897c2468		MOVQ R15, 0x68(SP)									
  module.go:35826	0x6301af		90			NOPL											
  module.go:35828	0x6301b0		90			NOPL											
  module.go:62929	0x6301b1		478b6c0c08		MOVL 0x8(R12)(R9*1), R13								
  module.go:63129	0x6301b6		438b540c04		MOVL 0x4(R12)(R9*1), DX									
  module.go:63129	0x6301bb		478b243c		MOVL 0(R12)(R15*1), R12									
  module.go:63129	0x6301bf		90			NOPL											
  module.go:35830	0x6301c0		4539d0			CMPL R8, R10										
  module.go:35830	0x6301c3		750a			JNE 0x6301cf										
  module.go:36033	0x6301c5		89ce			MOVL CX, SI										
  module.go:36033	0x6301c7		0f57c0			XORPS X0, X0										
  module.go:35833	0x6301ca		e9f20d0000		JMP 0x630fc1										
  module.go:62929	0x6301cf		897c2444		MOVL DI, 0x44(SP)									
  module.go:35836	0x6301d3		4189f2			MOVL SI, R10										
  module.go:35836	0x6301d6		81e6feffff7f		ANDL $0x7ffffffe, SI									
  module.go:35897	0x6301dc		894c2420		MOVL CX, 0x20(SP)									
  module.go:35897	0x6301e0		0f57c0			XORPS X0, X0										
  module.go:35839	0x6301e3		e95c0c0000		JMP 0x630e44										
  module.go:62928	0x6301e8		498d7107		LEAQ 0x7(R9), SI									
  module.go:35902	0x6301ec		90			NOPL											
  module.go:62928	0x6301ed		4939f2			CMPQ R10, SI										
  module.go:62928	0x6301f0		0f863e0c0000		JBE 0x630e34										
  module.go:63129	0x6301f6		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:63129	0x6301fd		89de			MOVL BX, SI										
  module.go:62928	0x6301ff		4d8d790b		LEAQ 0xb(R9), R15									
  module.go:35904	0x630203		90			NOPL											
  module.go:62929	0x630204		478b5c0c04		MOVL 0x4(R12)(R9*1), R11								
  module.go:63129	0x630209		418b3434		MOVL 0(R12)(SI*1), SI									
  module.go:62928	0x63020d		4d39fa			CMPQ R10, R15										
  module.go:62928	0x630210		0f86190c0000		JBE 0x630e2f										
  module.go:62929	0x630216		478b540c08		MOVL 0x8(R12)(R9*1), R10								
  module.go:62929	0x63021b		0f57c0			XORPS X0, X0										
  module.go:62929	0x63021e		6690			NOPW											
  module.go:35909	0x630220		e9ec090000		JMP 0x630c11										
  module.go:63129	0x630225		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:36140	0x63022c		89ce			MOVL CX, SI										
  module.go:35813	0x63022e		e93c070000		JMP 0x63096f										
  module.go:62928	0x630233		4d8d7917		LEAQ 0x17(R9), R15									
  module.go:35913	0x630237		90			NOPL											
  module.go:35913	0x630238		0f1f840000000000	NOPL 0(AX)(AX*1)									
  module.go:62928	0x630240		4d39fa			CMPQ R10, R15										
  module.go:62928	0x630243		0f86c3090000		JBE 0x630c0c										
  module.go:35916	0x630249		29d7			SUBL DX, DI										
  module.go:62929	0x63024b		438b540c14		MOVL 0x14(R12)(R9*1), DX								
  module.go:35914	0x630250		29ca			SUBL CX, DX										
  module.go:35918	0x630252		39d7			CMPL DI, DX										
  module.go:35919	0x630254		0f47fa			CMOVA DX, DI										
  module.go:35922	0x630257		8d140f			LEAL 0(DI)(CX*1), DX									
  module.go:35922	0x63025a		660f1f440000		NOPW 0(AX)(AX*1)									
  module.go:35923	0x630260		39d7			CMPL DI, DX										
  module.go:35918	0x630262		0f877d090000		JA 0x630be5										
  module.go:62928	0x630268		4d8d7903		LEAQ 0x3(R9), R15									
  module.go:35924	0x63026c		90			NOPL											
  module.go:62928	0x63026d		4d39fa			CMPQ R10, R15										
  module.go:62928	0x630270		0f8668090000		JBE 0x630bde										
  module.go:35919	0x630276		897c2424		MOVL DI, 0x24(SP)									
  module.go:62929	0x63027a		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:62929	0x630281		4189da			MOVL BX, R10										
  module.go:62929	0x630284		4c89542468		MOVQ R10, 0x68(SP)									
  module.go:62929	0x630289		478b2414		MOVL 0(R12)(R10*1), R12									
  module.go:35927	0x63028d		4139d4			CMPL R12, DX										
  module.go:35927	0x630290		0f83aa020000		JAE 0x630540										
  module.go:35937	0x630296		4489e2			MOVL R12, DX										
  module.go:35937	0x630299		4129cc			SUBL CX, R12										
  module.go:35937	0x63029c		0f1f4000		NOPL 0(AX)										
  module.go:35939	0x6302a0		4439e7			CMPL DI, R12										
  module.go:35939	0x6302a3		7704			JA 0x6302a9										
  module.go:62929	0x6302a5		89d6			MOVL DX, SI										
  module.go:35940	0x6302a7		eb72			JMP 0x63031b										
  module.go:62929	0x6302a9		89542444		MOVL DX, 0x44(SP)									
  module.go:35942	0x6302ad		be08000000		MOVL $0x8, SI										
  module.go:35942	0x6302b2		4189f0			MOVL SI, R8										
  module.go:35942	0x6302b5		e8a6bef9ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn3(SB)		
  module.go:35943	0x6302ba		488b842498000000	MOVQ 0x98(SP), AX									
  module.go:35943	0x6302c2		488b5038		MOVQ 0x38(AX), DX									
  module.go:62928	0x6302c6		4c8b4c2478		MOVQ 0x78(SP), R9									
  module.go:62928	0x6302cb		4c39ca			CMPQ DX, R9										
  module.go:62928	0x6302ce		0f8605090000		JBE 0x630bd9										
  module.go:35943	0x6302d4		488b5030		MOVQ 0x30(AX), DX									
  module.go:62929	0x6302d8		488bb42480000000	MOVQ 0x80(SP), SI									
  module.go:62929	0x6302e0		8b4c160c		MOVL 0xc(SI)(DX*1), CX									
  module.go:35946	0x6302e4		448b642444		MOVL 0x44(SP), R12									
  module.go:35946	0x6302e9		4589e0			MOVL R12, R8										
  module.go:35946	0x6302ec		4129c8			SUBL CX, R8										
  module.go:63129	0x6302ef		4c8b542468		MOVQ 0x68(SP), R10									
  module.go:63129	0x6302f4		418b1412		MOVL 0(R10)(DX*1), DX									
  module.go:35992	0x6302f8		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:35956	0x6302ff		4489e6			MOVL R12, SI										
  module.go:35987	0x630302		8b7c2424		MOVL 0x24(SP), DI									
  module.go:62928	0x630306		4c8b8c2480000000	MOVQ 0x80(SP), R9									
  module.go:62945	0x63030e		4c8b5c2478		MOVQ 0x78(SP), R11									
  module.go:62928	0x630313		4c8b6c2470		MOVQ 0x70(SP), R13									
  module.go:35947	0x630318		4589c4			MOVL R8, R12										
  module.go:35951	0x63031b		4c8b4038		MOVQ 0x38(AX), R8									
  module.go:62928	0x63031f		4d8d790b		LEAQ 0xb(R9), R15									
  module.go:62928	0x630323		4d39f8			CMPQ R8, R15										
  module.go:62928	0x630326		0f86a8080000		JBE 0x630bd4										
  module.go:35951	0x63032c		4c8b5030		MOVQ 0x30(AX), R10									
  module.go:62929	0x630330		438b5c1108		MOVL 0x8(R9)(R10*1), BX									
  module.go:35953	0x630335		4139dc			CMPL R12, BX										
  module.go:35953	0x630338		7214			JB 0x63034e										
  module.go:35992	0x63033a		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:63129	0x630341		4c8b542468		MOVQ 0x68(SP), R10									
  module.go:35986	0x630346		4189d4			MOVL DX, R12										
  module.go:35954	0x630349		e9f2010000		JMP 0x630540										
  module.go:35947	0x63034e		894c2420		MOVL CX, 0x20(SP)									
  module.go:35947	0x630352		89542434		MOVL DX, 0x34(SP)									
  module.go:35956	0x630356		4189f4			MOVL SI, R12										
  module.go:35956	0x630359		29de			SUBL BX, SI										
  module.go:35958	0x63035b		29f1			SUBL SI, CX										
  module.go:35964	0x63035d		4429e2			SUBL R12, DX										
  module.go:35960	0x630360		39f1			CMPL CX, SI										
  module.go:35960	0x630362		410f92c5		SETB R13										
  module.go:35961	0x630366		450fb6ed		MOVZX R13, R13										
  module.go:35964	0x63036a		39ca			CMPL DX, CX										
  module.go:35964	0x63036c		0f93c2			SETAE DL										
  module.go:35965	0x63036f		0fb6d2			MOVZX DL, DX										
  module.go:35967	0x630372		4185d5			TESTL DX, R13										
  module.go:35967	0x630375		0f85f6000000		JNE 0x630471										
  module.go:35969	0x63037b		89f2			MOVL SI, DX										
  module.go:35969	0x63037d		c1e603			SHLL $0x3, SI										
  module.go:35968	0x630380		448b642434		MOVL 0x34(SP), R12									
  module.go:35968	0x630385		4589e5			MOVL R12, R13										
  module.go:35968	0x630388		4129d4			SUBL DX, R12										
  module.go:35970	0x63038b		85f6			TESTL SI, SI										
  module.go:35970	0x63038d		0f84a9000000		JE 0x63043c										
  module.go:62928	0x630393		498d5107		LEAQ 0x7(R9), DX									
  module.go:35971	0x630397		90			NOPL											
  module.go:35971	0x630398		0f1f840000000000	NOPL 0(AX)(AX*1)									
  module.go:62928	0x6303a0		4939d0			CMPQ R8, DX										
  module.go:62928	0x6303a3		0f8626080000		JBE 0x630bcf										
  module.go:62929	0x6303a9		438b540a04		MOVL 0x4(R10)(R9*1), DX									
  module.go:35973	0x6303ae		428d0ce2		LEAL 0(DX)(R12*8), CX									
  module.go:35973	0x6303b2		8d14da			LEAL 0(DX)(BX*8), DX									
  module.go:63054	0x6303b5		89c9			MOVL CX, CX										
  module.go:63055	0x6303b7		89d2			MOVL DX, DX										
  module.go:63056	0x6303b9		89f6			MOVL SI, SI										
  module.go:63056	0x6303bb		488d1c0e		LEAQ 0(SI)(CX*1), BX									
  module.go:63057	0x6303bf		4c8d1c16		LEAQ 0(SI)(DX*1), R11									
  module.go:63058	0x6303c3		4939d8			CMPQ R8, BX										
  module.go:63058	0x6303c6		0f82fe070000		JB 0x630bca										
  module.go:63058	0x6303cc		4889cb			MOVQ CX, BX										
  module.go:63058	0x6303cf		4c29c1			SUBQ R8, CX										
  module.go:63058	0x6303d2		48c1f93f		SARQ $0x3f, CX										
  module.go:63058	0x6303d6		4821cb			ANDQ CX, BX										
  module.go:63058	0x6303d9		4a8d0c13		LEAQ 0(BX)(R10*1), CX									
  module.go:63058	0x6303dd		0f1f00			NOPL 0(AX)										
  module.go:63058	0x6303e0		4d39d8			CMPQ R8, R11										
  module.go:63058	0x6303e3		0f82dc070000		JB 0x630bc5										
  module.go:63058	0x6303e9		4989d3			MOVQ DX, R11										
  module.go:63058	0x6303ec		4c29c2			SUBQ R8, DX										
  module.go:63058	0x6303ef		48c1fa3f		SARQ $0x3f, DX										
  module.go:63058	0x6303f3		4921d3			ANDQ DX, R11										
  module.go:63058	0x6303f6		4b8d1c13		LEAQ 0(R11)(R10*1), BX									
  module.go:63058	0x6303fa		4839cb			CMPQ BX, CX										
  module.go:63058	0x6303fd		7438			JE 0x630437										
  module.go:62928	0x6303ff		4c897c2460		MOVQ R15, 0x60(SP)									
  module.go:35968	0x630404		4489642428		MOVL R12, 0x28(SP)									
  module.go:63058	0x630409		4889c8			MOVQ CX, AX										
  module.go:63058	0x63040c		4889f1			MOVQ SI, CX										
  module.go:63058	0x63040f		e84c09e6ff		CALL runtime.memmove(SB)								
  module.go:35975	0x630414		488b842498000000	MOVQ 0x98(SP), AX									
  module.go:35987	0x63041c		8b7c2424		MOVL 0x24(SP), DI									
  module.go:62946	0x630420		4c8b8c2480000000	MOVQ 0x80(SP), R9									
  module.go:62946	0x630428		448b642428		MOVL 0x28(SP), R12									
  module.go:35986	0x63042d		448b6c2434		MOVL 0x34(SP), R13									
  module.go:62945	0x630432		4c8b7c2460		MOVQ 0x60(SP), R15									
  module.go:62945	0x630437		4c8b5c2478		MOVQ 0x78(SP), R11									
  module.go:35975	0x63043c		488b5038		MOVQ 0x38(AX), DX									
  module.go:62945	0x630440		4c39fa			CMPQ DX, R15										
  module.go:62945	0x630443		0f8675070000		JBE 0x630bbe										
  module.go:35975	0x630449		488b5030		MOVQ 0x30(AX), DX									
  module.go:62946	0x63044d		4589641108		MOVL R12, 0x8(R9)(DX*1)									
  module.go:35992	0x630452		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:63129	0x630459		4c8b542468		MOVQ 0x68(SP), R10									
  module.go:62928	0x63045e		4c8b6c2470		MOVQ 0x70(SP), R13									
  module.go:35986	0x630463		8b4c2420		MOVL 0x20(SP), CX									
  module.go:35986	0x630467		448b642434		MOVL 0x34(SP), R12									
  module.go:35976	0x63046c		e9cf000000		JMP 0x630540										
  module.go:35978	0x630471		c1e103			SHLL $0x3, CX										
  module.go:35979	0x630474		85c9			TESTL CX, CX										
  module.go:35979	0x630476		751f			JNE 0x630497										
  module.go:35992	0x630478		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:63129	0x63047f		4c8b542468		MOVQ 0x68(SP), R10									
  module.go:62928	0x630484		4c8b6c2470		MOVQ 0x70(SP), R13									
  module.go:35986	0x630489		8b4c2420		MOVL 0x20(SP), CX									
  module.go:35986	0x63048d		448b642434		MOVL 0x34(SP), R12									
  module.go:35980	0x630492		e9a9000000		JMP 0x630540										
  module.go:62928	0x630497		498d5107		LEAQ 0x7(R9), DX									
  module.go:35982	0x63049b		90			NOPL											
  module.go:35982	0x63049c		0f1f4000		NOPL 0(AX)										
  module.go:62928	0x6304a0		4939d0			CMPQ R8, DX										
  module.go:62928	0x6304a3		0f8610070000		JBE 0x630bb9										
  module.go:62929	0x6304a9		438b540a04		MOVL 0x4(R10)(R9*1), DX									
  module.go:35984	0x6304ae		428d34e2		LEAL 0(DX)(R12*8), SI									
  module.go:63054	0x6304b2		89f6			MOVL SI, SI										
  module.go:63056	0x6304b4		89c9			MOVL CX, CX										
  module.go:63056	0x6304b6		4c8d2431		LEAQ 0(CX)(SI*1), R12									
  module.go:63057	0x6304ba		4c8d2c11		LEAQ 0(CX)(DX*1), R13									
  module.go:63057	0x6304be		6690			NOPW											
  module.go:63058	0x6304c0		4d39e0			CMPQ R8, R12										
  module.go:63058	0x6304c3		0f82eb060000		JB 0x630bb4										
  module.go:63058	0x6304c9		4989f4			MOVQ SI, R12										
  module.go:63058	0x6304cc		4c29c6			SUBQ R8, SI										
  module.go:63058	0x6304cf		48c1fe3f		SARQ $0x3f, SI										
  module.go:63058	0x6304d3		4921f4			ANDQ SI, R12										
  module.go:63058	0x6304d6		4b8d3414		LEAQ 0(R12)(R10*1), SI									
  module.go:63058	0x6304da		660f1f440000		NOPW 0(AX)(AX*1)									
  module.go:63058	0x6304e0		4d39e8			CMPQ R8, R13										
  module.go:63058	0x6304e3		0f82c6060000		JB 0x630baf										
  module.go:63058	0x6304e9		4189d4			MOVL DX, R12										
  module.go:63058	0x6304ec		4c29c2			SUBQ R8, DX										
  module.go:63058	0x6304ef		48c1fa3f		SARQ $0x3f, DX										
  module.go:63058	0x6304f3		4c21e2			ANDQ R12, DX										
  module.go:63058	0x6304f6		4a8d1c12		LEAQ 0(DX)(R10*1), BX									
  module.go:63058	0x6304fa		4839f3			CMPQ BX, SI										
  module.go:63058	0x6304fd		7421			JE 0x630520										
  module.go:63058	0x6304ff		4889f0			MOVQ SI, AX										
  module.go:63058	0x630502		e85908e6ff		CALL runtime.memmove(SB)								
  module.go:36000	0x630507		488b842498000000	MOVQ 0x98(SP), AX									
  module.go:35987	0x63050f		8b7c2424		MOVL 0x24(SP), DI									
  module.go:62946	0x630513		4c8b8c2480000000	MOVQ 0x80(SP), R9									
  module.go:62945	0x63051b		4c8b5c2478		MOVQ 0x78(SP), R11									
  module.go:35992	0x630520		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:63129	0x630527		4c8b542468		MOVQ 0x68(SP), R10									
  module.go:62928	0x63052c		4c8b6c2470		MOVQ 0x70(SP), R13									
  module.go:35986	0x630531		8b4c2420		MOVL 0x20(SP), CX									
  module.go:35986	0x630535		448b642434		MOVL 0x34(SP), R12									
  module.go:35986	0x63053a		660f1f440000		NOPW 0(AX)(AX*1)									
  module.go:35987	0x630540		85ff			TESTL DI, DI										
  module.go:35987	0x630542		0f8427050000		JE 0x630a6f										
  module.go:35919	0x630548		89fa			MOVL DI, DX										
  module.go:35989	0x63054a		e94a050000		JMP 0x630a99										
  module.go:62945	0x63054f		498d7113		LEAQ 0x13(R9), SI									
  module.go:35782	0x630553		90			NOPL											
  module.go:62945	0x630554		4939f2			CMPQ R10, SI										
  module.go:62945	0x630557		0f860d050000		JBE 0x630a6a										
  module.go:62946	0x63055d		4389542110		MOVL DX, 0x10(R9)(R12*1)								
  module.go:35784	0x630562		488b5038		MOVQ 0x38(AX), DX									
  module.go:62928	0x630566		498d7103		LEAQ 0x3(R9), SI									
  module.go:62928	0x63056a		4839f2			CMPQ DX, SI										
  module.go:62928	0x63056d		0f86f2040000		JBE 0x630a65										
  module.go:35784	0x630573		488b5030		MOVQ 0x30(AX), DX									
  module.go:62929	0x630577		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:62929	0x63057e		4189d8			MOVL BX, R8										
  module.go:62929	0x630581		418b1410		MOVL 0(R8)(DX*1), DX									
  module.go:35786	0x630585		85d2			TESTL DX, DX										
  module.go:35786	0x630587		7405			JE 0x63058e										
  module.go:35786	0x630589		4531d2			XORL R10, R10										
  module.go:35786	0x63058c		eb5c			JMP 0x6305ea										
  module.go:62928	0x63058e		4889742470		MOVQ SI, 0x70(SP)									
  module.go:62929	0x630593		4c89442468		MOVQ R8, 0x68(SP)									
  module.go:35787	0x630598		e8e342fbff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn88(SB)		
  module.go:35788	0x63059d		488b842498000000	MOVQ 0x98(SP), AX									
  module.go:35788	0x6305a5		488b4838		MOVQ 0x38(AX), CX									
  module.go:62928	0x6305a9		488b542470		MOVQ 0x70(SP), DX									
  module.go:62928	0x6305ae		4839d1			CMPQ CX, DX										
  module.go:62928	0x6305b1		0f86a7040000		JBE 0x630a5e										
  module.go:35788	0x6305b7		488b5030		MOVQ 0x30(AX), DX									
  module.go:62929	0x6305bb		488b742468		MOVQ 0x68(SP), SI									
  module.go:62929	0x6305c0		8b3416			MOVL 0(SI)(DX*1), SI									
  module.go:62928	0x6305c3		4c8b442478		MOVQ 0x78(SP), R8									
  module.go:62928	0x6305c8		4c39c1			CMPQ CX, R8										
  module.go:62928	0x6305cb		0f8688040000		JBE 0x630a59										
  module.go:62929	0x6305d1		4c8b8c2480000000	MOVQ 0x80(SP), R9									
  module.go:62929	0x6305d9		458b54110c		MOVL 0xc(R9)(DX*1), R10									
  module.go:63129	0x6305de		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:62945	0x6305e5		4d89c3			MOVQ R8, R11										
  module.go:35790	0x6305e8		89f2			MOVL SI, DX										
  module.go:35795	0x6305ea		488b7038		MOVQ 0x38(AX), SI									
  module.go:62945	0x6305ee		4c39de			CMPQ SI, R11										
  module.go:62945	0x6305f1		0f865d040000		JBE 0x630a54										
  module.go:35794	0x6305f7		418d7201		LEAL 0x1(R10), SI									
  module.go:35795	0x6305fb		4c8b4030		MOVQ 0x30(AX), R8									
  module.go:62946	0x6305ff		438974010c		MOVL SI, 0xc(R9)(R8*1)									
  module.go:35796	0x630604		4c8b4038		MOVQ 0x38(AX), R8									
  module.go:62928	0x630608		4d8d5907		LEAQ 0x7(R9), R11									
  module.go:62928	0x63060c		4d39d8			CMPQ R8, R11										
  module.go:62928	0x63060f		0f863a040000		JBE 0x630a4f										
  module.go:35796	0x630615		4c8b5830		MOVQ 0x30(AX), R11									
  module.go:62928	0x630619		4d8d610b		LEAQ 0xb(R9), R12									
  module.go:35797	0x63061d		90			NOPL											
  module.go:62929	0x63061e		478b6c1904		MOVL 0x4(R9)(R11*1), R13								
  module.go:62928	0x630623		4d39e0			CMPQ R8, R12										
  module.go:62928	0x630626		0f861e040000		JBE 0x630a4a										
  module.go:62929	0x63062c		478b641908		MOVL 0x8(R9)(R11*1), R12								
  module.go:35798	0x630631		4501e2			ADDL R12, R10										
  module.go:35801	0x630634		4439d2			CMPL DX, R10										
  module.go:35802	0x630637		41bc00000000		MOVL $0x0, R12										
  module.go:35802	0x63063d		440f46e2		CMOVBE DX, R12										
  module.go:35804	0x630641		4529e2			SUBL R12, R10										
  module.go:35804	0x630644		438d54d500		LEAL 0(R13)(R10*8), DX									
  module.go:62971	0x630649		4189d2			MOVL DX, R10										
  module.go:62971	0x63064c		4983c207		ADDQ $0x7, R10										
  module.go:62971	0x630650		4d39d0			CMPQ R8, R10										
  module.go:35801	0x630653		0f86ec030000		JBE 0x630a45										
  module.go:62972	0x630659		4189d0			MOVL DX, R8										
  module.go:62972	0x63065c		4bc7040300000000	MOVQ $0x0, 0(R11)(R8*1)									
  module.go:62972	0x630664		31d2			XORL DX, DX										
  module.go:35805	0x630666		e904030000		JMP 0x63096f										
  module.go:36025	0x63066b		488b7038		MOVQ 0x38(AX), SI									
  module.go:62954	0x63066f		4c8d471f		LEAQ 0x1f(DI), R8									
  module.go:62954	0x630673		4c39c6			CMPQ SI, R8										
  module.go:62954	0x630676		0f86ee020000		JBE 0x63096a										
  module.go:36025	0x63067c		488b7030		MOVQ 0x30(AX), SI									
  module.go:36026	0x630680		4c8b4838		MOVQ 0x38(AX), R9									
  module.go:62955	0x630684		488b743718		MOVQ 0x18(DI)(SI*1), SI									
  unsafe.go:41		0x630689		66480f6ec6		MOVQ SI, X0										
  module.go:36026	0x63068e		f20f100dd2182d00	MOVSD_XMM $f64.3ff0000000000000(SB), X1							
  module.go:36026	0x630696		f20f58c8		ADDSD X0, X1										
  module.go:36026	0x63069a		660f1f440000		NOPW 0(AX)(AX*1)									
  module.go:62971	0x6306a0		4d39c1			CMPQ R9, R8										
  module.go:62971	0x6306a3		0f86bc020000		JBE 0x630965										
  module.go:36026	0x6306a9		488b7030		MOVQ 0x30(AX), SI									
  module.go:62972	0x6306ad		f20f114c3718		MOVSD_XMM X1, 0x18(DI)(SI*1)								
  module.go:36027	0x6306b3		e9a0020000		JMP 0x630958										
  module.go:35705	0x6306b8		8974242c		MOVL SI, 0x2c(SP)									
  module.go:35739	0x6306bc		bb10000000		MOVL $0x10, BX										
  module.go:35739	0x6306c1		b901000000		MOVL $0x1, CX										
  module.go:35739	0x6306c6		e895bcf9ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn4(SB)		
  module.go:35741	0x6306cb		85c0			TESTL AX, AX										
  module.go:35741	0x6306cd		0f8457020000		JE 0x63092a										
  module.go:35742	0x6306d3		488b942498000000	MOVQ 0x98(SP), DX									
  module.go:35742	0x6306db		488b7238		MOVQ 0x38(DX), SI									
  module.go:63054	0x6306df		89c7			MOVL AX, DI										
  module.go:63056	0x6306e1		4c8d4710		LEAQ 0x10(DI), R8									
  module.go:63058	0x6306e5		4c39c6			CMPQ SI, R8										
  module.go:63058	0x6306e8		0f8237020000		JB 0x630925										
  module.go:35742	0x6306ee		4c8b4230		MOVQ 0x30(DX), R8									
  module.go:63058	0x6306f2		4c01c7			ADDQ R8, DI										
  module.go:63058	0x6306f5		660f1f840000000000	NOPW 0(AX)(AX*1)									
  module.go:63058	0x6306fe		6690			NOPW											
  module.go:63058	0x630700		4881fe718e1000		CMPQ SI, $0x108e71									
  module.go:63058	0x630707		0f820c020000		JB 0x630919										
  module.go:35739	0x63070d		89442420		MOVL AX, 0x20(SP)									
  module.go:63058	0x630711		498db0618e1000		LEAQ 0x108e61(R8), SI									
  module.go:63058	0x630718		4839fe			CMPQ SI, DI										
  module.go:63058	0x63071b		740b			JE 0x630728										
  module.go:63058	0x63071d		410f1080618e1000	MOVUPS 0x108e61(R8), X0									
  module.go:63058	0x630725		0f1107			MOVUPS X0, 0(DI)									
  module.go:35743	0x630728		4889d0			MOVQ DX, AX										
  module.go:35743	0x63072b		bb0c000000		MOVL $0xc, BX										
  module.go:35743	0x630730		b904000000		MOVL $0x4, CX										
  module.go:35743	0x630735		e826bcf9ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn4(SB)		
  module.go:35743	0x63073a		660f1f440000		NOPW 0(AX)(AX*1)									
  module.go:35745	0x630740		85c0			TESTL AX, AX										
  module.go:35745	0x630742		0f84a7010000		JE 0x6308ef										
  module.go:35749	0x630748		488b8c2498000000	MOVQ 0x98(SP), CX									
  module.go:35749	0x630750		488b5138		MOVQ 0x38(CX), DX									
  module.go:35749	0x630754		89c3			MOVL AX, BX										
  module.go:62945	0x630756		488d730b		LEAQ 0xb(BX), SI									
  module.go:62945	0x63075a		660f1f440000		NOPW 0(AX)(AX*1)									
  module.go:62945	0x630760		4839f2			CMPQ DX, SI										
  module.go:62945	0x630763		0f8681010000		JBE 0x6308ea										
  module.go:35749	0x630769		488b5130		MOVQ 0x30(CX), DX									
  module.go:62946	0x63076d		c744130810000000	MOVL $0x10, 0x8(BX)(DX*1)								
  module.go:35750	0x630775		488b5138		MOVQ 0x38(CX), DX									
  module.go:62945	0x630779		488d7307		LEAQ 0x7(BX), SI									
  module.go:62945	0x63077d		0f1f00			NOPL 0(AX)										
  module.go:62945	0x630780		4839f2			CMPQ DX, SI										
  module.go:62945	0x630783		0f865c010000		JBE 0x6308e5										
  module.go:35750	0x630789		488b5130		MOVQ 0x30(CX), DX									
  module.go:62946	0x63078d		8b742420		MOVL 0x20(SP), SI									
  module.go:62946	0x630791		89741304		MOVL SI, 0x4(BX)(DX*1)									
  module.go:35751	0x630795		488b5138		MOVQ 0x38(CX), DX									
  module.go:62945	0x630799		4883c303		ADDQ $0x3, BX										
  module.go:62945	0x63079d		0f1f00			NOPL 0(AX)										
  module.go:62945	0x6307a0		4839da			CMPQ DX, BX										
  module.go:62945	0x6307a3		0f8635010000		JBE 0x6308de										
  module.go:35737	0x6307a9		8b542430		MOVL 0x30(SP), DX									
  module.go:35737	0x6307ad		8d5ae8			LEAL -0x18(DX), BX									
  module.go:35751	0x6307b0		488b7130		MOVQ 0x30(CX), SI									
  module.go:35752	0x6307b4		89df			MOVL BX, DI										
  module.go:62946	0x6307b6		4189c0			MOVL AX, R8										
  module.go:62946	0x6307b9		42c7040610000000	MOVL $0x10, 0(SI)(R8*1)									
  module.go:35752	0x6307c1		488b7138		MOVQ 0x38(CX), SI									
  module.go:62945	0x6307c5		4c8d4707		LEAQ 0x7(DI), R8									
  module.go:62945	0x6307c9		4c39c6			CMPQ SI, R8										
  module.go:62945	0x6307cc		0f8607010000		JBE 0x6308d9										
  module.go:35752	0x6307d2		488b7130		MOVQ 0x30(CX), SI									
  module.go:62946	0x6307d6		c744370490931000	MOVL $0x109390, 0x4(DI)(SI*1)								
  module.go:35753	0x6307de		488b7138		MOVQ 0x38(CX), SI									
  module.go:62945	0x6307e2		4883c703		ADDQ $0x3, DI										
  module.go:62945	0x6307e6		4839fe			CMPQ SI, DI										
  module.go:62945	0x6307e9		0f86e5000000		JBE 0x6308d4										
  module.go:35753	0x6307ef		488b7130		MOVQ 0x30(CX), SI									
  module.go:35755	0x6307f3		8b7c242c		MOVL 0x2c(SP), DI									
  module.go:35755	0x6307f7		89ff			MOVL DI, DI										
  module.go:62946	0x6307f9		89db			MOVL BX, BX										
  module.go:62946	0x6307fb		89041e			MOVL AX, 0(SI)(BX*1)									
  module.go:35755	0x6307fe		488b4138		MOVQ 0x38(CX), AX									
  module.go:62928	0x630802		488d5f0f		LEAQ 0xf(DI), BX									
  module.go:62928	0x630806		4839d8			CMPQ AX, BX										
  module.go:62928	0x630809		0f86c0000000		JBE 0x6308cf										
  module.go:35755	0x63080f		488b4130		MOVQ 0x30(CX), AX									
  module.go:62929	0x630813		8b5c070c		MOVL 0xc(DI)(AX*1), BX									
  module.go:63129	0x630817		8b440708		MOVL 0x8(DI)(AX*1), AX									
  module.go:35702	0x63081b		8d72f8			LEAL -0x8(DX), SI									
  module.go:36164	0x63081e		488b7938		MOVQ 0x38(CX), DI									
  module.go:36165	0x630822		4189f0			MOVL SI, R8										
  module.go:62945	0x630825		4d8d4807		LEAQ 0x7(R8), R9									
  module.go:62945	0x630829		4c39cf			CMPQ DI, R9										
  module.go:62945	0x63082c		0f8698000000		JBE 0x6308ca										
  module.go:36164	0x630832		4c8b4930		MOVQ 0x30(CX), R9									
  module.go:62946	0x630836		43895c0804		MOVL BX, 0x4(R8)(R9*1)									
  module.go:62945	0x63083b		498d5803		LEAQ 0x3(R8), BX									
  module.go:36166	0x63083f		90			NOPL											
  module.go:62945	0x630840		4839df			CMPQ DI, BX										
  module.go:62945	0x630843		0f867c000000		JBE 0x6308c5										
  module.go:35700	0x630849		8d5af0			LEAL -0x10(DX), BX									
  module.go:36171	0x63084c		89df			MOVL BX, DI										
  module.go:62946	0x63084e		89f6			MOVL SI, SI										
  module.go:62946	0x630850		41890431		MOVL AX, 0(R9)(SI*1)									
  module.go:36167	0x630854		895950			MOVL BX, 0x50(CX)									
  module.go:36171	0x630857		488b4138		MOVQ 0x38(CX), AX									
  module.go:62928	0x63085b		488d5f0f		LEAQ 0xf(DI), BX									
  module.go:62928	0x63085f		90			NOPL											
  module.go:62928	0x630860		4839d8			CMPQ AX, BX										
  module.go:62928	0x630863		765a			JBE 0x6308bf										
  module.go:36171	0x630865		488b5930		MOVQ 0x30(CX), BX									
  module.go:62928	0x630869		488d770b		LEAQ 0xb(DI), SI									
  module.go:36174	0x63086d		90			NOPL											
  module.go:62929	0x63086e		448b441f0c		MOVL 0xc(DI)(BX*1), R8									
  module.go:62928	0x630873		4839f0			CMPQ AX, SI										
  module.go:62928	0x630876		7642			JBE 0x6308ba										
  module.go:62945	0x630878		8bb424a0000000		MOVL 0xa0(SP), SI									
  module.go:62945	0x63087f		4189f1			MOVL SI, R9										
  module.go:62945	0x630882		4d8d5103		LEAQ 0x3(R9), R10									
  module.go:36175	0x630886		90			NOPL											
  module.go:62929	0x630887		8b7c1f08		MOVL 0x8(DI)(BX*1), DI									
  module.go:62945	0x63088b		4c39d0			CMPQ AX, R10										
  module.go:62945	0x63088e		7625			JBE 0x6308b5										
  module.go:62946	0x630890		89f6			MOVL SI, SI										
  module.go:62946	0x630892		893c33			MOVL DI, 0(BX)(SI*1)									
  module.go:62945	0x630895		498d7107		LEAQ 0x7(R9), SI									
  module.go:36176	0x630899		90			NOPL											
  module.go:62945	0x63089a		4839f0			CMPQ AX, SI										
  module.go:62945	0x63089d		7611			JBE 0x6308b0										
  module.go:62946	0x63089f		4589441904		MOVL R8, 0x4(R9)(BX*1)									
  module.go:36177	0x6308a4		895150			MOVL DX, 0x50(CX)									
  module.go:36178	0x6308a7		4881c488000000		ADDQ $0x88, SP										
  module.go:36178	0x6308ae		5d			POPQ BP											
  module.go:36178	0x6308af		c3			RET											
  module.go:62945	0x6308b0		e80b01e6ff		CALL runtime.panicBounds(SB)								
  module.go:62945	0x6308b5		e80601e6ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x6308ba		e80101e6ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x6308bf		90			NOPL											
  module.go:62928	0x6308c0		e8fb00e6ff		CALL runtime.panicBounds(SB)								
  module.go:62945	0x6308c5		e8f600e6ff		CALL runtime.panicBounds(SB)								
  module.go:62945	0x6308ca		e8f100e6ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x6308cf		e8ec00e6ff		CALL runtime.panicBounds(SB)								
  module.go:62945	0x6308d4		e8e700e6ff		CALL runtime.panicBounds(SB)								
  module.go:62945	0x6308d9		e8e200e6ff		CALL runtime.panicBounds(SB)								
  module.go:62945	0x6308de		6690			NOPW											
  module.go:62945	0x6308e0		e8db00e6ff		CALL runtime.panicBounds(SB)								
  module.go:62945	0x6308e5		e8d600e6ff		CALL runtime.panicBounds(SB)								
  module.go:62945	0x6308ea		e8d100e6ff		CALL runtime.panicBounds(SB)								
  module.go:35746	0x6308ef		488b842498000000	MOVQ 0x98(SP), AX									
  module.go:35746	0x6308f7		bb04000000		MOVL $0x4, BX										
  module.go:35746	0x6308fc		b90c000000		MOVL $0xc, CX										
  module.go:35746	0x630901		e83a3efaff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn35(SB)		
  module.go:35747	0x630906		488d0513a12100		LEAQ 0x21a113(IP), AX									
  module.go:35747	0x63090d		488d1ddc192d00		LEAQ 0x2d19dc(IP), BX									
  module.go:35747	0x630914		e8c77ee5ff		CALL runtime.gopanic(SB)								
  module.go:63058	0x630919		48c7c0718e1000		MOVQ $0x108e71, AX									
  module.go:63058	0x630920		e89b00e6ff		CALL runtime.panicBounds(SB)								
  module.go:63058	0x630925		e89600e6ff		CALL runtime.panicBounds(SB)								
  module.go:35762	0x63092a		488b842498000000	MOVQ 0x98(SP), AX									
  module.go:35762	0x630932		bb01000000		MOVL $0x1, BX										
  module.go:35762	0x630937		b910000000		MOVL $0x10, CX										
  module.go:35762	0x63093c		0f1f4000		NOPL 0(AX)										
  module.go:35762	0x630940		e89bb7f9ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn2(SB)		
  module.go:35763	0x630945		488d05d4a02100		LEAQ 0x21a0d4(IP), AX									
  module.go:35763	0x63094c		488d1d9d192d00		LEAQ 0x2d199d(IP), BX									
  module.go:35763	0x630953		e8887ee5ff		CALL runtime.gopanic(SB)								
  module.go:35757	0x630958		89cb			MOVL CX, BX										
  module.go:36164	0x63095a		4889c1			MOVQ AX, CX										
  module.go:36164	0x63095d		31c0			XORL AX, AX										
  module.go:36164	0x63095f		90			NOPL											
  module.go:36162	0x630960		e9b6feffff		JMP 0x63081b										
  module.go:62971	0x630965		e85600e6ff		CALL runtime.panicBounds(SB)								
  module.go:62954	0x63096a		e85100e6ff		CALL runtime.panicBounds(SB)								
  module.go:36141	0x63096f		39d6			CMPL SI, DX										
  module.go:36141	0x630971		0f86a2000000		JBE 0x630a19										
  module.go:36145	0x630977		488b4838		MOVQ 0x38(AX), CX									
  module.go:62928	0x63097b		498d7107		LEAQ 0x7(R9), SI									
  module.go:62928	0x63097f		90			NOPL											
  module.go:62928	0x630980		4839f1			CMPQ CX, SI										
  module.go:62928	0x630983		0f868b000000		JBE 0x630a14										
  module.go:36145	0x630989		488b7030		MOVQ 0x30(AX), SI									
  module.go:62928	0x63098d		498d790b		LEAQ 0xb(R9), DI									
  module.go:36146	0x630991		90			NOPL											
  module.go:62929	0x630992		458b443104		MOVL 0x4(R9)(SI*1), R8									
  module.go:62928	0x630997		4839f9			CMPQ CX, DI										
  module.go:62928	0x63099a		7673			JBE 0x630a0f										
  module.go:62929	0x63099c		418b7c3108		MOVL 0x8(R9)(SI*1), DI									
  module.go:36147	0x6309a1		01fa			ADDL DI, DX										
  module.go:63129	0x6309a3		89db			MOVL BX, BX										
  module.go:63129	0x6309a5		8b1c33			MOVL 0(BX)(SI*1), BX									
  module.go:36148	0x6309a8		90			NOPL											
  module.go:36152	0x6309a9		39d3			CMPL BX, DX										
  module.go:36152	0x6309ab		7602			JBE 0x6309af										
  module.go:36152	0x6309ad		31db			XORL BX, BX										
  module.go:36155	0x6309af		29da			SUBL BX, DX										
  module.go:36155	0x6309b1		418d14d0		LEAL 0(R8)(DX*8), DX									
  module.go:62954	0x6309b5		89d3			MOVL DX, BX										
  module.go:62954	0x6309b7		4883c307		ADDQ $0x7, BX										
  module.go:36156	0x6309bb		90			NOPL											
  module.go:36156	0x6309bc		0f1f4000		NOPL 0(AX)										
  module.go:62954	0x6309c0		4839d9			CMPQ CX, BX										
  module.go:62954	0x6309c3		7645			JBE 0x630a0a										
  module.go:36157	0x6309c5		488b4838		MOVQ 0x38(AX), CX									
  module.go:62955	0x6309c9		89d7			MOVL DX, DI										
  module.go:62955	0x6309cb		488b3437		MOVQ 0(DI)(SI*1), SI									
  unsafe.go:41		0x6309cf		66480f6ec6		MOVQ SI, X0										
  module.go:36156	0x6309d4		90			NOPL											
  module.go:36157	0x6309d5		f20f100d8b152d00	MOVSD_XMM $f64.3ff0000000000000(SB), X1							
  module.go:36157	0x6309dd		f20f58c1		ADDSD X1, X0										
  module.go:62971	0x6309e1		4839d9			CMPQ CX, BX										
  module.go:62971	0x6309e4		761f			JBE 0x630a05										
  module.go:36157	0x6309e6		488b7030		MOVQ 0x30(AX), SI									
  module.go:62972	0x6309ea		f20f11043e		MOVSD_XMM X0, 0(SI)(DI*1)								
  module.go:62945	0x6309ef		8b9c24a0000000		MOVL 0xa0(SP), BX									
  module.go:36159	0x6309f6		89d1			MOVL DX, CX										
  module.go:35702	0x6309f8		8b542430		MOVL 0x30(SP), DX									
  module.go:35702	0x6309fc		0f1f4000		NOPL 0(AX)										
  module.go:36160	0x630a00		e953ffffff		JMP 0x630958										
  module.go:62971	0x630a05		e8b6ffe5ff		CALL runtime.panicBounds(SB)								
  module.go:62954	0x630a0a		e8b1ffe5ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x630a0f		e8acffe5ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x630a14		e8a7ffe5ff		CALL runtime.panicBounds(SB)								
  module.go:36142	0x630a19		bbf88e1000		MOVL $0x108ef8, BX									
  module.go:36142	0x630a1e		b914000000		MOVL $0x14, CX										
  module.go:36142	0x630a23		bf0c8f1000		MOVL $0x108f0c, DI									
  module.go:36142	0x630a28		e873effaff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn69(SB)		
  module.go:36143	0x630a2d		488d05ec9f2100		LEAQ 0x219fec(IP), AX									
  module.go:36143	0x630a34		488d1db5182d00		LEAQ 0x2d18b5(IP), BX									
  module.go:36143	0x630a3b		0f1f440000		NOPL 0(AX)(AX*1)									
  module.go:36143	0x630a40		e89b7de5ff		CALL runtime.gopanic(SB)								
  module.go:62971	0x630a45		e876ffe5ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x630a4a		e871ffe5ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x630a4f		e86cffe5ff		CALL runtime.panicBounds(SB)								
  module.go:62945	0x630a54		e867ffe5ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x630a59		e862ffe5ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x630a5e		6690			NOPW											
  module.go:62928	0x630a60		e85bffe5ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x630a65		e856ffe5ff		CALL runtime.panicBounds(SB)								
  module.go:62945	0x630a6a		e851ffe5ff		CALL runtime.panicBounds(SB)								
  module.go:36019	0x630a6f		488b5038		MOVQ 0x38(AX), DX									
  module.go:62928	0x630a73		4c39ea			CMPQ DX, R13										
  module.go:62928	0x630a76		7613			JBE 0x630a8b										
  module.go:36019	0x630a78		4c8b4030		MOVQ 0x30(AX), R8									
  module.go:36020	0x630a7c		90			NOPL											
  module.go:62946	0x630a7d		43297c0110		SUBL DI, 0x10(R9)(R8*1)									
  module.go:62946	0x630a82		31d2			XORL DX, DX										
  module.go:36140	0x630a84		89ce			MOVL CX, SI										
  module.go:36022	0x630a86		e9e4feffff		JMP 0x63096f										
  module.go:62928	0x630a8b		e830ffe5ff		CALL runtime.panicBounds(SB)								
  module.go:36013	0x630a90		ffcf			DECL DI											
  module.go:63129	0x630a92		4c8b542468		MOVQ 0x68(SP), R10									
  module.go:36015	0x630a97		89f1			MOVL SI, CX										
  module.go:35991	0x630a99		4439e1			CMPL CX, R12										
  module.go:35991	0x630a9c		7567			JNE 0x630b05										
  module.go:36015	0x630a9e		897c244c		MOVL DI, 0x4c(SP)									
  module.go:35992	0x630aa2		e8d93dfbff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn88(SB)		
  module.go:35993	0x630aa7		488b842498000000	MOVQ 0x98(SP), AX									
  module.go:35993	0x630aaf		488b4838		MOVQ 0x38(AX), CX									
  module.go:62928	0x630ab3		488b542478		MOVQ 0x78(SP), DX									
  module.go:62928	0x630ab8		0f1f840000000000	NOPL 0(AX)(AX*1)									
  module.go:62928	0x630ac0		4839d1			CMPQ CX, DX										
  module.go:62928	0x630ac3		0f86e1000000		JBE 0x630baa										
  module.go:35993	0x630ac9		488b7030		MOVQ 0x30(AX), SI									
  module.go:35995	0x630acd		90			NOPL											
  module.go:62929	0x630ace		4c8b842480000000	MOVQ 0x80(SP), R8									
  module.go:62929	0x630ad6		418b4c300c		MOVL 0xc(R8)(SI*1), CX									
  module.go:63129	0x630adb		4c8b4c2468		MOVQ 0x68(SP), R9									
  module.go:63129	0x630ae0		458b2431		MOVL 0(R9)(SI*1), R12									
  module.go:62946	0x630ae4		8b542424		MOVL 0x24(SP), DX									
  module.go:35992	0x630ae8		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:36014	0x630aef		8b7c244c		MOVL 0x4c(SP), DI									
  module.go:62946	0x630af3		4d89c1			MOVQ R8, R9										
  module.go:63129	0x630af6		4c8b542468		MOVQ 0x68(SP), R10									
  module.go:62945	0x630afb		4c8b5c2478		MOVQ 0x78(SP), R11									
  module.go:62928	0x630b00		4c8b6c2470		MOVQ 0x70(SP), R13									
  module.go:36000	0x630b05		488b7038		MOVQ 0x38(AX), SI									
  module.go:62945	0x630b09		4c39de			CMPQ SI, R11										
  module.go:62945	0x630b0c		0f8693000000		JBE 0x630ba5										
  module.go:35999	0x630b12		8d7101			LEAL 0x1(CX), SI									
  module.go:36000	0x630b15		4c8b4030		MOVQ 0x30(AX), R8									
  module.go:62946	0x630b19		438974010c		MOVL SI, 0xc(R9)(R8*1)									
  module.go:36001	0x630b1e		4c8b4038		MOVQ 0x38(AX), R8									
  module.go:62928	0x630b22		4d8d790b		LEAQ 0xb(R9), R15									
  module.go:62928	0x630b26		4d39f8			CMPQ R8, R15										
  module.go:62928	0x630b29		7671			JBE 0x630b9c										
  module.go:36001	0x630b2b		4c8b4030		MOVQ 0x30(AX), R8									
  module.go:62929	0x630b2f		478b7c0108		MOVL 0x8(R9)(R8*1), R15									
  module.go:36003	0x630b34		418d4fff		LEAL -0x1(R15), CX									
  module.go:36004	0x630b38		478d3c3c		LEAL 0(R12)(R15*1), R15									
  module.go:36004	0x630b3c		458d7fff		LEAL -0x1(R15), R15									
  module.go:62928	0x630b40		4d8d5107		LEAQ 0x7(R9), R10									
  module.go:36010	0x630b44		90			NOPL											
  module.go:36006	0x630b45		4139cf			CMPL R15, CX										
  module.go:36007	0x630b48		410f42cf		CMOVB R15, CX										
  module.go:62946	0x630b4c		43894c0108		MOVL CX, 0x8(R9)(R8*1)									
  module.go:36011	0x630b51		4c8b4038		MOVQ 0x38(AX), R8									
  module.go:62928	0x630b55		4d39d0			CMPQ R8, R10										
  module.go:62928	0x630b58		763d			JBE 0x630b97										
  module.go:36011	0x630b5a		4c8b5030		MOVQ 0x30(AX), R10									
  module.go:62929	0x630b5e		478b7c1104		MOVL 0x4(R9)(R10*1), R15								
  module.go:36012	0x630b63		458d3ccf		LEAL 0(R15)(CX*8), R15									
  module.go:62971	0x630b67		4489f9			MOVL R15, CX										
  module.go:62971	0x630b6a		4883c107		ADDQ $0x7, CX										
  module.go:62971	0x630b6e		4939c8			CMPQ R8, CX										
  module.go:62971	0x630b71		761f			JBE 0x630b92										
  module.go:62972	0x630b73		4589f8			MOVL R15, R8										
  module.go:62972	0x630b76		4bc7040200000000	MOVQ $0x0, 0(R10)(R8*1)									
  module.go:62972	0x630b7e		6690			NOPW											
  module.go:36014	0x630b80		83ff01			CMPL DI, $0x1										
  module.go:36014	0x630b83		0f8507ffffff		JNE 0x630a90										
  module.go:62946	0x630b89		89d7			MOVL DX, DI										
  module.go:62946	0x630b8b		89f1			MOVL SI, CX										
  module.go:36014	0x630b8d		e9ddfeffff		JMP 0x630a6f										
  module.go:62971	0x630b92		e829fee5ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x630b97		e824fee5ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x630b9c		0f1f4000		NOPL 0(AX)										
  module.go:62928	0x630ba0		e81bfee5ff		CALL runtime.panicBounds(SB)								
  module.go:62945	0x630ba5		e816fee5ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x630baa		e811fee5ff		CALL runtime.panicBounds(SB)								
  module.go:63058	0x630baf		e80cfee5ff		CALL runtime.panicBounds(SB)								
  module.go:63058	0x630bb4		e807fee5ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x630bb9		e802fee5ff		CALL runtime.panicBounds(SB)								
  module.go:62945	0x630bbe		6690			NOPW											
  module.go:62945	0x630bc0		e8fbfde5ff		CALL runtime.panicBounds(SB)								
  module.go:63058	0x630bc5		e8f6fde5ff		CALL runtime.panicBounds(SB)								
  module.go:63058	0x630bca		e8f1fde5ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x630bcf		e8ecfde5ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x630bd4		e8e7fde5ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x630bd9		e8e2fde5ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x630bde		6690			NOPW											
  module.go:62928	0x630be0		e8dbfde5ff		CALL runtime.panicBounds(SB)								
  module.go:35933	0x630be5		bb508e1000		MOVL $0x108e50, BX									
  module.go:35933	0x630bea		b911000000		MOVL $0x11, CX										
  module.go:35933	0x630bef		bfe88e1000		MOVL $0x108ee8, DI									
  module.go:35933	0x630bf4		e8a7edfaff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn69(SB)		
  module.go:35934	0x630bf9		488d05209e2100		LEAQ 0x219e20(IP), AX									
  module.go:35934	0x630c00		488d1de9162d00		LEAQ 0x2d16e9(IP), BX									
  module.go:35934	0x630c07		e8d47be5ff		CALL runtime.gopanic(SB)								
  module.go:62928	0x630c0c		e8affde5ff		CALL runtime.panicBounds(SB)								
  module.go:36088	0x630c11		4439d6			CMPL SI, R10										
  module.go:36088	0x630c14		7602			JBE 0x630c18										
  module.go:36088	0x630c16		31f6			XORL SI, SI										
  module.go:36091	0x630c18		4129f2			SUBL SI, R10										
  module.go:36091	0x630c1b		438d34d3		LEAL 0(R11)(R10*8), SI									
  module.go:36092	0x630c1f		4c8b5038		MOVQ 0x38(AX), R10									
  module.go:62954	0x630c23		4189f3			MOVL SI, R11										
  module.go:62954	0x630c26		4983c307		ADDQ $0x7, R11										
  module.go:62954	0x630c2a		4d39da			CMPQ R10, R11										
  module.go:62954	0x630c2d		0f86f7010000		JBE 0x630e2a										
  module.go:36092	0x630c33		4c8b5030		MOVQ 0x30(AX), R10									
  module.go:36093	0x630c37		4c8b6038		MOVQ 0x38(AX), R12									
  module.go:62955	0x630c3b		89f6			MOVL SI, SI										
  module.go:62955	0x630c3d		4e8b1416		MOVQ 0(SI)(R10*1), R10									
  module.go:36092	0x630c41		66490f6eca		MOVQ R10, X1										
  module.go:36093	0x630c46		f20f58c1		ADDSD X1, X0										
  module.go:62971	0x630c4a		4d39dc			CMPQ R12, R11										
  module.go:62971	0x630c4d		0f86d2010000		JBE 0x630e25										
  module.go:36093	0x630c53		4c8b5030		MOVQ 0x30(AX), R10									
  module.go:62972	0x630c57		f2410f110432		MOVSD_XMM X0, 0(R10)(SI*1)								
  module.go:36098	0x630c5d		488b7038		MOVQ 0x38(AX), SI									
  module.go:36097	0x630c61		448d143a		LEAL 0(DX)(DI*1), R10									
  module.go:36097	0x630c65		8d143a			LEAL 0(DX)(DI*1), DX									
  module.go:36097	0x630c68		8d5201			LEAL 0x1(DX), DX									
  module.go:62945	0x630c6b		4c39ee			CMPQ SI, R13										
  module.go:62945	0x630c6e		0f86aa010000		JBE 0x630e1e										
  module.go:36098	0x630c74		488b7030		MOVQ 0x30(AX), SI									
  module.go:62946	0x630c78		4189543110		MOVL DX, 0x10(R9)(SI*1)									
  module.go:36099	0x630c7d		4529d0			SUBL R10, R8										
  module.go:36099	0x630c80		418d50ff		LEAL -0x1(R8), DX									
  module.go:36102	0x630c84		89d6			MOVL DX, SI										
  module.go:36102	0x630c86		29ca			SUBL CX, DX										
  module.go:36102	0x630c88		81fafeffff7f		CMPL DX, $0x7ffffffe									
  module.go:36102	0x630c8e		773d			JA 0x630ccd										
  module.go:36106	0x630c90		488b5038		MOVQ 0x38(AX), DX									
  module.go:62928	0x630c94		4d8d4103		LEAQ 0x3(R9), R8									
  module.go:62928	0x630c98		0f1f840000000000	NOPL 0(AX)(AX*1)									
  module.go:62928	0x630ca0		4c39c2			CMPQ DX, R8										
  module.go:62928	0x630ca3		0f8670010000		JBE 0x630e19										
  module.go:62928	0x630ca9		4c89442470		MOVQ R8, 0x70(SP)									
  module.go:36099	0x630cae		8974244c		MOVL SI, 0x4c(SP)									
  module.go:36106	0x630cb2		488b5030		MOVQ 0x30(AX), DX									
  module.go:62929	0x630cb6		4189da			MOVL BX, R10										
  module.go:62929	0x630cb9		4c89542468		MOVQ R10, 0x68(SP)									
  module.go:36105	0x630cbe		448d59ff		LEAL -0x1(CX), R11									
  module.go:62929	0x630cc2		418b1412		MOVL 0(R10)(DX*1), DX									
  module.go:36108	0x630cc6		4c8b642478		MOVQ 0x78(SP), R12									
  module.go:36108	0x630ccb		eb21			JMP 0x630cee										
  module.go:36021	0x630ccd		89f2			MOVL SI, DX										
  module.go:36140	0x630ccf		89ce			MOVL CX, SI										
  module.go:36103	0x630cd1		e999fcffff		JMP 0x63096f										
  module.go:62928	0x630cd6		4c8b442470		MOVQ 0x70(SP), R8									
  module.go:62929	0x630cdb		4c8b542468		MOVQ 0x68(SP), R10									
  module.go:36136	0x630ce0		4489e9			MOVL R13, CX										
  module.go:36136	0x630ce3		4589cb			MOVL R9, R11										
  module.go:62946	0x630ce6		4c8b8c2480000000	MOVQ 0x80(SP), R9									
  module.go:36112	0x630cee		39ca			CMPL DX, CX										
  module.go:36112	0x630cf0		7574			JNE 0x630d66										
  module.go:36136	0x630cf2		44895c2424		MOVL R11, 0x24(SP)									
  module.go:36113	0x630cf7		e8843bfbff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn88(SB)		
  module.go:36114	0x630cfc		488b842498000000	MOVQ 0x98(SP), AX									
  module.go:36114	0x630d04		488b4838		MOVQ 0x38(AX), CX									
  module.go:62928	0x630d08		488b542470		MOVQ 0x70(SP), DX									
  module.go:62928	0x630d0d		4839d1			CMPQ CX, DX										
  module.go:62928	0x630d10		0f86fe000000		JBE 0x630e14										
  module.go:36114	0x630d16		488b7030		MOVQ 0x30(AX), SI									
  module.go:62929	0x630d1a		4c8b442468		MOVQ 0x68(SP), R8									
  module.go:62929	0x630d1f		458b0c30		MOVL 0(R8)(SI*1), R9									
  module.go:62928	0x630d23		4c8b542478		MOVQ 0x78(SP), R10									
  module.go:62928	0x630d28		4c39d1			CMPQ CX, R10										
  module.go:62928	0x630d2b		0f86de000000		JBE 0x630e0f										
  module.go:62929	0x630d31		4c8b9c2480000000	MOVQ 0x80(SP), R11									
  module.go:62929	0x630d39		418b4c330c		MOVL 0xc(R11)(SI*1), CX									
  module.go:36113	0x630d3e		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:36135	0x630d45		8b74244c		MOVL 0x4c(SP), SI									
  module.go:62928	0x630d49		4989d0			MOVQ DX, R8										
  module.go:62929	0x630d4c		4c8b542468		MOVQ 0x68(SP), R10									
  module.go:36134	0x630d51		448b5c2424		MOVL 0x24(SP), R11									
  module.go:62945	0x630d56		4c8b642478		MOVQ 0x78(SP), R12									
  module.go:36116	0x630d5b		4489ca			MOVL R9, DX										
  module.go:62946	0x630d5e		4c8b8c2480000000	MOVQ 0x80(SP), R9									
  module.go:36123	0x630d66		4c8b6838		MOVQ 0x38(AX), R13									
  module.go:62945	0x630d6a		4d39e5			CMPQ R13, R12										
  module.go:62945	0x630d6d		0f8697000000		JBE 0x630e0a										
  module.go:36122	0x630d73		448d6901		LEAL 0x1(CX), R13									
  module.go:36123	0x630d77		4c8b7830		MOVQ 0x30(AX), R15									
  module.go:62946	0x630d7b		47896c390c		MOVL R13, 0xc(R9)(R15*1)								
  module.go:36124	0x630d80		4c8b7838		MOVQ 0x38(AX), R15									
  module.go:62928	0x630d84		498d7907		LEAQ 0x7(R9), DI									
  module.go:62928	0x630d88		4939ff			CMPQ R15, DI										
  module.go:62928	0x630d8b		7678			JBE 0x630e05										
  module.go:36124	0x630d8d		488b7830		MOVQ 0x30(AX), DI									
  module.go:62928	0x630d91		4d8d510b		LEAQ 0xb(R9), R10									
  module.go:36125	0x630d95		90			NOPL											
  module.go:62929	0x630d96		458b443904		MOVL 0x4(R9)(DI*1), R8									
  module.go:62929	0x630d9b		0f1f440000		NOPL 0(AX)(AX*1)									
  module.go:62928	0x630da0		4d39d7			CMPQ R15, R10										
  module.go:62928	0x630da3		7656			JBE 0x630dfb										
  module.go:62929	0x630da5		458b543908		MOVL 0x8(R9)(DI*1), R10									
  module.go:36126	0x630daa		4101ca			ADDL CX, R10										
  module.go:36129	0x630dad		4439d2			CMPL DX, R10										
  module.go:35772	0x630db0		4c89c9			MOVQ R9, CX										
  module.go:36130	0x630db3		41b900000000		MOVL $0x0, R9										
  module.go:36130	0x630db9		440f46ca		CMOVBE DX, R9										
  module.go:36132	0x630dbd		4529ca			SUBL R9, R10										
  module.go:36132	0x630dc0		478d04d0		LEAL 0(R8)(R10*8), R8									
  module.go:62971	0x630dc4		4589c1			MOVL R8, R9										
  module.go:62971	0x630dc7		4983c107		ADDQ $0x7, R9										
  module.go:62971	0x630dcb		4d39cf			CMPQ R15, R9										
  module.go:36129	0x630dce		7626			JBE 0x630df6										
  module.go:36134	0x630dd0		458d4b01		LEAL 0x1(R11), R9									
  module.go:62972	0x630dd4		4589c0			MOVL R8, R8										
  module.go:62972	0x630dd7		4ac7040700000000	MOVQ $0x0, 0(DI)(R8*1)									
  module.go:62972	0x630ddf		90			NOPL											
  module.go:36135	0x630de0		4439ce			CMPL SI, R9										
  module.go:36135	0x630de3		0f85edfeffff		JNE 0x630cd6										
  module.go:62928	0x630de9		4989c9			MOVQ CX, R9										
  module.go:36021	0x630dec		89f2			MOVL SI, DX										
  module.go:36140	0x630dee		4489ee			MOVL R13, SI										
  module.go:36135	0x630df1		e979fbffff		JMP 0x63096f										
  module.go:62971	0x630df6		e8c5fbe5ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x630dfb		0f1f440000		NOPL 0(AX)(AX*1)									
  module.go:62928	0x630e00		e8bbfbe5ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x630e05		e8b6fbe5ff		CALL runtime.panicBounds(SB)								
  module.go:62945	0x630e0a		e8b1fbe5ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x630e0f		e8acfbe5ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x630e14		e8a7fbe5ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x630e19		e8a2fbe5ff		CALL runtime.panicBounds(SB)								
  module.go:62945	0x630e1e		6690			NOPW											
  module.go:62945	0x630e20		e89bfbe5ff		CALL runtime.panicBounds(SB)								
  module.go:62971	0x630e25		e896fbe5ff		CALL runtime.panicBounds(SB)								
  module.go:62954	0x630e2a		e891fbe5ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x630e2f		e88cfbe5ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x630e34		e887fbe5ff		CALL runtime.panicBounds(SB)								
  module.go:35895	0x630e39		83c6fe			ADDL $-0x2, SI										
  module.go:35897	0x630e3c		894c2420		MOVL CX, 0x20(SP)									
  module.go:35897	0x630e40		8b4c243c		MOVL 0x3c(SP), CX									
  module.go:35843	0x630e44		85c9			TESTL CX, CX										
  module.go:35843	0x630e46		750a			JNE 0x630e52										
  module.go:35843	0x630e48		31c9			XORL CX, CX										
  module.go:35843	0x630e4a		0f57c9			XORPS X1, X1										
  module.go:35847	0x630e4d		e998000000		JMP 0x630eea										
  module.go:35851	0x630e52		4c8b7838		MOVQ 0x38(AX), R15									
  module.go:62945	0x630e56		4d39df			CMPQ R15, R11										
  module.go:62945	0x630e59		0f867a030000		JBE 0x6311d9										
  module.go:35850	0x630e5f		448d79ff		LEAL -0x1(CX), R15									
  module.go:35851	0x630e63		488b4830		MOVQ 0x30(AX), CX									
  module.go:62946	0x630e67		45897c090c		MOVL R15, 0xc(R9)(CX*1)									
  module.go:35853	0x630e6c		418d4d01		LEAL 0x1(R13), CX									
  module.go:35856	0x630e70		4139cc			CMPL R12, CX										
  module.go:35856	0x630e73		7705			JA 0x630e7a										
  module.go:63129	0x630e75		4489e1			MOVL R12, CX										
  module.go:35857	0x630e78		eb06			JMP 0x630e80										
  module.go:35883	0x630e7a		4489e1			MOVL R12, CX										
  module.go:35883	0x630e7d		4531e4			XORL R12, R12										
  module.go:35897	0x630e80		44896c2428		MOVL R13, 0x28(SP)									
  module.go:35860	0x630e85		4c8b4038		MOVQ 0x38(AX), R8									
  module.go:35859	0x630e89		4529e5			SUBL R12, R13										
  module.go:62945	0x630e8c		4939d8			CMPQ R8, BX										
  module.go:62945	0x630e8f		0f863f030000		JBE 0x6311d4										
  module.go:35859	0x630e95		458d4501		LEAL 0x1(R13), R8									
  module.go:35860	0x630e99		4c8b6030		MOVQ 0x30(AX), R12									
  module.go:62946	0x630e9d		4789442108		MOVL R8, 0x8(R9)(R12*1)									
  module.go:35861	0x630ea2		4c8b6038		MOVQ 0x38(AX), R12									
  module.go:35861	0x630ea6		448b6c2428		MOVL 0x28(SP), R13									
  module.go:35861	0x630eab		468d2cea		LEAL 0(DX)(R13*8), R13									
  module.go:62954	0x630eaf		4489ef			MOVL R13, DI										
  module.go:62954	0x630eb2		4883c707		ADDQ $0x7, DI										
  module.go:62954	0x630eb6		4939fc			CMPQ R12, DI										
  module.go:62954	0x630eb9		0f8610030000		JBE 0x6311cf										
  module.go:35861	0x630ebf		4c8b6030		MOVQ 0x30(AX), R12									
  module.go:62955	0x630ec3		4489ef			MOVL R13, DI										
  module.go:62955	0x630ec6		4e8b2427		MOVQ 0(DI)(R12*1), R12									
  unsafe.go:41		0x630eca		66490f6ecc		MOVQ R12, X1										
  module.go:36067	0x630ecf		8b7c2444		MOVL 0x44(SP), DI									
  module.go:35883	0x630ed3		4189cc			MOVL CX, R12										
  module.go:35861	0x630ed6		4489f9			MOVL R15, CX										
  module.go:35861	0x630ed9		4589c5			MOVL R8, R13										
  module.go:35861	0x630edc		894c2420		MOVL CX, 0x20(SP)									
  module.go:36099	0x630ee0		448b442448		MOVL 0x48(SP), R8									
  module.go:63129	0x630ee5		4c8b7c2468		MOVQ 0x68(SP), R15									
  module.go:35867	0x630eea		f20f58c8		ADDSD X0, X1										
  module.go:35870	0x630eee		85c9			TESTL CX, CX										
  module.go:35870	0x630ef0		7516			JNE 0x630f08										
  module.go:35870	0x630ef2		0f57c0			XORPS X0, X0										
  module.go:35888	0x630ef5		8b4c2420		MOVL 0x20(SP), CX									
  module.go:35888	0x630ef9		31c9			XORL CX, CX										
  module.go:35888	0x630efb		894c243c		MOVL CX, 0x3c(SP)									
  module.go:35888	0x630eff		8b4c2420		MOVL 0x20(SP), CX									
  module.go:35874	0x630f03		e998000000		JMP 0x630fa0										
  module.go:35878	0x630f08		4c8b7838		MOVQ 0x38(AX), R15									
  module.go:62945	0x630f0c		4d39df			CMPQ R15, R11										
  module.go:62945	0x630f0f		0f86b5020000		JBE 0x6311ca										
  module.go:35877	0x630f15		448d79ff		LEAL -0x1(CX), R15									
  module.go:35878	0x630f19		488b4830		MOVQ 0x30(AX), CX									
  module.go:62946	0x630f1d		45897c090c		MOVL R15, 0xc(R9)(CX*1)									
  module.go:35880	0x630f22		418d4d01		LEAL 0x1(R13), CX									
  module.go:35883	0x630f26		4139cc			CMPL R12, CX										
  module.go:35883	0x630f29		7705			JA 0x630f30										
  module.go:63129	0x630f2b		4489e1			MOVL R12, CX										
  module.go:35884	0x630f2e		eb06			JMP 0x630f36										
  module.go:35856	0x630f30		4489e1			MOVL R12, CX										
  module.go:35856	0x630f33		4531e4			XORL R12, R12										
  module.go:35861	0x630f36		44896c2440		MOVL R13, 0x40(SP)									
  module.go:35887	0x630f3b		4c8b4038		MOVQ 0x38(AX), R8									
  module.go:35886	0x630f3f		4529e5			SUBL R12, R13										
  module.go:62945	0x630f42		4939d8			CMPQ R8, BX										
  module.go:62945	0x630f45		0f867a020000		JBE 0x6311c5										
  module.go:35886	0x630f4b		458d4501		LEAL 0x1(R13), R8									
  module.go:35887	0x630f4f		4c8b6030		MOVQ 0x30(AX), R12									
  module.go:62946	0x630f53		4789442108		MOVL R8, 0x8(R9)(R12*1)									
  module.go:35888	0x630f58		4c8b6038		MOVQ 0x38(AX), R12									
  module.go:35888	0x630f5c		448b6c2440		MOVL 0x40(SP), R13									
  module.go:35888	0x630f61		468d2cea		LEAL 0(DX)(R13*8), R13									
  module.go:62954	0x630f65		4489ef			MOVL R13, DI										
  module.go:62954	0x630f68		4883c707		ADDQ $0x7, DI										
  module.go:62954	0x630f6c		4939fc			CMPQ R12, DI										
  module.go:62954	0x630f6f		0f8649020000		JBE 0x6311be										
  module.go:35888	0x630f75		4c8b6030		MOVQ 0x30(AX), R12									
  module.go:62955	0x630f79		4489ef			MOVL R13, DI										
  module.go:62955	0x630f7c		4e8b2427		MOVQ 0(DI)(R12*1), R12									
  unsafe.go:41		0x630f80		66490f6ec4		MOVQ R12, X0										
  module.go:36067	0x630f85		8b7c2444		MOVL 0x44(SP), DI									
  module.go:35856	0x630f89		4189cc			MOVL CX, R12										
  module.go:35888	0x630f8c		4589c5			MOVL R8, R13										
  module.go:35888	0x630f8f		4489f9			MOVL R15, CX										
  module.go:35888	0x630f92		894c243c		MOVL CX, 0x3c(SP)									
  module.go:36099	0x630f96		448b442448		MOVL 0x48(SP), R8									
  module.go:63129	0x630f9b		4c8b7c2468		MOVQ 0x68(SP), R15									
  module.go:35894	0x630fa0		f20f58c1		ADDSD X1, X0										
  module.go:35896	0x630fa4		83fe02			CMPL SI, $0x2										
  module.go:35896	0x630fa7		0f858cfeffff		JNE 0x630e39										
  module.go:36030	0x630fad		410fbae200		BTL $0x0, R10										
  module.go:36030	0x630fb2		7207			JB 0x630fbb										
  module.go:36031	0x630fb4		89ce			MOVL CX, SI										
  module.go:36031	0x630fb6		e99e000000		JMP 0x631059										
  module.go:36033	0x630fbb		89ce			MOVL CX, SI										
  module.go:36033	0x630fbd		8b4c243c		MOVL 0x3c(SP), CX									
  module.go:36034	0x630fc1		85c9			TESTL CX, CX										
  module.go:36034	0x630fc3		0f8489000000		JE 0x631052										
  module.go:36037	0x630fc9		488b7038		MOVQ 0x38(AX), SI									
  module.go:62945	0x630fcd		4c39de			CMPQ SI, R11										
  module.go:62945	0x630fd0		0f86e3010000		JBE 0x6311b9										
  module.go:36036	0x630fd6		8d71ff			LEAL -0x1(CX), SI									
  module.go:36037	0x630fd9		4c8b5030		MOVQ 0x30(AX), R10									
  module.go:62946	0x630fdd		438974110c		MOVL SI, 0xc(R9)(R10*1)									
  module.go:36039	0x630fe2		458d5501		LEAL 0x1(R13), R10									
  module.go:36042	0x630fe6		4539d4			CMPL R12, R10										
  module.go:36042	0x630fe9		7705			JA 0x630ff0										
  module.go:63129	0x630feb		4489e1			MOVL R12, CX										
  module.go:36043	0x630fee		eb06			JMP 0x630ff6										
  module.go:36057	0x630ff0		4489e1			MOVL R12, CX										
  module.go:36057	0x630ff3		4531e4			XORL R12, R12										
  module.go:36033	0x630ff6		44896c2438		MOVL R13, 0x38(SP)									
  module.go:36046	0x630ffb		4c8b5038		MOVQ 0x38(AX), R10									
  module.go:36045	0x630fff		4529e5			SUBL R12, R13										
  module.go:62945	0x631002		4939da			CMPQ R10, BX										
  module.go:62945	0x631005		0f86a9010000		JBE 0x6311b4										
  module.go:36045	0x63100b		458d5501		LEAL 0x1(R13), R10									
  module.go:36046	0x63100f		4c8b6030		MOVQ 0x30(AX), R12									
  module.go:62946	0x631013		4789542108		MOVL R10, 0x8(R9)(R12*1)								
  module.go:36047	0x631018		4c8b6038		MOVQ 0x38(AX), R12									
  module.go:36047	0x63101c		448b6c2438		MOVL 0x38(SP), R13									
  module.go:36047	0x631021		468d2cea		LEAL 0(DX)(R13*8), R13									
  module.go:62954	0x631025		4589ef			MOVL R13, R15										
  module.go:62954	0x631028		4983c707		ADDQ $0x7, R15										
  module.go:62954	0x63102c		4d39fc			CMPQ R12, R15										
  module.go:62954	0x63102f		0f867a010000		JBE 0x6311af										
  module.go:36047	0x631035		4c8b6030		MOVQ 0x30(AX), R12									
  module.go:62955	0x631039		4589ef			MOVL R13, R15										
  module.go:62955	0x63103c		4f8b2427		MOVQ 0(R15)(R12*1), R12									
  unsafe.go:41		0x631040		66490f6ecc		MOVQ R12, X1										
  module.go:36057	0x631045		4189cc			MOVL CX, R12										
  module.go:63129	0x631048		4c8b7c2468		MOVQ 0x68(SP), R15									
  module.go:36047	0x63104d		4589d5			MOVL R10, R13										
  module.go:36049	0x631050		eb03			JMP 0x631055										
  module.go:36049	0x631052		0f57c9			XORPS X1, X1										
  module.go:36051	0x631055		f20f58c1		ADDSD X1, X0										
  module.go:36053	0x631059		85f6			TESTL SI, SI										
  module.go:36053	0x63105b		7423			JE 0x631080										
  module.go:62929	0x63105d		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:35906	0x631064		4589ea			MOVL R13, R10										
  module.go:36054	0x631067		89f1			MOVL SI, CX										
  module.go:36054	0x631069		4189d3			MOVL DX, R11										
  module.go:36097	0x63106c		8b54244c		MOVL 0x4c(SP), DX									
  module.go:62945	0x631070		4c8b6c2470		MOVQ 0x70(SP), R13									
  module.go:36054	0x631075		4489e6			MOVL R12, SI										
  module.go:36054	0x631078		e994fbffff		JMP 0x630c11										
  module.go:36054	0x63107d		0f1f00			NOPL 0(AX)										
  module.go:36057	0x631080		4585e4			TESTL R12, R12										
  module.go:36057	0x631083		740a			JE 0x63108f										
  module.go:36057	0x631085		b901000000		MOVL $0x1, CX										
  module.go:36057	0x63108a		e99a000000		JMP 0x631129										
  module.go:62928	0x63108f		48895c2460		MOVQ BX, 0x60(SP)									
  module.go:36031	0x631094		f20f11442458		MOVSD_XMM X0, 0x58(SP)									
  module.go:36058	0x63109a		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:36058	0x6310a1		e8da37fbff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn88(SB)		
  module.go:36059	0x6310a6		488b842498000000	MOVQ 0x98(SP), AX									
  module.go:36059	0x6310ae		488b4838		MOVQ 0x38(AX), CX									
  module.go:62928	0x6310b2		488b542478		MOVQ 0x78(SP), DX									
  module.go:62928	0x6310b7		660f1f840000000000	NOPW 0(AX)(AX*1)									
  module.go:62928	0x6310c0		4839d1			CMPQ CX, DX										
  module.go:62928	0x6310c3		0f86e1000000		JBE 0x6311aa										
  module.go:36059	0x6310c9		488b7030		MOVQ 0x30(AX), SI									
  module.go:36061	0x6310cd		90			NOPL											
  module.go:62929	0x6310ce		4c8b842480000000	MOVQ 0x80(SP), R8									
  module.go:62929	0x6310d6		458b4c300c		MOVL 0xc(R8)(SI*1), R9									
  module.go:62928	0x6310db		4c8b542470		MOVQ 0x70(SP), R10									
  module.go:62928	0x6310e0		4c39d1			CMPQ CX, R10										
  module.go:62928	0x6310e3		0f86bc000000		JBE 0x6311a5										
  module.go:36060	0x6310e9		41ffc1			INCL R9											
  module.go:36063	0x6310ec		90			NOPL											
  module.go:36065	0x6310ed		90			NOPL											
  module.go:62929	0x6310ee		418b7c3010		MOVL 0x10(R8)(SI*1), DI									
  module.go:63129	0x6310f3		458b5c3004		MOVL 0x4(R8)(SI*1), R11									
  module.go:63129	0x6310f8		4c8b7c2468		MOVQ 0x68(SP), R15									
  module.go:63129	0x6310fd		458b2437		MOVL 0(R15)(SI*1), R12									
  module.go:63129	0x631101		458b6c3008		MOVL 0x8(R8)(SI*1), R13									
  module.go:62945	0x631106		488b5c2460		MOVQ 0x60(SP), BX									
  module.go:36099	0x63110b		448b442448		MOVL 0x48(SP), R8									
  module.go:62972	0x631110		f20f10442458		MOVSD_XMM 0x58(SP), X0									
  module.go:36067	0x631116		4489c9			MOVL R9, CX										
  module.go:36067	0x631119		4489da			MOVL R11, DX										
  module.go:62946	0x63111c		4c8b8c2480000000	MOVQ 0x80(SP), R9									
  module.go:62945	0x631124		4c8b5c2478		MOVQ 0x78(SP), R11									
  module.go:36070	0x631129		488b7038		MOVQ 0x38(AX), SI									
  module.go:62945	0x63112d		4c39de			CMPQ SI, R11										
  module.go:62945	0x631130		766c			JBE 0x63119e										
  module.go:36070	0x631132		488b7030		MOVQ 0x30(AX), SI									
  module.go:62946	0x631136		41894c310c		MOVL CX, 0xc(R9)(SI*1)									
  module.go:36073	0x63113b		418d75ff		LEAL -0x1(R13), SI									
  module.go:36074	0x63113f		478d142c		LEAL 0(R12)(R13*1), R10									
  module.go:36074	0x631143		458d52ff		LEAL -0x1(R10), R10									
  module.go:36080	0x631147		4c8b6838		MOVQ 0x38(AX), R13									
  module.go:36076	0x63114b		4539d4			CMPL R12, R10										
  module.go:36077	0x63114e		410f47f2		CMOVA R10, SI										
  module.go:62945	0x631152		4939dd			CMPQ R13, BX										
  module.go:36076	0x631155		7642			JBE 0x631199										
  module.go:36080	0x631157		4c8b5030		MOVQ 0x30(AX), R10									
  module.go:62946	0x63115b		4389741108		MOVL SI, 0x8(R9)(R10*1)									
  module.go:36081	0x631160		4c8b5038		MOVQ 0x38(AX), R10									
  module.go:36081	0x631164		8d14f2			LEAL 0(DX)(SI*8), DX									
  module.go:62971	0x631167		89d6			MOVL DX, SI										
  module.go:62971	0x631169		4883c607		ADDQ $0x7, SI										
  module.go:62971	0x63116d		4939f2			CMPQ R10, SI										
  module.go:62971	0x631170		7622			JBE 0x631194										
  module.go:36081	0x631172		488b7030		MOVQ 0x30(AX), SI									
  module.go:62972	0x631176		4189d2			MOVL DX, R10										
  module.go:62972	0x631179		f2420f110416		MOVSD_XMM X0, 0(SI)(R10*1)								
  module.go:36097	0x63117f		8b54244c		MOVL 0x4c(SP), DX									
  module.go:62929	0x631183		8b9c24a4000000		MOVL 0xa4(SP), BX									
  module.go:62945	0x63118a		4c8b6c2470		MOVQ 0x70(SP), R13									
  module.go:36082	0x63118f		e9c9faffff		JMP 0x630c5d										
  module.go:62971	0x631194		e827f8e5ff		CALL runtime.panicBounds(SB)								
  module.go:62945	0x631199		e822f8e5ff		CALL runtime.panicBounds(SB)								
  module.go:62945	0x63119e		6690			NOPW											
  module.go:62945	0x6311a0		e81bf8e5ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x6311a5		e816f8e5ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x6311aa		e811f8e5ff		CALL runtime.panicBounds(SB)								
  module.go:62954	0x6311af		e80cf8e5ff		CALL runtime.panicBounds(SB)								
  module.go:62945	0x6311b4		e807f8e5ff		CALL runtime.panicBounds(SB)								
  module.go:62945	0x6311b9		e802f8e5ff		CALL runtime.panicBounds(SB)								
  module.go:62954	0x6311be		6690			NOPW											
  module.go:62954	0x6311c0		e8fbf7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62945	0x6311c5		e8f6f7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62945	0x6311ca		e8f1f7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62954	0x6311cf		e8ecf7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62945	0x6311d4		e8e7f7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62945	0x6311d9		e8e2f7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x6311de		6690			NOPW											
  module.go:62928	0x6311e0		e8dbf7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x6311e5		e8d6f7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x6311ea		e8d1f7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62928	0x6311ef		e8ccf7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62954	0x6311f4		e8c7f7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62954	0x6311f9		e8c2f7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62954	0x6311fe		6690			NOPW											
  module.go:62954	0x631200		e8bbf7e5ff		CALL runtime.panicBounds(SB)								
  module.go:62954	0x631205		90			NOPL											
  module.go:35694	0x631206		4889442408		MOVQ AX, 0x8(SP)									
  module.go:35694	0x63120b		895c2410		MOVL BX, 0x10(SP)									
  module.go:35694	0x63120f		894c2414		MOVL CX, 0x14(SP)									
  module.go:35694	0x631213		f20f11442418		MOVSD_XMM X0, 0x18(SP)									
  module.go:35694	0x631219		e882dae5ff		CALL runtime.morestack_noctxt.abi0(SB)							
  module.go:35694	0x63121e		488b442408		MOVQ 0x8(SP), AX									
  module.go:35694	0x631223		8b5c2410		MOVL 0x10(SP), BX									
  module.go:35694	0x631227		8b4c2414		MOVL 0x14(SP), CX									
  module.go:35694	0x63122b		f20f10442418		MOVSD_XMM 0x18(SP), X0									
  module.go:35694	0x631231		e9eaecffff		JMP dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn176(SB)		
