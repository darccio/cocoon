TEXT dario.cat/cocoon/examples/datadog/go/dd.(*Sketch).Add.func1.1(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/cocoon_gen.go
  cocoon_gen.go:583	0x7de680		493b6610		CMPQ SP, 0x10(R14)										
  cocoon_gen.go:583	0x7de684		7673			JBE 0x7de6f9											
  cocoon_gen.go:583	0x7de686		55			PUSHQ BP											
  cocoon_gen.go:583	0x7de687		4889e5			MOVQ SP, BP											
  cocoon_gen.go:583	0x7de68a		4883ec20		SUBQ $0x20, SP											
  cocoon_gen.go:586	0x7de68e		4889442430		MOVQ AX, 0x30(SP)										
  cocoon_gen.go:583	0x7de693		488b5a10		MOVQ 0x10(DX), BX										
  cocoon_gen.go:583	0x7de697		f20f104218		MOVSD_XMM 0x18(DX), X0										
  cocoon_gen.go:583	0x7de69c		488b4a08		MOVQ 0x8(DX), CX										
  cocoon_gen.go:584	0x7de6a0		488b09			MOVQ 0(CX), CX											
  cocoon_gen.go:584	0x7de6a3		488b01			MOVQ 0(CX), AX											
  cocoon_gen.go:584	0x7de6a6		e8957de7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).Xcocoon_sketch_add(SB)	
  cocoon_gen.go:585	0x7de6ab		488d1d42550f00		LEAQ 0xf5542(IP), BX										
  cocoon_gen.go:585	0x7de6b2		b903000000		MOVL $0x3, CX											
  cocoon_gen.go:585	0x7de6b7		89c7			MOVL AX, DI											
  cocoon_gen.go:585	0x7de6b9		488b442430		MOVQ 0x30(SP), AX										
  cocoon_gen.go:585	0x7de6be		6690			NOPW												
  cocoon_gen.go:585	0x7de6c0		e87b98deff		CALL dario.cat/cocoon/rt.(*Call).ResultView(SB)							
  cocoon_gen.go:586	0x7de6c5		4885ff			TESTQ DI, DI											
  cocoon_gen.go:586	0x7de6c8		7523			JNE 0x7de6ed											
  cocoon_gen.go:589	0x7de6ca		4885db			TESTQ BX, BX											
  cocoon_gen.go:589	0x7de6cd		7414			JE 0x7de6e3											
  cocoon_gen.go:590	0x7de6cf		488b056a214f00		MOVQ dario.cat/cocoon/rt.ErrProtocol(SB), AX							
  cocoon_gen.go:590	0x7de6d6		488b1d6b214f00		MOVQ dario.cat/cocoon/rt.ErrProtocol+8(SB), BX							
  cocoon_gen.go:590	0x7de6dd		4883c420		ADDQ $0x20, SP											
  cocoon_gen.go:590	0x7de6e1		5d			POPQ BP												
  cocoon_gen.go:590	0x7de6e2		c3			RET												
  cocoon_gen.go:592	0x7de6e3		31c0			XORL AX, AX											
  cocoon_gen.go:592	0x7de6e5		31db			XORL BX, BX											
  cocoon_gen.go:592	0x7de6e7		4883c420		ADDQ $0x20, SP											
  cocoon_gen.go:592	0x7de6eb		5d			POPQ BP												
  cocoon_gen.go:592	0x7de6ec		c3			RET												
  cocoon_gen.go:587	0x7de6ed		4889f8			MOVQ DI, AX											
  cocoon_gen.go:587	0x7de6f0		4889f3			MOVQ SI, BX											
  cocoon_gen.go:587	0x7de6f3		4883c420		ADDQ $0x20, SP											
  cocoon_gen.go:587	0x7de6f7		5d			POPQ BP												
  cocoon_gen.go:587	0x7de6f8		c3			RET												
  cocoon_gen.go:583	0x7de6f9		4889442408		MOVQ AX, 0x8(SP)										
  cocoon_gen.go:583	0x7de6fe		6690			NOPW												
  cocoon_gen.go:583	0x7de700		e8fb04cbff		CALL runtime.morestack.abi0(SB)									
  cocoon_gen.go:583	0x7de705		488b442408		MOVQ 0x8(SP), AX										
  cocoon_gen.go:583	0x7de70a		e971ffffff		JMP dario.cat/cocoon/examples/datadog/go/dd.(*Sketch).Add.func1.1(SB)				
