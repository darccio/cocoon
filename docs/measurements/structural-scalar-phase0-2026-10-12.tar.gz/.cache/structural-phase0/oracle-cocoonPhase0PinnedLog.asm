TEXT dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.cocoonPhase0PinnedLog(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/internal/wasm/module.go
  module.go:63218	0x691540		493b6610		CMPQ SP, 0x10(R14)										
  module.go:63218	0x691544		0f868a000000		JBE 0x6915d4											
  module.go:63218	0x69154a		55			PUSHQ BP											
  module.go:63218	0x69154b		4889e5			MOVQ SP, BP											
  module.go:63218	0x69154e		4883ec08		SUBQ $0x8, SP											
  module.go:63219	0x691552		0f57c9			XORPS X1, X1											
  module.go:63219	0x691555		660f2ec1		UCOMISD X1, X0											
  module.go:63219	0x691559		7268			JB 0x6915c3											
  module.go:63219	0x69155b		488b0526f56400		MOVQ dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.cocoonPhase0OracleBytes+8(SB), AX	
  module.go:63219	0x691562		48c1e803		SHRQ $0x3, AX											
  module.go:63219	0x691566		0f57c9			XORPS X1, X1											
  module.go:63219	0x691569		f2480f2ac8		CVTSI2SDQ AX, X1										
  module.go:63219	0x69156e		660f2ec8		UCOMISD X0, X1											
  module.go:63219	0x691572		764f			JBE 0x6915c3											
  module.go:63220	0x691574		f2480f2cc0		CVTTSD2SIQ X0, AX										
  module.go:63221	0x691579		89c1			MOVL AX, CX											
  module.go:63221	0x69157b		0f57c9			XORPS X1, X1											
  module.go:63221	0x69157e		f2480f2ac9		CVTSI2SDQ CX, X1										
  module.go:63221	0x691583		660f2ec8		UCOMISD X0, X1											
  module.go:63221	0x691587		753a			JNE 0x6915c3											
  module.go:63221	0x691589		7a38			JP 0x6915c3											
  module.go:63221	0x69158b		803dc204670000		CMPB dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.cocoonPhase0OracleEnabled(SB), $0x0	
  module.go:63221	0x691592		742f			JE 0x6915c3											
  module.go:63219	0x691594		488b0df5f46400		MOVQ dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.cocoonPhase0OracleBytes+16(SB), CX	
  module.go:63222	0x69159b		89c0			MOVL AX, AX											
  module.go:63222	0x69159d		4889c2			MOVQ AX, DX											
  module.go:63222	0x6915a0		48c1e003		SHLQ $0x3, AX											
  module.go:63223	0x6915a4		4883c008		ADDQ $0x8, AX											
  module.go:63223	0x6915a8		4839c1			CMPQ CX, AX											
  module.go:63223	0x6915ab		7221			JB 0x6915ce											
  module.go:63219	0x6915ad		488b05ccf46400		MOVQ dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.cocoonPhase0OracleBytes(SB), AX	
  binary.go:117		0x6915b4		488b04d0		MOVQ 0(AX)(DX*8), AX										
  unsafe.go:41		0x6915b8		66480f6ec0		MOVQ AX, X0											
  module.go:63223	0x6915bd		4883c408		ADDQ $0x8, SP											
  module.go:63223	0x6915c1		5d			POPQ BP												
  module.go:63223	0x6915c2		c3			RET												
  module.go:63226	0x6915c3		e898fdffff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.cocoonPhase0OriginalLog(SB)		
  module.go:63226	0x6915c8		4883c408		ADDQ $0x8, SP											
  module.go:63226	0x6915cc		5d			POPQ BP												
  module.go:63226	0x6915cd		c3			RET												
  module.go:63223	0x6915ce		e8edf3dfff		CALL runtime.panicBounds(SB)									
  module.go:63223	0x6915d3		90			NOPL												
  module.go:63218	0x6915d4		f20f11442408		MOVSD_XMM X0, 0x8(SP)										
  module.go:63218	0x6915da		e8c1d6dfff		CALL runtime.morestack_noctxt.abi0(SB)								
  module.go:63218	0x6915df		f20f10442408		MOVSD_XMM 0x8(SP), X0										
  module.go:63218	0x6915e5		e956ffffff		JMP dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.cocoonPhase0PinnedLog(SB)		
