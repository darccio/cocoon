# Structural phase-0 host entry

2026-10-12, read-only source/archive/local-harness audit. No build, test, profile
or timing executed. This ignored note is the only write. Stop tools after the
note; parent owns any authorized subsequent isolated measurements and design.

## Remaining host work and feasibility

Current scalar Add still performs one library admission, ownership cell locking/
closed-alive-epoch checks/KeepAlive, checked execution mutex/state/recovery/host
panic clearing/FULL Call reset, actual guest export, canonical descriptor and
payload/type validation, and separate CURRENT post-call Memory/MaxMemory check
with immediate poison. No Reserve, input encoding or pool recycle is paid by
scalar Add. These are not accidental duplicated checks: ownership serializes
alias Close and cleanup, execution serializes different resources sharing a home,
admission is what draining library Close waits on, and post-memory enforces a
property reply validation cannot supply. Standalone admission cannot be hoisted
out of an application loop without changing the opportunity for shutdown or
call-level contract. Existing Batch is the opt-in contract for admitted sequences.

The last same-binary scope observations are supported scalar88.02 ns and rawGuest
53.64 ns; their approximately34 ns gap is only a rough cumulative attainable
ceiling. They calibrate different increasing-input/state prefixes and rawGuest
omits supported work. The absolute55.44 ns target leaves very little room above
that raw scope, while fresh reference110%=61.358 ns leaves roughly8 ns. Neither
comparison proves an irreducible floor, but it shows why expecting tens of ns
from one range branch or a cosmetic callback rewrite is implausible. Historical
empty checked Call~15.8 ns and admission~7.3 ns are separate old observations,
not additive costs to combine with current guest timing.

Latest matching ordinary scalar profile: export56.08% cumulative, fn17631.75%
flat/40.83% cumulative, ResultView8.92% cumulative, fn844.17% cumulative. These
overlap and include mandatory algorithm/check work. The log polynomial already
executes in floating-point registers; deleting whole guest work, rounding casts,
bounds/traps or ownership is not an attainable checked optimization. ResultView
must obtain Memory once per reply, descriptor8B/LE/MaxOutput/payload logical range
(including size0)/status validation in order; independent post-memory read stays.
Epoch, healthy expected errors, owned error text, context cancellation, partial
Batch completion, old-home nonmigration and drain semantics remain mandatory.

## Why another hand-shaped host rewrite is not justified

- R1/R2 optional-lock/reply wrappers and extra reset accounting stores regressed
  scalar; R3 added checked frame, R4 deferred recovery method, R5-R7 state/reset/
  recovery refinements and R11 moving an identical checked body to a new source
  file all failed scalar/holdout guards. Original Call/ResultView source placement
  with one authored generated checked policy was ultimately retained.
- Earlier fusion of Resource execution retained locks/checks but showed no
  intended scalar gain and was removed, including its proposed APIs. Deferring
  fewer exits, specialized mutable slab lookup and owned reply publication had
  no broad retained win or lost SQL/batch/trace. They are not fresh structural
  evidence merely because a profile still contains those functions.
- Recent checked ResultUnit specialization improved unsupported unit-only
  validation about18.8%(~1.6 ns) but original scalar failed and SQL varied/holdout
  repeatedly lost2–3%. Two covered store32 guards lost their preregistered original
  screening comparator; three adjacent read64/store64 guards had only tiny raw
  gains. None justifies dropping more checks or chasing source layout.
- Exact-value cache had large miss-heavy losses; ordered/bit predicates and
  floor/saturation rewrites failed broad guards. Batch benefits alone do not
  solve standalone scalar. Per-resource-instance sharding/sessions are qualified
  throughput tools, with default/small-chunk costs explicitly preserved.

Current profile could motivate compiler devirtualization/inlining measurement,
but not a new generic/public runtime or removal/fusion of cell and instance
mutexes. The independent reference is NOT an ABI3 host-cost floor: its scalar
Add invokes guest and FromStatus with a fixed synthetic error string; it omits
canonical descriptor/unit validation, per-call memory cap, full Call state,
library terminal admission/drain and the modern shared ownership/epoch model.
Its direct scalar Count/new returns also differ. Restoring that path would be
a contract regression, not an optimization. Any new typed-return/public proposal
requires specification/compatibility review and explicit operator approval.

## Local consuming application search

No representative consuming application or real application CPU/PGO profile was
identified. Read-only search of local Code Go files/modfiles finds only Cocoon,
its independent spike and cocoon-wasm-review test overlays importing these
modules. The requested original /home/bits/inject-bench and dd-trace demo checkout
paths are absent, as are /home/dario/Code/inject-bench and dd-trace-go. Cached
dd-trace-go versions2.9.1/2.9.2/2.10.1 exist but have no Cocoon/injection embedding
match; their arbitrary tracer tests are not a representative Cocoon application.
Nothing in those repositories/modules is edited.

Available local harnesses: public examples/datadog scalar/SQL/batch/trace and
held-out corpora, synthetic full-lifetime streaming, authored installed external
consumer in internal/smoke/workflow_test.go, and an old external review's EPYC
ABI2 isolated benchmark log. The smoke consumer is correctness-only; archived
equal-time four-class PGO training is SYNTHETIC, not production traffic. Older
EPYC numbers cannot qualify current Ryzen code or ABI3. A constructed consuming
main can measure integration/compiler effects, but must be labelled synthetic
until actual operator workload/profile is available.

## Structural compiler pipeline comparison

| Layer | Cocoon | Independent reference |
| --- | --- | --- |
| Rust |1.97, locked, std/panic_abort, release opt3, LTOtrue, codegen-units1, explicit panicabort, stripsymbols |1.97, locked, std/panic_abort, release opt3, LTOtrue, codegen-units1, debugfalse/stripsymbols; profile does not explicitly set panic |
| Rust flags/identity |MaxMemory linker cap, canonical path remapping and crate metadata wrapper/seed |Same256MiB cap for DD; own source/metadata paths, no Cocoon metadata wrapper |
| Wasm |Binaryen133 metaDCE thenO3, explicitMVP+verified features/export set |Binaryen133 metaDCE thenO3 with own export roots/feature list |
| Translation |wasm2go0.4.16 unsafe, default AST optimization, private authored hardening |Same0.4.16 unsafe/default AST optimization, OWN older hardener |
| Go qualification |Exact official1.26.8, CGO0, GOAMD64v1, PGOoff |Same official1.26.8/CGO0/v1/off, independently rebuilt |

There is no obvious missing O3/LTO flag to explain the target gap. Rust path/
metadata differences can change symbol ordering/layout and error strings; they
are not themselves useful optimizations to remove. Reference ABI/shim/guest
ownership and payload shape differences dominate attribution limits. Building
std/panic_abort is recorded for both; it does not alone prove every reference
crate's panic profile matches Cocoon's explicit abort setting. Retain actual
compiler flags/artifacts rather than infer equivalence from a profile name.

Earlier BinaryenO4, O3-no-StackIR and O3-converge were measured/rejected. Do not
relabel them as a new large compiler opportunity without new machine evidence.
Pinned translator0.4.16 exposes -noopt (AST optimizations), -nohost and -nanbox.
NoHost addresses import interfaces, absent from normal hot scalar execution;
NanBox changes numeric/architecture behavior and is not a performance candidate.
Unsafe is already enabled with checks; disabling checks is prohibited. Default
GOAMD64v1 preserves portability; any optional native deployment-v3 comparison
must retain portable fallback and own matching reference, not change the default
CPU contract or mix profiles/toolchains. No default PGO profile is installed.

## Concrete next measurements, before design

1. For a larger translation-shape ceiling, predeclare ONE coarse compiler-policy
   experiment instead of editing two more instructions: same committed final
   Wasm/default hardener, pinned wasm2go default AST pipeline versus -noopt.
   That can change function/control-flow/temporary lifetime and Go allocation/
   inlining/register shape across the full guest while leaving ABI3 checked host
   source untouched. It is a hypothesis, not a promised improvement. Inspect
   ordinary hot machine code and counters/frames/text first; if no credible shape
   change or broad end-to-end ceiling appears, retain a negative and stop it.
   A separate Rust opt2 or size-oriented compilation screen (same LTO/unit/panic/
   Binaryen policy) is another possible coupling experiment, not something to
   combine into the same first comparison or add to old gains. New optimizer
   outputs require original-Wasm/native independent numeric/trap/evaluation
   oracles, not only Go versus the candidate's same Wasm.
2. For the safest host compiler ceiling, use actual consuming-main profile PGO
   if an operator workload becomes available. Prior SYNTHETIC own-profile PGO
   repeated~5% scalar gains but lost batches1.26% and remained opt-in; it does
   not establish the needed~30% current fresh-target reduction. If no real
   application is available, an ignored explicit-main harness may exercise
   unchanged generated facade with bounded New/Add/Count/Encode/Close lifetimes,
   SQL/trace operations and realistic-specified input/call distribution, but
   label its mix synthetic and hold out other mixes/corpora. Profile each role
   with PGOoff, train its own profile, compare off/on separately, inspect actual
   devirtualized interface/callback targets and never reuse a different role's
   profile as training. No global/default library PGO policy follows.
3. Existing AddMany/sharding/bounded Batch have much larger attained throughput
   ceilings than these scalar microcuts. Measure them in a real consuming
   workload before proposing new interfaces or rebatching scalar calls. Rebatching
   changes timing/invalid-tail/partial-completion semantics and cannot be done
   invisibly. A throughput result remains distinct from standalone scalar M1.

All experiments need source/argv/tool hashes, clean frozen ordinary binaries,
original default scalar primary and both appropriate controls, negative/increasing/
broad scalar, SQL original/varied/holdout, batch/repeated/broad and trace, actual
P1 default and P16 one/sixteen-home full streaming fixed/holdout (and Batch/mixed
guards for a production change). Record allocation/current-memory/growth,
complete owned outputs, all negative directions, fresh own-reference/M1 limits,
code/metadata size and static-vs-dynamic attribution limits. No compilation,
profiles, tests/lint or reviewer work overlaps paired alternating/reversed
measurement. No source-layout tuning/selected retiming after failure. A credible
larger measured ceiling must precede private generic specification/implementation.

Historical provenance erratum: the scalar-next first tool probe was previously
described as an unsupported -version flag. Pinned wasm2go0.4.16 DOES support it;
the preserved raw stderr shows read-only inherited globalGOCACHE, just like the
second -n probe. Build/source/sample outcomes are unchanged. Old archives/records
are preserved; use that raw cache-failure reason in new descriptions.
