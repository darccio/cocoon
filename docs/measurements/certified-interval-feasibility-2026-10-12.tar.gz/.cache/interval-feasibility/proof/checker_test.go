package intervalproof

import (
	"errors"
	"math"
	"math/big"
	"os"
	"strings"
	"sync/atomic"
	"testing"
)

// One cumulative ledger per native test process, never reset between tests.
// Count literal constructor/checker/native-kernel whole-graph evaluations.
// Primitive arithmetic tests and source binding are not whole-graph checks.
var checkerDriverWhole atomic.Uint32

const checkerDriverWholeCap = 9000

func checkerCount(t *testing.T, n uint32) {
	t.Helper()
	if count := checkerDriverWhole.Add(n); count > checkerDriverWholeCap {
		t.Fatalf("checker cumulative whole-driver budget exceeded: %d", count)
	}
}
func checkerLogCount(t *testing.T) {
	t.Helper()
	t.Logf("checker-cumulative-whole-evaluations=%d checker-driver-cap=%d tiny-members=0 wasm-requests=0", checkerDriverWhole.Load(), checkerDriverWholeCap)
}
func testCheckerGraph(t *testing.T) *Graph {
	t.Helper()
	g := engineGraph(t)
	if e := VerifyGraph(g); e != nil {
		t.Fatal(e)
	}
	return g
}
func checkerPower(exponent int) *big.Rat {
	if exponent >= 0 {
		return new(big.Rat).SetInt(new(big.Int).Lsh(big.NewInt(1), uint(exponent)))
	}
	return new(big.Rat).SetFrac(big.NewInt(1), new(big.Int).Lsh(big.NewInt(1), uint(-exponent)))
}
func checkerAdd(a, b *big.Rat) *big.Rat     { return new(big.Rat).Add(a, b) }
func testCheckerBounds(a, b float64) Bounds { return Bounds{math.Float64bits(a), math.Float64bits(b)} }

func TestCheckerNearestEvenPrimitive(t *testing.T) {
	one := big.NewRat(1, 1)
	maxFinite, _ := checkerDecode(0x7fefffffffffffff)
	cases := []struct {
		name         string
		r            *big.Rat
		negativeZero bool
		want         uint64
	}{
		{"one", one, false, 0x3ff0000000000000},
		{"even-lower-tie", checkerAdd(one, checkerPower(-53)), false, 0x3ff0000000000000},
		{"odd-lower-tie", checkerAdd(one, new(big.Rat).Mul(big.NewRat(3, 1), checkerPower(-53))), false, 0x3ff0000000000002},
		{"negative-tie", new(big.Rat).Neg(checkerAdd(one, checkerPower(-53))), false, 0xbff0000000000000},
		{"zero", big.NewRat(0, 1), false, 0}, {"negative-zero", big.NewRat(0, 1), true, 1 << 63},
		{"subnormal-half", checkerPower(-1075), false, 0},
		{"subnormal-half-plus", checkerAdd(checkerPower(-1075), checkerPower(-1200)), false, 1},
		{"subnormal-even-tie", new(big.Rat).Mul(big.NewRat(3, 1), checkerPower(-1075)), false, 2},
		{"negative-underflow", new(big.Rat).Neg(checkerPower(-1075)), false, 1 << 63},
		{"normal-seam-tie", new(big.Rat).Sub(checkerPower(-1022), checkerPower(-1075)), false, 0x0010000000000000},
		{"maxfinite", maxFinite, false, 0x7fefffffffffffff},
		{"overflow-tie", checkerAdd(maxFinite, checkerPower(970)), false, 0x7ff0000000000000},
		{"large-underflow", checkerPower(-2000), false, 0},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			got, w, e := checkerNearest(c.r, c.negativeZero)
			if e != nil || got != c.want {
				t.Fatalf("nearest=%016x want=%016x work=%+v error=%v", got, c.want, w, e)
			}
			if w.shifts > 4 || w.comparisons > 8 || w.quotients > 1 || w.maxBits > 4096 {
				t.Fatalf("rounder ledger %+v", w)
			}
		})
	}
	oversized := new(big.Rat).SetInt(new(big.Int).Lsh(big.NewInt(1), 4096))
	if _, w, e := checkerNearest(oversized, false); !errors.Is(e, ErrVerification) || w.shifts != 0 || w.quotients != 0 {
		t.Fatalf("oversized before copies/operations: work=%+v err=%v", w, e)
	}
}

func TestCheckerDirectedContainmentAndInwardCounterexample(t *testing.T) {
	// This exact real lies above the midpoint: inward [1,1] excludes it and
	// its correctly rounded primitive. No big.Float or constructor rounder.
	real := checkerAdd(checkerAdd(big.NewRat(1, 1), checkerPower(-53)), checkerPower(-110))
	var work Work
	got, e := checkerDirectedWork(real, &work)
	want := Bounds{0x3ff0000000000000, 0x3ff0000000000001}
	if e != nil || got != want {
		t.Fatalf("directed got=%+v want=%+v error=%v", got, want, e)
	}
	nearest, _, e := checkerNearest(real, false)
	if e != nil || nearest != want.Hi {
		t.Fatalf("counterexample nearest %016x %v", nearest, e)
	}
	badUpper, _ := checkerDecode(want.Lo)
	if cmp, _ := checkerRatCompare(real, badUpper); cmp <= 0 {
		t.Fatal("inward mutant counterexample vacuous")
	}
	if work.Conversions != 1 || work.QuoRem != 1 || work.Shifts > 4 || work.Comparisons > 8 {
		t.Fatalf("independent conversion ledger %+v", work)
	}
	for _, r := range []*big.Rat{new(big.Rat).Neg(real), checkerPower(-1075), new(big.Rat).Neg(checkerPower(-1075)), big.NewRat(0, 1)} {
		bounds, e := checkerDirected(r)
		if e != nil {
			t.Fatal(e)
		}
		lo, _ := checkerDecode(bounds.Lo)
		hi, _ := checkerDecode(bounds.Hi)
		if cmp, _ := checkerRatCompare(lo, r); cmp > 0 {
			t.Fatal("lower bound inward")
		}
		if cmp, _ := checkerRatCompare(hi, r); cmp < 0 {
			t.Fatal("upper bound inward")
		}
	}
	if _, e := checkerDirected(checkerPower(1024)); !errors.Is(e, ErrVerification) {
		t.Fatalf("nonfinite outward endpoint accepted: %v", e)
	}
}

func TestCheckerAllSignedCornersAndStrictBin(t *testing.T) {
	cases := []struct {
		op         Op
		a, b, want Bounds
	}{
		{OpMul, testCheckerBounds(-3, -1), testCheckerBounds(-2, 4), testCheckerBounds(-12, 6)},
		{OpSub, testCheckerBounds(-1, 2), testCheckerBounds(3, 4), testCheckerBounds(-5, -1)},
		{OpDiv, testCheckerBounds(-3, 1), testCheckerBounds(-4, -2), testCheckerBounds(-.5, 1.5)},
		{OpDiv, testCheckerBounds(-3, 1), testCheckerBounds(2, 4), testCheckerBounds(-1.5, .5)},
		{OpMul, testCheckerBounds(-2, 3), testCheckerBounds(-2, 3), testCheckerBounds(-6, 9)},
	}
	for _, c := range cases {
		var w Work
		got, e := checkerTransferWork(c.op, c.a, c.b, &w)
		if e != nil || got != c.want {
			t.Fatalf("corners op=%d got=%+v want=%+v err=%v", c.op, got, c.want, e)
		}
		if w.EndpointOps != 4 || w.Conversions != 2 || w.QuoRem > 2 || w.Shifts > 8 || w.MaxIntegerBits > 4096 {
			t.Fatalf("corner ledger=%+v", w)
		}
	}
	if _, e := checkerTransfer(OpDiv, testCheckerBounds(1, 2), testCheckerBounds(-1, 1)); !errors.Is(e, ErrVerification) {
		t.Fatal("division through zero accepted")
	}
	negative := testCheckerBounds(-.75, -.25)
	if e := checkerBin(negative, -1); e != nil {
		t.Fatal(e)
	}
	if e := checkerBin(negative, 0); !errors.Is(e, ErrVerification) {
		t.Fatal("truncation instead of negative floor accepted")
	}
	if bin, e := checkerFloor(math.Float64bits(-.25)); e != nil || bin != -1 {
		t.Fatalf("negative floor %d %v", bin, e)
	}
	if e := checkerBin(testCheckerBounds(-.75, 0), -1); !errors.Is(e, ErrVerification) {
		t.Fatal("non-strict upper boundary accepted")
	}
	if e := checkerBin(testCheckerBounds(2, 3), 2); !errors.Is(e, ErrVerification) {
		t.Fatal("positive integer upper boundary accepted")
	}
	// Choosing only same-sign products would yield [2,6], excluding -3*4=-12.
	if c, _ := checkerRatCompare(big.NewRat(-12, 1), big.NewRat(2, 1)); c >= 0 {
		t.Fatal("signed-corner counterexample vacuous")
	}
}

func TestCheckerSourceBindingMutants(t *testing.T) {
	g := testCheckerGraph(t)
	mutants := []struct {
		name string
		edit func(*Graph)
	}{
		{"sha", func(g *Graph) { g.SourceSHA[0] ^= 1 }}, {"gamma", func(g *Graph) { g.Params[0]++ }}, {"multiplier", func(g *Graph) { g.Params[1]++ }}, {"threshold", func(g *Graph) { g.Params[2]++ }}, {"offset", func(g *Graph) { g.Params[3]++ }},
		{"raw-constant", func(g *Graph) {
			g.RawSnippet = strings.Replace(g.RawSnippet, "0.15313837699209373", "0.15313837699209374", 1)
		}},
		{"log-branch", func(g *Graph) {
			g.LogSource = strings.Replace(g.LogSource, "v20 != i64(0x3ff00000)", "v20 == i64(0x3ff00000)", 1)
		}},
		{"saturation", func(g *Graph) { g.SaturationSource = strings.Replace(g.SaturationSource, "f != f", "f == f", 1) }},
		{"node-literal", func(g *Graph) { g.Nodes[2].Bits++ }}, {"node-operation", func(g *Graph) { g.Nodes[3].Op = OpDiv }}, {"node-operand", func(g *Graph) { g.Nodes[3].A = 2 }}, {"cycle", func(g *Graph) { g.Nodes[3].A = 3 }},
		{"rounded-count", func(g *Graph) { g.Rounded-- }}, {"node-count", func(g *Graph) { g.Count-- }}, {"output", func(g *Graph) { g.Output = g.LogOutput }}, {"unused-ghost-node", func(g *Graph) { g.Nodes[255] = Node{Op: OpConst, Bits: 1} }},
	}
	for _, m := range mutants {
		t.Run(m.name, func(t *testing.T) {
			copy := *g
			m.edit(&copy)
			if e := VerifyGraph(&copy); !errors.Is(e, ErrVerification) {
				t.Fatalf("mutant source/node binding accepted: %v", e)
			}
		})
	}
}

func TestCheckerCompleteTraceAndMutants(t *testing.T) {
	defer checkerLogCount(t)
	g := testCheckerGraph(t)
	bits := math.Float64bits(42)
	checkerCount(t, 1)
	cert, trace, _, e := Certify(g, g.Params, bits-(1<<40), bits+(1<<40), DefaultBudget)
	if e != nil {
		t.Fatal(e)
	}
	checkerCount(t, 1)
	work, e := VerifyWork(g, g.Params, cert, &trace)
	if e != nil {
		t.Fatal(e)
	}
	if work.Nodes != uint32(g.Count) || work.Rounded != uint32(g.Rounded) || work.EndpointOps != 4*work.Rounded || work.Conversions != 2*work.Rounded || work.QuoRem > work.Conversions || work.Shifts > 4*work.Conversions || work.MaxIntegerBits > 4096 {
		t.Fatalf("independent full trace ledger %+v", work)
	}
	t.Logf("checker-work=%+v", work)
	arithmetic := uint16(0)
	for i := uint16(0); i < g.Count; i++ {
		if g.Nodes[i].Op >= OpAdd && g.Nodes[i].Op <= OpDiv && trace.Slots[i].Lo != trace.Slots[i].Hi {
			arithmetic = i
			break
		}
	}
	if arithmetic == 0 {
		t.Fatal("no nontrivial arithmetic slot for inward mutation")
	}
	tests := []struct {
		name   string
		change func(*Certificate, *Trace)
	}{
		{"carry", func(_ *Certificate, tr *Trace) { tr.Carry ^= 1 }}, {"exponent", func(_ *Certificate, tr *Trace) { tr.Exponent++ }}, {"missing-node", func(_ *Certificate, tr *Trace) { tr.Count-- }}, {"unused-slot", func(_ *Certificate, tr *Trace) { tr.Slots[255] = Bounds{1, 1} }}, {"input-identity", func(_ *Certificate, tr *Trace) { tr.Lo++ }}, {"parameter-identity", func(_ *Certificate, tr *Trace) { tr.Params[0]++ }}, {"source-identity", func(_ *Certificate, tr *Trace) { tr.SourceSHA[0] ^= 1 }},
		{"lower-inward", func(_ *Certificate, tr *Trace) {
			tr.Slots[arithmetic].Lo = checkerAdjacent(tr.Slots[arithmetic].Lo, true)
		}}, {"upper-inward", func(_ *Certificate, tr *Trace) {
			tr.Slots[arithmetic].Hi = checkerAdjacent(tr.Slots[arithmetic].Hi, false)
		}}, {"wrong-bin", func(c *Certificate, _ *Trace) { c.Bin++ }}, {"signed-corner", func(_ *Certificate, tr *Trace) { tr.Slots[arithmetic] = Bounds{0, 0} }}, {"strict-upper", func(c *Certificate, tr *Trace) { tr.Slots[g.Output].Hi = math.Float64bits(float64(c.Bin) + 1) }},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			c, tr := cert, trace
			test.change(&c, &tr)
			checkerCount(t, 1)
			if _, e := VerifyWork(g, g.Params, c, &tr); !errors.Is(e, ErrVerification) {
				t.Fatalf("trace mutant accepted: %v", e)
			}
		})
	}
	budget := DefaultBudget
	budget.Rounded = 0
	checkerCount(t, 1)
	c, tr, _, e := Certify(g, g.Params, bits, bits+1, budget)
	if !errors.Is(e, ErrUnknown) || ReasonOf(e) != ReasonBudget {
		t.Fatalf("budget rejection %v", e)
	}
	checkerCount(t, 1)
	if e := Verify(g, g.Params, c, &tr); !errors.Is(e, ErrVerification) {
		t.Fatal("exhausted-budget partial trace promoted")
	}
}

func TestCheckerEveryAcceptedBankTrace(t *testing.T) {
	defer checkerLogCount(t)
	g := testCheckerGraph(t)
	var total Work
	verified := 0
	bank, report, e := BuildBank(g, DefaultBudget, func(a Attempt, tr *Trace) error {
		if a.Reason != ReasonNone {
			return nil
		}
		checkerCount(t, 1)
		w, e := VerifyWork(g, g.Params, Certificate{a.Lo, a.Hi, a.Bin}, tr)
		if e != nil {
			return e
		}
		verified++
		total.Nodes += w.Nodes
		total.Rounded += w.Rounded
		total.EndpointOps += w.EndpointOps
		total.Conversions += w.Conversions
		total.Shifts += w.Shifts
		total.Comparisons += w.Comparisons
		total.QuoRem += w.QuoRem
		total.MaxIntegerBits = max(total.MaxIntegerBits, w.MaxIntegerBits)
		total.WorkspaceBytes = max(total.WorkspaceBytes, w.WorkspaceBytes)
		return nil
	})
	checkerCount(t, uint32(report.Count))
	if e != nil {
		t.Fatal(e)
	}
	var cells [2048]bool
	cellCount := 0
	positive, negative, nearby := false, false, false
	for i := uint16(0); i < bank.Count; i++ {
		c := bank.Certificates[i]
		if c.Lo == c.Hi {
			t.Fatal("singleton accepted")
		}
		exponent := c.Lo >> 52
		if !cells[exponent] {
			cells[exponent] = true
			cellCount++
		}
		positive = positive || c.Bin > 0
		negative = negative || c.Bin < 0
		nearby = nearby || (c.Lo <= math.Float64bits(42) && c.Hi >= math.Float64bits(42)+8191)
	}
	if verified != int(bank.Count) || bank.Count < 16 || cellCount < 4 || !positive || !negative || !nearby {
		t.Fatalf("nonvacuity verified=%d accepted=%d cells=%d signs=%v/%v nearby8192=%v", verified, bank.Count, cellCount, positive, negative, nearby)
	}
	t.Logf("independent-bank-verified=%d builder-attempts=%d original-exponents=%d positive=%v negative=%v nearby8192=%v independent-work=%+v", verified, report.Count, cellCount, positive, negative, nearby, total)
}

func TestCheckerEveryNormalExponentCarryAndCompiledOriginal(t *testing.T) {
	defer checkerLogCount(t)
	g := testCheckerGraph(t)
	check := func(bits uint64) {
		t.Helper()
		checkerCount(t, 1)
		bin, tr, e := CheckerPointTrace(g, g.Params, bits)
		if e != nil {
			t.Fatalf("accepted-domain point %016x: %v", bits, e)
		}
		checkerCount(t, 1)
		originalLog := OriginalLog(math.Float64frombits(bits))
		if got := math.Float64bits(originalLog); got != tr.Slots[g.LogOutput].Lo {
			t.Fatalf("independent point vs full-source log bits=%016x checker=%016x original=%016x", bits, tr.Slots[g.LogOutput].Lo, got)
		}
		// Reuse exactly this full-source log result, no second kernel call or
		// graph-derived OriginalPointTrace witness.
		originalBin := i32_trunc_sat_f64_s(math.Floor(float64(float64(math.Float64frombits(0x40501fead4ea6e2b)*originalLog) + math.Float64frombits(0x4094ea0000000000))))
		if originalBin != bin {
			t.Fatalf("independent bin bits=%016x checker=%d original=%d", bits, bin, originalBin)
		}
	}
	for exponent := uint64(1); exponent <= 2046; exponent++ {
		for _, fraction := range []uint64{0x2000000000000, 0xe000000000000} {
			check(exponent<<52 | fraction)
		}
	}
	var points []uint64
	for _, exponent := range []uint64{1, 1022, 1023, 1024, 2046} {
		seam := exponent<<52 | 0x6a09e00000000
		points = append(points, seam-1, seam, seam+1, seam+0xffffffff)
	}
	points = append(points, g.Params[2], g.Params[2]+1, 0x3ff0000000000000-1, 0x3ff0000000000000+1, 0x7feffffffffffffe, 0x7fefffffffffffff, math.Float64bits(42)-1, math.Float64bits(42), math.Float64bits(42)+8191)
	for _, bits := range points {
		check(bits)
	}
	t.Logf("every-original-normal-exponent=2046 carry-sides=2 primary-inputs=4092 targeted-inputs=%d literal-kernel-evaluations=%d", len(points), 2*(4092+len(points)))
}

// Executable semantic mutants are deliberately selected outside healthy runs.
// Each computes a concrete wrong numerical result and MUST fail an assertion.
// A compiler error, signal or startup failure is not a successful mutant proof.
func TestCheckerExecutableNumericalMutant(t *testing.T) {
	kind := os.Getenv("COCOON_INTERVAL_MUTANT")
	if kind == "" {
		t.Skip("select explicit numerical mutant through COCOON_INTERVAL_MUTANT")
	}
	switch kind {
	case "inward-bounds":
		real := checkerAdd(checkerAdd(big.NewRat(1, 1), checkerPower(-53)), checkerPower(-110))
		rounded, _, e := checkerNearest(real, false)
		if e != nil {
			t.Fatal(e)
		}
		broken := Bounds{math.Float64bits(1), math.Float64bits(1)}
		if math.Float64frombits(rounded) > math.Float64frombits(broken.Hi) {
			t.Fatalf("NUMERICAL_MUTANT inward-bounds real=%s correctly-rounded=%016x broken-upper=%016x", real.RatString(), rounded, broken.Hi)
		}
	case "signed-extrema":
		broken := testCheckerBounds(2, 6) // only same-sign endpoints of [-3,-1]*[-2,4]
		actual := float64(-3) * float64(4)
		if actual < math.Float64frombits(broken.Lo) {
			t.Fatalf("NUMERICAL_MUTANT signed-extrema concrete=%g broken=[%g,%g]", actual, math.Float64frombits(broken.Lo), math.Float64frombits(broken.Hi))
		}
	case "strict-upper":
		brokenBin := int32(2)
		actual := int32(math.Floor(3))
		// Broken <= comparison admits the integer upper endpoint of [2,3].
		if float64(actual) <= float64(brokenBin)+1 && actual != brokenBin {
			t.Fatalf("NUMERICAL_MUTANT strict-upper concrete-bin=%d admitted-certificate-bin=%d", actual, brokenBin)
		}
	case "negative-floor":
		actual := float64(-.25)
		broken := int32(actual)
		correct := int32(math.Floor(actual))
		if broken != correct {
			t.Fatalf("NUMERICAL_MUTANT negative-floor input=%g truncation=%d floor=%d", actual, broken, correct)
		}
	case "carry-wrap", "source-literal":
		g := testCheckerGraph(t)
		bits := uint64(1023)<<52 | 0x6a09e00000000
		if kind == "source-literal" {
			bits = math.Float64bits(42)
			g.Nodes[2].Bits = math.Float64bits(0)
		}
		checkerCount(t, 1)
		brokenLog := checkerBrokenPointLog(t, g, bits, kind == "carry-wrap")
		checkerCount(t, 1)
		correct := OriginalLog(math.Float64frombits(bits))
		if math.Float64bits(brokenLog) != math.Float64bits(correct) {
			t.Fatalf("NUMERICAL_MUTANT %s input=%016x broken-log=%016x original-log=%016x", kind, bits, math.Float64bits(brokenLog), math.Float64bits(correct))
		}
	case "wrong-bin":
		checkerCount(t, 1)
		correct := OriginalBin(42)
		broken := correct + 1
		if broken != correct {
			t.Fatalf("NUMERICAL_MUTANT wrong-bin value=42 broken-bin=%d original-bin=%d", broken, correct)
		}
	case "wrong-config":
		checkerCount(t, 1)
		log := OriginalLog(42)
		correct := i32_trunc_sat_f64_s(math.Floor(float64(float64(math.Float64frombits(0x40501fead4ea6e2b)*log) + math.Float64frombits(0x4094ea0000000000))))
		broken := i32_trunc_sat_f64_s(math.Floor(float64(float64(2*math.Float64frombits(0x40501fead4ea6e2b)*log) + math.Float64frombits(0x4094ea0000000000))))
		if broken != correct {
			t.Fatalf("NUMERICAL_MUTANT wrong-config value=42 broken-bin=%d exact-config-bin=%d", broken, correct)
		}
	case "budget-unknown":
		g := testCheckerGraph(t)
		budget := DefaultBudget
		budget.Rounded = 0
		bits := math.Float64bits(42)
		checkerCount(t, 1)
		_, _, _, e := Certify(g, g.Params, bits, bits+1, budget)
		if !errors.Is(e, ErrUnknown) || ReasonOf(e) != ReasonBudget {
			t.Fatalf("healthy setup expected budget uncertainty: %v", e)
		}
		checkerCount(t, 1)
		log := OriginalLog(42)
		correct := i32_trunc_sat_f64_s(math.Floor(float64(float64(math.Float64frombits(0x40501fead4ea6e2b)*log) + math.Float64frombits(0x4094ea0000000000))))
		broken := int32(0) // incorrectly promote the uncomputed zero-value result
		if broken != correct {
			t.Fatalf("NUMERICAL_MUTANT budget-unknown broken-bin=%d concrete-bin=%d error=%v", broken, correct, e)
		}
	default:
		t.Fatalf("unsupported mutant %q", kind)
	}
	t.Fatalf("mutant %s did not expose its required numerical counterexample", kind)
}

// Test-only broken interpreter: source-literal skips the binding rejection;
// carry-wrap subtracts one exponent contribution at the exact carry seam.
// Its actual arithmetic is independently NE-rounded, so the selected failure
// is the broken premise rather than a compiler/trap failure.
func checkerBrokenPointLog(t *testing.T, g *Graph, bits uint64, omitCarry bool) float64 {
	t.Helper()
	reduced, k, _, e := checkerCell(checkerParameters(), bits, bits)
	if e != nil {
		t.Fatal(e)
	}
	if omitCarry {
		k--
	}
	var slots [256]uint64
	for i := uint16(0); i < g.Count; i++ {
		n := g.Nodes[i]
		switch n.Op {
		case OpReduced:
			slots[i] = reduced.Lo
		case OpExponent:
			slots[i] = math.Float64bits(float64(k))
		case OpConst:
			slots[i] = n.Bits
		case OpCopy:
			slots[i] = slots[n.A]
		case OpNeg:
			slots[i] = slots[n.A] ^ 1<<63
		case OpAdd, OpSub, OpMul, OpDiv:
			a, b := slots[n.A], slots[n.B]
			ar, e := checkerDecode(a)
			if e != nil {
				t.Fatal(e)
			}
			br, e := checkerDecode(b)
			if e != nil {
				t.Fatal(e)
			}
			r, e := checkerBinary(n.Op, ar, br)
			if e != nil {
				t.Fatal(e)
			}
			slots[i], _, e = checkerNearest(r, checkerZeroSign(n.Op, a, b))
			if e != nil {
				t.Fatal(e)
			}
		default:
			t.Fatal("unknown mutant node")
		}
	}
	return math.Float64frombits(slots[g.LogOutput])
}
