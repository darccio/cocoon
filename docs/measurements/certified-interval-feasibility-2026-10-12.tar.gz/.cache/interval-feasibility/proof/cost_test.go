package intervalproof

import (
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"os"
	"runtime"
	"runtime/debug"
	"testing"
	"time"
)

// This is a cost observation harness, not a promotion or locality benchmark.
// Source extraction and input-witness construction precede the timer. Each
// process exposes setup separately; no graph/source check is removed from Verify.
type costFixture struct {
	graph              *Graph
	cert               Certificate
	trace              Trace
	sourcePrepareNS    int64
	sourcePrepareBytes uint64
}

var costSink struct {
	Bank   Bank
	Report BankReport
	Cert   Certificate
	Trace  Trace
	Work   Work
	Err    error
}

func prepareCost(tb testing.TB) costFixture {
	tb.Helper()
	path := os.Getenv("COCOON_INTERVAL_SOURCE")
	if path == "" {
		path = "../../../examples/datadog/go/dd/internal/wasm/module.go"
	}
	var before, after runtime.MemStats
	runtime.ReadMemStats(&before)
	start := time.Now()
	g, err := Load(path)
	sourcePrepareNS := time.Since(start).Nanoseconds()
	runtime.ReadMemStats(&after)
	if err != nil {
		tb.Fatal(err)
	}
	bits := Seeds()[0]
	cert, trace, _, err := Certify(g, g.Params, bits-(1<<40), bits+(1<<40), DefaultBudget)
	if err != nil {
		tb.Fatal(err)
	}
	if err := Verify(g, g.Params, cert, &trace); err != nil {
		tb.Fatal(err)
	}
	return costFixture{graph: g, cert: cert, trace: trace, sourcePrepareNS: sourcePrepareNS, sourcePrepareBytes: after.TotalAlloc - before.TotalAlloc}
}

func (f costFixture) execute(name string) {
	switch name {
	case "BankConstruct":
		costSink.Bank, costSink.Report, costSink.Err = BuildBank(f.graph, DefaultBudget, nil)
	case "BankVerified":
		costSink.Bank, costSink.Report, costSink.Err = BuildBank(f.graph, DefaultBudget, func(a Attempt, tr *Trace) error {
			if a.Reason != ReasonNone {
				return nil
			}
			return Verify(f.graph, f.graph.Params, Certificate{a.Lo, a.Hi, a.Bin}, tr)
		})
	case "Accepted42", "RejectedCell2", "RejectedBoundary":
		index := 0
		if name == "RejectedCell2" {
			index = 3
		}
		if name == "RejectedBoundary" {
			index = 16
		}
		bits := Seeds()[index]
		costSink.Cert, costSink.Trace, costSink.Work, costSink.Err = Certify(f.graph, f.graph.Params, bits-(1<<40), bits+(1<<40), DefaultBudget)
	case "AcceptedChecker":
		costSink.Work, costSink.Err = VerifyWork(f.graph, f.graph.Params, f.cert, &f.trace)
	default:
		panic(name)
	}
}

func (f costFixture) check(tb testing.TB, name string) {
	tb.Helper()
	if name == "BankConstruct" || name == "BankVerified" {
		if costSink.Bank.Count != 57 || costSink.Report.Count != 92 || costSink.Report.Accepted != costSink.Bank.Count || costSink.Report.Total.WorkspaceBytes > MaxWorkspaceBytes {
			tb.Fatal("fixed bank cost scope or work bound changed")
		}
	}
	if name == "RejectedCell2" || name == "RejectedBoundary" {
		want := ReasonCell
		if name == "RejectedBoundary" {
			want = ReasonBoundary
		}
		if !errors.Is(costSink.Err, ErrUnknown) || ReasonOf(costSink.Err) != want {
			tb.Fatalf("fixed rejection %s changed: %v", name, costSink.Err)
		}
	} else if costSink.Err != nil {
		tb.Fatal(costSink.Err)
	}
}

func benchmarkCost(b *testing.B, name string) {
	b.StopTimer()
	f := prepareCost(b)
	f.execute(name)
	f.check(b, name)
	b.ReportAllocs()
	if runtime.GOMAXPROCS(0) != 1 {
		b.Fatal("cost observations require actual GOMAXPROCS=1")
	}
	b.ResetTimer()
	b.StartTimer()
	for range b.N {
		f.execute(name)
	}
	b.StopTimer()
	if runtime.GOMAXPROCS(0) != 1 {
		b.Fatal("cost observations changed actual GOMAXPROCS")
	}
	b.ReportMetric(1, "actual-procs")
	f.check(b, name)
	b.ReportMetric(float64(f.sourcePrepareNS), "source-prepare-ns")
	b.ReportMetric(float64(f.sourcePrepareBytes), "source-prepare-bytes")
	if name == "BankConstruct" || name == "BankVerified" {
		b.ReportMetric(float64(costSink.Report.Count), "attempts/op")
		b.ReportMetric(float64(costSink.Bank.Count), "certificates/op")
	} else {
		b.ReportMetric(float64(costSink.Work.Rounded), "rounded-nodes/op")
		b.ReportMetric(float64(costSink.Work.Conversions), "bound-conversions/op")
	}
}

func BenchmarkIntervalBankConstruct(b *testing.B)    { benchmarkCost(b, "BankConstruct") }
func BenchmarkIntervalBankVerified(b *testing.B)     { benchmarkCost(b, "BankVerified") }
func BenchmarkIntervalAccepted42(b *testing.B)       { benchmarkCost(b, "Accepted42") }
func BenchmarkIntervalRejectedCell2(b *testing.B)    { benchmarkCost(b, "RejectedCell2") }
func BenchmarkIntervalRejectedBoundary(b *testing.B) { benchmarkCost(b, "RejectedBoundary") }
func BenchmarkIntervalAcceptedChecker(b *testing.B)  { benchmarkCost(b, "AcceptedChecker") }

func TestIntervalCostMemory(t *testing.T) {
	f := prepareCost(t)
	old := debug.SetGCPercent(-1)
	defer debug.SetGCPercent(old)
	for _, name := range []string{"BankConstruct", "BankVerified", "Accepted42", "RejectedCell2", "RejectedBoundary", "AcceptedChecker"} {
		costSink = struct {
			Bank   Bank
			Report BankReport
			Cert   Certificate
			Trace  Trace
			Work   Work
			Err    error
		}{}
		runtime.GC()
		var before, after, collected runtime.MemStats
		runtime.ReadMemStats(&before)
		f.execute(name)
		f.check(t, name)
		runtime.ReadMemStats(&after)
		runtime.GC()
		runtime.ReadMemStats(&collected)
		record := map[string]any{"scope": name, "architecture": runtime.GOARCH, "GC_disabled_during_observation": true, "observation": "end-of-operation heap with GC disabled, not peak RSS or a hard heap bound", "before": before, "after": after, "after_forced_GC": collected, "allocated_bytes": after.TotalAlloc - before.TotalAlloc, "allocations": after.Mallocs - before.Mallocs, "heap_delta_before_collection": int64(after.HeapAlloc) - int64(before.HeapAlloc), "heap_delta_after_collection": int64(collected.HeapAlloc) - int64(before.HeapAlloc), "logical_graph_bytes": GraphBytes(f.graph), "logical_builder_workspace_bytes": WorkspaceBytes(), "result_error": fmt.Sprint(costSink.Err), "accepted42_members": f.cert.Hi - f.cert.Lo + 1, "accepted42_width": math.Float64frombits(f.cert.Hi) - math.Float64frombits(f.cert.Lo)}
		data, err := json.Marshal(record)
		if err != nil {
			t.Fatal(err)
		}
		t.Log("INTERVAL_MEMORY " + string(data))
	}
}
