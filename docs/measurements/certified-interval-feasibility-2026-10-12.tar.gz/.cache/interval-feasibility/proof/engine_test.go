package intervalproof

import (
	"bytes"
	"errors"
	"math"
	"math/big"
	"os"
	"path/filepath"
	"testing"
	"unsafe"
)

func engineGraph(t *testing.T) *Graph {
	t.Helper()
	path := os.Getenv("COCOON_INTERVAL_SOURCE")
	if path == "" {
		path = "../../../examples/datadog/go/dd/internal/wasm/module.go"
	}
	g, err := Load(path)
	if err != nil {
		t.Fatal(err)
	}
	return g
}

func TestEngineSourceAndLimits(t *testing.T) {
	g := engineGraph(t)
	if g.Rounded > MaxRounded || g.Count > MaxSlots || GraphBytes(g) > MaxGraphBytes || WorkspaceBytes() > MaxWorkspaceBytes || unsafe.Sizeof(Bank{}) > MaxBankBytes {
		t.Fatal("registered storage/work limits exceeded")
	}
	native, err := NativeSource(g)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Contains(native, []byte(g.LogSource)) || !bytes.Contains(native, []byte(g.SaturationSource)) {
		t.Fatal("native generator changed full original log/saturation source")
	}
	t.Logf("source=%x nodes=%d rounded=%d graph-bytes=%d workspace-bytes=%d bank-bytes=%d native-bytes=%d", g.SourceSHA, g.Count, g.Rounded, GraphBytes(g), WorkspaceBytes(), unsafe.Sizeof(Bank{}), len(native))
	for _, mutate := range []func(*Graph){func(g *Graph) { g.Nodes[g.Output].Op = OpNeg }, func(g *Graph) { g.SourceSHA[0] ^= 1 }, func(g *Graph) { g.Params[1]++ }, func(g *Graph) { g.RawSnippet += "\n" }} {
		copyGraph := *g
		mutate(&copyGraph)
		if _, _, _, err := Certify(&copyGraph, g.Params, math.Float64bits(42), math.Float64bits(42)+1, DefaultBudget); !errors.Is(err, ErrFatal) || ReasonOf(err) != ReasonFatal {
			t.Fatalf("graph drift accepted: %v", err)
		}
	}
	t.Log("verification-ledger whole=4 tiny=0 (fatal graph queries)")
}

func TestEngineSourceDrift(t *testing.T) {
	path := os.Getenv("COCOON_INTERVAL_SOURCE")
	if path == "" {
		path = "../../../examples/datadog/go/dd/internal/wasm/module.go"
	}
	source, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	source[0] ^= 1
	changed := filepath.Join(t.TempDir(), "module.go")
	if err := os.WriteFile(changed, source, 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := Load(changed); !errors.Is(err, ErrFatal) {
		t.Fatalf("source drift not fatal: %v", err)
	}
}

func TestEngineDirectedRounding(t *testing.T) {
	den := new(big.Int).Lsh(big.NewInt(1), 1075)
	cases := []struct {
		name   string
		value  *big.Rat
		lo, hi uint64
	}{
		{"one", big.NewRat(1, 1), math.Float64bits(1), math.Float64bits(1)},
		{"positive-tie", new(big.Rat).SetFrac(new(big.Int).SetUint64(9007199254740993), new(big.Int).SetUint64(9007199254740992)), math.Float64bits(1), math.Float64bits(math.Nextafter(1, 2))},
		{"negative-tie", new(big.Rat).SetFrac(new(big.Int).SetInt64(-9007199254740993), new(big.Int).SetUint64(9007199254740992)), math.Float64bits(math.Nextafter(-1, -2)), math.Float64bits(-1)},
		{"zero", big.NewRat(0, 1), 1 << 63, 0},
		{"positive-underflow", new(big.Rat).SetFrac(big.NewInt(1), den), 0, 1},
		{"negative-underflow", new(big.Rat).SetFrac(big.NewInt(-1), den), 1<<63 | 1, 1 << 63},
	}
	for _, test := range cases {
		t.Run(test.name, func(t *testing.T) {
			c := calculator{budget: DefaultBudget}
			lo, err := c.directed(test.value, false)
			if err != nil {
				t.Fatal(err)
			}
			hi, err := c.directed(test.value, true)
			if err != nil {
				t.Fatal(err)
			}
			if lo != test.lo || hi != test.hi {
				t.Fatalf("directed mismatch got=%016x/%016x want=%016x/%016x", lo, hi, test.lo, test.hi)
			}
			if c.work.Conversions != 2 || c.work.QuoRem > 2 || c.work.Shifts > 8 || c.work.Comparisons > 16 {
				t.Fatalf("rounder work exceeds conversion bound: %+v", c.work)
			}
		})
	}
}

func floatBounds(lo, hi float64) Bounds { return Bounds{math.Float64bits(lo), math.Float64bits(hi)} }

func TestEngineSignedCornerExtrema(t *testing.T) {
	cases := []struct {
		name       string
		op         Op
		a, b, want Bounds
	}{
		{"mixed-product", OpMul, floatBounds(-3, -1), floatBounds(-2, 4), floatBounds(-12, 6)},
		{"subtract", OpSub, floatBounds(-1, 2), floatBounds(3, 4), floatBounds(-5, -1)},
		{"negative-denominator", OpDiv, floatBounds(-3, 1), floatBounds(-4, -2), floatBounds(-0.5, 1.5)},
		{"positive-denominator", OpDiv, floatBounds(-3, 1), floatBounds(2, 4), floatBounds(-1.5, 0.5)},
	}
	for _, test := range cases {
		t.Run(test.name, func(t *testing.T) {
			c := calculator{budget: DefaultBudget}
			got, err := c.transfer(test.op, test.a, test.b)
			if err != nil {
				t.Fatal(err)
			}
			if got != test.want {
				t.Fatalf("signed corner mismatch got=%+v want=%+v", got, test.want)
			}
			if c.work.EndpointOps > 4 {
				t.Fatalf("endpoint ledger=%d", c.work.EndpointOps)
			}
		})
	}
	c := calculator{budget: DefaultBudget}
	if _, err := c.transfer(OpDiv, floatBounds(1, 2), floatBounds(-1, 1)); ReasonOf(err) != ReasonDivision {
		t.Fatalf("zero divisor accepted: %v", err)
	}
}

func TestEngineCellsAndUnknowns(t *testing.T) {
	g := engineGraph(t)
	base := math.Float64bits(42)
	cert, trace, work, err := Certify(g, g.Params, base, base+8191, DefaultBudget)
	if err != nil {
		t.Fatal(err)
	}
	if trace.Count != g.Count || cert.Lo != base || cert.Hi != base+8191 || work.Conversions > 192 {
		t.Fatal("incomplete trace or range")
	}
	// The request still certifies all 8192 nearby values. This supplementary
	// finite enumeration uses 512 members; each also consumes a whole-graph
	// evaluation in the collective per-architecture verification ledger.
	for bits := base; bits <= base+511; bits++ {
		bin, _, err := Point(g, g.Params, bits)
		if err != nil || bin != cert.Bin {
			t.Fatalf("tiny-span concrete mismatch bits=%016x bin=%d certificate=%d err=%v", bits, bin, cert.Bin, err)
		}
	}
	cases := []struct {
		name   string
		lo, hi uint64
		reason Reason
	}{
		{"zero", 0, 0, ReasonDomain}, {"subnormal", 1, 1, ReasonDomain}, {"negative", 1 << 63, 1 << 63, ReasonDomain}, {"nan", 0x7ff0000000000001, 0x7ff0000000000001, ReasonDomain},
		{"threshold-below", g.Params[2] - 1, g.Params[2] - 1, ReasonDomain},
		{"reversed", base + 1, base, ReasonDomain},
		{"one", math.Float64bits(1), math.Float64bits(1), ReasonCell},
		{"exponent-cross", math.Float64bits(2) - 1, math.Float64bits(2), ReasonCell},
		{"seam-cross", uint64(1023)<<52 | uint64(0x6a09e)<<32 - 1, uint64(1023)<<52 | uint64(0x6a09e)<<32, ReasonCell},
	}
	for _, test := range cases {
		t.Run(test.name, func(t *testing.T) {
			_, _, _, err := Certify(g, g.Params, test.lo, test.hi, DefaultBudget)
			if !errors.Is(err, ErrUnknown) || ReasonOf(err) != test.reason {
				t.Fatalf("unknown mismatch err=%v want=%s", err, test.reason)
			}
		})
	}
	changed := g.Params
	changed[0]++
	if _, _, _, err := Certify(g, changed, base, base+1, DefaultBudget); ReasonOf(err) != ReasonParameters {
		t.Fatal("changed configuration accepted")
	}
	for _, change := range []func(*Budget){func(b *Budget) { b.Nodes = 1 }, func(b *Budget) { b.Rounded = 0 }, func(b *Budget) { b.Conversions = 0 }, func(b *Budget) { b.IntegerBits = 1 }, func(b *Budget) { b.WorkspaceBytes = 1 }, func(b *Budget) { b.GraphBytes = 1 }, func(b *Budget) { b.Conversions = 193 }} {
		budget := DefaultBudget
		change(&budget)
		if _, _, _, err := Certify(g, g.Params, base, base+1, budget); !errors.Is(err, ErrUnknown) || ReasonOf(err) != ReasonBudget {
			t.Fatalf("budget ignored %+v err=%v", budget, err)
		}
	}
	t.Log("verification-ledger whole=530 tiny=512 (18 requests plus 512 point evaluations)")
}

func TestEngineFrozenBank(t *testing.T) {
	g := engineGraph(t)
	tooSmall := DefaultBudget
	tooSmall.WorkspaceBytes = WorkspaceBytes() - 1
	if _, _, err := BuildBank(g, tooSmall, nil); !errors.Is(err, ErrUnknown) || ReasonOf(err) != ReasonBudget {
		t.Fatalf("complete-bank workspace budget ignored: %v", err)
	}
	observed := 0
	bank, report, err := BuildBank(g, DefaultBudget, func(attempt Attempt, trace *Trace) error {
		observed++
		if attempt.Reason == ReasonNone && trace.Count != g.Count {
			return errors.New("incomplete accepted trace")
		}
		return nil
	})
	if err != nil {
		t.Fatal(err)
	}
	if observed != int(report.Count) || bank.Count != report.Accepted || report.Count > 320 || bank.Count > 64 {
		t.Fatal("fixed bank counters")
	}
	first, err := BankBytes(&bank)
	if err != nil {
		t.Fatal(err)
	}
	secondBank, secondReport, err := BuildBank(g, DefaultBudget, nil)
	if err != nil {
		t.Fatal(err)
	}
	second, err := BankBytes(&secondBank)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(first, second) || report != secondReport {
		t.Fatal("bank outcome nondeterminism")
	}
	t.Logf("verification-ledger whole=%d tiny=0 (two fixed-bank builds plus early workspace rejection)", 2*int(report.Count)+1)
	var cells [2048]bool
	var cellCount int
	var positive, negative, nearby bool
	for i := 0; i < int(bank.Count); i++ {
		cert := bank.Certificates[i]
		if cert.Lo == cert.Hi {
			t.Fatal("singleton bank")
		}
		exponent := cert.Lo >> 52
		if !cells[exponent] {
			cells[exponent] = true
			cellCount++
		}
		positive = positive || cert.Bin > 0
		negative = negative || cert.Bin < 0
		nearby = nearby || (cert.Lo <= math.Float64bits(42) && cert.Hi >= math.Float64bits(42)+8191)
		if bin, hit := Lookup(&bank, g.SourceSHA, g.Params, cert.Lo); !hit || bin != cert.Bin {
			t.Fatal("bank lookup omitted member")
		}
	}
	changed := g.Params
	changed[1]++
	if _, hit := Lookup(&bank, g.SourceSHA, changed, math.Float64bits(42)); hit {
		t.Fatal("parameter mismatch hit")
	}
	source := g.SourceSHA
	source[0]++
	if _, hit := Lookup(&bank, source, g.Params, math.Float64bits(42)); hit {
		t.Fatal("source mismatch hit")
	}
	t.Logf("frozen-bank attempts=%d accepted=%d original-exponents=%d positive=%t negative=%t nearby8192=%t nonvacuity=%t work=%+v bank-wire-bytes=%d", report.Count, bank.Count, cellCount, positive, negative, nearby, bank.Count >= 16 && cellCount >= 4 && positive && negative && nearby, report.Total, len(first))
	for i := 0; i < int(report.Count); i++ {
		attempt := report.Attempts[i]
		t.Logf("seed=%d refine=%d lo=%016x hi=%016x result=%s bin=%d", attempt.Seed, attempt.Refinement, attempt.Lo, attempt.Hi, attempt.Reason, attempt.Bin)
	}
}

func TestEngineCompiledOriginalPoints(t *testing.T) {
	g := engineGraph(t)
	seedBits := Seeds()
	points := append([]uint64(nil), seedBits[:]...)
	for _, exponent := range []int{-1022, -1, 0, 1, 1023} {
		seam := uint64(exponent+1023)<<52 | uint64(0x6a09e)<<32
		points = append(points, seam-1, seam, seam+1, seam+0xffffffff)
	}
	points = append(points, g.Params[2]-1, g.Params[2], g.Params[2]+1,
		math.Float64bits(1)-1, math.Float64bits(1), math.Float64bits(1)+1,
		0x7feffffffffffffe, 0x7fefffffffffffff)
	whole := 0
	for _, bits := range points {
		bin, trace, err := Point(g, g.Params, bits)
		whole++
		if err != nil {
			if !errors.Is(err, ErrUnknown) {
				t.Fatal(err)
			}
			continue
		}
		originalLog := OriginalLog(math.Float64frombits(bits))
		originalBin := OriginalBin(math.Float64frombits(bits))
		nativeBin, nativeTrace, nativeErr := OriginalPointTrace(bits)
		whole += 3
		if math.Float64bits(originalLog) != trace.Slots[g.LogOutput].Lo || originalBin != bin {
			t.Fatalf("compiled-original mismatch bits=%016x graph-log=%016x original-log=%016x graph-bin=%d original-bin=%d", bits, trace.Slots[g.LogOutput].Lo, math.Float64bits(originalLog), bin, originalBin)
		}
		if nativeErr != nil || nativeBin != bin || nativeTrace != trace {
			t.Fatalf("compiled graph-trace mismatch bits=%016x nativeErr=%v nativeBin=%d graphBin=%d", bits, nativeErr, nativeBin, bin)
		}
	}
	if whole > 368 {
		t.Fatal("registered concrete-driver bound")
	}
	t.Logf("whole-evaluator-calls=%d inputs=%d tiny-members=0", whole, len(points))
}
