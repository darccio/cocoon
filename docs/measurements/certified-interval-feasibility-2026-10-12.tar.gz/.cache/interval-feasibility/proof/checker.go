package intervalproof

import (
	"bytes"
	"encoding/hex"
	"errors"
	"fmt"
	"go/ast"
	"go/constant"
	"go/format"
	"go/parser"
	"go/token"
	"math"
	"math/big"
	"unsafe"
)

// The checker has its own immutable source/configuration identities. It does
// not use the constructor seal, graph derivation, cell, transfer or rounder.
const checkerSourceHash = "626550cafa323c490a6a2ec6b2b341656c40e223c7c84701e414078633dcc298"
const checkerIntegerLimit = 4096

var ErrVerification = errors.New("independent certificate verification failure")

func verification(format string, args ...any) error {
	return fmt.Errorf("%w: %s", ErrVerification, fmt.Sprintf(format, args...))
}
func checkerParameters() Params {
	return Params{0x3ff0400000000000, 0x40501fead4ea6e2b, 0x0010400000000000, 0x4094ea0000000000}
}
func checkerSHA() [32]byte {
	raw, _ := hex.DecodeString(checkerSourceHash)
	var h [32]byte
	copy(h[:], raw)
	return h
}

const checkerRaw = "v6 = p18 + i32(614242)\nv16 = float64(int32(uint32(v6)>>20) + v1)\nt21 := float64(v16 * float64(0x1.62e42feep-01))\nv2 = float64(math.Float64frombits(uint64(v19&i64(0xffffffff)|int64(uint32(v6&i32(0xfffff)+i32(1072079006)))<<32)) + float64(-1))\nt22 := v2\nt23 := float64(v16 * float64(0x1.a39ef35793c76p-33))\nv16 = float64(v2 / float64(v2+float64(2)))\nt24 := v16\nv17 = float64(v2 * float64(v2*float64(0.5)))\nt25 := v17\nv16 = float64(v16 * v16)\nv2 = float64(v16 * v16)\nt26 := float64(t21 + float64(t22+float64(float64(t23+float64(t24*float64(t25+float64(float64(v2*float64(float64(v2*float64(float64(v2*float64(0.15313837699209373))+float64(0.22222198432149784)))+float64(0.3999999999940942)))+float64(v16*float64(float64(v2*float64(float64(v2*float64(float64(v2*float64(0.14798198605116586))+float64(0.1818357216161805)))+float64(0.2857142874366239)))+float64(0.6666666666666735)))))))-v17)))\np17 = t26\nv7 = i32_trunc_sat_f64_s(math.Floor(float64(float64(t16*p17) + t27)))\n"
const checkerLog = "func OriginalLog(v2 float64) float64 {\nvar v1,v6 int32\nvar v16,v17 float64\nvar v19,v20 int64\nvar p17 float64\n\t\t\t\t\t\t\t\t\t\t{\n\t\t\t\t\t\t\t\t\t\t\tvar p18 int32\n\t\t\t\t\t\t\t\t\t\t\t{\n\t\t\t\t\t\t\t\t\t\t\t\tv19 = int64(math.Float64bits(v2))\n\t\t\t\t\t\t\t\t\t\t\t\tif v19 >= i64(0x10000000000000) {\n\t\t\t\t\t\t\t\t\t\t\t\t\tif uint64(v19) > uint64(i64(0x7fefffffffffffff)) {\n\t\t\t\t\t\t\t\t\t\t\t\t\t\tgoto l3\n\t\t\t\t\t\t\t\t\t\t\t\t\t}\n\t\t\t\t\t\t\t\t\t\t\t\t\tv1 = i32(-1023)\n\t\t\t\t\t\t\t\t\t\t\t\t\tv20 = int64(uint64(v19) >> 32)\n\t\t\t\t\t\t\t\t\t\t\t\t\tif v20 != i64(0x3ff00000) {\n\t\t\t\t\t\t\t\t\t\t\t\t\t\tt19 := int32(v20)\n\t\t\t\t\t\t\t\t\t\t\t\t\t\tp18 = t19\n\t\t\t\t\t\t\t\t\t\t\t\t\t\tgoto l4\n\t\t\t\t\t\t\t\t\t\t\t\t\t}\n\t\t\t\t\t\t\t\t\t\t\t\t\tif int32(v19) != 0 {\n\t\t\t\t\t\t\t\t\t\t\t\t\t\tp18 = i32(0x3ff00000)\n\t\t\t\t\t\t\t\t\t\t\t\t\t\tgoto l4\n\t\t\t\t\t\t\t\t\t\t\t\t\t}\n\t\t\t\t\t\t\t\t\t\t\t\t\tp17 = float64(0)\n\t\t\t\t\t\t\t\t\t\t\t\t\tgoto l5\n\t\t\t\t\t\t\t\t\t\t\t\t}\n\t\t\t\t\t\t\t\t\t\t\t\tt20 := float64(float64(-1) / float64(v2*v2))\n\t\t\t\t\t\t\t\t\t\t\t\tif v2 == float64(0) {\n\t\t\t\t\t\t\t\t\t\t\t\t\tp17 = t20\n\t\t\t\t\t\t\t\t\t\t\t\t\tgoto l5\n\t\t\t\t\t\t\t\t\t\t\t\t}\n\t\t\t\t\t\t\t\t\t\t\t\tif v19 < i64(0) {\n\t\t\t\t\t\t\t\t\t\t\t\t\tgoto l6\n\t\t\t\t\t\t\t\t\t\t\t\t}\n\t\t\t\t\t\t\t\t\t\t\t\tv1 = i32(-1077)\n\t\t\t\t\t\t\t\t\t\t\t\tv19 = int64(math.Float64bits(float64(v2 * float64(0x1p+54))))\n\t\t\t\t\t\t\t\t\t\t\t\tp18 = int32(int64(uint64(v19) >> 32))\n\t\t\t\t\t\t\t\t\t\t\t}\n\t\t\t\t\t\t\t\t\t\tl4:\n\t\t\t\t\t\t\t\t\t\t\tv6 = p18 + i32(614242)\n\t\t\t\t\t\t\t\t\t\t\tv16 = float64(int32(uint32(v6)>>20) + v1)\n\t\t\t\t\t\t\t\t\t\t\tt21 := float64(v16 * float64(0x1.62e42feep-01))\n\t\t\t\t\t\t\t\t\t\t\tv2 = float64(math.Float64frombits(uint64(v19&i64(0xffffffff)|int64(uint32(v6&i32(0xfffff)+i32(1072079006)))<<32)) + float64(-1))\n\t\t\t\t\t\t\t\t\t\t\tt22 := v2\n\t\t\t\t\t\t\t\t\t\t\tt23 := float64(v16 * float64(0x1.a39ef35793c76p-33))\n\t\t\t\t\t\t\t\t\t\t\tv16 = float64(v2 / float64(v2+float64(2)))\n\t\t\t\t\t\t\t\t\t\t\tt24 := v16\n\t\t\t\t\t\t\t\t\t\t\tv17 = float64(v2 * float64(v2*float64(0.5)))\n\t\t\t\t\t\t\t\t\t\t\tt25 := v17\n\t\t\t\t\t\t\t\t\t\t\tv16 = float64(v16 * v16)\n\t\t\t\t\t\t\t\t\t\t\tv2 = float64(v16 * v16)\n\t\t\t\t\t\t\t\t\t\t\tt26 := float64(t21 + float64(t22+float64(float64(t23+float64(t24*float64(t25+float64(float64(v2*float64(float64(v2*float64(float64(v2*float64(0.15313837699209373))+float64(0.22222198432149784)))+float64(0.3999999999940942)))+float64(v16*float64(float64(v2*float64(float64(v2*float64(float64(v2*float64(0.14798198605116586))+float64(0.1818357216161805)))+float64(0.2857142874366239)))+float64(0.6666666666666735)))))))-v17)))\n\t\t\t\t\t\t\t\t\t\t\tp17 = t26\n\t\t\t\t\t\t\t\t\t\t\tgoto l5\n\t\t\t\t\t\t\t\t\t\t}\n\t\t\t\t\t\t\t\t\tl6:\n\t\t\t\t\t\t\t\t\t\tv2 = float64(float64(v2-v2) / float64(0))\n\t\t\t\t\t\t\t\t\tl3:\n\t\t\t\t\t\t\t\t\t\tp17 = v2\n\t\t\t\t\t\t\t\t\tl5:\nreturn p17\n}"
const checkerSaturation = "func i32_trunc_sat_f64_s(f float64) int32 {\n\tswitch {\n\tcase f <= math.MinInt32:\n\t\treturn math.MinInt32\n\tcase f >= math.MaxInt32:\n\t\treturn math.MaxInt32\n\tcase f != f:\n\t\treturn 0\n\t}\n\treturn int32(f)\n}"

// checkerRoundWork is independent of the constructor's operation counters.
type checkerRoundWork struct{ shifts, comparisons, quotients, maxBits uint32 }

func (w *checkerRoundWork) bound(n *big.Int) error {
	bits := n.BitLen()
	if bits > checkerIntegerLimit {
		return verification("integer size %d", bits)
	}
	if uint32(bits) > w.maxBits {
		w.maxBits = uint32(bits)
	}
	return nil
}
func (w *checkerRoundWork) shift(n *big.Int, amount int) (*big.Int, error) {
	if amount < 0 || n.BitLen()+amount > checkerIntegerLimit || w.shifts >= 4 {
		return nil, verification("checked shift budget")
	}
	w.shifts++
	r := new(big.Int).Lsh(n, uint(amount))
	return r, w.bound(r)
}
func (w *checkerRoundWork) compare(a, b *big.Int) (int, error) {
	if w.comparisons >= 8 {
		return 0, verification("comparison budget")
	}
	if e := w.bound(a); e != nil {
		return 0, e
	}
	if e := w.bound(b); e != nil {
		return 0, e
	}
	w.comparisons++
	return a.Cmp(b), nil
}

// nearest uses a separately implemented integer significand and quotient /
// remainder tie-to-even rule. Directed bounds below derive from this nearest
// result and exact comparison, rather than the constructor's floor/ceil logic.
func checkerNearest(r *big.Rat, negativeZero bool) (uint64, checkerRoundWork, error) {
	var w checkerRoundWork
	if r == nil || r.Denom().Sign() <= 0 {
		return 0, w, verification("invalid rational")
	}
	// Check caller-owned integers before allocating copies of their limbs.
	if e := w.bound(r.Num()); e != nil {
		return 0, w, e
	}
	if e := w.bound(r.Denom()); e != nil {
		return 0, w, e
	}
	numerator := new(big.Int).Abs(r.Num())
	denominator := new(big.Int).Set(r.Denom())
	if e := w.bound(numerator); e != nil {
		return 0, w, e
	}
	if e := w.bound(denominator); e != nil {
		return 0, w, e
	}
	sign := uint64(0)
	if r.Sign() < 0 || (r.Sign() == 0 && negativeZero) {
		sign = 1 << 63
	}
	if numerator.Sign() == 0 {
		return sign, w, nil
	}
	exponent := numerator.BitLen() - denominator.BitLen()
	var left, right *big.Int
	var e error
	if exponent < 0 {
		left, e = w.shift(numerator, -exponent)
		right = denominator
	} else {
		right, e = w.shift(denominator, exponent)
		left = numerator
	}
	if e != nil {
		return 0, w, e
	}
	cmp, e := w.compare(left, right)
	if e != nil {
		return 0, w, e
	}
	if cmp < 0 {
		exponent--
	}
	if exponent > 1023 {
		return sign | 0x7ff0000000000000, w, nil
	}
	if exponent < -1075 {
		return sign, w, nil
	}
	scale := 52 - exponent
	if exponent < -1022 {
		scale = 1074
	}
	scaledN, scaledD := numerator, denominator
	if scale >= 0 {
		scaledN, e = w.shift(numerator, scale)
	} else {
		scaledD, e = w.shift(denominator, -scale)
	}
	if e != nil {
		return 0, w, e
	}
	q, rem := new(big.Int), new(big.Int)
	if w.quotients != 0 {
		return 0, w, verification("quotient budget")
	}
	w.quotients++
	q.QuoRem(scaledN, scaledD, rem)
	if e = w.bound(q); e != nil {
		return 0, w, e
	}
	if e = w.bound(rem); e != nil {
		return 0, w, e
	}
	twice, e := w.shift(rem, 1)
	if e != nil {
		return 0, w, e
	}
	cmp, e = w.compare(twice, scaledD)
	if e != nil {
		return 0, w, e
	}
	if cmp > 0 || (cmp == 0 && q.Bit(0) != 0) {
		if q.BitLen()+1 > checkerIntegerLimit {
			return 0, w, verification("rounding increment size")
		}
		q.Add(q, big.NewInt(1))
	}
	if q.BitLen() > 54 {
		return 0, w, verification("significand size")
	}
	m := q.Uint64()
	if exponent < -1022 {
		if m > 1<<52 {
			return 0, w, verification("subnormal significand")
		}
		return sign | m, w, nil
	}
	if m == 1<<53 {
		m >>= 1
		exponent++
	}
	if exponent > 1023 {
		return sign | 0x7ff0000000000000, w, nil
	}
	if m < 1<<52 || m >= 1<<53 {
		return 0, w, verification("normal significand")
	}
	return sign | uint64(exponent+1023)<<52 | (m - 1<<52), w, nil
}

func checkerFinite(b uint64) bool { return b&0x7ff0000000000000 != 0x7ff0000000000000 }
func checkerDecode(bits uint64) (*big.Rat, error) {
	if !checkerFinite(bits) {
		return nil, verification("nonfinite encoding")
	}
	mantissa := bits & 0x000fffffffffffff
	exponent := int(bits>>52&0x7ff) - 1075
	if bits>>52&0x7ff == 0 {
		exponent = -1074
	} else {
		mantissa |= 1 << 52
	}
	n := new(big.Int).SetUint64(mantissa)
	d := big.NewInt(1)
	if exponent < 0 {
		d.Lsh(d, uint(-exponent))
	} else {
		n.Lsh(n, uint(exponent))
	}
	if bits>>63 != 0 {
		n.Neg(n)
	}
	if n.BitLen() > checkerIntegerLimit || d.BitLen() > checkerIntegerLimit {
		return nil, verification("dyadic decode size")
	}
	return new(big.Rat).SetFrac(n, d), nil
}
func checkerRatCompare(a, b *big.Rat) (int, error) {
	if a.Num().BitLen()+b.Denom().BitLen() > checkerIntegerLimit || b.Num().BitLen()+a.Denom().BitLen() > checkerIntegerLimit {
		return 0, verification("rational comparison temporary")
	}
	left := new(big.Int).Mul(a.Num(), b.Denom())
	right := new(big.Int).Mul(b.Num(), a.Denom())
	return left.Cmp(right), nil
}
func checkerAdjacent(bits uint64, up bool) uint64 {
	if bits&0x7fffffffffffffff == 0 {
		if up {
			return 1
		}
		return 1<<63 | 1
	}
	if up == (bits>>63 == 0) {
		return bits + 1
	}
	return bits - 1
}
func checkerDirected(r *big.Rat) (Bounds, error) {
	return checkerDirectedWork(r, nil)
}

// These counters belong to the checker. MaxIntegerBits records the largest
// checked integer-width bound, including unreduced/comparison temporaries.
func checkerWidth(work *Work, widths ...int) {
	if work == nil {
		return
	}
	for _, width := range widths {
		if uint32(width) > work.MaxIntegerBits {
			work.MaxIntegerBits = uint32(width)
		}
	}
}
func checkerCompareWork(a, b *big.Rat, work *Work) (int, error) {
	if work != nil {
		work.Comparisons++
	}
	leftWidth, rightWidth := a.Num().BitLen()+b.Denom().BitLen(), b.Num().BitLen()+a.Denom().BitLen()
	if leftWidth > checkerIntegerLimit || rightWidth > checkerIntegerLimit {
		return 0, verification("rational comparison temporary")
	}
	checkerWidth(work, leftWidth, rightWidth)
	return checkerRatCompare(a, b)
}
func checkerDirectedWork(r *big.Rat, work *Work) (Bounds, error) {
	nearest, conversion, e := checkerNearest(r, false)
	if work != nil {
		work.Conversions++
		work.Shifts += conversion.shifts
		work.Comparisons += conversion.comparisons
		work.QuoRem += conversion.quotients
		checkerWidth(work, int(conversion.maxBits))
	}
	if e != nil {
		return Bounds{}, e
	}
	if !checkerFinite(nearest) {
		return Bounds{}, verification("outward overflow")
	}
	rounded, e := checkerDecode(nearest)
	if e != nil {
		return Bounds{}, e
	}
	cmp, e := checkerCompareWork(rounded, r, work)
	if e != nil {
		return Bounds{}, e
	}
	result := Bounds{nearest, nearest}
	if cmp < 0 {
		result.Hi = checkerAdjacent(nearest, true)
	} else if cmp > 0 {
		result.Lo = checkerAdjacent(nearest, false)
	}
	if r.Sign() == 0 {
		result.Lo = 1 << 63
		result.Hi = 0
	}
	if !checkerFinite(result.Lo) || !checkerFinite(result.Hi) {
		return Bounds{}, verification("nonfinite directed endpoint")
	}
	return result, nil
}
func checkerBinary(op Op, a, b *big.Rat) (*big.Rat, error) {
	if a == nil || b == nil {
		return nil, verification("missing rational operand")
	}
	nb, db := 0, 0
	switch op {
	case OpAdd, OpSub:
		nb = max(a.Num().BitLen()+b.Denom().BitLen(), b.Num().BitLen()+a.Denom().BitLen()) + 1
		db = a.Denom().BitLen() + b.Denom().BitLen()
	case OpMul:
		nb = a.Num().BitLen() + b.Num().BitLen()
		db = a.Denom().BitLen() + b.Denom().BitLen()
	case OpDiv:
		if b.Sign() == 0 {
			return nil, verification("division includes zero")
		}
		nb = a.Num().BitLen() + b.Denom().BitLen()
		db = a.Denom().BitLen() + b.Num().BitLen()
	default:
		return nil, verification("unsupported binary operator")
	}
	if nb > checkerIntegerLimit || db > checkerIntegerLimit {
		return nil, verification("unreduced arithmetic size")
	}
	r := new(big.Rat)
	switch op {
	case OpAdd:
		r.Add(a, b)
	case OpSub:
		r.Sub(a, b)
	case OpMul:
		r.Mul(a, b)
	case OpDiv:
		r.Quo(a, b)
	}
	if r.Num().BitLen() > checkerIntegerLimit || r.Denom().BitLen() > checkerIntegerLimit {
		return nil, verification("reduced arithmetic size")
	}
	return r, nil
}
func checkerOrdered(bounds Bounds) bool {
	return checkerFinite(bounds.Lo) && checkerFinite(bounds.Hi) && math.Float64frombits(bounds.Lo) <= math.Float64frombits(bounds.Hi)
}

// Extrema are recomputed by independently checking EVERY operand corner. The
// checker does not trust which corners the constructor claimed were extremal.
func checkerTransfer(op Op, a, b Bounds) (Bounds, error) {
	return checkerTransferWork(op, a, b, nil)
}
func checkerTransferWork(op Op, a, b Bounds, work *Work) (Bounds, error) {
	if !checkerOrdered(a) || !checkerOrdered(b) {
		return Bounds{}, verification("unordered operand range")
	}
	if op == OpDiv && math.Float64frombits(b.Lo) <= 0 && math.Float64frombits(b.Hi) >= 0 {
		return Bounds{}, verification("denominator zero")
	}
	av := [2]*big.Rat{}
	bv := [2]*big.Rat{}
	for i, bits := range [2]uint64{a.Lo, a.Hi} {
		r, e := checkerDecode(bits)
		if e != nil {
			return Bounds{}, e
		}
		av[i] = r
	}
	for i, bits := range [2]uint64{b.Lo, b.Hi} {
		r, e := checkerDecode(bits)
		if e != nil {
			return Bounds{}, e
		}
		bv[i] = r
	}
	var low, high *big.Rat
	for i := 0; i < 2; i++ {
		for j := 0; j < 2; j++ {
			if work != nil {
				work.EndpointOps++
			}
			// Account the conservative preflight bound before the allocating
			// operation, including products which may later cancel/reduce.
			x, y := av[i], bv[j]
			switch op {
			case OpAdd, OpSub:
				checkerWidth(work, max(x.Num().BitLen()+y.Denom().BitLen(), y.Num().BitLen()+x.Denom().BitLen())+1, x.Denom().BitLen()+y.Denom().BitLen())
			case OpMul:
				checkerWidth(work, x.Num().BitLen()+y.Num().BitLen(), x.Denom().BitLen()+y.Denom().BitLen())
			case OpDiv:
				checkerWidth(work, x.Num().BitLen()+y.Denom().BitLen(), x.Denom().BitLen()+y.Num().BitLen())
			}
			r, e := checkerBinary(op, x, y)
			if e != nil {
				return Bounds{}, e
			}
			if low == nil {
				low, high = r, r
				continue
			}
			cmp, e := checkerCompareWork(r, low, work)
			if e != nil {
				return Bounds{}, e
			}
			if cmp < 0 {
				low = r
			}
			cmp, e = checkerCompareWork(r, high, work)
			if e != nil {
				return Bounds{}, e
			}
			if cmp > 0 {
				high = r
			}
		}
	}
	lo, e := checkerDirectedWork(low, work)
	if e != nil {
		return Bounds{}, e
	}
	hi, e := checkerDirectedWork(high, work)
	if e != nil {
		return Bounds{}, e
	}
	return Bounds{lo.Lo, hi.Hi}, nil
}

// This reduction proof is independently expressed as integer translation
// through an affine offset on the complete positive-normal bit interval.
func checkerCell(params Params, lo, hi uint64) (Bounds, int32, uint8, error) {
	if params != checkerParameters() {
		return Bounds{}, 0, 0, verification("parameter mismatch")
	}
	if lo > hi || lo < 0x0010000000000000 || hi > 0x7fefffffffffffff || lo < 0x0010400000000000 {
		return Bounds{}, 0, 0, verification("normal domain")
	}
	if lo <= 0x3ff0000000000000 && hi >= 0x3ff0000000000000 {
		return Bounds{}, 0, 0, verification("one shortcut")
	}
	exponent := lo >> 52 & 0x7ff
	if exponent != hi>>52&0x7ff {
		return Bounds{}, 0, 0, verification("original exponent seam")
	}
	lowerFraction := (lo >> 32) & 0xfffff
	upperFraction := (hi >> 32) & 0xfffff
	lowerCarry := lowerFraction >= 0x6a09e
	upperCarry := upperFraction >= 0x6a09e
	if lowerCarry != upperCarry {
		return Bounds{}, 0, 0, verification("normalization carry seam")
	}
	carry := uint8(0)
	if lowerCarry {
		carry = 1
	}
	// No signed overflow: the largest positive finite high word plus the exact
	// adjustment is below MaxInt32. All accepted reduced encodings have one fixed
	// positive exponent and the same low 32 bits; the mantissa translation has
	// no wrap inside the selected carry cell.
	if (hi>>32)+614242 > 0x7fffffff {
		return Bounds{}, 0, 0, verification("normalization overflow")
	}
	reconstructed := func(input uint64) uint64 {
		mantissa := (input >> 32) & 0xfffff
		translated := mantissa + 614242 - uint64(carry)*(1<<20) + 0x3fe6a09e
		return translated<<32 | (input & 0xffffffff)
	}
	l, u := reconstructed(lo), reconstructed(hi)
	if !checkerFinite(l) || !checkerFinite(u) || l>>63 != 0 || u < l || u-l != hi-lo {
		return Bounds{}, 0, 0, verification("reduction integer relation")
	}
	return Bounds{l, u}, int32(exponent) + int32(carry) - 1023, carry, nil
}

func checkerFormat(fragment string) (string, error) {
	fset := token.NewFileSet()
	file, e := parser.ParseFile(fset, "checker-source.go", "package intervalproof\n"+fragment, 0)
	if e != nil {
		return "", verification("source parse: %v", e)
	}
	var out bytes.Buffer
	if e = format.Node(&out, fset, file); e != nil {
		return "", e
	}
	return out.String(), nil
}

type checkerGraph struct {
	nodes                             [256]Node
	count, rounded, output, logOutput uint16
	names                             map[string]uint16
}

func (c *checkerGraph) put(n Node) (uint16, error) {
	if c.count >= 256 {
		return 0, verification("canonical node bound")
	}
	index := c.count
	c.nodes[index] = n
	c.count++
	if n.Op >= OpAdd && n.Op <= OpDiv {
		c.rounded++
		if c.rounded > 96 {
			return 0, verification("canonical rounded bound")
		}
	}
	return index, nil
}
func checkerConstant(e ast.Expr) (*big.Rat, bool, error) {
	switch x := e.(type) {
	case *ast.ParenExpr:
		return checkerConstant(x.X)
	case *ast.BasicLit:
		if x.Kind != token.INT && x.Kind != token.FLOAT {
			return nil, false, nil
		}
		v := constant.MakeFromLiteral(x.Value, x.Kind, 0)
		if v.Kind() == constant.Unknown {
			return nil, false, verification("unknown literal")
		}
		numerator := constant.Num(v)
		denominator := constant.Denom(v)
		n, ok := new(big.Int).SetString(numerator.ExactString(), 10)
		if !ok {
			return nil, false, verification("constant numerator")
		}
		d, ok := new(big.Int).SetString(denominator.ExactString(), 10)
		if !ok || d.Sign() <= 0 {
			return nil, false, verification("constant denominator")
		}
		if n.BitLen() > 4096 || d.BitLen() > 4096 {
			return nil, false, verification("constant size")
		}
		return new(big.Rat).SetFrac(n, d), true, nil
	case *ast.UnaryExpr:
		if x.Op != token.ADD && x.Op != token.SUB {
			return nil, false, nil
		}
		v, ok, e := checkerConstant(x.X)
		if e != nil || !ok {
			return v, ok, e
		}
		if x.Op == token.SUB {
			v.Neg(v)
		}
		return v, true, nil
	case *ast.CallExpr:
		id, ok := x.Fun.(*ast.Ident)
		if !ok || id.Name != "float64" || len(x.Args) != 1 {
			return nil, false, nil
		}
		return checkerConstant(x.Args[0])
	default:
		return nil, false, nil
	}
}
func checkerExprText(e ast.Expr) string {
	var b bytes.Buffer
	_ = format.Node(&b, token.NewFileSet(), e)
	return b.String()
}
func (c *checkerGraph) expression(e ast.Expr) (uint16, error) {
	if v, ok, err := checkerConstant(e); err != nil {
		return 0, err
	} else if ok {
		bits, _, err := checkerNearest(v, false)
		if err != nil {
			return 0, err
		}
		if !checkerFinite(bits) {
			return 0, verification("nonfinite canonical literal")
		}
		return c.put(Node{Op: OpConst, Bits: bits})
	}
	switch x := e.(type) {
	case *ast.ParenExpr:
		return c.expression(x.X)
	case *ast.Ident:
		index, ok := c.names[x.Name]
		if !ok {
			return 0, verification("canonical unbound %s", x.Name)
		}
		return index, nil
	case *ast.UnaryExpr:
		index, e := c.expression(x.X)
		if e != nil {
			return 0, e
		}
		op := OpCopy
		if x.Op == token.SUB {
			op = OpNeg
		} else if x.Op != token.ADD {
			return 0, verification("canonical unary")
		}
		return c.put(Node{Op: op, A: index})
	case *ast.BinaryExpr:
		left, e := c.expression(x.X)
		if e != nil {
			return 0, e
		}
		right, e := c.expression(x.Y)
		if e != nil {
			return 0, e
		}
		op, ok := map[token.Token]Op{token.ADD: OpAdd, token.SUB: OpSub, token.MUL: OpMul, token.QUO: OpDiv}[x.Op]
		if !ok {
			return 0, verification("canonical operator")
		}
		return c.put(Node{Op: op, A: left, B: right})
	case *ast.CallExpr:
		if id, ok := x.Fun.(*ast.Ident); ok && id.Name == "float64" && len(x.Args) == 1 {
			index, e := c.expression(x.Args[0])
			if e != nil {
				return 0, e
			}
			return c.put(Node{Op: OpCopy, A: index})
		}
		if checkerExprText(x) == "math.Float64frombits(uint64(v19&i64(0xffffffff) | int64(uint32(v6&i32(0xfffff)+i32(1072079006)))<<32))" {
			return 0, nil
		}
		return 0, verification("canonical unsupported call")
	default:
		return 0, verification("canonical unsupported expression")
	}
}
func checkerExpectedGraph() (checkerGraph, error) {
	var c checkerGraph
	c.names = map[string]uint16{"v16": 1}
	if _, e := c.put(Node{Op: OpReduced}); e != nil {
		return c, e
	}
	if _, e := c.put(Node{Op: OpExponent}); e != nil {
		return c, e
	}
	fset := token.NewFileSet()
	file, e := parser.ParseFile(fset, "canonical.go", "package intervalproof\nfunc f(){\n"+checkerRaw+"}\n", 0)
	if e != nil {
		return c, e
	}
	statements := file.Decls[0].(*ast.FuncDecl).Body.List
	for i, statement := range statements {
		if i < 2 {
			continue
		}
		assignment, ok := statement.(*ast.AssignStmt)
		if !ok || len(assignment.Lhs) != 1 || len(assignment.Rhs) != 1 {
			return c, verification("canonical assignment")
		}
		destination, ok := assignment.Lhs[0].(*ast.Ident)
		if !ok {
			return c, verification("canonical destination")
		}
		expr := assignment.Rhs[0]
		if destination.Name == "v7" {
			for _, p := range []struct {
				name string
				bits uint64
			}{{"t16", checkerParameters()[1]}, {"t27", checkerParameters()[3]}} {
				n, e := c.put(Node{Op: OpConst, Bits: p.bits})
				if e != nil {
					return c, e
				}
				c.names[p.name] = n
			}
			sat, ok := expr.(*ast.CallExpr)
			if !ok || len(sat.Args) != 1 {
				return c, verification("canonical saturation")
			}
			floor, ok := sat.Args[0].(*ast.CallExpr)
			if !ok || len(floor.Args) != 1 {
				return c, verification("canonical floor")
			}
			expr = floor.Args[0]
		}
		id, e := c.expression(expr)
		if e != nil {
			return c, e
		}
		c.names[destination.Name] = id
		if destination.Name == "p17" {
			c.logOutput = id
		}
		if destination.Name == "v7" {
			c.output = id
		}
	}
	return c, nil
}

// VerifyGraph binds all model strings, constants, operators, edge IDs and
// counts to a separately reconstructed canonical slice of the original source.
func VerifyGraph(g *Graph) error {
	if g == nil {
		return verification("nil graph")
	}
	if g.SourceSHA != checkerSHA() || g.Params != checkerParameters() {
		return verification("source/parameter identity")
	}
	if uint64(unsafe.Sizeof(*g))+uint64(len(g.RawSnippet))+uint64(len(g.LogSource))+uint64(len(g.SaturationSource)) > 16<<10 {
		return verification("owned graph bound")
	}
	if g.RawSnippet != checkerRaw {
		return verification("normal source binding")
	}
	actual, e := checkerFormat(g.LogSource)
	if e != nil {
		return e
	}
	want, e := checkerFormat(checkerLog)
	if e != nil {
		return e
	}
	if actual != want {
		return verification("full log source binding")
	}
	actual, e = checkerFormat(g.SaturationSource)
	if e != nil {
		return e
	}
	want, e = checkerFormat(checkerSaturation)
	if e != nil {
		return e
	}
	if actual != want {
		return verification("saturation source binding")
	}
	expected, e := checkerExpectedGraph()
	if e != nil {
		return e
	}
	if g.Nodes != expected.nodes || g.Count != expected.count || g.Rounded != expected.rounded || g.Output != expected.output || g.LogOutput != expected.logOutput {
		return verification("source/node/edge binding")
	}
	return nil
}

func checkerSameBounds(a, b Bounds) bool {
	// The accepted graph has no zero-sign observation after reduction. Both
	// signs denote the same real endpoint; division involving zero is rejected.
	return checkerOrdered(a) && checkerOrdered(b) && math.Float64frombits(a.Lo) == math.Float64frombits(b.Lo) && math.Float64frombits(a.Hi) == math.Float64frombits(b.Hi)
}
func checkerFloor(bits uint64) (int32, error) {
	r, e := checkerDecode(bits)
	if e != nil {
		return 0, e
	}
	q, rem := new(big.Int), new(big.Int)
	q.QuoRem(r.Num(), r.Denom(), rem)
	if r.Sign() < 0 && rem.Sign() != 0 {
		q.Sub(q, big.NewInt(1))
	}
	if !q.IsInt64() {
		return 0, verification("floor range")
	}
	k := q.Int64()
	if k <= -2147483648 || k >= 2147483647 {
		return 0, verification("saturation uncertainty")
	}
	return int32(k), nil
}
func checkerBin(bounds Bounds, bin int32) error {
	return checkerBinWork(bounds, bin, nil)
}
func checkerBinWork(bounds Bounds, bin int32, work *Work) error {
	if !checkerOrdered(bounds) || bin <= -2147483648 || bin >= 2147483647 {
		return verification("bin/endpoint domain")
	}
	lo, e := checkerDecode(bounds.Lo)
	if e != nil {
		return e
	}
	hi, e := checkerDecode(bounds.Hi)
	if e != nil {
		return e
	}
	lower := new(big.Rat).SetInt64(int64(bin))
	upper := new(big.Rat).SetInt64(int64(bin) + 1)
	cmp, e := checkerCompareWork(lo, lower, work)
	if e != nil {
		return e
	}
	if cmp < 0 {
		return verification("lower bin containment")
	}
	cmp, e = checkerCompareWork(hi, upper, work)
	if e != nil {
		return e
	}
	if cmp >= 0 {
		return verification("strict upper bin containment")
	}
	return nil
}

// Verify never invokes constructor source derivation, cell, arithmetic,
// transfer, point evaluation, seal or rounding. All trace slots are recomputed
// from independently verified prior slots and every signed operand corner.
func Verify(g *Graph, params Params, cert Certificate, trace *Trace) error {
	_, err := VerifyWork(g, params, cert, trace)
	return err
}

// VerifyWork includes required canonical source binding and returns a separate
// arithmetic ledger even on rejection. Nodes count attempted transfer slots;
// EndpointOps counts every recomputed signed corner, not trusted extrema.
// WorkspaceBytes counts the fixed interval/trace arrays, not AST or allocating
// math/big heap. Those allocations belong to the full VerifyWork cost scope.
func VerifyWork(g *Graph, params Params, cert Certificate, trace *Trace) (Work, error) {
	var work Work
	work.WorkspaceBytes = uint32(unsafe.Sizeof([256]Bounds{}) + unsafe.Sizeof(Trace{}))
	if e := VerifyGraph(g); e != nil {
		return work, e
	}
	if trace == nil || trace.Count != g.Count || trace.Lo != cert.Lo || trace.Hi != cert.Hi || trace.SourceSHA != checkerSHA() || trace.Params != checkerParameters() || params != checkerParameters() {
		return work, verification("trace identity/completeness")
	}
	reduced, k, carry, e := checkerCell(params, cert.Lo, cert.Hi)
	if e != nil {
		return work, e
	}
	if trace.Exponent != k || trace.Carry != carry {
		return work, verification("trace reduction tags")
	}
	var verified [256]Bounds
	for i := uint16(0); i < g.Count; i++ {
		n := g.Nodes[i]
		work.Nodes++
		var bounds Bounds
		switch n.Op {
		case OpReduced:
			bounds = reduced
		case OpExponent:
			v := math.Float64bits(float64(k))
			bounds = Bounds{v, v}
		case OpConst:
			bounds = Bounds{n.Bits, n.Bits}
		case OpCopy:
			bounds = verified[n.A]
		case OpNeg:
			a := verified[n.A]
			bounds = Bounds{a.Hi ^ 1<<63, a.Lo ^ 1<<63}
		case OpAdd, OpSub, OpMul, OpDiv:
			work.Rounded++
			bounds, e = checkerTransferWork(n.Op, verified[n.A], verified[n.B], &work)
		default:
			e = verification("unknown verified node")
		}
		if e != nil {
			return work, verification("node%d: %v", i, e)
		}
		if !checkerSameBounds(bounds, trace.Slots[i]) {
			return work, verification("node%d inward/altered bounds", i)
		}
		verified[i] = bounds
	}
	for i := int(trace.Count); i < 256; i++ {
		if trace.Slots[i] != (Bounds{}) {
			return work, verification("extraneous trace slot")
		}
	}
	binErr := checkerBinWork(verified[g.Output], cert.Bin, &work)
	return work, binErr
}

func checkerZeroSign(op Op, a, b uint64) bool {
	switch op {
	case OpMul, OpDiv:
		return (a^b)>>63 != 0
	case OpSub:
		b ^= 1 << 63
		fallthrough
	case OpAdd:
		return a&0x7fffffffffffffff == 0 && b&0x7fffffffffffffff == 0 && a>>63 != 0 && b>>63 != 0
	default:
		return false
	}
}

// CheckerPoint separately rounds exact primitive results to nearest-even. Its
// direct bits may be compared to the compiled original graph/source witnesses.
func CheckerPoint(g *Graph, params Params, bits uint64) (int32, error) {
	_, trace, e := CheckerPointTrace(g, params, bits)
	if e != nil {
		return 0, e
	}
	return checkerFloor(trace.Slots[g.Output].Lo)
}
func CheckerPointTrace(g *Graph, params Params, bits uint64) (int32, Trace, error) {
	var trace Trace
	if e := VerifyGraph(g); e != nil {
		return 0, trace, e
	}
	reduced, k, carry, e := checkerCell(params, bits, bits)
	if e != nil {
		return 0, trace, e
	}
	trace.Lo, trace.Hi, trace.Params, trace.SourceSHA, trace.Exponent, trace.Carry = bits, bits, params, checkerSHA(), k, carry
	for i := uint16(0); i < g.Count; i++ {
		n := g.Nodes[i]
		var value uint64
		switch n.Op {
		case OpReduced:
			value = reduced.Lo
		case OpExponent:
			value = math.Float64bits(float64(k))
		case OpConst:
			value = n.Bits
		case OpCopy:
			value = trace.Slots[n.A].Lo
		case OpNeg:
			value = trace.Slots[n.A].Lo ^ 1<<63
		case OpAdd, OpSub, OpMul, OpDiv:
			a, b := trace.Slots[n.A].Lo, trace.Slots[n.B].Lo
			ar, err := checkerDecode(a)
			if err != nil {
				return 0, trace, err
			}
			br, err := checkerDecode(b)
			if err != nil {
				return 0, trace, err
			}
			real, err := checkerBinary(n.Op, ar, br)
			if err != nil {
				return 0, trace, err
			}
			value, _, e = checkerNearest(real, checkerZeroSign(n.Op, a, b))
			if e != nil {
				return 0, trace, e
			}
		default:
			return 0, trace, verification("unknown point node")
		}
		if !checkerFinite(value) {
			return 0, trace, verification("nonfinite point")
		}
		trace.Slots[i] = Bounds{value, value}
		trace.Count = i + 1
	}
	bin, e := checkerFloor(trace.Slots[g.Output].Lo)
	return bin, trace, e
}
