package intervalproof

import "math"

func i32(x int32) int32 { return x }
func i64(x int64) int64 { return x }
func OriginalLog(v2 float64) float64 {
	var v1, v6 int32
	var v16, v17 float64
	var v19, v20 int64
	var p17 float64
	{
		var p18 int32
		{
			v19 = int64(math.Float64bits(v2))
			if v19 >= i64(0x10000000000000) {
				if uint64(v19) > uint64(i64(0x7fefffffffffffff)) {
					goto l3
				}
				v1 = i32(-1023)
				v20 = int64(uint64(v19) >> 32)
				if v20 != i64(0x3ff00000) {
					t19 := int32(v20)
					p18 = t19
					goto l4
				}
				if int32(v19) != 0 {
					p18 = i32(0x3ff00000)
					goto l4
				}
				p17 = float64(0)
				goto l5
			}
			t20 := float64(float64(-1) / float64(v2*v2))
			if v2 == float64(0) {
				p17 = t20
				goto l5
			}
			if v19 < i64(0) {
				goto l6
			}
			v1 = i32(-1077)
			v19 = int64(math.Float64bits(float64(v2 * float64(0x1p+54))))
			p18 = int32(int64(uint64(v19) >> 32))
		}
	l4:
		v6 = p18 + i32(614242)
		v16 = float64(int32(uint32(v6)>>20) + v1)
		t21 := float64(v16 * float64(0x1.62e42feep-01))
		v2 = float64(math.Float64frombits(uint64(v19&i64(0xffffffff)|int64(uint32(v6&i32(0xfffff)+i32(1072079006)))<<32)) + float64(-1))
		t22 := v2
		t23 := float64(v16 * float64(0x1.a39ef35793c76p-33))
		v16 = float64(v2 / float64(v2+float64(2)))
		t24 := v16
		v17 = float64(v2 * float64(v2*float64(0.5)))
		t25 := v17
		v16 = float64(v16 * v16)
		v2 = float64(v16 * v16)
		t26 := float64(t21 + float64(t22+float64(float64(t23+float64(t24*float64(t25+float64(float64(v2*float64(float64(v2*float64(float64(v2*float64(0.15313837699209373))+float64(0.22222198432149784)))+float64(0.3999999999940942)))+float64(v16*float64(float64(v2*float64(float64(v2*float64(float64(v2*float64(0.14798198605116586))+float64(0.1818357216161805)))+float64(0.2857142874366239)))+float64(0.6666666666666735)))))))-v17)))
		p17 = t26
		goto l5
	}
l6:
	v2 = float64(float64(v2-v2) / float64(0))
l3:
	p17 = v2
l5:
	return p17
}
func i32_trunc_sat_f64_s(f float64) int32 {
	switch {
	case f <= math.MinInt32:
		return math.MinInt32
	case f >= math.MaxInt32:
		return math.MaxInt32
	case f != f:
		return 0
	}
	return int32(f)
}
func OriginalBin(value float64) int32 {
	return i32_trunc_sat_f64_s(math.Floor(float64(float64(math.Float64frombits(0x40501fead4ea6e2b)*OriginalLog(value)) + math.Float64frombits(0x4094ea0000000000))))
}
func OriginalPointTrace(bits uint64) (int32, Trace, error) {
	var trace Trace
	if bits < 0x0010400000000000 || bits > 0x7fefffffffffffff || bits == 0x3ff0000000000000 {
		return 0, trace, unknown(ReasonDomain)
	}
	h := uint64(uint32(bits >> 32))
	a := h + 0x95f62
	k := int32(a>>20) - 1023
	reduced := bits&0xffffffff | ((a&0xfffff)+0x3fe6a09e)<<32
	trace.Lo = bits
	trace.Hi = bits
	trace.Params = Params{0x3ff0400000000000, 0x40501fead4ea6e2b, 0x10400000000000, 0x4094ea0000000000}
	trace.Exponent = k
	trace.Carry = uint8(((h & 0xfffff) + 0x95f62) >> 20)
	trace.Count = 76
	trace.SourceSHA = [32]byte{98, 101, 80, 202, 250, 50, 60, 73, 10, 106, 46, 198, 178, 179, 65, 101, 108, 64, 226, 35, 199, 200, 71, 1, 228, 20, 7, 134, 51, 220, 194, 152}
	s0 := math.Float64frombits(reduced)
	v0 := math.Float64bits(s0)
	trace.Slots[0] = Bounds{v0, v0}
	s1 := float64(k)
	v1 := math.Float64bits(s1)
	trace.Slots[1] = Bounds{v1, v1}
	s2 := math.Float64frombits(0x3fe62e42fee00000)
	v2 := math.Float64bits(s2)
	trace.Slots[2] = Bounds{v2, v2}
	s3 := float64(s1 * s2)
	v3 := math.Float64bits(s3)
	trace.Slots[3] = Bounds{v3, v3}
	s4 := s3
	v4 := math.Float64bits(s4)
	trace.Slots[4] = Bounds{v4, v4}
	s5 := math.Float64frombits(0xbff0000000000000)
	v5 := math.Float64bits(s5)
	trace.Slots[5] = Bounds{v5, v5}
	s6 := float64(s0 + s5)
	v6 := math.Float64bits(s6)
	trace.Slots[6] = Bounds{v6, v6}
	s7 := s6
	v7 := math.Float64bits(s7)
	trace.Slots[7] = Bounds{v7, v7}
	s8 := math.Float64frombits(0x3dea39ef35793c76)
	v8 := math.Float64bits(s8)
	trace.Slots[8] = Bounds{v8, v8}
	s9 := float64(s1 * s8)
	v9 := math.Float64bits(s9)
	trace.Slots[9] = Bounds{v9, v9}
	s10 := s9
	v10 := math.Float64bits(s10)
	trace.Slots[10] = Bounds{v10, v10}
	s11 := math.Float64frombits(0x4000000000000000)
	v11 := math.Float64bits(s11)
	trace.Slots[11] = Bounds{v11, v11}
	s12 := float64(s7 + s11)
	v12 := math.Float64bits(s12)
	trace.Slots[12] = Bounds{v12, v12}
	s13 := s12
	v13 := math.Float64bits(s13)
	trace.Slots[13] = Bounds{v13, v13}
	s14 := float64(s7 / s13)
	v14 := math.Float64bits(s14)
	trace.Slots[14] = Bounds{v14, v14}
	s15 := s14
	v15 := math.Float64bits(s15)
	trace.Slots[15] = Bounds{v15, v15}
	s16 := math.Float64frombits(0x3fe0000000000000)
	v16 := math.Float64bits(s16)
	trace.Slots[16] = Bounds{v16, v16}
	s17 := float64(s7 * s16)
	v17 := math.Float64bits(s17)
	trace.Slots[17] = Bounds{v17, v17}
	s18 := s17
	v18 := math.Float64bits(s18)
	trace.Slots[18] = Bounds{v18, v18}
	s19 := float64(s7 * s18)
	v19 := math.Float64bits(s19)
	trace.Slots[19] = Bounds{v19, v19}
	s20 := s19
	v20 := math.Float64bits(s20)
	trace.Slots[20] = Bounds{v20, v20}
	s21 := float64(s15 * s15)
	v21 := math.Float64bits(s21)
	trace.Slots[21] = Bounds{v21, v21}
	s22 := s21
	v22 := math.Float64bits(s22)
	trace.Slots[22] = Bounds{v22, v22}
	s23 := float64(s22 * s22)
	v23 := math.Float64bits(s23)
	trace.Slots[23] = Bounds{v23, v23}
	s24 := s23
	v24 := math.Float64bits(s24)
	trace.Slots[24] = Bounds{v24, v24}
	s25 := math.Float64frombits(0x3fc39a09d078c69f)
	v25 := math.Float64bits(s25)
	trace.Slots[25] = Bounds{v25, v25}
	s26 := float64(s24 * s25)
	v26 := math.Float64bits(s26)
	trace.Slots[26] = Bounds{v26, v26}
	s27 := s26
	v27 := math.Float64bits(s27)
	trace.Slots[27] = Bounds{v27, v27}
	s28 := math.Float64frombits(0x3fcc71c51d8e78af)
	v28 := math.Float64bits(s28)
	trace.Slots[28] = Bounds{v28, v28}
	s29 := float64(s27 + s28)
	v29 := math.Float64bits(s29)
	trace.Slots[29] = Bounds{v29, v29}
	s30 := s29
	v30 := math.Float64bits(s30)
	trace.Slots[30] = Bounds{v30, v30}
	s31 := float64(s24 * s30)
	v31 := math.Float64bits(s31)
	trace.Slots[31] = Bounds{v31, v31}
	s32 := s31
	v32 := math.Float64bits(s32)
	trace.Slots[32] = Bounds{v32, v32}
	s33 := math.Float64frombits(0x3fd999999997fa04)
	v33 := math.Float64bits(s33)
	trace.Slots[33] = Bounds{v33, v33}
	s34 := float64(s32 + s33)
	v34 := math.Float64bits(s34)
	trace.Slots[34] = Bounds{v34, v34}
	s35 := s34
	v35 := math.Float64bits(s35)
	trace.Slots[35] = Bounds{v35, v35}
	s36 := float64(s24 * s35)
	v36 := math.Float64bits(s36)
	trace.Slots[36] = Bounds{v36, v36}
	s37 := s36
	v37 := math.Float64bits(s37)
	trace.Slots[37] = Bounds{v37, v37}
	s38 := math.Float64frombits(0x3fc2f112df3e5244)
	v38 := math.Float64bits(s38)
	trace.Slots[38] = Bounds{v38, v38}
	s39 := float64(s24 * s38)
	v39 := math.Float64bits(s39)
	trace.Slots[39] = Bounds{v39, v39}
	s40 := s39
	v40 := math.Float64bits(s40)
	trace.Slots[40] = Bounds{v40, v40}
	s41 := math.Float64frombits(0x3fc7466496cb03de)
	v41 := math.Float64bits(s41)
	trace.Slots[41] = Bounds{v41, v41}
	s42 := float64(s40 + s41)
	v42 := math.Float64bits(s42)
	trace.Slots[42] = Bounds{v42, v42}
	s43 := s42
	v43 := math.Float64bits(s43)
	trace.Slots[43] = Bounds{v43, v43}
	s44 := float64(s24 * s43)
	v44 := math.Float64bits(s44)
	trace.Slots[44] = Bounds{v44, v44}
	s45 := s44
	v45 := math.Float64bits(s45)
	trace.Slots[45] = Bounds{v45, v45}
	s46 := math.Float64frombits(0x3fd2492494229359)
	v46 := math.Float64bits(s46)
	trace.Slots[46] = Bounds{v46, v46}
	s47 := float64(s45 + s46)
	v47 := math.Float64bits(s47)
	trace.Slots[47] = Bounds{v47, v47}
	s48 := s47
	v48 := math.Float64bits(s48)
	trace.Slots[48] = Bounds{v48, v48}
	s49 := float64(s24 * s48)
	v49 := math.Float64bits(s49)
	trace.Slots[49] = Bounds{v49, v49}
	s50 := s49
	v50 := math.Float64bits(s50)
	trace.Slots[50] = Bounds{v50, v50}
	s51 := math.Float64frombits(0x3fe5555555555593)
	v51 := math.Float64bits(s51)
	trace.Slots[51] = Bounds{v51, v51}
	s52 := float64(s50 + s51)
	v52 := math.Float64bits(s52)
	trace.Slots[52] = Bounds{v52, v52}
	s53 := s52
	v53 := math.Float64bits(s53)
	trace.Slots[53] = Bounds{v53, v53}
	s54 := float64(s22 * s53)
	v54 := math.Float64bits(s54)
	trace.Slots[54] = Bounds{v54, v54}
	s55 := s54
	v55 := math.Float64bits(s55)
	trace.Slots[55] = Bounds{v55, v55}
	s56 := float64(s37 + s55)
	v56 := math.Float64bits(s56)
	trace.Slots[56] = Bounds{v56, v56}
	s57 := s56
	v57 := math.Float64bits(s57)
	trace.Slots[57] = Bounds{v57, v57}
	s58 := float64(s20 + s57)
	v58 := math.Float64bits(s58)
	trace.Slots[58] = Bounds{v58, v58}
	s59 := s58
	v59 := math.Float64bits(s59)
	trace.Slots[59] = Bounds{v59, v59}
	s60 := float64(s15 * s59)
	v60 := math.Float64bits(s60)
	trace.Slots[60] = Bounds{v60, v60}
	s61 := s60
	v61 := math.Float64bits(s61)
	trace.Slots[61] = Bounds{v61, v61}
	s62 := float64(s10 + s61)
	v62 := math.Float64bits(s62)
	trace.Slots[62] = Bounds{v62, v62}
	s63 := s62
	v63 := math.Float64bits(s63)
	trace.Slots[63] = Bounds{v63, v63}
	s64 := float64(s63 - s20)
	v64 := math.Float64bits(s64)
	trace.Slots[64] = Bounds{v64, v64}
	s65 := s64
	v65 := math.Float64bits(s65)
	trace.Slots[65] = Bounds{v65, v65}
	s66 := float64(s7 + s65)
	v66 := math.Float64bits(s66)
	trace.Slots[66] = Bounds{v66, v66}
	s67 := s66
	v67 := math.Float64bits(s67)
	trace.Slots[67] = Bounds{v67, v67}
	s68 := float64(s4 + s67)
	v68 := math.Float64bits(s68)
	trace.Slots[68] = Bounds{v68, v68}
	s69 := s68
	v69 := math.Float64bits(s69)
	trace.Slots[69] = Bounds{v69, v69}
	s70 := math.Float64frombits(0x40501fead4ea6e2b)
	v70 := math.Float64bits(s70)
	trace.Slots[70] = Bounds{v70, v70}
	s71 := math.Float64frombits(0x4094ea0000000000)
	v71 := math.Float64bits(s71)
	trace.Slots[71] = Bounds{v71, v71}
	s72 := float64(s70 * s69)
	v72 := math.Float64bits(s72)
	trace.Slots[72] = Bounds{v72, v72}
	s73 := s72
	v73 := math.Float64bits(s73)
	trace.Slots[73] = Bounds{v73, v73}
	s74 := float64(s73 + s71)
	v74 := math.Float64bits(s74)
	trace.Slots[74] = Bounds{v74, v74}
	s75 := s74
	v75 := math.Float64bits(s75)
	trace.Slots[75] = Bounds{v75, v75}
	return i32_trunc_sat_f64_s(math.Floor(s75)), trace, nil
}
