package intervalproof

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"go/ast"
	"go/constant"
	"go/format"
	"go/parser"
	"go/printer"
	"go/token"
	"math"
	"os"
	"strings"
)

func nodeText(node ast.Node) string {
	var out bytes.Buffer
	_ = printer.Fprint(&out, token.NewFileSet(), node)
	return out.String()
}

func normalizedFragment(source string) (string, error) {
	data, err := format.Source([]byte("package intervalproof\n" + source + "\n"))
	if err != nil {
		return "", fatal("format source fragment: %v", err)
	}
	return strings.TrimSpace(strings.TrimPrefix(string(data), "package intervalproof\n")), nil
}

func declaration(source string, fset *token.FileSet, file *ast.File, name string) (string, error) {
	for _, d := range file.Decls {
		if fn, ok := d.(*ast.FuncDecl); ok && fn.Name.Name == name {
			return strings.Clone(source[fset.Position(fn.Pos()).Offset:fset.Position(fn.End()).Offset]), nil
		}
	}
	return "", fatal("missing source function %s", name)
}

// Load is author preparation, outside construction timing. Full module/AST and
// binding maps are discarded; all strings retained by Graph have owned backing.
func Load(path string) (*Graph, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, fatal("read module: %v", err)
	}
	hash := sha256.Sum256(data)
	if hex.EncodeToString(hash[:]) != SourceHash {
		return nil, fatal("whole module SHA mismatch")
	}
	source := string(data)
	fset := token.NewFileSet()
	file, err := parser.ParseFile(fset, path, source, 0)
	if err != nil {
		return nil, fatal("parse module: %v", err)
	}
	fn, err := declaration(source, fset, file, "fn176")
	if err != nil {
		return nil, err
	}
	constructor, err := declaration(source, fset, file, "Xcocoon_sketch_new")
	if err != nil {
		return nil, err
	}
	for _, required := range []string{
		"uint64(i64(0x4094ea0000000000))", "uint64(i64(4634239110019182123))", "uint64(i64(0x3ff0400000000000))", "math.Float64bits(float64(0x1.04p-1022))",
	} {
		if !strings.Contains(constructor, required) {
			return nil, fatal("parameter constructor drift: %s", required)
		}
	}
	for _, required := range []string{
		"t15 := math.Float64frombits(load64(m.memory, uint64(uint32(v3))+48))",
		"t16 := math.Float64frombits(load64(m.memory, uint64(uint32(v3))+40))",
		"t27 := math.Float64frombits(load64(m.memory, uint64(uint32(v3))+56))",
	} {
		if strings.Count(fn, required) != 1 {
			return nil, fatal("mapping read binding drift")
		}
	}
	start := strings.Index(fn, "v6 = p18 + i32(614242)")
	if start < 0 {
		return nil, fatal("normal path marker drift")
	}
	endMark := "p17 = t26"
	end := strings.Index(fn[start:], endMark)
	if end < 0 {
		return nil, fatal("normal path marker drift")
	}
	end += start + len(endMark)
	normal := fn[start:end]
	affineMark := "v7 = i32_trunc_sat_f64_s(math.Floor(float64(float64(t16*p17) + t27)))"
	if strings.Count(fn, affineMark) != 1 {
		return nil, fatal("affine source drift")
	}
	var rawLines []string
	for _, line := range strings.Split(normal, "\n") {
		rawLines = append(rawLines, strings.TrimSpace(line))
	}
	raw := strings.Join(rawLines, "\n") + "\n" + affineMark + "\n"
	logStart := strings.Index(fn, "var p17 float64\n")
	if logStart < 0 {
		return nil, fatal("log region start")
	}
	logStart += len("var p17 float64\n")
	logEnd := strings.Index(fn[logStart:], "l5:\n")
	if logEnd < 0 {
		return nil, fatal("log region end")
	}
	logEnd += logStart + len("l5:\n")
	logFragment := "func OriginalLog(v2 float64) float64 {\nvar v1,v6 int32\nvar v16,v17 float64\nvar v19,v20 int64\nvar p17 float64\n" + fn[logStart:logEnd] + "return p17\n}"
	logSource, err := normalizedFragment(logFragment)
	if err != nil {
		return nil, err
	}
	saturation, err := declaration(source, fset, file, "i32_trunc_sat_f64_s")
	if err != nil {
		return nil, err
	}
	g := &Graph{SourceSHA: hash, Params: canonicalParams(), RawSnippet: strings.Clone(raw), LogSource: strings.Clone(logSource), SaturationSource: strings.Clone(saturation)}
	if err := derive(g); err != nil {
		return nil, err
	}
	if GraphBytes(g) > MaxGraphBytes {
		return nil, fatal("owned graph representation exceeds 16 KiB: %d", GraphBytes(g))
	}
	g.seal = graphSeal(g)
	if err := validateGraph(g); err != nil {
		return nil, err
	}
	return g, nil
}

type graphBuilder struct {
	graph *Graph
	names map[string]uint16
}

func (b *graphBuilder) emit(node Node) (uint16, error) {
	if b.graph.Count >= MaxSlots {
		return 0, fatal("graph slots")
	}
	if node.Op >= OpAdd && node.Op <= OpDiv {
		b.graph.Rounded++
		if b.graph.Rounded > MaxRounded {
			return 0, fatal("rounded graph nodes")
		}
	}
	id := b.graph.Count
	b.graph.Nodes[id] = node
	b.graph.Count++
	return id, nil
}

func compileConstant(expr ast.Expr) (constant.Value, bool) {
	switch e := expr.(type) {
	case *ast.BasicLit:
		if e.Kind != token.INT && e.Kind != token.FLOAT {
			return nil, false
		}
		v := constant.MakeFromLiteral(e.Value, e.Kind, 0)
		return v, v.Kind() != constant.Unknown
	case *ast.ParenExpr:
		return compileConstant(e.X)
	case *ast.UnaryExpr:
		if e.Op != token.ADD && e.Op != token.SUB {
			return nil, false
		}
		v, ok := compileConstant(e.X)
		if !ok {
			return nil, false
		}
		return constant.UnaryOp(e.Op, v, 0), true
	case *ast.CallExpr:
		id, ok := e.Fun.(*ast.Ident)
		if !ok || id.Name != "float64" || len(e.Args) != 1 {
			return nil, false
		}
		return compileConstant(e.Args[0])
	default:
		return nil, false
	}
}

func (b *graphBuilder) expression(expr ast.Expr) (uint16, error) {
	if value, ok := compileConstant(expr); ok {
		f, _ := constant.Float64Val(value)
		bits := math.Float64bits(f)
		if !finite(bits) {
			return 0, fatal("nonfinite source literal")
		}
		return b.emit(Node{Op: OpConst, Bits: bits})
	}
	switch e := expr.(type) {
	case *ast.ParenExpr:
		return b.expression(e.X)
	case *ast.Ident:
		id, ok := b.names[e.Name]
		if !ok {
			return 0, fatal("unbound scalar %s", e.Name)
		}
		return id, nil
	case *ast.UnaryExpr:
		id, err := b.expression(e.X)
		if err != nil {
			return 0, err
		}
		if e.Op == token.ADD {
			return b.emit(Node{Op: OpCopy, A: id})
		}
		if e.Op == token.SUB {
			return b.emit(Node{Op: OpNeg, A: id})
		}
		return 0, fatal("unary source operation")
	case *ast.BinaryExpr:
		left, err := b.expression(e.X)
		if err != nil {
			return 0, err
		}
		right, err := b.expression(e.Y)
		if err != nil {
			return 0, err
		}
		var op Op
		switch e.Op {
		case token.ADD:
			op = OpAdd
		case token.SUB:
			op = OpSub
		case token.MUL:
			op = OpMul
		case token.QUO:
			op = OpDiv
		default:
			return 0, fatal("binary source operation %s", e.Op)
		}
		return b.emit(Node{Op: op, A: left, B: right})
	case *ast.CallExpr:
		if id, ok := e.Fun.(*ast.Ident); ok && id.Name == "float64" && len(e.Args) == 1 {
			id, err := b.expression(e.Args[0])
			if err != nil {
				return 0, err
			}
			return b.emit(Node{Op: OpCopy, A: id})
		}
		if nodeText(e) == "math.Float64frombits(uint64(v19&i64(0xffffffff) | int64(uint32(v6&i32(0xfffff)+i32(1072079006)))<<32))" {
			return 0, nil
		}
		return 0, fatal("source call outside reduction/cast whitelist: %s", nodeText(e))
	default:
		return 0, fatal("unsupported source expression %T", expr)
	}
}

func derive(g *Graph) error {
	fset := token.NewFileSet()
	file, err := parser.ParseFile(fset, "selected.go", "package intervalproof\nfunc selected(){\n"+g.RawSnippet+"\n}", 0)
	if err != nil {
		return fatal("selected AST: %v", err)
	}
	fn := file.Decls[0].(*ast.FuncDecl)
	stmts := fn.Body.List
	if len(stmts) < 3 || nodeText(stmts[0]) != "v6 = p18 + i32(614242)" || nodeText(stmts[1]) != "v16 = float64(int32(uint32(v6)>>20) + v1)" {
		return fatal("normal reduction AST drift")
	}
	b := graphBuilder{graph: g, names: make(map[string]uint16)}
	_, err = b.emit(Node{Op: OpReduced})
	if err != nil {
		return err
	}
	_, err = b.emit(Node{Op: OpExponent})
	if err != nil {
		return err
	}
	b.names["v16"] = 1
	for index, stmt := range stmts[2:] {
		assign, ok := stmt.(*ast.AssignStmt)
		if !ok || len(assign.Lhs) != 1 || len(assign.Rhs) != 1 || (assign.Tok != token.ASSIGN && assign.Tok != token.DEFINE) {
			return fatal("selected assignment shape")
		}
		name, ok := assign.Lhs[0].(*ast.Ident)
		if !ok {
			return fatal("selected destination binding")
		}
		expr := assign.Rhs[0]
		if index == len(stmts)-3 {
			if name.Name != "v7" {
				return fatal("final affine binding")
			}
			sat, ok := expr.(*ast.CallExpr)
			if !ok || len(sat.Args) != 1 || nodeText(sat.Fun) != "i32_trunc_sat_f64_s" {
				return fatal("saturation binding")
			}
			floor, ok := sat.Args[0].(*ast.CallExpr)
			if !ok || len(floor.Args) != 1 || nodeText(floor.Fun) != "math.Floor" {
				return fatal("floor binding")
			}
			for _, p := range []struct {
				name string
				bits uint64
			}{{"t16", g.Params[1]}, {"t27", g.Params[3]}} {
				id, e := b.emit(Node{Op: OpConst, Bits: p.bits})
				if e != nil {
					return e
				}
				b.names[p.name] = id
			}
			expr = floor.Args[0]
		}
		id, err := b.expression(expr)
		if err != nil {
			return err
		}
		b.names[name.Name] = id
		if name.Name == "p17" {
			g.LogOutput = id
		}
		if name.Name == "v7" {
			g.Output = id
		}
	}
	return nil
}

// NativeSource mechanically emits the complete original log helper and original
// affine/Floor/saturation point path. The additional trace helper is a compiled
// source-derived graph diagnostic, not a new independent logarithm algorithm.
func NativeSource(g *Graph) ([]byte, error) {
	if err := validateGraph(g); err != nil {
		return nil, err
	}
	var out strings.Builder
	out.WriteString("package intervalproof\nimport \"math\"\n")
	out.WriteString("func i32(x int32) int32{return x}\nfunc i64(x int64) int64{return x}\n")
	out.WriteString(g.LogSource)
	out.WriteByte('\n')
	out.WriteString(g.SaturationSource)
	out.WriteByte('\n')
	fmt.Fprintf(&out, "func OriginalBin(value float64)int32{return i32_trunc_sat_f64_s(math.Floor(float64(float64(math.Float64frombits(%#x)*OriginalLog(value))+math.Float64frombits(%#x))))}\n", g.Params[1], g.Params[3])
	out.WriteString("func OriginalPointTrace(bits uint64)(int32,Trace,error){var trace Trace\n")
	out.WriteString("if bits<0x0010400000000000||bits>0x7fefffffffffffff||bits==0x3ff0000000000000{return 0,trace,unknown(ReasonDomain)}\n")
	out.WriteString("h:=uint64(uint32(bits>>32));a:=h+0x95f62;k:=int32(a>>20)-1023;reduced:=bits&0xffffffff|((a&0xfffff)+0x3fe6a09e)<<32\n")
	fmt.Fprintf(&out, "trace.Lo=bits;trace.Hi=bits;trace.Params=Params{%#x,%#x,%#x,%#x};trace.Exponent=k;trace.Carry=uint8(((h&0xfffff)+0x95f62)>>20);trace.Count=%d\n", g.Params[0], g.Params[1], g.Params[2], g.Params[3], g.Count)
	fmt.Fprintf(&out, "trace.SourceSHA=[32]byte{%s}\n", byteList(g.SourceSHA))
	for i := 0; i < int(g.Count); i++ {
		n := g.Nodes[i]
		var expression string
		switch n.Op {
		case OpReduced:
			expression = "math.Float64frombits(reduced)"
		case OpExponent:
			expression = "float64(k)"
		case OpConst:
			expression = fmt.Sprintf("math.Float64frombits(%#x)", n.Bits)
		case OpNeg:
			expression = fmt.Sprintf("-s%d", n.A)
		case OpCopy:
			expression = fmt.Sprintf("s%d", n.A)
		case OpAdd, OpSub, OpMul, OpDiv:
			symbol := map[Op]string{OpAdd: "+", OpSub: "-", OpMul: "*", OpDiv: "/"}[n.Op]
			expression = fmt.Sprintf("float64(s%d%s s%d)", n.A, symbol, n.B)
		default:
			return nil, fatal("native emitter node")
		}
		fmt.Fprintf(&out, "s%d:=%s;v%d:=math.Float64bits(s%d);trace.Slots[%d]=Bounds{v%d,v%d}\n", i, expression, i, i, i, i, i)
	}
	fmt.Fprintf(&out, "return i32_trunc_sat_f64_s(math.Floor(s%d)),trace,nil}\n", g.Output)
	data, err := format.Source([]byte(out.String()))
	if err != nil {
		return nil, fatal("native source format: %v", err)
	}
	return data, nil
}

func byteList(hash [32]byte) string {
	var result strings.Builder
	for _, v := range hash {
		fmt.Fprintf(&result, "%d,", v)
	}
	return result.String()
}
