// Package intervalproof is ignored, offline numerical evidence. It is not a
// production cache, compiler transformation, or runtime contract.
package intervalproof

import (
	"crypto/sha256"
	"encoding/binary"
	"errors"
	"fmt"
	"math"
	"math/big"
	mathbits "math/bits"
	"unsafe"
)

const (
	MaxSlots          = 256
	MaxRounded        = 96
	MaxCertificates   = 64
	MaxAttempts       = 320
	MaxGraphBytes     = 16 << 10
	MaxWorkspaceBytes = 64 << 10
	MaxBankBytes      = 4 << 10
	MaxIntegerBits    = 4096
	SourceHash        = "626550cafa323c490a6a2ec6b2b341656c40e223c7c84701e414078633dcc298"
	WasmHash          = "ae0119ca34206c2fcd8b69ae4e81421214417abb364d589c3afabcf16d8c6333"
)

type Params [4]uint64

var PinnedParams = Params{0x3ff0400000000000, 0x40501fead4ea6e2b, 0x0010400000000000, 0x4094ea0000000000}

func canonicalParams() Params {
	return Params{0x3ff0400000000000, 0x40501fead4ea6e2b, 0x0010400000000000, 0x4094ea0000000000}
}
func canonicalSourceSHA() [32]byte {
	return [32]byte{0x62, 0x65, 0x50, 0xca, 0xfa, 0x32, 0x3c, 0x49, 0x0a, 0x6a, 0x2e, 0xc6, 0xb2, 0xb3, 0x41, 0x65, 0x6c, 0x40, 0xe2, 0x23, 0xc7, 0xc8, 0x47, 0x01, 0xe4, 0x14, 0x07, 0x86, 0x33, 0xdc, 0xc2, 0x98}
}

type Op uint8

const (
	OpReduced Op = iota
	OpExponent
	OpConst
	OpNeg
	OpAdd
	OpSub
	OpMul
	OpDiv
	OpCopy
)

type Node struct {
	Bits uint64
	A, B uint16
	Op   Op
}

type Graph struct {
	Nodes                                   [MaxSlots]Node
	SourceSHA                               [32]byte
	Params                                  Params
	RawSnippet, LogSource, SaturationSource string
	Count, Rounded, Output, LogOutput       uint16
	seal                                    [32]byte
}

// Bounds encodes finite binary64 endpoints as bits, including signed zeros.
type Bounds struct{ Lo, Hi uint64 }

type Trace struct {
	Slots     [MaxSlots]Bounds
	Lo, Hi    uint64
	SourceSHA [32]byte
	Params    Params
	Exponent  int32
	Count     uint16
	Carry     uint8
}

type Work struct {
	Nodes, Rounded, EndpointOps, Conversions                    uint32
	Shifts, Comparisons, QuoRem, MaxIntegerBits, WorkspaceBytes uint32
}

type Budget struct{ Nodes, Rounded, Conversions, IntegerBits, WorkspaceBytes, GraphBytes uint32 }

var DefaultBudget = Budget{MaxSlots, MaxRounded, 2 * MaxRounded, MaxIntegerBits, MaxWorkspaceBytes, MaxGraphBytes}

type Certificate struct {
	Lo, Hi uint64
	Bin    int32
}

type Bank struct {
	Certificates [MaxCertificates]Certificate
	SourceSHA    [32]byte
	Params       Params
	Count        uint16
}

type Reason uint8

const (
	ReasonNone Reason = iota
	ReasonDomain
	ReasonCell
	ReasonParameters
	ReasonBudget
	ReasonDivision
	ReasonNonfinite
	ReasonBoundary
	ReasonFatal
)

func (r Reason) String() string {
	switch r {
	case ReasonNone:
		return "accepted"
	case ReasonDomain:
		return "domain"
	case ReasonCell:
		return "cell"
	case ReasonParameters:
		return "parameters"
	case ReasonBudget:
		return "budget"
	case ReasonDivision:
		return "division"
	case ReasonNonfinite:
		return "nonfinite"
	case ReasonBoundary:
		return "boundary"
	case ReasonFatal:
		return "fatal"
	default:
		return "invalid-reason"
	}
}

var ErrUnknown = errors.New("interval unknown")
var ErrFatal = errors.New("interval source/proof failure")

type UnknownError struct{ Reason Reason }

func (e *UnknownError) Error() string { return ErrUnknown.Error() + ": " + e.Reason.String() }
func (e *UnknownError) Unwrap() error { return ErrUnknown }
func unknown(r Reason) error          { return &UnknownError{Reason: r} }
func fatal(format string, args ...any) error {
	return fmt.Errorf("%w: %s", ErrFatal, fmt.Sprintf(format, args...))
}
func ReasonOf(err error) Reason {
	if err == nil {
		return ReasonNone
	}
	var e *UnknownError
	if errors.As(err, &e) {
		return e.Reason
	}
	return ReasonFatal // Unknown and fatal errors must never share a rejection category.
}

type Attempt struct {
	Lo, Hi           uint64
	Work             Work
	Bin              int32
	Seed, Refinement uint16
	Reason           Reason
}

type BankReport struct {
	Attempts        [MaxAttempts]Attempt
	Total           Work
	Count, Accepted uint16
}

// Observer sees exactly one transient trace. It may verify/export bounded
// numerical evidence, but retaining all traces is outside the builder budget.
type Observer func(Attempt, *Trace) error

func graphSeal(g *Graph) [32]byte {
	h := sha256.New()
	_, _ = h.Write(g.SourceSHA[:])
	var b [16]byte
	for _, p := range g.Params {
		binary.LittleEndian.PutUint64(b[:8], p)
		_, _ = h.Write(b[:8])
	}
	for _, n := range g.Nodes {
		binary.LittleEndian.PutUint64(b[:8], n.Bits)
		binary.LittleEndian.PutUint16(b[8:10], n.A)
		binary.LittleEndian.PutUint16(b[10:12], n.B)
		b[12] = byte(n.Op)
		_, _ = h.Write(b[:13])
	}
	for _, n := range []uint16{g.Count, g.Rounded, g.Output, g.LogOutput} {
		binary.LittleEndian.PutUint16(b[:2], n)
		_, _ = h.Write(b[:2])
	}
	for _, s := range []string{g.RawSnippet, g.LogSource, g.SaturationSource} {
		_, _ = h.Write([]byte(s))
	}
	var result [32]byte
	copy(result[:], h.Sum(nil))
	return result
}

func GraphBytes(g *Graph) uint32 {
	size := uint64(unsafe.Sizeof(*g))
	for _, text := range []string{g.RawSnippet, g.LogSource, g.SaturationSource} {
		length := uint64(len(text))
		if length > uint64(math.MaxUint32)-size {
			return math.MaxUint32
		}
		size += length
	}
	return uint32(size)
}

func validateGraph(g *Graph) error {
	if g == nil || g.Count < 2 || g.Count > MaxSlots || g.Rounded > MaxRounded || g.Output >= g.Count || g.LogOutput >= g.Count {
		return fatal("invalid graph shape")
	}
	if g.SourceSHA != canonicalSourceSHA() || g.Params != canonicalParams() || GraphBytes(g) > MaxGraphBytes || graphSeal(g) != g.seal {
		return fatal("graph identity/capacity drift")
	}
	var rounded uint16
	for i := 0; i < int(g.Count); i++ {
		n := g.Nodes[i]
		switch n.Op {
		case OpReduced:
			if i != 0 {
				return fatal("reduction binding")
			}
		case OpExponent:
			if i != 1 {
				return fatal("exponent binding")
			}
		case OpConst:
			if !finite(n.Bits) {
				return fatal("nonfinite constant")
			}
		case OpNeg, OpCopy:
			if int(n.A) >= i {
				return fatal("forward unary edge")
			}
		case OpAdd, OpSub, OpMul, OpDiv:
			if int(n.A) >= i || int(n.B) >= i {
				return fatal("forward arithmetic edge")
			}
			rounded++
		default:
			return fatal("unknown node")
		}
	}
	if rounded != g.Rounded {
		return fatal("rounded count drift")
	}
	return nil
}

func finite(bits uint64) bool { return bits&0x7ff0000000000000 != 0x7ff0000000000000 }

// cell proves bit-order preservation under the exact integer reduction. It
// deliberately rejects 1.0 even for a singleton: its shortcut is a separate path.
func cell(params Params, lo, hi uint64) (Bounds, int32, uint8, error) {
	if params != canonicalParams() {
		return Bounds{}, 0, 0, unknown(ReasonParameters)
	}
	if lo > hi || lo < 0x0010000000000000 || hi > 0x7fefffffffffffff || lo < params[2] {
		return Bounds{}, 0, 0, unknown(ReasonDomain)
	}
	if lo <= 0x3ff0000000000000 && hi >= 0x3ff0000000000000 {
		return Bounds{}, 0, 0, unknown(ReasonCell)
	}
	e0, e1 := lo>>52, hi>>52
	h0, h1 := uint32(lo>>32), uint32(hi>>32)
	c0, c1 := uint8((uint64(h0&0xfffff)+0x95f62)>>20), uint8((uint64(h1&0xfffff)+0x95f62)>>20)
	if e0 != e1 || c0 != c1 {
		return Bounds{}, 0, 0, unknown(ReasonCell)
	}
	a0, a1 := uint64(h0)+0x95f62, uint64(h1)+0x95f62
	if a0 > math.MaxInt32 || a1 > math.MaxInt32 || a0>>20 != a1>>20 {
		return Bounds{}, 0, 0, unknown(ReasonCell)
	}
	reduce := func(bits, a uint64) uint64 { return bits&0xffffffff | ((a&0xfffff)+0x3fe6a09e)<<32 }
	r0, r1 := reduce(lo, a0), reduce(hi, a1)
	// The reconstructed word differs by exactly the input word difference
	// within this exponent/carry cell; this also proves low-word transitions.
	if r1 < r0 || r1-r0 != hi-lo || !finite(r0) || !finite(r1) || r0>>63 != 0 {
		return Bounds{}, 0, 0, fatal("integer reduction relation")
	}
	return Bounds{r0, r1}, int32(a0>>20) - 1023, c0, nil
}

type calculator struct {
	budget Budget
	work   Work
}

func validBudget(b Budget) bool {
	return b.Nodes <= MaxSlots && b.Rounded <= MaxRounded && b.Conversions <= 2*MaxRounded && b.IntegerBits <= MaxIntegerBits && b.WorkspaceBytes <= MaxWorkspaceBytes && b.GraphBytes <= MaxGraphBytes
}

func (c *calculator) integer(n *big.Int) error {
	bits := uint32(n.BitLen())
	if bits > c.work.MaxIntegerBits {
		c.work.MaxIntegerBits = bits
	}
	if bits > c.budget.IntegerBits {
		return unknown(ReasonBudget)
	}
	return nil
}

func (c *calculator) preflight(bits int) error {
	if bits < 0 || uint32(bits) > c.budget.IntegerBits {
		return unknown(ReasonBudget)
	}
	return nil
}

func (c *calculator) shift(dst, src *big.Int, n int) error {
	if n < 0 {
		return fatal("negative integer shift")
	}
	if err := c.preflight(src.BitLen() + n); err != nil {
		return err
	}
	c.work.Shifts++
	dst.Lsh(src, uint(n))
	return c.integer(dst)
}

func (c *calculator) compare(a, b *big.Int) (int, error) {
	if err := c.integer(a); err != nil {
		return 0, err
	}
	if err := c.integer(b); err != nil {
		return 0, err
	}
	c.work.Comparisons++
	return a.Cmp(b), nil
}

func (c *calculator) rat(bits uint64) (*big.Rat, error) {
	if !finite(bits) {
		return nil, unknown(ReasonNonfinite)
	}
	exponent := int((bits >> 52) & 0x7ff)
	fraction := bits & ((1 << 52) - 1)
	initial := fraction
	if exponent != 0 {
		initial |= 1 << 52
	}
	if err := c.preflight(mathbits.Len64(initial)); err != nil {
		return nil, err
	}
	n := new(big.Int).SetUint64(initial)
	power := -1074
	if exponent != 0 {
		n.SetUint64(fraction | 1<<52)
		power = exponent - 1023 - 52
	}
	d := big.NewInt(1)
	if power >= 0 {
		if err := c.shift(n, n, power); err != nil {
			return nil, err
		}
	} else {
		if err := c.shift(d, d, -power); err != nil {
			return nil, err
		}
	}
	if bits>>63 != 0 {
		n.Neg(n)
	}
	if err := c.integer(n); err != nil {
		return nil, err
	}
	if err := c.integer(d); err != nil {
		return nil, err
	}
	return new(big.Rat).SetFrac(n, d), nil
}

func (c *calculator) primitive(op Op, a, b *big.Rat) (*big.Rat, error) {
	// Preflight unreduced products and addition carry, before math/big allocates
	// those values. These are caps on explicit arithmetic, not library scratch.
	var nb, db int
	switch op {
	case OpAdd, OpSub:
		nb = max(a.Num().BitLen()+b.Denom().BitLen(), b.Num().BitLen()+a.Denom().BitLen()) + 1
		db = a.Denom().BitLen() + b.Denom().BitLen()
	case OpMul:
		nb = a.Num().BitLen() + b.Num().BitLen()
		db = a.Denom().BitLen() + b.Denom().BitLen()
	case OpDiv:
		if b.Sign() == 0 {
			return nil, unknown(ReasonDivision)
		}
		nb = a.Num().BitLen() + b.Denom().BitLen()
		db = a.Denom().BitLen() + b.Num().BitLen()
	default:
		return nil, fatal("not a rational binary operation")
	}
	if err := c.preflight(nb); err != nil {
		return nil, err
	}
	if err := c.preflight(db); err != nil {
		return nil, err
	}
	c.work.EndpointOps++
	r := new(big.Rat)
	switch op {
	case OpAdd:
		r.Add(a, b)
	case OpSub:
		r.Sub(a, b)
	case OpMul:
		r.Mul(a, b)
	case OpDiv:
		r.Quo(a, b)
	}
	if err := c.integer(r.Num()); err != nil {
		return nil, err
	}
	if err := c.integer(r.Denom()); err != nil {
		return nil, err
	}
	return r, nil
}

func (c *calculator) ratCmp(a, b *big.Rat) (int, error) {
	if err := c.preflight(a.Num().BitLen() + b.Denom().BitLen()); err != nil {
		return 0, err
	}
	if err := c.preflight(b.Num().BitLen() + a.Denom().BitLen()); err != nil {
		return 0, err
	}
	x := new(big.Int).Mul(a.Num(), b.Denom())
	y := new(big.Int).Mul(b.Num(), a.Denom())
	return c.compare(x, y)
}

// directed computes floor/ceil in binary64 directly from an exact rational.
// There is one bounded exponent comparison, at most four shifts/eight
// comparisons and one QuoRem per conversion. No neighboring-float search.
func (c *calculator) directed(r *big.Rat, upward bool) (uint64, error) {
	if c.work.Conversions >= c.budget.Conversions {
		return 0, unknown(ReasonBudget)
	}
	c.work.Conversions++
	beforeShift, beforeCmp, beforeQuo := c.work.Shifts, c.work.Comparisons, c.work.QuoRem
	if err := c.integer(r.Num()); err != nil {
		return 0, err
	}
	if err := c.integer(r.Denom()); err != nil {
		return 0, err
	}
	n := new(big.Int).Abs(r.Num())
	d := new(big.Int).Set(r.Denom())
	if err := c.integer(n); err != nil {
		return 0, err
	}
	if err := c.integer(d); err != nil {
		return 0, err
	}
	if n.Sign() == 0 {
		if upward {
			return 0, nil
		}
		return 1 << 63, nil
	}
	negative := r.Sign() < 0
	// Rounding magnitude upward is reversed for negative rational values.
	ceilMagnitude := upward != negative
	e := n.BitLen() - d.BitLen()
	left, right := new(big.Int).Set(n), new(big.Int).Set(d)
	if e >= 0 {
		if err := c.shift(right, right, e); err != nil {
			return 0, err
		}
	} else {
		if err := c.shift(left, left, -e); err != nil {
			return 0, err
		}
	}
	cmp, err := c.compare(left, right)
	if err != nil {
		return 0, err
	}
	if cmp < 0 {
		e--
	}
	if e > 1023 {
		return 0, unknown(ReasonNonfinite)
	}
	unit := e - 52
	if e < -1022 {
		unit = -1074
	}
	numerator, denominator := new(big.Int).Set(n), new(big.Int).Set(d)
	if unit >= 0 {
		if err := c.shift(denominator, denominator, unit); err != nil {
			return 0, err
		}
	} else {
		if err := c.shift(numerator, numerator, -unit); err != nil {
			return 0, err
		}
	}
	q, rem := new(big.Int), new(big.Int)
	c.work.QuoRem++
	q.QuoRem(numerator, denominator, rem)
	if ceilMagnitude && rem.Sign() != 0 {
		if err := c.preflight(q.BitLen() + 1); err != nil {
			return 0, err
		}
		q.Add(q, big.NewInt(1))
	}
	if err := c.integer(q); err != nil {
		return 0, err
	}
	if err := c.integer(rem); err != nil {
		return 0, err
	}
	if q.BitLen() > 54 {
		return 0, fatal("rounder significand")
	}
	magnitude := q.Uint64()
	var bits uint64
	if e < -1022 {
		if magnitude > 1<<52 {
			return 0, fatal("rounder subnormal significand")
		}
		bits = magnitude
	} else {
		if magnitude == 1<<53 {
			magnitude >>= 1
			e++
		}
		if e > 1023 {
			return 0, unknown(ReasonNonfinite)
		}
		if magnitude < 1<<52 || magnitude >= 1<<53 {
			return 0, fatal("rounder normal significand")
		}
		bits = uint64(e+1023)<<52 | (magnitude - (1 << 52))
	}
	if negative {
		bits |= 1 << 63
	}
	if c.work.Shifts-beforeShift > 4 || c.work.Comparisons-beforeCmp > 8 || c.work.QuoRem-beforeQuo > 1 {
		return 0, fatal("rounder operation budget")
	}
	return bits, nil
}

func (c *calculator) transfer(op Op, a, b Bounds) (Bounds, error) {
	alo, ahi := math.Float64frombits(a.Lo), math.Float64frombits(a.Hi)
	blo, bhi := math.Float64frombits(b.Lo), math.Float64frombits(b.Hi)
	if !finite(a.Lo) || !finite(a.Hi) || !finite(b.Lo) || !finite(b.Hi) || alo > ahi || blo > bhi {
		return Bounds{}, unknown(ReasonNonfinite)
	}
	if op == OpDiv && blo <= 0 && bhi >= 0 {
		return Bounds{}, unknown(ReasonDivision)
	}
	av0, err := c.rat(a.Lo)
	if err != nil {
		return Bounds{}, err
	}
	av1, err := c.rat(a.Hi)
	if err != nil {
		return Bounds{}, err
	}
	bv0, err := c.rat(b.Lo)
	if err != nil {
		return Bounds{}, err
	}
	bv1, err := c.rat(b.Hi)
	if err != nil {
		return Bounds{}, err
	}
	var low, high *big.Rat
	if op == OpAdd || op == OpSub {
		if op == OpSub {
			bv0, bv1 = bv1, bv0
		}
		low, err = c.primitive(op, av0, bv0)
		if err != nil {
			return Bounds{}, err
		}
		high, err = c.primitive(op, av1, bv1)
		if err != nil {
			return Bounds{}, err
		}
	} else {
		for _, av := range [2]*big.Rat{av0, av1} {
			for _, bv := range [2]*big.Rat{bv0, bv1} {
				r, e := c.primitive(op, av, bv)
				if e != nil {
					return Bounds{}, e
				}
				if low == nil {
					low, high = r, r
					continue
				}
				cmp, e := c.ratCmp(r, low)
				if e != nil {
					return Bounds{}, e
				}
				if cmp < 0 {
					low = r
				}
				cmp, e = c.ratCmp(r, high)
				if e != nil {
					return Bounds{}, e
				}
				if cmp > 0 {
					high = r
				}
			}
		}
	}
	lo, err := c.directed(low, false)
	if err != nil {
		return Bounds{}, err
	}
	hi, err := c.directed(high, true)
	if err != nil {
		return Bounds{}, err
	}
	return Bounds{lo, hi}, nil
}

// Explicit rational scratch has at most 32 integer slots of 4096 bits. Go
// math/big allocation/internal scratch remains outside this logical ledger.
const logicalIntegerSlots = 32

// The ledger includes the complete builder/report and two trace images for
// the Certify return handoff. Returning the final bank/report reserves two
// images after the transient rational workspace is dead. This is logical data
// accounting, not a bound on compiler ABI stack copies, RSS or math/big internals.
// Rational slots count explicit headers and maximum limb capacity, including
// decoder/conversion temporaries; no rational operation history is retained.
func WorkspaceBytes() uint32 {
	bank := uint32(unsafe.Sizeof(Bank{}))
	report := uint32(unsafe.Sizeof(BankReport{}))
	active := 2*uint32(unsafe.Sizeof(Trace{})) + bank + report + uint32(unsafe.Sizeof(calculator{})) + logicalIntegerSlots*(MaxIntegerBits/8+uint32(unsafe.Sizeof(big.Int{})))
	return max(active, 2*(bank+report))
}

func Certify(g *Graph, params Params, lo, hi uint64, budget Budget) (Certificate, Trace, Work, error) {
	var trace Trace
	var work Work
	if err := validateGraph(g); err != nil {
		return Certificate{}, trace, work, err
	}
	workspace := WorkspaceBytes()
	work.WorkspaceBytes = workspace
	if !validBudget(budget) || uint32(g.Count) > budget.Nodes || uint32(g.Rounded) > budget.Rounded || GraphBytes(g) > budget.GraphBytes || workspace > budget.WorkspaceBytes {
		return Certificate{}, trace, work, unknown(ReasonBudget)
	}
	reduced, exponent, carry, err := cell(params, lo, hi)
	if err != nil {
		return Certificate{}, trace, work, err
	}
	trace.Lo, trace.Hi, trace.Params, trace.SourceSHA, trace.Exponent, trace.Carry = lo, hi, params, g.SourceSHA, exponent, carry
	c := calculator{budget: budget, work: work}
	for i := 0; i < int(g.Count); i++ {
		n := g.Nodes[i]
		var result Bounds
		switch n.Op {
		case OpReduced:
			result = reduced
		case OpExponent:
			bits := math.Float64bits(float64(exponent))
			result = Bounds{bits, bits}
		case OpConst:
			result = Bounds{n.Bits, n.Bits}
		case OpCopy:
			result = trace.Slots[n.A]
		case OpNeg:
			a := trace.Slots[n.A]
			result = Bounds{a.Hi ^ 1<<63, a.Lo ^ 1<<63}
		case OpAdd, OpSub, OpMul, OpDiv:
			c.work.Rounded++
			result, err = c.transfer(n.Op, trace.Slots[n.A], trace.Slots[n.B])
		default:
			err = fatal("unknown transfer node")
		}
		c.work.Nodes++
		if err != nil {
			return Certificate{}, trace, c.work, err
		}
		trace.Slots[i] = result
		trace.Count = uint16(i + 1)
	}
	end := trace.Slots[g.Output]
	lower, upper := math.Float64frombits(end.Lo), math.Float64frombits(end.Hi)
	if !finite(end.Lo) || !finite(end.Hi) || lower > upper {
		return Certificate{}, trace, c.work, unknown(ReasonNonfinite)
	}
	k := math.Floor(lower)
	if k <= math.MinInt32 || k >= math.MaxInt32 || upper >= k+1 {
		return Certificate{}, trace, c.work, unknown(ReasonBoundary)
	}
	return Certificate{lo, hi, int32(k)}, trace, c.work, nil
}

func Point(g *Graph, params Params, bits uint64) (int32, Trace, error) {
	var trace Trace
	if err := validateGraph(g); err != nil {
		return 0, trace, err
	}
	r, k, carry, err := cell(params, bits, bits)
	if err != nil {
		return 0, trace, err
	}
	trace.Lo, trace.Hi, trace.SourceSHA, trace.Params, trace.Exponent, trace.Carry = bits, bits, g.SourceSHA, params, k, carry
	for i := 0; i < int(g.Count); i++ {
		n := g.Nodes[i]
		a, b := math.Float64frombits(trace.Slots[n.A].Lo), math.Float64frombits(trace.Slots[n.B].Lo)
		var value float64
		switch n.Op {
		case OpReduced:
			value = math.Float64frombits(r.Lo)
		case OpExponent:
			value = float64(k)
		case OpConst:
			value = math.Float64frombits(n.Bits)
		case OpCopy:
			value = a
		case OpNeg:
			value = -a
		case OpAdd:
			value = float64(a + b)
		case OpSub:
			value = float64(a - b)
		case OpMul:
			value = float64(a * b)
		case OpDiv:
			value = float64(a / b)
		default:
			return 0, trace, fatal("point node")
		}
		v := math.Float64bits(value)
		trace.Slots[i] = Bounds{v, v}
		trace.Count = uint16(i + 1)
	}
	f := math.Floor(math.Float64frombits(trace.Slots[g.Output].Lo))
	if !finite(math.Float64bits(f)) || f <= math.MinInt32 || f >= math.MaxInt32 {
		return 0, trace, unknown(ReasonNonfinite)
	}
	return int32(f), trace, nil
}

func Seeds() [MaxCertificates]uint64 {
	var result [MaxCertificates]uint64
	first := [16]float64{42, 43, 0.5, 2, 16, 64, 256, 4096, 1000000, 1000001, 1e-12, 1e-11, 1e12, 1e100, 1e-100, 1e300}
	for i, v := range first {
		result[i] = math.Float64bits(v)
	}
	exponents := [16]int{-1000, -900, -600, -300, -30, -1, 0, 1, 5, 10, 20, 40, 100, 300, 600, 1000}
	fractions := [3]uint64{0x2000000000000, 0x8000000000000, 0xe000000000000}
	index := 16
	for _, e := range exponents {
		for _, f := range fractions {
			result[index] = uint64(e+1023)<<52 | f
			index++
		}
	}
	return result
}

func addWork(total *Work, w Work) {
	total.Nodes += w.Nodes
	total.Rounded += w.Rounded
	total.EndpointOps += w.EndpointOps
	total.Conversions += w.Conversions
	total.Shifts += w.Shifts
	total.Comparisons += w.Comparisons
	total.QuoRem += w.QuoRem
	total.MaxIntegerBits = max(total.MaxIntegerBits, w.MaxIntegerBits)
	total.WorkspaceBytes = max(total.WorkspaceBytes, w.WorkspaceBytes)
}

func BuildBank(g *Graph, budget Budget, observe Observer) (Bank, BankReport, error) {
	var bank Bank
	var report BankReport
	if err := validateGraph(g); err != nil {
		return bank, report, err
	}
	if unsafe.Sizeof(bank) > MaxBankBytes {
		return bank, report, fatal("bank layout exceeds bound")
	}
	if !validBudget(budget) || WorkspaceBytes() > budget.WorkspaceBytes || GraphBytes(g) > budget.GraphBytes {
		return bank, report, unknown(ReasonBudget)
	}
	bank.SourceSHA, bank.Params = g.SourceSHA, g.Params
	for seed, bits := range Seeds() {
		for refinement := 0; refinement <= 4; refinement++ {
			if report.Count >= MaxAttempts {
				return bank, report, fatal("bank attempt bound")
			}
			width := uint64(1) << uint(40-refinement)
			if bits < width || bits > math.MaxUint64-width {
				return bank, report, fatal("frozen seed endpoint overflow")
			}
			lo, hi := bits-width, bits+width
			cert, trace, work, err := Certify(g, g.Params, lo, hi, budget)
			if err != nil && !errors.Is(err, ErrUnknown) {
				return bank, report, err
			}
			attempt := Attempt{Lo: lo, Hi: hi, Work: work, Bin: cert.Bin, Seed: uint16(seed), Refinement: uint16(refinement), Reason: ReasonOf(err)}
			report.Attempts[report.Count] = attempt
			report.Count++
			addWork(&report.Total, work)
			if observe != nil {
				if e := observe(attempt, &trace); e != nil {
					return bank, report, fatal("observer: %v", e)
				}
			}
			if err != nil {
				continue
			}
			for j := 0; j < int(bank.Count); j++ {
				other := bank.Certificates[j]
				if cert.Lo <= other.Hi && other.Lo <= cert.Hi && cert.Bin != other.Bin {
					return bank, report, fatal("contradictory certificate overlap")
				}
			}
			if bank.Count >= MaxCertificates {
				return bank, report, fatal("certificate bound")
			}
			bank.Certificates[bank.Count] = cert
			bank.Count++
			report.Accepted++
			break
		}
	}
	return bank, report, nil
}

func Lookup(bank *Bank, sourceSHA [32]byte, params Params, bits uint64) (int32, bool) {
	if bank == nil || bank.Count > MaxCertificates || sourceSHA != canonicalSourceSHA() || sourceSHA != bank.SourceSHA || params != bank.Params || params != canonicalParams() || bits < params[2] || bits > 0x7fefffffffffffff {
		return 0, false
	}
	for i := 0; i < int(bank.Count); i++ {
		cert := bank.Certificates[i]
		if bits >= cert.Lo && bits <= cert.Hi {
			return cert.Bin, true
		}
	}
	return 0, false
}

func BankBytes(bank *Bank) ([]byte, error) {
	if bank == nil || bank.Count > MaxCertificates {
		return nil, fatal("invalid bank serialization")
	}
	n := 66 + 20*int(bank.Count)
	if uintptr(n)+unsafe.Sizeof(*bank) > MaxBankBytes {
		return nil, fatal("retained bank/output budget")
	}
	data := make([]byte, n)
	copy(data[:32], bank.SourceSHA[:])
	for i, p := range bank.Params {
		binary.LittleEndian.PutUint64(data[32+i*8:40+i*8], p)
	}
	binary.LittleEndian.PutUint16(data[64:66], bank.Count)
	for i := 0; i < int(bank.Count); i++ {
		offset := 66 + 20*i
		cert := bank.Certificates[i]
		binary.LittleEndian.PutUint64(data[offset:offset+8], cert.Lo)
		binary.LittleEndian.PutUint64(data[offset+8:offset+16], cert.Hi)
		binary.LittleEndian.PutUint32(data[offset+16:offset+20], uint32(cert.Bin))
	}
	return data, nil
}
