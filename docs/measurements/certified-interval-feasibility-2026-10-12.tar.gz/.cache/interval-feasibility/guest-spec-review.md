# Guest specification review

Reviewed `docs/certified-interval-feasibility.md` before implementation or the
specification commit. Read-only source inspection plus this ignored note only;
no builds, tests, profiles, measurements or tracked edits.

## Verdict

The core numerical guarantee is sufficient for a private offline experiment.
An inclusive input-bit interval must remain in a proven original exponent/carry
cell, exclude exact 1.0 and below-threshold inputs, and enclose every rounded
source operation. Requiring the final finite enclosure to be entirely inside
one nonsaturating `[k,k+1)` proves one logical bin, including for negative k.
It does not assume endpoint-log or mathematical-ln monotonicity. Correlation,
unknown branches, unsupported identities and budget failures conservatively
reject; no cache or guest integration is proposed.

The four parameter words agree with current constructor stores and later
resource copies. Gamma is configuration/encoding identity without inventing a
new hot-path read. Existing threshold/multiplier/offset positions, counters,
store collapse, errors and resource lifetime remain future integration
obligations rather than being silently certified by this pure proof.

The source normal reduction uses positive high words at most `0x7fefffff`.
Adding `0x95f62` remains below `0x80000000`; the masked high-word construction
also remains positive finite. Within constant original exponent and carry,
the reconstructed bit word is affine and ordered in the input word. This
justifies reduction endpoint bounds independently of the floating logarithm.
Intervals across the mantissa seam `0x6a09e` reject. All decimal/hex constants,
temporary versions and explicit roundings remain source-derived.

## Clarifications requested before signing

1. Define independent trace verification as reconstruction from the pinned
   graph, exact input bounds and parameter tuple. It recomputes branch/reduction
   facts, node operands, exact rational extrema and directed/nearest bounds;
   it never accepts a constructor trace as an unverified operand source.
   Separate quotient/remainder rounding is useful, but a nearest-only point
   checker is not by itself an independent enclosure checker. Avoid sharing
   the constructor's directed converter/extremum implementation. Shared source
   identity and declarative graph are appropriate; arithmetic checks remain
   separate.
2. State that 320 attempts bounds one complete registered 64-seed bank
   construction, including all failed refinements. Finite adversarial and
   every-exponent proof drivers should have their own fixed/reported limits;
   they must never add seeds or populate/retune the measured bank. Otherwise
   the global-looking attempt rule is ambiguous beside the thousands of
   possible normal-exponent tests. Point-only checks can remain distinct from
   candidate construction, but record that distinction.
3. Define the four-cell nonvacuity rule as four distinct original exponent
   fields, or explicitly choose exponent/carry pairs. The current draft's
   wording permits both readings. The registered seeds support the stronger
   original-exponent interpretation without expansion.

These clarify the executable/accounting proof; they do not broaden the domain
or change the chosen finite budget.

## Finite feasibility and proof limits

The seed count is exactly 64: 16 explicit values plus 16 exponents times three
fractions. Initial plus four halvings yields at most five attempts each.
Powers of two such as 0.5, 2, 16 and 64 can remain rejected at all symmetric
widths because they straddle original exponent boundaries; this is expected
negative coverage, not permission to clip or move them. The nearby corpus is
exactly the 8,192 successive bit words starting at Float64bits(42), so the
registered 42 request is the natural nonvacuity witness if it certifies.
That is a prescribed outcome test, not a guarantee that dependency widening
will allow it. A failure at the limits completes the experiment.

The bank's 4 KiB and graph/workspace caps account for fixed-array capacity,
padding and metadata on both architectures. Exact-rational temporary heap is
honestly excluded from a hard process-memory claim and must be reported. Every
primitive starts from finite binary64 endpoints, so intermediate rational
magnitude has a finite conservative bound before rounding back; the explicit
4,096-bit guard must also cover conversion/comparison intermediates or classify
them in a separate enforced ledger. No huge precision growth may hide behind
the element count.

The three oracle scopes are appropriate: source-derived universal enclosure
argument, separately rounded exact point/primitive checks, and unchanged
original-Wasm singleton logical-bin evidence. Finite interior checks are not
presented as exhausting all represented mantissas. Fresh singleton resources
avoid collapse masking an incorrect logical bin. Existing guest full-state,
atomic errors, poison and shutdown tests validate unchanged production and
remain explicitly separate from a nonexistent cached guest implementation.

The mutant requirements are meaningful if each has a real numerical witness:
wrong outward/signed extrema, wrong reduction carry, inclusive upper boundary,
wrong bin/configuration, negative truncation, and acceptance after uncertainty
or budget failure. Compile/startup failures must not satisfy semantic rejection;
source/constant drift has its own explicit rejection category. Both actual
native amd64 and 386 should execute these cases before any cost measurements.

The cost/locality plan correctly labels a static offline bank, setup and
verification costs, misses and unknown reasons. It does not infer on-demand
construction, cache eviction, full-call scalar improvement, application
traffic or M1 qualification. Proceed only after the reviewed private spec is
committed. No production predicate or public API approval is implied.

## Final readiness recheck

The parent applied all requested clarifications before signing. The checker
independently reconstructs branch/reduction facts, operands, signed corner
extrema and directed bounds from the pinned source/graph and request; it does
not share the constructor's directed converter or trust emitted traces. The
320-attempt limit is per fixed-bank construction, with separately bounded
non-tuning proof drivers. Nonvacuity uses four distinct original exponent
fields. Integer preflight guards cover unreduced/scaling/comparison/rounder
temporaries, with at most 192 directed conversions per candidate and explicit
bounded shift/comparison/quotient work. Trace capacity shares the workspace
budget and retains binary64 bounds/IDs rather than rational histories.

Approved for signing the private offline specification. No remaining guest
correctness/specification blocker was found. No implementation, builds, tests
or measurements were run for the recheck; all guest tools are stopped.
