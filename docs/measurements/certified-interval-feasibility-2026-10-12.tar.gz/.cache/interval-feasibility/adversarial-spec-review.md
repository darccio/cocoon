# Adversarial private feasibility specification review

Reviewed the pre-implementation draft against the current pinned fn176 expression, constructor/boundary evidence, entry requirements and the independently audited structural-ceiling outcome. Read-only source/document/reference checks only; no code/proof/bench/test/lint/profile or tracked edits. Main/origin compare0/0 at aeaf01b and the only tracked-tree addition is the draft private document.

The scope is substantially narrower than production and is appropriate: an ExactRat OFFLINE certificate builder for one exact four-word configuration, plus independent checking and original compiled/Wasm point witnesses. No native proposer, actual cache, caller substitution, generic predicate/publiccontract or fullscalar gain is promised. Universal containment applies to every representable input inside each accepted interval; point/Wasm histories are supplementary evidence. A finite verified bank is not a sound on-demand constructor/consumer integration by inference. Expensive construction/checking, transient math/big heap and immutable prebuilt-bank locality are honestly separated.

The proposed normal-cell transformation is correct under stated constraints. H+0x95f62 has no signed32 wrap across positive finite NORMAL input highwords; fixed original exponent and carry tag make reconstruction an increasing bit transformation. Mantissa highword0x6a09e is the carry seam. Restricting at exact1, exponent boundaries and carry crossings is conservative. The default minimum threshold must remain an explicit input precondition; below it is a zero-count/no-bin branch. Exact parameter bits/source identities and the gamma-asidentity-only distinction match current source. All reassignment/explicit rounding boundaries and the final multiply-then-add/Floor/saturating semantics must remain in the graph.

Exact real corner extrema followed by directed binary64 rounding can conservatively enclose the actual nearest-even operations; intervals may widen and fail. Signed multiplication/division extrema, denominator zero exclusion, underflow/zeros/overflow and strictfinal[k,k+1) handling are correct declared requirements. Negative binfloor must not become truncation. Correlation cannot justify narrowing. Local officialGo1.26.8go_spec.html confirms explicitfloat conversions prevent omitted rounding/fusion; public Go/Wasm primary references were read but are not substitutes for pinned local compiler/source proof. Source-derived graph/constants and current constructor output still need executable validation after the signed checkpoint.

The hard seed/width/refinement policy is useful preregistration. Several power-of-two seeds necessarily straddle an original exponent boundary and can never certify under symmetric halvings; record those intentional failures rather than clipping/retuning. Nonvacuity requires16nonsingletoncertificates acrossfourcells, both bin signs and one covering the whole8192NearbyUniqueCycle, so singleton/point-only proofs cannot pass. Define the cell identifier as the original exponent plus normalization carry tag. A conservative accepted interval need not place its neighboring outside point into a different bin; outside means uncertified by that certificate, not a true-bin transition.

Two required pre-commit clarifications were sent to root:

1. Independent checker scope. A separate nearest-even quotient/remainder rounder alone does not validate the builder's chosen extrema or extracted graph. Require it to validate source-to-graph operators/edge bindings/constants/versions, branch/reduction assumptions and every trace node from previously verified operands. For multiplication/division independently consider allfour signed corner results, rather than rounding whichever extrema the builder supplied. Reject missing/duplicate/out-of-order nodes, altered operands/ops/constants/parameters and incomplete traces. Sharing arbitrary-precision integer infrastructure is fine; sharing the builder's selection/transfer/rounding implementation would weaken independence. Signed zero metadata must be modelled where needed or prove no sign-sensitive observation in accepted arithmetic.
2. Work/storage cap enforcement. Node counts and4096-bit values with conversionCOUNTERS do not by themselves bound an arbitrary conversion/search loop. Pin directed-rounder normalization/bisection/shift iteration limits and a total conversion/check operation bound, or a concrete algebraic bound derived from fixed input widths. Check conservative bit-size bounds BEFORE forming unreduced products/cross-products/scaling/rounder temporaries; include those intermediates in4096bits, not just reduced finalRat values. Exhaustion must prevent publication and preserve ledger/rejection evidence. Specify what64KiBlogicalworkspace/trace counts and when capacity/padding is checked; stream per-certificate archived traces so64retainedtraces are not silently held in the4KiBnumericbank. Math/big transientheap remains explicitly outside a hardprocess bound.

Additional classification clarity: malformed/unsupported request, parameter/version mismatch, branch seam or budget exhaustion produces uncertainty; source/parser/graph/constant drift or contradictory overlap is fatal invalid experiment/evidence. This distinction is implied in separate passages but should be explicit to prevent generic uncertainty from hiding a changed pinned source. Count all request attempts including early rejection, overlap checks and conversion work. The independentchecker's own costs/bounds are reported separately, not hidden as free cheap-construction validation.

No additional numerical strategy expansion is requested. With these clarifications, the private spec can be committed for the ExactRat proof phase. Applied implementation still needs adversarial audit before retaining any proof or starting isolated timings. Every semantic mutant must actually compile and fail a named numerical/checker assertion; in particular an inward rounding mutant must have a crafted failing case. Source/version rejection is a separate category, not a substitute for numerical mutant effectiveness.

Future cost scopes should include all fixedbank attempts and failed/refined requests, explicit requiredverification and finite allocations; immutablebankcoverage is offline locality only, without cache hits/eviction/on-demand fill claims. Use fixedcorpora and independentboundaries, report miss-heavy/broad/negative effects and retain every failure. No fullscalar/M1/cache/publiccontract approval follows; unchangedproduction gates do not qualify ignoredoffline code or integration. Generic production eligibility and ABI3memory/fault/ownership/drain obligations remain separate laterproofs.

Status: pending root's explicit checker/cap clarifications and final applied reread before the specification checkpoint. All reviewer tools stop after this note/report.

Reviewed identities:

```json
{
  "docs/certified-interval-feasibility.md": "cfaa42706f421f032cebd36d6706eb3f307cad46e1db28d71b496a41d4bba7df",
  "examples/datadog/go/dd/internal/wasm/module.go": "626550cafa323c490a6a2ec6b2b341656c40e223c7c84701e414078633dcc298",
  "examples/datadog/go/dd/bin_math_test.go": "ead973b7020bedec6fbac658be23b79fee2d40a0cb6096d4ec70acd5e75de3a6",
  "examples/datadog/go/dd/bin_reuse_bench_test.go": "aee2461dbc412268372a620863600f95bb6c3e6ab3cc934d6c4a7e514d73de2a",
  ".cache/toolchains/go1.26.8/go/doc/go_spec.html": "e5806989624c1e9dd32bddaedd2f70a1dd208295cb6d0ff72b02625b2cd6f592"
}
```

Primary references checked: https://go.dev/ref/spec#Floating_point_operators and https://webassembly.github.io/spec/core/exec/numerics.html#floating-point-operations . No historical-compiler claim rests on current web pages alone.


## Final applied clarification review

APPROVE the private specification checkpoint after root's required restage/exact snapshot validation. No numerical/scope/cap-description blocker remains in the final draft; applied proof implementation and all measured claims remain unapproved until their own review.

Independence now explicitly covers graph/source binding, previous verified operand slots, all signed corner combinations and full trace reconstruction. It rejects trusting the constructor's chosen extrema or sharing its directed rounder; source/graph drift is fatal while unsupported requests/budget exhaustion are uncertain. This closes the shared-extrema/false-independence concern without promising production generality.

Caps now include at most192directed conversions per candidate and per conversion at most4checked shifts/8comparisons/1QuoRem, no search/refinement loop. The4096bit bound includes unreduced/scaled/comparison intermediates with conservative preflight before growth. Explicit math/big internals/allocations are recorded reference machinery, not a hardCPU/wall/processheap guarantee. The64KiBlogicalworkspace includes its single binary trace; no Rat history or all64traces may be hidden in the4KiBbank. Graph16KiB remains separately bounded. Everyearly rejection/refinement consumes the320-per-bank ledger.

Verification driver caps and their separate non-tuning purpose are explicit:16384whole-graph checks,262144tiny concrete members and2048originalWasm singletons per native architecture. Implementation must keep all relevant ledgers, including overlapping work categories, and report actual counts/rejections rather than treating a limit as observed work. The16certificate/non-singleton/bothlogicalsigns/Nearby8192nonvacuity rule now names fourdistinct ORIGINAL exponent fields, so carry-tag diversity alone cannot pass.

No seed/policy/budget retuning follows proof outcomes. Some power-of-two requests necessarily reject under the preregistered symmetric no-clipping policy; those remain expected negatives. ExactRat builder, independent verification, compiled point traces, originalWasm finite witnesses and immutable offline bankcoverage remain distinct scopes. Expensive construction/verification and setup are visible before any future lookup/proposer/cache claim. Publiccontracts/productionintegration/M1 remain outside this checkpoint.

Root reports the earlier staged test started before these edits and will restage/retest the FINAL bytes. This approval does not claim that later exact-stage validation or signing has happened. No proof code or measurement exists yet. All reviewer tools STOPPED after this note/report.

Final spec SHA-256: cfaa42706f421f032cebd36d6706eb3f307cad46e1db28d71b496a41d4bba7df
