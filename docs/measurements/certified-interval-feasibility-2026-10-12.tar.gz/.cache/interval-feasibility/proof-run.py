"""Journal builds and actual native proof execution, including failures."""
from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'.cache/interval-feasibility'
GO=ROOT/'.cache/toolchains/go1.26.8/go/bin/go'
ENV=dict(os.environ,GOROOT=str(GO.parent.parent),GOTOOLCHAIN='local',CGO_ENABLED='0',GOAMD64='v1',GOCACHE=str(ROOT/'.cache/go'),GOFLAGS='-buildvcs=false',GOMAXPROCS='1',COCOON_INTERVAL_SOURCE=str(ROOT/'examples/datadog/go/dd/internal/wasm/module.go'),COCOON_INTERVAL_PROOF_SOURCE=str(ROOT/'examples/datadog/go/dd/internal/wasm/module.go'))
ENV['PATH']=str(GO.parent)+':'+ENV['PATH']

def run(name,cmd,cwd,extra=None):
 env=ENV if extra is None else dict(ENV,**extra)
 record={'name':name,'argv':list(map(str,cmd)),'cwd':str(cwd),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'env':{key:env.get(key,'default') for key in ['GOROOT','GOTOOLCHAIN','CGO_ENABLED','GOAMD64','GOARCH','GOFLAGS','GOCACHE','GOMAXPROCS','COCOON_INTERVAL_SOURCE','COCOON_INTERVAL_PROOF_SOURCE','COCOON_INTERVAL_PROOF_OUTPUT']}}
 with (OUT/(name+'.log')).open('x') as log:
  print('COMMAND',json.dumps(record),file=log,flush=True)
  result=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
  print('EXIT',result.returncode,file=log,flush=True)
 record.update(exit=result.returncode,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 with (OUT/'proof-command-records.jsonl').open('a') as journal:journal.write(json.dumps(record)+'\n')
 print(name,'EXIT',result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)

def main():
 mode=sys.argv[1]
 if mode=='build':
  prefix=('build-'+sys.argv[2]+'-') if len(sys.argv)>2 else 'build-'
  overlay={'Replace':{str(ROOT/'examples/datadog/go/dd/phase0_interval_consumer_test.go'):str(OUT/'consumer_test.go')}}
  (OUT/'consumer-overlay.json').write_text(json.dumps(overlay,indent=2)+'\n')
  for arch in ['amd64','386']:
   run(prefix+'core-'+arch,[GO,'test','-pgo=off','-c','-o',OUT/('core-'+arch+'.test')],OUT/'proof',{'GOARCH':arch})
   run(prefix+'consumer-'+arch,[GO,'test','-pgo=off','-modfile='+str(OUT/'consumer.mod'),'-overlay='+str(OUT/'consumer-overlay.json'),'-c','-o',OUT/('consumer-'+arch+'.test'),'./examples/datadog/go/dd'],ROOT,{'GOARCH':arch})
 elif mode in ['amd64','386']:
  run('proof-core-'+mode,[OUT/('core-'+mode+'.test'),'-test.run=^(TestEngine|TestChecker)','-test.v','-test.count=1','-test.timeout=5m'],OUT/'proof')
  run('proof-consumer-'+mode,[OUT/('consumer-'+mode+'.test'),'-test.run=^TestIntervalHostProof$','-test.v','-test.count=1','-test.timeout=5m'],ROOT/'examples/datadog/go/dd',{'COCOON_INTERVAL_PROOF_OUTPUT':str(OUT/('consumer-'+mode+'.jsonl'))})
 else:raise ValueError(mode)

if __name__=='__main__':main()
