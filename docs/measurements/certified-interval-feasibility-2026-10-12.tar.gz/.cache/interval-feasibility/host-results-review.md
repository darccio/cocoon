# Host final result and prose review

Verdict: READY to retain the private specification and proof/cost evidence.
No host correctness, reporting, or public-contract blocker found in the current
bounded numerical section of `docs/performance.md`, roadmap resume text, or
specification status. This approves numerical feasibility and evidence-only
retention. Online construction, scalar improvement, and M1 remain unqualified.

This review used source/report reads and independent JSON/hash arithmetic only;
no build, test, benchmark, or profile was executed. Archive payload verification
and resolution of the new evidence links remain with the parent's packaging
step; the archive had not yet been created for this review.

## Cost and provenance audit

All 84 raw rows have successful exit status and actual-procs=1. Each of the six
scopes has exactly seven samples in each of the two rounds. Independent medians
of every raw metric equal `cost-summary.json` and the documented table:

| Scope | Screen ns/op | Confirm ns/op | Confirm B/op | Confirm allocs/op |
| --- | ---: | ---: | ---: | ---: |
| BankConstruct | 12,413,339 | 12,257,211 | 6,349,379 | 161,936 |
| BankVerified | 69,353,764 | 69,606,535 | 22,946,569 | 574,813 |
| Accepted42 | 197,945 | 199,829 | 93,359 | 2,611 |
| RejectedCell2 | 8,847 | 8,841 | 3,313 | 5 |
| RejectedBoundary | 204,270 | 200,786 | 93,343 | 2,609 |
| AcceptedChecker | 978,811 | 975,270 | 290,839 | 7,246 |

The documentation correctly rounds complete construction to 12.257 ms and
verified construction to 69.607 ms. The latter includes every accepted trace's
complete independent source/node binding; it is not a lightweight numeric-only
checker cost. Source extraction and the accepted witness, framework initial
1x invocation, and scope warm-up are outside the retained timing. The separate
Accepted42 confirmation preparation median is 142,905,312 ns and 40,916,976
allocated bytes. No lookup latency or computed-miss latency was measured.

Official Go1.26.8/CGO0/GOAMD64v1/PGO-off and fixed iteration counts agree with
the frozen plan, ELF identity, raw argv, and row environment. Actual P1 is
asserted immediately around timing. The measurement begins after the source
freeze at 19:10:20 UTC and completes at 19:11:47 UTC. Recorded Linux version,
all 16 powersave governor values, and enabled boost agree with the conditions.
All 85 frozen entries other than the specification still match their hashes;
the specification differs only in its post-result status/history text. No
implementation correction occurred after freeze.

Separate GC-disabled single-operation observations match the prose: 6,349,272
bytes for construction, 23,043,488 verified, and 392,448 individual-checker
allocation. These observations differ from warmed timed B/op as disclosed.
End-of-operation and forced-GC deltas support no peak RSS, retained-bank heap,
or hard bounded-process claim.

## Source, ownership, and finite proof scope

Native amd64 and 386 reports have identical complete source/original-Wasm pins,
canonical bank bytes/SHA, certificate identities, accepted verification count,
corpora, mismatch results, and local proof ledger. Actual admitted resource
configuration is independently copied under Lifecycle/Resource/Instance locks
from the live handle's checked generation/occupied record and current logical
memory. Its four words are:

`3ff0400000000000 40501fead4ea6e2b 0010400000000000 4094ea0000000000`.

The original constructor Count is zero; gamma/offset agree with the complete
constructor protobuf. This private whole-source-pinned fixture layout is not
promoted to a generic resource-memory API. No view, offset, resource identity,
or guest pointer is retained in the numeric bank.

Each native event stream contains 521 original-Wasm singleton requests, with
Count bits exactly 1.0 and nonempty complete protobuf evidence for every one;
six are the disclosed no-bin controls. The docs correctly say requests rather
than asserting a broader distinct-input or exhaustive-Wasm proof. The Wasm
oracle witnesses logical bin/Count/protobuf only, not intermediate operations.
Compiled full OriginalLog and OriginalBin remain distinct from graph-derived
OriginalPointTrace; the independent point checker agrees per primitive slot.

Actual host counts are 3,833 whole evaluations, 114 tiny members, and 521 Wasm
requests per architecture. Core 1,081 + checker 8,407 + host 3,833 + eight
selected fault evaluator calls = 13,329 whole evaluations. Core 512 + host 114
= 626 tiny members, also charged to whole evaluations. These satisfy the
fixed 16,384 / 262,144 / 2,048 caps; earlier oversized author checks are
separately retained and do not become final capped validation credit.

The bank is 57 accepted / 92 attempts / 23 original exponent fields, with both
bin signs and one interval containing NearbyUniqueCycle. Raw reasons are 57
accepted, 30 cell rejects from six power-of-two seeds, and five boundary rejects
from seed16. The earlier host inference of seven cell-rejecting seeds was wrong;
the corrected evidence and unchanged cost scope are accurately disclosed.

All accepted traces independently verify. Reported logical graph, complete
builder/report/handoff workspace, combined export capacity, and bank plus
canonical encoding match both architecture summaries: bank 2,814/2,554 bytes,
workspace plus export 56,156/55,384 bytes. These are logical representation
bounds. The 235-bit accepted checker arithmetic ledger is not an overall
temporary-width maximum; the separately guarded dyadic decoder may reach
1,075 bits, now correctly stated in the prose.

## Negative locality and disposition

The immutable first/revisit banks and totals match exactly. Repeated and Nearby
hit 8,192/8,192; Unique9, MostlyUnique633, Phases768, NegativeBins1,024, and
Broad0 per 8,192. Increasing hits 1,806/4,194,304 (0.043058%); all parameter
229,376 and source262,144 mismatch lookups miss. Every miss is uncertified;
coverage performs no original-computation fallback, on-demand certification,
eviction, or live guest substitution. Poor broad/increasing locality is explicit
and cannot be interpreted as a warmed cache result or predicted full-call gain.

The seven gate records and two repetitions are successful; before/after all
61 production proof/runtime fingerprint maps are byte-identical. These qualify
unchanged production plus separately executed private native proof evidence,
not a shipping optimization. New public API/ABI, facade latency, streaming
throughput, representative SDK, native arm64/big-endian, and M1 claims remain
absent. A separate reviewed specification is needed before any faster bounded
constructor, lookup-cost, guest-integration, or eligibility experiment.

READY. No further source changes requested. Host tools stopped after this note.
