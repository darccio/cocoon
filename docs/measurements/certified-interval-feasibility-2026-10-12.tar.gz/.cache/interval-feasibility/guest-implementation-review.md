# Guest implementation and cross-review

Private offline proof core only, following signed specification
`8c8791b1db5569e0d80cea442774ca0e2bfad15e`. No production source, generated
module, guest/Wasm, runtime contract or public API was edited. No benchmark,
profile or calibrated cost observation was run by this reviewer.

## Core source identities and behavior

Owned files at this readiness review:

| File | SHA-256 |
| --- | --- |
| proof/engine.go | `4e2eb6dddf5cec1b48192f5bd2248951c5b1d6172a57ba89241a69127f3008fe` |
| proof/source.go | `ae5ccd7fcc02ae9c490d41fc41aeb834e71c09ae610bf59bf63a4eea1e2ca4ea` |
| proof/engine_test.go | `1da5fb4a6abb2516e2fc85e8ec068470ef5e202a66d7f5f4e2046eb0fb1a6270` |

Load pins the complete original DD module SHA and current constructor/read
bindings. It derives an immutable versioned graph from actual normal-path
assignments and affine source; no host ln/exp or reference payload is used.
Graph retains only fixed node capacity and cloned source fragments. Whole
module bytes, AST, FileSet and binding maps are preparation temporaries, not
retained graph storage. GraphBytes uses guarded wide accumulation before
downcast. Literal source/configuration identities plus a node/source seal reject
drift; exported convenience parameter data cannot redefine the canonical tuple.

The normal-cell predicate excludes unsupported input, threshold, exponent,
carry and exact-one branches. Within an accepted cell the reduced-word
difference equals the input-word difference exactly; positive finite reduction
endpoints and constant K follow without a logarithm monotonicity assumption.
Each actual rounded binary64 operation gets rational extrema and directly
computed outward bounds. Addition/subtraction use their extremal combinations;
multiplication/division use all four signed corners. Zero-containing divisor,
nonfinite enclosure, saturation uncertainty or a two-bin enclosure rejects.
The final strict `[k,k+1)` check applies after both original affine roundings.
Unknown requests and fatal source/proof errors have distinct sentinels and
Reason categories. Source drift never becomes ordinary budget uncertainty.

The directed converter derives its exponent from integer lengths, performs a
bounded comparison and scaled quotient/remainder, then emits binary64 floor/
ceil directly. It uses no big.Float, neighbor search or finite-precision
intermediate. Explicit preflight checks cover input copies, unreduced rational
operations, scaling and comparison temporaries. Rounder shifts/comparisons/
quotients and the per-candidate conversion ledger are enforced. The 32 explicit
integer scratch slots include decode/conversion temporaries, not retained
operation history; math/big internals/allocator overhead remain allocating
reference machinery rather than a hard process-memory guarantee.

The logical workspace reserves the full Bank/BankReport plus the active
request, two Trace images during handoff and explicit integer capacities and
headers; final bank/report return reserves two images after rational workspace
is dead. It does not claim to bound compiler ABI stack copies, RSS or Go-runtime
stack behavior. Both Certify and BuildBank reject reduced budgets that cannot
contain the complete modeled builder. Trace export capacity receives a separate
combined check in the consumer observer.

## Focused checks and preliminary outcomes

The final focused command, recorded in `core-focused-ready.log`, passed:

```sh
PATH=/home/dario/Code/cocoon/.cache/toolchains/go1.26.8/go/bin:$PATH \
GOROOT=/home/dario/Code/cocoon/.cache/toolchains/go1.26.8/go \
GOTOOLCHAIN=local CGO_ENABLED=0 GOAMD64=v1 GOFLAGS=-buildvcs=false \
GOCACHE=/home/dario/Code/cocoon/.cache/go \
/home/dario/Code/cocoon/.cache/toolchains/go1.26.8/go/bin/go \
  test -pgo=off -run '^TestEngine' -v ./...
```

These are functional preparation checks, not performance samples or the
parent's final native qualification. The first attempt without a writable
GOCACHE reported unavailable std packages/read-only default cache. Its actual
stdout remains in tool history; the parent was notified. No fabricated raw log
is supplied. Later repo-cache commands pass; earlier focused logs are retained.

Observed amd64 graph: 76 slots, 30 rounded nodes, 7,249 logical graph bytes.
Modeled complete builder workspace is 47,964 bytes, Bank is 1,608 bytes and the
57-entry canonical bank encoding is 1,206 bytes (2,814 bytes combined).
The fixed 64 seeds produce 92 attempts and 57 certificates across 23 original
exponent fields, with both logical signs and one certificate covering all
8,192 NearbyUniqueCycle inputs. Six symmetric power-of-two seeds reject all
five attempts for cell crossings; one fixed low-exponent seed rejects all five
for final-bin uncertainty. No seed, width, capacity or arithmetic retuning took
place. Final success requires independent/native/Wasm qualification, not only
these constructor outcomes.

Exact compiled OriginalLog result bits match graph LogOutput, and the full
compiled original affine/Floor/saturation helper matches graph logical bins.
OriginalPointTrace is explicitly graph-generated; it is a compiled graph
witness, not independent source reconstruction or an independent ln oracle.

The final core verification ledger is exactly 1,081 whole checks: four fatal
graph queries, 530 domain/budget/ordinary/tiny checks, 185 checks for two fixed
bank builds plus early workspace rejection, and 362 concrete evaluator calls
over 92 inputs. Its 512 tiny members also count toward whole checks. Earlier
8,192-member focused enumeration logs are author preparation, outside the final
collective-driver claim; their finite selection was reduced before verification
freeze without changing the certified interval, seeds or bank. No Wasm request
is made by the core driver. The parent combines these counts with independent
checker and consumer ledgers per architecture, including mutant executions.

## Applied independent checker and consumer review

The checker uses its own immutable canonical source/configuration values,
independently parses and binds the complete node graph, recomputes integer
reduction/branch tags and all four corner extrema from verified previous slots,
and rounds with a separate nearest-even quotient/remainder implementation plus
exact comparison/adjacent directed adjustment. It never calls constructor
rounding, transfer, cell or seal as its oracle. Claimed traces are compared with
independently rebuilt bounds, not trusted as operands. Strict integer-bin
containment uses rational comparison and independent negative floor handling.
The requested preflight check before copying oversized input integers is now
applied. Native tests compare source-derived point bits to the separately
compiled full original log and affine path; finite tests do not replace the
inductive universal enclosure argument.

The consumer reconstructs the actual handle-to-record/generation relation from
the pinned module and reads the four parameter words inside existing ownership
and Instance.Call checks. Fresh original-Wasm singleton sketches expose logical
bins, Count and complete protobuf without collapse masking errors. Below-minimum
values are explicitly zero-count/no-bin, not bin zero. Expected scalar/batch
errors and lifetime tests remain unchanged-production controls because no new
guest mapping is integrated. All literal evaluator calls and original-Wasm
singletons receive explicit ledger charges. The observer checks constructor and
independent work, plus JSON capacity and active engine workspace together;
trace/export maxima are reported. No retained rational history is exported.

Compiled selected mutants provide numerical counterexamples to inward bounds,
wrong signed extrema, inclusive upper bin boundaries, negative truncation,
missing carry, source-literal/configuration/bin changes and acceptance after
uncertainty. Their explicit named numerical failure marker is required; compiler,
startup or signal failure is not credit. These are proof-premise/interpreter
counterexamples, not a new production compiler pass. Healthy source-drift
rejection is a distinct category. Parent will execute the frozen native amd64
and actual 386 binaries and selected mutants; this note does not substitute
that final execution record.

## Cost scope review and readiness

The parent's six fixed cost scopes retain source/graph identity checks and full
independent Verify work. BankVerified constructs and verifies one accepted
trace at a time; BankConstruct reports the unverified construction scope
separately. Accepted42, early cell rejection, numerical boundary rejection and
independent accepted verification are distinct. Source preparation and fixed
witness setup are untimed and separately observed. The applied P1 assertions
before ResetTimer and after StopTimer, actual-procs metric and fixed bank/count
checks match the recorded plan. GC-disabled heap observations are labelled
end-of-operation snapshots, not peak RSS or a hard heap bound. The plan supplies
no scalar latency/throughput promotion, SDK traffic or cache integration claim.

Core implementation and applied cross-review are ready for the parent's final
functional qualification and freeze. No remaining guest numerical/source or
scope blocker was identified. All timing remains the parent's isolated work;
no native arm64/big-endian or M1 acceptance claim follows.
