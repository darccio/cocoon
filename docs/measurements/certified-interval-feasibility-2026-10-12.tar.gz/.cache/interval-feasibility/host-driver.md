# Private consumer proof driver

Owned files are only `consumer_test.go` and this note under the ignored cache.
The signed private specification is `8c8791b1db5569e0d80cea442774ca0e2bfad15e`.
No production source, generated module, Wasm, runtime, facade, cache or public
API is changed. This is correctness and offline-bank coverage; it contains no
benchmark, CPU profile, latency measurement or attainable scalar claim.

The parent owns the temporary module/overlay, native build/run journal,
architecture comparison and final aggregate budget. The guest owns the pure
constructor/source graph, the adversarial reviewer the independent checker.
This agent authored no proof-core or checker files and has not run builds/tests.

## Overlay and execution inputs

The parent maps a virtual additional `_test.go` in `examples/datadog/go/dd` to
`consumer_test.go`, and uses its temporary `consumer.mod`/sum with local
replacement of `cocoonintervalproof` by the ignored proof module. All three
baseline translated modules and original Wasm remain byte-identical.

`TestIntervalHostProof` requires the pure package's `Load`, `BuildBank`,
`Certify`, `Point`, `Lookup`, `BankBytes`, `VerifyGraph`, `VerifyWork`,
`CheckerPointTrace`, and generated `OriginalLog`, `OriginalBin`,
`OriginalPointTrace`. The final helper is graph-generated and is explicitly
not an independent reconstruction of the original source. Point comparisons
also check original-log bits and original-bin output from the separately
reconstructed exact source, then original-Wasm singleton encoding supplies
independent guest bins.

Environment inputs:

- `COCOON_INTERVAL_PROOF_SOURCE`: actual unchanged full translated source;
  defaults to `internal/wasm/module.go` relative to the dd test working directory.
- `COCOON_INTERVAL_PROOF_OUTPUT`: optional absolute fresh JSONL output path.
  With this variable set, opening uses `O_EXCL`, preserving earlier results.
  Without it, events are sent to the test log. Every native validation needs
  its own path; retries/mutants must also use distinct paths.

Native builds/runs use the exact official
`.cache/toolchains/go1.26.8/go/bin/go`, `GOTOOLCHAIN=local`, `CGO_ENABLED=0`,
`GOAMD64=v1`, repository `GOCACHE` and `-pgo=off`. The parent chooses the
actual temporary overlay filename and journals argv rather than relying on
this note's guessed file path. Both amd64 and actual native386 must execute.
Wazero's existing default reference engine on386 is an interpreter; that is
valid original-Wasm semantic evidence, never a compiled-backend performance
claim. No native arm64 or big-endian execution is asserted.

## Constructor ownership and source context

The fixture uses the unchanged supported facade to create a resource. It then
enters the library lifecycle, Resource.Use and Instance.Call to inspect only
current logical guest memory. The full SHA-pinned `fn84`/Add relation resolves
`slot=memory.u32(1101436)+(uint32(handle)-1)*72`, requires nonzero index,
index<count at1101440, widened nonwrapping arithmetic, current logical bounds,
matching generation atslot+64 and an occupied first word. It copies the four
actual words atslot+32/+40/+48/+56. Current header length and complete byte SHA
are identical before/after this read. No slice or pointer escapes the callback
or survives guest execution/growth. The encoded fresh sketch also checks gamma
and offset; Count is0. Source literals and full module SHA explain this private
layout assertion; it is never a new generic handle/memory API.

The graph and actual constructor must agree on all four words and the pinned
source/Wasm identities. Gamma is metadata identity, not a claimed extra
existing numeric read. Current public admission, reset, reply validation,
MaxMemory, poisoning, epochs and draining Close stay unchanged. This fixture
read proves no future cache integration behavior.

## Universal proof versus finite evidence

An Observer receives one constructor trace at a time. Accepted certificates
are passed to `VerifyWork`, which independently rebinds graph/source,
reconstructs reduction and all signed corners, and compares every trace node.
Accepted checker work must have exactly the graph's node/rounded counts,
4 corners per rounded node,2 bound conversions per rounded node,<=192 total
conversions,<=4096 integer bits and<=64KiB logical arrays/trace. Independent
work totals and per-certificate maxima are recorded separately from constructor
work, including the full verifier's source binding cost in its later scope.

The output writer records actual `cap(jsonBytes)` and charges it together
with the active conservative builder WorkspaceBytes for EVERY event emitted
inside Observer; sum must fit64KiB. The maximum export capacity and combined
workspace appear in the final summary. It never retains all traces. Temporary
encoding/json and math/big heap/RSS are not hard bounded by this logical ledger;
the standard-library allocation cost remains a separate observed quantity.
Outside the builder, diagnostic reports/protobuf outputs/canonical-byte copies
are driver evidence, not retained numeric-bank storage or a process-memory
claim. Graph16KiB/bank4KiB logical sizes are independently checked.

Returned bank certificates must exactly equal the synchronously verified
accepted attempts in order. Requests must follow all64 frozen seeds, half-width
2^(40-refinement), initial+four unknown refinements, with no skipped seeds,
clipping, retuning or further work after acceptance. All negative attempts are
recorded. The same serialized bank before/after coverage confirms lookup does
not mutate it. Canonical little-endian bank hex/hash is emitted; the parent
must compare these EXACT bytes between actual amd64/386 runs, not native struct
padding or architecture-dependent WorkspaceBytes.

For every retained certificate, nine declared endpoints/outside neighbors/
structured interiors are compared across graph interpreter, graph-generated
trace, independent checker point/ALL primitive slots, original source log/bin and fresh original
Wasm. Two additional adjacent members form a fully enumerated tiny interval.
Finite traces/samples never replace the universal rational enclosure argument.
Complete Count bits and owned protobuf bytes are recorded per original-Wasm
singleton, including fresh resources and cleanup, so collapse cannot hide an
incorrect bin. Eight zero/subnormal/minimum controls expose the separate
zero-count/no-bin path. Unsupported domains, all four parameter-bit mismatches,
32 source-byte mismatches, six low budgets and fatal source drift are explicit.

Nonvacuity is checked after reports/coverage:>=16 non-singletons,>=4 ORIGINAL
exponent fields, positive+negative bins and ONE certificate containing the
entire8192 NearbyUniqueCycle. Coverage itself must fully hit that nearby corpus.
A failed rule is reported as a negative; bank seeds/caps are not expanded.

## Finite ledger and replay

The local ledger charges every actual bank Certify attempt, accepted VerifyWork,
VerifyGraph, each domain/budget/source request, ALL FIVE full point evaluators
and each original-Wasm point/model call. Local hard caps are16384 whole
checks,262144 tiny members and2048 original-Wasm singleton requests.
For the current preliminary57-certificate/92-attempt bank, expected host counts
are about3833 whole checks,114 tiny members and521 original-Wasm requests;
these are not success assertions or substituted actual counts. Static max
for64certificates/320attempts is4516 whole checks,128 tiny members and584Wasm.
The parent aggregates all other core/checker validation calls with these
counts against the SAME architecture-wide caps. Earlier larger preparation
loops must stay labelled preparation, not the final single capped validation.

Offline replay uses the unchanged7 frozen8192-value cyclic corpora, first and
revisit passes,112 phase records and14 total records. Distinct Increasing
inputs1..4194304 produce4096 phase records and1 total record. Each phase is1024
inputs; hit/miss/domain/exact-one/uncertified counts reconcile. The bank is
prebuilt/immutable with disclosed setup. There is no eviction, hidden per-miss
certification, resource churn controller or on-demand constructor. Parameter
mismatch replays cover4*7*8192=229376 inputs; source mismatch replays32*8192=
262144 nearby inputs; certified hits must be0. Coverage loops call Lookup only,
not graph computation; they are not timed and cannot predict a full-call gain.

## Output records and failure handling

JSONL events retain actual constructor words/owned encoding, each fixed
candidate attempt, accepted independent checker work, accepted transient
trace, certificate widths, every original-Wasm singleton's full protobuf,
unsupported/budget/mismatch outcomes, each replay phase/total and final summary.
The cleanup summary also emits on numerical test failure; missing setup/native
source/checker or a stale output path is a setup failure, not an acceptable
semantic mutant failure. Compiling named numerical mutants are parent/checker
owned and must fail their intended assertion.

Before any constructor-cost timings, complete both native correctness runs,
read-only cross reviews and collective ledgers; freeze source/graph/config/
bank/binaries/toolchain plus exact timing scopes. All local reviewer/build/
lint/fuzz/profile work stops during parent measurements. New production/cache/
lookup/native-fast-constructor design requires its own specification; no public
contract is approved here, and M1 remains unaccepted.

## Applied final review and observed correctness

Read-only core/source/checker/cost review found no remaining host or scope
blocker. The constructor uses source-pinned owned graph strings, full graph
seal/context checks and positive-normal/carry restrictions; the independent
checker reconstructs all corners/bounds/source nodes rather than trusting the
constructor. Directed bound conversion and independent nearest-even rounding
remain separate implementations. Logical bit/work/preflight caps do not claim
math/big internal allocation or RSS is hard bounded. A future runtime cache,
current-memory bypass, stale parameter snapshot or reordered observable read
has not been implemented. Actual ownership-bound reads remain private tests.

Final amd64/386 summaries both report57 certificates/92 attempts/23 ORIGINAL
exponent fields, both bin signs, complete Nearby8192 coverage and57 independently
verified traces. Canonical bank SHA256 is
7cbaa190712acef7949eb7cb61724721f43c226499d9904d4a61cf3be7778686
on both architectures. Actual host ledger is3833 whole/114 tiny/521 original
Wasm singleton requests on each architecture. Parent's aggregate final capped
validation is13329 whole/626 tiny/521Wasm including eight selected mutant
calls. Earlier8192-member preparation logs are not this capped validation.

Observed graph bytes are7249/7225, bank plus one canonical encoding2814/2554
on amd64/386. Max JSON export buffer capacity8192B; active builder workspace+
export reaches56156/55384B, within65536B. Independent verifier total work:
4332 nodes,1710 rounded,6840 corners,3420 conversions; per accepted certificate
76/30/120/60. These are counted logical observations, not process heap bounds.
Root reports nine same-ELF numerical mutant failures on each architecture,
all seven gates and two61-fingerprint repeats passed; this reviewer executed
no tests/builds/gates. The root owns those command/log identities.

Coverage remains offline immutable-bank locality, identical across native
architectures:8192/8192 Repeated and Nearby,9/8192 UniqueCycle,633/8192 MostlyUnique,
768/8192 Phases,0/8192 BroadHoldout,1024/8192 NegativeBins,1806/4194304 Increasing.
First/revisit counts are equal because no on-demand certification/eviction or
mutation occurs. This does not promise application hits, cheap construction,
lookup latency, a full-facade improvement, an attainable cache or M1 acceptance.

Cost source and frozen cost-plan scope are coherent: BankConstruct excludes
verification and BankVerified includes every accepted full-source-bound Verify;
accepted/rejected requests and AcceptedChecker are separate operations. Full
source preparation is untimed author preparation with duration/TotalAlloc delta
reported separately. Actual P1 is asserted immediately around timer and
reported. Fixed-count framework probes and warmups are setup, not qualification
rows. Error/attempt/node checks consume final outputs. GC-disabled single-op
MemStats observations are end-of-operation/collected heap, not peak RSS or
hard bounds; no component-cost subtraction or scalar-speed claim follows.

A review mistake was corrected before freeze: I inferred from57accepted/92attempts
that every failed seed was a cell rejection and incorrectly flagged cost seed16
as invalid. Actual core-focused-ready.log records SIX power-of-two seeds yielding
30cell attempts and seed16 yielding fiveBOUNDARY attempts; its frozen initial
request0171ff0000000000..0172010000000000 is valid. No bank or cost request changed.
The earlier false blocker message is preserved in collaboration history; this
correction records why the claimed blocker is withdrawn. Parent still performs
exact-binary functional cost preflight before isolated timing.

No code alteration is requested by this final review. Consumer source uses
CheckerPointTrace per-slot equality plus independently reconstructed full-source
p17/bin bits; all five evaluator charges remain. Ready for root freeze and
cost observations; all child tools stop after this final hash record.

## READY for isolated cost observation

Final host cross-review: no blockers; tools stopped. Consumer SHA256
`22a43d5b3b75ba2c574f6becbca2b9caf84250b1770c08686dc04d791618796f`;
engine `4e2eb6dddf5cec1b48192f5bd2248951c5b1d6172a57ba89241a69127f3008fe`;
checker `ed339451331015e06a71c221a4954e298a4d31bb313ef8ced4e7201b7901ba31`;
cost harness `e1ea1a67470b8ecabc010b7e43013016b68bb8b79fc83eda404ed11f86de1550`.
Cost seed16 is the recorded boundary rejection; the earlier inferred cell-only
claim was false and withdrawn. No bank/request/source change is requested.
