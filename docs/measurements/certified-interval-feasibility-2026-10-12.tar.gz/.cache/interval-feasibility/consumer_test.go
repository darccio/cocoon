package dd

import (
	"bytes"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"go/ast"
	"go/parser"
	"go/token"
	"math"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"testing"
	"unsafe"

	intervalproof "cocoonintervalproof"
	"dario.cat/cocoon/cocoontest"
	"dario.cat/cocoon/rt"
)

// This file exists only in the ignored consumer overlay. No production method,
// resource, cache, compiler pass or checked boundary is replaced.
const (
	intervalHostWholeLimit = 16384
	intervalHostTinyLimit  = 262144
	intervalHostWasmLimit  = 2048
)

type intervalHostLedger struct {
	Whole uint64 `json:"whole_graph_checks"`
	Tiny  uint64 `json:"tiny_span_members"`
	Wasm  uint64 `json:"original_wasm_singletons"`
}

func (l *intervalHostLedger) whole(tb testing.TB) {
	tb.Helper()
	if l.Whole >= intervalHostWholeLimit {
		tb.Fatal("interval host driver exhausted whole-graph budget")
	}
	l.Whole++
}

func (l *intervalHostLedger) tiny(tb testing.TB) {
	tb.Helper()
	if l.Tiny >= intervalHostTinyLimit {
		tb.Fatal("interval host driver exhausted tiny-span budget")
	}
	l.Tiny++
}

func (l *intervalHostLedger) wasm(tb testing.TB) {
	tb.Helper()
	if l.Wasm >= intervalHostWasmLimit {
		tb.Fatal("interval host driver exhausted original-Wasm singleton budget")
	}
	l.Wasm++
}

type intervalHostWriter struct {
	file                 *os.File
	builderWorkspace     uint32
	maxExportCapacity    uint64
	maxCombinedWorkspace uint64
}

func intervalHostOutput(tb testing.TB) *intervalHostWriter {
	tb.Helper()
	writer := &intervalHostWriter{}
	path := os.Getenv("COCOON_INTERVAL_PROOF_OUTPUT")
	if path == "" {
		return writer
	}
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		tb.Fatal(err)
	}
	file, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0o600)
	if err != nil {
		tb.Fatalf("interval proof output must be fresh: %v", err)
	}
	writer.file = file
	return writer
}

func (w *intervalHostWriter) event(tb testing.TB, name string, value any) {
	tb.Helper()
	data, err := json.Marshal(struct {
		Event string `json:"event"`
		Data  any    `json:"data"`
	}{name, value})
	if err != nil {
		tb.Fatal(err)
	}
	if w.builderWorkspace != 0 {
		capacity := uint64(cap(data))
		combined := capacity + uint64(w.builderWorkspace)
		if combined > intervalproof.MaxWorkspaceBytes {
			tb.Fatalf("interval export capacity%d+active workspace%d exceeds64KiB", capacity, w.builderWorkspace)
		}
		w.maxExportCapacity = max(w.maxExportCapacity, capacity)
		w.maxCombinedWorkspace = max(w.maxCombinedWorkspace, combined)
	}
	if w.file == nil {
		tb.Logf("INTERVAL_HOST %s", data)
		return
	}
	if _, err := fmt.Fprintf(w.file, "%s\n", data); err != nil {
		tb.Fatal(err)
	}
}

func intervalHostPath() string {
	if path := os.Getenv("COCOON_INTERVAL_PROOF_SOURCE"); path != "" {
		return path
	}
	return filepath.Join("internal", "wasm", "module.go")
}

// Full-source identity pins this fixture layout. Literal assertions reconstruct
// why the returned handle binds the current record; they are not a generic API.
func intervalHostLayoutSource(tb testing.TB, path string) {
	tb.Helper()
	source, err := os.ReadFile(path)
	if err != nil {
		tb.Fatal(err)
	}
	if got := fmt.Sprintf("%x", sha256.Sum256(source)); got != intervalproof.SourceHash {
		tb.Fatalf("interval constructor-layout source drift: %s", got)
	}
	set := token.NewFileSet()
	file, err := parser.ParseFile(set, path, source, 0)
	if err != nil {
		tb.Fatal(err)
	}
	functions := make(map[string]string)
	for _, declaration := range file.Decls {
		function, ok := declaration.(*ast.FuncDecl)
		if !ok {
			continue
		}
		functions[function.Name.Name] = string(source[set.Position(function.Pos()).Offset:set.Position(function.End()).Offset])
	}
	checks := map[string][]string{
		"fn84": {
			"v5 = int32(v3)", "v5 = v5 - i32(1)", "if uint32(t2) <= uint32(v5)",
			"v6 = v1 + v5*i32(72)", "load32(m.memory, uint64(uint32(v6))+64)",
			"if t6 == int32(int64(uint64(v3)>>32))", "if t7 != i32(-1)",
			"store32(m.memory, uint64(uint32(v0))+4, uint32(v1))",
		},
		"Xcocoon_sketch_add": {
			"load32(m.memory, uint32(i32(1101436)))", "load32(m.memory, uint32(i32(1101440)))",
			"m.fn84(v3, t3, t4, v0)", "load32(m.memory, uint64(uint32(v3))+4)",
			"m.fn176(v2+i32(8), v4, v1)",
		},
		"fn176": {
			"load64(m.memory, uint64(uint32(v3))+48)", "load64(m.memory, uint64(uint32(v3))+40)",
			"load64(m.memory, uint64(uint32(v3))+56)",
		},
		"Xcocoon_sketch_new": {
			"uint64(i64(0x3ff0400000000000))", "uint64(i64(4634239110019182123))",
			"math.Float64bits(float64(0x1.04p-1022))", "uint64(i64(0x4094ea0000000000))",
			"store64(m.memory, uint64(uint32(v0))+32, uint64(t20))",
			"store64(m.memory, uint64(uint32(v0))+40, uint64(t19))",
			"store64(m.memory, uint64(uint32(v0))+48, uint64(t18))",
			"store64(m.memory, uint64(uint32(v0))+56, uint64(t17))",
		},
	}
	for name, literals := range checks {
		for _, literal := range literals {
			if !strings.Contains(functions[name], literal) {
				tb.Fatalf("interval constructor-layout relation drift in %s: %s", name, literal)
			}
		}
	}
}

type intervalHostConstructor struct {
	Params      intervalproof.Params `json:"parameter_bits"`
	Handle      uint64               `json:"handle"`
	Record      uint64               `json:"private_record_offset"`
	Generation  uint32               `json:"generation"`
	LiveWord    uint32               `json:"occupied_word"`
	MemoryBytes uint64               `json:"current_logical_memory_bytes"`
	MemorySHA   string               `json:"unchanged_memory_sha256"`
	Encoding    []byte               `json:"constructor_protobuf"`
}

func intervalHostU32(tb testing.TB, memory []byte, offset uint64) uint32 {
	tb.Helper()
	if offset > uint64(len(memory)) || uint64(len(memory))-offset < 4 {
		tb.Fatalf("interval constructor-layout offset outside current logical memory: %d", offset)
	}
	return binary.LittleEndian.Uint32(memory[offset : offset+4])
}

func intervalHostConstructorConfig(tb testing.TB) intervalHostConstructor {
	tb.Helper()
	library := openTest(tb, Options{Instances: 1, ResourceInstances: 1})
	sketch, err := library.NewSketch()
	if err != nil {
		tb.Fatal(err)
	}
	tb.Cleanup(func() {
		if closeErr := sketch.Close(); closeErr != nil {
			tb.Error(closeErr)
		}
	})
	var result intervalHostConstructor
	if enterErr := library.life.Enter(); enterErr != nil {
		tb.Fatal(enterErr)
	}
	defer library.life.Leave()
	useErr := sketch.owner.Use("interval-constructor-fixture", func(instance *rt.Instance, handle uint64) error {
		return instance.Call("interval-constructor-fixture", func(_ *rt.Call) error {
			memory := sketch.guest.module.Memory()
			before := sha256.Sum256(memory)
			base := uint64(intervalHostU32(tb, memory, 1101436))
			count := uint64(intervalHostU32(tb, memory, 1101440))
			index := uint64(uint32(handle))
			if index == 0 || index-1 >= count {
				tb.Fatal("interval constructor-layout handle has no current slot")
			}
			index--
			if index > (math.MaxUint32-base)/72 {
				tb.Fatal("interval constructor-layout widened record address would wrap wasm32")
			}
			record := base + index*72
			if record > uint64(len(memory)) || uint64(len(memory))-record < 72 {
				tb.Fatal("interval constructor-layout record outside current logical memory")
			}
			generation := intervalHostU32(tb, memory, record+64)
			live := intervalHostU32(tb, memory, record)
			if generation != uint32(handle>>32) || live == math.MaxUint32 {
				tb.Fatal("interval constructor-layout ownership/generation differs")
			}
			for field := range result.Params {
				offset := record + 32 + uint64(field)*8
				result.Params[field] = binary.LittleEndian.Uint64(memory[offset : offset+8])
			}
			after := sketch.guest.module.Memory()
			if len(after) != len(memory) || sha256.Sum256(after) != before {
				tb.Fatal("interval constructor-layout read changed current guest memory")
			}
			result.Handle, result.Record, result.Generation, result.LiveWord = handle, record, generation, live
			result.MemoryBytes, result.MemorySHA = uint64(len(memory)), fmt.Sprintf("%x", before)
			return nil
		})
	})
	if useErr != nil {
		tb.Fatal(useErr)
	}
	result.Encoding, err = sketch.Encode()
	if err != nil {
		tb.Fatal(err)
	}
	if count, countErr := sketch.Count(); countErr != nil || count != 0 {
		tb.Fatalf("interval constructor fixture count=%g error=%v", count, countErr)
	}
	var gamma, offset uint64
	var gammaFound, offsetFound bool
	for _, field := range sketchWireFields(tb, result.Encoding) {
		if field.number != 1 || field.wire != 2 {
			continue
		}
		for _, mapping := range sketchWireFields(tb, field.data) {
			if mapping.wire != 1 {
				continue
			}
			switch mapping.number {
			case 1:
				gamma, gammaFound = binary.LittleEndian.Uint64(mapping.data), true
			case 2:
				offset, offsetFound = binary.LittleEndian.Uint64(mapping.data), true
			}
		}
	}
	if !gammaFound || !offsetFound || gamma != result.Params[0] || offset != result.Params[3] {
		tb.Fatal("interval constructor protobuf configuration differs from bound record")
	}
	return result
}

type intervalHostCoverage struct {
	Corpus   string `json:"corpus"`
	Pass     int    `json:"pass"`
	Phase    int    `json:"phase"`
	Inputs   uint64 `json:"inputs"`
	Hits     uint64 `json:"certified_hits"`
	Misses   uint64 `json:"misses"`
	Domain   uint64 `json:"unsupported_domain"`
	Cell     uint64 `json:"unsupported_exact_one"`
	Unproved uint64 `json:"outside_certified_bank"`
	Digest   uint64 `json:"logical_output_digest"`
}

func (c *intervalHostCoverage) observe(bank *intervalproof.Bank, source [32]byte, params intervalproof.Params, bits uint64) {
	c.Inputs++
	bin, hit := intervalproof.Lookup(bank, source, params, bits)
	if hit {
		c.Hits++
		c.Digest = c.Digest<<7 | c.Digest>>(64-7)
		c.Digest ^= bits ^ uint64(int64(bin))
		return
	}
	c.Misses++
	switch {
	case bits < params[2] || bits > 0x7fefffffffffffff:
		c.Domain++
	case bits == math.Float64bits(1):
		c.Cell++
	default:
		c.Unproved++
	}
}

func intervalHostReplay(tb testing.TB, writer *intervalHostWriter, bank *intervalproof.Bank) []intervalHostCoverage {
	tb.Helper()
	var totals []intervalHostCoverage
	for _, corpus := range binReuseCorpora {
		values := binReuseValues(corpus)
		for pass := range 2 {
			total := intervalHostCoverage{Corpus: corpus, Pass: pass}
			for phase := 0; phase < len(values)/1024; phase++ {
				part := intervalHostCoverage{Corpus: corpus, Pass: pass, Phase: phase}
				for _, value := range values[phase*1024 : (phase+1)*1024] {
					part.observe(bank, bank.SourceSHA, bank.Params, math.Float64bits(value))
				}
				writer.event(tb, "coverage_phase", part)
				intervalHostAddCoverage(&total, part)
			}
			if corpus == "NearbyUniqueCycle" && total.Hits != uint64(len(values)) {
				tb.Errorf("interval frozen-bank Nearby8192 does not fully hit: pass=%d hits=%d inputs=%d", pass, total.Hits, len(values))
			}
			if total.Hits+total.Misses != uint64(len(values)) || total.Misses != total.Domain+total.Cell+total.Unproved {
				tb.Fatal("interval coverage accounting is incomplete")
			}
			totals = append(totals, total)
			writer.event(tb, "coverage_total", total)
		}
	}
	total := intervalHostCoverage{Corpus: "Increasing", Pass: 0}
	for phase := range 4096 {
		part := intervalHostCoverage{Corpus: "Increasing", Pass: 0, Phase: phase}
		for index := range 1024 {
			part.observe(bank, bank.SourceSHA, bank.Params, math.Float64bits(float64(phase*1024+index+1)))
		}
		writer.event(tb, "coverage_phase", part)
		intervalHostAddCoverage(&total, part)
	}
	if total.Inputs != 4194304 || total.Hits+total.Misses != total.Inputs {
		tb.Fatal("interval Increasing coverage accounting is incomplete")
	}
	totals = append(totals, total)
	writer.event(tb, "coverage_total", total)
	return totals
}

func intervalHostAddCoverage(total *intervalHostCoverage, part intervalHostCoverage) {
	total.Inputs += part.Inputs
	total.Hits += part.Hits
	total.Misses += part.Misses
	total.Domain += part.Domain
	total.Cell += part.Cell
	total.Unproved += part.Unproved
	total.Digest = total.Digest<<7 | total.Digest>>(64-7)
	total.Digest ^= part.Digest
}

func intervalHostCheckPoint(tb testing.TB, ledger *intervalHostLedger, graph *intervalproof.Graph, bits uint64, certificate *intervalproof.Certificate) int32 {
	tb.Helper()
	ledger.whole(tb)
	got, graphTrace, err := intervalproof.Point(graph, graph.Params, bits)
	if err != nil {
		tb.Fatalf("interval graph point %016x: %v", bits, err)
	}
	ledger.whole(tb)
	generated, generatedTrace, err := intervalproof.OriginalPointTrace(bits)
	if err != nil {
		tb.Fatalf("interval graph-generated point %016x: %v", bits, err)
	}
	ledger.whole(tb)
	checked, checkerTrace, err := intervalproof.CheckerPointTrace(graph, graph.Params, bits)
	if err != nil || got != generated || got != checked {
		tb.Fatalf("interval independent point mismatch input=%016x graph=%d generated=%d checker=%d error=%v", bits, got, generated, checked, err)
	}
	if graphTrace.Count != graph.Count || generatedTrace.Count != graph.Count || checkerTrace.Count != graph.Count {
		tb.Fatal("interval point trace skipped graph nodes")
	}
	for node := 0; node < int(graph.Count); node++ {
		if graphTrace.Slots[node] != generatedTrace.Slots[node] || graphTrace.Slots[node] != checkerTrace.Slots[node] {
			tb.Fatalf("interval independent primitive trace mismatch input=%016x node=%d graph=%v generated=%v checker=%v", bits, node, graphTrace.Slots[node], generatedTrace.Slots[node], checkerTrace.Slots[node])
		}
	}
	ledger.whole(tb)
	originalLog := intervalproof.OriginalLog(math.Float64frombits(bits))
	if want := graphTrace.Slots[graph.LogOutput].Lo; math.Float64bits(originalLog) != want {
		tb.Fatalf("interval independently reconstructed original-log bits mismatch input=%016x graph=%016x original=%016x", bits, want, math.Float64bits(originalLog))
	}
	ledger.whole(tb)
	originalBin := intervalproof.OriginalBin(math.Float64frombits(bits))
	if originalBin != got {
		tb.Fatalf("interval independently reconstructed original-bin mismatch input=%016x graph=%d original=%d", bits, got, originalBin)
	}
	if certificate != nil && bits >= certificate.Lo && bits <= certificate.Hi && got != certificate.Bin {
		tb.Fatalf("interval accepted certificate maps input=%016x to wrong bin: got=%d certificate=%d", bits, got, certificate.Bin)
	}
	return got
}

func intervalHostWasmPoint(tb testing.TB, writer *intervalHostWriter, ledger *intervalHostLedger, reference *cocoontest.Guest, bits uint64, want *int32) {
	tb.Helper()
	ledger.wasm(tb)
	ledger.whole(tb) // Charge the original Wasm point/model even on a no-bin input.
	count, encoded := binOracleState(tb, reference, rt.Limits{MaxInput: generatedInputLimit, MaxOutput: generatedOutputLimit, MaxMemory: maximumMemory}, []float64{math.Float64frombits(bits)})
	bin := readSingletonSketchBin(tb, encoded)
	if count != math.Float64bits(1) {
		tb.Fatalf("interval original-Wasm singleton count input=%016x got=%016x", bits, count)
	}
	if want != nil && (!bin.hasBin || bin.index != int64(*want) || bin.zeroCount != 0) {
		tb.Fatalf("interval original-Wasm singleton wrong bin input=%016x result=%+v want=%d", bits, bin, *want)
	}
	if bits < intervalproof.PinnedParams[2] || bits == 1<<63 {
		if bin.hasBin || bin.zeroCount != math.Float64bits(1) {
			tb.Fatalf("interval threshold input=%016x is not the original zero/no-bin path: %+v", bits, bin)
		}
	}
	writer.event(tb, "original_wasm_singleton", struct {
		Bits      uint64 `json:"input_bits"`
		CountBits uint64 `json:"count_bits"`
		Bin       int64  `json:"logical_bin"`
		HasBin    bool   `json:"has_bin"`
		ZeroBits  uint64 `json:"zero_count_bits"`
		Protobuf  []byte `json:"complete_protobuf"`
	}{bits, count, bin.index, bin.hasBin, bin.zeroCount, encoded})
}

func intervalHostCertificatePoints(certificate intervalproof.Certificate) [9]uint64 {
	span := certificate.Hi - certificate.Lo
	return [9]uint64{
		certificate.Lo, certificate.Hi, certificate.Lo - 1, certificate.Hi + 1,
		certificate.Lo + span/2, certificate.Lo + span/4, certificate.Lo + span/4*3,
		certificate.Lo + span/8, certificate.Lo + span/8*7,
	}
}

type intervalHostDomainReport struct {
	UnsupportedRequests uint64 `json:"unsupported_requests"`
	ParameterReplay     uint64 `json:"parameter_mismatch_replay_inputs"`
	SourceReplay        uint64 `json:"source_mismatch_replay_inputs"`
	MismatchHits        uint64 `json:"mismatch_certified_hits"`
	BudgetRequests      uint64 `json:"budget_rejections"`
	FatalSourceRequests uint64 `json:"fatal_source_requests"`
}

func intervalHostDomains(tb testing.TB, writer *intervalHostWriter, ledger *intervalHostLedger, graph *intervalproof.Graph, bank *intervalproof.Bank) intervalHostDomainReport {
	tb.Helper()
	var report intervalHostDomainReport
	one := math.Float64bits(1)
	cases := []struct {
		Name   string
		Lo, Hi uint64
	}{
		{"positive-zero", 0, 0}, {"negative-zero", 1 << 63, 1 << 63},
		{"smallest-subnormal", 1, 1}, {"largest-subnormal", 0x000fffffffffffff, 0x000fffffffffffff},
		{"below-minimum", graph.Params[2] - 1, graph.Params[2] - 1},
		{"negative-finite", math.Float64bits(-42), math.Float64bits(-42)},
		{"positive-infinity", 0x7ff0000000000000, 0x7ff0000000000000},
		{"negative-infinity", 0xfff0000000000000, 0xfff0000000000000},
		{"quiet-nan", 0x7ff8000000000001, 0x7ff8000000000001},
		{"signaling-nan", 0x7ff0000000000001, 0x7ff0000000000001},
		{"exact-one", one, one}, {"contains-one", one - 1, one + 1},
		{"reversed", math.Float64bits(43), math.Float64bits(42)},
		{"overflows-domain", math.Float64bits(42), math.MaxUint64},
		{"exponent-seam", math.Float64bits(2) - 1, math.Float64bits(2)},
		{"carry-seam", 0x3ff6a09dffffffff, 0x3ff6a09e00000000},
	}
	for _, test := range cases {
		ledger.whole(tb)
		_, _, work, err := intervalproof.Certify(graph, graph.Params, test.Lo, test.Hi, intervalproof.DefaultBudget)
		if !errors.Is(err, intervalproof.ErrUnknown) {
			tb.Fatalf("interval unsupported %s accepted or fatal: %v", test.Name, err)
		}
		report.UnsupportedRequests++
		writer.event(tb, "unsupported_request", struct {
			Name   string             `json:"name"`
			Lo     uint64             `json:"lo_bits"`
			Hi     uint64             `json:"hi_bits"`
			Reason string             `json:"reason"`
			Work   intervalproof.Work `json:"work"`
		}{test.Name, test.Lo, test.Hi, intervalproof.ReasonOf(err).String(), work})
	}
	for field := range graph.Params {
		params := graph.Params
		params[field] ^= 1
		ledger.whole(tb)
		_, _, _, err := intervalproof.Certify(graph, params, math.Float64bits(42), math.Float64bits(42), intervalproof.DefaultBudget)
		if !errors.Is(err, intervalproof.ErrUnknown) || intervalproof.ReasonOf(err) != intervalproof.ReasonParameters {
			tb.Fatalf("interval parameter mismatch field%d was not uncertainty: %v", field, err)
		}
		for _, corpus := range binReuseCorpora {
			for _, value := range binReuseValues(corpus) {
				report.ParameterReplay++
				if _, hit := intervalproof.Lookup(bank, graph.SourceSHA, params, math.Float64bits(value)); hit {
					report.MismatchHits++
					tb.Fatalf("interval parameter mismatch field%d produced a hit", field)
				}
			}
		}
	}
	for index := range graph.SourceSHA {
		source := graph.SourceSHA
		source[index] ^= 1
		for _, value := range binReuseValues("NearbyUniqueCycle") {
			report.SourceReplay++
			if _, hit := intervalproof.Lookup(bank, source, graph.Params, math.Float64bits(value)); hit {
				report.MismatchHits++
				tb.Fatalf("interval source mismatch byte%d produced a hit", index)
			}
		}
	}
	budgets := []struct {
		Name   string
		Budget intervalproof.Budget
	}{
		{"nodes", intervalproof.Budget{Nodes: 1, Rounded: 96, Conversions: 192, IntegerBits: 4096, WorkspaceBytes: 65536, GraphBytes: 16384}},
		{"rounded", intervalproof.Budget{Nodes: 256, Rounded: 0, Conversions: 192, IntegerBits: 4096, WorkspaceBytes: 65536, GraphBytes: 16384}},
		{"conversions", intervalproof.Budget{Nodes: 256, Rounded: 96, Conversions: 0, IntegerBits: 4096, WorkspaceBytes: 65536, GraphBytes: 16384}},
		{"integer-bits", intervalproof.Budget{Nodes: 256, Rounded: 96, Conversions: 192, IntegerBits: 1, WorkspaceBytes: 65536, GraphBytes: 16384}},
		{"workspace", intervalproof.Budget{Nodes: 256, Rounded: 96, Conversions: 192, IntegerBits: 4096, WorkspaceBytes: 1, GraphBytes: 16384}},
		{"graph-storage", intervalproof.Budget{Nodes: 256, Rounded: 96, Conversions: 192, IntegerBits: 4096, WorkspaceBytes: 65536, GraphBytes: 1}},
	}
	for _, test := range budgets {
		ledger.whole(tb)
		_, _, work, err := intervalproof.Certify(graph, graph.Params, math.Float64bits(42), math.Float64bits(42), test.Budget)
		if !errors.Is(err, intervalproof.ErrUnknown) || intervalproof.ReasonOf(err) != intervalproof.ReasonBudget {
			tb.Fatalf("interval budget %s did not reject with uncertainty: %v", test.Name, err)
		}
		report.BudgetRequests++
		writer.event(tb, "budget_rejection", struct {
			Name string             `json:"name"`
			Work intervalproof.Work `json:"work"`
		}{test.Name, work})
	}
	wrong := *graph
	wrong.SourceSHA[0] ^= 1
	ledger.whole(tb)
	_, _, _, sourceErr := intervalproof.Certify(&wrong, graph.Params, math.Float64bits(42), math.Float64bits(42), intervalproof.DefaultBudget)
	if !errors.Is(sourceErr, intervalproof.ErrFatal) {
		tb.Fatalf("interval source drift was not fatal: %v", sourceErr)
	}
	report.FatalSourceRequests++
	writer.event(tb, "domain_and_mismatch_summary", report)
	return report
}

func TestIntervalHostProof(t *testing.T) {
	writer := intervalHostOutput(t)
	ledger := &intervalHostLedger{}
	var report struct {
		Architecture         string                   `json:"architecture"`
		SourceSHA            string                   `json:"source_sha256"`
		WasmSHA              string                   `json:"original_wasm_sha256"`
		BankHex              string                   `json:"deterministic_bank_le_bytes"`
		BankSHA              string                   `json:"deterministic_bank_sha256"`
		GraphBytes           uint32                   `json:"logical_graph_bytes"`
		BankRetainedBytes    uint64                   `json:"logical_bank_plus_encoding_bytes"`
		Ledger               *intervalHostLedger      `json:"verification_driver_ledger"`
		Domain               intervalHostDomainReport `json:"domain_and_mismatch"`
		Build                intervalproof.BankReport `json:"fixed_bank_report"`
		Coverage             []intervalHostCoverage   `json:"offline_bank_coverage"`
		Certificates         uint16                   `json:"certificates"`
		OriginalExponents    int                      `json:"distinct_original_exponents"`
		PositiveBins         bool                     `json:"positive_bins"`
		NegativeBins         bool                     `json:"negative_bins"`
		NearbyWhole          bool                     `json:"one_certificate_covers_nearby8192"`
		IndependentTraces    uint16                   `json:"accepted_traces_independently_verified"`
		CheckerTotal         intervalproof.Work       `json:"independent_checker_total_work"`
		CheckerMax           intervalproof.Work       `json:"independent_checker_max_work_per_certificate"`
		MaxExportCapacity    uint64                   `json:"max_builder_export_buffer_capacity"`
		MaxCombinedWorkspace uint64                   `json:"max_builder_workspace_plus_export_capacity"`
		Failed               bool                     `json:"test_failed"`
	}
	report.Architecture, report.Ledger = runtime.GOARCH, ledger
	t.Cleanup(func() {
		report.Failed = t.Failed()
		report.MaxExportCapacity, report.MaxCombinedWorkspace = writer.maxExportCapacity, writer.maxCombinedWorkspace
		writer.event(t, "summary", report)
		if writer.file != nil {
			if err := writer.file.Close(); err != nil {
				t.Error(err)
			}
		}
	})
	path := intervalHostPath()
	intervalHostLayoutSource(t, path)
	if got := fmt.Sprintf("%x", sha256.Sum256(generatedWasm)); got != intervalproof.WasmHash {
		t.Fatalf("interval original-Wasm drift: %s", got)
	}
	graph, err := intervalproof.Load(path)
	if err != nil {
		t.Fatal(err)
	}
	ledger.whole(t)
	if err := intervalproof.VerifyGraph(graph); err != nil {
		t.Fatal(err)
	}
	report.SourceSHA, report.WasmSHA = fmt.Sprintf("%x", graph.SourceSHA), intervalproof.WasmHash
	report.GraphBytes = intervalproof.GraphBytes(graph)
	if report.GraphBytes > intervalproof.MaxGraphBytes {
		t.Fatal("interval graph exceeds logical cap")
	}
	constructor := intervalHostConstructorConfig(t)
	if constructor.Params != graph.Params || constructor.Params != intervalproof.PinnedParams {
		t.Fatal("interval actual constructor differs from proof configuration")
	}
	writer.event(t, "actual_constructor", constructor)
	observer := func(attempt intervalproof.Attempt, trace *intervalproof.Trace) error {
		ledger.whole(t) // Every actual Certify request, including unknown/budget attempts.
		writer.builderWorkspace = attempt.Work.WorkspaceBytes
		defer func() { writer.builderWorkspace = 0 }()
		if attempt.Work.Nodes > uint32(graph.Count) || attempt.Work.Rounded > uint32(graph.Rounded) || attempt.Work.EndpointOps > 4*attempt.Work.Rounded || attempt.Work.Conversions > 2*attempt.Work.Rounded || attempt.Work.Conversions > 192 || attempt.Work.MaxIntegerBits > 4096 || attempt.Work.WorkspaceBytes > 65536 {
			return fmt.Errorf("interval candidate exceeded declared ledger: %+v", attempt.Work)
		}
		writer.event(t, "candidate_attempt", attempt)
		if attempt.Reason != intervalproof.ReasonNone {
			return nil
		}
		certificate := intervalproof.Certificate{Lo: attempt.Lo, Hi: attempt.Hi, Bin: attempt.Bin}
		ledger.whole(t)
		checkerWork, verifyErr := intervalproof.VerifyWork(graph, graph.Params, certificate, trace)
		writer.event(t, "accepted_checker_work", struct {
			Certificate intervalproof.Certificate `json:"certificate"`
			Work        intervalproof.Work        `json:"work"`
		}{certificate, checkerWork})
		if verifyErr != nil {
			return fmt.Errorf("interval accepted trace verification: %w", verifyErr)
		}
		if checkerWork.Nodes != uint32(graph.Count) || checkerWork.Rounded != uint32(graph.Rounded) || checkerWork.EndpointOps != 4*checkerWork.Rounded || checkerWork.Conversions != 2*checkerWork.Rounded || checkerWork.Conversions > 192 || checkerWork.MaxIntegerBits > 4096 || checkerWork.WorkspaceBytes > 65536 {
			return fmt.Errorf("interval independent checker ledger invalid: %+v", checkerWork)
		}
		intervalHostAddWork(&report.CheckerTotal, checkerWork, false)
		intervalHostAddWork(&report.CheckerMax, checkerWork, true)
		if trace.Count != graph.Count {
			return errors.New("interval accepted trace omits graph nodes")
		}
		report.IndependentTraces++
		writer.event(t, "accepted_trace", struct {
			Certificate intervalproof.Certificate `json:"certificate"`
			Trace       *intervalproof.Trace      `json:"trace"`
		}{certificate, trace})
		return nil
	}
	bank, build, err := intervalproof.BuildBank(graph, intervalproof.DefaultBudget, observer)
	report.Build = build
	if err != nil {
		t.Fatal(err)
	}
	if bank.SourceSHA != graph.SourceSHA || bank.Params != constructor.Params || bank.Count > 64 || build.Count > 320 || build.Accepted != bank.Count || report.IndependentTraces != bank.Count {
		t.Fatal("interval bank/attempt/verification accounting differs")
	}
	seeds := intervalproof.Seeds()
	writer.event(t, "frozen_seed_bits", seeds)
	var lastSeed int = -1
	var lastRefinement int = -1
	var previousAccepted bool
	var returned int
	for index := 0; index < int(build.Count); index++ {
		attempt := build.Attempts[index]
		if int(attempt.Seed) >= len(seeds) || attempt.Refinement > 4 || attempt.Reason > intervalproof.ReasonBoundary {
			t.Fatal("interval attempt ledger has invalid seed/refinement/reason")
		}
		seed, refinement := int(attempt.Seed), int(attempt.Refinement)
		if seed == lastSeed {
			if previousAccepted || refinement != lastRefinement+1 {
				t.Fatal("interval attempt ledger retuned a finished seed or skipped a refinement")
			}
		} else if seed != lastSeed+1 || refinement != 0 || lastSeed >= 0 && !previousAccepted && lastRefinement != 4 {
			t.Fatal("interval attempt ledger skipped/reordered a frozen seed or stopped early")
		}
		width := uint64(1) << uint(40-refinement)
		if seeds[seed] < width || seeds[seed] > math.MaxUint64-width || attempt.Lo != seeds[seed]-width || attempt.Hi != seeds[seed]+width {
			t.Fatal("interval candidate was clipped or changed from frozen request")
		}
		previousAccepted = attempt.Reason == intervalproof.ReasonNone
		if previousAccepted {
			want := intervalproof.Certificate{Lo: attempt.Lo, Hi: attempt.Hi, Bin: attempt.Bin}
			if returned >= int(bank.Count) || bank.Certificates[returned] != want {
				t.Fatal("interval returned bank differs from independently verified accepted traces")
			}
			returned++
		}
		lastSeed, lastRefinement = seed, refinement
	}
	if lastSeed != 63 || returned != int(bank.Count) || !previousAccepted && lastRefinement != 4 {
		t.Fatal("interval bank does not include outcomes for all64 frozen seeds")
	}
	data, err := intervalproof.BankBytes(&bank)
	if err != nil {
		t.Fatal(err)
	}
	report.BankRetainedBytes = uint64(unsafe.Sizeof(bank)) + uint64(len(data))
	if report.BankRetainedBytes > intervalproof.MaxBankBytes {
		t.Fatal("interval bank and canonical encoding exceed the logical cap")
	}
	report.BankHex, report.BankSHA = hex.EncodeToString(data), fmt.Sprintf("%x", sha256.Sum256(data))
	before := bytes.Clone(data)
	exponents := make(map[uint64]bool)
	var nonSingleton uint16
	_, reference := newDifferential(t)
	for index := 0; index < int(bank.Count); index++ {
		certificate := bank.Certificates[index]
		if certificate.Lo >= certificate.Hi {
			t.Error("interval bank contains a singleton/nonordered certificate")
		} else {
			nonSingleton++
		}
		exponent := certificate.Lo >> 52
		if exponent != certificate.Hi>>52 {
			t.Fatal("interval certificate crosses an original exponent field")
		}
		exponents[exponent] = true
		report.PositiveBins = report.PositiveBins || certificate.Bin > 0
		report.NegativeBins = report.NegativeBins || certificate.Bin < 0
		nearby := math.Float64bits(42)
		report.NearbyWhole = report.NearbyWhole || certificate.Lo <= nearby && certificate.Hi >= nearby+8191
		writer.event(t, "certificate_width", struct {
			Index    int     `json:"index"`
			Members  uint64  `json:"binary64_members"`
			RealSpan float64 `json:"real_width"`
			Exponent uint64  `json:"original_exponent"`
		}{index, certificate.Hi - certificate.Lo + 1, math.Float64frombits(certificate.Hi) - math.Float64frombits(certificate.Lo), exponent})
		for _, bits := range intervalHostCertificatePoints(certificate) {
			want := intervalHostCheckPoint(t, ledger, graph, bits, &certificate)
			intervalHostWasmPoint(t, writer, ledger, reference, bits, &want)
		}
		// Exhaustive finite tiny spans supplement, never replace, the
		// universal rational enclosure. All direct/graph/checker calls count.
		for delta := uint64(1); delta <= 2 && delta <= certificate.Hi-certificate.Lo; delta++ {
			ledger.tiny(t)
			intervalHostCheckPoint(t, ledger, graph, certificate.Lo+delta, &certificate)
		}
	}
	report.Certificates, report.OriginalExponents = bank.Count, len(exponents)
	for _, bits := range []uint64{0, 1 << 63, 1, 0x000fffffffffffff, 0x0010000000000000, graph.Params[2] - 1, graph.Params[2], graph.Params[2] + 1} {
		intervalHostWasmPoint(t, writer, ledger, reference, bits, nil)
		if _, hit := intervalproof.Lookup(&bank, graph.SourceSHA, graph.Params, bits); hit {
			t.Fatal("interval unsupported/subthreshold control accidentally hits the frozen bank")
		}
	}
	report.Domain = intervalHostDomains(t, writer, ledger, graph, &bank)
	report.Coverage = intervalHostReplay(t, writer, &bank)
	after, err := intervalproof.BankBytes(&bank)
	if err != nil || !bytes.Equal(before, after) {
		t.Fatalf("offline coverage changed the immutable bank: %v", err)
	}
	if nonSingleton < 16 || report.OriginalExponents < 4 || !report.PositiveBins || !report.NegativeBins || !report.NearbyWhole {
		t.Errorf("interval nonvacuity negative: nonSingleton=%d exponentFields=%d positive=%t negative=%t Nearby8192=%t; keep failures without retuning", nonSingleton, report.OriginalExponents, report.PositiveBins, report.NegativeBins, report.NearbyWhole)
	}
}

func intervalHostAddWork(total *intervalproof.Work, work intervalproof.Work, maximum bool) {
	combine := func(a, b uint32) uint32 {
		if maximum {
			return max(a, b)
		}
		return a + b
	}
	total.Nodes = combine(total.Nodes, work.Nodes)
	total.Rounded = combine(total.Rounded, work.Rounded)
	total.EndpointOps = combine(total.EndpointOps, work.EndpointOps)
	total.Conversions = combine(total.Conversions, work.Conversions)
	total.Shifts = combine(total.Shifts, work.Shifts)
	total.Comparisons = combine(total.Comparisons, work.Comparisons)
	total.QuoRem = combine(total.QuoRem, work.QuoRem)
	total.MaxIntegerBits = max(total.MaxIntegerBits, work.MaxIntegerBits)
	total.WorkspaceBytes = max(total.WorkspaceBytes, work.WorkspaceBytes)
}
