# Host specification review: exact-rational offline interval feasibility

Read-only review of docs/certified-interval-feasibility.md before its commit, at clean merged production/documentation HEAD aeaf01b341a85024804e9ae1abe43af90d36e4d1 (main/origin0/0). Only the untracked draft is present. This ignored note is the only write. No code, build, test, benchmark, profile, public contract or production cache change.

Verdict: approve the private experiment scope; no blocking ownership/lifecycle/API issue. One small trace-accounting clarification is recommended before commit (below). The private exact-Rat proof is intentionally narrower than my earlier fast replay suggestions: no lookup/certification speedup is promised, no dynamic eviction or on-demand cache work is part of this round, and no full-facade promotion rule is inferred.

## Domain and exact identity

The four constructor words and offsets match actual current source: gamma3ff0400000000000/+32, multiplier40501fead4ea6e2b/+40, minimum0010400000000000/+48, offset4094ea0000000000/+56. Constructor/current module626550ca… and original Wasm ae0119ca… remain pinned. Gamma is correctly labelled configuration/encoding identity, not an extra existing hot read. Positive normal finite endpoints at/above minimum, exact-one rejection, exponent/carry-cell restrictions and unsupported saturation rejection supply a conservative domain; the separate below-minimum zero/no-bin branch is preserved.

For accepted normal cells, H+0x95f62 and normalization carry seam0x6a09e match the original translated integer reduction. Lack of wrap/constant carry and increasing reconstructed bits must actually be verified in implementation; exponent/mantissa endpoint logic does not presume ln monotonicity. Source parsing must preserve reassigned bindings, exact compiled constants, explicit rounding boundaries and only the proved operations. Strict enclosure [k,k+1), correct negative floor, explicit int32 range and unsupported/fallback checks correctly prevent boundary/saturation guesses.

Exact finite binary64 operands decode to dyadic rationals. Because every graph result rounds back to binary64, each next primitive starts with fresh finite binary64 endpoints rather than an indefinitely growing rational chain. A4096-bit numerator/denominator cap is a plausible safe primitive budget; implementation must justify and check temporary construction sizes, including intermediates before rational normalization. All four signed endpoint combinations for multiply/divide, denominator-zero rejection, outward conversion and lost-sign rejection are explicit. The separate quotient/remainder nearest-even checker, unchanged compiled traces and original-Wasm singleton bins give useful independent checks; tests complement rather than replace the induction proof.

## Logical caps and heap accounting

The fixed graph96 rounded/256 total nodes,16KiB immutable graph,64 certificates/4KiB bank and≤320 candidate attempts follow deterministically from64 frozen seeds×(initial+four refinements). Failures consume the ledger; at most one certificate per seed; overlap cannot disagree. Half-width2^40 and fixed order prevent selecting an easy successful subset after results. Nonvacuity≥16 useful certificates/four exponent cells/both bin signs/entire NearbyUnique8192 is explicit and may legitimately fail. No clipping or cap sweep can rescue it after outcome.

The specification candidly distinguishes logical arrays/limb/work/serialized-trace limits from actual allocating math/big heap/RSS. That is appropriate for an exact reference procedure. It does NOT implement my earlier optional hard64KiB-allocation suggestion, and must never be reported as a process-memory guarantee. Measure complete accepted/rejected construction, checker and preparation costs separately; transient Go-heap observations and allocation totals cannot be repackaged as enforced bounds. Returned certificates retain numeric endpoints/bins/configuration identity only, never proof-builder guest pointers or mutable state.

Clarify the64KiB row before commit: is ONE complete transfer trace included in the same64KiB logical workspace total? It should retain fixed node IDs/binary64 bounds and required branch metadata, with independent exact-rational values recomputed by the checker. Retaining every exact-rational endpoint temporary across96 nodes could vastly exceed that logical budget. A serialized/raw evidence transcript may be streamed separately, but that distinction must be explicit so trace/work costs do not escape the cap. This is a specification clarity issue, not grounds to claim the forthcoming implementation satisfies it without counting.

## Costs/locality and future host barriers

Complete-bank/accepted/rejected request/checker costs are observational outputs; timed scope/binary/CPU policy must be frozen separately after correctness. Existing seven alternating/reversed samples and strict no-overlap rules remain. Coverage replay is an explicitly prebuilt immutable offline bank on named cycles plus distinct1..4194304 Increasing; first/revisit and1024-phase counters/mismatch zero-hit checks prevent concealed misses. No eviction, cheap per-miss construction, representative SDK locality or full-call gain is inferred. Setup allocations/bank bytes remain visible even when coverage or later warm lookup allocates nothing.

No guest caller is substituted now. Existing invalid-late atomic batch, collapse, lifetime/reply/memory/poison tests are unchanged-production controls, not integration proof. Any later integration must preserve original parameter reads/traps and memory headers, per-call reset/recovery/MaxMemory/reply checks, ordered counter/collapse updates, ownership/admission/context/epoch/old-handle and draining Close policy. It must not retain a guest slice over call/import/growth or cache a store pointer. Numeric/context binding does not authorize using stale snapshots or migrate old handles to replacement homes. A native fast constructor, runtime cache, source-independent compiler predicate and any new public contract each require separate specification/approval as appropriate.

Old exact-value cache and broad/negative/SQL losses remain constraints; the64MiB log oracle gives headroom only. No M1 acceptance, scalar prediction, arm64/big-endian native claim, approximate arithmetic or reference implementation transplant is made. Actual amd64/386 proof, budget/fallback mutants and all gates/repeated proof artifacts remain requirements after the private spec is committed. Evidence must preserve all failed attempts and nonvacuity/cost negatives.

Reviewed draft SHA256:

```json
{
  "docs/certified-interval-feasibility.md": "3d4809612eafa17cf2b2e1e44888d048b25848ad438007be2ec69f13de96e016"
}
```

## Final clarified-draft recheck

Ready for private specification signing after the parent repeats exact staged validation. No blockers. The64KiB workspace explicitly INCLUDES one bounded node-ID/binary64-bound trace; rational histories are not retained, independent checker recomputes complete signed extrema/reduction/rounding/source correspondence, and trace export/rejections cannot evade ledgers. Graph16KiB/bank4KiB remain separate logical caps; allocating math/big heap/RSS remains measured rather than hard bounded. Preflight4096-bit limits now include unreduced products/scaling/comparison temporaries; conversion/work caps are finite and independently recorded. Verification16384 whole-graph/262144 tiny-member/2048 original-Wasm limits are separate from the fixed320 bank candidates and cannot select/retune them. Four cells now mean distinct ORIGINAL exponent fields, closing normalization-tag ambiguity. No runtime state, public contract, constructor-speed claim or cache integration is added. This recheck was one source read and this ignored note append, with no implementation/build/test/benchmark/profile.

Final reviewed draft SHA256: `cfaa42706f421f032cebd36d6706eb3f307cad46e1db28d71b496a41d4bba7df`.
