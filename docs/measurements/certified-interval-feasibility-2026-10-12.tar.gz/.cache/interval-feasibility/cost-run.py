"""Freeze, execute in isolation, and retain all fixed cost observations."""
from pathlib import Path
import datetime, hashlib, json, os, platform, re, statistics, subprocess, sys

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'.cache/interval-feasibility'
GO=ROOT/'.cache/toolchains/go1.26.8/go/bin/go'
ELF=OUT/'core-amd64.test'
ENV=dict(os.environ,GOROOT=str(GO.parent.parent),GOTOOLCHAIN='local',CGO_ENABLED='0',GOAMD64='v1',GOMAXPROCS='1',GOCACHE=str(ROOT/'.cache/go'),GOFLAGS='-buildvcs=false',GOWORK='off',GODEBUG='',GOEXPERIMENT='',GOGC='100',GOMEMLIMIT='off',COCOON_INTERVAL_SOURCE=str(ROOT/'examples/datadog/go/dd/internal/wasm/module.go'))
ENV['PATH']=str(GO.parent)+':'+ENV['PATH']
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def conditions():
 base=Path('/sys/devices/system/cpu')
 return {'utc':utc(),'uname':platform.uname()._asdict(),'cpu_policy':{str(p):p.read_text().strip() for pattern in ['cpu*/cpufreq/scaling_governor','cpufreq/boost','cpu*/cpufreq/scaling_cur_freq'] for p in sorted(base.glob(pattern))},'cpuinfo':Path('/proc/cpuinfo').read_text(),'loadavg':Path('/proc/loadavg').read_text(),'processes':subprocess.check_output(['ps','-eo','pid,ppid,comm,args'],text=True)}
def verify(freeze):
 for filename,expected in freeze['sha256'].items():assert sha(Path(filename))==expected,filename
def execute(name,cmd):
 record={'name':name,'argv':list(map(str,cmd)),'started_utc':utc(),'env':{key:ENV[key] for key in ['GOROOT','GOTOOLCHAIN','CGO_ENABLED','GOAMD64','GOMAXPROCS','GOFLAGS','GOWORK','GODEBUG','GOEXPERIMENT','GOGC','GOMEMLIMIT','COCOON_INTERVAL_SOURCE']}}
 with (OUT/'costs'/(name+'.log')).open('x') as log:
  print('COMMAND',json.dumps(record),file=log,flush=True)
  result=subprocess.run(cmd,cwd=OUT/'proof',env=ENV,stdout=log,stderr=subprocess.STDOUT)
  print('EXIT',result.returncode,file=log,flush=True)
 record.update(exit=result.returncode,completed_utc=utc(),raw='costs/'+name+'.log')
 with (OUT/'cost-command-records.jsonl').open('a') as log:log.write(json.dumps(record)+'\n')
 assert result.returncode==0,name
 return record,(OUT/record['raw']).read_text()
def main():
 mode=sys.argv[1];plan=json.loads((OUT/'cost-plan.json').read_text())
 if mode=='freeze':
  paths=[*sorted((OUT/'proof').rglob('*.go')),OUT/'proof/go.mod',OUT/'consumer_test.go',OUT/'consumer.mod',OUT/'consumer.sum',OUT/'cost-plan.json',OUT/'proof-run.py',OUT/'mutant-run.py',Path(__file__).resolve(),ROOT/'docs/certified-interval-feasibility.md',GO,ELF,OUT/'core-386.test',OUT/'consumer-amd64.test',OUT/'consumer-386.test']
  paths += [ROOT/p for p in json.loads((OUT/'proof-before.json').read_text())]
  for n in ['src/math/big/rat.go','src/math/big/ratconv.go','doc/go_spec.html']:paths.append(GO.parent.parent/n)
  frozen={'created_utc':utc(),'HEAD':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'go_version':subprocess.check_output([GO,'version'],text=True).strip(),'buildinfo':subprocess.check_output([GO,'version','-m',ELF],text=True),'plan':plan,'sha256':{str(p):sha(p) for p in paths}}
  assert 'go1.26.8' in frozen['go_version'];assert 'CGO_ENABLED=0' in frozen['buildinfo'];assert 'GOAMD64=v1' in frozen['buildinfo']
  (OUT/'frozen-spec.md').write_bytes((ROOT/'docs/certified-interval-feasibility.md').read_bytes())
  (OUT/'cost-frozen.json').write_text(json.dumps(frozen,indent=2)+'\n');print('FROZEN',len(paths))
 elif mode=='run':
  frozen=json.loads((OUT/'cost-frozen.json').read_text());verify(frozen)
  (OUT/'costs').mkdir(exist_ok=False)
  (OUT/'measurement-before.json').write_text(json.dumps(conditions(),indent=2)+'\n')
  rows=[]
  for round_name in plan['rounds']:
   for sample in range(7):
    scopes=plan['scopes'];shift=sample%len(scopes);scopes=scopes[shift:]+scopes[:shift]
    if round_name=='confirm':scopes=list(reversed(scopes))
    for scope in scopes:
     verify(frozen)
     cmd=[ELF,'-test.run=^$','-test.bench=^BenchmarkInterval'+scope['name']+'$','-test.benchtime='+str(scope['iterations'])+'x','-test.benchmem','-test.count=1','-test.cpu=1','-test.timeout=5m']
     record,raw=execute(f"{round_name}-{sample}-{scope['name']}",cmd)
     lines=[line for line in raw.splitlines() if line.startswith('Benchmark')];assert len(lines)==1,lines
     fields=lines[0].split();assert int(fields[1])==scope['iterations'];assert '\nPASS\n' in raw
     metrics={fields[i+1]:float(fields[i]) for i in range(2,len(fields),2)}
     assert metrics['actual-procs']==1
     row=dict(record,round=round_name,sample=sample,scope=scope['name'],iterations=scope['iterations'],metrics=metrics,raw_row=lines[0]);rows.append(row)
     with (OUT/'cost-rows.jsonl').open('a') as log:log.write(json.dumps(row)+'\n')
     print(round_name,sample,scope['name'],metrics['ns/op'],flush=True)
  verify(frozen)
  (OUT/'measurement-after.json').write_text(json.dumps(conditions(),indent=2)+'\n')
  assert len(rows)==84
  (OUT/'cost-complete.json').write_text(json.dumps({'completed_utc':utc(),'rows':84,'ELF_sha256':sha(ELF)},indent=2)+'\n')
 elif mode=='memory':
  frozen=json.loads((OUT/'cost-frozen.json').read_text());verify(frozen)
  execute('memory-observations',[ELF,'-test.run=^TestIntervalCostMemory$','-test.v','-test.count=1','-test.cpu=1'])
 elif mode=='summarize':
  rows=[json.loads(line) for line in (OUT/'cost-rows.jsonl').read_text().splitlines()];assert len(rows)==84
  summary={}
  for round_name in plan['rounds']:
   summary[round_name]={}
   for scope in plan['scopes']:
    values=[row for row in rows if row['round']==round_name and row['scope']==scope['name']];assert len(values)==7
    summary[round_name][scope['name']]={metric:{'median':statistics.median([v['metrics'][metric] for v in values]),'min':min(v['metrics'][metric] for v in values),'max':max(v['metrics'][metric] for v in values)} for metric in values[0]['metrics']}
  (OUT/'cost-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
 else:raise ValueError(mode)
if __name__=='__main__':main()
