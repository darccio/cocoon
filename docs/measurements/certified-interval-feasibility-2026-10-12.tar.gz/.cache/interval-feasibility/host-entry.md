# Host entry: private certified-interval feasibility

Read-only source review at documentation HEAD b088fe188d112a644c93d89f99d20791699a7d1f while parent owns CI/merge. This is a proposed entry plan, not the committed experiment specification or implementation approval. Only this ignored note is written; no builds, tests, profiles, benchmarks or tracked changes. Parent must freeze/commit the private experiment specification before any proof implementation. No production cache, translator predicate, runtime/facade/ABI change, external-workspace edit or new public API is proposed.

## Exact scope and numerical obligation

Freeze ONE existing default DDSketch configuration and source algorithm. Its four binary64 parameter words are:

| Field | Exact bits | Value/context |
|---|---|---|
| gamma | 3ff0400000000000 | 1.015625; configuration/encoding identity |
| multiplier | 40501fead4ea6e2b | 64.49870798963154; original numeric read at record+40 |
| minimum | 0010400000000000 | 0x1.04p-1022; original threshold read at+48 |
| index offset | 4094ea0000000000 | 1338.5; original numeric read at+56 |

The current constructor emits these words; source/module hash626550ca… and original Wasm ae0119ca… identify the pinned implementation. For admitted finite nonnegative points, point<minimum takes a zero-count/no-bin path. A certificate must not label that path as integer bin0. Initial certification may deliberately support only positive normal inputs at/above minimum and fall back on every other input, exact-one special branch, reduction discontinuity, unsupported width/saturation region or uncertainty. Restricting coverage is valid if disclosed and counted.

The proposition to prove is: every representable binary64 input in a closed interval maps to the same logical int32 index under the EXACT current branch/reduction/log polynomial, each rounded multiply/add/divide/cast, affine transform, math.Floor and i32_trunc_sat_f64_s. It is not a theorem about ideal ln or ideal gamma^index, nor about samples or only endpoints. An enclosure over a real interval may be used to imply the required statement about all contained float64 values, but the certificate must account for each binary64 rounding and bitwise exponent/mantissa reduction. Do not quietly substitute a host math.Log, FMA, reassociation, decimal-rational coefficient, assumed monotonicity or ideal exponential boundary.

A conservative private proof helper can interpret the pinned scalar expression with outward intervals, provided its primitive rounding enclosure is justified independently. It must split or reject intervals that cross an unproved bit/reduction/branch case; bound bit manipulations and uint32/int32 wrap explicitly; reject any denominator enclosure containing zero, NaN/nonfinite bound, overflow or uncertified branch. To certify nonsaturating bin k, the entire enclosed rounded affine result must lie in [k,k+1), with strict upper<k+1. Floor/saturating alternatives need their own exact proof; initially falling back is simpler. An original oracle binary search may suggest candidate bounds but supplies no continuum certificate. Enumerating a tiny interval is a finite exact result, not proof that a useful wider interval is sound.

## Recommended finite limits to preregister

These are concrete proposed caps for the root's specification, not already accepted policy:

- At most64 retained certificates. At most4096B total retained numeric certificate bank/config/index metadata, including Go slice/header/count/padding overhead. No unbounded map or process-global answer table. Record actual sizes on amd64 and386; unused capacity counts.
- At most64KiB simultaneous proof-builder scratch; at most4096 abstract interval evaluations per requested certificate,262144 per bank construction, depth64, and at most256-bit precision if high-precision arithmetic is used. Count actual primitive evaluations separately. Fixed allocation/precision/node capacities must enforce limits; a post-hoc heap sample is not enforcement.
- Exceeding any work/storage/depth/precision cap yields UNCERTAIN/fallback, never a guessed bin or an unbounded retry. Bound stack/queue and auxiliary temporary limbs; include failed candidate attempts in setup/work counters. The raw transcript may be written for evidence, but its unbounded disk log is not retained proof-bank storage.
- A useful nonvacuity target: at least16 independently verified non-singleton certificates over several nonnegative/negative logical-bin and exponent regions, with represented-member counts disclosed. Include at least one range covering the entire8192-distinct nearby corpus, or report why it cannot be certified. A singleton or handful of adjacent tested values must not pass the wider-interval objective.

An initial negative at any of these constraints is a completed feasibility result. Do not enlarge caps, omit bad branches or tune certificate seeds/replacement against holdouts after results. Any amended experiment gets a new explicit premeasurement plan; existing results stay retained.

## Setup, lookup, uncertainty and churn accounting

Separate three observed scopes rather than subtracting independent benchmarks:

1. Cold bank construction from declared seeds/config: certification success and failures, total attempted regions/primitive evaluations, wall/time per attempt and complete bank, Go allocations/bytes, maximum enforced scratch/depth/precision, retained bank bytes and any file/source/initialization cost. Include discarded certificates. Exact-source extraction and build are provenance, not runtime cost.
2. Warm lookup against an immutable fixed bank: input/config eligibility, interval search and returned logical value. Measure matching false/scaffold control plus original exact pure mapping. Both modes retain identical bank/setup. Input references/results must be consumed. Report hit and miss operations, comparisons/probes per input, first/last endpoint ownership and fallback cost; zero warmed allocations do not erase setup storage.
3. Complete pure numeric replay: decision+lookup+original computation on every miss, with any certification/rebuild/churn work in its timed scope when intended as on-demand work. A miss that silently certifies outside timing is invalid. A separately prebuilt-bank scenario is valid only when explicitly labelled; it cannot establish cheap online certification. Avoid adding separate setup/hit/miss medians as an alleged full-call saving.

Predeclare seeds, interval ordering and finite replay policy before benchmarking. The private replay may discard/rebuild banks to test churn; it is not a production eviction/cache design. Report construction requests, attempted/certified/uncertain/budget-rejected intervals; certified hits, ordinary misses and their reasons; field-mismatch fallbacks; first pass/revisit hits; bank occupancy, discarded/rebuilt certificates, bytes and amortization by sequence; entire numeric outputs. Never count a fallback computation as a certificate hit. Record each1024-input phase plus complete sequences so a global average cannot conceal hot/cold phase losses.

Use separate repeated42, true increasing1..N,8192 UniqueCycle, NearbyUniqueCycle, MostlyUniqueCycle(1/16 hot), Phases, NegativeBins, independent BroadHoldout and reduction/boundary holdouts. Existing named cycles repeat; Increasing is the nonrepeating control. Include starting empty versus prebuilt banks, cold/revisit passes, many short independent contexts, repeated discards/rebuilds and deliberately mismatched configuration words. Do not infer representative application locality: no local private SDK profile was available. Churn/topology context must not be falsely attributed to a pure guest arithmetic transformation.

## Proposed go/no-go ladder

First gate is mathematical soundness plus bounded enforcement, not a timing gain: zero false accepted intervals, independently justified primitive bounds/branch coverage, actual nonvacuous intervals, deterministic identical certificates, all uncertainty/budget/parameter violations falling back, and semantic mutants failing for the intended numeric assertion after compile/setup succeeds. If the proof cannot meet the declared cap or needs oracle membership assumptions, stop with evidence.

Only after that gate, commit a measurement plan for the pure helper. One reasonable predeclared usefulness bar is at least10% complete pure-mapping replay time reduction versus untouched exact mapping AND identical-bank false scaffold in both seven-sample alternating500ms/reversed1s sets on at least one declared nonrepeating nearby workload. Do not use a constant-input hit microbenchmark as its sole promotion result. Require no repeated detected slowdown on broad/negative/mostly-unique replay controls, or explicitly classify the prototype as rejected for general use. Report confidence/p-values, all misses/uncertainty/allocations/storage/setup negatives and untouched ordinary code placement; this numerical-component test never qualifies scalar/facade performance or M1.

A promising pure result would justify a SEPARATE source-pinned guest integration ceiling experiment after another specification/review; it does not automatically approve a compiler pass or cache. That later round needs paired original adaptive scalar/SQL/batch/trace plus matched P1 guards, original fixed-prefix context and P1/P16 one/sixteen-home stream brackets, full checked-call gains versus untouched and matching shape control, same fresh independent references and actual-procs validation. Strict standalone scalar/SQL criteria cannot be relaxed to accommodate the prototype. All compilation/lint/proof/reviewer work stops during measurements.

## Minimum independent executable proof controls

- Preserve an untouched source-pinned original mapping callable independent of the certificate helper. Mechanical exact extraction/liveness/source identity must be audited, but is not by itself an independent ln algorithm.
- Implement or independently audit a primitive enclosure verifier: binary64 constants as exact bits; actual round-to-nearest/cast semantics and every permitted +,−,×,÷ and reduction/bit transformation. An exact rational/high-precision outward checker at higher precision can challenge enclosures; it must not merely call the same floating interval helper. Failure to certify remains valid fallback.
- Challenge all certificate endpoints and nextafter neighbors, interior deterministic/broad values, exact1 and its neighbors, normal/minimum thresholds, exponent/reduction boundaries, near-largest finite values, negative logical bins, signed zeros, subnormals, NaNs/Inf, and every changed configuration word. Samples are regression evidence in addition to the certificate proof, not the mathematical justification.
- Compare accepted logical bins against independent original-Wasm singleton encodings (existing readSingletonSketchBin), then complete scalar and batch Count/protobuf histories with collapse, invalid-late atomic batches, recovery, stale/reused handles and normal lifetime checks if any temporary caller wrapper is authored. A pure test alone does not establish guest memory/reply/ownership behavior. No actual caller integration is part of the initial private proof.
- Run nativeamd64 and actual native386 correctness after the private spec is committed. Cross compilation alone is not native or floating semantic validation. No native arm64 performance claim without execution.
- Required compiling semantic mutants: certificate enlarged across a known bin boundary; wrong bin/config binding; removed strict-upper guard/uncertainty fallback; altered coefficient or branch normalization. They must cause named semantic failures rather than compile/startup/path skips. Exercise budget/depth/storage rejection deterministically, including failed construction paths. No zero-certificate/vacuous ownership skip is acceptable.

## Host barriers for any FUTURE integration

The pure proof stores only numeric configuration bits/bounds/logical bins. It has no instance, handle, guest address, slice view, result descriptor, store offset or mutable store target. Current default gamma is configuration/serialization identity; numeric index reads multiplier/minimum/offset. Do not invent a gamma read as an already existing guest effect, or treat field equality as free. If mapping parameters become variable, every relevant current bit/value must bind certificates; source identity/fixed constructor is not proof of mutable memory identity.

Original threshold+48 read, multiplier+40 read and offset+56 read/trap positions are separate from pure arithmetic. Skipping pure work must never skip/reorder original effects or lifetime validation. In particular, a current logical-length failure at offset+56 must still occur before guest writes even on a nominal interval hit; captured capacity, stale memory pointers or cached parameter snapshots cannot authorize a new access. Do not hold a guest slice over any guest/import/growth boundary. Module field swaps, callbacks, re-entry, logical-header replacement and imports invalidate unproved facts; original guest-owned backing and native trusted preconditions remain necessary.

All Call reset/recovery/currentMemory/MaxMemory and reply checks remain per operation. Numeric lookup is inside the existing execution/ownership policy if later integrated; it cannot run before context/admission/Resource.Use or manufacture success for closed/poisoned/stale handles. Poison advances epoch; old handles never migrate to replacement homes. Future mutable instance/resource memoization needs explicit close/reset/new-home/parameter-change isolation and bounded memory/accounting, not inheritance of safety from this pure fixed-context proof. Certified intervals never cache store pointers: every counter update, allocation, collapse and ordered state write still executes.

The current Session/Batch admission and draining Close contract also remains unchanged. An expensive builder in a guest execution lock would lengthen lock ownership/admitted work, so construction cost/fallback work is observable and must be bounded and counted. Do not add asynchronous work, new cancellation/re-entry semantics or hidden host state outside the approved contract. A new public proposal requires operator approval before implementation; this private feasibility step offers no such permission.

## Existing no-go constraints

Earlier capacities1/64 exact-value caches regressed original increasing scalar23.22%/20.48%, original AddMany34.41%/33.36%, held-out batch50.21%/53.05%; old raw misses cost about39ns versus original17–18ns. The recent unsupported64MiB log oracle wins checked fixed-prefix scalar19.69%/19.38% but misses absolute/fresh M1 targets; outline alone loses2.46%/1.63%, enabled negative scalar2.87%/3.45%, broad scalar3.40%/2.55%, broad batch10.15%/9.51% and SQL holdout1.71%/1.49%. These are retained constraints, not a revived exact-value cache, certified membership, arithmetic approximation, default PGO, public ABI change or production approval. Host R1–R11/unit reply controls remain their prior no-go outcomes; this proof leaves the checked host floor untouched.

## Inputs read

```json
{
  "examples/datadog/go/dd/internal/wasm/module.go": "626550cafa323c490a6a2ec6b2b341656c40e223c7c84701e414078633dcc298",
  "examples/datadog/go/dd/bin_math_test.go": "ead973b7020bedec6fbac658be23b79fee2d40a0cb6096d4ec70acd5e75de3a6",
  "examples/datadog/go/dd/bin_reuse_bench_test.go": "aee2461dbc412268372a620863600f95bb6c3e6ab3cc934d6c4a7e514d73de2a",
  "examples/datadog/shim/src/implementation.rs": "f9334487368b2090799ae8261e315c14350d8480c3af4fcd7e0571a714d2bec4",
  "rt/resource.go": "10576bedf0d4745afed6f73f4dd7db2c0f11c1018b302c2df5cfcfab96cfee8c",
  "rt/instance.go": "607103f216fb1da1445e705deaea8891f21cbdd04f74e385f4958795ef107d74",
  "docs/roadmap.md": "dd2124c6d58a73635f99de94770369514bdc085b0a130f515ba339259c871091"
}
```
