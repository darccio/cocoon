# Final guest evidence and documentation review

**READY for evidence retention.** No source, numerical rule, seed, capacity or
production contract change is requested. Reviewed the new numerical section of
`docs/performance.md`, roadmap/resume and updated specification status against
`numerical-outcome.json`, both native host summaries, `cost-summary.json`, the
frozen specification and the existing proof source. No new build, test,
profile, benchmark or cost observation was run for this final review.

## Numerical and oracle verdict

The documents correctly report 57 non-singleton certificates from 92 attempts,
23 distinct original exponent fields, both logical signs, and complete coverage
of NearbyUniqueCycle by one certificate. Actual amd64/386 bank bytes agree at
SHA-256 `7cbaa190712acef7949eb7cb61724721f43c226499d9904d4a61cf3be7778686`.
All 57 accepted traces verify independently on both architectures. The final
strict collective ledger is 13,329 whole checks per architecture, including 626
tiny members and selected numerical faults; 521 original-Wasm singletons are
below the fixed limits. Earlier author/pre-review runs are explicitly separate.

Thirty requests reject exponent crossings from six power-of-two seeds and five
reject final affine-bin uncertainty at seed 16. No refinements rescue those
seven seeds. Constructor totals of 1,860 rounded nodes, 5,704 endpoint operations
and 3,720 directed conversions include rejected work. The positive decision is
numerical nonvacuity under the signed finite rule, not an online cost claim.

Soundness remains the integer reduction relation plus induction over exact
rounded source nodes and strict final-bin containment. The independent checker
binds source/nodes itself, recomputes signed extrema and uses separate rounding.
Compiled complete OriginalLog/OriginalBin remain distinct from a graph-generated
trace. Finite primitive/interior/native tests and unchanged-Wasm singleton bins
support the argument without becoming an exhaustive Wasm/intermediate-float
proof. The docs retain those distinctions and the unchanged-production effect,
ownership, error, memory and lifetime scope. Nine compiled selected numerical
counterexample modes fail their concrete assertions; compile/startup failure
is not given credit. No new cached guest is claimed.

## Width and storage audit

The checker arithmetic/rounder ledger's 235-bit maximum is not an overall
scratch-width maximum. Its dyadic decoder constructs an unreduced denominator
`2^1074`, whose bit length is 1,075, including for binary64 zero before rational
reduction. For any finite encoding, decode shift ranges follow directly from
the exponent field: denominator shift is at most 1,074, and numerator shift is
at most 971 on a 53-bit significand. Thus raw decoded magnitudes remain at most
1,075 bits and under the independent 4,096-bit guard. The arithmetic/rounder
then uses separately guarded unreduced, scaled and comparison temporaries.
The documentation explicitly separates these scopes; no numerical cap or
constructor output is changed to repair a counter presentation.

Reported representation sizes match native summaries: graph 7,249/7,225 bytes,
complete modeled builder workspace 47,964/47,192, maximum workspace plus export
capacity 56,156/55,384, and bank plus encoding 2,814/2,554 on amd64/386. Fixed
array capacities and handoff images are counted; these are logical storage
figures. The allocating math/big reference, source ASTs, compiler/Go stack and
library scratch are expressly outside a hard heap/RSS/CPU-instruction bound.
Actual allocations and GC-disabled end-of-operation observations are reported
separately. No hidden claim of a 64 KiB process or a cheap miss path is made.

## Cost and coverage audit

All six table medians and confirmation allocation/count columns match
`cost-summary.json`: complete bank 12.413/12.257 ms, independently verified
bank 69.354/69.607 ms, accepted 42 interval 197.945/199.829 microseconds,
early cell rejection 8.847/8.841 microseconds, boundary rejection
204.270/200.786 microseconds and complete independent checker
978.811/975.270 microseconds. These are two sets of absolute fixed-scope
observations, not a baseline speed comparison or significance test. Source
preparation remains outside those scopes and separately reports approximately
143 ms and 40.9 MB in the named confirmation row. Untimed framework/witness
setup and single-operation memory observation scope are disclosed.

Coverage and mismatch counts match both host summaries. Repeated and nearby
are 100%; unique is 9/8,192, mostly unique 633/8,192, phases 768/8,192,
negative bins 1,024/8,192 and broad holdout zero. Increasing is only
1,806/4,194,304, approximately 0.043%. Both passes agree because the bank is
immutable; no on-demand certification, eviction, original miss computation or
warming improvement is implied. Every source/configuration mismatch produces
zero hits. The documents correctly reject promotion of this allocating reference
or sparse bank as a scalar improvement and leave M1 unaccepted.

The frozen signed specification SHA is
`cfaa42706f421f032cebd36d6706eb3f307cad46e1db28d71b496a41d4bba7df`.
The current specification differs only in status/completion-link prose; its
finite numerical/work/cap/domain rules remain unchanged. Gate and identical
61-file reproduction claims are correctly scoped to unchanged production,
with separate private native proof/consumer execution. This final review did
not rerun those commands.

## Minor prose suggestions sent to parent

- The older roadmap track-2 sentence saying to next specify an interval
  feasibility proof is stale now that this proof is complete. Point it to a
  separately specified fast-construction/lookup-cost control.
- The performance conclusion should call the earlier streaming numbers
  recorded throughput observations rather than qualified ceilings: their
  source section explicitly denies strict capacity bounds.

Neither affects the numerical/evidence verdict. Retain the signed specification,
proof, failures, costs and limits only; no cache, production predicate, public
contract, scalar latency gain or M1 acceptance follows. All guest tools stop
after this note and report.
