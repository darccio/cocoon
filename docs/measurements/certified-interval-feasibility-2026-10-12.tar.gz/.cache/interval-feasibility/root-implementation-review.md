# Applied root review before cost observations

The signed private specification was committed before ignored implementation.
No production source/API/artifact/module/lock is changed. All seven production
quality gates passed, and two all-three fixture/runtime reproductions matched
all61 original fingerprints. These control gates do not validate a shipping
cache; no cache/caller substitution is implemented.

The source-derived graph owns cloned slices and pins complete source and
configuration. Independent canonical parsing binds every node/literal/edge,
then recomputes reduction and every signed corner from independently verified
prior slots. Builder floor/ceil integer rounding and checker nearest-even plus
exact comparison/adjacency are distinct implementations. Universal containment
follows cell translation and rounded transfer induction, not finite samples.
Full compiled OriginalLog bits and OriginalBin plus graph-derived primitive
traces are separately named. Original Wasm supplies logical bin/Count/protobuf,
not intermediate numerical traces or a proof over all values.

Applied findings: account complete report/bank/trace handoff workspace; preflight
integer allocation and oversized graph lengths; distinct fatal reason; per-slot
checker point comparison; trace-export capacity and complete workspace; P1
assertions and actual-procs rows; honest full source-binding checker cost and
separate untimed source preparation. Tiny-member calls also consume the whole
graph ledger: final core supplementary enumeration512, preserving its original
8192-wide certificate and all64 bank seeds/caps. Earlier larger author tests,
compiler/cache setup failures and pre-review builds stay archived as preparation,
not the final capped proof set. The host review incorrectly inferred seven cell
failures; raw logs establish30 cell +5 boundary and unchanged seed16 cost scope.

Both final native drivers pass, identical bank SHA
7cbaa190712acef7949eb7cb61724721f43c226499d9904d4a61cf3be7778686.
Every57 accepted trace is independently verified;92 fixed requests span23
original exponent fields, both bin signs, and one includes all8192 nearby values.
Each architecture has13329 whole checks including8 selected-mutant kernel calls,
626 tiny members included in that whole count, and521 original-Wasm requests.
Nine same-ELF numerical faults each require exit1 and its exact numerical marker;
no compiler/startup error earns numerical-fault credit.

Coverage uses immutable prebuilt bank only. Broad0/8192 and Increasing1806/4194304
are negative locality results; repeated and nearby8192/8192 alone establish no
online/full-call speedup. All parameter and source mismatch replays have zero
hits. Request uncertainty and fatal source drift are separate; no partial
unverified trace is promoted.

Reviewed constructor cost scopes are full bank without checker, full bank with
all required accepted-trace checks, accepted seed0 request, early rejected seed3,
fully evaluated boundary-rejected seed16, and full required individual checker.
Source extraction, witness setup, framework1x probe and warm-up are untimed and
disclosed; Load duration/TotalAlloc appear separately. Seven samples per scope
in each of two rotated/reversed orders, CGO0 official Go1.26.8 P1 PGOoff; no
latency promotion comparison. Allocation observations disable GC for one operation
and disclose end-of-operation heap, not peak RSS/hard bounds. All reviewer/build/
quality work must stop before timing, and sources/ELFs/toolchain must freeze.

Source identities reviewed here are root-applied-source-hashes.json. Final cost
observations and durable evidence review remain; numerical feasibility is
positive, cheap online construction and M1 acceptance are not established.
