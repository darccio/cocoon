# Guest entry review: bounded numerical feasibility

Read-only review before the private specification and before any numerical
implementation. No build, test, profile, benchmark, production edit or public
contract proposal was made. The parent is waiting for PR #8 CI/merge before
proceeding with the implementation round.

## Recommended finite question

Can a bounded offline constructor certify a nontrivial inclusive interval of
positive normal binary64 inputs as one exact logical DDSketch bin under one
pinned mapping configuration? Return unknown for every unsupported branch,
parameter configuration, budget exhaustion or enclosure spanning two bins.
This is a numerical feasibility proof, not a cache, compiler predicate,
integration, locality measurement or throughput prediction.

The previous unsupported table demonstrates approximately 19% original checked
fixed-prefix headroom, but uses 64 MiB and loses on fallback-heavy inputs. Exact
outlining itself regresses. A continuum certificate therefore needs its own
construction and resource bounds; the table's gain is not a predicted gain for
this step. No endpoint agreement or mathematical-log monotonicity suffices.

## Exact source and parameter configuration

The current locked translated module SHA-256 is
`626550cafa323c490a6a2ec6b2b341656c40e223c7c84701e414078633dcc298`.
The original pure source is `fn176`, approximately lines 35777–35831; the
threshold/multiplier/offset loads remain at +48/+40/+56 around it, followed by
the affine expression, Floor and `i32_trunc_sat_f64_s` at lines 35832–35833.
The previous reconstruction in `.cache/structural-phase0/proof/prepare.py`
checks the original source region and all surrounding caller text. Its direct
bit reference reconstructs source operations; it is not an independent ln
algorithm or an exported Wasm intermediate.

Default `Xcocoon_sketch_new` publishes these binary64 bits, later copied to
the resource mapping fields (approximately lines 46620–46701):

| Field | Exact bits | Resource offset |
| --- | --- | --- |
| gamma | `3ff0400000000000` | +32 |
| multiplier | `40501fead4ea6e2b` | +40 |
| minimum indexable value | `0010400000000000` | +48 |
| index offset | `4094ea0000000000` | +56 |

Pin all four words, the source, literal conversions and saturation helper.
Derive these words from the authored/current source rather than recomputing
default parameters with host ln/exp. The pinned Rust source is
`libdd-ddsketch/src/lib.rs`: `index` floors `value.ln()*multiplier+offset`;
`add_with_count` rejects invalid points, routes below-threshold values to the
zero counter, then updates the ordered low-collapsing store. The authored shim
validates an entire AddMany input before any mutation. None of those operations
is implemented differently in this offline step.

## Conservative certificate

1. Represent a request by inclusive uint64 input-bit endpoints. Require positive
   normal finite endpoints, ordered bits, the exact parameter tuple, and every
   input in the interval at or above the pinned threshold. Positive normal bit
   order is numeric order. Reject negative, zero, subnormal, NaN/Inf and
   below-threshold intervals. These remain outside the first certificate scope.
2. Partition at original exponent boundaries and at the normalization carry.
   With original high word H, the source computes H+`0x95f62`. Carry occurs when
   the original mantissa high word reaches `0x6a09e`. Within one exponent/carry
   segment the reduced exponent K is constant. Isolate the exact input 1.0,
   whose original branch returns +0 directly. Reject rather than implicitly
   evaluating one branch for an interval crossing any of these boundaries.
3. Derive the source bit transformation exactly, including the low 32 bits and
   `((H+0x95f62)&0xfffff)+0x3fe6a09e` high-word construction. Within a qualified
   segment this is an increasing affine map of input bits to positive reduced
   binary64 bits; prove that integer relation and its lack of wrap. Endpoint
   reduction bounds follow from this integer proof, not from monotonic ln.
4. Parse the pinned AST into an immutable, versioned expression/assignment graph
   preserving temporary reassignments and every explicit binary64 rounding
   boundary. Interpret the original operations in order. A binding, operation,
   branch, literal, cast or helper outside the small whitelist means unknown.
   Never simplify, reassociate, contract into FMA, substitute math.Log, or use a
   hand-transplanted polynomial as the source of truth.
5. Enclose every rounded +, -, *, / operation. Addition/subtraction have the
   appropriate endpoint extrema; multiplication/division consider all four
   endpoint combinations. Division is unknown if the denominator enclosure
   includes zero. Every endpoint result gets conservative directed binary64
   bounds. Correlated operands may widen the enclosure; this is a reason to
   fall back, not permission to discard dependency or an error term.
6. Apply the pinned multiplier and offset as two separately rounded operations,
   then the exact Floor and signed saturating conversion. Only accept when both
   final enclosure endpoints map to the same logical int32 value. The floor/
   clamp maps are monotone on finite real values; this final monotonicity is
   distinct from an assumption about the logarithm. An upper enclosure exactly
   at the next bin boundary conservatively rejects. Reject NaN/nonfinite or
   unsupported enclosure cases; singleton 1.0 still goes through affine/Floor/
   saturation. A singleton or a sampled endpoint is not a useful-width proof.

The universal claim is conditional on the interval invariant and induction over
the exact rounded AST, with proven interval primitives and integer reduction.
Finite tests strengthen that proof and catch implementation defects; they do
not exhaust an arbitrary 52-bit mantissa interval by themselves.

## Arithmetic reference and architecture risks

Use exact rational arithmetic for the offline trusted enclosure/reference.
Decode every finite binary64 operand and literal to an exact dyadic rational;
compute exact endpoint extrema; convert outward directly to binary64, including
subnormal underflow and overflow policy. Do not silently double-round through
a finite-precision big.Float intermediate. A separately checked integer
quotient/remainder implementation of round-to-nearest/ties-to-even supplies
point-oracle bits for each original source operation. Check literal decimal
conversion against exact constants and actual compiled values.

A native constructor using one Nextafter toward each infinity around each
ordinary endpoint operation can be sound and cheaper: prove containment
against exact rational endpoint extrema at every primitive. Require explicit
float64 rounding, no FMA/contraction, correctly rounded endpoint operations,
finite ordered enclosures, denominator separation from zero, and known native
floating mode. Native amd64/386 replay plus matching ordinary assembly can
support that implementation later; neither architecture test alone proves all
inputs. For the first proof prefer the exact-rational path. Native intervals
are an optional separately audited constructor, not a prerequisite or a
promised production hot path.

Signed-zero distinctions are preserved by the point oracle. Real interval
bounds may enclose both zero signs only where sign cannot affect a following
division or branch; otherwise unknown. Exponent extremes, cancellation, the
reduction seam, values immediately adjacent to 1.0, and negative intermediate
polynomial terms need directed rounding just as positive terms do.

## Proposed upfront limits for the private spec

These are proposed finite experiment limits, not implemented measurements:

- One exact source/configuration; at most 96 rounded floating nodes on the
  selected normal path, with at most four exact corner operations per node.
  Refuse a source whose derived graph exceeds its registered node bound.
- At most 256 seed requests, 1,024 total constructor attempts and 16 refinements
  per seed. Split known branch seams first; bound any bit midpoint refinement
  explicitly. No unbounded binary search, recursion, retry or certificate
  expansion. At least one accepted certificate must cover distinct inputs.
- At most 256 retained certificates, each an explicitly serialized pair of
  uint64 bounds plus int32 logical bin: 20 bytes each, 5,120 bytes total. A
  fixed 32-byte parameter tuple and source identity apply to that collection.
  Bound AST/trace output separately, for example a 16 KiB graph and 64 KiB trace
  cap; exceeding either means unknown rather than unbounded output.
- Guard exact-rational numerator/denominator magnitudes, with a conservative
  4,096-bit result cap for one elementary operation over finite binary64
  endpoint operands; each node rounds back to binary64 before the next node.
  Count and cap rational endpoint/conversion work and live slots explicitly.
  Do not describe these logical byte caps as a hard process/Go-heap cap while
  using allocating math/big: allocator/transient/scratch bytes must be measured
  separately, or fixed storage must actually enforce them. A constructor that
  exceeds its work or storage ledger returns unknown.

This bounds the first question without inventing a resource-local cache model.
The parent should choose and commit the precise counters/byte ledger before
implementation. Certification costs, coverage and storage are first-class
outputs; elapsed timings and throughput come only after source/proof review.

## Minimum executable proof and negative controls

The proof should check source/AST identity and actual parameter bytes first.
Use an independent exact-integer rational/rounding checker for arithmetic,
source-derived direct point evaluation for operation bits, and unchanged
original Wasm singleton sketches/decoded protobuf logical bins for independent
engine evidence. These are three different scopes; do not claim host rational
math is an independent ln implementation, or full guest state equivalence for
a pure offline certificate that is never integrated into a guest.

Required families:

- Primitive rational extrema and outward/nearest rounding: exact results,
  halfway-even ties, nextafter neighbors, subnormal underflow, signed zero,
  cancellation, negative products/divisors, and nonfinite/zero-denominator
  rejection. Trace every source operation on representative actual inputs.
- Every normal exponent and both sides of the reduction carry; low-word
  transitions and neighboring bits; exact 1.0 and its neighbors; threshold
  below/equal/above; source-coefficient and affine integer-boundary neighbors.
- Exhaustively enumerate bounded small certified bit spans, including interiors,
  and separately probe endpoints plus stratified/random interior bits of wider
  certificates. Document the inductive enclosure proof as the universal basis;
  finite enumeration has its actual finite size. Explicit unknown cases cover
  crossing exponent/seam/1.0, two-bin bounds, invalid parameter bits and budget
  exhaustion. Certificates outside the pinned tuple must never be reused.
- Original-Wasm one-point bin extraction for accepted interior samples and
  rejected/fallback edges. Fresh resources avoid collapsing-store ambiguity;
  Count/full protobuf supplies oracle checks. Existing zero/invalid/atomic batch,
  collapse and lifetime tests remain relevant unchanged-production controls,
  not integration tests for a new cached guest.
- Post-construction mutants: inward instead of outward rounding; wrong seam/
  reduced exponent; Floor replaced by truncation; accept an enclosure spanning
  two verified bins; change a parameter while allowing reuse; change a pinned
  source coefficient/rounding boundary. Reject via explicit named semantic
  assertions or deliberate source-drift rejection, identifying which category
  each proves. Do not count compiler/startup errors as semantic rejection.

Native amd64 and actual native 386 are the useful first implementation gates
once authorized. Record tool/source/parameter hashes, exact argv, failed setup
expectations and unsupported cases. No native arm64, big-endian or application
locality claim follows from those two architectures.

## Effect boundary and verdict

Go for a separately reviewed private offline feasibility specification only.
This review makes no claim that certification is cheap or that useful coverage
is attainable. A later guest integration would still need original threshold,
multiplier and offset reads/checks at their original positions, exact parameter
bits, invalid/batch atomicity, ordered counter/collapse updates, partial effects,
memory/import/growth barriers, poisoning, epochs and old-handle invalidation.
Only the logical result could be reused; no store address or resource pointer.
Those are future proof obligations, not work authorized in this pure step.

Previously rejected exact-value caches, numeric classifiers, approximations,
polynomial simplification, recovery/unit reply rewrites and small guard probes
remain excluded. This note uses the current source's operations and bits, never
reference payload code or host math.Log. All tools stop after the entry report.
