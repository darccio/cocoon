# Private certified-interval feasibility evidence

PR #8 merged at aeaf01b after four green CI checks; local main fast-forwarded.
Signed private specification 8c8791b preceded ignored implementation. Production
source, API, modules, artifacts and locks remain unchanged. The immutable
measurement specification is frozen-spec.md, SHA-256
cfaa42706f421f032cebd36d6706eb3f307cad46e1db28d71b496a41d4bba7df.
Later documentation status and links change no seed, cap or decision rule.

The universal argument is exact integer cell translation, rounded interval
transfer induction and strict bin containment. Independent canonical source
binding and signed-corner recomputation verify every trace. Finite compiled
source/native/Wasm checks supplement that argument. Wasm supplies no intermediate
float trace. The graph-generated point trace is distinct from full compiled
OriginalLog/OriginalBin. Checker arithmetic/rounder MaxIntegerBits=235 excludes
its decoder's raw 1,075-bit zero denominator; the separately guarded decoder
fits the 4,096-bit cap by finite-encoding bounds.

Numerical outcome: 57 independently verified non-singleton certificates in 92
attempts (57 accepted, 30 cell, 5 boundary), 23 original exponent fields, both bin
signs, and one interval containing all 8,192 nearby values. Bank SHA-256
7cbaa190712acef7949eb7cb61724721f43c226499d9904d4a61cf3be7778686
agrees on executed amd64/386. Each final driver has 13,329 whole evaluations,
626 tiny members counted in that whole ledger, and 521 fresh Wasm requests,
below 16,384/262,144/2,048 caps. Earlier focused tests, corrected compiler/cache
failures and pre-review builds are preserved author preparation, outside the
final capped driver. Nine compiled numerical fault modes each require exit 1
and its intended NUMERICAL_MUTANT marker; startup failures never earn credit.

All 84 raw cost rows remain: two rounds, seven samples, six scopes; official
Go 1.26.8, CGO=0, amd64v1, P1, PGO off. BankConstruct/BankVerified use 32x;
Accepted42/RejectedBoundary/AcceptedChecker use 512x; RejectedCell2 uses 65536x.
Rotated/reversed orders retain every source/binary/toolchain hash, raw command,
row and metric. Complete construction costs 12.257 ms / 6.35 MB allocated;
required verification raises this to 69.607 ms / 22.95 MB. Source extraction,
witness setup, the framework 1x probe and scope warm-up are excluded and
separately disclosed. Source preparation metrics remain in each row.
There is no timing gain, significance test or full-call claim.

Before/after conditions preserve CPU policy, machine, timestamps and process
PID/PPID/command. Unrelated shell-wrapper arguments are intentionally omitted,
as condition-redaction.json records. No benchmark sample or numeric metric
changed. GC-disabled single-operation memory records retain before/after/
forced-GC MemStats. Negative collected deltas are not retained-bank sizes or
peak RSS. Logical graph/bank/workspace bounds impose no hard Go heap/stack/RSS
cap on allocating math/big reference machinery.

Coverage is immutable offline-bank locality, with no eviction, fill or original
miss execution. Repeated/Nearby=100%, Unique=0.110%, MostlyUnique=7.727%,
Phases=9.375%, Negative=12.5%, Broad=0%, Increasing=1806/4194304 (0.043%).
First/revisit totals agree. Parameter/source mismatch replay hits are zero.
Every 1,024-input phase and all fresh Wasm Count/protobuf records remain in
consumer-ARCH.jsonl.

Quality check/race/rust/cross/smoke/fuzz/integration all pass on unchanged
production; two builds of all three proof packages and runtime reproduce all
61 fingerprints. Check uses Go 1.26.8 and official golangci-lint 2.13.1 with
49 strict linters; other gates use system Go 1.27.2 and Rust 1.97.0. Private
proofs separately execute on amd64/386. There is no native arm64/big-endian or
representative private SDK claim.

## Offline reproduction

Audit compressed SHA-256 and MANIFEST.json before restoring relative paths in
a separate Cocoon checkout with exact production fingerprints. Compiler, ELFs
and caches are omitted. Use official Go 1.26.8 under
.cache/toolchains/go1.26.8/go, CGO=0, GOTOOLCHAIN=local, GOAMD64=v1, PGO off.
If relocating the checkout, update consumer.mod's local replace path and record
new provenance; production go.mod/go.sum stay untouched. Archived writers
refuse existing outputs, so reproduce in a separate copy with output logs,
JSONL and generated binaries cleared while preserving the original bundle.

In .cache/interval-feasibility/proof run:

    go run -pgo=off ./cmd/generate-native <ROOT>/examples/datadog/go/dd/internal/wasm/module.go <PROOF>/native_generated.go

Regenerated source should match the supplied helper. It contains the complete
compiled log and a separately labeled graph trace. The full production module
and Wasm hashes are pinned in source and proof-before.json.

From repository root:

    python3 .cache/interval-feasibility/proof-run.py build applied
    python3 .cache/interval-feasibility/proof-run.py amd64
    python3 .cache/interval-feasibility/proof-run.py 386
    python3 .cache/interval-feasibility/mutant-run.py amd64
    python3 .cache/interval-feasibility/mutant-run.py 386

Actual 386 execution is required; cross-compilation with -exec=true is
insufficient. Numerical faults must exit 1 at the indicated assertion.

After reviews, stop all builds, linters, fuzzers, profiles and reviewer tools:

    python3 .cache/interval-feasibility/cost-run.py freeze
    python3 .cache/interval-feasibility/cost-run.py run
    python3 .cache/interval-feasibility/cost-run.py memory
    python3 .cache/interval-feasibility/cost-run.py summarize

The frozen recorder initially collected shell-wrapper arguments; any new
reproduction should keep only ps PID/PPID/command, recording this metadata
change as new provenance. All original numeric samples remain untouched.

qualify.py runs seven gates and two proof/runtime reproductions; it needs
Rust/cargo, Binaryen 133 and official lint 2.13.1. It must preserve production
fingerprints. Final documentation/staged validation and signing happen after
the evidence bundle is frozen and are recorded in Git and local retention logs.

The bundle retains exact source, scripts, proofs, reviews and logs; ELFs are
identified by hashes and build commands. docs/performance.md and roadmap.md
hold durable conclusions. M1 remains unaccepted. Next separately specify a
fast bounded constructor or lookup-cost control; consider guest integration
and eligibility only if justified. No production cache or public contract is
implemented. The new branch remains local.
