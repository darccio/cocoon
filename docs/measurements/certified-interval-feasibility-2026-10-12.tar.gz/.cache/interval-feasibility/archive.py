"""Retain exact private proof/cost/review evidence, omitting caches and ELFs."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'.cache/interval-feasibility'
TARGET=ROOT/'docs/measurements/certified-interval-feasibility-2026-10-12.tar.gz'
extensions={'.go','.mod','.sum','.json','.jsonl','.txt','.md','.log','.py','.sh'}
files={}
for p in sorted(OUT.rglob('*')):
 if not p.is_file() or any(part in {'gocache','__pycache__'} for part in p.relative_to(OUT).parts):continue
 if p.suffix not in extensions and p.name not in {'staged-tree','staged-snapshot'}:continue
 files[str(p.relative_to(ROOT))]=p.read_bytes()
manifest={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in files.items()}
stream=io.BytesIO()
with tarfile.open(fileobj=stream,mode='w') as archive:
 for name,data in [('MANIFEST.json',(json.dumps(manifest,indent=2)+'\n').encode()),*sorted(files.items())]:
  assert not Path(name).is_absolute() and '..' not in Path(name).parts
  member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644;member.mtime=0
  archive.addfile(member,io.BytesIO(data))
packed=gzip.compress(stream.getvalue(),mtime=0)
with tarfile.open(fileobj=io.BytesIO(packed),mode='r:gz') as archive:
 members=archive.getmembers();assert len(members)==len(manifest)+1
 assert len({m.name for m in members})==len(members)
 assert {m.name for m in members}==set(manifest)|{'MANIFEST.json'}
 assert json.loads(archive.extractfile('MANIFEST.json').read())==manifest
 for member in members:
  assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
  if member.name=='MANIFEST.json':continue
  data=archive.extractfile(member).read();assert len(data)==manifest[member.name]['bytes'];assert hashlib.sha256(data).hexdigest()==manifest[member.name]['sha256']
assert not TARGET.exists()
with TARGET.open('xb') as archive:archive.write(packed)
digest=hashlib.sha256(packed).hexdigest()
TARGET.with_name(TARGET.name+'.sha256').write_text(digest+'  '+TARGET.name+'\n')
inventory={'payload_files':len(files),'members_including_manifest':len(files)+1,'compressed_bytes':len(packed),'compressed_sha256':digest,'cost_rows':84,'native_architectures':['amd64','386'],'production_files_unchanged':61}
(OUT/'archive-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
print(json.dumps(inventory,indent=2))
