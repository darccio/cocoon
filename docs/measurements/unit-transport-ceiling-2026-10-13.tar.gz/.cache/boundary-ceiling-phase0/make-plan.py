from pathlib import Path
import json
out=Path('.cache/boundary-ceiling-phase0');groups=[]
def case(role,binary,parts,procs=1):return {'role':role,'binary':binary,'parts':parts,'actual_procs':procs}
def group(key,cases,scope='adaptive',primary=False):
 groups.append({'key':key,'cases':cases,'scope':scope,'primary':primary,'comparators':[[c['role'],cases[-1]['role']] for c in cases[:-1]] if primary or scope=='fixed' else [[cases[0]['role'],cases[1]['role']]]})
for corpus in ['Increasing','Repeated','UniqueCycle','NearbyUniqueCycle','MostlyUniqueCycle','Phases','BroadHoldout','NegativeBins']:
 group('Fixed-'+corpus,[case('Bare','bare',['BenchmarkPhase0TransportOriginalFixed',corpus]),case('Original','augmented',['BenchmarkPhase0TransportOriginalFixed',corpus]),case('Checked','augmented',['BenchmarkPhase0TransportScaffoldFixed','Checked',corpus]),case('Oracle','augmented',['BenchmarkPhase0TransportScaffoldFixed','Oracle',corpus])],'fixed',corpus=='Increasing')
group('Adaptive-Increasing',[case('Bare','bare',['BenchmarkPhase0TransportOriginalAdaptive']),case('Original','augmented',['BenchmarkPhase0TransportOriginalAdaptive']),case('Checked','augmented',['BenchmarkPhase0TransportScaffoldAdaptive','Checked']),case('Oracle','augmented',['BenchmarkPhase0TransportScaffoldAdaptive','Oracle'])],primary=True)
for key,parts in [('OriginalScalar',['BenchmarkSketchAdd']),('OriginalSQL',['BenchmarkObfuscateSQL']),('OriginalBatch',['BenchmarkSketchAddMany1k']),('OriginalTrace',['BenchmarkObfuscateTraces1k']),('VariedScalar',['BenchmarkSketchAddVaried']),('NegativeScalar',['BenchmarkSketchAddNegativeBins']),('VariedSQL',['BenchmarkObfuscateSQLVaried']),('SQLHoldout',['BenchmarkObfuscateSQLTranslationHoldout']),('BroadBatch',['BenchmarkSketchMatchedBatch','Holdout','N8192','Facade']),('BroadTrace',['BenchmarkPhase0TraceHoldout'])]:
 group('Bracket-'+key,[case('Bare','bare',parts),case('Augmented','augmented',parts)])
 if key in ['OriginalScalar','OriginalSQL']:
  groups[-1]['cases'].append(case('Reference','reference',parts));groups[-1]['comparators'].append(['Reference','Augmented'])
for corpus in ['Fixed','Holdout']:
 for procs,homes in [(1,1),(16,1),(16,16)]:
  parts=['BenchmarkStreamStandalone',corpus,'P'+str(procs),'Chunk64','Retain32'] if homes==1 else ['BenchmarkStreamChecked',corpus,'P16','Chunk64','N32','StandaloneHomesP']
  group('Stream-'+corpus+'-P'+str(procs)+'-Homes'+str(homes),[case('Bare','stream-bare',parts,procs),case('Augmented','stream-augmented',parts,procs)])
plan={'samples':7,'rounds':[{'name':'screen','duration':'500ms','prefix':4194304,'reverse':False},{'name':'confirm','duration':'1s','prefix':8388608,'reverse':True}],'measurement_go_version':'go1.26.8','groups':groups,'binaries':{name:str((out/(filename+'.test')).resolve()) for name,filename in [('bare','bare-amd64'),('augmented','augmented-amd64'),('stream-bare','stream-bare'),('stream-augmented','stream-augmented'),('reference','reference-observed')]},'expected_rows':14*sum(len(g['cases']) for g in groups),'decision':'Adaptive-Increasing AND Fixed-Increasing >=10% median time reduction with unadjusted p<.05 against Bare,Original,Checked in BOTH sets; any nonprimary detected slowdown same comparator BOTH sets rejects; no retiming/filter/layout rescue; unsupported ABI3 and no M1 acceptance'}
for item in groups:
 item['guard_comparators']=[pair for pair in item['comparators'] if 'Reference' not in pair]
 item['contextual_comparators']=[pair for pair in item['comparators'] if 'Reference' in pair]
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print(len(groups),sum(len(g['cases']) for g in groups),plan['expected_rows'])
