TEXT dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).Phase0SketchAdd(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/internal/wasm/phase0_add.go
  phase0_add.go:7	0x691c80		493b6610		CMPQ SP, 0x10(R14)									
  phase0_add.go:7	0x691c84		0f86c80b0000		JBE 0x692852										
  phase0_add.go:7	0x691c8a		55			PUSHQ BP										
  phase0_add.go:7	0x691c8b		4889e5			MOVQ SP, BP										
  phase0_add.go:7	0x691c8e		4883ec70		SUBQ $0x70, SP										
  phase0_add.go:10	0x691c92		8b5050			MOVL 0x50(AX), DX									
  phase0_add.go:11	0x691c95		448d42f0		LEAL -0x10(DX), R8									
  phase0_add.go:12	0x691c99		44894050		MOVL R8, 0x50(AX)									
  phase0_add.go:13	0x691c9d		4c8b4838		MOVQ 0x38(AX), R9									
  phase0_add.go:13	0x691ca1		4981f9b0cf1000		CMPQ R9, $0x10cfb0									
  phase0_add.go:13	0x691ca8		0f86970b0000		JBE 0x692845										
  phase0_add.go:13	0x691cae		4889842480000000	MOVQ AX, 0x80(SP)									
  phase0_add.go:13	0x691cb6		f20f11842490000000	MOVSD_XMM X0, 0x90(SP)									
  phase0_add.go:13	0x691cbf		888c2498000000		MOVB CL, 0x98(SP)									
  phase0_add.go:10	0x691cc6		8954242c		MOVL DX, 0x2c(SP)									
  phase0_add.go:11	0x691cca		4489442420		MOVL R8, 0x20(SP)									
  phase0_add.go:13	0x691ccf		4c8b4830		MOVQ 0x30(AX), R9									
  phase0_add.go:13	0x691cd3		450fb689b0cf1000	MOVZX 0x10cfb0(R9), R9									
  phase0_add.go:13	0x691cdb		0f1f440000		NOPL 0(AX)(AX*1)									
  phase0_add.go:14	0x691ce0		4183f901		CMPL R9, $0x1										
  phase0_add.go:14	0x691ce4		7437			JE 0x691d1d										
  phase0_add.go:13	0x691ce6		48899c2488000000	MOVQ BX, 0x88(SP)									
  phase0_add.go:15	0x691cee		e86d48f4ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn41(SB)		
  phase0_add.go:18	0x691cf3		488b842480000000	MOVQ 0x80(SP), AX									
  phase0_add.go:13	0x691cfb		0fb68c2498000000	MOVZX 0x98(SP), CX									
  phase0_add.go:172	0x691d03		8b54242c		MOVL 0x2c(SP), DX									
  phase0_add.go:23	0x691d07		488b9c2488000000	MOVQ 0x88(SP), BX									
  phase0_add.go:24	0x691d0f		448b442420		MOVL 0x20(SP), R8									
  unsafe.go:35		0x691d14		f20f10842490000000	MOVSD_XMM 0x90(SP), X0									
  phase0_add.go:18	0x691d1d		4c8b4838		MOVQ 0x38(AX), R9									
  module.go:62983	0x691d21		4981f973ce1000		CMPQ R9, $0x10ce73									
  module.go:62983	0x691d28		0f860a0b0000		JBE 0x692838										
  phase0_add.go:18	0x691d2e		4c8b4830		MOVQ 0x30(AX), R9									
  module.go:62984	0x691d32		4183b970ce100000	CMPL 0x10ce70(R9), $0x0									
  module.go:62984	0x691d3a		660f1f440000		NOPW 0(AX)(AX*1)									
  phase0_add.go:19	0x691d40		0f85d00a0000		JNE 0x692816										
  phase0_add.go:20	0x691d46		90			NOPL											
  module.go:63001	0x691d47		41c78170ce1000ffffffff	MOVL $-0x1, 0x10ce70(R9)								
  phase0_add.go:21	0x691d52		4c8b4838		MOVQ 0x38(AX), R9									
  phase0_add.go:21	0x691d56		660f1f840000000000	NOPW 0(AX)(AX*1)									
  phase0_add.go:21	0x691d5f		90			NOPL											
  module.go:62983	0x691d60		4981f97fce1000		CMPQ R9, $0x10ce7f									
  module.go:62983	0x691d67		0f869d0a0000		JBE 0x69280a										
  phase0_add.go:22	0x691d6d		90			NOPL											
  module.go:62983	0x691d6e		4981f983ce1000		CMPQ R9, $0x10ce83									
  module.go:62983	0x691d75		0f86830a0000		JBE 0x6927fe										
  phase0_add.go:21	0x691d7b		488b5030		MOVQ 0x30(AX), DX									
  phase0_add.go:24	0x691d7f		4589c1			MOVL R8, R9										
  phase0_add.go:24	0x691d82		4c894c2468		MOVQ R9, 0x68(SP)									
  module.go:62984	0x691d87		8b8a7cce1000		MOVL 0x10ce7c(DX), CX									
  module.go:62984	0x691d8d		8bba80ce1000		MOVL 0x10ce80(DX), DI									
  phase0_add.go:23	0x691d93		4889de			MOVQ BX, SI										
  phase0_add.go:23	0x691d96		4489c3			MOVL R8, BX										
  phase0_add.go:23	0x691d99		e8a221f5ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn84(SB)		
  phase0_add.go:24	0x691d9e		488b842480000000	MOVQ 0x80(SP), AX									
  phase0_add.go:24	0x691da6		488b5038		MOVQ 0x38(AX), DX									
  module.go:62983	0x691daa		4c8b442468		MOVQ 0x68(SP), R8									
  module.go:62983	0x691daf		4d8d4807		LEAQ 0x7(R8), R9									
  module.go:62983	0x691db3		4c39ca			CMPQ DX, R9										
  module.go:62983	0x691db6		0f863d0a0000		JBE 0x6927f9										
  phase0_add.go:24	0x691dbc		488b7030		MOVQ 0x30(AX), SI									
  module.go:62983	0x691dc0		498d7803		LEAQ 0x3(R8), DI									
  phase0_add.go:31	0x691dc4		90			NOPL											
  module.go:62984	0x691dc5		418b4c3004		MOVL 0x4(R8)(SI*1), CX									
  module.go:62983	0x691dca		4839fa			CMPQ DX, DI										
  module.go:62983	0x691dcd		0f86210a0000		JBE 0x6927f4										
  module.go:62984	0x691dd3		8b5c2420		MOVL 0x20(SP), BX									
  module.go:62984	0x691dd7		4189da			MOVL BX, R10										
  module.go:62984	0x691dda		458b1c32		MOVL 0(R10)(SI*1), R11									
  module.go:62984	0x691dde		6690			NOPW											
  phase0_add.go:33	0x691de0		4183fbff		CMPL R11, $-0x1										
  phase0_add.go:33	0x691de4		7418			JE 0x691dfe										
  module.go:63009	0x691de6		4d8d600f		LEAQ 0xf(R8), R12									
  phase0_add.go:34	0x691dea		90			NOPL											
  module.go:63009	0x691deb		4c39e2			CMPQ DX, R12										
  module.go:63009	0x691dee		0f86fb090000		JBE 0x6927ef										
  module.go:63010	0x691df4		498b543008		MOVQ 0x8(R8)(SI*1), DX									
  phase0_add.go:36	0x691df9		e946070000		JMP 0x692544										
  module.go:62983	0x691dfe		4c894c2460		MOVQ R9, 0x60(SP)									
  module.go:62983	0x691e03		48897c2458		MOVQ DI, 0x58(SP)									
  module.go:62984	0x691e08		4c89542450		MOVQ R10, 0x50(SP)									
  phase0_add.go:38	0x691e0d		8b5050			MOVL 0x50(AX), DX									
  phase0_add.go:38	0x691e10		89542428		MOVL DX, 0x28(SP)									
  phase0_add.go:39	0x691e14		8d72c0			LEAL -0x40(DX), SI									
  phase0_add.go:40	0x691e17		897050			MOVL SI, 0x50(AX)									
  unsafe.go:35		0x691e1a		f20f10842490000000	MOVSD_XMM 0x90(SP), X0									
  unsafe.go:35		0x691e23		66490f7ec3		MOVQ X0, R11										
  phase0_add.go:43	0x691e28		4d89dc			MOVQ R11, R12										
  phase0_add.go:43	0x691e2b		490fbaf33f		BTRQ $0x3f, R11										
  phase0_add.go:49	0x691e30		4d8d6c24ff		LEAQ -0x1(R12), R13									
  phase0_add.go:54	0x691e35		49bf000000000000f0ff	MOVQ $0xfff0000000000000, R15								
  phase0_add.go:54	0x691e3f		4d01df			ADDQ R11, R15										
  phase0_add.go:42	0x691e42		90			NOPL											
  phase0_add.go:45	0x691e43		4d85db			TESTQ R11, R11										
  phase0_add.go:45	0x691e46		410f94c3		SETE R11										
  phase0_add.go:48	0x691e4a		450fb6db		MOVZX R11, R11										
  phase0_add.go:49	0x691e4e		49b8ffffffffffff0f00	MOVQ $0xfffffffffffff, R8								
  phase0_add.go:49	0x691e58		4d39e8			CMPQ R8, R13										
  phase0_add.go:49	0x691e5b		410f97c0		SETA R8											
  phase0_add.go:52	0x691e5f		450fb6c0		MOVZX R8, R8										
  phase0_add.go:52	0x691e63		4509c3			ORL R8, R11										
  phase0_add.go:54	0x691e66		49b8000000000000e07f	MOVQ $0x7fe0000000000000, R8								
  phase0_add.go:54	0x691e70		4d39f8			CMPQ R8, R15										
  phase0_add.go:54	0x691e73		410f97c0		SETA R8											
  phase0_add.go:57	0x691e77		450fb6c0		MOVZX R8, R8										
  phase0_add.go:58	0x691e7b		4d85e4			TESTQ R12, R12										
  phase0_add.go:58	0x691e7e		410f9dc4		SETGE R12										
  phase0_add.go:61	0x691e82		450fb6e4		MOVZX R12, R12										
  phase0_add.go:61	0x691e86		4521e0			ANDL R12, R8										
  phase0_add.go:61	0x691e89		4509d8			ORL R11, R8										
  phase0_add.go:61	0x691e8c		4585c0			TESTL R8, R8										
  phase0_add.go:61	0x691e8f		0f8493030000		JE 0x692228										
  phase0_add.go:39	0x691e95		89742424		MOVL SI, 0x24(SP)									
  phase0_add.go:85	0x691e99		8d5ac8			LEAL -0x38(DX), BX									
  phase0_add.go:85	0x691e9c		0f1f4000		NOPL 0(AX)										
  phase0_add.go:85	0x691ea0		e81be8f9ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn176(SB)		
  phase0_add.go:86	0x691ea5		488b842480000000	MOVQ 0x80(SP), AX									
  phase0_add.go:86	0x691ead		488b5038		MOVQ 0x38(AX), DX									
  phase0_add.go:86	0x691eb1		8b742424		MOVL 0x24(SP), SI									
  phase0_add.go:86	0x691eb5		89f6			MOVL SI, SI										
  module.go:62983	0x691eb7		488d7e0b		LEAQ 0xb(SI), DI									
  module.go:62983	0x691ebb		0f1f440000		NOPL 0(AX)(AX*1)									
  module.go:62983	0x691ec0		4839fa			CMPQ DX, DI										
  module.go:62983	0x691ec3		0f8621090000		JBE 0x6927ea										
  phase0_add.go:86	0x691ec9		488b7830		MOVQ 0x30(AX), DI									
  module.go:62984	0x691ecd		448b443e08		MOVL 0x8(SI)(DI*1), R8									
  phase0_add.go:88	0x691ed2		4585c0			TESTL R8, R8										
  phase0_add.go:88	0x691ed5		7536			JNE 0x691f0d										
  phase0_add.go:124	0x691ed7		90			NOPL											
  module.go:63000	0x691ed8		488b4c2458		MOVQ 0x58(SP), CX									
  module.go:63000	0x691edd		0f1f00			NOPL 0(AX)										
  module.go:63000	0x691ee0		4839ca			CMPQ DX, CX										
  module.go:63000	0x691ee3		0f86fc080000		JBE 0x6927e5										
  module.go:63001	0x691ee9		488b542450		MOVQ 0x50(SP), DX									
  module.go:63001	0x691eee		c70417ffffffff		MOVL $-0x1, 0(DI)(DX*1)									
  module.go:63009	0x691ef5		488b742468		MOVQ 0x68(SP), SI									
  module.go:62983	0x691efa		488b7c2460		MOVQ 0x60(SP), DI									
  module.go:62983	0x691eff		4989c8			MOVQ CX, R8										
  module.go:62984	0x691f02		4989d1			MOVQ DX, R9										
  phase0_add.go:127	0x691f05		4889c1			MOVQ AX, CX										
  phase0_add.go:127	0x691f08		e9cf040000		JMP 0x6923dc										
  module.go:62983	0x691f0d		4c8d4e0f		LEAQ 0xf(SI), R9									
  phase0_add.go:89	0x691f11		90			NOPL											
  module.go:62983	0x691f12		4c39ca			CMPQ DX, R9										
  module.go:62983	0x691f15		0f86c3080000		JBE 0x6927de										
  module.go:63000	0x691f1b		4c8d4e2b		LEAQ 0x2b(SI), R9									
  phase0_add.go:91	0x691f1f		90			NOPL											
  module.go:62984	0x691f20		448b543e0c		MOVL 0xc(SI)(DI*1), R10									
  module.go:63000	0x691f25		4c39ca			CMPQ DX, R9										
  module.go:63000	0x691f28		0f86ab080000		JBE 0x6927d9										
  module.go:63001	0x691f2e		c7443e2800000000	MOVL $0x0, 0x28(SI)(DI*1)								
  phase0_add.go:92	0x691f36		488b7838		MOVQ 0x38(AX), DI									
  module.go:63026	0x691f3a		4c8d5e27		LEAQ 0x27(SI), R11									
  module.go:63026	0x691f3e		6690			NOPW											
  module.go:63026	0x691f40		4c39df			CMPQ DI, R11										
  module.go:63026	0x691f43		0f868b080000		JBE 0x6927d4										
  phase0_add.go:92	0x691f49		488b7830		MOVQ 0x30(AX), DI									
  module.go:63027	0x691f4d		49bc0000000001000000	MOVQ $0x100000000, R12									
  module.go:63027	0x691f57		4c89643e20		MOVQ R12, 0x20(SI)(DI*1)								
  phase0_add.go:93	0x691f5c		488b7838		MOVQ 0x38(AX), DI									
  module.go:63000	0x691f60		4c8d6633		LEAQ 0x33(SI), R12									
  module.go:63000	0x691f64		4c39e7			CMPQ DI, R12										
  module.go:63000	0x691f67		0f8662080000		JBE 0x6927cf										
  phase0_add.go:93	0x691f6d		488b7830		MOVQ 0x30(AX), DI									
  module.go:63001	0x691f71		c7443e30c81a1000	MOVL $0x101ac8, 0x30(SI)(DI*1)								
  phase0_add.go:94	0x691f79		488b7838		MOVQ 0x38(AX), DI									
  module.go:63026	0x691f7d		4c8d663b		LEAQ 0x3b(SI), R12									
  module.go:63026	0x691f81		4c39e7			CMPQ DI, R12										
  module.go:63026	0x691f84		0f8640080000		JBE 0x6927ca										
  phase0_add.go:94	0x691f8a		488b7830		MOVQ 0x30(AX), DI									
  module.go:63027	0x691f8e		48c7443e3420000060	MOVQ $0x60000020, 0x34(SI)(DI*1)							
  phase0_add.go:95	0x691f97		488b7838		MOVQ 0x38(AX), DI									
  module.go:63000	0x691f9b		4c8d662f		LEAQ 0x2f(SI), R12									
  module.go:63000	0x691f9f		90			NOPL											
  module.go:63000	0x691fa0		4c39e7			CMPQ DI, R12										
  module.go:63000	0x691fa3		0f861c080000		JBE 0x6927c5										
  phase0_add.go:95	0x691fa9		488b7830		MOVQ 0x30(AX), DI									
  phase0_add.go:95	0x691fad		8b5c2428		MOVL 0x28(SP), BX									
  phase0_add.go:95	0x691fb1		448d63e0		LEAL -0x20(BX), R12									
  module.go:63001	0x691fb5		4489643e2c		MOVL R12, 0x2c(SI)(DI*1)								
  phase0_add.go:96	0x691fba		488b7838		MOVQ 0x38(AX), DI									
  module.go:62983	0x691fbe		4d8d6213		LEAQ 0x13(R10), R12									
  module.go:62983	0x691fc2		4c39e7			CMPQ DI, R12										
  module.go:62983	0x691fc5		0f86f3070000		JBE 0x6927be										
  phase0_add.go:96	0x691fcb		488b7830		MOVQ 0x30(AX), DI									
  module.go:62984	0x691fcf		498d3c3a		LEAQ 0(R10)(DI*1), DI									
  module.go:62984	0x691fd3		488d7f10		LEAQ 0x10(DI), DI									
  module.go:62984	0x691fd7		48633f			MOVSXD 0(DI), DI									
  module.go:62984	0x691fda		660f1f440000		NOPW 0(AX)(AX*1)									
  module.go:63164	0x691fe0		48397808		CMPQ 0x8(AX), DI									
  module.go:63164	0x691fe4		0f86c1070000		JBE 0x6927ab										
  phase0_add.go:97	0x691fea		48c1e704		SHLQ $0x4, DI										
  phase0_add.go:97	0x691fee		4c8b20			MOVQ 0(AX), R12										
  phase0_add.go:97	0x691ff1		4e8b2c27		MOVQ 0(DI)(R12*1), R13									
  phase0_add.go:97	0x691ff5		4a8b542708		MOVQ 0x8(DI)(R12*1), DX									
  phase0_add.go:97	0x691ffa		488d3d1f1a1d00		LEAQ 0x1d1a1f(IP), DI									
  phase0_add.go:97	0x692001		4939fd			CMPQ R13, DI										
  phase0_add.go:97	0x692004		0f858f070000		JNE 0x692799										
  phase0_add.go:86	0x69200a		4889742448		MOVQ SI, 0x48(SP)									
  module.go:62984	0x69200f		4489442434		MOVL R8, 0x34(SP)									
  module.go:62984	0x692014		4489542430		MOVL R10, 0x30(SP)									
  module.go:63000	0x692019		4c894c2440		MOVQ R9, 0x40(SP)									
  module.go:63026	0x69201e		4c895c2438		MOVQ R11, 0x38(SP)									
  phase0_add.go:97	0x692023		488b0a			MOVQ 0(DX), CX										
  phase0_add.go:97	0x692026		83c3ec			ADDL $-0x14, BX										
  phase0_add.go:97	0x692029		4489c0			MOVL R8, AX										
  phase0_add.go:97	0x69202c		ffd1			CALL CX											
  phase0_add.go:98	0x69202e		85c0			TESTL AX, AX										
  phase0_add.go:98	0x692030		0f8528070000		JNE 0x69275e										
  phase0_add.go:102	0x692036		488b842480000000	MOVQ 0x80(SP), AX									
  phase0_add.go:102	0x69203e		488b7038		MOVQ 0x38(AX), SI									
  module.go:62983	0x692042		488b7c2440		MOVQ 0x40(SP), DI									
  module.go:62983	0x692047		4839fe			CMPQ SI, DI										
  module.go:62983	0x69204a		0f8609070000		JBE 0x692759										
  phase0_add.go:102	0x692050		488b7830		MOVQ 0x30(AX), DI									
  module.go:63000	0x692054		4c8b442448		MOVQ 0x48(SP), R8									
  module.go:63000	0x692059		4d8d481b		LEAQ 0x1b(R8), R9									
  phase0_add.go:103	0x69205d		90			NOPL											
  module.go:62984	0x69205e		458b543828		MOVL 0x28(R8)(DI*1), R10								
  module.go:63000	0x692063		4c39ce			CMPQ SI, R9										
  module.go:63000	0x692066		0f86e8060000		JBE 0x692754										
  module.go:63001	0x69206c		4589543818		MOVL R10, 0x18(R8)(DI*1)								
  phase0_add.go:104	0x692071		488b7038		MOVQ 0x38(AX), SI									
  module.go:63009	0x692075		488b7c2438		MOVQ 0x38(SP), DI									
  module.go:63009	0x69207a		660f1f440000		NOPW 0(AX)(AX*1)									
  module.go:63009	0x692080		4839fe			CMPQ SI, DI										
  module.go:63009	0x692083		0f86c6060000		JBE 0x69274f										
  phase0_add.go:104	0x692089		488b7830		MOVQ 0x30(AX), DI									
  module.go:63026	0x69208d		4d8d5017		LEAQ 0x17(R8), R10									
  phase0_add.go:105	0x692091		90			NOPL											
  module.go:63010	0x692092		4d8b5c3820		MOVQ 0x20(R8)(DI*1), R11								
  module.go:63010	0x692097		660f1f840000000000	NOPW 0(AX)(AX*1)									
  module.go:63026	0x6920a0		4c39d6			CMPQ SI, R10										
  module.go:63026	0x6920a3		0f86a1060000		JBE 0x69274a										
  module.go:63027	0x6920a9		4d895c3810		MOVQ R11, 0x10(R8)(DI*1)								
  phase0_add.go:106	0x6920ae		488b7038		MOVQ 0x38(AX), SI									
  module.go:62983	0x6920b2		8b7c2430		MOVL 0x30(SP), DI									
  module.go:62983	0x6920b6		4c8d5f03		LEAQ 0x3(DI), R11									
  module.go:62983	0x6920ba		660f1f440000		NOPW 0(AX)(AX*1)									
  module.go:62983	0x6920c0		4c39de			CMPQ SI, R11										
  module.go:62983	0x6920c3		0f867c060000		JBE 0x692745										
  module.go:63000	0x6920c9		4c894c2440		MOVQ R9, 0x40(SP)									
  module.go:63026	0x6920ce		4c89542438		MOVQ R10, 0x38(SP)									
  phase0_add.go:106	0x6920d3		488b7030		MOVQ 0x30(AX), SI									
  module.go:62984	0x6920d7		8b3437			MOVL 0(DI)(SI*1), SI									
  phase0_add.go:108	0x6920da		85f6			TESTL SI, SI										
  phase0_add.go:108	0x6920dc		7451			JE 0x69212f										
  phase0_add.go:109	0x6920de		4863f6			MOVSXD SI, SI										
  module.go:63164	0x6920e1		48397008		CMPQ 0x8(AX), SI									
  module.go:63164	0x6920e5		0f8642060000		JBE 0x69272d										
  phase0_add.go:109	0x6920eb		48c1e604		SHLQ $0x4, SI										
  phase0_add.go:109	0x6920ef		4c8b18			MOVQ 0(AX), R11										
  phase0_add.go:109	0x6920f2		4e8b241e		MOVQ 0(SI)(R11*1), R12									
  phase0_add.go:109	0x6920f6		4a8b541e08		MOVQ 0x8(SI)(R11*1), DX									
  phase0_add.go:109	0x6920fb		488d1dbe291c00		LEAQ 0x1c29be(IP), BX									
  phase0_add.go:109	0x692102		4939dc			CMPQ R12, BX										
  phase0_add.go:109	0x692105		0f8513060000		JNE 0x69271e										
  phase0_add.go:109	0x69210b		488b0a			MOVQ 0(DX), CX										
  phase0_add.go:109	0x69210e		8b442434		MOVL 0x34(SP), AX									
  phase0_add.go:109	0x692112		ffd1			CALL CX											
  phase0_add.go:111	0x692114		488b842480000000	MOVQ 0x80(SP), AX									
  module.go:62983	0x69211c		8b7c2430		MOVL 0x30(SP), DI									
  module.go:62984	0x692120		4c8b442448		MOVQ 0x48(SP), R8									
  module.go:62983	0x692125		4c8b4c2440		MOVQ 0x40(SP), R9									
  module.go:63009	0x69212a		4c8b542438		MOVQ 0x38(SP), R10									
  phase0_add.go:111	0x69212f		488b5038		MOVQ 0x38(AX), DX									
  module.go:62983	0x692133		488d7707		LEAQ 0x7(DI), SI									
  module.go:62983	0x692137		660f1f840000000000	NOPW 0(AX)(AX*1)									
  module.go:62983	0x692140		4839f2			CMPQ DX, SI										
  module.go:62983	0x692143		0f86d0050000		JBE 0x692719										
  phase0_add.go:111	0x692149		488b7030		MOVQ 0x30(AX), SI									
  module.go:62984	0x69214d		8b4c3704		MOVL 0x4(DI)(SI*1), CX									
  phase0_add.go:113	0x692151		85c9			TESTL CX, CX										
  phase0_add.go:113	0x692153		7434			JE 0x692189										
  module.go:62983	0x692155		488d770b		LEAQ 0xb(DI), SI									
  phase0_add.go:114	0x692159		90			NOPL											
  phase0_add.go:114	0x69215a		660f1f440000		NOPW 0(AX)(AX*1)									
  module.go:62983	0x692160		4839f2			CMPQ DX, SI										
  module.go:62983	0x692163		0f86ab050000		JBE 0x692714										
  phase0_add.go:115	0x692169		8b5c2434		MOVL 0x34(SP), BX									
  phase0_add.go:115	0x69216d		e80ea6f3ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn1(SB)		
  phase0_add.go:117	0x692172		488b842480000000	MOVQ 0x80(SP), AX									
  module.go:62984	0x69217a		4c8b442448		MOVQ 0x48(SP), R8									
  module.go:62983	0x69217f		4c8b4c2440		MOVQ 0x40(SP), R9									
  module.go:63009	0x692184		4c8b542438		MOVQ 0x38(SP), R10									
  phase0_add.go:117	0x692189		488b4838		MOVQ 0x38(AX), CX									
  module.go:62983	0x69218d		4c39c9			CMPQ CX, R9										
  module.go:62983	0x692190		0f8679050000		JBE 0x69270f										
  phase0_add.go:117	0x692196		488b5030		MOVQ 0x30(AX), DX									
  module.go:63000	0x69219a		488b742468		MOVQ 0x68(SP), SI									
  module.go:63000	0x69219f		488d7e0b		LEAQ 0xb(SI), DI									
  phase0_add.go:118	0x6921a3		90			NOPL											
  module.go:62984	0x6921a4		458b4c1018		MOVL 0x18(R8)(DX*1), R9									
  module.go:63000	0x6921a9		4839f9			CMPQ CX, DI										
  module.go:63000	0x6921ac		0f8658050000		JBE 0x69270a										
  module.go:63001	0x6921b2		44894c1608		MOVL R9, 0x8(SI)(DX*1)									
  phase0_add.go:119	0x6921b7		488b4838		MOVQ 0x38(AX), CX									
  phase0_add.go:119	0x6921bb		0f1f440000		NOPL 0(AX)(AX*1)									
  module.go:63009	0x6921c0		4c39d1			CMPQ CX, R10										
  module.go:63009	0x6921c3		0f863c050000		JBE 0x692705										
  phase0_add.go:119	0x6921c9		488b5030		MOVQ 0x30(AX), DX									
  phase0_add.go:120	0x6921cd		90			NOPL											
  module.go:63010	0x6921ce		498b7c1010		MOVQ 0x10(R8)(DX*1), DI									
  module.go:63026	0x6921d3		4c8b442460		MOVQ 0x60(SP), R8									
  module.go:63026	0x6921d8		0f1f840000000000	NOPL 0(AX)(AX*1)									
  module.go:63026	0x6921e0		4c39c1			CMPQ CX, R8										
  module.go:63026	0x6921e3		0f8615050000		JBE 0x6926fe										
  module.go:63027	0x6921e9		488b4c2450		MOVQ 0x50(SP), CX									
  module.go:63027	0x6921ee		48893c0a		MOVQ DI, 0(DX)(CX*1)									
  phase0_add.go:121	0x6921f2		488b5038		MOVQ 0x38(AX), DX									
  module.go:63000	0x6921f6		488d7e0f		LEAQ 0xf(SI), DI									
  module.go:63000	0x6921fa		660f1f440000		NOPW 0(AX)(AX*1)									
  module.go:63000	0x692200		4839fa			CMPQ DX, DI										
  module.go:63000	0x692203		0f86f0040000		JBE 0x6926f9										
  phase0_add.go:121	0x692209		488b5030		MOVQ 0x30(AX), DX									
  module.go:63001	0x69220d		c744160c01000000	MOVL $0x1, 0xc(SI)(DX*1)								
  module.go:62983	0x692215		4c89c7			MOVQ R8, DI										
  module.go:62983	0x692218		4c8b442458		MOVQ 0x58(SP), R8									
  module.go:62984	0x69221d		4989c9			MOVQ CX, R9										
  phase0_add.go:127	0x692220		4889c1			MOVQ AX, CX										
  phase0_add.go:122	0x692223		e9b4010000		JMP 0x6923dc										
  phase0_add.go:62	0x692228		bb2c000000		MOVL $0x2c, BX										
  phase0_add.go:62	0x69222d		b901000000		MOVL $0x1, CX										
  phase0_add.go:62	0x692232		e8c9a8f3ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn4(SB)		
  phase0_add.go:64	0x692237		85c0			TESTL AX, AX										
  phase0_add.go:64	0x692239		0f8490040000		JE 0x6926cf										
  phase0_add.go:68	0x69223f		488b8c2480000000	MOVQ 0x80(SP), CX									
  phase0_add.go:68	0x692247		488b5138		MOVQ 0x38(CX), DX									
  module.go:63026	0x69224b		488b742468		MOVQ 0x68(SP), SI									
  module.go:63026	0x692250		488d7e0f		LEAQ 0xf(SI), DI									
  module.go:63026	0x692254		4839fa			CMPQ DX, DI										
  module.go:63026	0x692257		0f866d040000		JBE 0x6926ca										
  phase0_add.go:68	0x69225d		488b5130		MOVQ 0x30(CX), DX									
  module.go:63027	0x692261		48bf2c00000002000000	MOVQ $0x20000002c, DI									
  module.go:63027	0x69226b		48897c1608		MOVQ DI, 0x8(SI)(DX*1)									
  phase0_add.go:69	0x692270		488b5138		MOVQ 0x38(CX), DX									
  module.go:63000	0x692274		488b7c2460		MOVQ 0x60(SP), DI									
  module.go:63000	0x692279		0f1f8000000000		NOPL 0(AX)										
  module.go:63000	0x692280		4839fa			CMPQ DX, DI										
  module.go:63000	0x692283		0f863c040000		JBE 0x6926c5										
  phase0_add.go:69	0x692289		488b5130		MOVQ 0x30(CX), DX									
  module.go:63001	0x69228d		89441604		MOVL AX, 0x4(SI)(DX*1)									
  phase0_add.go:70	0x692291		488b5138		MOVQ 0x38(CX), DX									
  module.go:63000	0x692295		4c8b442458		MOVQ 0x58(SP), R8									
  module.go:63000	0x69229a		660f1f440000		NOPW 0(AX)(AX*1)									
  module.go:63000	0x6922a0		4c39c2			CMPQ DX, R8										
  module.go:63000	0x6922a3		0f8613040000		JBE 0x6926bc										
  phase0_add.go:70	0x6922a9		488b5130		MOVQ 0x30(CX), DX									
  module.go:63001	0x6922ad		4c8b4c2450		MOVQ 0x50(SP), R9									
  module.go:63001	0x6922b2		42c7040a2c000000	MOVL $0x2c, 0(DX)(R9*1)									
  phase0_add.go:71	0x6922ba		488b5138		MOVQ 0x38(CX), DX									
  phase0_add.go:71	0x6922be		6690			NOPW											
  module.go:62983	0x6922c0		4881fa9b191000		CMPQ DX, $0x10199b									
  module.go:62983	0x6922c7		0f86e3030000		JBE 0x6926b0										
  phase0_add.go:72	0x6922cd		4189c2			MOVL AX, R10										
  module.go:63000	0x6922d0		4d8d5a2b		LEAQ 0x2b(R10), R11									
  module.go:63000	0x6922d4		4c39da			CMPQ DX, R11										
  module.go:63000	0x6922d7		0f86ce030000		JBE 0x6926ab										
  phase0_add.go:71	0x6922dd		488b5130		MOVQ 0x30(CX), DX									
  module.go:62984	0x6922e1		448b9a98191000		MOVL 0x101998(DX), R11									
  module.go:63001	0x6922e8		45895c1228		MOVL R11, 0x28(R10)(DX*1)								
  phase0_add.go:73	0x6922ed		488b5138		MOVQ 0x38(CX), DX									
  module.go:63009	0x6922f1		4881fa97191000		CMPQ DX, $0x101997									
  module.go:63009	0x6922f8		0f86a1030000		JBE 0x69269f										
  module.go:63026	0x6922fe		4d8d5a27		LEAQ 0x27(R10), R11									
  phase0_add.go:74	0x692302		90			NOPL											
  module.go:63026	0x692303		4c39da			CMPQ DX, R11										
  module.go:63026	0x692306		0f868e030000		JBE 0x69269a										
  phase0_add.go:73	0x69230c		488b5130		MOVQ 0x30(CX), DX									
  module.go:63010	0x692310		4c8b9a90191000		MOVQ 0x101990(DX), R11									
  module.go:63027	0x692317		4d895c1220		MOVQ R11, 0x20(R10)(DX*1)								
  phase0_add.go:75	0x69231c		488b5138		MOVQ 0x38(CX), DX									
  module.go:63009	0x692320		4881fa8f191000		CMPQ DX, $0x10198f									
  module.go:63009	0x692327		0f8661030000		JBE 0x69268e										
  module.go:63026	0x69232d		4d8d5a1f		LEAQ 0x1f(R10), R11									
  phase0_add.go:76	0x692331		90			NOPL											
  module.go:63026	0x692332		4c39da			CMPQ DX, R11										
  module.go:63026	0x692335		0f864e030000		JBE 0x692689										
  phase0_add.go:75	0x69233b		488b5130		MOVQ 0x30(CX), DX									
  module.go:63010	0x69233f		4c8b9a88191000		MOVQ 0x101988(DX), R11									
  module.go:63027	0x692346		4d895c1218		MOVQ R11, 0x18(R10)(DX*1)								
  phase0_add.go:77	0x69234b		488b5138		MOVQ 0x38(CX), DX									
  module.go:63009	0x69234f		4881fa87191000		CMPQ DX, $0x101987									
  module.go:63009	0x692356		0f8621030000		JBE 0x69267d										
  module.go:63026	0x69235c		4d8d5a17		LEAQ 0x17(R10), R11									
  phase0_add.go:78	0x692360		90			NOPL											
  module.go:63026	0x692361		4c39da			CMPQ DX, R11										
  module.go:63026	0x692364		0f860e030000		JBE 0x692678										
  phase0_add.go:77	0x69236a		488b5130		MOVQ 0x30(CX), DX									
  module.go:63010	0x69236e		4c8b9a80191000		MOVQ 0x101980(DX), R11									
  module.go:63027	0x692375		4d895c1210		MOVQ R11, 0x10(R10)(DX*1)								
  phase0_add.go:79	0x69237a		488b5138		MOVQ 0x38(CX), DX									
  phase0_add.go:79	0x69237e		6690			NOPW											
  module.go:63009	0x692380		4881fa7f191000		CMPQ DX, $0x10197f									
  module.go:63009	0x692387		0f86df020000		JBE 0x69266c										
  module.go:63026	0x69238d		4d8d5a0f		LEAQ 0xf(R10), R11									
  phase0_add.go:80	0x692391		90			NOPL											
  module.go:63026	0x692392		4c39da			CMPQ DX, R11										
  module.go:63026	0x692395		0f86cc020000		JBE 0x692667										
  phase0_add.go:79	0x69239b		488b5130		MOVQ 0x30(CX), DX									
  module.go:63010	0x69239f		4c8b9a78191000		MOVQ 0x101978(DX), R11									
  module.go:63027	0x6923a6		4d895c1208		MOVQ R11, 0x8(R10)(DX*1)								
  phase0_add.go:81	0x6923ab		488b5138		MOVQ 0x38(CX), DX									
  module.go:63009	0x6923af		4881fa77191000		CMPQ DX, $0x101977									
  module.go:63009	0x6923b6		0f869f020000		JBE 0x69265b										
  module.go:63026	0x6923bc		4983c207		ADDQ $0x7, R10										
  phase0_add.go:82	0x6923c0		90			NOPL											
  module.go:63026	0x6923c1		4c39d2			CMPQ DX, R10										
  module.go:63026	0x6923c4		0f868c020000		JBE 0x692656										
  phase0_add.go:81	0x6923ca		488b5130		MOVQ 0x30(CX), DX									
  module.go:63010	0x6923ce		4c8b9270191000		MOVQ 0x101970(DX), R10									
  module.go:63027	0x6923d5		4189c3			MOVL AX, R11										
  module.go:63027	0x6923d8		4e89141a		MOVQ R10, 0(DX)(R11*1)									
  phase0_add.go:127	0x6923dc		8b542428		MOVL 0x28(SP), DX									
  phase0_add.go:127	0x6923e0		895150			MOVL DX, 0x50(CX)									
  phase0_add.go:130	0x6923e3		488b5138		MOVQ 0x38(CX), DX									
  module.go:62983	0x6923e7		4c39c2			CMPQ DX, R8										
  module.go:62983	0x6923ea		0f8661020000		JBE 0x692651										
  phase0_add.go:130	0x6923f0		4c8b5130		MOVQ 0x30(CX), R10									
  module.go:62984	0x6923f4		478b1c11		MOVL 0(R9)(R10*1), R11									
  module.go:62984	0x6923f8		0f1f840000000000	NOPL 0(AX)(AX*1)									
  phase0_add.go:132	0x692400		4183fbff		CMPL R11, $-0x1										
  phase0_add.go:132	0x692404		0f85fb000000		JNE 0x692505										
  phase0_add.go:152	0x69240a		90			NOPL											
  module.go:62983	0x69240b		4881fa73ce1000		CMPQ DX, $0x10ce73									
  module.go:62983	0x692412		0f862d020000		JBE 0x692645										
  phase0_add.go:153	0x692418		90			NOPL											
  module.go:63001	0x692419		41ff8270ce1000		INCL 0x10ce70(R10)									
  phase0_add.go:154	0x692420		488b5138		MOVQ 0x38(CX), DX									
  phase0_add.go:154	0x692424		4881fafccf1000		CMPQ DX, $0x10cffc									
  phase0_add.go:154	0x69242b		0f8604020000		JBE 0x692635										
  phase0_add.go:154	0x692431		488b5130		MOVQ 0x30(CX), DX									
  phase0_add.go:154	0x692435		0fb692fccf1000		MOVZX 0x10cffc(DX), DX									
  phase0_add.go:154	0x69243c		0f1f4000		NOPL 0(AX)										
  phase0_add.go:155	0x692440		83fa01			CMPL DX, $0x1										
  phase0_add.go:155	0x692443		7410			JE 0x692455										
  phase0_add.go:156	0x692445		4889c8			MOVQ CX, AX										
  phase0_add.go:156	0x692448		e81358f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn105(SB)		
  phase0_add.go:158	0x69244d		488b8c2480000000	MOVQ 0x80(SP), CX									
  phase0_add.go:158	0x692455		488b5138		MOVQ 0x38(CX), DX									
  phase0_add.go:158	0x692459		0f1f8000000000		NOPL 0(AX)										
  module.go:62983	0x692460		4881fad3cf1000		CMPQ DX, $0x10cfd3									
  module.go:62983	0x692467		0f86bc010000		JBE 0x692629										
  phase0_add.go:158	0x69246d		488b7130		MOVQ 0x30(CX), SI									
  module.go:62984	0x692471		83bed0cf100000		CMPL 0x10cfd0(SI), $0x0									
  phase0_add.go:159	0x692478		0f858b010000		JNE 0x692609										
  phase0_add.go:163	0x69247e		90			NOPL											
  phase0_add.go:163	0x69247f		90			NOPL											
  module.go:62983	0x692480		4881fae7cf1000		CMPQ DX, $0x10cfe7									
  module.go:62983	0x692487		0f8670010000		JBE 0x6925fd										
  phase0_add.go:13	0x69248d		0fb69c2498000000	MOVZX 0x98(SP), BX									
  phase0_add.go:13	0x692495		84db			TESTL BL, BL										
  phase0_add.go:164	0x692497		7562			JNE 0x6924fb										
  phase0_add.go:165	0x692499		90			NOPL											
  phase0_add.go:165	0x69249a		660f1f440000		NOPW 0(AX)(AX*1)									
  module.go:63000	0x6924a0		4881faefcf1000		CMPQ DX, $0x10cfef									
  module.go:63000	0x6924a7		0f8644010000		JBE 0x6925f1										
  module.go:62984	0x6924ad		8b96e4cf1000		MOVL 0x10cfe4(SI), DX									
  module.go:63001	0x6924b3		8996eccf1000		MOVL DX, 0x10cfec(SI)									
  phase0_add.go:166	0x6924b9		488b5138		MOVQ 0x38(CX), DX									
  phase0_add.go:166	0x6924bd		0f1f00			NOPL 0(AX)										
  module.go:63000	0x6924c0		4881faebcf1000		CMPQ DX, $0x10cfeb									
  module.go:63000	0x6924c7		0f8618010000		JBE 0x6925e5										
  phase0_add.go:166	0x6924cd		488b5130		MOVQ 0x30(CX), DX									
  module.go:63001	0x6924d1		c782e8cf100000000000	MOVL $0x0, 0x10cfe8(DX)									
  phase0_add.go:167	0x6924db		488b5138		MOVQ 0x38(CX), DX									
  phase0_add.go:167	0x6924df		90			NOPL											
  module.go:63000	0x6924e0		4881faf3cf1000		CMPQ DX, $0x10cff3									
  module.go:63000	0x6924e7		0f86e7000000		JBE 0x6925d4										
  phase0_add.go:167	0x6924ed		488b5130		MOVQ 0x30(CX), DX									
  module.go:63001	0x6924f1		c782f0cf100000000000	MOVL $0x0, 0x10cff0(DX)									
  phase0_add.go:169	0x6924fb		31c0			XORL AX, AX										
  phase0_add.go:169	0x6924fd		0f1f00			NOPL 0(AX)										
  phase0_add.go:171	0x692500		e99d000000		JMP 0x6925a2										
  phase0_add.go:135	0x692505		90			NOPL											
  module.go:62983	0x692506		4839fa			CMPQ DX, DI										
  module.go:62983	0x692509		0f86c0000000		JBE 0x6925cf										
  module.go:63009	0x69250f		4c8d660f		LEAQ 0xf(SI), R12									
  phase0_add.go:137	0x692513		90			NOPL											
  module.go:62984	0x692514		468b6c1604		MOVL 0x4(SI)(R10*1), R13								
  module.go:62984	0x692519		0f1f8000000000		NOPL 0(AX)										
  module.go:63009	0x692520		4c39e2			CMPQ DX, R12										
  module.go:63009	0x692523		0f86a1000000		JBE 0x6925ca										
  module.go:63010	0x692529		4a8b541608		MOVQ 0x8(SI)(R10*1), DX									
  phase0_add.go:142	0x69252e		4889c8			MOVQ CX, AX										
  phase0_add.go:147	0x692531		8b5c2420		MOVL 0x20(SP), BX									
  module.go:63001	0x692535		4d89ca			MOVQ R9, R10										
  phase0_add.go:141	0x692538		4489e9			MOVL R13, CX										
  module.go:63000	0x69253b		4989f9			MOVQ DI, R9										
  module.go:63000	0x69253e		4c89c7			MOVQ R8, DI										
  module.go:63026	0x692541		4989f0			MOVQ SI, R8										
  phase0_add.go:142	0x692544		488b7038		MOVQ 0x38(AX), SI									
  module.go:62983	0x692548		4881fe73ce1000		CMPQ SI, $0x10ce73									
  module.go:62983	0x69254f		766d			JBE 0x6925be										
  phase0_add.go:142	0x692551		488b7030		MOVQ 0x30(AX), SI									
  module.go:63026	0x692555		4d8d600f		LEAQ 0xf(R8), R12									
  phase0_add.go:143	0x692559		90			NOPL											
  module.go:63001	0x69255a		ff8670ce1000		INCL 0x10ce70(SI)									
  phase0_add.go:144	0x692560		488b7038		MOVQ 0x38(AX), SI									
  module.go:63026	0x692564		4c39e6			CMPQ SI, R12										
  module.go:63026	0x692567		7650			JBE 0x6925b9										
  phase0_add.go:144	0x692569		488b7030		MOVQ 0x30(AX), SI									
  module.go:63027	0x69256d		4989543008		MOVQ DX, 0x8(R8)(SI*1)									
  phase0_add.go:145	0x692572		488b5038		MOVQ 0x38(AX), DX									
  module.go:63000	0x692576		4c39ca			CMPQ DX, R9										
  module.go:63000	0x692579		7639			JBE 0x6925b4										
  phase0_add.go:145	0x69257b		488b5030		MOVQ 0x30(AX), DX									
  module.go:63001	0x69257f		41894c1004		MOVL CX, 0x4(R8)(DX*1)									
  phase0_add.go:146	0x692584		488b4838		MOVQ 0x38(AX), CX									
  module.go:63000	0x692588		4839f9			CMPQ CX, DI										
  module.go:63000	0x69258b		7622			JBE 0x6925af										
  phase0_add.go:146	0x69258d		488b4830		MOVQ 0x30(AX), CX									
  module.go:63001	0x692591		46891c11		MOVL R11, 0(CX)(R10*1)									
  phase0_add.go:147	0x692595		e8c6abf4ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn60(SB)		
  phase0_add.go:172	0x69259a		488b8c2480000000	MOVQ 0x80(SP), CX									
  phase0_add.go:172	0x6925a2		8b54242c		MOVL 0x2c(SP), DX									
  phase0_add.go:172	0x6925a6		895150			MOVL DX, 0x50(CX)									
  phase0_add.go:173	0x6925a9		4883c470		ADDQ $0x70, SP										
  phase0_add.go:173	0x6925ad		5d			POPQ BP											
  phase0_add.go:173	0x6925ae		c3			RET											
  module.go:63000	0x6925af		e80ce4dfff		CALL runtime.panicBounds(SB)								
  module.go:63000	0x6925b4		e807e4dfff		CALL runtime.panicBounds(SB)								
  module.go:63026	0x6925b9		e802e4dfff		CALL runtime.panicBounds(SB)								
  module.go:62983	0x6925be		48c7c073ce1000		MOVQ $0x10ce73, AX									
  module.go:62983	0x6925c5		e8f6e3dfff		CALL runtime.panicBounds(SB)								
  module.go:63009	0x6925ca		e8f1e3dfff		CALL runtime.panicBounds(SB)								
  module.go:62983	0x6925cf		e8ece3dfff		CALL runtime.panicBounds(SB)								
  module.go:63000	0x6925d4		48c7c0f3cf1000		MOVQ $0x10cff3, AX									
  module.go:63000	0x6925db		0f1f440000		NOPL 0(AX)(AX*1)									
  module.go:63000	0x6925e0		e8dbe3dfff		CALL runtime.panicBounds(SB)								
  module.go:63000	0x6925e5		48c7c0ebcf1000		MOVQ $0x10cfeb, AX									
  module.go:63000	0x6925ec		e8cfe3dfff		CALL runtime.panicBounds(SB)								
  module.go:63000	0x6925f1		48c7c0efcf1000		MOVQ $0x10cfef, AX									
  module.go:63000	0x6925f8		e8c3e3dfff		CALL runtime.panicBounds(SB)								
  module.go:62983	0x6925fd		48c7c0e7cf1000		MOVQ $0x10cfe7, AX									
  module.go:62983	0x692604		e8b7e3dfff		CALL runtime.panicBounds(SB)								
  phase0_add.go:160	0x692609		4889c8			MOVQ CX, AX										
  phase0_add.go:160	0x69260c		bb60171000		MOVL $0x101760, BX									
  phase0_add.go:160	0x692611		e86a11f4ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn24(SB)		
  phase0_add.go:161	0x692616		488d05e3051c00		LEAQ 0x1c05e3(IP), AX									
  phase0_add.go:161	0x69261d		488d1dfc872700		LEAQ 0x2787fc(IP), BX									
  phase0_add.go:161	0x692624		e8b761dfff		CALL runtime.gopanic(SB)								
  module.go:62983	0x692629		48c7c0d3cf1000		MOVQ $0x10cfd3, AX									
  module.go:62983	0x692630		e88be3dfff		CALL runtime.panicBounds(SB)								
  phase0_add.go:154	0x692635		48c7c0fccf1000		MOVQ $0x10cffc, AX									
  phase0_add.go:154	0x69263c		0f1f4000		NOPL 0(AX)										
  phase0_add.go:154	0x692640		e87be3dfff		CALL runtime.panicBounds(SB)								
  module.go:62983	0x692645		48c7c073ce1000		MOVQ $0x10ce73, AX									
  module.go:62983	0x69264c		e86fe3dfff		CALL runtime.panicBounds(SB)								
  module.go:62983	0x692651		e86ae3dfff		CALL runtime.panicBounds(SB)								
  module.go:63026	0x692656		e865e3dfff		CALL runtime.panicBounds(SB)								
  module.go:63009	0x69265b		48c7c077191000		MOVQ $0x101977, AX									
  module.go:63009	0x692662		e859e3dfff		CALL runtime.panicBounds(SB)								
  module.go:63026	0x692667		e854e3dfff		CALL runtime.panicBounds(SB)								
  module.go:63009	0x69266c		48c7c07f191000		MOVQ $0x10197f, AX									
  module.go:63009	0x692673		e848e3dfff		CALL runtime.panicBounds(SB)								
  module.go:63026	0x692678		e843e3dfff		CALL runtime.panicBounds(SB)								
  module.go:63009	0x69267d		48c7c087191000		MOVQ $0x101987, AX									
  module.go:63009	0x692684		e837e3dfff		CALL runtime.panicBounds(SB)								
  module.go:63026	0x692689		e832e3dfff		CALL runtime.panicBounds(SB)								
  module.go:63009	0x69268e		48c7c08f191000		MOVQ $0x10198f, AX									
  module.go:63009	0x692695		e826e3dfff		CALL runtime.panicBounds(SB)								
  module.go:63026	0x69269a		e821e3dfff		CALL runtime.panicBounds(SB)								
  module.go:63009	0x69269f		48c7c097191000		MOVQ $0x101997, AX									
  module.go:63009	0x6926a6		e815e3dfff		CALL runtime.panicBounds(SB)								
  module.go:63000	0x6926ab		e810e3dfff		CALL runtime.panicBounds(SB)								
  module.go:62983	0x6926b0		48c7c09b191000		MOVQ $0x10199b, AX									
  module.go:62983	0x6926b7		e804e3dfff		CALL runtime.panicBounds(SB)								
  module.go:63000	0x6926bc		0f1f4000		NOPL 0(AX)										
  module.go:63000	0x6926c0		e8fbe2dfff		CALL runtime.panicBounds(SB)								
  module.go:63000	0x6926c5		e8f6e2dfff		CALL runtime.panicBounds(SB)								
  module.go:63026	0x6926ca		e8f1e2dfff		CALL runtime.panicBounds(SB)								
  phase0_add.go:65	0x6926cf		488b842480000000	MOVQ 0x80(SP), AX									
  phase0_add.go:65	0x6926d7		bb01000000		MOVL $0x1, BX										
  phase0_add.go:65	0x6926dc		b92c000000		MOVL $0x2c, CX										
  phase0_add.go:65	0x6926e1		e89aa1f3ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn2(SB)		
  phase0_add.go:66	0x6926e6		488d0513051c00		LEAQ 0x1c0513(IP), AX									
  phase0_add.go:66	0x6926ed		488d1d2c872700		LEAQ 0x27872c(IP), BX									
  phase0_add.go:66	0x6926f4		e8e760dfff		CALL runtime.gopanic(SB)								
  module.go:63000	0x6926f9		e8c2e2dfff		CALL runtime.panicBounds(SB)								
  module.go:63026	0x6926fe		6690			NOPW											
  module.go:63026	0x692700		e8bbe2dfff		CALL runtime.panicBounds(SB)								
  module.go:63009	0x692705		e8b6e2dfff		CALL runtime.panicBounds(SB)								
  module.go:63000	0x69270a		e8b1e2dfff		CALL runtime.panicBounds(SB)								
  module.go:62983	0x69270f		e8ace2dfff		CALL runtime.panicBounds(SB)								
  module.go:62983	0x692714		e8a7e2dfff		CALL runtime.panicBounds(SB)								
  module.go:62983	0x692719		e8a2e2dfff		CALL runtime.panicBounds(SB)								
  phase0_add.go:109	0x69271e		4c89e0			MOVQ R12, AX										
  phase0_add.go:109	0x692721		488d0db8161d00		LEAQ 0x1d16b8(IP), CX									
  phase0_add.go:109	0x692728		e853bad8ff		CALL runtime.panicdottypeE(SB)								
  module.go:63165	0x69272d		488d05cc041c00		LEAQ 0x1c04cc(IP), AX									
  module.go:63165	0x692734		488d1dd59e2700		LEAQ 0x279ed5(IP), BX									
  module.go:63165	0x69273b		0f1f440000		NOPL 0(AX)(AX*1)									
  module.go:63165	0x692740		e89b60dfff		CALL runtime.gopanic(SB)								
  module.go:62983	0x692745		e876e2dfff		CALL runtime.panicBounds(SB)								
  module.go:63026	0x69274a		e871e2dfff		CALL runtime.panicBounds(SB)								
  module.go:63009	0x69274f		e86ce2dfff		CALL runtime.panicBounds(SB)								
  module.go:63000	0x692754		e867e2dfff		CALL runtime.panicBounds(SB)								
  module.go:62983	0x692759		e862e2dfff		CALL runtime.panicBounds(SB)								
  phase0_add.go:99	0x69275e		8b7c2428		MOVL 0x28(SP), DI									
  phase0_add.go:99	0x692762		ffcf			DECL DI											
  phase0_add.go:99	0x692764		488b842480000000	MOVQ 0x80(SP), AX									
  phase0_add.go:99	0x69276c		bbf01a1000		MOVL $0x101af0, BX									
  phase0_add.go:99	0x692771		b937000000		MOVL $0x37, CX										
  phase0_add.go:99	0x692776		bee01a1000		MOVL $0x101ae0, SI									
  phase0_add.go:99	0x69277b		41b8281b1000		MOVL $0x101b28, R8									
  phase0_add.go:99	0x692781		e8ba13f4ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn27(SB)		
  phase0_add.go:100	0x692786		488d0573041c00		LEAQ 0x1c0473(IP), AX									
  phase0_add.go:100	0x69278d		488d1d8c862700		LEAQ 0x27868c(IP), BX									
  phase0_add.go:100	0x692794		e84760dfff		CALL runtime.gopanic(SB)								
  phase0_add.go:97	0x692799		4c89e8			MOVQ R13, AX										
  phase0_add.go:97	0x69279c		4889fb			MOVQ DI, BX										
  phase0_add.go:97	0x69279f		488d0d3a161d00		LEAQ 0x1d163a(IP), CX									
  phase0_add.go:97	0x6927a6		e8d5b9d8ff		CALL runtime.panicdottypeE(SB)								
  module.go:63165	0x6927ab		488d054e041c00		LEAQ 0x1c044e(IP), AX									
  module.go:63165	0x6927b2		488d1d579e2700		LEAQ 0x279e57(IP), BX									
  module.go:63165	0x6927b9		e82260dfff		CALL runtime.gopanic(SB)								
  module.go:62983	0x6927be		6690			NOPW											
  module.go:62983	0x6927c0		e8fbe1dfff		CALL runtime.panicBounds(SB)								
  module.go:63000	0x6927c5		e8f6e1dfff		CALL runtime.panicBounds(SB)								
  module.go:63026	0x6927ca		e8f1e1dfff		CALL runtime.panicBounds(SB)								
  module.go:63000	0x6927cf		e8ece1dfff		CALL runtime.panicBounds(SB)								
  module.go:63026	0x6927d4		e8e7e1dfff		CALL runtime.panicBounds(SB)								
  module.go:63000	0x6927d9		e8e2e1dfff		CALL runtime.panicBounds(SB)								
  module.go:62983	0x6927de		6690			NOPW											
  module.go:62983	0x6927e0		e8dbe1dfff		CALL runtime.panicBounds(SB)								
  module.go:63000	0x6927e5		e8d6e1dfff		CALL runtime.panicBounds(SB)								
  module.go:62983	0x6927ea		e8d1e1dfff		CALL runtime.panicBounds(SB)								
  module.go:63009	0x6927ef		e8cce1dfff		CALL runtime.panicBounds(SB)								
  module.go:62983	0x6927f4		e8c7e1dfff		CALL runtime.panicBounds(SB)								
  module.go:62983	0x6927f9		e8c2e1dfff		CALL runtime.panicBounds(SB)								
  module.go:62983	0x6927fe		48c7c083ce1000		MOVQ $0x10ce83, AX									
  module.go:62983	0x692805		e8b6e1dfff		CALL runtime.panicBounds(SB)								
  module.go:62983	0x69280a		48c7c07fce1000		MOVQ $0x10ce7f, AX									
  module.go:62983	0x692811		e8aae1dfff		CALL runtime.panicBounds(SB)								
  phase0_add.go:175	0x692816		bb60171000		MOVL $0x101760, BX									
  phase0_add.go:175	0x69281b		0f1f440000		NOPL 0(AX)(AX*1)									
  phase0_add.go:175	0x692820		e85b0ff4ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn24(SB)		
  phase0_add.go:176	0x692825		488d05d4031c00		LEAQ 0x1c03d4(IP), AX									
  phase0_add.go:176	0x69282c		488d1ded852700		LEAQ 0x2785ed(IP), BX									
  phase0_add.go:176	0x692833		e8a85fdfff		CALL runtime.gopanic(SB)								
  module.go:62983	0x692838		48c7c073ce1000		MOVQ $0x10ce73, AX									
  module.go:62983	0x69283f		90			NOPL											
  module.go:62983	0x692840		e87be1dfff		CALL runtime.panicBounds(SB)								
  phase0_add.go:13	0x692845		48c7c0b0cf1000		MOVQ $0x10cfb0, AX									
  phase0_add.go:13	0x69284c		e86fe1dfff		CALL runtime.panicBounds(SB)								
  phase0_add.go:13	0x692851		90			NOPL											
  phase0_add.go:7	0x692852		4889442408		MOVQ AX, 0x8(SP)									
  phase0_add.go:7	0x692857		48895c2410		MOVQ BX, 0x10(SP)									
  phase0_add.go:7	0x69285c		f20f11442418		MOVSD_XMM X0, 0x18(SP)									
  phase0_add.go:7	0x692862		884c2420		MOVB CL, 0x20(SP)									
  phase0_add.go:7	0x692866		e835c4dfff		CALL runtime.morestack_noctxt.abi0(SB)							
  phase0_add.go:7	0x69286b		488b442408		MOVQ 0x8(SP), AX									
  phase0_add.go:7	0x692870		488b5c2410		MOVQ 0x10(SP), BX									
  phase0_add.go:7	0x692875		f20f10442418		MOVSD_XMM 0x18(SP), X0									
  phase0_add.go:7	0x69287b		0fb64c2420		MOVZX 0x20(SP), CX									
  phase0_add.go:7	0x692880		e9fbf3ffff		JMP dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).Phase0SketchAdd(SB)	
