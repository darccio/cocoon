TEXT dario.cat/cocoon/examples/datadog/go/dd.phase0TransportAdd(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/phase0_transport.go
  phase0_transport.go:11	0x7e0e60		493b6610		CMPQ SP, 0x10(R14)																																																							
  phase0_transport.go:11	0x7e0e64		0f86a3010000		JBE 0x7e100d																																																								
  phase0_transport.go:11	0x7e0e6a		55			PUSHQ BP																																																								
  phase0_transport.go:11	0x7e0e6b		4889e5			MOVQ SP, BP																																																								
  phase0_transport.go:11	0x7e0e6e		4883ec78		SUBQ $0x78, SP																																																								
  phase0_transport.go:11	0x7e0e72		66440fd67c2470		MOVQ X15, 0x70(SP)																																																							
  phase0_transport.go:11	0x7e0e79		c644242f00		MOVB $0x0, 0x2f(SP)																																																							
  phase0_transport.go:11	0x7e0e7e		440f117c2430		MOVUPS X15, 0x30(SP)																																																							
  phase0_transport.go:12	0x7e0e84		4885c0			TESTQ AX, AX																																																								
  phase0_transport.go:12	0x7e0e87		7411			JE 0x7e0e9a																																																								
  phase0_transport.go:12	0x7e0e89		488b10			MOVQ 0(AX), DX																																																								
  phase0_transport.go:12	0x7e0e8c		4885d2			TESTQ DX, DX																																																								
  phase0_transport.go:12	0x7e0e8f		7409			JE 0x7e0e9a																																																								
  phase0_transport.go:12	0x7e0e91		4883781000		CMPQ 0x10(AX), $0x0																																																							
  phase0_transport.go:12	0x7e0e96		7402			JE 0x7e0e9a																																																								
  lifecycle.go:22		0x7e0e98		eb56			JMP 0x7e0ef0																																																								
  phase0_transport.go:13	0x7e0e9a		488d051fc10a00		LEAQ 0xac11f(IP), AX																																																							
  phase0_transport.go:13	0x7e0ea1		e87a13c4ff		CALL runtime.newobject(SB)																																																						
  phase0_transport.go:13	0x7e0ea6		48c7400803000000	MOVQ $0x3, 0x8(AX)																																																							
  phase0_transport.go:13	0x7e0eae		488d0db0b20f00		LEAQ 0xfb2b0(IP), CX																																																							
  phase0_transport.go:13	0x7e0eb5		488908			MOVQ CX, 0(AX)																																																								
  phase0_transport.go:13	0x7e0eb8		48c740180c000000	MOVQ $0xc, 0x18(AX)																																																							
  phase0_transport.go:13	0x7e0ec0		488d0d63f30f00		LEAQ 0xff363(IP), CX																																																							
  phase0_transport.go:13	0x7e0ec7		48894810		MOVQ CX, 0x10(AX)																																																							
  phase0_transport.go:13	0x7e0ecb		488d0daed01200		LEAQ go:itab.*dario.cat/cocoon/rt.HandleError,error(SB), CX																																																		
  phase0_transport.go:13	0x7e0ed2		48894c2430		MOVQ CX, 0x30(SP)																																																							
  phase0_transport.go:13	0x7e0ed7		4889442438		MOVQ AX, 0x38(SP)																																																							
  phase0_transport.go:13	0x7e0edc		488b4c2430		MOVQ 0x30(SP), CX																																																							
  phase0_transport.go:13	0x7e0ee1		4889c3			MOVQ AX, BX																																																								
  phase0_transport.go:13	0x7e0ee4		4889c8			MOVQ CX, AX																																																								
  phase0_transport.go:13	0x7e0ee7		4883c478		ADDQ $0x78, SP																																																								
  phase0_transport.go:13	0x7e0eeb		5d			POPQ BP																																																									
  phase0_transport.go:13	0x7e0eec		c3			RET																																																									
  phase0_transport.go:21	0x7e0eed		4889c8			MOVQ CX, AX																																																								
  lifecycle.go:23		0x7e0ef0		90			NOPL																																																									
  type.go:181			0x7e0ef1		4c8b4260		MOVQ 0x60(DX), R8																																																							
  lifecycle.go:24		0x7e0ef5		490fbae03f		BTQ $0x3f, R8																																																								
  lifecycle.go:24		0x7e0efa		7246			JB 0x7e0f42																																																								
  lifecycle.go:27		0x7e0efc		49b9ffffffffffffff7f	MOVQ $0x7fffffffffffffff, R9																																																						
  lifecycle.go:27		0x7e0f06		4d39c8			CMPQ R8, R9																																																								
  lifecycle.go:27		0x7e0f09		7422			JE 0x7e0f2d																																																								
  lifecycle.go:30		0x7e0f0b		4d8d5001		LEAQ 0x1(R8), R10																																																							
  phase0_transport.go:12	0x7e0f0f		4889c1			MOVQ AX, CX																																																								
  type.go:191			0x7e0f12		4c89c0			MOVQ R8, AX																																																								
  type.go:191			0x7e0f15		f04c0fb15260		LOCK CMPXCHGQ R10, 0x60(DX)																																																						
  type.go:191			0x7e0f1b		410f94c0		SETE R8																																																									
  type.go:191			0x7e0f1f		90			NOPL																																																									
  type.go:191			0x7e0f20		4584c0			TESTL R8, R8																																																								
  lifecycle.go:30		0x7e0f23		74c8			JE 0x7e0eed																																																								
  lifecycle.go:30		0x7e0f25		4531c0			XORL R8, R8																																																								
  lifecycle.go:30		0x7e0f28		4531c9			XORL R9, R9																																																								
  phase0_transport.go:16	0x7e0f2b		eb26			JMP 0x7e0f53																																																								
  phase0_transport.go:16	0x7e0f2d		4c8b05dcd84f00		MOVQ dario.cat/cocoon/rt.ErrTooLarge(SB), R8																																																				
  phase0_transport.go:16	0x7e0f34		4c8b0dddd84f00		MOVQ dario.cat/cocoon/rt.ErrTooLarge+8(SB), R9																																																				
  phase0_transport.go:21	0x7e0f3b		4889c1			MOVQ AX, CX																																																								
  phase0_transport.go:21	0x7e0f3e		6690			NOPW																																																									
  phase0_transport.go:16	0x7e0f40		eb11			JMP 0x7e0f53																																																								
  phase0_transport.go:16	0x7e0f42		4c8b05a7d84f00		MOVQ dario.cat/cocoon/rt.ErrClosed(SB), R8																																																				
  phase0_transport.go:16	0x7e0f49		4c8b0da8d84f00		MOVQ dario.cat/cocoon/rt.ErrClosed+8(SB), R9																																																				
  phase0_transport.go:21	0x7e0f50		4889c1			MOVQ AX, CX																																																								
  phase0_transport.go:16	0x7e0f53		4d85c0			TESTQ R8, R8																																																								
  phase0_transport.go:16	0x7e0f56		7416			JE 0x7e0f6e																																																								
  phase0_transport.go:17	0x7e0f58		4c89442430		MOVQ R8, 0x30(SP)																																																							
  phase0_transport.go:17	0x7e0f5d		4c894c2438		MOVQ R9, 0x38(SP)																																																							
  phase0_transport.go:17	0x7e0f62		4c89c0			MOVQ R8, AX																																																								
  phase0_transport.go:17	0x7e0f65		4c89cb			MOVQ R9, BX																																																								
  phase0_transport.go:17	0x7e0f68		4883c478		ADDQ $0x78, SP																																																								
  phase0_transport.go:17	0x7e0f6c		5d			POPQ BP																																																									
  phase0_transport.go:17	0x7e0f6d		c3			RET																																																									
  phase0_transport.go:19	0x7e0f6e		4c8d05eb010000		LEAQ dario.cat/cocoon/examples/datadog/go/dd.phase0TransportAdd.deferwrap1(SB), R8																																															
  phase0_transport.go:19	0x7e0f75		4c89442440		MOVQ R8, 0x40(SP)																																																							
  phase0_transport.go:19	0x7e0f7a		4883c238		ADDQ $0x38, DX																																																								
  phase0_transport.go:19	0x7e0f7e		4889542448		MOVQ DX, 0x48(SP)																																																							
  phase0_transport.go:19	0x7e0f83		488d542440		LEAQ 0x40(SP), DX																																																							
  phase0_transport.go:19	0x7e0f88		4889542470		MOVQ DX, 0x70(SP)																																																							
  phase0_transport.go:19	0x7e0f8d		c644242f01		MOVB $0x1, 0x2f(SP)																																																							
  phase0_transport.go:21	0x7e0f92		488d15a7000000		LEAQ dario.cat/cocoon/examples/datadog/go/dd.phase0TransportAdd.func1(SB), DX																																																
  phase0_transport.go:21	0x7e0f99		4889542450		MOVQ DX, 0x50(SP)																																																							
  phase0_transport.go:21	0x7e0f9e		48894c2458		MOVQ CX, 0x58(SP)																																																							
  phase0_transport.go:21	0x7e0fa3		f20f11442460		MOVSD_XMM X0, 0x60(SP)																																																							
  phase0_transport.go:21	0x7e0fa9		885c2468		MOVB BL, 0x68(SP)																																																							
  phase0_transport.go:21	0x7e0fad		488b4110		MOVQ 0x10(CX), AX																																																							
  phase0_transport.go:21	0x7e0fb1		488d1dc8d01200		LEAQ dario.cat/cocoon/rt..dict.Resource[dario.cat/cocoon/examples/datadog/go/dd.Sketch](SB), BX																																														
  phase0_transport.go:21	0x7e0fb8		488d0da6b10f00		LEAQ 0xfb1a6(IP), CX																																																							
  phase0_transport.go:21	0x7e0fbf		bf03000000		MOVL $0x3, DI																																																								
  phase0_transport.go:21	0x7e0fc4		488d742450		LEAQ 0x50(SP), SI																																																							
  phase0_transport.go:21	0x7e0fc9		e8f2db0200		CALL dario.cat/cocoon/rt.(*Resource[go.shape.struct { dario.cat/cocoon/examples/datadog/go/dd._ dario.cat/cocoon/rt.NoCopy; dario.cat/cocoon/examples/datadog/go/dd.library *dario.cat/cocoon/examples/datadog/go/dd.Library; dario.cat/cocoon/examples/datadog/go/dd.guest *dario.cat/cocoon/examples/datadog/go/dd.guest; dario.cat/cocoon/examples/datadog/go/dd.owner *dario.cat/cocoon/rt.Resource[dario.cat/cocoon/examples/datadog/go/dd.Sketch] }]).Use(SB)	
  phase0_transport.go:28	0x7e0fce		4889442430		MOVQ AX, 0x30(SP)																																																							
  phase0_transport.go:28	0x7e0fd3		48895c2438		MOVQ BX, 0x38(SP)																																																							
  phase0_transport.go:28	0x7e0fd8		c644242f00		MOVB $0x0, 0x2f(SP)																																																							
  phase0_transport.go:28	0x7e0fdd		488b542470		MOVQ 0x70(SP), DX																																																							
  phase0_transport.go:28	0x7e0fe2		4c8b02			MOVQ 0(DX), R8																																																								
  phase0_transport.go:28	0x7e0fe5		41ffd0			CALL R8																																																									
  phase0_transport.go:28	0x7e0fe8		488b442430		MOVQ 0x30(SP), AX																																																							
  phase0_transport.go:28	0x7e0fed		488b5c2438		MOVQ 0x38(SP), BX																																																							
  phase0_transport.go:28	0x7e0ff2		4883c478		ADDQ $0x78, SP																																																								
  phase0_transport.go:28	0x7e0ff6		5d			POPQ BP																																																									
  phase0_transport.go:28	0x7e0ff7		c3			RET																																																									
  phase0_transport.go:28	0x7e0ff8		e843cbc6ff		CALL runtime.deferreturn(SB)																																																						
  phase0_transport.go:28	0x7e0ffd		488b442430		MOVQ 0x30(SP), AX																																																							
  phase0_transport.go:28	0x7e1002		488b5c2438		MOVQ 0x38(SP), BX																																																							
  phase0_transport.go:28	0x7e1007		4883c478		ADDQ $0x78, SP																																																								
  phase0_transport.go:28	0x7e100b		5d			POPQ BP																																																									
  phase0_transport.go:28	0x7e100c		c3			RET																																																									
  phase0_transport.go:11	0x7e100d		4889442408		MOVQ AX, 0x8(SP)																																																							
  phase0_transport.go:11	0x7e1012		f20f11442410		MOVSD_XMM X0, 0x10(SP)																																																							
  phase0_transport.go:11	0x7e1018		885c2418		MOVB BL, 0x18(SP)																																																							
  phase0_transport.go:11	0x7e101c		0f1f4000		NOPL 0(AX)																																																								
  phase0_transport.go:11	0x7e1020		e87bdccaff		CALL runtime.morestack_noctxt.abi0(SB)																																																					
  phase0_transport.go:11	0x7e1025		488b442408		MOVQ 0x8(SP), AX																																																							
  phase0_transport.go:11	0x7e102a		f20f10442410		MOVSD_XMM 0x10(SP), X0																																																							
  phase0_transport.go:11	0x7e1030		0fb65c2418		MOVZX 0x18(SP), BX																																																							
  phase0_transport.go:11	0x7e1035		e926feffff		JMP dario.cat/cocoon/examples/datadog/go/dd.phase0TransportAdd(SB)																																																	

TEXT dario.cat/cocoon/examples/datadog/go/dd.phase0TransportAdd.func1(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/phase0_transport.go
  phase0_transport.go:21	0x7e1040		493b6610		CMPQ SP, 0x10(R14)								
  phase0_transport.go:21	0x7e1044		7665			JBE 0x7e10ab									
  phase0_transport.go:21	0x7e1046		55			PUSHQ BP									
  phase0_transport.go:21	0x7e1047		4889e5			MOVQ SP, BP									
  phase0_transport.go:21	0x7e104a		4883ec48		SUBQ $0x48, SP									
  phase0_transport.go:21	0x7e104e		f20f104210		MOVSD_XMM 0x10(DX), X0								
  phase0_transport.go:21	0x7e1053		0fb67218		MOVZX 0x18(DX), SI								
  phase0_transport.go:21	0x7e1057		488b5208		MOVQ 0x8(DX), DX								
  phase0_transport.go:22	0x7e105b		488b5208		MOVQ 0x8(DX), DX								
  phase0_transport.go:23	0x7e105f		488d7c2420		LEAQ 0x20(SP), DI								
  phase0_transport.go:23	0x7e1064		440f113f		MOVUPS X15, 0(DI)								
  phase0_transport.go:23	0x7e1068		440f117f10		MOVUPS X15, 0x10(DI)								
  phase0_transport.go:23	0x7e106d		440f117f18		MOVUPS X15, 0x18(DI)								
  phase0_transport.go:23	0x7e1072		4c8d0567000000		LEAQ dario.cat/cocoon/examples/datadog/go/dd.phase0TransportAdd.func1.1(SB), R8	
  phase0_transport.go:23	0x7e1079		4c89442420		MOVQ R8, 0x20(SP)								
  phase0_transport.go:23	0x7e107e		4889542428		MOVQ DX, 0x28(SP)								
  phase0_transport.go:23	0x7e1083		48895c2430		MOVQ BX, 0x30(SP)								
  phase0_transport.go:23	0x7e1088		f20f11442438		MOVSD_XMM X0, 0x38(SP)								
  phase0_transport.go:23	0x7e108e		4088742440		MOVB SI, 0x40(SP)								
  phase0_transport.go:23	0x7e1093		488d1dcbb00f00		LEAQ 0xfb0cb(IP), BX								
  phase0_transport.go:23	0x7e109a		b903000000		MOVL $0x3, CX									
  phase0_transport.go:23	0x7e109f		90			NOPL										
  phase0_transport.go:23	0x7e10a0		e83b6adeff		CALL dario.cat/cocoon/rt.(*Instance).Call(SB)					
  phase0_transport.go:23	0x7e10a5		4883c448		ADDQ $0x48, SP									
  phase0_transport.go:23	0x7e10a9		5d			POPQ BP										
  phase0_transport.go:23	0x7e10aa		c3			RET										
  phase0_transport.go:21	0x7e10ab		4889442408		MOVQ AX, 0x8(SP)								
  phase0_transport.go:21	0x7e10b0		48895c2410		MOVQ BX, 0x10(SP)								
  phase0_transport.go:21	0x7e10b5		e846dbcaff		CALL runtime.morestack.abi0(SB)							
  phase0_transport.go:21	0x7e10ba		488b442408		MOVQ 0x8(SP), AX								
  phase0_transport.go:21	0x7e10bf		488b5c2410		MOVQ 0x10(SP), BX								
  phase0_transport.go:21	0x7e10c4		e977ffffff		JMP dario.cat/cocoon/examples/datadog/go/dd.phase0TransportAdd.func1(SB)	

TEXT dario.cat/cocoon/examples/datadog/go/dd.phase0TransportAdd.func1.1(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/phase0_transport.go
  phase0_transport.go:23	0x7e10e0		493b6610		CMPQ SP, 0x10(R14)										
  phase0_transport.go:23	0x7e10e4		7650			JBE 0x7e1136											
  phase0_transport.go:23	0x7e10e6		55			PUSHQ BP											
  phase0_transport.go:23	0x7e10e7		4889e5			MOVQ SP, BP											
  phase0_transport.go:23	0x7e10ea		4883ec28		SUBQ $0x28, SP											
  phase0_transport.go:25	0x7e10ee		4889442438		MOVQ AX, 0x38(SP)										
  phase0_transport.go:23	0x7e10f3		0fb64a20		MOVZX 0x20(DX), CX										
  phase0_transport.go:23	0x7e10f7		884c2427		MOVB CL, 0x27(SP)										
  phase0_transport.go:23	0x7e10fb		488b5a10		MOVQ 0x10(DX), BX										
  phase0_transport.go:23	0x7e10ff		f20f104218		MOVSD_XMM 0x18(DX), X0										
  phase0_transport.go:23	0x7e1104		488b5208		MOVQ 0x8(DX), DX										
  phase0_transport.go:24	0x7e1108		488b12			MOVQ 0(DX), DX											
  phase0_transport.go:24	0x7e110b		488b02			MOVQ 0(DX), AX											
  phase0_transport.go:24	0x7e110e		e86d0bebff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).Phase0SketchAdd(SB)	
  phase0_transport.go:25	0x7e1113		488d1d4bb00f00		LEAQ 0xfb04b(IP), BX										
  phase0_transport.go:25	0x7e111a		b903000000		MOVL $0x3, CX											
  phase0_transport.go:25	0x7e111f		89c7			MOVL AX, DI											
  phase0_transport.go:25	0x7e1121		0fb6742427		MOVZX 0x27(SP), SI										
  phase0_transport.go:25	0x7e1126		488b442438		MOVQ 0x38(SP), AX										
  phase0_transport.go:25	0x7e112b		e8507bdeff		CALL dario.cat/cocoon/rt.(*Call).Phase0UnitReply(SB)						
  phase0_transport.go:25	0x7e1130		4883c428		ADDQ $0x28, SP											
  phase0_transport.go:25	0x7e1134		5d			POPQ BP												
  phase0_transport.go:25	0x7e1135		c3			RET												
  phase0_transport.go:23	0x7e1136		4889442408		MOVQ AX, 0x8(SP)										
  phase0_transport.go:23	0x7e113b		0f1f440000		NOPL 0(AX)(AX*1)										
  phase0_transport.go:23	0x7e1140		e8bbdacaff		CALL runtime.morestack.abi0(SB)									
  phase0_transport.go:23	0x7e1145		488b442408		MOVQ 0x8(SP), AX										
  phase0_transport.go:23	0x7e114a		eb94			JMP dario.cat/cocoon/examples/datadog/go/dd.phase0TransportAdd.func1.1(SB)			

TEXT dario.cat/cocoon/examples/datadog/go/dd.phase0TransportAdd.deferwrap1(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/phase0_transport.go
  phase0_transport.go:19	0x7e1160		493b6610		CMPQ SP, 0x10(R14)								
  phase0_transport.go:19	0x7e1164		7617			JBE 0x7e117d									
  phase0_transport.go:19	0x7e1166		55			PUSHQ BP									
  phase0_transport.go:19	0x7e1167		4889e5			MOVQ SP, BP									
  phase0_transport.go:19	0x7e116a		4883ec08		SUBQ $0x8, SP									
  phase0_transport.go:19	0x7e116e		488b4208		MOVQ 0x8(DX), AX								
  phase0_transport.go:19	0x7e1172		e80977deff		CALL dario.cat/cocoon/rt.(*Lifecycle).Leave(SB)					
  phase0_transport.go:19	0x7e1177		4883c408		ADDQ $0x8, SP									
  phase0_transport.go:19	0x7e117b		5d			POPQ BP										
  phase0_transport.go:19	0x7e117c		c3			RET										
  phase0_transport.go:19	0x7e117d		0f1f00			NOPL 0(AX)									
  phase0_transport.go:19	0x7e1180		e87bdacaff		CALL runtime.morestack.abi0(SB)							
  phase0_transport.go:19	0x7e1185		ebd9			JMP dario.cat/cocoon/examples/datadog/go/dd.phase0TransportAdd.deferwrap1(SB)	
