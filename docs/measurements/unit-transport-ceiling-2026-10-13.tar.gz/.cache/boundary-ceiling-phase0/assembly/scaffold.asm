TEXT dario.cat/cocoon/examples/datadog/go/dd.BenchmarkPhase0TransportScaffoldFixed(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/phase0_scaffold_test.go
  phase0_scaffold_test.go:9	0x804520		493b6610		CMPQ SP, 0x10(R14)											
  phase0_scaffold_test.go:9	0x804524		0f86d0000000		JBE 0x8045fa												
  phase0_scaffold_test.go:9	0x80452a		55			PUSHQ BP												
  phase0_scaffold_test.go:9	0x80452b		4889e5			MOVQ SP, BP												
  phase0_scaffold_test.go:9	0x80452e		4883ec60		SUBQ $0x60, SP												
  phase0_scaffold_test.go:10	0x804532		4889442470		MOVQ AX, 0x70(SP)											
  phase0_scaffold_test.go:10	0x804537		48c744244007000000	MOVQ $0x7, 0x40(SP)											
  phase0_scaffold_test.go:10	0x804540		488d0d008e0d00		LEAQ 0xd8e00(IP), CX											
  phase0_scaffold_test.go:10	0x804547		48894c2438		MOVQ CX, 0x38(SP)											
  phase0_scaffold_test.go:10	0x80454c		48c744245006000000	MOVQ $0x6, 0x50(SP)											
  phase0_scaffold_test.go:10	0x804555		488d0de0870d00		LEAQ 0xd87e0(IP), CX											
  phase0_scaffold_test.go:10	0x80455c		48894c2448		MOVQ CX, 0x48(SP)											
  phase0_scaffold_test.go:10	0x804561		488d4c2438		LEAQ 0x38(SP), CX											
  phase0_scaffold_test.go:10	0x804566		31d2			XORL DX, DX												
  phase0_scaffold_test.go:10	0x804568		eb27			JMP 0x804591												
  phase0_scaffold_test.go:11	0x80456a		48895808		MOVQ BX, 0x8(AX)											
  phase0_scaffold_test.go:11	0x80456e		4889c7			MOVQ AX, DI												
  phase0_scaffold_test.go:11	0x804571		488b442470		MOVQ 0x70(SP), AX											
  phase0_scaffold_test.go:11	0x804576		e8a5a0d0ff		CALL testing.(*B).Run(SB)										
  phase0_scaffold_test.go:10	0x80457b		488b4c2458		MOVQ 0x58(SP), CX											
  phase0_scaffold_test.go:10	0x804580		4883c110		ADDQ $0x10, CX												
  phase0_scaffold_test.go:10	0x804584		488b542428		MOVQ 0x28(SP), DX											
  phase0_scaffold_test.go:10	0x804589		48ffc2			INCQ DX													
  phase0_scaffold_test.go:11	0x80458c		488b442470		MOVQ 0x70(SP), AX											
  phase0_scaffold_test.go:10	0x804591		4883fa02		CMPQ DX, $0x2												
  phase0_scaffold_test.go:10	0x804595		7d5d			JGE 0x8045f4												
  phase0_scaffold_test.go:10	0x804597		4889542428		MOVQ DX, 0x28(SP)											
  phase0_scaffold_test.go:10	0x80459c		48894c2458		MOVQ CX, 0x58(SP)											
  phase0_scaffold_test.go:10	0x8045a1		488b5108		MOVQ 0x8(CX), DX											
  phase0_scaffold_test.go:10	0x8045a5		4889542420		MOVQ DX, 0x20(SP)											
  phase0_scaffold_test.go:10	0x8045aa		488b09			MOVQ 0(CX), CX												
  phase0_scaffold_test.go:10	0x8045ad		48894c2430		MOVQ CX, 0x30(SP)											
  phase0_scaffold_test.go:11	0x8045b2		488d0547a20700		LEAQ 0x7a247(IP), AX											
  phase0_scaffold_test.go:11	0x8045b9		e862dcc1ff		CALL runtime.newobject(SB)										
  phase0_scaffold_test.go:11	0x8045be		488d0d5b000000		LEAQ dario.cat/cocoon/examples/datadog/go/dd.BenchmarkPhase0TransportScaffoldFixed.func1(SB), CX	
  phase0_scaffold_test.go:11	0x8045c5		488908			MOVQ CX, 0(AX)												
  phase0_scaffold_test.go:11	0x8045c8		488b4c2420		MOVQ 0x20(SP), CX											
  phase0_scaffold_test.go:11	0x8045cd		48894810		MOVQ CX, 0x10(AX)											
  phase0_scaffold_test.go:11	0x8045d1		833d98bb500000		CMPL runtime.writeBarrier(SB), $0x0									
  phase0_scaffold_test.go:11	0x8045d8		7508			JNE 0x8045e2												
  phase0_scaffold_test.go:11	0x8045da		488b5c2430		MOVQ 0x30(SP), BX											
  phase0_scaffold_test.go:11	0x8045df		90			NOPL													
  phase0_scaffold_test.go:11	0x8045e0		eb88			JMP 0x80456a												
  phase0_scaffold_test.go:11	0x8045e2		e819c0c8ff		CALL runtime.gcWriteBarrier1(SB)									
  phase0_scaffold_test.go:11	0x8045e7		488b5c2430		MOVQ 0x30(SP), BX											
  phase0_scaffold_test.go:11	0x8045ec		49891b			MOVQ BX, 0(R11)												
  phase0_scaffold_test.go:11	0x8045ef		e976ffffff		JMP 0x80456a												
  phase0_scaffold_test.go:44	0x8045f4		4883c460		ADDQ $0x60, SP												
  phase0_scaffold_test.go:44	0x8045f8		5d			POPQ BP													
  phase0_scaffold_test.go:44	0x8045f9		c3			RET													
  phase0_scaffold_test.go:9	0x8045fa		4889442408		MOVQ AX, 0x8(SP)											
  phase0_scaffold_test.go:9	0x8045ff		90			NOPL													
  phase0_scaffold_test.go:9	0x804600		e89ba6c8ff		CALL runtime.morestack_noctxt.abi0(SB)									
  phase0_scaffold_test.go:9	0x804605		488b442408		MOVQ 0x8(SP), AX											
  phase0_scaffold_test.go:9	0x80460a		e911ffffff		JMP dario.cat/cocoon/examples/datadog/go/dd.BenchmarkPhase0TransportScaffoldFixed(SB)			

TEXT dario.cat/cocoon/examples/datadog/go/dd.BenchmarkPhase0TransportScaffoldFixed.func1(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/phase0_scaffold_test.go
  phase0_scaffold_test.go:11	0x804620		493b6610		CMPQ SP, 0x10(R14)											
  phase0_scaffold_test.go:11	0x804624		0f8601010000		JBE 0x80472b												
  phase0_scaffold_test.go:11	0x80462a		55			PUSHQ BP												
  phase0_scaffold_test.go:11	0x80462b		4889e5			MOVQ SP, BP												
  phase0_scaffold_test.go:11	0x80462e		4883ec58		SUBQ $0x58, SP												
  phase0_scaffold_test.go:12	0x804632		4889442468		MOVQ AX, 0x68(SP)											
  phase0_scaffold_test.go:12	0x804637		488b0d62ac4d00		MOVQ dario.cat/cocoon/examples/datadog/go/dd.phase0TransportCorpora(SB), CX				
  phase0_scaffold_test.go:11	0x80463e		488b5a08		MOVQ 0x8(DX), BX											
  phase0_scaffold_test.go:11	0x804642		48895c2440		MOVQ BX, 0x40(SP)											
  phase0_scaffold_test.go:11	0x804647		488b5210		MOVQ 0x10(DX), DX											
  phase0_scaffold_test.go:11	0x80464b		4889542420		MOVQ DX, 0x20(SP)											
  phase0_scaffold_test.go:12	0x804650		488b3551ac4d00		MOVQ dario.cat/cocoon/examples/datadog/go/dd.phase0TransportCorpora+8(SB), SI				
  phase0_scaffold_test.go:12	0x804657		4889742438		MOVQ SI, 0x38(SP)											
  phase0_scaffold_test.go:12	0x80465c		31ff			XORL DI, DI												
  phase0_scaffold_test.go:12	0x80465e		6690			NOPW													
  phase0_scaffold_test.go:12	0x804660		eb48			JMP 0x8046aa												
  phase0_scaffold_test.go:13	0x804662		48895808		MOVQ BX, 0x8(AX)											
  phase0_scaffold_test.go:13	0x804666		488b742420		MOVQ 0x20(SP), SI											
  phase0_scaffold_test.go:13	0x80466b		48897020		MOVQ SI, 0x20(AX)											
  phase0_scaffold_test.go:13	0x80466f		48895018		MOVQ DX, 0x18(AX)											
  phase0_scaffold_test.go:13	0x804673		4889c7			MOVQ AX, DI												
  phase0_scaffold_test.go:13	0x804676		488b442468		MOVQ 0x68(SP), AX											
  phase0_scaffold_test.go:13	0x80467b		0f1f440000		NOPL 0(AX)(AX*1)											
  phase0_scaffold_test.go:13	0x804680		e89b9fd0ff		CALL testing.(*B).Run(SB)										
  phase0_scaffold_test.go:12	0x804685		488b4c2450		MOVQ 0x50(SP), CX											
  phase0_scaffold_test.go:12	0x80468a		4883c110		ADDQ $0x10, CX												
  phase0_scaffold_test.go:12	0x80468e		488b7c2430		MOVQ 0x30(SP), DI											
  phase0_scaffold_test.go:12	0x804693		48ffc7			INCQ DI													
  phase0_scaffold_test.go:13	0x804696		488b442468		MOVQ 0x68(SP), AX											
  phase0_scaffold_test.go:13	0x80469b		488b542420		MOVQ 0x20(SP), DX											
  phase0_scaffold_test.go:13	0x8046a0		488b5c2440		MOVQ 0x40(SP), BX											
  phase0_scaffold_test.go:12	0x8046a5		488b742438		MOVQ 0x38(SP), SI											
  phase0_scaffold_test.go:12	0x8046aa		4839f7			CMPQ DI, SI												
  phase0_scaffold_test.go:12	0x8046ad		7d76			JGE 0x804725												
  phase0_scaffold_test.go:12	0x8046af		48897c2430		MOVQ DI, 0x30(SP)											
  phase0_scaffold_test.go:12	0x8046b4		48894c2450		MOVQ CX, 0x50(SP)											
  phase0_scaffold_test.go:12	0x8046b9		488b5108		MOVQ 0x8(CX), DX											
  phase0_scaffold_test.go:12	0x8046bd		4889542428		MOVQ DX, 0x28(SP)											
  phase0_scaffold_test.go:12	0x8046c2		488b09			MOVQ 0(CX), CX												
  phase0_scaffold_test.go:12	0x8046c5		48894c2448		MOVQ CX, 0x48(SP)											
  phase0_scaffold_test.go:13	0x8046ca		488d05eff50800		LEAQ 0x8f5ef(IP), AX											
  phase0_scaffold_test.go:13	0x8046d1		e84adbc1ff		CALL runtime.newobject(SB)										
  phase0_scaffold_test.go:13	0x8046d6		488d0d63000000		LEAQ dario.cat/cocoon/examples/datadog/go/dd.BenchmarkPhase0TransportScaffoldFixed.func1.1(SB), CX	
  phase0_scaffold_test.go:13	0x8046dd		488908			MOVQ CX, 0(AX)												
  phase0_scaffold_test.go:13	0x8046e0		488b4c2428		MOVQ 0x28(SP), CX											
  phase0_scaffold_test.go:13	0x8046e5		48894810		MOVQ CX, 0x10(AX)											
  phase0_scaffold_test.go:13	0x8046e9		833d80ba500000		CMPL runtime.writeBarrier(SB), $0x0									
  phase0_scaffold_test.go:13	0x8046f0		7513			JNE 0x804705												
  phase0_scaffold_test.go:13	0x8046f2		488b542440		MOVQ 0x40(SP), DX											
  phase0_scaffold_test.go:13	0x8046f7		488b5c2448		MOVQ 0x48(SP), BX											
  phase0_scaffold_test.go:13	0x8046fc		0f1f4000		NOPL 0(AX)												
  phase0_scaffold_test.go:13	0x804700		e95dffffff		JMP 0x804662												
  phase0_scaffold_test.go:13	0x804705		e816bfc8ff		CALL runtime.gcWriteBarrier2(SB)									
  phase0_scaffold_test.go:13	0x80470a		488b5c2448		MOVQ 0x48(SP), BX											
  phase0_scaffold_test.go:13	0x80470f		49891b			MOVQ BX, 0(R11)												
  phase0_scaffold_test.go:13	0x804712		488b542440		MOVQ 0x40(SP), DX											
  phase0_scaffold_test.go:13	0x804717		49895308		MOVQ DX, 0x8(R11)											
  phase0_scaffold_test.go:13	0x80471b		0f1f440000		NOPL 0(AX)(AX*1)											
  phase0_scaffold_test.go:13	0x804720		e93dffffff		JMP 0x804662												
  phase0_scaffold_test.go:42	0x804725		4883c458		ADDQ $0x58, SP												
  phase0_scaffold_test.go:42	0x804729		5d			POPQ BP													
  phase0_scaffold_test.go:42	0x80472a		c3			RET													
  phase0_scaffold_test.go:11	0x80472b		4889442408		MOVQ AX, 0x8(SP)											
  phase0_scaffold_test.go:11	0x804730		e8cba4c8ff		CALL runtime.morestack.abi0(SB)										
  phase0_scaffold_test.go:11	0x804735		488b442408		MOVQ 0x8(SP), AX											
  phase0_scaffold_test.go:11	0x80473a		e9e1feffff		JMP dario.cat/cocoon/examples/datadog/go/dd.BenchmarkPhase0TransportScaffoldFixed.func1(SB)		

TEXT dario.cat/cocoon/examples/datadog/go/dd.BenchmarkPhase0TransportScaffoldFixed.func1.1(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/phase0_scaffold_test.go
  phase0_scaffold_test.go:13	0x804740		4c8da42430feffff	LEAQ 0xfffffe30(SP), R12									
  phase0_scaffold_test.go:13	0x804748		4d3b6610		CMPQ R12, 0x10(R14)										
  phase0_scaffold_test.go:13	0x80474c		0f865c060000		JBE 0x804dae											
  phase0_scaffold_test.go:13	0x804752		55			PUSHQ BP											
  phase0_scaffold_test.go:13	0x804753		4889e5			MOVQ SP, BP											
  phase0_scaffold_test.go:13	0x804756		4881ec48020000		SUBQ $0x248, SP											
  phase0_scaffold_test.go:13	0x80475d		66440fd6bc2440020000	MOVQ X15, 0x240(SP)										
  phase0_scaffold_test.go:16	0x804767		4889842458020000	MOVQ AX, 0x258(SP)										
  phase0_scaffold_test.go:13	0x80476f		c68424d700000000	MOVB $0x0, 0xd7(SP)										
  phase0_scaffold_test.go:13	0x804777		488b4a08		MOVQ 0x8(DX), CX										
  phase0_scaffold_test.go:13	0x80477b		48898c24e0010000	MOVQ CX, 0x1e0(SP)										
  phase0_scaffold_test.go:13	0x804783		488b4a10		MOVQ 0x10(DX), CX										
  phase0_scaffold_test.go:13	0x804787		48898c2418010000	MOVQ CX, 0x118(SP)										
  phase0_scaffold_test.go:13	0x80478f		488b4a18		MOVQ 0x18(DX), CX										
  phase0_scaffold_test.go:13	0x804793		48898c2438010000	MOVQ CX, 0x138(SP)										
  phase0_scaffold_test.go:13	0x80479b		488b4a20		MOVQ 0x20(DX), CX										
  phase0_scaffold_test.go:13	0x80479f		48898c2420010000	MOVQ CX, 0x120(SP)										
  phase0_scaffold_test.go:14	0x8047a7		4889c3			MOVQ AX, BX											
  phase0_scaffold_test.go:14	0x8047aa		488d05df541100		LEAQ go:itab.*testing.B,testing.TB(SB), AX							
  phase0_scaffold_test.go:14	0x8047b1		e8eadbffff		CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportProcessors(SB)			
  phase0_scaffold_test.go:14	0x8047b6		4889842440020000	MOVQ AX, 0x240(SP)										
  phase0_scaffold_test.go:14	0x8047be		c68424d700000001	MOVB $0x1, 0xd7(SP)										
  phase0_scaffold_test.go:15	0x8047c6		488d05c3541100		LEAQ go:itab.*testing.B,testing.TB(SB), AX							
  phase0_scaffold_test.go:15	0x8047cd		488b9c2458020000	MOVQ 0x258(SP), BX										
  phase0_scaffold_test.go:15	0x8047d5		e866c8ffff		CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportPrefix(SB)				
  phase0_scaffold_test.go:15	0x8047da		48898424f0000000	MOVQ AX, 0xf0(SP)										
  phase0_scaffold_test.go:16	0x8047e2		488b8c2458020000	MOVQ 0x258(SP), CX										
  phase0_scaffold_test.go:16	0x8047ea		4883b91002000001	CMPQ 0x210(CX), $0x1										
  phase0_scaffold_test.go:16	0x8047f2		7446			JE 0x80483a											
  phase0_scaffold_test.go:17	0x8047f4		488d1505e40400		LEAQ 0x4e405(IP), DX										
  phase0_scaffold_test.go:17	0x8047fb		4889942430020000	MOVQ DX, 0x230(SP)										
  phase0_scaffold_test.go:17	0x804803		488d1516701000		LEAQ 0x107016(IP), DX										
  phase0_scaffold_test.go:17	0x80480a		4889942438020000	MOVQ DX, 0x238(SP)										
  phase0_scaffold_test.go:17	0x804812		4889c8			MOVQ CX, AX											
  phase0_scaffold_test.go:17	0x804815		488d9c2430020000	LEAQ 0x230(SP), BX										
  phase0_scaffold_test.go:17	0x80481d		b901000000		MOVL $0x1, CX											
  phase0_scaffold_test.go:17	0x804822		4889cf			MOVQ CX, DI											
  phase0_scaffold_test.go:17	0x804825		e89657d1ff		CALL testing.(*common).Fatal(SB)								
  phase0_scaffold_test.go:20	0x80482a		488b8424f0000000	MOVQ 0xf0(SP), AX										
  phase0_scaffold_test.go:21	0x804832		488b8c2458020000	MOVQ 0x258(SP), CX										
  phase0_original_test.go:41	0x80483a		488b9c2418010000	MOVQ 0x118(SP), BX										
  phase0_original_test.go:41	0x804842		4883fb0a		CMPQ BX, $0xa											
  phase0_original_test.go:41	0x804846		7528			JNE 0x804870											
  phase0_original_test.go:41	0x804848		48ba496e637265617369	MOVQ $0x6973616572636e49, DX									
  phase0_original_test.go:41	0x804852		4c8b8c24e0010000	MOVQ 0x1e0(SP), R9										
  phase0_original_test.go:41	0x80485a		493911			CMPQ 0(R9), DX											
  phase0_original_test.go:41	0x80485d		7519			JNE 0x804878											
  phase0_original_test.go:41	0x80485f		66418179086e67		CMPW 0x8(R9), $0x676e										
  phase0_original_test.go:41	0x804866		7510			JNE 0x804878											
  phase0_original_test.go:41	0x804868		31d2			XORL DX, DX											
  phase0_original_test.go:41	0x80486a		31f6			XORL SI, SI											
  phase0_original_test.go:41	0x80486c		31ff			XORL DI, DI											
  phase0_scaffold_test.go:19	0x80486e		eb36			JMP 0x8048a6											
  phase0_original_test.go:45	0x804870		4c8b8c24e0010000	MOVQ 0x1e0(SP), R9										
  phase0_original_test.go:45	0x804878		4c89c8			MOVQ R9, AX											
  phase0_original_test.go:45	0x80487b		0f1f440000		NOPL 0(AX)(AX*1)										
  phase0_original_test.go:45	0x804880		e87b55ffff		CALL dario.cat/cocoon/examples/datadog/go/dd.binReuseValues(SB)					
  phase0_scaffold_test.go:20	0x804885		4c8b8c24e0010000	MOVQ 0x1e0(SP), R9										
  phase0_scaffold_test.go:19	0x80488d		4889da			MOVQ BX, DX											
  phase0_scaffold_test.go:19	0x804890		4889c6			MOVQ AX, SI											
  phase0_scaffold_test.go:19	0x804893		4889cf			MOVQ CX, DI											
  phase0_scaffold_test.go:20	0x804896		488b8424f0000000	MOVQ 0xf0(SP), AX										
  phase0_scaffold_test.go:20	0x80489e		488b9c2418010000	MOVQ 0x118(SP), BX										
  phase0_scaffold_test.go:19	0x8048a6		4889b42428010000	MOVQ SI, 0x128(SP)										
  phase0_scaffold_test.go:19	0x8048ae		48899424e8000000	MOVQ DX, 0xe8(SP)										
  phase0_scaffold_test.go:20	0x8048b6		4889f1			MOVQ SI, CX											
  phase0_scaffold_test.go:20	0x8048b9		4889fe			MOVQ DI, SI											
  phase0_scaffold_test.go:20	0x8048bc		4989c0			MOVQ AX, R8											
  phase0_scaffold_test.go:20	0x8048bf		4c89c8			MOVQ R9, AX											
  phase0_scaffold_test.go:20	0x8048c2		4889d7			MOVQ DX, DI											
  phase0_scaffold_test.go:20	0x8048c5		e856c8ffff		CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportInputSHA(SB)			
  phase0_scaffold_test.go:20	0x8048ca		4889842440010000	MOVQ AX, 0x140(SP)										
  phase0_scaffold_test.go:20	0x8048d2		48899c24f8000000	MOVQ BX, 0xf8(SP)										
  phase0_scaffold_test.go:21	0x8048da		488b8c24e0010000	MOVQ 0x1e0(SP), CX										
  phase0_scaffold_test.go:21	0x8048e2		488bbc2418010000	MOVQ 0x118(SP), DI										
  phase0_scaffold_test.go:21	0x8048ea		488bb424f0000000	MOVQ 0xf0(SP), SI										
  phase0_scaffold_test.go:21	0x8048f2		4989c0			MOVQ AX, R8											
  phase0_scaffold_test.go:21	0x8048f5		4989d9			MOVQ BX, R9											
  phase0_scaffold_test.go:21	0x8048f8		488d0591531100		LEAQ go:itab.*testing.B,testing.TB(SB), AX							
  phase0_scaffold_test.go:21	0x8048ff		488b9c2458020000	MOVQ 0x258(SP), BX										
  phase0_scaffold_test.go:21	0x804907		e874d1ffff		CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportExpected(SB)			
  phase0_scaffold_test.go:21	0x80490c		488b1424		MOVQ 0(SP), DX											
  phase0_scaffold_test.go:21	0x804910		4889942490010000	MOVQ DX, 0x190(SP)										
  phase0_scaffold_test.go:21	0x804918		488b542408		MOVQ 0x8(SP), DX										
  phase0_scaffold_test.go:21	0x80491d		4889942408010000	MOVQ DX, 0x108(SP)										
  phase0_scaffold_test.go:21	0x804925		488b542410		MOVQ 0x10(SP), DX										
  phase0_scaffold_test.go:21	0x80492a		4889942410010000	MOVQ DX, 0x110(SP)										
  phase0_scaffold_test.go:21	0x804932		48898424e8010000	MOVQ AX, 0x1e8(SP)										
  phase0_scaffold_test.go:21	0x80493a		48899c24f0010000	MOVQ BX, 0x1f0(SP)										
  phase0_scaffold_test.go:21	0x804942		48898c24f8010000	MOVQ CX, 0x1f8(SP)										
  phase0_scaffold_test.go:21	0x80494a		4889bc2400020000	MOVQ DI, 0x200(SP)										
  phase0_scaffold_test.go:21	0x804952		4889b42408020000	MOVQ SI, 0x208(SP)										
  phase0_scaffold_test.go:21	0x80495a		4c89842410020000	MOVQ R8, 0x210(SP)										
  phase0_scaffold_test.go:21	0x804962		4c898c2418020000	MOVQ R9, 0x218(SP)										
  phase0_scaffold_test.go:21	0x80496a		4c89942420020000	MOVQ R10, 0x220(SP)										
  phase0_scaffold_test.go:21	0x804972		4c899c2428020000	MOVQ R11, 0x228(SP)										
  phase0_scaffold_test.go:21	0x80497a		488d942498010000	LEAQ 0x198(SP), DX										
  phase0_scaffold_test.go:21	0x804982		4c8d8c24e8010000	LEAQ 0x1e8(SP), R9										
  phase0_scaffold_test.go:21	0x80498a		450f1031		MOVUPS 0(R9), X14										
  phase0_scaffold_test.go:21	0x80498e		440f1132		MOVUPS X14, 0(DX)										
  phase0_scaffold_test.go:21	0x804992		450f107110		MOVUPS 0x10(R9), X14										
  phase0_scaffold_test.go:21	0x804997		440f117210		MOVUPS X14, 0x10(DX)										
  phase0_scaffold_test.go:21	0x80499c		450f107120		MOVUPS 0x20(R9), X14										
  phase0_scaffold_test.go:21	0x8049a1		440f117220		MOVUPS X14, 0x20(DX)										
  phase0_scaffold_test.go:21	0x8049a6		450f107130		MOVUPS 0x30(R9), X14										
  phase0_scaffold_test.go:21	0x8049ab		440f117230		MOVUPS X14, 0x30(DX)										
  phase0_scaffold_test.go:21	0x8049b0		450f107138		MOVUPS 0x38(R9), X14										
  phase0_scaffold_test.go:21	0x8049b5		440f117238		MOVUPS X14, 0x38(DX)										
  phase0_scaffold_test.go:22	0x8049ba		488d05cf521100		LEAQ go:itab.*testing.B,testing.TB(SB), AX							
  phase0_scaffold_test.go:22	0x8049c1		488b9c2458020000	MOVQ 0x258(SP), BX										
  phase0_scaffold_test.go:22	0x8049c9		e8b2c9ffff		CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportSketch(SB)				
  phase0_scaffold_test.go:22	0x8049ce		4889842430010000	MOVQ AX, 0x130(SP)										
  phase0_scaffold_test.go:23	0x8049d6		488b5008		MOVQ 0x8(AX), DX										
  phase0_scaffold_test.go:23	0x8049da		488b12			MOVQ 0(DX), DX											
  zz_adapter.go:11		0x8049dd		488b12			MOVQ 0(DX), DX											
  module.go:62926		0x8049e0		8402			TESTB AL, 0(DX)											
  module.go:62926		0x8049e2		4883c230		ADDQ $0x30, DX											
  zz_adapter.go:11		0x8049e6		488b5208		MOVQ 0x8(DX), DX										
  zz_adapter.go:11		0x8049ea		48899424e0000000	MOVQ DX, 0xe0(SP)										
  phase0_scaffold_test.go:13	0x8049f2		4c8b8c2420010000	MOVQ 0x120(SP), R9										
  phase0_scaffold_test.go:13	0x8049fa		660f1f440000		NOPW 0(AX)(AX*1)										
  phase0_scaffold_test.go:13	0x804a00		4983f906		CMPQ R9, $0x6											
  phase0_scaffold_test.go:24	0x804a04		751c			JNE 0x804a22											
  phase0_scaffold_test.go:24	0x804a06		488b8c2438010000	MOVQ 0x138(SP), CX										
  phase0_scaffold_test.go:24	0x804a0e		81394f726163		CMPL 0(CX), $0x6361724f										
  phase0_scaffold_test.go:24	0x804a14		750c			JNE 0x804a22											
  phase0_scaffold_test.go:24	0x804a16		668179046c65		CMPW 0x4(CX), $0x656c										
  phase0_scaffold_test.go:24	0x804a1c		0f94c1			SETE CL												
  phase0_scaffold_test.go:24	0x804a1f		90			NOPL												
  phase0_scaffold_test.go:24	0x804a20		eb02			JMP 0x804a24											
  phase0_scaffold_test.go:24	0x804a22		31c9			XORL CX, CX											
  phase0_scaffold_test.go:24	0x804a24		880d43b15000		MOVB CL, dario.cat/cocoon/examples/datadog/go/dd.phase0TransportMode(SB)			
  phase0_scaffold_test.go:25	0x804a2a		90			NOPL												
  benchmark.go:193		0x804a2b		488b9c2458020000	MOVQ 0x258(SP), BX										
  benchmark.go:193		0x804a33		c6835202000001		MOVB $0x1, 0x252(BX)										
  phase0_scaffold_test.go:26	0x804a3a		488d054f521100		LEAQ go:itab.*testing.B,testing.TB(SB), AX							
  phase0_scaffold_test.go:26	0x804a41		e81adaffff		CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportActual(SB)				
  phase0_scaffold_test.go:27	0x804a46		488b842458020000	MOVQ 0x258(SP), AX										
  phase0_scaffold_test.go:27	0x804a4e		e8cd6cd0ff		CALL testing.(*B).ResetTimer(SB)								
  phase0_scaffold_test.go:27	0x804a53		31c0			XORL AX, AX											
  phase0_scaffold_test.go:28	0x804a55		eb0b			JMP 0x804a62											
  phase0_scaffold_test.go:28	0x804a57		488b842400010000	MOVQ 0x100(SP), AX										
  phase0_scaffold_test.go:28	0x804a5f		48ffc0			INCQ AX												
  phase0_scaffold_test.go:28	0x804a62		488b8c24f0000000	MOVQ 0xf0(SP), CX										
  phase0_scaffold_test.go:28	0x804a6a		4839c1			CMPQ CX, AX											
  phase0_scaffold_test.go:28	0x804a6d		0f8ee5000000		JLE 0x804b58											
  phase0_scaffold_test.go:28	0x804a73		4889842400010000	MOVQ AX, 0x100(SP)										
  phase0_original_test.go:41	0x804a7b		488b942418010000	MOVQ 0x118(SP), DX										
  phase0_original_test.go:41	0x804a83		4883fa0a		CMPQ DX, $0xa											
  phase0_original_test.go:49	0x804a87		7532			JNE 0x804abb											
  phase0_original_test.go:49	0x804a89		48be496e637265617369	MOVQ $0x6973616572636e49, SI									
  phase0_original_test.go:49	0x804a93		488bbc24e0010000	MOVQ 0x1e0(SP), DI										
  phase0_original_test.go:49	0x804a9b		0f1f440000		NOPL 0(AX)(AX*1)										
  phase0_original_test.go:49	0x804aa0		483937			CMPQ 0(DI), SI											
  phase0_original_test.go:49	0x804aa3		7528			JNE 0x804acd											
  phase0_original_test.go:49	0x804aa5		66817f086e67		CMPW 0x8(DI), $0x676e										
  phase0_original_test.go:49	0x804aab		7520			JNE 0x804acd											
  phase0_original_test.go:50	0x804aad		4c8d4001		LEAQ 0x1(AX), R8										
  phase0_original_test.go:50	0x804ab1		0f57c9			XORPS X1, X1											
  phase0_original_test.go:50	0x804ab4		f2490f2ac8		CVTSI2SDQ R8, X1										
  phase0_scaffold_test.go:29	0x804ab9		eb3c			JMP 0x804af7											
  phase0_scaffold_test.go:29	0x804abb		48be496e637265617369	MOVQ $0x6973616572636e49, SI									
  phase0_original_test.go:49	0x804ac5		488bbc24e0010000	MOVQ 0x1e0(SP), DI										
  phase0_original_test.go:52	0x804acd		25ff1f0000		ANDL $0x1fff, AX										
  phase0_original_test.go:52	0x804ad2		4c8b8c24e8000000	MOVQ 0xe8(SP), R9										
  phase0_original_test.go:52	0x804ada		660f1f440000		NOPW 0(AX)(AX*1)										
  phase0_original_test.go:52	0x804ae0		4939c1			CMPQ R9, AX											
  phase0_original_test.go:52	0x804ae3		0f86b1020000		JBE 0x804d9a											
  phase0_original_test.go:52	0x804ae9		4c8b942428010000	MOVQ 0x128(SP), R10										
  phase0_original_test.go:52	0x804af1		f2410f100cc2		MOVSD_XMM 0(R10)(AX*8), X1									
  phase0_scaffold_test.go:30	0x804af7		0fb61d6fb05000		MOVZX dario.cat/cocoon/examples/datadog/go/dd.phase0TransportMode(SB), BX			
  phase0_scaffold_test.go:30	0x804afe		488b842430010000	MOVQ 0x130(SP), AX										
  phase0_scaffold_test.go:30	0x804b06		0f10c1			MOVUPS X1, X0											
  phase0_scaffold_test.go:30	0x804b09		e852c3fdff		CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportAdd(SB)				
  phase0_scaffold_test.go:30	0x804b0e		4885c0			TESTQ AX, AX											
  phase0_scaffold_test.go:30	0x804b11		0f8440ffffff		JE 0x804a57											
  phase0_scaffold_test.go:31	0x804b17		440f11bc2430020000	MOVUPS X15, 0x230(SP)										
  phase0_scaffold_test.go:31	0x804b20		7404			JE 0x804b26											
  phase0_scaffold_test.go:31	0x804b22		488b4008		MOVQ 0x8(AX), AX										
  phase0_scaffold_test.go:31	0x804b26		4889842430020000	MOVQ AX, 0x230(SP)										
  phase0_scaffold_test.go:31	0x804b2e		48899c2438020000	MOVQ BX, 0x238(SP)										
  phase0_scaffold_test.go:31	0x804b36		488b842458020000	MOVQ 0x258(SP), AX										
  phase0_scaffold_test.go:31	0x804b3e		488d9c2430020000	LEAQ 0x230(SP), BX										
  phase0_scaffold_test.go:31	0x804b46		b901000000		MOVL $0x1, CX											
  phase0_scaffold_test.go:31	0x804b4b		4889cf			MOVQ CX, DI											
  phase0_scaffold_test.go:31	0x804b4e		e86d54d1ff		CALL testing.(*common).Fatal(SB)								
  phase0_scaffold_test.go:31	0x804b53		e9fffeffff		JMP 0x804a57											
  phase0_scaffold_test.go:34	0x804b58		488b842458020000	MOVQ 0x258(SP), AX										
  phase0_scaffold_test.go:34	0x804b60		e8fb6ad0ff		CALL testing.(*B).StopTimer(SB)									
  phase0_scaffold_test.go:35	0x804b65		488d0524511100		LEAQ go:itab.*testing.B,testing.TB(SB), AX							
  phase0_scaffold_test.go:35	0x804b6c		488b9c2458020000	MOVQ 0x258(SP), BX										
  phase0_scaffold_test.go:35	0x804b74		e8e7d8ffff		CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportActual(SB)				
  phase0_scaffold_test.go:36	0x804b79		488b8c2430010000	MOVQ 0x130(SP), CX										
  phase0_scaffold_test.go:36	0x804b81		488b5108		MOVQ 0x8(CX), DX										
  phase0_scaffold_test.go:36	0x804b85		488b12			MOVQ 0(DX), DX											
  zz_adapter.go:11		0x804b88		488b12			MOVQ 0(DX), DX											
  module.go:62926		0x804b8b		8402			TESTB AL, 0(DX)											
  module.go:62926		0x804b8d		4883c230		ADDQ $0x30, DX											
  zz_adapter.go:11		0x804b91		488b5208		MOVQ 0x8(DX), DX										
  zz_adapter.go:11		0x804b95		48899424d8000000	MOVQ DX, 0xd8(SP)										
  phase0_scaffold_test.go:37	0x804b9d		488d05ec501100		LEAQ go:itab.*testing.B,testing.TB(SB), AX							
  phase0_scaffold_test.go:37	0x804ba4		488b9c2458020000	MOVQ 0x258(SP), BX										
  phase0_scaffold_test.go:37	0x804bac		488bbc24e0010000	MOVQ 0x1e0(SP), DI										
  phase0_scaffold_test.go:37	0x804bb4		488bb42418010000	MOVQ 0x118(SP), SI										
  phase0_scaffold_test.go:37	0x804bbc		4c8b8424f0000000	MOVQ 0xf0(SP), R8										
  phase0_scaffold_test.go:37	0x804bc4		4c8b8c2440010000	MOVQ 0x140(SP), R9										
  phase0_scaffold_test.go:37	0x804bcc		4c8b9424f8000000	MOVQ 0xf8(SP), R10										
  phase0_scaffold_test.go:37	0x804bd4		e8c7c9ffff		CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportState(SB)				
  phase0_scaffold_test.go:37	0x804bd9		488b1424		MOVQ 0(SP), DX											
  phase0_scaffold_test.go:37	0x804bdd		4c8b642408		MOVQ 0x8(SP), R12										
  phase0_scaffold_test.go:37	0x804be2		4c8b6c2410		MOVQ 0x10(SP), R13										
  phase0_scaffold_test.go:37	0x804be7		48898424e8010000	MOVQ AX, 0x1e8(SP)										
  phase0_scaffold_test.go:37	0x804bef		48899c24f0010000	MOVQ BX, 0x1f0(SP)										
  phase0_scaffold_test.go:37	0x804bf7		48898c24f8010000	MOVQ CX, 0x1f8(SP)										
  phase0_scaffold_test.go:37	0x804bff		4889bc2400020000	MOVQ DI, 0x200(SP)										
  phase0_scaffold_test.go:37	0x804c07		4889b42408020000	MOVQ SI, 0x208(SP)										
  phase0_scaffold_test.go:37	0x804c0f		4c89842410020000	MOVQ R8, 0x210(SP)										
  phase0_scaffold_test.go:37	0x804c17		4c898c2418020000	MOVQ R9, 0x218(SP)										
  phase0_scaffold_test.go:37	0x804c1f		4c89942420020000	MOVQ R10, 0x220(SP)										
  phase0_scaffold_test.go:37	0x804c27		4c899c2428020000	MOVQ R11, 0x228(SP)										
  phase0_scaffold_test.go:37	0x804c2f		488d8c2448010000	LEAQ 0x148(SP), CX										
  phase0_scaffold_test.go:37	0x804c37		488d9c24e8010000	LEAQ 0x1e8(SP), BX										
  phase0_scaffold_test.go:37	0x804c3f		440f1033		MOVUPS 0(BX), X14										
  phase0_scaffold_test.go:37	0x804c43		440f1131		MOVUPS X14, 0(CX)										
  phase0_scaffold_test.go:37	0x804c47		440f107310		MOVUPS 0x10(BX), X14										
  phase0_scaffold_test.go:37	0x804c4c		440f117110		MOVUPS X14, 0x10(CX)										
  phase0_scaffold_test.go:37	0x804c51		440f107320		MOVUPS 0x20(BX), X14										
  phase0_scaffold_test.go:37	0x804c56		440f117120		MOVUPS X14, 0x20(CX)										
  phase0_scaffold_test.go:37	0x804c5b		440f107330		MOVUPS 0x30(BX), X14										
  phase0_scaffold_test.go:37	0x804c60		440f117130		MOVUPS X14, 0x30(CX)										
  phase0_scaffold_test.go:37	0x804c65		440f107338		MOVUPS 0x38(BX), X14										
  phase0_scaffold_test.go:37	0x804c6a		440f117138		MOVUPS X14, 0x38(CX)										
  phase0_scaffold_test.go:38	0x804c6f		4889e1			MOVQ SP, CX											
  phase0_scaffold_test.go:38	0x804c72		440f1033		MOVUPS 0(BX), X14										
  phase0_scaffold_test.go:38	0x804c76		440f1131		MOVUPS X14, 0(CX)										
  phase0_scaffold_test.go:38	0x804c7a		440f107310		MOVUPS 0x10(BX), X14										
  phase0_scaffold_test.go:38	0x804c7f		440f117110		MOVUPS X14, 0x10(CX)										
  phase0_scaffold_test.go:38	0x804c84		440f107320		MOVUPS 0x20(BX), X14										
  phase0_scaffold_test.go:38	0x804c89		440f117120		MOVUPS X14, 0x20(CX)										
  phase0_scaffold_test.go:38	0x804c8e		440f107330		MOVUPS 0x30(BX), X14										
  phase0_scaffold_test.go:38	0x804c93		440f117130		MOVUPS X14, 0x30(CX)										
  phase0_scaffold_test.go:38	0x804c98		440f107338		MOVUPS 0x38(BX), X14										
  phase0_scaffold_test.go:38	0x804c9d		440f117138		MOVUPS X14, 0x38(CX)										
  phase0_scaffold_test.go:38	0x804ca2		488d5c2448		LEAQ 0x48(SP), BX										
  phase0_scaffold_test.go:38	0x804ca7		488db42498010000	LEAQ 0x198(SP), SI										
  phase0_scaffold_test.go:38	0x804caf		440f1036		MOVUPS 0(SI), X14										
  phase0_scaffold_test.go:38	0x804cb3		440f1133		MOVUPS X14, 0(BX)										
  phase0_scaffold_test.go:38	0x804cb7		440f107610		MOVUPS 0x10(SI), X14										
  phase0_scaffold_test.go:38	0x804cbc		440f117310		MOVUPS X14, 0x10(BX)										
  phase0_scaffold_test.go:38	0x804cc1		440f107620		MOVUPS 0x20(SI), X14										
  phase0_scaffold_test.go:38	0x804cc6		440f117320		MOVUPS X14, 0x20(BX)										
  phase0_scaffold_test.go:38	0x804ccb		440f107630		MOVUPS 0x30(SI), X14										
  phase0_scaffold_test.go:38	0x804cd0		440f117330		MOVUPS X14, 0x30(BX)										
  phase0_scaffold_test.go:38	0x804cd5		440f107638		MOVUPS 0x38(SI), X14										
  phase0_scaffold_test.go:38	0x804cda		440f117338		MOVUPS X14, 0x38(BX)										
  phase0_scaffold_test.go:38	0x804cdf		488d05aa4f1100		LEAQ go:itab.*testing.B,testing.TB(SB), AX							
  phase0_scaffold_test.go:38	0x804ce6		488b9c2458020000	MOVQ 0x258(SP), BX										
  phase0_scaffold_test.go:38	0x804cee		4c89e7			MOVQ R12, DI											
  phase0_scaffold_test.go:38	0x804cf1		4c89ee			MOVQ R13, SI											
  phase0_scaffold_test.go:38	0x804cf4		4c8b842490010000	MOVQ 0x190(SP), R8										
  phase0_scaffold_test.go:38	0x804cfc		4c8b8c2408010000	MOVQ 0x108(SP), R9										
  phase0_scaffold_test.go:38	0x804d04		4c8b942410010000	MOVQ 0x110(SP), R10										
  phase0_scaffold_test.go:38	0x804d0c		4889d1			MOVQ DX, CX											
  phase0_scaffold_test.go:38	0x804d0f		e88cd4ffff		CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportAssert(SB)				
  phase0_scaffold_test.go:39	0x804d14		4889e1			MOVQ SP, CX											
  phase0_scaffold_test.go:39	0x804d17		488d942448010000	LEAQ 0x148(SP), DX										
  phase0_scaffold_test.go:39	0x804d1f		440f1032		MOVUPS 0(DX), X14										
  phase0_scaffold_test.go:39	0x804d23		440f1131		MOVUPS X14, 0(CX)										
  phase0_scaffold_test.go:39	0x804d27		440f107210		MOVUPS 0x10(DX), X14										
  phase0_scaffold_test.go:39	0x804d2c		440f117110		MOVUPS X14, 0x10(CX)										
  phase0_scaffold_test.go:39	0x804d31		440f107220		MOVUPS 0x20(DX), X14										
  phase0_scaffold_test.go:39	0x804d36		440f117120		MOVUPS X14, 0x20(CX)										
  phase0_scaffold_test.go:39	0x804d3b		440f107230		MOVUPS 0x30(DX), X14										
  phase0_scaffold_test.go:39	0x804d40		440f117130		MOVUPS X14, 0x30(CX)										
  phase0_scaffold_test.go:39	0x804d45		440f107238		MOVUPS 0x38(DX), X14										
  phase0_scaffold_test.go:39	0x804d4a		440f117138		MOVUPS X14, 0x38(CX)										
  phase0_scaffold_test.go:39	0x804d4f		488b842458020000	MOVQ 0x258(SP), AX										
  phase0_scaffold_test.go:39	0x804d57		488b9c2430010000	MOVQ 0x130(SP), BX										
  phase0_scaffold_test.go:39	0x804d5f		488bbc24d8000000	MOVQ 0xd8(SP), DI										
  phase0_scaffold_test.go:39	0x804d67		488bb424f0000000	MOVQ 0xf0(SP), SI										
  phase0_scaffold_test.go:39	0x804d6f		488b8c24e0000000	MOVQ 0xe0(SP), CX										
  phase0_scaffold_test.go:39	0x804d77		e8c4d7ffff		CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportMetrics(SB)				
  phase0_scaffold_test.go:40	0x804d7c		c68424d700000000	MOVB $0x0, 0xd7(SP)										
  phase0_scaffold_test.go:40	0x804d84		488b942440020000	MOVQ 0x240(SP), DX										
  phase0_scaffold_test.go:40	0x804d8c		488b0a			MOVQ 0(DX), CX											
  phase0_scaffold_test.go:40	0x804d8f		ffd1			CALL CX												
  phase0_scaffold_test.go:40	0x804d91		4881c448020000		ADDQ $0x248, SP											
  phase0_scaffold_test.go:40	0x804d98		5d			POPQ BP												
  phase0_scaffold_test.go:40	0x804d99		c3			RET												
  phase0_original_test.go:52	0x804d9a		e821bcc8ff		CALL runtime.panicBounds(SB)									
  phase0_original_test.go:52	0x804d9f		90			NOPL												
  phase0_original_test.go:52	0x804da0		e89b8dc4ff		CALL runtime.deferreturn(SB)									
  phase0_original_test.go:52	0x804da5		4881c448020000		ADDQ $0x248, SP											
  phase0_original_test.go:52	0x804dac		5d			POPQ BP												
  phase0_original_test.go:52	0x804dad		c3			RET												
  phase0_scaffold_test.go:13	0x804dae		4889442408		MOVQ AX, 0x8(SP)										
  phase0_scaffold_test.go:13	0x804db3		e8489ec8ff		CALL runtime.morestack.abi0(SB)									
  phase0_scaffold_test.go:13	0x804db8		488b442408		MOVQ 0x8(SP), AX										
  phase0_scaffold_test.go:13	0x804dbd		0f1f00			NOPL 0(AX)											
  phase0_scaffold_test.go:13	0x804dc0		e97bf9ffff		JMP dario.cat/cocoon/examples/datadog/go/dd.BenchmarkPhase0TransportScaffoldFixed.func1.1(SB)	

TEXT dario.cat/cocoon/examples/datadog/go/dd.BenchmarkPhase0TransportScaffoldAdaptive(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/phase0_scaffold_test.go
  phase0_scaffold_test.go:46	0x804de0		493b6610		CMPQ SP, 0x10(R14)											
  phase0_scaffold_test.go:46	0x804de4		0f86d0000000		JBE 0x804eba												
  phase0_scaffold_test.go:46	0x804dea		55			PUSHQ BP												
  phase0_scaffold_test.go:46	0x804deb		4889e5			MOVQ SP, BP												
  phase0_scaffold_test.go:46	0x804dee		4883ec60		SUBQ $0x60, SP												
  phase0_scaffold_test.go:47	0x804df2		4889442470		MOVQ AX, 0x70(SP)											
  phase0_scaffold_test.go:47	0x804df7		48c744244007000000	MOVQ $0x7, 0x40(SP)											
  phase0_scaffold_test.go:47	0x804e00		488d0d40850d00		LEAQ 0xd8540(IP), CX											
  phase0_scaffold_test.go:47	0x804e07		48894c2438		MOVQ CX, 0x38(SP)											
  phase0_scaffold_test.go:47	0x804e0c		48c744245006000000	MOVQ $0x6, 0x50(SP)											
  phase0_scaffold_test.go:47	0x804e15		488d0d207f0d00		LEAQ 0xd7f20(IP), CX											
  phase0_scaffold_test.go:47	0x804e1c		48894c2448		MOVQ CX, 0x48(SP)											
  phase0_scaffold_test.go:47	0x804e21		488d4c2438		LEAQ 0x38(SP), CX											
  phase0_scaffold_test.go:47	0x804e26		31d2			XORL DX, DX												
  phase0_scaffold_test.go:47	0x804e28		eb27			JMP 0x804e51												
  phase0_scaffold_test.go:48	0x804e2a		48895808		MOVQ BX, 0x8(AX)											
  phase0_scaffold_test.go:48	0x804e2e		4889c7			MOVQ AX, DI												
  phase0_scaffold_test.go:48	0x804e31		488b442470		MOVQ 0x70(SP), AX											
  phase0_scaffold_test.go:48	0x804e36		e8e597d0ff		CALL testing.(*B).Run(SB)										
  phase0_scaffold_test.go:47	0x804e3b		488b4c2458		MOVQ 0x58(SP), CX											
  phase0_scaffold_test.go:47	0x804e40		4883c110		ADDQ $0x10, CX												
  phase0_scaffold_test.go:47	0x804e44		488b542428		MOVQ 0x28(SP), DX											
  phase0_scaffold_test.go:47	0x804e49		48ffc2			INCQ DX													
  phase0_scaffold_test.go:48	0x804e4c		488b442470		MOVQ 0x70(SP), AX											
  phase0_scaffold_test.go:47	0x804e51		4883fa02		CMPQ DX, $0x2												
  phase0_scaffold_test.go:47	0x804e55		7d5d			JGE 0x804eb4												
  phase0_scaffold_test.go:47	0x804e57		4889542428		MOVQ DX, 0x28(SP)											
  phase0_scaffold_test.go:47	0x804e5c		48894c2458		MOVQ CX, 0x58(SP)											
  phase0_scaffold_test.go:47	0x804e61		488b5108		MOVQ 0x8(CX), DX											
  phase0_scaffold_test.go:47	0x804e65		4889542420		MOVQ DX, 0x20(SP)											
  phase0_scaffold_test.go:47	0x804e6a		488b09			MOVQ 0(CX), CX												
  phase0_scaffold_test.go:47	0x804e6d		48894c2430		MOVQ CX, 0x30(SP)											
  phase0_scaffold_test.go:48	0x804e72		488d0587990700		LEAQ 0x79987(IP), AX											
  phase0_scaffold_test.go:48	0x804e79		e8a2d3c1ff		CALL runtime.newobject(SB)										
  phase0_scaffold_test.go:48	0x804e7e		488d0d5b000000		LEAQ dario.cat/cocoon/examples/datadog/go/dd.BenchmarkPhase0TransportScaffoldAdaptive.func1(SB), CX	
  phase0_scaffold_test.go:48	0x804e85		488908			MOVQ CX, 0(AX)												
  phase0_scaffold_test.go:48	0x804e88		488b4c2420		MOVQ 0x20(SP), CX											
  phase0_scaffold_test.go:48	0x804e8d		48894810		MOVQ CX, 0x10(AX)											
  phase0_scaffold_test.go:48	0x804e91		833dd8b2500000		CMPL runtime.writeBarrier(SB), $0x0									
  phase0_scaffold_test.go:48	0x804e98		7508			JNE 0x804ea2												
  phase0_scaffold_test.go:48	0x804e9a		488b5c2430		MOVQ 0x30(SP), BX											
  phase0_scaffold_test.go:48	0x804e9f		90			NOPL													
  phase0_scaffold_test.go:48	0x804ea0		eb88			JMP 0x804e2a												
  phase0_scaffold_test.go:48	0x804ea2		e859b7c8ff		CALL runtime.gcWriteBarrier1(SB)									
  phase0_scaffold_test.go:48	0x804ea7		488b5c2430		MOVQ 0x30(SP), BX											
  phase0_scaffold_test.go:48	0x804eac		49891b			MOVQ BX, 0(R11)												
  phase0_scaffold_test.go:48	0x804eaf		e976ffffff		JMP 0x804e2a												
  phase0_scaffold_test.go:70	0x804eb4		4883c460		ADDQ $0x60, SP												
  phase0_scaffold_test.go:70	0x804eb8		5d			POPQ BP													
  phase0_scaffold_test.go:70	0x804eb9		c3			RET													
  phase0_scaffold_test.go:46	0x804eba		4889442408		MOVQ AX, 0x8(SP)											
  phase0_scaffold_test.go:46	0x804ebf		90			NOPL													
  phase0_scaffold_test.go:46	0x804ec0		e8db9dc8ff		CALL runtime.morestack_noctxt.abi0(SB)									
  phase0_scaffold_test.go:46	0x804ec5		488b442408		MOVQ 0x8(SP), AX											
  phase0_scaffold_test.go:46	0x804eca		e911ffffff		JMP dario.cat/cocoon/examples/datadog/go/dd.BenchmarkPhase0TransportScaffoldAdaptive(SB)		

TEXT dario.cat/cocoon/examples/datadog/go/dd.BenchmarkPhase0TransportScaffoldAdaptive.func1(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/phase0_scaffold_test.go
  phase0_scaffold_test.go:48	0x804ee0		4c8da42460ffffff		LEAQ 0xffffff60(SP), R12									
  phase0_scaffold_test.go:48	0x804ee8		4d3b6610			CMPQ R12, 0x10(R14)										
  phase0_scaffold_test.go:48	0x804eec		0f8620030000			JBE 0x805212											
  phase0_scaffold_test.go:48	0x804ef2		55				PUSHQ BP											
  phase0_scaffold_test.go:48	0x804ef3		4889e5				MOVQ SP, BP											
  phase0_scaffold_test.go:48	0x804ef6		4881ec18010000			SUBQ $0x118, SP											
  phase0_scaffold_test.go:48	0x804efd		66440fd6bc2410010000		MOVQ X15, 0x110(SP)										
  phase0_scaffold_test.go:48	0x804f07		c644247700			MOVB $0x0, 0x77(SP)										
  phase0_scaffold_test.go:48	0x804f0c		4889842428010000		MOVQ AX, 0x128(SP)										
  phase0_scaffold_test.go:48	0x804f14		488b4a08			MOVQ 0x8(DX), CX										
  phase0_scaffold_test.go:48	0x804f18		48898c24a0000000		MOVQ CX, 0xa0(SP)										
  phase0_scaffold_test.go:48	0x804f20		488b4a10			MOVQ 0x10(DX), CX										
  phase0_scaffold_test.go:48	0x804f24		48898c2490000000		MOVQ CX, 0x90(SP)										
  phase0_scaffold_test.go:49	0x804f2c		488b9c2428010000		MOVQ 0x128(SP), BX										
  phase0_scaffold_test.go:49	0x804f34		488d05554d1100			LEAQ go:itab.*testing.B,testing.TB(SB), AX							
  phase0_scaffold_test.go:49	0x804f3b		0f1f440000			NOPL 0(AX)(AX*1)										
  phase0_scaffold_test.go:49	0x804f40		e85bd4ffff			CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportProcessors(SB)			
  phase0_scaffold_test.go:49	0x804f45		4889842410010000		MOVQ AX, 0x110(SP)										
  phase0_scaffold_test.go:49	0x804f4d		c644247701			MOVB $0x1, 0x77(SP)										
  phase0_scaffold_test.go:50	0x804f52		488b9c2428010000		MOVQ 0x128(SP), BX										
  phase0_scaffold_test.go:50	0x804f5a		488d052f4d1100			LEAQ go:itab.*testing.B,testing.TB(SB), AX							
  phase0_scaffold_test.go:50	0x804f61		e81ac4ffff			CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportSketch(SB)				
  phase0_scaffold_test.go:50	0x804f66		4889842498000000		MOVQ AX, 0x98(SP)										
  phase0_scaffold_test.go:51	0x804f6e		488b4808			MOVQ 0x8(AX), CX										
  phase0_scaffold_test.go:51	0x804f72		488b09				MOVQ 0(CX), CX											
  zz_adapter.go:11		0x804f75		488b09				MOVQ 0(CX), CX											
  module.go:62926		0x804f78		8401				TESTB AL, 0(CX)											
  module.go:62926		0x804f7a		4883c130			ADDQ $0x30, CX											
  zz_adapter.go:11		0x804f7e		488b4908			MOVQ 0x8(CX), CX										
  zz_adapter.go:11		0x804f82		48898c2480000000		MOVQ CX, 0x80(SP)										
  phase0_scaffold_test.go:48	0x804f8a		488b942490000000		MOVQ 0x90(SP), DX										
  phase0_scaffold_test.go:48	0x804f92		4883fa06			CMPQ DX, $0x6											
  phase0_scaffold_test.go:52	0x804f96		751b				JNE 0x804fb3											
  phase0_scaffold_test.go:52	0x804f98		488b9424a0000000		MOVQ 0xa0(SP), DX										
  phase0_scaffold_test.go:52	0x804fa0		813a4f726163			CMPL 0(DX), $0x6361724f										
  phase0_scaffold_test.go:52	0x804fa6		750b				JNE 0x804fb3											
  phase0_scaffold_test.go:52	0x804fa8		66817a046c65			CMPW 0x4(DX), $0x656c										
  phase0_scaffold_test.go:52	0x804fae		0f94c2				SETE DL												
  phase0_scaffold_test.go:52	0x804fb1		eb02				JMP 0x804fb5											
  phase0_scaffold_test.go:52	0x804fb3		31d2				XORL DX, DX											
  phase0_scaffold_test.go:52	0x804fb5		8815b2ab5000			MOVB DL, dario.cat/cocoon/examples/datadog/go/dd.phase0TransportMode(SB)			
  phase0_scaffold_test.go:53	0x804fbb		48c784248800000000000000	MOVQ $0x0, 0x88(SP)										
  phase0_scaffold_test.go:54	0x804fc7		488b8c2428010000		MOVQ 0x128(SP), CX										
  benchmark.go:193		0x804fcf		c6815202000001			MOVB $0x1, 0x252(CX)										
  phase0_scaffold_test.go:55	0x804fd6		488b9c2428010000		MOVQ 0x128(SP), BX										
  phase0_scaffold_test.go:55	0x804fde		488d05ab4c1100			LEAQ go:itab.*testing.B,testing.TB(SB), AX							
  phase0_scaffold_test.go:55	0x804fe5		e876d4ffff			CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportActual(SB)				
  phase0_scaffold_test.go:56	0x804fea		488b842428010000		MOVQ 0x128(SP), AX										
  phase0_scaffold_test.go:56	0x804ff2		e82967d0ff			CALL testing.(*B).ResetTimer(SB)								
  phase0_scaffold_test.go:57	0x804ff7		488b842428010000		MOVQ 0x128(SP), AX										
  benchmark.go:515		0x804fff		488b88c0020000			MOVQ 0x2c0(AX), CX										
  benchmark.go:515		0x805006		483988b8020000			CMPQ 0x2b8(AX), CX										
  benchmark.go:515		0x80500d		7613				JBE 0x805022											
  benchmark.go:516		0x80500f		48ffc1				INCQ CX												
  benchmark.go:516		0x805012		488988c0020000			MOVQ CX, 0x2c0(AX)										
  benchmark.go:516		0x805019		b801000000			MOVL $0x1, AX											
  benchmark.go:516		0x80501e		6690				NOPW												
  phase0_scaffold_test.go:57	0x805020		eb05				JMP 0x805027											
  benchmark.go:519		0x805022		e89977d0ff			CALL testing.(*B).loopSlowPath(SB)								
  phase0_scaffold_test.go:57	0x805027		84c0				TESTL AL, AL											
  phase0_scaffold_test.go:57	0x805029		0f84b0000000			JE 0x8050df											
  phase0_scaffold_test.go:58	0x80502f		f20f108c2488000000		MOVSD_XMM 0x88(SP), X1										
  phase0_scaffold_test.go:58	0x805038		f20f1015585a1000		MOVSD_XMM $f64.3ff0000000000000(SB), X2								
  phase0_scaffold_test.go:58	0x805040		f20f58ca			ADDSD X2, X1											
  phase0_scaffold_test.go:58	0x805044		f20f118c2488000000		MOVSD_XMM X1, 0x88(SP)										
  phase0_scaffold_test.go:59	0x80504d		0fb61d19ab5000			MOVZX dario.cat/cocoon/examples/datadog/go/dd.phase0TransportMode(SB), BX			
  phase0_scaffold_test.go:59	0x805054		f20f10842488000000		MOVSD_XMM 0x88(SP), X0										
  phase0_scaffold_test.go:59	0x80505d		488b842498000000		MOVQ 0x98(SP), AX										
  phase0_scaffold_test.go:59	0x805065		e8f6bdfdff			CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportAdd(SB)				
  phase0_scaffold_test.go:59	0x80506a		48898424a8000000		MOVQ AX, 0xa8(SP)										
  phase0_scaffold_test.go:59	0x805072		48899c24b0000000		MOVQ BX, 0xb0(SP)										
  phase0_scaffold_test.go:59	0x80507a		660f1f440000			NOPW 0(AX)(AX*1)										
  phase0_scaffold_test.go:59	0x805080		4885c0				TESTQ AX, AX											
  phase0_scaffold_test.go:59	0x805083		0f846effffff			JE 0x804ff7											
  phase0_scaffold_test.go:60	0x805089		440f11bc2400010000		MOVUPS X15, 0x100(SP)										
  phase0_scaffold_test.go:60	0x805092		488b9424a8000000		MOVQ 0xa8(SP), DX										
  phase0_scaffold_test.go:60	0x80509a		4885d2				TESTQ DX, DX											
  phase0_scaffold_test.go:60	0x80509d		7404				JE 0x8050a3											
  phase0_scaffold_test.go:60	0x80509f		488b5208			MOVQ 0x8(DX), DX										
  phase0_scaffold_test.go:60	0x8050a3		488bb424b0000000		MOVQ 0xb0(SP), SI										
  phase0_scaffold_test.go:60	0x8050ab		4889942400010000		MOVQ DX, 0x100(SP)										
  phase0_scaffold_test.go:60	0x8050b3		4889b42408010000		MOVQ SI, 0x108(SP)										
  phase0_scaffold_test.go:60	0x8050bb		488b842428010000		MOVQ 0x128(SP), AX										
  phase0_scaffold_test.go:60	0x8050c3		8400				TESTB AL, 0(AX)											
  phase0_scaffold_test.go:60	0x8050c5		488d9c2400010000		LEAQ 0x100(SP), BX										
  phase0_scaffold_test.go:60	0x8050cd		b901000000			MOVL $0x1, CX											
  phase0_scaffold_test.go:60	0x8050d2		4889cf				MOVQ CX, DI											
  phase0_scaffold_test.go:60	0x8050d5		e8e64ed1ff			CALL testing.(*common).Fatal(SB)								
  phase0_scaffold_test.go:60	0x8050da		e918ffffff			JMP 0x804ff7											
  phase0_scaffold_test.go:63	0x8050df		488b842428010000		MOVQ 0x128(SP), AX										
  phase0_scaffold_test.go:63	0x8050e7		e87465d0ff			CALL testing.(*B).StopTimer(SB)									
  phase0_scaffold_test.go:64	0x8050ec		488b9c2428010000		MOVQ 0x128(SP), BX										
  phase0_scaffold_test.go:64	0x8050f4		488d05954b1100			LEAQ go:itab.*testing.B,testing.TB(SB), AX							
  phase0_scaffold_test.go:64	0x8050fb		0f1f440000			NOPL 0(AX)(AX*1)										
  phase0_scaffold_test.go:64	0x805100		e85bd3ffff			CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportActual(SB)				
  phase0_scaffold_test.go:65	0x805105		488b9c2498000000		MOVQ 0x98(SP), BX										
  phase0_scaffold_test.go:65	0x80510d		488b4b08			MOVQ 0x8(BX), CX										
  phase0_scaffold_test.go:65	0x805111		488b09				MOVQ 0(CX), CX											
  phase0_scaffold_test.go:66	0x805114		488b842428010000		MOVQ 0x128(SP), AX										
  phase0_scaffold_test.go:66	0x80511c		488b9010020000			MOVQ 0x210(AX), DX										
  zz_adapter.go:11		0x805123		488b09				MOVQ 0(CX), CX											
  module.go:62926		0x805126		8401				TESTB AL, 0(CX)											
  module.go:62926		0x805128		4883c130			ADDQ $0x30, CX											
  zz_adapter.go:11		0x80512c		488b4908			MOVQ 0x8(CX), CX										
  zz_adapter.go:11		0x805130		48894c2478			MOVQ CX, 0x78(SP)										
  phase0_scaffold_test.go:66	0x805135		4889d1				MOVQ DX, CX											
  phase0_scaffold_test.go:66	0x805138		e8e3e5ffff			CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportAdaptiveWitness(SB)			
  phase0_scaffold_test.go:66	0x80513d		48898424b8000000		MOVQ AX, 0xb8(SP)										
  phase0_scaffold_test.go:66	0x805145		48899c24c0000000		MOVQ BX, 0xc0(SP)										
  phase0_scaffold_test.go:66	0x80514d		48898c24c8000000		MOVQ CX, 0xc8(SP)										
  phase0_scaffold_test.go:66	0x805155		4889bc24d0000000		MOVQ DI, 0xd0(SP)										
  phase0_scaffold_test.go:66	0x80515d		4889b424d8000000		MOVQ SI, 0xd8(SP)										
  phase0_scaffold_test.go:66	0x805165		4c898424e0000000		MOVQ R8, 0xe0(SP)										
  phase0_scaffold_test.go:66	0x80516d		4c898c24e8000000		MOVQ R9, 0xe8(SP)										
  phase0_scaffold_test.go:66	0x805175		4c899424f0000000		MOVQ R10, 0xf0(SP)										
  phase0_scaffold_test.go:66	0x80517d		4c899c24f8000000		MOVQ R11, 0xf8(SP)										
  phase0_scaffold_test.go:67	0x805185		488b842428010000		MOVQ 0x128(SP), AX										
  phase0_scaffold_test.go:67	0x80518d		488bb010020000			MOVQ 0x210(AX), SI										
  phase0_scaffold_test.go:67	0x805194		4889e1				MOVQ SP, CX											
  phase0_scaffold_test.go:67	0x805197		488d9424b8000000		LEAQ 0xb8(SP), DX										
  phase0_scaffold_test.go:67	0x80519f		440f1032			MOVUPS 0(DX), X14										
  phase0_scaffold_test.go:67	0x8051a3		440f1131			MOVUPS X14, 0(CX)										
  phase0_scaffold_test.go:67	0x8051a7		440f107210			MOVUPS 0x10(DX), X14										
  phase0_scaffold_test.go:67	0x8051ac		440f117110			MOVUPS X14, 0x10(CX)										
  phase0_scaffold_test.go:67	0x8051b1		440f107220			MOVUPS 0x20(DX), X14										
  phase0_scaffold_test.go:67	0x8051b6		440f117120			MOVUPS X14, 0x20(CX)										
  phase0_scaffold_test.go:67	0x8051bb		440f107230			MOVUPS 0x30(DX), X14										
  phase0_scaffold_test.go:67	0x8051c0		440f117130			MOVUPS X14, 0x30(CX)										
  phase0_scaffold_test.go:67	0x8051c5		440f107238			MOVUPS 0x38(DX), X14										
  phase0_scaffold_test.go:67	0x8051ca		440f117138			MOVUPS X14, 0x38(CX)										
  phase0_scaffold_test.go:67	0x8051cf		488b9c2498000000		MOVQ 0x98(SP), BX										
  phase0_scaffold_test.go:67	0x8051d7		488b7c2478			MOVQ 0x78(SP), DI										
  phase0_scaffold_test.go:67	0x8051dc		488b8c2480000000		MOVQ 0x80(SP), CX										
  phase0_scaffold_test.go:67	0x8051e4		e857d3ffff			CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportMetrics(SB)				
  phase0_scaffold_test.go:68	0x8051e9		c644247700			MOVB $0x0, 0x77(SP)										
  phase0_scaffold_test.go:68	0x8051ee		488b942410010000		MOVQ 0x110(SP), DX										
  phase0_scaffold_test.go:68	0x8051f6		488b0a				MOVQ 0(DX), CX											
  phase0_scaffold_test.go:68	0x8051f9		ffd1				CALL CX												
  phase0_scaffold_test.go:68	0x8051fb		4881c418010000			ADDQ $0x118, SP											
  phase0_scaffold_test.go:68	0x805202		5d				POPQ BP												
  phase0_scaffold_test.go:68	0x805203		c3				RET												
  phase0_scaffold_test.go:68	0x805204		e83789c4ff			CALL runtime.deferreturn(SB)									
  phase0_scaffold_test.go:68	0x805209		4881c418010000			ADDQ $0x118, SP											
  phase0_scaffold_test.go:68	0x805210		5d				POPQ BP												
  phase0_scaffold_test.go:68	0x805211		c3				RET												
  phase0_scaffold_test.go:48	0x805212		4889442408			MOVQ AX, 0x8(SP)										
  phase0_scaffold_test.go:48	0x805217		e8e499c8ff			CALL runtime.morestack.abi0(SB)									
  phase0_scaffold_test.go:48	0x80521c		488b442408			MOVQ 0x8(SP), AX										
  phase0_scaffold_test.go:48	0x805221		e9bafcffff			JMP dario.cat/cocoon/examples/datadog/go/dd.BenchmarkPhase0TransportScaffoldAdaptive.func1(SB)	
