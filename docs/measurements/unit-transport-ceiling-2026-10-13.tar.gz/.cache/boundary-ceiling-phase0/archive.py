"""Retain exact bounded-diagnostic evidence, excluding executables/build caches."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'.cache/boundary-ceiling-phase0'
TARGET=ROOT/'docs/measurements/unit-transport-ceiling-2026-10-13.tar.gz'
extensions={'.go','.mod','.sum','.json','.jsonl','.txt','.md','.log','.py','.sh','.warnings','.asm','.bin','.pb','.wasm'}
files={};omitted={'reference-module.go'}
for p in sorted(OUT.rglob('*')):
 if not p.is_file() or any(part in {'reference-rust','__pycache__','gocache','retention'} for part in p.relative_to(OUT).parts) or p.name in omitted:continue
 if p.suffix not in extensions and p.name not in {'staged-tree','staged-tree-initial','staged-tree-final','staged-snapshot'}:continue
 files[str(p.relative_to(ROOT))]=p.read_bytes()
reference=json.loads((OUT/'reference-source-before.json').read_text());assert reference==json.loads((OUT/'reference-source-after.json').read_text())
spike=Path(reference['spike'])
for name,digest in reference['source_sha256'].items():
 assert not Path(name).is_absolute() and '..' not in Path(name).parts
 data=(spike/name).read_bytes();assert hashlib.sha256(data).hexdigest()==digest
 files['.cache/boundary-ceiling-phase0/reference-source/'+name]=data
for name in ['.cache/reference.mod','.cache/reference.sum']:files[name]=(ROOT/name).read_bytes()
files['.cache/boundary-ceiling-phase0/spec/preregistered.md']=(ROOT/'docs/unit-transport-ceiling.md').read_bytes()
rows=[json.loads(line) for line in (OUT/'records.jsonl').read_text().splitlines()];assert len(rows)==json.loads((OUT/'complete.json').read_text())['rows']==980
for row in rows:
 data=(OUT/row['raw']).read_text();assert row['raw_row'] in data and '\nEXIT 0\n' in data
assert json.loads((OUT/'decision.json').read_text())['status']=='NO-GO'
manifest={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(files.items())}
stream=io.BytesIO()
with tarfile.open(fileobj=stream,mode='w') as archive:
 for name,data in [('MANIFEST.json',(json.dumps(manifest,indent=2)+'\n').encode()),*sorted(files.items())]:
  assert not Path(name).is_absolute() and '..' not in Path(name).parts
  member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644;member.mtime=0
  archive.addfile(member,io.BytesIO(data))
packed=gzip.compress(stream.getvalue(),mtime=0)
with tarfile.open(fileobj=io.BytesIO(packed),mode='r:gz') as archive:
 members=archive.getmembers();assert len(members)==len(manifest)+1 and len({m.name for m in members})==len(members)
 assert {m.name for m in members}==set(manifest)|{'MANIFEST.json'} and json.loads(archive.extractfile('MANIFEST.json').read())==manifest
 for member in members:
  assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
  if member.name=='MANIFEST.json':continue
  data=archive.extractfile(member).read();assert len(data)==manifest[member.name]['bytes'] and hashlib.sha256(data).hexdigest()==manifest[member.name]['sha256']
assert not TARGET.exists()
with TARGET.open('xb') as archive:archive.write(packed)
digest=hashlib.sha256(packed).hexdigest();TARGET.with_name(TARGET.name+'.sha256').write_text(digest+'  '+TARGET.name+'\n')
inventory={'payload_files':len(files),'members_including_manifest':len(files)+1,'compressed_bytes':len(packed),'compressed_sha256':digest,'raw_rows':980,'statistical_pairs':90,'frozen_identities':481,'native_architectures':['amd64','386'],'production_files_unchanged':61}
(OUT/'archive-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
readable=ROOT/'docs/measurements/unit-transport-ceiling-2026-10-13.md';assert not readable.exists()
footer='\n## Exact-byte archive\n\nThe gzip/tar preserves cause/generated overlays, every sample/metric/process log,\nall comparisons/aliases, source/conditions/proof/mutant/review records and quality\nlogs without whitespace normalization. Executables, Rust build caches and the\nunchanged reference generated module are omitted but identified by hashes and\nexact build commands. Selected unversioned reference authored inputs are included.\nThe adversarial independent result audit was received before final-file model\ncapacity errors; the root-authored received-review record states that distinction.\nSpec staged validation is included; final retention validation is performed on\nthe exact staged tree after constructing this archive, avoiding recursive hashes.\n\n'
footer+='```json\n'+json.dumps(inventory,indent=2)+'\n```\n\nAudit without executing/extracting: verify the compressed SHA256, read gzip/tar\nin memory, require unique relative regular-file members, and verify every\nMANIFEST.json byte length/SHA256. Reproduce source/artifacts from the signed\nspec checkpoint and archived sources/build commands.\n'
readable.write_text((OUT/'report-body.md').read_text()+footer)
print(json.dumps(inventory,indent=2))
