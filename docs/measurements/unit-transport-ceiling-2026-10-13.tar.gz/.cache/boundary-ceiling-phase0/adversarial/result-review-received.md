# Adversarial result review received by root

This is a root-authored record of the adversarial review message received after
its completed independent audit. The agent's subsequent final-file generation
hit model capacity twice; this file is not represented as agent-authored and
no rerun or new measurement follows. Its earlier entry/spec/applied notes remain.

The reviewer independently reconciled all 980 raw rows, custom metrics, P1/P16
counts and 140 cells, all 90 benchstat comparisons/aliases and all 481 frozen
hashes. Four contextual reference pairs were excluded from guards in the
frozen plan before data. It confirmed the exact no-go: adaptive oracle gains
3.1487%/3.7912% versus bare, 2.1513%/3.0825% versus original and 6.2699%/6.9727%
versus scaffold (all p=.001), with every primary gain below 10%. Fixed screening
is undetected/noisy and confirmation also below 10%. Repeated original, varied
and holdout SQL losses reject independently. It explicitly requested retention
of BroadTrace +1.8171% screening (p=.002) and +27.2158% confirmation (p=.902),
Fixed P1 +0.6560% screening (p=.026) and Fixed P16 one-home +5.7003%
confirmation (p=.535), with no nondetection/equivalence claim. Root verified
these requests against summary and retains all values in durable docs.

No production/public contract or M1 acceptance is supported. Root independently
applies the frozen predicate in decision.json and retains all raw samples,
precision negatives and reference/streaming limitations. Guest and host result
reviews completed and wrote their own notes; all tool work stopped before timing.
