package rt

import (
	"encoding/binary"
	"errors"
	"fmt"
	"math"
	"os"
	"reflect"
	"runtime"
	"sync/atomic"
	"testing"
	"time"
)

// The oracle is wire/query behavior, not a second implementation of the
// unsupported success shortcut. Native backing always remains safely readable.
type phase0ProofModule struct {
	memory      []byte
	views       [][]byte
	events      []string
	queries     int
	panicAt     int
	output      uint32
	outputCalls int
}

func (m *phase0ProofModule) Memory() []byte {
	m.queries++
	m.events = append(m.events, fmt.Sprintf("memory:%d", m.queries))
	if m.queries == m.panicAt {
		panic("phase0 observable memory panic")
	}
	if len(m.views) != 0 {
		index := min(m.queries-1, len(m.views)-1)
		return m.views[index]
	}
	return m.memory
}

func (*phase0ProofModule) Version() uint32       { return ABIVersion }
func (*phase0ProofModule) Schema() uint64        { return 7 }
func (*phase0ProofModule) Init()                 {}
func (*phase0ProofModule) Reserve(uint32) uint32 { return 24 }
func (m *phase0ProofModule) Output() uint32 {
	m.outputCalls++
	return m.output
}
func (*phase0ProofModule) Trim(uint32) {}

func phase0ProofInstance(t *testing.T, output uint32) (*Instance, *phase0ProofModule, *Host) {
	t.Helper()
	m := &phase0ProofModule{memory: make([]byte, 64, 256), output: output}
	host := NewHost(nil)
	i, err := NewInstance(m, 7, Limits{MaxInput: 64, MaxOutput: 32, MaxMemory: 128}, host)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(i.Close)
	m.reset()
	return i, m, host
}

func (m *phase0ProofModule) reset(views ...[]byte) {
	m.views, m.events, m.queries, m.panicAt = views, nil, 0, 0
}

func phase0ProofReply(memory []byte, output, pointer, size uint32) {
	binary.LittleEndian.PutUint32(memory[output:], pointer)
	binary.LittleEndian.PutUint32(memory[output+4:], size)
}

type phase0ProofRole struct {
	name string
	skip bool
	base bool
}

var phase0ProofRoles = []phase0ProofRole{
	{name: "original", base: true},
	{name: "checked"},
	{name: "oracle", skip: true},
}

func (r phase0ProofRole) reply(c *Call, status Status) error {
	if r.base {
		view, err := c.ResultView("probe", status)
		if err != nil {
			return err
		}
		if len(view) != 0 {
			return ErrProtocol
		}
		return nil
	}
	return c.Phase0UnitReply("probe", status, r.skip)
}

func phase0ProofQueries(t *testing.T, m *phase0ProofModule, count int) {
	t.Helper()
	want := make([]string, count)
	for index := range want {
		want[index] = fmt.Sprintf("memory:%d", index+1)
	}
	if m.queries != count || !reflect.DeepEqual(m.events, want) {
		t.Fatalf("observable memory queries=%d events=%v want=%v", m.queries, m.events, want)
	}
}

func phase0ProofFaultState(t *testing.T, i *Instance, epoch uint64, poison bool) {
	t.Helper()
	if i.Healthy() == poison || (i.Epoch() != epoch) != poison {
		t.Fatalf("healthy=%t epoch=%d initial=%d poison=%t", i.Healthy(), i.Epoch(), epoch, poison)
	}
	if poison {
		if i.Epoch() != epoch+1 {
			t.Fatalf("poison epoch changed more than once: %d -> %d", epoch, i.Epoch())
		}
		if err := i.Call("next", func(*Call) error {
			t.Fatal("callback entered after immediate poison")
			return nil
		}); !errors.Is(err, ErrPoisoned) {
			t.Fatalf("next call=%v, want poisoned", err)
		}
	}
}

func TestPhase0HostWireAndQueryContract(t *testing.T) {
	for _, test := range []struct {
		name          string
		pointer, size uint32
		status        Status
		short         bool
		want          error
		poison        bool
	}{
		{name: "empty-zero", status: OK},
		{name: "empty-end", pointer: 64, status: OK},
		{name: "nonempty-ok", pointer: 16, size: 1, status: OK, want: ErrProtocol, poison: true},
		{name: "zero-spare", pointer: 65, status: OK, want: ErrProtocol, poison: true},
		{name: "zero-max", pointer: math.MaxUint32, status: OK, want: ErrProtocol, poison: true},
		{name: "widened-end", pointer: math.MaxUint32, size: 2, status: OK, want: ErrProtocol, poison: true},
		{name: "short-payload", pointer: 63, size: 2, status: OK, want: ErrProtocol, poison: true},
		{name: "truncated-descriptor", short: true, status: OK, want: ErrProtocol, poison: true},
		{name: "ok-output-limit", pointer: 16, size: 33, status: OK, want: ErrTooLarge},
		{name: "limit-before-pointer", pointer: math.MaxUint32, size: 33, status: OK, want: ErrTooLarge},
		{name: "limit-before-arg", pointer: math.MaxUint32, size: 33, status: ErrArg, want: ErrTooLarge},
		{name: "limit-before-pending", pointer: math.MaxUint32, size: 33, status: Pending, want: ErrTooLarge},
		{name: "range-before-pending", pointer: 65, status: Pending, want: ErrProtocol, poison: true},
		{name: "range-before-arg", pointer: 63, size: 2, status: ErrArg, want: ErrProtocol, poison: true},
		{name: "nonok-short-descriptor", short: true, status: ErrArg, want: ErrProtocol, poison: true},
		{name: "pending", pointer: 16, status: Pending, want: ErrProtocol, poison: true},
		{name: "unknown-positive", pointer: 16, status: Status(17), want: ErrProtocol, poison: true},
		{name: "unknown-negative", pointer: 16, status: Status(-7), want: ErrProtocol, poison: true},
	} {
		for _, role := range phase0ProofRoles {
			t.Run(test.name+"/"+role.name, func(t *testing.T) {
				i, m, _ := phase0ProofInstance(t, 0)
				epoch := i.Epoch()
				phase0ProofReply(m.memory, 0, test.pointer, test.size)
				if test.short {
					m.reset(m.memory[:4], m.memory)
				}
				want, poison := test.want, test.poison
				if role.skip && test.status == OK {
					want, poison = nil, false // Deliberate unsupported ABI3 divergence.
				}
				err := i.Call("probe", func(c *Call) error { return role.reply(c, test.status) })
				if !errors.Is(err, want) {
					t.Fatalf("result=%v want=%v", err, want)
				}
				if want == ErrProtocol && (test.name == "range-before-pending" || test.name == "range-before-arg") {
					end := uint64(test.pointer) + uint64(test.size)
					message := fmt.Sprintf("%s: memory range [%d,%d) exceeds 64", ErrProtocol, test.pointer, end)
					if err.Error() != message {
						t.Fatalf("range precedence=%q want=%q", err.Error(), message)
					}
				}
				phase0ProofQueries(t, m, 2)
				phase0ProofFaultState(t, i, epoch, poison)
			})
		}
	}
}

func TestPhase0HostOwnedOpaqueErrorAndReuse(t *testing.T) {
	const message = "\xffbad\x00☃"
	for _, role := range phase0ProofRoles {
		for _, status := range []Status{ErrApp, ErrArg, ErrHandle, ErrLimit} {
			t.Run(fmt.Sprintf("%s/%d", role.name, status), func(t *testing.T) {
				i, m, _ := phase0ProofInstance(t, 8)
				epoch := i.Epoch()
				copy(m.memory[24:], message)
				phase0ProofReply(m.memory, 8, 24, uint32(len(message)))
				err := i.Call("probe", func(c *Call) error { return role.reply(c, status) })
				if err == nil || !i.Healthy() || i.Epoch() != epoch {
					t.Fatalf("expected error=%v healthy=%t epoch=%d", err, i.Healthy(), i.Epoch())
				}
				phase0ProofQueries(t, m, 2)
				before := err.Error()
				clear(m.memory[24:])
				if err.Error() != before {
					t.Fatal("error retained guest backing bytes")
				}
				switch status {
				case ErrApp, ErrArg:
					var app *AppError
					if !errors.As(err, &app) || app.Op != "probe" || app.Status != status || app.Message != message {
						t.Fatalf("opaque application error=%#v", err)
					}
				case ErrHandle:
					var handle *HandleError
					if !errors.As(err, &handle) || handle.Op != "probe" || handle.Reason != message {
						t.Fatalf("opaque handle error=%#v", err)
					}
				case ErrLimit:
					if !errors.Is(err, ErrTooLarge) || err.Error() != "probe: "+ErrTooLarge.Error()+": "+message {
						t.Fatalf("opaque limit error=%#v", err)
					}
				}
				// Fresh current backing, different descriptor contents, same cached
				// descriptor address; no stale borrowed view or output-export query.
				m.memory = make([]byte, 128)
				phase0ProofReply(m.memory, 8, 128, 0)
				m.reset()
				if err := i.Call("probe", func(c *Call) error { return role.reply(c, OK) }); err != nil {
					t.Fatal("healthy reuse failed", err)
				}
				phase0ProofQueries(t, m, 2)
				if m.outputCalls != 1 {
					t.Fatalf("descriptor export repeated %d times", m.outputCalls)
				}
			})
		}
	}
}

func TestPhase0HostAlternatingMemoryAndPostPriority(t *testing.T) {
	for _, role := range phase0ProofRoles {
		for _, status := range []Status{OK, ErrArg, Pending} {
			t.Run(fmt.Sprintf("%s/%d", role.name, status), func(t *testing.T) {
				i, m, _ := phase0ProofInstance(t, 0)
				epoch := i.Epoch()
				phase0ProofReply(m.memory, 0, 24, 0)
				// Only the reply query supplies a readable descriptor. The post
				// query is independent and must not be used for validation again.
				m.reset(m.memory, nil)
				err := i.Call("probe", func(c *Call) error { return role.reply(c, status) })
				if status == OK && err != nil {
					t.Fatal("post query replaced captured reply", err)
				}
				if status == ErrArg {
					var app *AppError
					if !errors.As(err, &app) || app.Status != ErrArg || app.Message != "" {
						t.Fatalf("nonOK query/order drift=%#v", err)
					}
				}
				if status == Pending && !errors.Is(err, ErrProtocol) {
					t.Fatal("pending accepted", err)
				}
				phase0ProofQueries(t, m, 2)
				phase0ProofFaultState(t, i, epoch, status == Pending)
			})
		}
		for _, status := range []Status{OK, ErrArg, Pending} {
			t.Run(fmt.Sprintf("post-limit/%s/%d", role.name, status), func(t *testing.T) {
				i, m, _ := phase0ProofInstance(t, 0)
				epoch := i.Epoch()
				phase0ProofReply(m.memory, 0, 24, 0)
				m.reset(m.memory, make([]byte, 129))
				err := i.Call("probe", func(c *Call) error { return role.reply(c, status) })
				if !errors.Is(err, ErrTooLarge) || err.Error() != "probe: "+ErrTooLarge.Error()+": linear memory exceeded maximum" {
					t.Fatalf("post MaxMemory precedence=%v", err)
				}
				phase0ProofQueries(t, m, 2)
				phase0ProofFaultState(t, i, epoch, true)
			})
		}
	}
}

func TestPhase0HostStaleOutputCanary(t *testing.T) {
	for _, previousStatus := range []Status{OK, ErrArg} {
		t.Run(fmt.Sprintf("previous-status=%d", previousStatus), func(t *testing.T) {
			i, m, _ := phase0ProofInstance(t, 0)
			epoch := i.Epoch()
			copy(m.memory[24:], "old output")
			phase0ProofReply(m.memory, 0, 24, 10)
			// Ordinary non-unit output or an expected error can remain in the
			// buffer. This deliberate transport model does not clear it.
			err := i.Call("previous", func(c *Call) error {
				view, err := c.ResultView("previous", previousStatus)
				if previousStatus == OK && (err != nil || string(view) != "old output") {
					t.Fatalf("previous data result=%q error=%v", view, err)
				}
				return err
			})
			if previousStatus == ErrArg {
				var app *AppError
				if !errors.As(err, &app) || app.Message != "old output" || !i.Healthy() {
					t.Fatalf("previous expected error=%#v", err)
				}
			} else if err != nil {
				t.Fatal(err)
			}
			before := append([]byte(nil), m.memory...)
			m.reset()
			if err := i.Call("probe", func(c *Call) error { return c.Phase0UnitReply("probe", OK, true) }); err != nil {
				t.Fatal("unsupported successful unit rejected stale data", err)
			}
			phase0ProofQueries(t, m, 2)
			phase0ProofFaultState(t, i, epoch, false)
			if !reflect.DeepEqual(before, m.memory) {
				t.Fatal("host oracle changed guest backing or output metadata")
			}
			m.reset()
			if err := i.Call("probe", func(c *Call) error { return c.Phase0UnitReply("probe", OK, false) }); !errors.Is(err, ErrProtocol) {
				t.Fatalf("checked ABI3 accepted same stale unit metadata: %v", err)
			}
			phase0ProofQueries(t, m, 2)
			phase0ProofFaultState(t, i, epoch, true)
		})
	}

	// Enabled success must still query even when no descriptor byte exists.
	i, m, _ := phase0ProofInstance(t, 0)
	m.reset(nil, m.memory)
	if err := i.Call("probe", func(c *Call) error { return c.Phase0UnitReply("probe", OK, true) }); err != nil {
		t.Fatal(err)
	}
	phase0ProofQueries(t, m, 2)
}

func TestPhase0HostQueryPanicsAndStaleResources(t *testing.T) {
	for _, role := range phase0ProofRoles {
		for _, at := range []int{1, 2} {
			t.Run(fmt.Sprintf("%s/query%d", role.name, at), func(t *testing.T) {
				i, m, _ := phase0ProofInstance(t, 0)
				epoch := i.Epoch()
				m.panicAt = at
				r, err := NewResource[int](i, uint64(0xdeadbeef)<<32|uint64(9), func(uint64) error { return nil })
				if err != nil {
					t.Fatal(err)
				}
				t.Cleanup(func() { _ = r.Close() })
				err = i.Call("probe", func(c *Call) error { return role.reply(c, OK) })
				var fault *FaultError
				if !errors.As(err, &fault) || fault.Kind != FaultUnknown || fault.Detail != "phase0 observable memory panic" {
					t.Fatalf("memory panic=%#v", err)
				}
				phase0ProofQueries(t, m, at)
				phase0ProofFaultState(t, i, epoch, true)
				var handle *HandleError
				if err := r.Use("stale", func(*Instance, uint64) error {
					t.Fatal("stale resource callback entered")
					return nil
				}); !errors.As(err, &handle) {
					t.Fatalf("stale resource=%v", err)
				}
			})
		}
	}
}

func TestPhase0HostCallAndPanicMetadataReset(t *testing.T) {
	i, m, host := phase0ProofInstance(t, 0)
	if err := i.Call("prepare", func(c *Call) error {
		if err := c.PrepareInput(3); err != nil {
			return err
		}
		_, err := c.PutString("abc")
		return err
	}); err != nil {
		t.Fatal(err)
	}
	host.lastPanic = "stale previous marker"
	m.reset()
	if err := i.Call("reset", func(c *Call) error {
		if c.instance != i || c.pointer != 0 || c.capacity != 0 || c.used != 0 || host.lastPanic != "" {
			t.Fatalf("call/host reset omitted: call=%#v marker=%q", c, host.lastPanic)
		}
		return c.Phase0UnitReply("reset", OK, true)
	}); err != nil {
		t.Fatal(err)
	}
	phase0ProofQueries(t, m, 2)
	epoch := i.Epoch()
	err := i.Call("trap", func(*Call) error {
		host.lastPanic = "current guest panic"
		panic("unreachable")
	})
	var fault *FaultError
	if !errors.As(err, &fault) || fault.Kind != FaultUnreachable || fault.GuestMsg != "current guest panic" || host.lastPanic != "" {
		t.Fatalf("guest panic marker=%#v retained=%q", err, host.lastPanic)
	}
	phase0ProofFaultState(t, i, epoch, true)
}

func TestPhase0HostShieldedImportPanic(t *testing.T) {
	i, _, host := phase0ProofInstance(t, 0)
	epoch := i.Epoch()
	host.Now = func() time.Time { panic("deliberate phase0 host import") }
	err := i.Call("import", func(*Call) error {
		host.ClockNanos()
		return nil
	})
	var shielded *HostError
	if !errors.As(err, &shielded) || shielded.Op != "import" || shielded.Value != "deliberate phase0 host import" {
		t.Fatalf("host import panic=%#v", err)
	}
	phase0ProofFaultState(t, i, epoch, true)
}

func TestPhase0HostDrainAliasAndGoexit(t *testing.T) {
	for _, goexit := range []bool{false, true} {
		t.Run(fmt.Sprintf("goexit=%t", goexit), func(t *testing.T) {
			i, _, _ := phase0ProofInstance(t, 0)
			var life Lifecycle
			var drops atomic.Int32
			r, err := NewResource[int](i, uint64(0xdeadbeef)<<32|uint64(9), func(h uint64) error {
				if h != uint64(0xdeadbeef)<<32|uint64(9) {
					t.Error("destructor handle bits changed")
				}
				drops.Add(1)
				return nil
			})
			if err != nil {
				t.Fatal(err)
			}
			alias := r
			entered, release, returned, closed := make(chan struct{}), make(chan struct{}), make(chan struct{}), make(chan error, 1)
			go func() {
				defer close(returned)
				if err := life.Enter(); err != nil {
					t.Error(err)
					return
				}
				defer life.Leave()
				if err := r.Use("probe", func(instance *Instance, h uint64) error {
					if h != uint64(0xdeadbeef)<<32|uint64(9) {
						t.Error("resource handle bits changed")
					}
					return instance.Call("probe", func(c *Call) error {
						close(entered)
						<-release
						if goexit {
							runtime.Goexit()
						}
						return c.Phase0UnitReply("probe", OK, true)
					})
				}); err != nil {
					t.Error(err)
				}
			}()
			<-entered
			go func() { closed <- life.Close(func() error { return alias.Close() }) }()
			for {
				if err := life.Enter(); errors.Is(err, ErrClosed) {
					break
				}
				life.Leave()
				runtime.Gosched()
			}
			blocked := drops.Load() == 0
			var alreadyClosed bool
			var closeErr error
			select {
			case closeErr = <-closed:
				blocked = false
				alreadyClosed = true
			default:
			}
			close(release)
			<-returned
			if !alreadyClosed {
				closeErr = <-closed
			}
			if closeErr != nil {
				t.Fatal(closeErr)
			}
			if !blocked || drops.Load() != 1 {
				t.Fatalf("Close did not drain once: blocked=%t drops=%d", blocked, drops.Load())
			}
			if err := r.Close(); err != nil || drops.Load() != 1 {
				t.Fatalf("alias Close repeated destructor: %v drops=%d", err, drops.Load())
			}
			var handle *HandleError
			if err := r.Use("closed", nil); !errors.As(err, &handle) {
				t.Fatalf("closed alias remained live: %v", err)
			}
			if err := i.Call("after", func(c *Call) error { return c.Phase0UnitReply("after", OK, true) }); err != nil {
				t.Fatal("execution lock remained held", err)
			}
		})
	}
}

// Run this test separately with an actual private source mutation. A passing
// parent requires exit1 and SEMANTIC_MUTANT, never a compile/startup failure.
func TestPhase0HostSelectedSemanticMutant(t *testing.T) {
	mode := os.Getenv("COCOON_PHASE0_MUTANT")
	if mode == "" {
		t.Skip("private semantic mutants are separate executed source variants")
	}
	i, m, _ := phase0ProofInstance(t, 0)
	epoch := i.Epoch()
	status := OK
	if mode == "skip-nonok-validation" || mode == "suppress-poison" {
		status = Pending
	}
	if mode == "drop-postmemory" {
		m.reset(m.memory, make([]byte, 129))
	}
	err := i.Call("probe", func(c *Call) error { return c.Phase0UnitReply("probe", status, true) })
	var mismatch bool
	switch mode {
	case "drop-reply-query":
		mismatch = err != nil || m.queries != 2
	case "drop-postmemory":
		mismatch = !errors.Is(err, ErrTooLarge) || i.Healthy() || i.Epoch() != epoch+1 || m.queries != 2
	case "skip-nonok-validation", "suppress-poison":
		mismatch = !errors.Is(err, ErrProtocol) || i.Healthy() || i.Epoch() != epoch+1 || m.queries != 2
	default:
		t.Fatalf("unknown mutant selector %q", mode)
	}
	if mismatch {
		t.Fatalf("SEMANTIC_MUTANT %s actual result=%v queries=%d healthy=%t epoch=%d initial=%d", mode, err, m.queries, i.Healthy(), i.Epoch(), epoch)
	}
}
