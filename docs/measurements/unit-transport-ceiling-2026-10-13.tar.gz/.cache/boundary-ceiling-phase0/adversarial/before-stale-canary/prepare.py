"""Prepare ignored runtime/query proof overlays and semantic source mutants."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
HELPER = ROOT / '.cache/boundary-ceiling-phase0/host/rt_unit_transport.go.txt'
TEST = OUT / 'rt_transport_test.go'
INSTANCE = ROOT / 'rt/instance.go'


def sha(data):
    return hashlib.sha256(data).hexdigest()


helper = HELPER.read_text()
instance = INSTANCE.read_text()
assert sha(instance.encode()) == '607103f216fb1da1445e705deaea8891f21cbdd04f74e385f4958795ef107d74'
assert helper.count('_ = c.instance.module.Memory()') == 1
assert helper.count('if skip && status == OK {') == 1
assert helper.count('c.ResultView(op, status)') == 1
start = instance.index('func (i *Instance) Call(')
end = instance.index('// checked runs ', start)
public_call = instance[start:end]
post = 'if uint64(len(i.module.Memory())) > i.limits.MaxMemory {'
protocol = 'if err != nil && errors.Is(err, ErrProtocol) {'
assert public_call.count(post) == public_call.count(protocol) == 1

base = {
    str(ROOT / 'rt/phase0_unit_transport.go'): str(HELPER),
    str(ROOT / 'rt/phase0_adversarial_transport_test.go'): str(TEST),
}
records = {'original_instance_sha256': sha(instance.encode()),
           'actual_helper_sha256': sha(helper.encode()),
           'test_source_sha256': sha(TEST.read_bytes()),
           'scope': 'Private copied-source overlays; production/source template unchanged',
           'variants': {}}
for mode in ['healthy', 'drop-reply-query', 'drop-postmemory', 'skip-nonok-validation', 'suppress-poison']:
    replacement = dict(base)
    helper_variant = helper
    instance_variant = instance
    if mode == 'drop-reply-query':
        helper_variant = helper.replace('_ = c.instance.module.Memory()', '// Deliberate mutant: omit observable reply query.')
    elif mode == 'skip-nonok-validation':
        helper_variant = helper.replace('if skip && status == OK {', 'if skip {')
    elif mode == 'drop-postmemory':
        # Preserve the independent current-Memory query, remove its bound.
        mutated = public_call.replace(post, 'if current := uint64(len(i.module.Memory())); current > math.MaxUint64 {')
        instance_variant = instance[:start] + mutated + instance[end:]
    elif mode == 'suppress-poison':
        mutated = public_call.replace(protocol, 'if false && err != nil && errors.Is(err, ErrProtocol) {')
        instance_variant = instance[:start] + mutated + instance[end:]
    if helper_variant != helper:
        path = OUT / (mode + '-helper.go.txt')
        path.write_text(helper_variant)
        replacement[str(ROOT / 'rt/phase0_unit_transport.go')] = str(path)
    if instance_variant != instance:
        path = OUT / (mode + '-instance.go.txt')
        path.write_text(instance_variant)
        replacement[str(INSTANCE)] = str(path)
    overlay = OUT / (mode + '-overlay.json')
    overlay.write_text(json.dumps({'Replace': replacement}, indent=2) + '\n')
    records['variants'][mode] = {'overlay': str(overlay.relative_to(ROOT)),
                               'helper_sha256': sha(helper_variant.encode()),
                               'instance_sha256': sha(instance_variant.encode()),
                               'mutant_expected_exit': None if mode == 'healthy' else 1,
                               'required_marker': None if mode == 'healthy' else 'SEMANTIC_MUTANT ' + mode}
(OUT / 'source-provenance.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps(records, indent=2))
