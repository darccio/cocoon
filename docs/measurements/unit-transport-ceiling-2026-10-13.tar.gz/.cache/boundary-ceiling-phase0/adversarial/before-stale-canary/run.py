"""Execute healthy query proof and four compiled private semantic mutants."""
from pathlib import Path
import os
import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
GO = ROOT / '.cache/toolchains/go1.26.8/go/bin/go'
env = dict(os.environ, CGO_ENABLED='0', GOTOOLCHAIN='local', GOCACHE=str(ROOT / '.cache/go'))
env.pop('COCOON_PHASE0_MUTANT', None)
env.pop('GOFLAGS', None)
env.pop('GOARCH', None)
records = []


def invoke(name, argv, active_env, expected=0, marker=None):
    begin = datetime.now(timezone.utc).isoformat()
    result = subprocess.run(argv, cwd=ROOT, env=active_env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    data = result.stdout
    (OUT / (name + '.log')).write_bytes(data)
    semantic = marker is None or (marker.encode() in data and b'--- FAIL: TestPhase0HostSelectedSemanticMutant' in data)
    record = {'name': name, 'argv': [str(x) for x in argv], 'architecture': active_env.get('GOARCH', 'amd64'),
              'started_utc': begin, 'completed_utc': datetime.now(timezone.utc).isoformat(),
              'exit': result.returncode, 'expected_exit': expected, 'required_marker': marker,
              'semantic_assertion_seen': semantic, 'output_sha256': hashlib.sha256(data).hexdigest()}
    records.append(record)
    (OUT / 'command-records.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, result.returncode, 'semantic=' + str(semantic), flush=True)
    if result.returncode != expected or not semantic:
        print(data.decode(errors='replace'), flush=True)
        sys.exit(1)


invoke('prepare', [sys.executable, OUT / 'prepare.py'], env)
invoke('format', [GO.with_name('gofmt'), '-w', OUT / 'rt_transport_test.go'], env)
# Rebind formatted authored-test identity before any compiler invocation.
invoke('prepare-formatted', [sys.executable, OUT / 'prepare.py'], env)
invoke('healthy', [GO, 'test', '-pgo=off', '-overlay', OUT / 'healthy-overlay.json', './rt',
                   '-run', '^TestPhase0Host', '-count=1', '-v', '-timeout=60s'], env)
for mode in ['drop-reply-query', 'drop-postmemory', 'skip-nonok-validation', 'suppress-poison']:
    exe = OUT / (mode + '-amd64.test')
    invoke('build-' + mode, [GO, 'test', '-pgo=off', '-overlay', OUT / (mode + '-overlay.json'),
                            '-c', '-o', exe, './rt'], env)
    changed = dict(env, COCOON_PHASE0_MUTANT=mode)
    invoke('mutant-' + mode, [exe, '-test.run=^TestPhase0HostSelectedSemanticMutant$', '-test.count=1', '-test.v', '-test.timeout=30s'],
           changed, expected=1, marker='SEMANTIC_MUTANT ' + mode)
