# Adversarial applied runtime proof and cross-review

Verdict: **READY for final native proof builds and measurement preparation.** The source/cause and tests implement the signed unsupported transport specification; no production file was changed. The complete final native386 replay/proof and final source freeze remain parent's work before timing. This note records functional proof and read-only cross-review, not timing/performance acceptance or a public ABI approval.

## Authored runtime proof

New package-rt test overlay `adversarial/rt_transport_test.go` contains nine named tests. Its fake module makes every Memory query observable through count/order/backing selection/panic, with initialization queries reset before each witness. Original generated-tail behavior, disabled helper and enabled helper are compared to independently specified wire/error/query expectations, not a second copy of the success shortcut. Every completed healthy or expected-error unit call has one reply query plus the independent original Instance.Call postquery. Panic tests require exactly the entered prefix. The descriptor export is resolved once and is not reread after growth/backing replacement.

Cases cover canonical empty zero/logical-end, nonempty successful payload, empty spare-capacity/max pointer, widened end, short descriptor/payload, MaxOutput precedence over pointer/status and range precedence over status, pending and positive/negative unknown statuses. Enabled OK deliberately accepts the malformed success canaries; they are explicitly ABI3 divergence, not relaxed production expectations. A specific old data/error output -> enabled OK -> checked poison history proves unchanged stale backing/metadata and the subsequent ordinary checked rejection. Even nil reply memory must be queried once before the independent valid postquery.

Expected App/Arg/Handle/Limit failures preserve concrete op/status/message/sentinel and opaque invalidUTF8/NUL/Unicode bytes, with the retained error re-evaluated after guest-byte overwrite. Fresh larger backing verifies healthy expected-error reuse and cached descriptor addressing. Alternating reply/post views distinguish captured validation from the independent postquery; 129-byte postmemory overrides prior success, expected error or protocol error and poisons once. Getter panics, guest trap/host marker reset and a real shielded Host.ClockNanos panic are classified and invalidate epochs. Poisoned subsequent Instance and Resource callbacks never run. Full Call reservation fields and host panic metadata reset before the next operation.

An actually admitted Resource/Instance callback blocks under the real lifecycle/resource/execution envelope. The proof observes terminal admission, requires Close remain blocked before release, then checks draining, once-only alias disposal, complete full-width handle bits and released ownership/execution locks. A Goexit path exercises all original deferred releases without inventing a new guest-preemption contract. Existing production ownership/GC/re-entry tests supplement this narrow overlay.

## Executed semantic mutants and provenance

Official Go1.26.8, CGO0 and PGOoff healthy runtime proof passes on amd64. The final journal has12 successful expected outcomes: prepare, format, post-format source rebind, healthy tests, four compiled source variants and their four actual assertion-failing executions. Each bad execution exits1 and includes its exact `SEMANTIC_MUTANT <mode>` plus `--- FAIL: TestPhase0HostSelectedSemanticMutant`. No compiler/startup failure is credited.

The mutations are actual ignored copied code: remove only enabled reply query; retain the postquery but replace its MaxMemory bound with an impossible uint64 maximum; extend success bypass to non-OK; and suppress only public Call's protocol-poison branch. Canonical runtime, template and host helper files remain unchanged. `prepare.py` pins the whole original Instance SHA, requires each exact target once, records source identities and overlays, and changes only the public Call region in private copies. No physical out-of-range memory access is needed to expose a fault. Initial pre-stale-canary source/logs are preserved in `before-stale-canary`; final compiled witnesses use the strengthened source. Initial read-only guesses at two file names produced missing-path output before any proof execution; no invented raw failure log or semantic credit follows those reads.

Parent can compile/run native386 with the final healthy/mutant overlays, using the same four selectors and markers; known sandbox startup failure must remain distinct from actual native execution. My driver intentionally executes amd64 only. No benchmark or profile was run by me.

## Host and guest cross-review

Actual host Phase0UnitReply is exactly the reviewed branch: skip&&OK performs one observable Memory query then nil; every other path invokes original ResultView once and retains unit shape/error semantics. The DD transport wrapper preserves both original nested callbacks, nil/admission/Leave/resource/handle/Instance boundaries and passes the same skip to guest and host. No cached handle, batching, pre-admission or view escapes are introduced.

The private guest generator binds complete source plus original method/Module/helper pins, guards reserved names and mode parameter, emits only an additional method, and wraps exactly the adjacent three publication stores with !skip while preserving the pointer read, all other statements/labels/effects and original method bytes. Mechanical unwrap-to-original and independent-of-whole-SHA drift tests support this source-pinned experiment, not a generic production predicate. Source order, original arithmetic and error paths stay intact. The bounded actual-Wasm state driver counts constructor/method/destructor operation exports individually and separately records identity/init/reserve/output calls; growth uses an actual prevalidated AddMany call rather than pretending thousands of scalar calls occurred. Complete protobuf/Count, stale metadata/error/recovery, generation reuse, wrong high-bit generation and independent resources are checked. I found a retained-error witness that only rechecked a saved string; guest fixed it to retain/re-evaluate the actual error and concrete AppError.Message after overwrite/growth. Parent must use the final repeated native proof bytes.

Original-only fixed/adaptive benchmark source is shared by bare/augmented ELFs and calls Sketch.Add directly. Scaffold/Oracle share one guest/helper and a mutable mode read per timed call. Fixed1x scopes execute exactly4M/8M inputs from unchanged corpora, bounded state and exact prevalidated Count/protobuf goldens; adaptive witnesses use their actual N and a fresh untimed original replay. Both immediate P1 checks and post-timer checks/metrics are present. Reset, owned result verification and setup are scoped honestly; there is no b.N-retained history. Additional witness work remains untimed and is not part of the finite Wasm cap or a cold setup advantage.

Plan has25groups,70cases/pass and980raw rows over7+7 planned passes, with adaptive AND fixed Increasing mandatory >=10%/p<.05 against all three controls in both sets. P1 one-home and P16 one/sixteen-home Fixed/Holdout complete streams remain listed. I flagged Reference->Augmented contextual M1 ratios being mistaken for linkage/code guards; the plan now marks them in contextual_comparators. The final decision/statistics writer must honor this field, while preserving Bare->Augmented rejection guards and every raw/reference comparison. Fresh reference remains context, not equivalent ABI or removable safety cost. Freeze/final proof/runner verification is still required before timing.

This is a deliberately unsupported success-publication/validation omission with one observable query retained. It is neither ABI3 safe-release check removal nor a generic typed-return transport, attainable checked implementation, mathematical maximum or M1 acceptance. No production/API/ABI/schema/Wasm/lock change, math approximation or permitted layout rescue follows.

## Reviewed identities

- `docs/unit-transport-ceiling.md`: `a31f60c4e0b9bd98fa49fef08bb7ff16fa15281cf5feea72b9b515c88eadf721`
- `rt/instance.go`: `607103f216fb1da1445e705deaea8891f21cbdd04f74e385f4958795ef107d74`
- `rt/resource.go`: `10576bedf0d4745afed6f73f4dd7db2c0f11c1018b302c2df5cfcfab96cfee8c`
- `rt/lifecycle.go`: `f3d9d622162f78f0b952e44a9aa21a5c1933d366e5078dbf93e8eada098b39b7`
- `.cache/boundary-ceiling-phase0/host/rt_unit_transport.go.txt`: `ef1d6307712f949a9af09f109dfb2ecb43b37ec63342479fbce294b523c0155d`
- `.cache/boundary-ceiling-phase0/host/dd_transport.go.txt`: `d34858224c9dba583636a9aa66e927f3526f736672d6c7791e1d2ef507caf926`
- `.cache/boundary-ceiling-phase0/host/phase0_original_test.go.txt`: `39b54a9a14c0f85f32d56398b583776d00a87b3a1d0c4d684396086be6e99200`
- `.cache/boundary-ceiling-phase0/host/phase0_scaffold_test.go.txt`: `4e58e99b09e2af8e47808126e233a4c3c93a2c544d2b1ad94c4fab0a53d76e6b`
- `.cache/boundary-ceiling-phase0/guest/generate.go`: `3d71589df31faabd827e8fdc980302786892457afffb59ea8285b5dbecc82726`
- `.cache/boundary-ceiling-phase0/guest/generate_test.go`: `9681dec2c7338dfdeb9cee826e0474c5c694fbb676b06be9fef094a850d2a408`
- `.cache/boundary-ceiling-phase0/guest/generated/phase0_add.go.txt`: `14f8d577debd64a86698b86649eef46db090ba3c1f345b4584bbcd6b3161a69e`
- `.cache/boundary-ceiling-phase0/guest/dd_proof_test.go.txt`: `156cf706289bbfb7dff71fe557042cce3a7f81378bb6853fa3270c7525bc2e91`
- `.cache/boundary-ceiling-phase0/adversarial/rt_transport_test.go`: `2301f5d393ec71b76d7f7cf21d437702a522ad5113395d06e3627d23a9fa4db8`
- `.cache/boundary-ceiling-phase0/adversarial/prepare.py`: `e54478d021f6436eba61e288541c9ce3f7af7bb4da22ec39e4c08b61367806fd`
- `.cache/boundary-ceiling-phase0/adversarial/run.py`: `2364edc50f79046e6d56741a5ff1127047072b86c0bf180889a482dcddef7345`
- `.cache/boundary-ceiling-phase0/adversarial/source-provenance.json`: `807b5948f48fcda1d53e6c6567a5e0e323ef3b933d80b0baafa950a0c61bcd42`
- `.cache/boundary-ceiling-phase0/adversarial/command-records.json`: `738ff9613453a2e5a768feac75e740b8fe064d9ba7e04af32c098c968ec602cc`

ALL TOOLS STOPPED after writing this separate applied note.
