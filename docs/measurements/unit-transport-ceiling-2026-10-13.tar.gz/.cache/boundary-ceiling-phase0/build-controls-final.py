from pathlib import Path
import os,subprocess,json,hashlib,datetime
root=Path.cwd();out=root/'.cache/boundary-ceiling-phase0'
go=root/'.cache/toolchains/go1.26.8/go/bin/go'
env=dict(os.environ,GOTOOLCHAIN='local',CGO_ENABLED='0',GOAMD64='v1',GOCACHE=str(root/'.cache/go'),GOFLAGS='-buildvcs=false',GOWORK='off')
env.pop('GOROOT',None)
base=json.loads((out/'bracket/overlay.json').read_text())['Replace']
base[str(root/'examples/datadog/go/dd/phase0_original_test.go')]=str(out/'host/phase0_original_test.go.txt')
(out/'bare-overlay.json').write_text(json.dumps({'Replace':base},indent=2)+'\n')
records=[]
def run(name,args):
 record={'name':name,'argv':list(map(str,args)),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (out/(name+'.log')).open('x') as log:
  result=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
 record.update(exit=result.returncode,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());records.append(record)
 (out/'final-control-build-records.json').write_text(json.dumps(records,indent=2)+'\n');assert result.returncode==0,name
 print('PASS',name,flush=True)
run('build-final-bare-amd64',[go,'test','-overlay='+str(out/'bare-overlay.json'),'-pgo=off','-c','-o',out/'bare-amd64.test','./examples/datadog/go/dd'])
run('build-final-stream-bare',[go,'test','-pgo=off','-c','-o',out/'stream-bare.test','./testdata/streaming/go/streaming'])
print('Bare controls frozen; augmented sources will use identical original/bracket harness files.',flush=True)
