from pathlib import Path
import os,subprocess,json,datetime
root=Path.cwd();out=root/'.cache/boundary-ceiling-phase0';records=[]
env=dict(os.environ,GOTOOLCHAIN='local',CGO_ENABLED='0',GOAMD64='v1',GOMAXPROCS='1',GOWORK='off')
for arch in ['amd64','386']:
 folder=out/('functional-'+arch);folder.mkdir(exist_ok=False)
 for n in [4194304,8388608]:
  args=[str(out/('augmented-'+arch+'.test')),'-test.run=^TestPhase0TransportFullReplay$','-test.v','-test.count=1','-test.cpu=1','-test.timeout=20m']
  record={'architecture':arch,'prefix':n,'argv':args,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'functional only: every input must return nil for each role and final exact Count/full protobuf; no performance qualification'}
  with (folder/(str(n)+'.log')).open('x') as log: result=subprocess.run(args,cwd=root,env=dict(env,COCOON_UNIT_PREFIX_N=str(n),COCOON_UNIT_PROOF_DIR=str(folder)),stdout=log,stderr=subprocess.STDOUT)
  record.update(exit=result.returncode,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());records.append(record);(out/'full-proof-records.json').write_text(json.dumps(records,indent=2)+'\n');assert result.returncode==0,record
  print('PASS',arch,n,'full ordered replay',flush=True)
for p in sorted((out/'functional-amd64/goldens').rglob('*')):
 if p.is_file():assert p.read_bytes()==(out/'functional-386/goldens'/p.relative_to(out/'functional-amd64/goldens')).read_bytes(),p
(out/'full-proof-complete.json').write_text(json.dumps({'goldens_native_identical':True,'architectures':['amd64','386'],'prefixes':[4194304,8388608],'total_input_calls_per_architecture':24*(4194304+8388608),'note':'stateful Go consistency, not full-N Wasm or universal equivalence'},indent=2)+'\n')
print('PASS native amd64/386 complete Count/protobuf bytes identical',flush=True)
