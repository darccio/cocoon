# Host entry review: joint successful-unit output protocol ceiling

Read-only entry, 2026-10-13. Reviewed the roadmap/performance history, ABI 3,
runtime boundary and ownership/lifecycle code, current generated Sketch.Add,
original translated export, and existing layer benchmarks. No build, test,
lint, profile, benchmark, tracked-source edit, or Git mutation was performed.
HEAD is `47f307971894d9257023dca1d6d7d848a2d0bc55` on
`task/fast-certified-interval-cost`; `main` and `origin/main` are both
`aeaf01b341a85024804e9ae1abe43af90d36e4d1` (0/0). Initial status is clean.

## Materially new question and restricted interpretation

The refined diagnostic asks whether jointly omitting guest successful-unit
publication and host successful-unit wire validation supplies a substantial
end-to-end ceiling with real guest math/state and all surrounding synchronization
retained. It does **not** remove either callback or their closure construction,
lifecycle admission, ownership, or the execution lock. Do not call its result
a callback-transport saving, a fully checked ABI 3 optimization, or a prediction
of a typed-return ABI's realizable gain.

This differs from the rejected Resource.Call fusion (same checks, no established
scalar benefit), existing-ABI unit specialization (all publication and validation
retained, isolated component improved but default scalar did not), and runtime
factoring/reset experiments. Those are not evidence that this joint ceiling is
zero; nor are their layer/profile shares additive available savings. Current
layers use independently calibrated prefixes/evolving state and compiler shapes.

The three named paths should be in the same augmented ELF: original Sketch.Add;
private scaffold checked with skip=false; identical scaffold oracle with
skip=true. Runtime flag selection must retain both variants. Source identity of
the original path is valuable, but adding methods/test code can change linked
placement: this ELF is not the original production ELF. A separately frozen
ordinary production bracket is useful context if economical; no result should
depend on claiming byte equality with it. Previously source-identical additions
changed the sign of a full-stream comparison. Checked-control regressions must
be reported rather than used to rescue a weak untouched-path comparison.

## Exact guest publication scope

Current module SHA-256 is
`626550cafa323c490a6a2ec6b2b341656c40e223c7c84701e414078633dcc298`.
`Xcocoon_sketch_add` starts at line 48457. Its successful l5 tail retains slab
release, output initialization/live-state checks and t42's pointer load, then:

```
store32(memory, 1101804, t42) // cached descriptor's payload pointer
store32(memory, 1101800, 0)   // output buffer's internal length
store32(memory, 1101808, 0)   // cached descriptor's payload length
```

`Xcocoon_out` returns 1101804. Thus the triple includes both descriptor words
and one output-buffer state update; it is not three descriptor words. The
ignored AST emitter must pin the whole source, locate and shape-check this exact
successful tail, clone all other statements unchanged, and make only these
stores conditional. Retain address/value evaluation before the conditional as
specified, initialization/traps, memory reads, handle lookup, numeric validation,
all fn176 work and mutations, stack restoration, status, and error publication.
Skipping store bounds/traps is part of the explicitly unsupported oracle scope,
not an established generic optimization.

Omission leaves previous output descriptor/buffer-length state stale. Functional
proof must include nonempty Count/Encode output and argument/handle errors
before oracle success, then checked success/error and other normal operations.
Compare Count and complete protobuf against original Wasm and the original path,
including long/collapse prefixes and all frozen corpora. Memory comparisons must
disclose the three intentional publication-state differences. Non-OK paths must
still publish their current error normally. A clone by itself provides no
original-Wasm equivalence of the omitted wire publication contract.

## Host reply and lifetime requirements

Current Add validates wrapper pointers, admits once, defers Leave, obtains the
current full-width handle under Resource.Use, then calls Instance.Call with
the original nested callback. It invokes the guest once and performs ResultView
followed by the nonempty-unit check. Add has no PrepareInput/Reserve crossing.
The private scaffold should copy this shape and change only the cloned export
and private reply helper calls.

For skip && status==OK, the private helper must query current Memory exactly
once and ignore the stale descriptor/payload. For every other path it must run
the unchanged ResultView exactly once, then reject a nonempty successful view.
Do not pre-read Memory and fall back to ResultView, which would add a query and
change observable side effects. No guest reinvocation on errors, no borrowed
view escape, no retained Call. A Memory query panic still reaches the unchanged
recovery boundary. The independent post-operation Memory query and MaxMemory
check remain; they can override an earlier returned error as today.

The full reset, stale-host-panic clearing, healthy/state gate, direct recovery,
classification/poison/epoch increment, and immediate protocol-error poisoning
stay in original Instance.Call. Owner alias/epoch/closed checks, KeepAlive,
resource and instance mutexes, once-only destructor, no re-entry, and terminal
library draining remain. Expected errors remain healthy; unknown/reserved
statuses and malformed non-OK replies remain checked and poison. Synchronous
execution and mutex waits remain nonpreemptible. No context/admission change.

Proof should count reply/post Memory queries with stateful query mocks and test
post-MaxMemory precedence, query panic, malformed/nonempty/oversized replies,
unknown status, owned error strings, reset, alias close, poisoned siblings and
draining waiters. Explicit malformed OK canaries should be accepted by the
oracle but rejected/poisoned by the checked path: this records precisely which
ABI 3 obligations the diagnostic suspends, rather than concealing them.

## Measurement and stopping criteria

Preregister fixed 4M and 8M complete prefixes for original increasing inputs
and all seven frozen corpora, three roles, seven alternating samples and seven
reversed confirmation samples. Prepare corpora and fresh resources/model state
outside timing; time every Add and its surrounding boundary, without per-hit
warmup or hidden output checks. Validate exact Count and complete protobuf after
the timer with an independent oracle. All measured leaves should set/assert P1
immediately around timing and report actual-procs; a -16 name suffix is not proof.
Use official Go 1.26.8, CGO disabled, PGO off, unchanged GC/memory defaults, and
freeze source/overlay/emitter/module/body/binary identities. No other work runs
during timing. Preserve every sample and all checked-control costs.

For this large-boundary question, a reasonable advance criterion is at least a
10% default fixed-prefix gain versus BOTH original augmented path and scaffold
checked, in both independent sets; no selected retiming rescue. This is a
recommendation for the premeasurement decision, not evidence already obtained.
Retain all scalar holdouts and complete SQL/batch/trace/context guards. Unchanged
stream roles are bracket observations when their ELFs are identical, never a
new streaming optimization or equivalence claim; report adverse medians and the
one-home/16-home, P1/P16, full-lifetime scopes honestly.

A positive result permits only a separately reviewed compatibility/design
proposal. ABI 3 requires even successful unit replies to publish and validate
the cached descriptor, MaxOutput, logical payload range and emptiness. Shipping
their omission requires an explicit versioned/public contract decision and
operator approval before implementation. This ceiling says nothing quantitative
about typed numeric returns, SQL/nonunit outputs, migration costs, new failure
channels, or platform support. If the deliberately weakened joint path cannot
supply a material repeatable default gain, park it; do not revive rejected
callback/unit/reset micro-shapes. M1 remains unaccepted.

## Entry source hashes

* ABI: f5534633c15c03e2799a53c6439ec42c9e4fafe6bac790fff035bb24fe7cc029
* Runtime Instance: 607103f216fb1da1445e705deaea8891f21cbdd04f74e385f4958795ef107d74
* Runtime Resource: 10576bedf0d4745afed6f73f4dd7db2c0f11c1018b302c2df5cfcfab96cfee8c
* Runtime Lifecycle: f3d9d622162f78f0b952e44a9aa21a5c1933d366e5078dbf93e8eada098b39b7
* Facade: 3d5aeacda6069a347a0e91e7840792ec194b0cdfd414f3c33328ec037231d672
* Roadmap: cab5d4ac266d416b3a1ee71720380e0314291fc7ef9577ee3816610bba80fbe2
* Performance: 42a2a1d776718c1efdf5ba6b8fd701faa01d54d025822b53669fe882964881f1

READY for committing a private diagnostic specification and subsequent separate
proof review under this scope. This is not production/public-contract approval.
Host reviewer stops tool work now for the parent's isolated profiling/timing.
