TEXT dario.cat/cocoon/examples/datadog/go/dd.BenchmarkPhase0TransportScaffoldFixed(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/phase0_scaffold_test.go
  phase0_scaffold_test.go:9	0x804ba0		493b6610		CMPQ SP, 0x10(R14)											
  phase0_scaffold_test.go:9	0x804ba4		0f86d0000000		JBE 0x804c7a												
  phase0_scaffold_test.go:9	0x804baa		55			PUSHQ BP												
  phase0_scaffold_test.go:9	0x804bab		4889e5			MOVQ SP, BP												
  phase0_scaffold_test.go:9	0x804bae		4883ec60		SUBQ $0x60, SP												
  phase0_scaffold_test.go:10	0x804bb2		4889442470		MOVQ AX, 0x70(SP)											
  phase0_scaffold_test.go:10	0x804bb7		48c744244007000000	MOVQ $0x7, 0x40(SP)											
  phase0_scaffold_test.go:10	0x804bc0		488d0d97870d00		LEAQ 0xd8797(IP), CX											
  phase0_scaffold_test.go:10	0x804bc7		48894c2438		MOVQ CX, 0x38(SP)											
  phase0_scaffold_test.go:10	0x804bcc		48c744245006000000	MOVQ $0x6, 0x50(SP)											
  phase0_scaffold_test.go:10	0x804bd5		488d0d7c810d00		LEAQ 0xd817c(IP), CX											
  phase0_scaffold_test.go:10	0x804bdc		48894c2448		MOVQ CX, 0x48(SP)											
  phase0_scaffold_test.go:10	0x804be1		488d4c2438		LEAQ 0x38(SP), CX											
  phase0_scaffold_test.go:10	0x804be6		31d2			XORL DX, DX												
  phase0_scaffold_test.go:10	0x804be8		eb27			JMP 0x804c11												
  phase0_scaffold_test.go:11	0x804bea		48895808		MOVQ BX, 0x8(AX)											
  phase0_scaffold_test.go:11	0x804bee		4889c7			MOVQ AX, DI												
  phase0_scaffold_test.go:11	0x804bf1		488b442470		MOVQ 0x70(SP), AX											
  phase0_scaffold_test.go:11	0x804bf6		e8259ad0ff		CALL testing.(*B).Run(SB)										
  phase0_scaffold_test.go:10	0x804bfb		488b4c2458		MOVQ 0x58(SP), CX											
  phase0_scaffold_test.go:10	0x804c00		4883c110		ADDQ $0x10, CX												
  phase0_scaffold_test.go:10	0x804c04		488b542428		MOVQ 0x28(SP), DX											
  phase0_scaffold_test.go:10	0x804c09		48ffc2			INCQ DX													
  phase0_scaffold_test.go:11	0x804c0c		488b442470		MOVQ 0x70(SP), AX											
  phase0_scaffold_test.go:10	0x804c11		4883fa02		CMPQ DX, $0x2												
  phase0_scaffold_test.go:10	0x804c15		7d5d			JGE 0x804c74												
  phase0_scaffold_test.go:10	0x804c17		4889542428		MOVQ DX, 0x28(SP)											
  phase0_scaffold_test.go:10	0x804c1c		48894c2458		MOVQ CX, 0x58(SP)											
  phase0_scaffold_test.go:10	0x804c21		488b5108		MOVQ 0x8(CX), DX											
  phase0_scaffold_test.go:10	0x804c25		4889542420		MOVQ DX, 0x20(SP)											
  phase0_scaffold_test.go:10	0x804c2a		488b09			MOVQ 0(CX), CX												
  phase0_scaffold_test.go:10	0x804c2d		48894c2430		MOVQ CX, 0x30(SP)											
  phase0_scaffold_test.go:11	0x804c32		488d05c79b0700		LEAQ 0x79bc7(IP), AX											
  phase0_scaffold_test.go:11	0x804c39		e8e2d5c1ff		CALL runtime.newobject(SB)										
  phase0_scaffold_test.go:11	0x804c3e		488d0d5b000000		LEAQ dario.cat/cocoon/examples/datadog/go/dd.BenchmarkPhase0TransportScaffoldFixed.func1(SB), CX	
  phase0_scaffold_test.go:11	0x804c45		488908			MOVQ CX, 0(AX)												
  phase0_scaffold_test.go:11	0x804c48		488b4c2420		MOVQ 0x20(SP), CX											
  phase0_scaffold_test.go:11	0x804c4d		48894810		MOVQ CX, 0x10(AX)											
  phase0_scaffold_test.go:11	0x804c51		833d18b5500000		CMPL runtime.writeBarrier(SB), $0x0									
  phase0_scaffold_test.go:11	0x804c58		7508			JNE 0x804c62												
  phase0_scaffold_test.go:11	0x804c5a		488b5c2430		MOVQ 0x30(SP), BX											
  phase0_scaffold_test.go:11	0x804c5f		90			NOPL													
  phase0_scaffold_test.go:11	0x804c60		eb88			JMP 0x804bea												
  phase0_scaffold_test.go:11	0x804c62		e899b9c8ff		CALL runtime.gcWriteBarrier1(SB)									
  phase0_scaffold_test.go:11	0x804c67		488b5c2430		MOVQ 0x30(SP), BX											
  phase0_scaffold_test.go:11	0x804c6c		49891b			MOVQ BX, 0(R11)												
  phase0_scaffold_test.go:11	0x804c6f		e976ffffff		JMP 0x804bea												
  phase0_scaffold_test.go:44	0x804c74		4883c460		ADDQ $0x60, SP												
  phase0_scaffold_test.go:44	0x804c78		5d			POPQ BP													
  phase0_scaffold_test.go:44	0x804c79		c3			RET													
  phase0_scaffold_test.go:9	0x804c7a		4889442408		MOVQ AX, 0x8(SP)											
  phase0_scaffold_test.go:9	0x804c7f		90			NOPL													
  phase0_scaffold_test.go:9	0x804c80		e81ba0c8ff		CALL runtime.morestack_noctxt.abi0(SB)									
  phase0_scaffold_test.go:9	0x804c85		488b442408		MOVQ 0x8(SP), AX											
  phase0_scaffold_test.go:9	0x804c8a		e911ffffff		JMP dario.cat/cocoon/examples/datadog/go/dd.BenchmarkPhase0TransportScaffoldFixed(SB)			

TEXT dario.cat/cocoon/examples/datadog/go/dd.BenchmarkPhase0TransportScaffoldFixed.func1(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/phase0_scaffold_test.go
  phase0_scaffold_test.go:11	0x804ca0		493b6610		CMPQ SP, 0x10(R14)											
  phase0_scaffold_test.go:11	0x804ca4		0f8601010000		JBE 0x804dab												
  phase0_scaffold_test.go:11	0x804caa		55			PUSHQ BP												
  phase0_scaffold_test.go:11	0x804cab		4889e5			MOVQ SP, BP												
  phase0_scaffold_test.go:11	0x804cae		4883ec58		SUBQ $0x58, SP												
  phase0_scaffold_test.go:12	0x804cb2		4889442468		MOVQ AX, 0x68(SP)											
  phase0_scaffold_test.go:12	0x804cb7		488b0de2a54d00		MOVQ dario.cat/cocoon/examples/datadog/go/dd.phase0TransportCorpora(SB), CX				
  phase0_scaffold_test.go:11	0x804cbe		488b5a08		MOVQ 0x8(DX), BX											
  phase0_scaffold_test.go:11	0x804cc2		48895c2440		MOVQ BX, 0x40(SP)											
  phase0_scaffold_test.go:11	0x804cc7		488b5210		MOVQ 0x10(DX), DX											
  phase0_scaffold_test.go:11	0x804ccb		4889542420		MOVQ DX, 0x20(SP)											
  phase0_scaffold_test.go:12	0x804cd0		488b35d1a54d00		MOVQ dario.cat/cocoon/examples/datadog/go/dd.phase0TransportCorpora+8(SB), SI				
  phase0_scaffold_test.go:12	0x804cd7		4889742438		MOVQ SI, 0x38(SP)											
  phase0_scaffold_test.go:12	0x804cdc		31ff			XORL DI, DI												
  phase0_scaffold_test.go:12	0x804cde		6690			NOPW													
  phase0_scaffold_test.go:12	0x804ce0		eb48			JMP 0x804d2a												
  phase0_scaffold_test.go:13	0x804ce2		48895808		MOVQ BX, 0x8(AX)											
  phase0_scaffold_test.go:13	0x804ce6		488b742420		MOVQ 0x20(SP), SI											
  phase0_scaffold_test.go:13	0x804ceb		48897020		MOVQ SI, 0x20(AX)											
  phase0_scaffold_test.go:13	0x804cef		48895018		MOVQ DX, 0x18(AX)											
  phase0_scaffold_test.go:13	0x804cf3		4889c7			MOVQ AX, DI												
  phase0_scaffold_test.go:13	0x804cf6		488b442468		MOVQ 0x68(SP), AX											
  phase0_scaffold_test.go:13	0x804cfb		0f1f440000		NOPL 0(AX)(AX*1)											
  phase0_scaffold_test.go:13	0x804d00		e81b99d0ff		CALL testing.(*B).Run(SB)										
  phase0_scaffold_test.go:12	0x804d05		488b4c2450		MOVQ 0x50(SP), CX											
  phase0_scaffold_test.go:12	0x804d0a		4883c110		ADDQ $0x10, CX												
  phase0_scaffold_test.go:12	0x804d0e		488b7c2430		MOVQ 0x30(SP), DI											
  phase0_scaffold_test.go:12	0x804d13		48ffc7			INCQ DI													
  phase0_scaffold_test.go:13	0x804d16		488b442468		MOVQ 0x68(SP), AX											
  phase0_scaffold_test.go:13	0x804d1b		488b542420		MOVQ 0x20(SP), DX											
  phase0_scaffold_test.go:13	0x804d20		488b5c2440		MOVQ 0x40(SP), BX											
  phase0_scaffold_test.go:12	0x804d25		488b742438		MOVQ 0x38(SP), SI											
  phase0_scaffold_test.go:12	0x804d2a		4839f7			CMPQ DI, SI												
  phase0_scaffold_test.go:12	0x804d2d		7d76			JGE 0x804da5												
  phase0_scaffold_test.go:12	0x804d2f		48897c2430		MOVQ DI, 0x30(SP)											
  phase0_scaffold_test.go:12	0x804d34		48894c2450		MOVQ CX, 0x50(SP)											
  phase0_scaffold_test.go:12	0x804d39		488b5108		MOVQ 0x8(CX), DX											
  phase0_scaffold_test.go:12	0x804d3d		4889542428		MOVQ DX, 0x28(SP)											
  phase0_scaffold_test.go:12	0x804d42		488b09			MOVQ 0(CX), CX												
  phase0_scaffold_test.go:12	0x804d45		48894c2448		MOVQ CX, 0x48(SP)											
  phase0_scaffold_test.go:13	0x804d4a		488d056fef0800		LEAQ 0x8ef6f(IP), AX											
  phase0_scaffold_test.go:13	0x804d51		e8cad4c1ff		CALL runtime.newobject(SB)										
  phase0_scaffold_test.go:13	0x804d56		488d0d63000000		LEAQ dario.cat/cocoon/examples/datadog/go/dd.BenchmarkPhase0TransportScaffoldFixed.func1.1(SB), CX	
  phase0_scaffold_test.go:13	0x804d5d		488908			MOVQ CX, 0(AX)												
  phase0_scaffold_test.go:13	0x804d60		488b4c2428		MOVQ 0x28(SP), CX											
  phase0_scaffold_test.go:13	0x804d65		48894810		MOVQ CX, 0x10(AX)											
  phase0_scaffold_test.go:13	0x804d69		833d00b4500000		CMPL runtime.writeBarrier(SB), $0x0									
  phase0_scaffold_test.go:13	0x804d70		7513			JNE 0x804d85												
  phase0_scaffold_test.go:13	0x804d72		488b542440		MOVQ 0x40(SP), DX											
  phase0_scaffold_test.go:13	0x804d77		488b5c2448		MOVQ 0x48(SP), BX											
  phase0_scaffold_test.go:13	0x804d7c		0f1f4000		NOPL 0(AX)												
  phase0_scaffold_test.go:13	0x804d80		e95dffffff		JMP 0x804ce2												
  phase0_scaffold_test.go:13	0x804d85		e896b8c8ff		CALL runtime.gcWriteBarrier2(SB)									
  phase0_scaffold_test.go:13	0x804d8a		488b5c2448		MOVQ 0x48(SP), BX											
  phase0_scaffold_test.go:13	0x804d8f		49891b			MOVQ BX, 0(R11)												
  phase0_scaffold_test.go:13	0x804d92		488b542440		MOVQ 0x40(SP), DX											
  phase0_scaffold_test.go:13	0x804d97		49895308		MOVQ DX, 0x8(R11)											
  phase0_scaffold_test.go:13	0x804d9b		0f1f440000		NOPL 0(AX)(AX*1)											
  phase0_scaffold_test.go:13	0x804da0		e93dffffff		JMP 0x804ce2												
  phase0_scaffold_test.go:42	0x804da5		4883c458		ADDQ $0x58, SP												
  phase0_scaffold_test.go:42	0x804da9		5d			POPQ BP													
  phase0_scaffold_test.go:42	0x804daa		c3			RET													
  phase0_scaffold_test.go:11	0x804dab		4889442408		MOVQ AX, 0x8(SP)											
  phase0_scaffold_test.go:11	0x804db0		e84b9ec8ff		CALL runtime.morestack.abi0(SB)										
  phase0_scaffold_test.go:11	0x804db5		488b442408		MOVQ 0x8(SP), AX											
  phase0_scaffold_test.go:11	0x804dba		e9e1feffff		JMP dario.cat/cocoon/examples/datadog/go/dd.BenchmarkPhase0TransportScaffoldFixed.func1(SB)		

TEXT dario.cat/cocoon/examples/datadog/go/dd.BenchmarkPhase0TransportScaffoldFixed.func1.1(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/phase0_scaffold_test.go
  phase0_scaffold_test.go:13	0x804dc0		4c8da42430feffff	LEAQ 0xfffffe30(SP), R12									
  phase0_scaffold_test.go:13	0x804dc8		4d3b6610		CMPQ R12, 0x10(R14)										
  phase0_scaffold_test.go:13	0x804dcc		0f865c060000		JBE 0x80542e											
  phase0_scaffold_test.go:13	0x804dd2		55			PUSHQ BP											
  phase0_scaffold_test.go:13	0x804dd3		4889e5			MOVQ SP, BP											
  phase0_scaffold_test.go:13	0x804dd6		4881ec48020000		SUBQ $0x248, SP											
  phase0_scaffold_test.go:13	0x804ddd		66440fd6bc2440020000	MOVQ X15, 0x240(SP)										
  phase0_scaffold_test.go:16	0x804de7		4889842458020000	MOVQ AX, 0x258(SP)										
  phase0_scaffold_test.go:13	0x804def		c68424d700000000	MOVB $0x0, 0xd7(SP)										
  phase0_scaffold_test.go:13	0x804df7		488b4a08		MOVQ 0x8(DX), CX										
  phase0_scaffold_test.go:13	0x804dfb		48898c24e0010000	MOVQ CX, 0x1e0(SP)										
  phase0_scaffold_test.go:13	0x804e03		488b4a10		MOVQ 0x10(DX), CX										
  phase0_scaffold_test.go:13	0x804e07		48898c2418010000	MOVQ CX, 0x118(SP)										
  phase0_scaffold_test.go:13	0x804e0f		488b4a18		MOVQ 0x18(DX), CX										
  phase0_scaffold_test.go:13	0x804e13		48898c2438010000	MOVQ CX, 0x138(SP)										
  phase0_scaffold_test.go:13	0x804e1b		488b4a20		MOVQ 0x20(DX), CX										
  phase0_scaffold_test.go:13	0x804e1f		48898c2420010000	MOVQ CX, 0x120(SP)										
  phase0_scaffold_test.go:14	0x804e27		4889c3			MOVQ AX, BX											
  phase0_scaffold_test.go:14	0x804e2a		488d05ff4e1100		LEAQ go:itab.*testing.B,testing.TB(SB), AX							
  phase0_scaffold_test.go:14	0x804e31		e86ad5ffff		CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportProcessors(SB)			
  phase0_scaffold_test.go:14	0x804e36		4889842440020000	MOVQ AX, 0x240(SP)										
  phase0_scaffold_test.go:14	0x804e3e		c68424d700000001	MOVB $0x1, 0xd7(SP)										
  phase0_scaffold_test.go:15	0x804e46		488d05e34e1100		LEAQ go:itab.*testing.B,testing.TB(SB), AX							
  phase0_scaffold_test.go:15	0x804e4d		488b9c2458020000	MOVQ 0x258(SP), BX										
  phase0_scaffold_test.go:15	0x804e55		e8e6c1ffff		CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportPrefix(SB)				
  phase0_scaffold_test.go:15	0x804e5a		48898424f0000000	MOVQ AX, 0xf0(SP)										
  phase0_scaffold_test.go:16	0x804e62		488b8c2458020000	MOVQ 0x258(SP), CX										
  phase0_scaffold_test.go:16	0x804e6a		4883b91002000001	CMPQ 0x210(CX), $0x1										
  phase0_scaffold_test.go:16	0x804e72		7446			JE 0x804eba											
  phase0_scaffold_test.go:17	0x804e74		488d1585dd0400		LEAQ 0x4dd85(IP), DX										
  phase0_scaffold_test.go:17	0x804e7b		4889942430020000	MOVQ DX, 0x230(SP)										
  phase0_scaffold_test.go:17	0x804e83		488d15066a1000		LEAQ 0x106a06(IP), DX										
  phase0_scaffold_test.go:17	0x804e8a		4889942438020000	MOVQ DX, 0x238(SP)										
  phase0_scaffold_test.go:17	0x804e92		4889c8			MOVQ CX, AX											
  phase0_scaffold_test.go:17	0x804e95		488d9c2430020000	LEAQ 0x230(SP), BX										
  phase0_scaffold_test.go:17	0x804e9d		b901000000		MOVL $0x1, CX											
  phase0_scaffold_test.go:17	0x804ea2		4889cf			MOVQ CX, DI											
  phase0_scaffold_test.go:17	0x804ea5		e81651d1ff		CALL testing.(*common).Fatal(SB)								
  phase0_scaffold_test.go:20	0x804eaa		488b8424f0000000	MOVQ 0xf0(SP), AX										
  phase0_scaffold_test.go:21	0x804eb2		488b8c2458020000	MOVQ 0x258(SP), CX										
  phase0_original_test.go:41	0x804eba		488b9c2418010000	MOVQ 0x118(SP), BX										
  phase0_original_test.go:41	0x804ec2		4883fb0a		CMPQ BX, $0xa											
  phase0_original_test.go:41	0x804ec6		7528			JNE 0x804ef0											
  phase0_original_test.go:41	0x804ec8		48ba496e637265617369	MOVQ $0x6973616572636e49, DX									
  phase0_original_test.go:41	0x804ed2		4c8b8c24e0010000	MOVQ 0x1e0(SP), R9										
  phase0_original_test.go:41	0x804eda		493911			CMPQ 0(R9), DX											
  phase0_original_test.go:41	0x804edd		7519			JNE 0x804ef8											
  phase0_original_test.go:41	0x804edf		66418179086e67		CMPW 0x8(R9), $0x676e										
  phase0_original_test.go:41	0x804ee6		7510			JNE 0x804ef8											
  phase0_original_test.go:41	0x804ee8		31d2			XORL DX, DX											
  phase0_original_test.go:41	0x804eea		31f6			XORL SI, SI											
  phase0_original_test.go:41	0x804eec		31ff			XORL DI, DI											
  phase0_scaffold_test.go:19	0x804eee		eb36			JMP 0x804f26											
  phase0_original_test.go:45	0x804ef0		4c8b8c24e0010000	MOVQ 0x1e0(SP), R9										
  phase0_original_test.go:45	0x804ef8		4c89c8			MOVQ R9, AX											
  phase0_original_test.go:45	0x804efb		0f1f440000		NOPL 0(AX)(AX*1)										
  phase0_original_test.go:45	0x804f00		e8fb4effff		CALL dario.cat/cocoon/examples/datadog/go/dd.binReuseValues(SB)					
  phase0_scaffold_test.go:20	0x804f05		4c8b8c24e0010000	MOVQ 0x1e0(SP), R9										
  phase0_scaffold_test.go:19	0x804f0d		4889da			MOVQ BX, DX											
  phase0_scaffold_test.go:19	0x804f10		4889c6			MOVQ AX, SI											
  phase0_scaffold_test.go:19	0x804f13		4889cf			MOVQ CX, DI											
  phase0_scaffold_test.go:20	0x804f16		488b8424f0000000	MOVQ 0xf0(SP), AX										
  phase0_scaffold_test.go:20	0x804f1e		488b9c2418010000	MOVQ 0x118(SP), BX										
  phase0_scaffold_test.go:19	0x804f26		4889b42428010000	MOVQ SI, 0x128(SP)										
  phase0_scaffold_test.go:19	0x804f2e		48899424e8000000	MOVQ DX, 0xe8(SP)										
  phase0_scaffold_test.go:20	0x804f36		4889f1			MOVQ SI, CX											
  phase0_scaffold_test.go:20	0x804f39		4889fe			MOVQ DI, SI											
  phase0_scaffold_test.go:20	0x804f3c		4989c0			MOVQ AX, R8											
  phase0_scaffold_test.go:20	0x804f3f		4c89c8			MOVQ R9, AX											
  phase0_scaffold_test.go:20	0x804f42		4889d7			MOVQ DX, DI											
  phase0_scaffold_test.go:20	0x804f45		e8d6c1ffff		CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportInputSHA(SB)			
  phase0_scaffold_test.go:20	0x804f4a		4889842440010000	MOVQ AX, 0x140(SP)										
  phase0_scaffold_test.go:20	0x804f52		48899c24f8000000	MOVQ BX, 0xf8(SP)										
  phase0_scaffold_test.go:21	0x804f5a		488b8c24e0010000	MOVQ 0x1e0(SP), CX										
  phase0_scaffold_test.go:21	0x804f62		488bbc2418010000	MOVQ 0x118(SP), DI										
  phase0_scaffold_test.go:21	0x804f6a		488bb424f0000000	MOVQ 0xf0(SP), SI										
  phase0_scaffold_test.go:21	0x804f72		4989c0			MOVQ AX, R8											
  phase0_scaffold_test.go:21	0x804f75		4989d9			MOVQ BX, R9											
  phase0_scaffold_test.go:21	0x804f78		488d05b14d1100		LEAQ go:itab.*testing.B,testing.TB(SB), AX							
  phase0_scaffold_test.go:21	0x804f7f		488b9c2458020000	MOVQ 0x258(SP), BX										
  phase0_scaffold_test.go:21	0x804f87		e8f4caffff		CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportExpected(SB)			
  phase0_scaffold_test.go:21	0x804f8c		488b1424		MOVQ 0(SP), DX											
  phase0_scaffold_test.go:21	0x804f90		4889942490010000	MOVQ DX, 0x190(SP)										
  phase0_scaffold_test.go:21	0x804f98		488b542408		MOVQ 0x8(SP), DX										
  phase0_scaffold_test.go:21	0x804f9d		4889942408010000	MOVQ DX, 0x108(SP)										
  phase0_scaffold_test.go:21	0x804fa5		488b542410		MOVQ 0x10(SP), DX										
  phase0_scaffold_test.go:21	0x804faa		4889942410010000	MOVQ DX, 0x110(SP)										
  phase0_scaffold_test.go:21	0x804fb2		48898424e8010000	MOVQ AX, 0x1e8(SP)										
  phase0_scaffold_test.go:21	0x804fba		48899c24f0010000	MOVQ BX, 0x1f0(SP)										
  phase0_scaffold_test.go:21	0x804fc2		48898c24f8010000	MOVQ CX, 0x1f8(SP)										
  phase0_scaffold_test.go:21	0x804fca		4889bc2400020000	MOVQ DI, 0x200(SP)										
  phase0_scaffold_test.go:21	0x804fd2		4889b42408020000	MOVQ SI, 0x208(SP)										
  phase0_scaffold_test.go:21	0x804fda		4c89842410020000	MOVQ R8, 0x210(SP)										
  phase0_scaffold_test.go:21	0x804fe2		4c898c2418020000	MOVQ R9, 0x218(SP)										
  phase0_scaffold_test.go:21	0x804fea		4c89942420020000	MOVQ R10, 0x220(SP)										
  phase0_scaffold_test.go:21	0x804ff2		4c899c2428020000	MOVQ R11, 0x228(SP)										
  phase0_scaffold_test.go:21	0x804ffa		488d942498010000	LEAQ 0x198(SP), DX										
  phase0_scaffold_test.go:21	0x805002		4c8d8c24e8010000	LEAQ 0x1e8(SP), R9										
  phase0_scaffold_test.go:21	0x80500a		450f1031		MOVUPS 0(R9), X14										
  phase0_scaffold_test.go:21	0x80500e		440f1132		MOVUPS X14, 0(DX)										
  phase0_scaffold_test.go:21	0x805012		450f107110		MOVUPS 0x10(R9), X14										
  phase0_scaffold_test.go:21	0x805017		440f117210		MOVUPS X14, 0x10(DX)										
  phase0_scaffold_test.go:21	0x80501c		450f107120		MOVUPS 0x20(R9), X14										
  phase0_scaffold_test.go:21	0x805021		440f117220		MOVUPS X14, 0x20(DX)										
  phase0_scaffold_test.go:21	0x805026		450f107130		MOVUPS 0x30(R9), X14										
  phase0_scaffold_test.go:21	0x80502b		440f117230		MOVUPS X14, 0x30(DX)										
  phase0_scaffold_test.go:21	0x805030		450f107138		MOVUPS 0x38(R9), X14										
  phase0_scaffold_test.go:21	0x805035		440f117238		MOVUPS X14, 0x38(DX)										
  phase0_scaffold_test.go:22	0x80503a		488d05ef4c1100		LEAQ go:itab.*testing.B,testing.TB(SB), AX							
  phase0_scaffold_test.go:22	0x805041		488b9c2458020000	MOVQ 0x258(SP), BX										
  phase0_scaffold_test.go:22	0x805049		e832c3ffff		CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportSketch(SB)				
  phase0_scaffold_test.go:22	0x80504e		4889842430010000	MOVQ AX, 0x130(SP)										
  phase0_scaffold_test.go:23	0x805056		488b5008		MOVQ 0x8(AX), DX										
  phase0_scaffold_test.go:23	0x80505a		488b12			MOVQ 0(DX), DX											
  zz_adapter.go:11		0x80505d		488b12			MOVQ 0(DX), DX											
  module.go:62926		0x805060		8402			TESTB AL, 0(DX)											
  module.go:62926		0x805062		4883c230		ADDQ $0x30, DX											
  zz_adapter.go:11		0x805066		488b5208		MOVQ 0x8(DX), DX										
  zz_adapter.go:11		0x80506a		48899424e0000000	MOVQ DX, 0xe0(SP)										
  phase0_scaffold_test.go:13	0x805072		4c8b8c2420010000	MOVQ 0x120(SP), R9										
  phase0_scaffold_test.go:13	0x80507a		660f1f440000		NOPW 0(AX)(AX*1)										
  phase0_scaffold_test.go:13	0x805080		4983f906		CMPQ R9, $0x6											
  phase0_scaffold_test.go:24	0x805084		751c			JNE 0x8050a2											
  phase0_scaffold_test.go:24	0x805086		488b8c2438010000	MOVQ 0x138(SP), CX										
  phase0_scaffold_test.go:24	0x80508e		81394f726163		CMPL 0(CX), $0x6361724f										
  phase0_scaffold_test.go:24	0x805094		750c			JNE 0x8050a2											
  phase0_scaffold_test.go:24	0x805096		668179046c65		CMPW 0x4(CX), $0x656c										
  phase0_scaffold_test.go:24	0x80509c		0f94c1			SETE CL												
  phase0_scaffold_test.go:24	0x80509f		90			NOPL												
  phase0_scaffold_test.go:24	0x8050a0		eb02			JMP 0x8050a4											
  phase0_scaffold_test.go:24	0x8050a2		31c9			XORL CX, CX											
  phase0_scaffold_test.go:24	0x8050a4		880dc3aa5000		MOVB CL, dario.cat/cocoon/examples/datadog/go/dd.phase0TransportMode(SB)			
  phase0_scaffold_test.go:25	0x8050aa		90			NOPL												
  benchmark.go:193		0x8050ab		488b9c2458020000	MOVQ 0x258(SP), BX										
  benchmark.go:193		0x8050b3		c6835202000001		MOVB $0x1, 0x252(BX)										
  phase0_scaffold_test.go:26	0x8050ba		488d056f4c1100		LEAQ go:itab.*testing.B,testing.TB(SB), AX							
  phase0_scaffold_test.go:26	0x8050c1		e89ad3ffff		CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportActual(SB)				
  phase0_scaffold_test.go:27	0x8050c6		488b842458020000	MOVQ 0x258(SP), AX										
  phase0_scaffold_test.go:27	0x8050ce		e84d66d0ff		CALL testing.(*B).ResetTimer(SB)								
  phase0_scaffold_test.go:27	0x8050d3		31c0			XORL AX, AX											
  phase0_scaffold_test.go:28	0x8050d5		eb0b			JMP 0x8050e2											
  phase0_scaffold_test.go:28	0x8050d7		488b842400010000	MOVQ 0x100(SP), AX										
  phase0_scaffold_test.go:28	0x8050df		48ffc0			INCQ AX												
  phase0_scaffold_test.go:28	0x8050e2		488b8c24f0000000	MOVQ 0xf0(SP), CX										
  phase0_scaffold_test.go:28	0x8050ea		4839c1			CMPQ CX, AX											
  phase0_scaffold_test.go:28	0x8050ed		0f8ee5000000		JLE 0x8051d8											
  phase0_scaffold_test.go:28	0x8050f3		4889842400010000	MOVQ AX, 0x100(SP)										
  phase0_original_test.go:41	0x8050fb		488b942418010000	MOVQ 0x118(SP), DX										
  phase0_original_test.go:41	0x805103		4883fa0a		CMPQ DX, $0xa											
  phase0_original_test.go:49	0x805107		7532			JNE 0x80513b											
  phase0_original_test.go:49	0x805109		48be496e637265617369	MOVQ $0x6973616572636e49, SI									
  phase0_original_test.go:49	0x805113		488bbc24e0010000	MOVQ 0x1e0(SP), DI										
  phase0_original_test.go:49	0x80511b		0f1f440000		NOPL 0(AX)(AX*1)										
  phase0_original_test.go:49	0x805120		483937			CMPQ 0(DI), SI											
  phase0_original_test.go:49	0x805123		7528			JNE 0x80514d											
  phase0_original_test.go:49	0x805125		66817f086e67		CMPW 0x8(DI), $0x676e										
  phase0_original_test.go:49	0x80512b		7520			JNE 0x80514d											
  phase0_original_test.go:50	0x80512d		4c8d4001		LEAQ 0x1(AX), R8										
  phase0_original_test.go:50	0x805131		0f57c9			XORPS X1, X1											
  phase0_original_test.go:50	0x805134		f2490f2ac8		CVTSI2SDQ R8, X1										
  phase0_scaffold_test.go:29	0x805139		eb3c			JMP 0x805177											
  phase0_scaffold_test.go:29	0x80513b		48be496e637265617369	MOVQ $0x6973616572636e49, SI									
  phase0_original_test.go:49	0x805145		488bbc24e0010000	MOVQ 0x1e0(SP), DI										
  phase0_original_test.go:52	0x80514d		25ff1f0000		ANDL $0x1fff, AX										
  phase0_original_test.go:52	0x805152		4c8b8c24e8000000	MOVQ 0xe8(SP), R9										
  phase0_original_test.go:52	0x80515a		660f1f440000		NOPW 0(AX)(AX*1)										
  phase0_original_test.go:52	0x805160		4939c1			CMPQ R9, AX											
  phase0_original_test.go:52	0x805163		0f86b1020000		JBE 0x80541a											
  phase0_original_test.go:52	0x805169		4c8b942428010000	MOVQ 0x128(SP), R10										
  phase0_original_test.go:52	0x805171		f2410f100cc2		MOVSD_XMM 0(R10)(AX*8), X1									
  phase0_scaffold_test.go:30	0x805177		0fb61defa95000		MOVZX dario.cat/cocoon/examples/datadog/go/dd.phase0TransportMode(SB), BX			
  phase0_scaffold_test.go:30	0x80517e		488b842430010000	MOVQ 0x130(SP), AX										
  phase0_scaffold_test.go:30	0x805186		0f10c1			MOVUPS X1, X0											
  phase0_scaffold_test.go:30	0x805189		e8d2bcfdff		CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportAdd(SB)				
  phase0_scaffold_test.go:30	0x80518e		4885c0			TESTQ AX, AX											
  phase0_scaffold_test.go:30	0x805191		0f8440ffffff		JE 0x8050d7											
  phase0_scaffold_test.go:31	0x805197		440f11bc2430020000	MOVUPS X15, 0x230(SP)										
  phase0_scaffold_test.go:31	0x8051a0		7404			JE 0x8051a6											
  phase0_scaffold_test.go:31	0x8051a2		488b4008		MOVQ 0x8(AX), AX										
  phase0_scaffold_test.go:31	0x8051a6		4889842430020000	MOVQ AX, 0x230(SP)										
  phase0_scaffold_test.go:31	0x8051ae		48899c2438020000	MOVQ BX, 0x238(SP)										
  phase0_scaffold_test.go:31	0x8051b6		488b842458020000	MOVQ 0x258(SP), AX										
  phase0_scaffold_test.go:31	0x8051be		488d9c2430020000	LEAQ 0x230(SP), BX										
  phase0_scaffold_test.go:31	0x8051c6		b901000000		MOVL $0x1, CX											
  phase0_scaffold_test.go:31	0x8051cb		4889cf			MOVQ CX, DI											
  phase0_scaffold_test.go:31	0x8051ce		e8ed4dd1ff		CALL testing.(*common).Fatal(SB)								
  phase0_scaffold_test.go:31	0x8051d3		e9fffeffff		JMP 0x8050d7											
  phase0_scaffold_test.go:34	0x8051d8		488b842458020000	MOVQ 0x258(SP), AX										
  phase0_scaffold_test.go:34	0x8051e0		e87b64d0ff		CALL testing.(*B).StopTimer(SB)									
  phase0_scaffold_test.go:35	0x8051e5		488d05444b1100		LEAQ go:itab.*testing.B,testing.TB(SB), AX							
  phase0_scaffold_test.go:35	0x8051ec		488b9c2458020000	MOVQ 0x258(SP), BX										
  phase0_scaffold_test.go:35	0x8051f4		e867d2ffff		CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportActual(SB)				
  phase0_scaffold_test.go:36	0x8051f9		488b8c2430010000	MOVQ 0x130(SP), CX										
  phase0_scaffold_test.go:36	0x805201		488b5108		MOVQ 0x8(CX), DX										
  phase0_scaffold_test.go:36	0x805205		488b12			MOVQ 0(DX), DX											
  zz_adapter.go:11		0x805208		488b12			MOVQ 0(DX), DX											
  module.go:62926		0x80520b		8402			TESTB AL, 0(DX)											
  module.go:62926		0x80520d		4883c230		ADDQ $0x30, DX											
  zz_adapter.go:11		0x805211		488b5208		MOVQ 0x8(DX), DX										
  zz_adapter.go:11		0x805215		48899424d8000000	MOVQ DX, 0xd8(SP)										
  phase0_scaffold_test.go:37	0x80521d		488d050c4b1100		LEAQ go:itab.*testing.B,testing.TB(SB), AX							
  phase0_scaffold_test.go:37	0x805224		488b9c2458020000	MOVQ 0x258(SP), BX										
  phase0_scaffold_test.go:37	0x80522c		488bbc24e0010000	MOVQ 0x1e0(SP), DI										
  phase0_scaffold_test.go:37	0x805234		488bb42418010000	MOVQ 0x118(SP), SI										
  phase0_scaffold_test.go:37	0x80523c		4c8b8424f0000000	MOVQ 0xf0(SP), R8										
  phase0_scaffold_test.go:37	0x805244		4c8b8c2440010000	MOVQ 0x140(SP), R9										
  phase0_scaffold_test.go:37	0x80524c		4c8b9424f8000000	MOVQ 0xf8(SP), R10										
  phase0_scaffold_test.go:37	0x805254		e847c3ffff		CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportState(SB)				
  phase0_scaffold_test.go:37	0x805259		488b1424		MOVQ 0(SP), DX											
  phase0_scaffold_test.go:37	0x80525d		4c8b642408		MOVQ 0x8(SP), R12										
  phase0_scaffold_test.go:37	0x805262		4c8b6c2410		MOVQ 0x10(SP), R13										
  phase0_scaffold_test.go:37	0x805267		48898424e8010000	MOVQ AX, 0x1e8(SP)										
  phase0_scaffold_test.go:37	0x80526f		48899c24f0010000	MOVQ BX, 0x1f0(SP)										
  phase0_scaffold_test.go:37	0x805277		48898c24f8010000	MOVQ CX, 0x1f8(SP)										
  phase0_scaffold_test.go:37	0x80527f		4889bc2400020000	MOVQ DI, 0x200(SP)										
  phase0_scaffold_test.go:37	0x805287		4889b42408020000	MOVQ SI, 0x208(SP)										
  phase0_scaffold_test.go:37	0x80528f		4c89842410020000	MOVQ R8, 0x210(SP)										
  phase0_scaffold_test.go:37	0x805297		4c898c2418020000	MOVQ R9, 0x218(SP)										
  phase0_scaffold_test.go:37	0x80529f		4c89942420020000	MOVQ R10, 0x220(SP)										
  phase0_scaffold_test.go:37	0x8052a7		4c899c2428020000	MOVQ R11, 0x228(SP)										
  phase0_scaffold_test.go:37	0x8052af		488d8c2448010000	LEAQ 0x148(SP), CX										
  phase0_scaffold_test.go:37	0x8052b7		488d9c24e8010000	LEAQ 0x1e8(SP), BX										
  phase0_scaffold_test.go:37	0x8052bf		440f1033		MOVUPS 0(BX), X14										
  phase0_scaffold_test.go:37	0x8052c3		440f1131		MOVUPS X14, 0(CX)										
  phase0_scaffold_test.go:37	0x8052c7		440f107310		MOVUPS 0x10(BX), X14										
  phase0_scaffold_test.go:37	0x8052cc		440f117110		MOVUPS X14, 0x10(CX)										
  phase0_scaffold_test.go:37	0x8052d1		440f107320		MOVUPS 0x20(BX), X14										
  phase0_scaffold_test.go:37	0x8052d6		440f117120		MOVUPS X14, 0x20(CX)										
  phase0_scaffold_test.go:37	0x8052db		440f107330		MOVUPS 0x30(BX), X14										
  phase0_scaffold_test.go:37	0x8052e0		440f117130		MOVUPS X14, 0x30(CX)										
  phase0_scaffold_test.go:37	0x8052e5		440f107338		MOVUPS 0x38(BX), X14										
  phase0_scaffold_test.go:37	0x8052ea		440f117138		MOVUPS X14, 0x38(CX)										
  phase0_scaffold_test.go:38	0x8052ef		4889e1			MOVQ SP, CX											
  phase0_scaffold_test.go:38	0x8052f2		440f1033		MOVUPS 0(BX), X14										
  phase0_scaffold_test.go:38	0x8052f6		440f1131		MOVUPS X14, 0(CX)										
  phase0_scaffold_test.go:38	0x8052fa		440f107310		MOVUPS 0x10(BX), X14										
  phase0_scaffold_test.go:38	0x8052ff		440f117110		MOVUPS X14, 0x10(CX)										
  phase0_scaffold_test.go:38	0x805304		440f107320		MOVUPS 0x20(BX), X14										
  phase0_scaffold_test.go:38	0x805309		440f117120		MOVUPS X14, 0x20(CX)										
  phase0_scaffold_test.go:38	0x80530e		440f107330		MOVUPS 0x30(BX), X14										
  phase0_scaffold_test.go:38	0x805313		440f117130		MOVUPS X14, 0x30(CX)										
  phase0_scaffold_test.go:38	0x805318		440f107338		MOVUPS 0x38(BX), X14										
  phase0_scaffold_test.go:38	0x80531d		440f117138		MOVUPS X14, 0x38(CX)										
  phase0_scaffold_test.go:38	0x805322		488d5c2448		LEAQ 0x48(SP), BX										
  phase0_scaffold_test.go:38	0x805327		488db42498010000	LEAQ 0x198(SP), SI										
  phase0_scaffold_test.go:38	0x80532f		440f1036		MOVUPS 0(SI), X14										
  phase0_scaffold_test.go:38	0x805333		440f1133		MOVUPS X14, 0(BX)										
  phase0_scaffold_test.go:38	0x805337		440f107610		MOVUPS 0x10(SI), X14										
  phase0_scaffold_test.go:38	0x80533c		440f117310		MOVUPS X14, 0x10(BX)										
  phase0_scaffold_test.go:38	0x805341		440f107620		MOVUPS 0x20(SI), X14										
  phase0_scaffold_test.go:38	0x805346		440f117320		MOVUPS X14, 0x20(BX)										
  phase0_scaffold_test.go:38	0x80534b		440f107630		MOVUPS 0x30(SI), X14										
  phase0_scaffold_test.go:38	0x805350		440f117330		MOVUPS X14, 0x30(BX)										
  phase0_scaffold_test.go:38	0x805355		440f107638		MOVUPS 0x38(SI), X14										
  phase0_scaffold_test.go:38	0x80535a		440f117338		MOVUPS X14, 0x38(BX)										
  phase0_scaffold_test.go:38	0x80535f		488d05ca491100		LEAQ go:itab.*testing.B,testing.TB(SB), AX							
  phase0_scaffold_test.go:38	0x805366		488b9c2458020000	MOVQ 0x258(SP), BX										
  phase0_scaffold_test.go:38	0x80536e		4c89e7			MOVQ R12, DI											
  phase0_scaffold_test.go:38	0x805371		4c89ee			MOVQ R13, SI											
  phase0_scaffold_test.go:38	0x805374		4c8b842490010000	MOVQ 0x190(SP), R8										
  phase0_scaffold_test.go:38	0x80537c		4c8b8c2408010000	MOVQ 0x108(SP), R9										
  phase0_scaffold_test.go:38	0x805384		4c8b942410010000	MOVQ 0x110(SP), R10										
  phase0_scaffold_test.go:38	0x80538c		4889d1			MOVQ DX, CX											
  phase0_scaffold_test.go:38	0x80538f		e80cceffff		CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportAssert(SB)				
  phase0_scaffold_test.go:39	0x805394		4889e1			MOVQ SP, CX											
  phase0_scaffold_test.go:39	0x805397		488d942448010000	LEAQ 0x148(SP), DX										
  phase0_scaffold_test.go:39	0x80539f		440f1032		MOVUPS 0(DX), X14										
  phase0_scaffold_test.go:39	0x8053a3		440f1131		MOVUPS X14, 0(CX)										
  phase0_scaffold_test.go:39	0x8053a7		440f107210		MOVUPS 0x10(DX), X14										
  phase0_scaffold_test.go:39	0x8053ac		440f117110		MOVUPS X14, 0x10(CX)										
  phase0_scaffold_test.go:39	0x8053b1		440f107220		MOVUPS 0x20(DX), X14										
  phase0_scaffold_test.go:39	0x8053b6		440f117120		MOVUPS X14, 0x20(CX)										
  phase0_scaffold_test.go:39	0x8053bb		440f107230		MOVUPS 0x30(DX), X14										
  phase0_scaffold_test.go:39	0x8053c0		440f117130		MOVUPS X14, 0x30(CX)										
  phase0_scaffold_test.go:39	0x8053c5		440f107238		MOVUPS 0x38(DX), X14										
  phase0_scaffold_test.go:39	0x8053ca		440f117138		MOVUPS X14, 0x38(CX)										
  phase0_scaffold_test.go:39	0x8053cf		488b842458020000	MOVQ 0x258(SP), AX										
  phase0_scaffold_test.go:39	0x8053d7		488b9c2430010000	MOVQ 0x130(SP), BX										
  phase0_scaffold_test.go:39	0x8053df		488bbc24d8000000	MOVQ 0xd8(SP), DI										
  phase0_scaffold_test.go:39	0x8053e7		488bb424f0000000	MOVQ 0xf0(SP), SI										
  phase0_scaffold_test.go:39	0x8053ef		488b8c24e0000000	MOVQ 0xe0(SP), CX										
  phase0_scaffold_test.go:39	0x8053f7		e844d1ffff		CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportMetrics(SB)				
  phase0_scaffold_test.go:40	0x8053fc		c68424d700000000	MOVB $0x0, 0xd7(SP)										
  phase0_scaffold_test.go:40	0x805404		488b942440020000	MOVQ 0x240(SP), DX										
  phase0_scaffold_test.go:40	0x80540c		488b0a			MOVQ 0(DX), CX											
  phase0_scaffold_test.go:40	0x80540f		ffd1			CALL CX												
  phase0_scaffold_test.go:40	0x805411		4881c448020000		ADDQ $0x248, SP											
  phase0_scaffold_test.go:40	0x805418		5d			POPQ BP												
  phase0_scaffold_test.go:40	0x805419		c3			RET												
  phase0_original_test.go:52	0x80541a		e8a1b5c8ff		CALL runtime.panicBounds(SB)									
  phase0_original_test.go:52	0x80541f		90			NOPL												
  phase0_original_test.go:52	0x805420		e81b87c4ff		CALL runtime.deferreturn(SB)									
  phase0_original_test.go:52	0x805425		4881c448020000		ADDQ $0x248, SP											
  phase0_original_test.go:52	0x80542c		5d			POPQ BP												
  phase0_original_test.go:52	0x80542d		c3			RET												
  phase0_scaffold_test.go:13	0x80542e		4889442408		MOVQ AX, 0x8(SP)										
  phase0_scaffold_test.go:13	0x805433		e8c897c8ff		CALL runtime.morestack.abi0(SB)									
  phase0_scaffold_test.go:13	0x805438		488b442408		MOVQ 0x8(SP), AX										
  phase0_scaffold_test.go:13	0x80543d		0f1f00			NOPL 0(AX)											
  phase0_scaffold_test.go:13	0x805440		e97bf9ffff		JMP dario.cat/cocoon/examples/datadog/go/dd.BenchmarkPhase0TransportScaffoldFixed.func1.1(SB)	

TEXT dario.cat/cocoon/examples/datadog/go/dd.BenchmarkPhase0TransportScaffoldAdaptive(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/phase0_scaffold_test.go
  phase0_scaffold_test.go:46	0x805460		493b6610		CMPQ SP, 0x10(R14)											
  phase0_scaffold_test.go:46	0x805464		0f86d0000000		JBE 0x80553a												
  phase0_scaffold_test.go:46	0x80546a		55			PUSHQ BP												
  phase0_scaffold_test.go:46	0x80546b		4889e5			MOVQ SP, BP												
  phase0_scaffold_test.go:46	0x80546e		4883ec60		SUBQ $0x60, SP												
  phase0_scaffold_test.go:47	0x805472		4889442470		MOVQ AX, 0x70(SP)											
  phase0_scaffold_test.go:47	0x805477		48c744244007000000	MOVQ $0x7, 0x40(SP)											
  phase0_scaffold_test.go:47	0x805480		488d0dd77e0d00		LEAQ 0xd7ed7(IP), CX											
  phase0_scaffold_test.go:47	0x805487		48894c2438		MOVQ CX, 0x38(SP)											
  phase0_scaffold_test.go:47	0x80548c		48c744245006000000	MOVQ $0x6, 0x50(SP)											
  phase0_scaffold_test.go:47	0x805495		488d0dbc780d00		LEAQ 0xd78bc(IP), CX											
  phase0_scaffold_test.go:47	0x80549c		48894c2448		MOVQ CX, 0x48(SP)											
  phase0_scaffold_test.go:47	0x8054a1		488d4c2438		LEAQ 0x38(SP), CX											
  phase0_scaffold_test.go:47	0x8054a6		31d2			XORL DX, DX												
  phase0_scaffold_test.go:47	0x8054a8		eb27			JMP 0x8054d1												
  phase0_scaffold_test.go:48	0x8054aa		48895808		MOVQ BX, 0x8(AX)											
  phase0_scaffold_test.go:48	0x8054ae		4889c7			MOVQ AX, DI												
  phase0_scaffold_test.go:48	0x8054b1		488b442470		MOVQ 0x70(SP), AX											
  phase0_scaffold_test.go:48	0x8054b6		e86591d0ff		CALL testing.(*B).Run(SB)										
  phase0_scaffold_test.go:47	0x8054bb		488b4c2458		MOVQ 0x58(SP), CX											
  phase0_scaffold_test.go:47	0x8054c0		4883c110		ADDQ $0x10, CX												
  phase0_scaffold_test.go:47	0x8054c4		488b542428		MOVQ 0x28(SP), DX											
  phase0_scaffold_test.go:47	0x8054c9		48ffc2			INCQ DX													
  phase0_scaffold_test.go:48	0x8054cc		488b442470		MOVQ 0x70(SP), AX											
  phase0_scaffold_test.go:47	0x8054d1		4883fa02		CMPQ DX, $0x2												
  phase0_scaffold_test.go:47	0x8054d5		7d5d			JGE 0x805534												
  phase0_scaffold_test.go:47	0x8054d7		4889542428		MOVQ DX, 0x28(SP)											
  phase0_scaffold_test.go:47	0x8054dc		48894c2458		MOVQ CX, 0x58(SP)											
  phase0_scaffold_test.go:47	0x8054e1		488b5108		MOVQ 0x8(CX), DX											
  phase0_scaffold_test.go:47	0x8054e5		4889542420		MOVQ DX, 0x20(SP)											
  phase0_scaffold_test.go:47	0x8054ea		488b09			MOVQ 0(CX), CX												
  phase0_scaffold_test.go:47	0x8054ed		48894c2430		MOVQ CX, 0x30(SP)											
  phase0_scaffold_test.go:48	0x8054f2		488d0507930700		LEAQ 0x79307(IP), AX											
  phase0_scaffold_test.go:48	0x8054f9		e822cdc1ff		CALL runtime.newobject(SB)										
  phase0_scaffold_test.go:48	0x8054fe		488d0d5b000000		LEAQ dario.cat/cocoon/examples/datadog/go/dd.BenchmarkPhase0TransportScaffoldAdaptive.func1(SB), CX	
  phase0_scaffold_test.go:48	0x805505		488908			MOVQ CX, 0(AX)												
  phase0_scaffold_test.go:48	0x805508		488b4c2420		MOVQ 0x20(SP), CX											
  phase0_scaffold_test.go:48	0x80550d		48894810		MOVQ CX, 0x10(AX)											
  phase0_scaffold_test.go:48	0x805511		833d58ac500000		CMPL runtime.writeBarrier(SB), $0x0									
  phase0_scaffold_test.go:48	0x805518		7508			JNE 0x805522												
  phase0_scaffold_test.go:48	0x80551a		488b5c2430		MOVQ 0x30(SP), BX											
  phase0_scaffold_test.go:48	0x80551f		90			NOPL													
  phase0_scaffold_test.go:48	0x805520		eb88			JMP 0x8054aa												
  phase0_scaffold_test.go:48	0x805522		e8d9b0c8ff		CALL runtime.gcWriteBarrier1(SB)									
  phase0_scaffold_test.go:48	0x805527		488b5c2430		MOVQ 0x30(SP), BX											
  phase0_scaffold_test.go:48	0x80552c		49891b			MOVQ BX, 0(R11)												
  phase0_scaffold_test.go:48	0x80552f		e976ffffff		JMP 0x8054aa												
  phase0_scaffold_test.go:70	0x805534		4883c460		ADDQ $0x60, SP												
  phase0_scaffold_test.go:70	0x805538		5d			POPQ BP													
  phase0_scaffold_test.go:70	0x805539		c3			RET													
  phase0_scaffold_test.go:46	0x80553a		4889442408		MOVQ AX, 0x8(SP)											
  phase0_scaffold_test.go:46	0x80553f		90			NOPL													
  phase0_scaffold_test.go:46	0x805540		e85b97c8ff		CALL runtime.morestack_noctxt.abi0(SB)									
  phase0_scaffold_test.go:46	0x805545		488b442408		MOVQ 0x8(SP), AX											
  phase0_scaffold_test.go:46	0x80554a		e911ffffff		JMP dario.cat/cocoon/examples/datadog/go/dd.BenchmarkPhase0TransportScaffoldAdaptive(SB)		

TEXT dario.cat/cocoon/examples/datadog/go/dd.BenchmarkPhase0TransportScaffoldAdaptive.func1(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/phase0_scaffold_test.go
  phase0_scaffold_test.go:48	0x805560		4c8da42460ffffff		LEAQ 0xffffff60(SP), R12									
  phase0_scaffold_test.go:48	0x805568		4d3b6610			CMPQ R12, 0x10(R14)										
  phase0_scaffold_test.go:48	0x80556c		0f8620030000			JBE 0x805892											
  phase0_scaffold_test.go:48	0x805572		55				PUSHQ BP											
  phase0_scaffold_test.go:48	0x805573		4889e5				MOVQ SP, BP											
  phase0_scaffold_test.go:48	0x805576		4881ec18010000			SUBQ $0x118, SP											
  phase0_scaffold_test.go:48	0x80557d		66440fd6bc2410010000		MOVQ X15, 0x110(SP)										
  phase0_scaffold_test.go:48	0x805587		c644247700			MOVB $0x0, 0x77(SP)										
  phase0_scaffold_test.go:48	0x80558c		4889842428010000		MOVQ AX, 0x128(SP)										
  phase0_scaffold_test.go:48	0x805594		488b4a08			MOVQ 0x8(DX), CX										
  phase0_scaffold_test.go:48	0x805598		48898c24a0000000		MOVQ CX, 0xa0(SP)										
  phase0_scaffold_test.go:48	0x8055a0		488b4a10			MOVQ 0x10(DX), CX										
  phase0_scaffold_test.go:48	0x8055a4		48898c2490000000		MOVQ CX, 0x90(SP)										
  phase0_scaffold_test.go:49	0x8055ac		488b9c2428010000		MOVQ 0x128(SP), BX										
  phase0_scaffold_test.go:49	0x8055b4		488d0575471100			LEAQ go:itab.*testing.B,testing.TB(SB), AX							
  phase0_scaffold_test.go:49	0x8055bb		0f1f440000			NOPL 0(AX)(AX*1)										
  phase0_scaffold_test.go:49	0x8055c0		e8dbcdffff			CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportProcessors(SB)			
  phase0_scaffold_test.go:49	0x8055c5		4889842410010000		MOVQ AX, 0x110(SP)										
  phase0_scaffold_test.go:49	0x8055cd		c644247701			MOVB $0x1, 0x77(SP)										
  phase0_scaffold_test.go:50	0x8055d2		488b9c2428010000		MOVQ 0x128(SP), BX										
  phase0_scaffold_test.go:50	0x8055da		488d054f471100			LEAQ go:itab.*testing.B,testing.TB(SB), AX							
  phase0_scaffold_test.go:50	0x8055e1		e89abdffff			CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportSketch(SB)				
  phase0_scaffold_test.go:50	0x8055e6		4889842498000000		MOVQ AX, 0x98(SP)										
  phase0_scaffold_test.go:51	0x8055ee		488b4808			MOVQ 0x8(AX), CX										
  phase0_scaffold_test.go:51	0x8055f2		488b09				MOVQ 0(CX), CX											
  zz_adapter.go:11		0x8055f5		488b09				MOVQ 0(CX), CX											
  module.go:62926		0x8055f8		8401				TESTB AL, 0(CX)											
  module.go:62926		0x8055fa		4883c130			ADDQ $0x30, CX											
  zz_adapter.go:11		0x8055fe		488b4908			MOVQ 0x8(CX), CX										
  zz_adapter.go:11		0x805602		48898c2480000000		MOVQ CX, 0x80(SP)										
  phase0_scaffold_test.go:48	0x80560a		488b942490000000		MOVQ 0x90(SP), DX										
  phase0_scaffold_test.go:48	0x805612		4883fa06			CMPQ DX, $0x6											
  phase0_scaffold_test.go:52	0x805616		751b				JNE 0x805633											
  phase0_scaffold_test.go:52	0x805618		488b9424a0000000		MOVQ 0xa0(SP), DX										
  phase0_scaffold_test.go:52	0x805620		813a4f726163			CMPL 0(DX), $0x6361724f										
  phase0_scaffold_test.go:52	0x805626		750b				JNE 0x805633											
  phase0_scaffold_test.go:52	0x805628		66817a046c65			CMPW 0x4(DX), $0x656c										
  phase0_scaffold_test.go:52	0x80562e		0f94c2				SETE DL												
  phase0_scaffold_test.go:52	0x805631		eb02				JMP 0x805635											
  phase0_scaffold_test.go:52	0x805633		31d2				XORL DX, DX											
  phase0_scaffold_test.go:52	0x805635		881532a55000			MOVB DL, dario.cat/cocoon/examples/datadog/go/dd.phase0TransportMode(SB)			
  phase0_scaffold_test.go:53	0x80563b		48c784248800000000000000	MOVQ $0x0, 0x88(SP)										
  phase0_scaffold_test.go:54	0x805647		488b8c2428010000		MOVQ 0x128(SP), CX										
  benchmark.go:193		0x80564f		c6815202000001			MOVB $0x1, 0x252(CX)										
  phase0_scaffold_test.go:55	0x805656		488b9c2428010000		MOVQ 0x128(SP), BX										
  phase0_scaffold_test.go:55	0x80565e		488d05cb461100			LEAQ go:itab.*testing.B,testing.TB(SB), AX							
  phase0_scaffold_test.go:55	0x805665		e8f6cdffff			CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportActual(SB)				
  phase0_scaffold_test.go:56	0x80566a		488b842428010000		MOVQ 0x128(SP), AX										
  phase0_scaffold_test.go:56	0x805672		e8a960d0ff			CALL testing.(*B).ResetTimer(SB)								
  phase0_scaffold_test.go:57	0x805677		488b842428010000		MOVQ 0x128(SP), AX										
  benchmark.go:515		0x80567f		488b88c0020000			MOVQ 0x2c0(AX), CX										
  benchmark.go:515		0x805686		483988b8020000			CMPQ 0x2b8(AX), CX										
  benchmark.go:515		0x80568d		7613				JBE 0x8056a2											
  benchmark.go:516		0x80568f		48ffc1				INCQ CX												
  benchmark.go:516		0x805692		488988c0020000			MOVQ CX, 0x2c0(AX)										
  benchmark.go:516		0x805699		b801000000			MOVL $0x1, AX											
  benchmark.go:516		0x80569e		6690				NOPW												
  phase0_scaffold_test.go:57	0x8056a0		eb05				JMP 0x8056a7											
  benchmark.go:519		0x8056a2		e81971d0ff			CALL testing.(*B).loopSlowPath(SB)								
  phase0_scaffold_test.go:57	0x8056a7		84c0				TESTL AL, AL											
  phase0_scaffold_test.go:57	0x8056a9		0f84b0000000			JE 0x80575f											
  phase0_scaffold_test.go:58	0x8056af		f20f108c2488000000		MOVSD_XMM 0x88(SP), X1										
  phase0_scaffold_test.go:58	0x8056b8		f20f101548541000		MOVSD_XMM $f64.3ff0000000000000(SB), X2								
  phase0_scaffold_test.go:58	0x8056c0		f20f58ca			ADDSD X2, X1											
  phase0_scaffold_test.go:58	0x8056c4		f20f118c2488000000		MOVSD_XMM X1, 0x88(SP)										
  phase0_scaffold_test.go:59	0x8056cd		0fb61d99a45000			MOVZX dario.cat/cocoon/examples/datadog/go/dd.phase0TransportMode(SB), BX			
  phase0_scaffold_test.go:59	0x8056d4		f20f10842488000000		MOVSD_XMM 0x88(SP), X0										
  phase0_scaffold_test.go:59	0x8056dd		488b842498000000		MOVQ 0x98(SP), AX										
  phase0_scaffold_test.go:59	0x8056e5		e876b7fdff			CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportAdd(SB)				
  phase0_scaffold_test.go:59	0x8056ea		48898424a8000000		MOVQ AX, 0xa8(SP)										
  phase0_scaffold_test.go:59	0x8056f2		48899c24b0000000		MOVQ BX, 0xb0(SP)										
  phase0_scaffold_test.go:59	0x8056fa		660f1f440000			NOPW 0(AX)(AX*1)										
  phase0_scaffold_test.go:59	0x805700		4885c0				TESTQ AX, AX											
  phase0_scaffold_test.go:59	0x805703		0f846effffff			JE 0x805677											
  phase0_scaffold_test.go:60	0x805709		440f11bc2400010000		MOVUPS X15, 0x100(SP)										
  phase0_scaffold_test.go:60	0x805712		488b9424a8000000		MOVQ 0xa8(SP), DX										
  phase0_scaffold_test.go:60	0x80571a		4885d2				TESTQ DX, DX											
  phase0_scaffold_test.go:60	0x80571d		7404				JE 0x805723											
  phase0_scaffold_test.go:60	0x80571f		488b5208			MOVQ 0x8(DX), DX										
  phase0_scaffold_test.go:60	0x805723		488bb424b0000000		MOVQ 0xb0(SP), SI										
  phase0_scaffold_test.go:60	0x80572b		4889942400010000		MOVQ DX, 0x100(SP)										
  phase0_scaffold_test.go:60	0x805733		4889b42408010000		MOVQ SI, 0x108(SP)										
  phase0_scaffold_test.go:60	0x80573b		488b842428010000		MOVQ 0x128(SP), AX										
  phase0_scaffold_test.go:60	0x805743		8400				TESTB AL, 0(AX)											
  phase0_scaffold_test.go:60	0x805745		488d9c2400010000		LEAQ 0x100(SP), BX										
  phase0_scaffold_test.go:60	0x80574d		b901000000			MOVL $0x1, CX											
  phase0_scaffold_test.go:60	0x805752		4889cf				MOVQ CX, DI											
  phase0_scaffold_test.go:60	0x805755		e86648d1ff			CALL testing.(*common).Fatal(SB)								
  phase0_scaffold_test.go:60	0x80575a		e918ffffff			JMP 0x805677											
  phase0_scaffold_test.go:63	0x80575f		488b842428010000		MOVQ 0x128(SP), AX										
  phase0_scaffold_test.go:63	0x805767		e8f45ed0ff			CALL testing.(*B).StopTimer(SB)									
  phase0_scaffold_test.go:64	0x80576c		488b9c2428010000		MOVQ 0x128(SP), BX										
  phase0_scaffold_test.go:64	0x805774		488d05b5451100			LEAQ go:itab.*testing.B,testing.TB(SB), AX							
  phase0_scaffold_test.go:64	0x80577b		0f1f440000			NOPL 0(AX)(AX*1)										
  phase0_scaffold_test.go:64	0x805780		e8dbccffff			CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportActual(SB)				
  phase0_scaffold_test.go:65	0x805785		488b9c2498000000		MOVQ 0x98(SP), BX										
  phase0_scaffold_test.go:65	0x80578d		488b4b08			MOVQ 0x8(BX), CX										
  phase0_scaffold_test.go:65	0x805791		488b09				MOVQ 0(CX), CX											
  phase0_scaffold_test.go:66	0x805794		488b842428010000		MOVQ 0x128(SP), AX										
  phase0_scaffold_test.go:66	0x80579c		488b9010020000			MOVQ 0x210(AX), DX										
  zz_adapter.go:11		0x8057a3		488b09				MOVQ 0(CX), CX											
  module.go:62926		0x8057a6		8401				TESTB AL, 0(CX)											
  module.go:62926		0x8057a8		4883c130			ADDQ $0x30, CX											
  zz_adapter.go:11		0x8057ac		488b4908			MOVQ 0x8(CX), CX										
  zz_adapter.go:11		0x8057b0		48894c2478			MOVQ CX, 0x78(SP)										
  phase0_scaffold_test.go:66	0x8057b5		4889d1				MOVQ DX, CX											
  phase0_scaffold_test.go:66	0x8057b8		e863dfffff			CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportAdaptiveWitness(SB)			
  phase0_scaffold_test.go:66	0x8057bd		48898424b8000000		MOVQ AX, 0xb8(SP)										
  phase0_scaffold_test.go:66	0x8057c5		48899c24c0000000		MOVQ BX, 0xc0(SP)										
  phase0_scaffold_test.go:66	0x8057cd		48898c24c8000000		MOVQ CX, 0xc8(SP)										
  phase0_scaffold_test.go:66	0x8057d5		4889bc24d0000000		MOVQ DI, 0xd0(SP)										
  phase0_scaffold_test.go:66	0x8057dd		4889b424d8000000		MOVQ SI, 0xd8(SP)										
  phase0_scaffold_test.go:66	0x8057e5		4c898424e0000000		MOVQ R8, 0xe0(SP)										
  phase0_scaffold_test.go:66	0x8057ed		4c898c24e8000000		MOVQ R9, 0xe8(SP)										
  phase0_scaffold_test.go:66	0x8057f5		4c899424f0000000		MOVQ R10, 0xf0(SP)										
  phase0_scaffold_test.go:66	0x8057fd		4c899c24f8000000		MOVQ R11, 0xf8(SP)										
  phase0_scaffold_test.go:67	0x805805		488b842428010000		MOVQ 0x128(SP), AX										
  phase0_scaffold_test.go:67	0x80580d		488bb010020000			MOVQ 0x210(AX), SI										
  phase0_scaffold_test.go:67	0x805814		4889e1				MOVQ SP, CX											
  phase0_scaffold_test.go:67	0x805817		488d9424b8000000		LEAQ 0xb8(SP), DX										
  phase0_scaffold_test.go:67	0x80581f		440f1032			MOVUPS 0(DX), X14										
  phase0_scaffold_test.go:67	0x805823		440f1131			MOVUPS X14, 0(CX)										
  phase0_scaffold_test.go:67	0x805827		440f107210			MOVUPS 0x10(DX), X14										
  phase0_scaffold_test.go:67	0x80582c		440f117110			MOVUPS X14, 0x10(CX)										
  phase0_scaffold_test.go:67	0x805831		440f107220			MOVUPS 0x20(DX), X14										
  phase0_scaffold_test.go:67	0x805836		440f117120			MOVUPS X14, 0x20(CX)										
  phase0_scaffold_test.go:67	0x80583b		440f107230			MOVUPS 0x30(DX), X14										
  phase0_scaffold_test.go:67	0x805840		440f117130			MOVUPS X14, 0x30(CX)										
  phase0_scaffold_test.go:67	0x805845		440f107238			MOVUPS 0x38(DX), X14										
  phase0_scaffold_test.go:67	0x80584a		440f117138			MOVUPS X14, 0x38(CX)										
  phase0_scaffold_test.go:67	0x80584f		488b9c2498000000		MOVQ 0x98(SP), BX										
  phase0_scaffold_test.go:67	0x805857		488b7c2478			MOVQ 0x78(SP), DI										
  phase0_scaffold_test.go:67	0x80585c		488b8c2480000000		MOVQ 0x80(SP), CX										
  phase0_scaffold_test.go:67	0x805864		e8d7ccffff			CALL dario.cat/cocoon/examples/datadog/go/dd.phase0TransportMetrics(SB)				
  phase0_scaffold_test.go:68	0x805869		c644247700			MOVB $0x0, 0x77(SP)										
  phase0_scaffold_test.go:68	0x80586e		488b942410010000		MOVQ 0x110(SP), DX										
  phase0_scaffold_test.go:68	0x805876		488b0a				MOVQ 0(DX), CX											
  phase0_scaffold_test.go:68	0x805879		ffd1				CALL CX												
  phase0_scaffold_test.go:68	0x80587b		4881c418010000			ADDQ $0x118, SP											
  phase0_scaffold_test.go:68	0x805882		5d				POPQ BP												
  phase0_scaffold_test.go:68	0x805883		c3				RET												
  phase0_scaffold_test.go:68	0x805884		e8b782c4ff			CALL runtime.deferreturn(SB)									
  phase0_scaffold_test.go:68	0x805889		4881c418010000			ADDQ $0x118, SP											
  phase0_scaffold_test.go:68	0x805890		5d				POPQ BP												
  phase0_scaffold_test.go:68	0x805891		c3				RET												
  phase0_scaffold_test.go:48	0x805892		4889442408			MOVQ AX, 0x8(SP)										
  phase0_scaffold_test.go:48	0x805897		e86493c8ff			CALL runtime.morestack.abi0(SB)									
  phase0_scaffold_test.go:48	0x80589c		488b442408			MOVQ 0x8(SP), AX										
  phase0_scaffold_test.go:48	0x8058a1		e9bafcffff			JMP dario.cat/cocoon/examples/datadog/go/dd.BenchmarkPhase0TransportScaffoldAdaptive.func1(SB)	
