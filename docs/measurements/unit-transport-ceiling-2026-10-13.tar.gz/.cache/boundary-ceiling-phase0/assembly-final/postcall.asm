TEXT dario.cat/cocoon/rt.(*Instance).Call(SB) /home/dario/Code/cocoon/rt/instance.go
  instance.go:158	0x5c7ae0		4c8d6424d0		LEAQ -0x30(SP), R12						
  instance.go:158	0x5c7ae5		4d3b6610		CMPQ R12, 0x10(R14)						
  instance.go:158	0x5c7ae9		0f86ac030000		JBE 0x5c7e9b							
  instance.go:158	0x5c7aef		55			PUSHQ BP							
  instance.go:158	0x5c7af0		4889e5			MOVQ SP, BP							
  instance.go:158	0x5c7af3		4881eca8000000		SUBQ $0xa8, SP							
  instance.go:158	0x5c7afa		440f11bc2498000000	MOVUPS X15, 0x98(SP)						
  mutex.go:63		0x5c7b03		48898424b8000000	MOVQ AX, 0xb8(SP)						
  mutex.go:63		0x5c7b0b		48898c24c8000000	MOVQ CX, 0xc8(SP)						
  mutex.go:63		0x5c7b13		48899c24c0000000	MOVQ BX, 0xc0(SP)						
  instance.go:158	0x5c7b1b		c644242f00		MOVB $0x0, 0x2f(SP)						
  instance.go:158	0x5c7b20		440f117c2430		MOVUPS X15, 0x30(SP)						
  instance.go:159	0x5c7b26		90			NOPL								
  mutex.go:63		0x5c7b27		4889c2			MOVQ AX, DX							
  mutex.go:63		0x5c7b2a		31c0			XORL AX, AX							
  mutex.go:63		0x5c7b2c		be01000000		MOVL $0x1, SI							
  mutex.go:63		0x5c7b31		f00fb17250		LOCK CMPXCHGL SI, 0x50(DX)					
  mutex.go:63		0x5c7b36		400f94c6		SETE SI								
  mutex.go:63		0x5c7b3a		4084f6			TESTL SI, SI							
  mutex.go:63		0x5c7b3d		7531			JNE 0x5c7b70							
  mutex.go:63		0x5c7b3f		4889bc24d0000000	MOVQ DI, 0xd0(SP)						
  mutex.go:46		0x5c7b47		488d4250		LEAQ 0x50(DX), AX						
  mutex.go:70		0x5c7b4b		e8f004edff		CALL internal/sync.(*Mutex).lockSlow(SB)			
  instance.go:168	0x5c7b50		488b8c24c8000000	MOVQ 0xc8(SP), CX						
  instance.go:160	0x5c7b58		488b9424b8000000	MOVQ 0xb8(SP), DX						
  instance.go:168	0x5c7b60		488b9c24c0000000	MOVQ 0xc0(SP), BX						
  instance.go:182	0x5c7b68		488bbc24d0000000	MOVQ 0xd0(SP), DI						
  instance.go:160	0x5c7b70		488d3569040000		LEAQ dario.cat/cocoon/rt.(*Instance).Call.deferwrap1(SB), SI	
  instance.go:160	0x5c7b77		4889b42488000000	MOVQ SI, 0x88(SP)						
  instance.go:160	0x5c7b7f		488d7250		LEAQ 0x50(DX), SI						
  instance.go:160	0x5c7b83		4889b42490000000	MOVQ SI, 0x90(SP)						
  instance.go:160	0x5c7b8b		488db42488000000	LEAQ 0x88(SP), SI						
  instance.go:160	0x5c7b93		4889b42498000000	MOVQ SI, 0x98(SP)						
  instance.go:160	0x5c7b9b		c644242f01		MOVB $0x1, 0x2f(SP)						
  instance.go:161	0x5c7ba0		0fb6725c		MOVZX 0x5c(DX), SI						
  instance.go:166	0x5c7ba4		4084f6			TESTL SI, SI							
  instance.go:166	0x5c7ba7		7414			JE 0x5c7bbd							
  instance.go:164	0x5c7ba9		4080fe01		CMPL SI, $0x1							
  instance.go:164	0x5c7bad		0f8493020000		JE 0x5c7e46							
  instance.go:162	0x5c7bb3		4080fe02		CMPL SI, $0x2							
  instance.go:162	0x5c7bb7		0f844c020000		JE 0x5c7e09							
  instance.go:168	0x5c7bbd		488d351c030000		LEAQ dario.cat/cocoon/rt.(*Instance).Call.func1(SB), SI		
  instance.go:168	0x5c7bc4		4889742460		MOVQ SI, 0x60(SP)						
  instance.go:168	0x5c7bc9		4889542468		MOVQ DX, 0x68(SP)						
  instance.go:168	0x5c7bce		488d742430		LEAQ 0x30(SP), SI						
  instance.go:168	0x5c7bd3		4889742470		MOVQ SI, 0x70(SP)						
  instance.go:168	0x5c7bd8		48898c2480000000	MOVQ CX, 0x80(SP)						
  instance.go:168	0x5c7be0		48895c2478		MOVQ BX, 0x78(SP)						
  instance.go:168	0x5c7be5		488d742460		LEAQ 0x60(SP), SI						
  instance.go:168	0x5c7bea		4889b424a0000000	MOVQ SI, 0xa0(SP)						
  instance.go:168	0x5c7bf2		c644242f03		MOVB $0x3, 0x2f(SP)						
  instance.go:178	0x5c7bf7		488b7210		MOVQ 0x10(DX), SI						
  instance.go:178	0x5c7bfb		0f1f440000		NOPL 0(AX)(AX*1)						
  instance.go:178	0x5c7c00		4885f6			TESTQ SI, SI							
  instance.go:178	0x5c7c03		742b			JE 0x5c7c30							
  instance.go:179	0x5c7c05		90			NOPL								
  host.go:90		0x5c7c06		48c7463800000000	MOVQ $0x0, 0x38(SI)						
  host.go:90		0x5c7c0e		833d5b85740000		CMPL runtime.writeBarrier(SB), $0x0				
  host.go:90		0x5c7c15		7411			JE 0x5c7c28							
  host.go:90		0x5c7c17		4c8b4630		MOVQ 0x30(SI), R8						
  host.go:90		0x5c7c1b		0f1f440000		NOPL 0(AX)(AX*1)						
  host.go:90		0x5c7c20		e8db89ecff		CALL runtime.gcWriteBarrier1(SB)				
  host.go:90		0x5c7c25		4d8903			MOVQ R8, 0(R11)							
  host.go:90		0x5c7c28		48c7463000000000	MOVQ $0x0, 0x30(SI)						
  instance.go:181	0x5c7c30		c7422000000000		MOVL $0x0, 0x20(DX)						
  instance.go:181	0x5c7c37		48c7422400000000	MOVQ $0x0, 0x24(DX)						
  instance.go:181	0x5c7c3f		833d2a85740000		CMPL runtime.writeBarrier(SB), $0x0				
  instance.go:181	0x5c7c46		7410			JE 0x5c7c58							
  instance.go:181	0x5c7c48		488b7218		MOVQ 0x18(DX), SI						
  instance.go:181	0x5c7c4c		e8cf89ecff		CALL runtime.gcWriteBarrier2(SB)				
  instance.go:181	0x5c7c51		498913			MOVQ DX, 0(R11)							
  instance.go:181	0x5c7c54		49897308		MOVQ SI, 0x8(R11)						
  instance.go:181	0x5c7c58		48895218		MOVQ DX, 0x18(DX)						
  instance.go:182	0x5c7c5c		488b0f			MOVQ 0(DI), CX							
  instance.go:182	0x5c7c5f		488d4218		LEAQ 0x18(DX), AX						
  instance.go:182	0x5c7c63		4889fa			MOVQ DI, DX							
  instance.go:182	0x5c7c66		ffd1			CALL CX								
  instance.go:182	0x5c7c68		4889442430		MOVQ AX, 0x30(SP)						
  instance.go:182	0x5c7c6d		48895c2438		MOVQ BX, 0x38(SP)						
  instance.go:183	0x5c7c72		488b8c24b8000000	MOVQ 0xb8(SP), CX						
  instance.go:183	0x5c7c7a		488b19			MOVQ 0(CX), BX							
  instance.go:183	0x5c7c7d		488b4108		MOVQ 0x8(CX), AX						
  instance.go:183	0x5c7c81		488b4b20		MOVQ 0x20(BX), CX						
  instance.go:183	0x5c7c85		ffd1			CALL CX								
  instance.go:183	0x5c7c87		488b8c24b8000000	MOVQ 0xb8(SP), CX						
  instance.go:183	0x5c7c8f		48395940		CMPQ 0x40(CX), BX						
  instance.go:183	0x5c7c93		727c			JB 0x5c7d11							
  instance.go:187	0x5c7c95		488b442430		MOVQ 0x30(SP), AX						
  instance.go:187	0x5c7c9a		4885c0			TESTQ AX, AX							
  instance.go:187	0x5c7c9d		743b			JE 0x5c7cda							
  instance.go:187	0x5c7c9f		488b5c2438		MOVQ 0x38(SP), BX						
  instance.go:187	0x5c7ca4		488b0d956b7100		MOVQ dario.cat/cocoon/rt.ErrProtocol(SB), CX			
  instance.go:187	0x5c7cab		488b3d966b7100		MOVQ dario.cat/cocoon/rt.ErrProtocol+8(SB), DI			
  instance.go:187	0x5c7cb2		e869f6ecff		CALL errors.Is(SB)						
  instance.go:187	0x5c7cb7		84c0			TESTL AL, AL							
  instance.go:187	0x5c7cb9		741f			JE 0x5c7cda							
  instance.go:188	0x5c7cbb		90			NOPL								
  instance.go:230	0x5c7cbc		90			NOPL								
  type.go:22		0x5c7cbd		31c0			XORL AX, AX							
  type.go:22		0x5c7cbf		488b8c24b8000000	MOVQ 0xb8(SP), CX						
  type.go:22		0x5c7cc7		874158			XCHGL AX, 0x58(CX)						
  instance.go:231	0x5c7cca		c6415c01		MOVB $0x1, 0x5c(CX)						
  instance.go:232	0x5c7cce		90			NOPL								
  type.go:195		0x5c7ccf		b801000000		MOVL $0x1, AX							
  type.go:195		0x5c7cd4		f0480fc14148		LOCK XADDQ AX, 0x48(CX)						
  instance.go:190	0x5c7cda		c644242f01		MOVB $0x1, 0x2f(SP)						
  instance.go:190	0x5c7cdf		488b9424a0000000	MOVQ 0xa0(SP), DX						
  instance.go:190	0x5c7ce7		488b02			MOVQ 0(DX), AX							
  instance.go:190	0x5c7cea		ffd0			CALL AX								
  instance.go:190	0x5c7cec		c644242f00		MOVB $0x0, 0x2f(SP)						
  instance.go:190	0x5c7cf1		488b942498000000	MOVQ 0x98(SP), DX						
  instance.go:190	0x5c7cf9		488b02			MOVQ 0(DX), AX							
  instance.go:190	0x5c7cfc		ffd0			CALL AX								
  instance.go:190	0x5c7cfe		488b442430		MOVQ 0x30(SP), AX						
  instance.go:190	0x5c7d03		488b5c2438		MOVQ 0x38(SP), BX						
  instance.go:190	0x5c7d08		4881c4a8000000		ADDQ $0xa8, SP							
  instance.go:190	0x5c7d0f		5d			POPQ BP								
  instance.go:190	0x5c7d10		c3			RET								
  instance.go:184	0x5c7d11		90			NOPL								
  instance.go:230	0x5c7d12		90			NOPL								
  type.go:22		0x5c7d13		31d2			XORL DX, DX							
  type.go:22		0x5c7d15		875158			XCHGL DX, 0x58(CX)						
  instance.go:231	0x5c7d18		c6415c01		MOVB $0x1, 0x5c(CX)						
  type.go:195		0x5c7d1c		ba01000000		MOVL $0x1, DX							
  type.go:195		0x5c7d21		f0480fc15148		LOCK XADDQ DX, 0x48(CX)						
  instance.go:185	0x5c7d27		488d4c2440		LEAQ 0x40(SP), CX						
  instance.go:185	0x5c7d2c		440f1139		MOVUPS X15, 0(CX)						
  instance.go:185	0x5c7d30		440f117910		MOVUPS X15, 0x10(CX)						
  instance.go:185	0x5c7d35		488b8424c0000000	MOVQ 0xc0(SP), AX						
  instance.go:185	0x5c7d3d		488b9c24c8000000	MOVQ 0xc8(SP), BX						
  instance.go:185	0x5c7d45		e836e7ebff		CALL runtime.convTstring(SB)					
  instance.go:185	0x5c7d4a		488d0dafae2800		LEAQ 0x28aeaf(IP), CX						
  instance.go:185	0x5c7d51		48894c2440		MOVQ CX, 0x40(SP)						
  instance.go:185	0x5c7d56		4889442448		MOVQ AX, 0x48(SP)						
  instance.go:185	0x5c7d5b		488b0dae6a7100		MOVQ dario.cat/cocoon/rt.ErrTooLarge(SB), CX			
  instance.go:185	0x5c7d62		4885c9			TESTQ CX, CX							
  instance.go:232	0x5c7d65		7404			JE 0x5c7d6b							
  instance.go:185	0x5c7d67		488b4908		MOVQ 0x8(CX), CX						
  instance.go:185	0x5c7d6b		488b15a66a7100		MOVQ dario.cat/cocoon/rt.ErrTooLarge+8(SB), DX			
  instance.go:185	0x5c7d72		48894c2450		MOVQ CX, 0x50(SP)						
  instance.go:185	0x5c7d77		4889542458		MOVQ DX, 0x58(SP)						
  errors.go:26		0x5c7d7c		488d05bd873200		LEAQ 0x3287bd(IP), AX						
  errors.go:26		0x5c7d83		bb26000000		MOVL $0x26, BX							
  errors.go:26		0x5c7d88		488d4c2440		LEAQ 0x40(SP), CX						
  errors.go:26		0x5c7d8d		bf02000000		MOVL $0x2, DI							
  errors.go:26		0x5c7d92		4889fe			MOVQ DI, SI							
  errors.go:26		0x5c7d95		e8e64ef2ff		CALL fmt.errorf(SB)						
  errors.go:26		0x5c7d9a		4885c0			TESTQ AX, AX							
  errors.go:26		0x5c7d9d		7529			JNE 0x5c7dc8							
  errors.go:31		0x5c7d9f		90			NOPL								
  errors.go:65		0x5c7da0		488d05f9012b00		LEAQ 0x2b01f9(IP), AX						
  errors.go:65		0x5c7da7		e874a4e5ff		CALL runtime.newobject(SB)					
  errors.go:65		0x5c7dac		48c7400826000000	MOVQ $0x26, 0x8(AX)						
  errors.go:65		0x5c7db4		488d0d85873200		LEAQ 0x328785(IP), CX						
  errors.go:65		0x5c7dbb		488908			MOVQ CX, 0(AX)							
  instance.go:185	0x5c7dbe		4889c3			MOVQ AX, BX							
  instance.go:185	0x5c7dc1		488d0550613400		LEAQ go:itab.*errors.errorString,error(SB), AX			
  instance.go:185	0x5c7dc8		4889442430		MOVQ AX, 0x30(SP)						
  instance.go:185	0x5c7dcd		48895c2438		MOVQ BX, 0x38(SP)						
  instance.go:185	0x5c7dd2		c644242f01		MOVB $0x1, 0x2f(SP)						
  instance.go:185	0x5c7dd7		488b9424a0000000	MOVQ 0xa0(SP), DX						
  instance.go:185	0x5c7ddf		488b02			MOVQ 0(DX), AX							
  instance.go:185	0x5c7de2		ffd0			CALL AX								
  instance.go:185	0x5c7de4		c644242f00		MOVB $0x0, 0x2f(SP)						
  instance.go:185	0x5c7de9		488b942498000000	MOVQ 0x98(SP), DX						
  instance.go:185	0x5c7df1		488b02			MOVQ 0(DX), AX							
  instance.go:185	0x5c7df4		ffd0			CALL AX								
  instance.go:185	0x5c7df6		488b442430		MOVQ 0x30(SP), AX						
  instance.go:185	0x5c7dfb		488b5c2438		MOVQ 0x38(SP), BX						
  instance.go:185	0x5c7e00		4881c4a8000000		ADDQ $0xa8, SP							
  instance.go:185	0x5c7e07		5d			POPQ BP								
  instance.go:185	0x5c7e08		c3			RET								
  instance.go:163	0x5c7e09		488b05e0697100		MOVQ dario.cat/cocoon/rt.ErrClosed(SB), AX			
  instance.go:163	0x5c7e10		488b0de1697100		MOVQ dario.cat/cocoon/rt.ErrClosed+8(SB), CX			
  instance.go:163	0x5c7e17		4889442430		MOVQ AX, 0x30(SP)						
  instance.go:163	0x5c7e1c		48894c2438		MOVQ CX, 0x38(SP)						
  instance.go:163	0x5c7e21		c644242f00		MOVB $0x0, 0x2f(SP)						
  instance.go:163	0x5c7e26		488b942498000000	MOVQ 0x98(SP), DX						
  instance.go:163	0x5c7e2e		488b02			MOVQ 0(DX), AX							
  instance.go:163	0x5c7e31		ffd0			CALL AX								
  instance.go:163	0x5c7e33		488b442430		MOVQ 0x30(SP), AX						
  instance.go:163	0x5c7e38		488b5c2438		MOVQ 0x38(SP), BX						
  instance.go:163	0x5c7e3d		4881c4a8000000		ADDQ $0xa8, SP							
  instance.go:163	0x5c7e44		5d			POPQ BP								
  instance.go:163	0x5c7e45		c3			RET								
  instance.go:165	0x5c7e46		488b05b3697100		MOVQ dario.cat/cocoon/rt.ErrPoisoned(SB), AX			
  instance.go:165	0x5c7e4d		488b0db4697100		MOVQ dario.cat/cocoon/rt.ErrPoisoned+8(SB), CX			
  instance.go:165	0x5c7e54		4889442430		MOVQ AX, 0x30(SP)						
  instance.go:165	0x5c7e59		48894c2438		MOVQ CX, 0x38(SP)						
  instance.go:165	0x5c7e5e		c644242f00		MOVB $0x0, 0x2f(SP)						
  instance.go:165	0x5c7e63		488b942498000000	MOVQ 0x98(SP), DX						
  instance.go:165	0x5c7e6b		488b02			MOVQ 0(DX), AX							
  instance.go:165	0x5c7e6e		ffd0			CALL AX								
  instance.go:165	0x5c7e70		488b442430		MOVQ 0x30(SP), AX						
  instance.go:165	0x5c7e75		488b5c2438		MOVQ 0x38(SP), BX						
  instance.go:165	0x5c7e7a		4881c4a8000000		ADDQ $0xa8, SP							
  instance.go:165	0x5c7e81		5d			POPQ BP								
  instance.go:165	0x5c7e82		c3			RET								
  instance.go:165	0x5c7e83		e8b85ce8ff		CALL runtime.deferreturn(SB)					
  instance.go:165	0x5c7e88		488b442430		MOVQ 0x30(SP), AX						
  instance.go:165	0x5c7e8d		488b5c2438		MOVQ 0x38(SP), BX						
  instance.go:165	0x5c7e92		4881c4a8000000		ADDQ $0xa8, SP							
  instance.go:165	0x5c7e99		5d			POPQ BP								
  instance.go:165	0x5c7e9a		c3			RET								
  instance.go:158	0x5c7e9b		4889442408		MOVQ AX, 0x8(SP)						
  instance.go:158	0x5c7ea0		48895c2410		MOVQ BX, 0x10(SP)						
  instance.go:158	0x5c7ea5		48894c2418		MOVQ CX, 0x18(SP)						
  instance.go:158	0x5c7eaa		48897c2420		MOVQ DI, 0x20(SP)						
  instance.go:158	0x5c7eaf		e8ec6decff		CALL runtime.morestack_noctxt.abi0(SB)				
  instance.go:158	0x5c7eb4		488b442408		MOVQ 0x8(SP), AX						
  instance.go:158	0x5c7eb9		488b5c2410		MOVQ 0x10(SP), BX						
  instance.go:158	0x5c7ebe		488b4c2418		MOVQ 0x18(SP), CX						
  instance.go:158	0x5c7ec3		488b7c2420		MOVQ 0x20(SP), DI						
  instance.go:158	0x5c7ec8		e913fcffff		JMP dario.cat/cocoon/rt.(*Instance).Call(SB)			
