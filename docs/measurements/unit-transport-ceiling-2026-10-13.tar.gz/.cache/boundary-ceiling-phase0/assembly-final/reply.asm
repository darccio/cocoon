TEXT dario.cat/cocoon/rt.(*Call).Phase0UnitReply(SB) /home/dario/Code/cocoon/rt/phase0_unit_transport.go
  phase0_unit_transport.go:5	0x5c8c80		493b6610		CMPQ SP, 0x10(R14)					
  phase0_unit_transport.go:5	0x5c8c84		766e			JBE 0x5c8cf4						
  phase0_unit_transport.go:5	0x5c8c86		55			PUSHQ BP						
  phase0_unit_transport.go:5	0x5c8c87		4889e5			MOVQ SP, BP						
  phase0_unit_transport.go:5	0x5c8c8a		4883ec20		SUBQ $0x20, SP						
  phase0_unit_transport.go:5	0x5c8c8e		48895c2438		MOVQ BX, 0x38(SP)					
  phase0_unit_transport.go:6	0x5c8c93		4084f6			TESTL SI, SI						
  phase0_unit_transport.go:6	0x5c8c96		741e			JE 0x5c8cb6						
  phase0_unit_transport.go:6	0x5c8c98		85ff			TESTL DI, DI						
  phase0_unit_transport.go:6	0x5c8c9a		751a			JNE 0x5c8cb6						
  phase0_unit_transport.go:7	0x5c8c9c		488b08			MOVQ 0(AX), CX						
  phase0_unit_transport.go:7	0x5c8c9f		488b11			MOVQ 0(CX), DX						
  phase0_unit_transport.go:7	0x5c8ca2		488b4108		MOVQ 0x8(CX), AX					
  phase0_unit_transport.go:7	0x5c8ca6		488b4a20		MOVQ 0x20(DX), CX					
  phase0_unit_transport.go:7	0x5c8caa		ffd1			CALL CX							
  phase0_unit_transport.go:8	0x5c8cac		31c0			XORL AX, AX						
  phase0_unit_transport.go:8	0x5c8cae		31db			XORL BX, BX						
  phase0_unit_transport.go:8	0x5c8cb0		4883c420		ADDQ $0x20, SP						
  phase0_unit_transport.go:8	0x5c8cb4		5d			POPQ BP							
  phase0_unit_transport.go:8	0x5c8cb5		c3			RET							
  phase0_unit_transport.go:10	0x5c8cb6		e865f9ffff		CALL dario.cat/cocoon/rt.(*Call).ResultView(SB)		
  phase0_unit_transport.go:10	0x5c8cbb		0f1f440000		NOPL 0(AX)(AX*1)					
  phase0_unit_transport.go:11	0x5c8cc0		4885ff			TESTQ DI, DI						
  phase0_unit_transport.go:11	0x5c8cc3		7523			JNE 0x5c8ce8						
  phase0_unit_transport.go:14	0x5c8cc5		4885db			TESTQ BX, BX						
  phase0_unit_transport.go:14	0x5c8cc8		7414			JE 0x5c8cde						
  phase0_unit_transport.go:15	0x5c8cca		488b056f5b7100		MOVQ dario.cat/cocoon/rt.ErrProtocol(SB), AX		
  phase0_unit_transport.go:15	0x5c8cd1		488b1d705b7100		MOVQ dario.cat/cocoon/rt.ErrProtocol+8(SB), BX		
  phase0_unit_transport.go:15	0x5c8cd8		4883c420		ADDQ $0x20, SP						
  phase0_unit_transport.go:15	0x5c8cdc		5d			POPQ BP							
  phase0_unit_transport.go:15	0x5c8cdd		c3			RET							
  phase0_unit_transport.go:17	0x5c8cde		31c0			XORL AX, AX						
  phase0_unit_transport.go:17	0x5c8ce0		31db			XORL BX, BX						
  phase0_unit_transport.go:17	0x5c8ce2		4883c420		ADDQ $0x20, SP						
  phase0_unit_transport.go:17	0x5c8ce6		5d			POPQ BP							
  phase0_unit_transport.go:17	0x5c8ce7		c3			RET							
  phase0_unit_transport.go:12	0x5c8ce8		4889f8			MOVQ DI, AX						
  phase0_unit_transport.go:12	0x5c8ceb		4889f3			MOVQ SI, BX						
  phase0_unit_transport.go:12	0x5c8cee		4883c420		ADDQ $0x20, SP						
  phase0_unit_transport.go:12	0x5c8cf2		5d			POPQ BP							
  phase0_unit_transport.go:12	0x5c8cf3		c3			RET							
  phase0_unit_transport.go:5	0x5c8cf4		4889442408		MOVQ AX, 0x8(SP)					
  phase0_unit_transport.go:5	0x5c8cf9		48895c2410		MOVQ BX, 0x10(SP)					
  phase0_unit_transport.go:5	0x5c8cfe		48894c2418		MOVQ CX, 0x18(SP)					
  phase0_unit_transport.go:5	0x5c8d03		897c2420		MOVL DI, 0x20(SP)					
  phase0_unit_transport.go:5	0x5c8d07		4088742424		MOVB SI, 0x24(SP)					
  phase0_unit_transport.go:5	0x5c8d0c		e88f5fecff		CALL runtime.morestack_noctxt.abi0(SB)			
  phase0_unit_transport.go:5	0x5c8d11		488b442408		MOVQ 0x8(SP), AX					
  phase0_unit_transport.go:5	0x5c8d16		488b5c2410		MOVQ 0x10(SP), BX					
  phase0_unit_transport.go:5	0x5c8d1b		488b4c2418		MOVQ 0x18(SP), CX					
  phase0_unit_transport.go:5	0x5c8d20		8b7c2420		MOVL 0x20(SP), DI					
  phase0_unit_transport.go:5	0x5c8d24		0fb6742424		MOVZX 0x24(SP), SI					
  phase0_unit_transport.go:5	0x5c8d29		e952ffffff		JMP dario.cat/cocoon/rt.(*Call).Phase0UnitReply(SB)	
