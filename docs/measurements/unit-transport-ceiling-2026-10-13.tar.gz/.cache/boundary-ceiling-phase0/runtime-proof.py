from pathlib import Path
import os,subprocess,json,datetime,hashlib
root=Path.cwd();out=root/'.cache/boundary-ceiling-phase0';adv=out/'adversarial';go=root/'.cache/toolchains/go1.26.8/go/bin/go';records=[]
env=dict(os.environ,GOTOOLCHAIN='local',CGO_ENABLED='0',GOAMD64='v1',GOCACHE=str(root/'.cache/go'),GOFLAGS='-buildvcs=false');env.pop('GOROOT',None)
def run(name,args,extra=None,expected=0,marker=None):
 record={'name':name,'argv':list(map(str,args)),'extra_env':extra,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 result=subprocess.run(args,cwd=root,env=dict(env,**(extra or {})),stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/(name+'.log')).write_bytes(result.stdout)
 record.update(exit=result.returncode,expected_exit=expected,required_marker=marker,output_sha256=hashlib.sha256(result.stdout).hexdigest(),completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());records.append(record);(out/'runtime-proof-records.json').write_text(json.dumps(records,indent=2)+'\n')
 assert result.returncode==expected and (marker is None or marker.encode() in result.stdout and b'--- FAIL: TestPhase0HostSelectedSemanticMutant' in result.stdout),record
 print('PASS',name,flush=True)
for arch in ['amd64','386']:
 exe=out/('runtime-'+arch+'.test')
 run('build-runtime-'+arch,[go,'test','-pgo=off','-overlay='+str(adv/'healthy-overlay.json'),'-c','-o',exe,'./rt'],{'GOARCH':arch})
 run('proof-runtime-'+arch,[exe,'-test.run=^TestPhase0Host','-test.count=1','-test.v','-test.timeout=60s'])
for mode in ['drop-reply-query','drop-postmemory','skip-nonok-validation','suppress-poison']:
 exe=out/(mode+'-386.test')
 run('build-mutant-386-'+mode,[go,'test','-pgo=off','-overlay='+str(adv/(mode+'-overlay.json')),'-c','-o',exe,'./rt'],{'GOARCH':'386'})
 run('mutant-386-'+mode,[exe,'-test.run=^TestPhase0HostSelectedSemanticMutant$','-test.v','-test.count=1'],{'COCOON_PHASE0_MUTANT':mode},1,'SEMANTIC_MUTANT '+mode)
print('PASS native amd64/386 query/fault/lifetime proof and four additional 386 semantic mutants',flush=True)
