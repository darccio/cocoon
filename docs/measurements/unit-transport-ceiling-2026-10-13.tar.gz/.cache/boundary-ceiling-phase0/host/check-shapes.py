#!/usr/bin/env python3
"""Read-only pins and exact authored Add-envelope reproduction audit."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
HOST = Path(__file__).resolve().parent
PINS = {
    "rt/instance.go": "607103f216fb1da1445e705deaea8891f21cbdd04f74e385f4958795ef107d74",
    "rt/resource.go": "10576bedf0d4745afed6f73f4dd7db2c0f11c1018b302c2df5cfcfab96cfee8c",
    "rt/lifecycle.go": "f3d9d622162f78f0b952e44a9aa21a5c1933d366e5078dbf93e8eada098b39b7",
    "examples/datadog/go/dd/cocoon_gen.go": "3d5aeacda6069a347a0e91e7840792ec194b0cdfd414f3c33328ec037231d672",
    "examples/datadog/go/dd/bin_reuse_bench_test.go": "aee2461dbc412268372a620863600f95bb6c3e6ab3cc934d6c4a7e514d73de2a",
    "examples/datadog/go/dd/internal/wasm/module.go": "626550cafa323c490a6a2ec6b2b341656c40e223c7c84701e414078633dcc298",
}
for name, expected in PINS.items():
    actual = hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
    if actual != expected:
        raise SystemExit(f"source pin mismatch: {name}: {actual} != {expected}")

source = (ROOT / "examples/datadog/go/dd/cocoon_gen.go").read_text()
start = source.index("func (r *Sketch) Add(_arg0 float64) error {")
end = source.index("\nfunc (r *Sketch) AddMany", start)
original = source[start:end]
expected = original.replace(
    "func (r *Sketch) Add(_arg0 float64) error {",
    "func phase0TransportAdd(r *Sketch, value float64, skip bool) error {",
    1,
).replace(
    "_guest.module.Xcocoon_sketch_add(int64(_handle), _arg0)",
    "_guest.module.Phase0SketchAdd(int64(_handle), value, skip)",
    1,
)
reply = '''\t\t\t_reply, _resultErr := _call.ResultView("add", _status)
\t\t\tif _resultErr != nil {
\t\t\t\treturn _resultErr
\t\t\t}
\t\t\tif len(_reply) != 0 {
\t\t\t\treturn rt.ErrProtocol
\t\t\t}
\t\t\treturn nil'''
if expected.count(reply) != 1:
    raise SystemExit("original host reply block is not unique")
expected = expected.replace(reply, '\t\t\treturn _call.Phase0UnitReply("add", _status, skip)', 1)
authored = (HOST / "dd_transport.go.txt").read_text()
actual = authored[authored.index("func phase0TransportAdd("):].rstrip()
if actual != expected.rstrip():
    raise SystemExit("private Add envelope differs beyond declared entry/reply substitutions")
print(json.dumps({
    "pins": PINS, "original_add_body_sha256": hashlib.sha256(original.encode()).hexdigest(),
    "private_add_body_sha256": hashlib.sha256(actual.encode()).hexdigest(),
    "exact_envelope_substitution": True,
    "runtime_original_unchanged": True,
}, indent=2))
