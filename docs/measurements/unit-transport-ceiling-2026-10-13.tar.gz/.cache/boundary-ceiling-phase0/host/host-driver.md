# Private host overlay and witness driver

Only ignored host files are authored. Root assembles the Go overlay; virtual
paths are new files, never replacements for existing production bodies:

| Owned source | Virtual package file |
| --- | --- |
| rt_unit_transport.go.txt | rt/phase0_unit_transport.go |
| dd_transport.go.txt | examples/datadog/go/dd/phase0_transport.go |
| phase0_original_test.go.txt | examples/datadog/go/dd/phase0_original_test.go |
| phase0_scaffold_test.go.txt | examples/datadog/go/dd/phase0_scaffold_test.go |

Guest's new wasm/phase0_transport.go is required by the augmented overlay;
adversarial runtime tests are additional new overlay files. Bare overlay has
only the byte-identical phase0_original_test.go among these four sources.
No interface assertion, production-field/global edit, or function-valued Add
adapter substitutes for the original path.

`python3 .cache/boundary-ceiling-phase0/host/check-shapes.py` verifies full source
pins and exact original Add reproduction with only the declared header/guest/
reply substitutions. Preserve its output before qualification. Original Call,
ResultView, ownership, lifecycle and translated module source are unchanged.

Root uses official `.cache/toolchains/go1.26.8/go/bin/go`, CGO_ENABLED=0,
GOAMD64=v1, GOTOOLCHAIN=local, repo GOCACHE, PGO off and isolated builds. Runtime
mock tests, all package tests, and actual amd64/386 native proofs precede freeze.
Only root runs any qualified timing; no host reviewer tool overlaps it.

Full-N proof command, separately on each native architecture and both N values:

```
COCOON_UNIT_PREFIX_N=4194304 COCOON_UNIT_PROOF_DIR=<ignored-proof-output> \
  <augmented-test-ELF> -test.run '^TestPhase0TransportFullReplay$' -test.v
```

Confirmation substitutes 8388608. Each ordered input is called/checks nil error
through Original, Checked and Oracle, then exact Count and full protobuf match
the original role. It is complete finite Go consistency, not full-N Wasm
equivalence or proof of the omitted wire safety. There is no warm Add before
these fresh-resource prefixes. Fixed resources/libraries are explicitly closed
after verification; ordinary registered cleanup is still terminal/idempotent.
The source model is never reduced to a precomputed numeric map.

Outputs include `corpora/<corpus>.bin` (exact little-endian binary64 bits for
all seven 8192-value arrays) with SHA/shape JSON, `full-replay-N-GOARCH.json`,
and `goldens/N/<corpus>.json` plus owned
complete protobuf `goldens/N/<corpus>.pb`. Each golden records complete input-bit
SHA, exact Count bits, wire length and full SHA; architecture runs must reproduce
the same golden bytes. Historical corpus arrays are obtained directly from
the existing frozen binReuseValues implementation (8192 bits, no retuning).
Increasing is exactly float64(index+1). Preserve raw corpus bit inventories in
root freeze and keep the existing function's source hash. There are 24*N Add
calls per full-proof process, separate from <=2048 bounded guest Wasm requests.

Fixed names:

* BenchmarkPhase0TransportOriginalFixed/<corpus>
* BenchmarkPhase0TransportScaffoldFixed/<Checked|Oracle>/<corpus>

Require COCOON_UNIT_PREFIX_N=4194304 or8388608,
COCOON_UNIT_EXPECTED_DIR=<proof-output>/goldens and -test.benchtime=1x. One
reported ns/op is one complete N-input prefix, not one Add. points/op=N and
ns/input/points/s are explicit. Golden loading/input SHA preparation/constructor
are untimed. Timed work includes every per-input envelope, callback/guest call,
reply behavior, and global mode load as an argument each iteration. Real branch
and global load must be shown by root's ordinary compiler assembly audit.

Adaptive names:

* BenchmarkPhase0TransportOriginalAdaptive
* BenchmarkPhase0TransportScaffoldAdaptive/<Checked|Oracle>

Their hot loops retain value++ and direct original Add/private paired helper.
Adaptive actual b.N can differ; after StopTimer each role builds a fresh
original resource, replays exactly its own 1..b.N prefix, and compares exact
Count/full protobuf. This is untimed validation, not a hidden cache or warm state.
points/op=1; post-memory snapshot precedes Count/Encode and witness preparation.

All leaves set/restore P1 at actual leaf scope, assert before ResetTimer and
immediately after StopTimer, then report actual-procs=1 after ResetTimer cleared
metrics. Initial/final/growth linear-byte metrics refer to the timed resource
before untimed Count/Encode. They exclude process heap/RSS and independent
witness memory. Output metric protobuf-B is final owned complete encoding.
wire-digest32 is a reporting checksum; actual validation uses full bytes and
full SHA, not that shortened metric. Host Go allocations are timer-scoped and
do not count guest Rust allocator activity.

Tests are not parallel and mutable mode is set per sequential role/leaf. The
method's enabled OK query is exactly the observable interface call; disabled
all-status/non-OK paths call original ResultView once plus original unit-empty
check. Original post-query/poison/reset remains in Instance.Call. Adversarial
runtime proofs own fake modules/query counters and executed mutants; guest
proofs own bounded original-Wasm, stale-publication and state transition checks.

READY criteria require both other roles and bare/scaffold costs disclosed,
not just a faster oracle/scaffold comparison. No supported public contract,
ABI/version/schema/export or implementation follows from these ignored files.
