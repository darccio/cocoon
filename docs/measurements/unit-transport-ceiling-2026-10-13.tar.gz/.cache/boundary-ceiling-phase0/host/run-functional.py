#!/usr/bin/env python3
"""Small functional compiler/test journal; never invokes benchmarks/profiles."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

HOST = Path(__file__).resolve().parent
ROOT = HOST.parents[2]
GO = ROOT / ".cache/toolchains/go1.26.8/go/bin/go"
parser = argparse.ArgumentParser()
parser.add_argument("role", choices=["bare", "augmented"])
parser.add_argument("--label", default="initial", choices=["initial", "final"])
args = parser.parse_args()
mapping = {
    str(ROOT / "examples/datadog/go/dd/phase0_original_test.go"): str(HOST / "phase0_original_test.go.txt"),
}
if args.role == "augmented":
    mapping.update({
        str(ROOT / "rt/phase0_unit_transport.go"): str(HOST / "rt_unit_transport.go.txt"),
        str(ROOT / "examples/datadog/go/dd/phase0_transport.go"): str(HOST / "dd_transport.go.txt"),
        str(ROOT / "examples/datadog/go/dd/phase0_scaffold_test.go"): str(HOST / "phase0_scaffold_test.go.txt"),
        str(ROOT / "examples/datadog/go/dd/internal/wasm/phase0_transport.go"):
            str(ROOT / ".cache/boundary-ceiling-phase0/guest/generated/phase0_add.go.txt"),
    })
for path in mapping.values():
    if not Path(path).is_file():
        raise SystemExit(f"missing actual overlay source: {path}")
suffix = "" if args.label == "initial" else "-" + args.label
overlay = HOST / f"{args.role}-functional{suffix}-overlay.json"
overlay.write_text(json.dumps({"Replace": mapping}, indent=2) + "\n")
env = os.environ.copy()
env.update({"CGO_ENABLED": "0", "GOTOOLCHAIN": "local", "GOAMD64": "v1",
            "GOCACHE": str(ROOT / ".cache/go"), "GOMAXPROCS": "1"})
for name in ["COCOON_UNIT_PREFIX_N", "COCOON_UNIT_EXPECTED_DIR", "COCOON_UNIT_PROOF_DIR", "GOFLAGS", "GOGC", "GOMEMLIMIT", "GODEBUG"]:
    env.pop(name, None)
commands = [
    ["python3", str(HOST / "check-shapes.py")],
    [str(GO), "version"],
    [str(GO), "test", "-pgo=off", "-overlay=" + str(overlay),
     "-run=^TestSQLTracesAndSketch$", "-count=1", "./examples/datadog/go/dd"],
]
journal = []
for number, command in enumerate(commands):
    started = time.time()
    result = subprocess.run(command, cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    logfile = HOST / f"{args.role}-functional{suffix}-{number}.log"
    logfile.write_bytes(result.stdout)
    journal.append({"argv": command, "cwd": str(ROOT), "started_unix": started,
                    "finished_unix": time.time(), "exit": result.returncode,
                    "log": str(logfile), "log_sha256": hashlib.sha256(result.stdout).hexdigest()})
    (HOST / f"{args.role}-functional{suffix}-journal.json").write_text(json.dumps({
        "scope": "bounded functional compilation/test only; no benchmark or CPU profile",
        "sources": {path: hashlib.sha256(Path(path).read_bytes()).hexdigest() for path in mapping.values()},
        "environment": {key: env.get(key) for key in ["CGO_ENABLED", "GOTOOLCHAIN", "GOAMD64", "GOCACHE", "GOMAXPROCS", "GOGC", "GOMEMLIMIT", "GODEBUG", "GOFLAGS"]},
        "commands": journal,
    }, indent=2) + "\n")
    print(f"{args.role} functional command {number}: exit {result.returncode}, {logfile}", flush=True)
    if result.returncode != 0:
        print(result.stdout.decode(errors="replace"), flush=True)
        raise SystemExit(result.returncode)
