# Host result review — evidence-only READY / production NO-GO

2026-10-13. Read-only audit of signed-spec plan, 980 raw rows/logs, summaries, benchstat, final proof/gate/source identities and custom metrics. No new compiler/test/profile/benchmark execution or frozen source edit. This note is the only write.

## Qualification and strict decision

All 980 rows exit0, 490 per set; each group/role has seven fresh-process samples. The25groups/70cases per pass match the frozen plan. All868actualP1 and112actualP16 observations match their requested leaves. Every raw row is present in its archived log; every summary role/metric median recomputes exactly from records.jsonl. All481 frozen hashes currently match. The61 production proof/runtime fingerprints are identical before/after two repeats. Recorded gates/rebuilds do not overlap the07:14:57–07:29:24UTC measurement window. This audit cannot establish absence of unrelated external system activity.

The preregistered threshold fails. Adaptive Oracle85.51/85.52ns versus Original87.39/88.24ns improves only2.151%/3.083%; versus Bare88.29/88.89 only3.149%/3.791%; versus Checked91.23/91.93 only6.270%/6.973%. All six p=.001, but none reaches10%. The Checked scaffold costs4.39%/4.18% relative to source-untouched Original; larger Oracle/Checked differences cannot rescue the original comparison.

Fixed Increasing screening is highly dispersed: Bare median130.215ns/input, Original142.336, Checked162.616, Oracle153.591. Oracle/Bare+17.952%(p=.805), Oracle/Original+7.908%(.710), Oracle/Checked−5.550%(.383). Benchstat Bare ±57%, Oracle ±45%; individual Bare samples range89.295–204.228ns/input. Keep every sample; do not retime it away or explain a cause from policy snapshots. Confirmation settles at88.926/88.030/91.132/84.815ns/input, improvements4.622%/3.652%/6.931% against the three controls, allp=.001 and all below10%. This alone forces NO-GO, independently of the repeated SQL guard failures.

## Fixed corpus outcomes

Values below normalize exact median whole-prefix ns/op by4M/8M inputs. Raw ns/op is a complete N-input prefix, b.N=1, not one Add. Reported ns/input has ordinary printing precision. Both primary prefixes/other corpora use identical ordered inputs across four roles, no warm Add.

| Corpus | Screen Bare / Original / Checked / Oracle ns/input | Confirm same order ns/input | Oracle/Original change screen / confirm | p screen / confirm |
| --- | --- | --- | --- | --- |
| Increasing | 130.215 / 142.336 / 162.616 / 153.591 | 88.926 / 88.030 / 91.132 / 84.815 | +7.908% / -3.652% | 0.710 / 0.001 |
| Repeated | 88.385 / 87.426 / 90.338 / 85.430 | 88.960 / 87.350 / 90.582 / 84.835 | -2.283% / -2.880% | 0.001 / 0.007 |
| UniqueCycle | 88.454 / 87.300 / 90.121 / 85.200 | 88.636 / 87.587 / 90.956 / 85.071 | -2.405% / -2.873% | 0.001 / 0.001 |
| NearbyUniqueCycle | 88.094 / 87.324 / 90.137 / 84.548 | 88.381 / 87.881 / 90.583 / 85.309 | -3.179% / -2.927% | 0.001 / 0.026 |
| MostlyUniqueCycle | 88.201 / 87.858 / 90.591 / 85.417 | 88.466 / 88.765 / 90.317 / 85.363 | -2.778% / -3.832% | 0.001 / 0.001 |
| Phases | 88.148 / 87.059 / 90.857 / 85.163 | 88.968 / 87.667 / 90.825 / 85.059 | -2.178% / -2.976% | 0.026 / 0.001 |
| BroadHoldout | 92.796 / 88.938 / 90.973 / 86.082 | 92.474 / 89.270 / 90.961 / 86.400 | -3.212% / -3.216% | 0.001 / 0.001 |
| NegativeBins | 88.155 / 87.104 / 90.316 / 85.552 | 88.818 / 87.753 / 91.018 / 85.351 | -1.782% / -2.738% | 0.001 / 0.001 |

The seven cyclic corpora repeat detected Oracle/Original gains, roughly1.78–3.83%, and Oracle/Checked5.01–6.35%. They are unsupported numerical-state-preserving transport gains, not retained scalar ABI3 gains. They do not reach the default promotion rule or imply all typed results have this cost. All504 fixed/adaptive rows report0B/0allocs,1179648 initial/final logical linear bytes and0timed growth. Per-row Count, protobuf length and short reporting checksums agree with finite goldens; full wire-byte/hash equality is asserted by the actual harness, not inferred solely from the32-bit metric. This does not measure Rust heap activity or process RSS.

## Original-source linkage guards and negatives

| Workload | Screen Bare → Augmented | Δ; p | Confirm Bare → Augmented | Δ; p |
| --- | --- | --- | --- | --- |
| OriginalScalar | 88.71 → 88.05 ns/op | -0.744%; 0.078 | 89.26 → 88.43 ns/op | -0.930%; 0.073 |
| OriginalSQL | 2124 → 2178 ns/op | +2.542%; 0.024 | 2126 → 2178 ns/op | +2.446%; 0.001 |
| OriginalBatch | 37879 → 38616 ns/op | +1.946%; 0.058 | 38146 → 38221 ns/op | +0.197%; 0.401 |
| OriginalTrace | 2.55603e+06 → 2.58581e+06 ns/op | +1.165%; 0.097 | 2.53092e+06 → 2.57042e+06 ns/op | +1.561%; 0.710 |
| VariedScalar | 89.14 → 88.26 ns/op | -0.987%; 0.001 | 89.74 → 88.62 ns/op | -1.248%; 0.004 |
| NegativeScalar | 89.06 → 88.08 ns/op | -1.100%; 0.196 | 89 → 88.77 ns/op | -0.258%; 0.383 |
| VariedSQL | 2700 → 2811 ns/op | +4.111%; 0.001 | 2691 → 2809 ns/op | +4.385%; 0.001 |
| SQLHoldout | 5413 → 5653 ns/op | +4.434%; 0.001 | 5437 → 5680 ns/op | +4.469%; 0.001 |
| BroadBatch | 312637 → 314343 ns/op | +0.546%; 0.456 | 315823 → 316659 ns/op | +0.265%; 1.000 |
| BroadTrace | 4.28191e+06 → 4.35972e+06 ns/op | +1.817%; 0.002 | 6.8034e+06 → 8.65499e+06 ns/op | +27.216%; 0.902 |

OriginalSQL(+2.542%/+2.446%,p=.024/.001), VariedSQL(+4.111%/+4.385%,.001/.001) and SQLHoldout(+4.434%/+4.469%,.001/.001) each violate the repeated same-comparator guard. These methods still call original code; no direct causal SQL effect of skipped unit publication can be inferred. Augmented linkage is a measured tradeoff, not an excuse for waiving the signed guard. BroadTrace loses1.817% in screening(.002); confirmation has an adverse27.216% median butp=.902 with large dispersion. OriginalBatch/Trace and BroadBatch have adverse medians in both sets without repeated detection. VariedScalar improves about1% both sets from linkage alone; this is not a retained implementation gain. No loss or outlier is excluded.

## Streaming: distinct linked binaries, untouched source/control calls

Bare stream ELF=a2076ad9349c334f028e1c73cc166004c15da1debab79e8d2c349d851bc373bf; augmented=2ecd9771d8090e4279f8fb64810510934eb965fe3a8cad10919e0accec6418aa. They are DISTINCT ELFs linked around unchanged streaming sources/Wasm; no streaming operation invokes either private transport helper. Interpret them as untouched-workload linkage/conditions brackets, never a new streaming transport gain. Both P1default and P16default retain one serialized resource home; P16Homes16 opts into sixteen homes independently of the stateless pool.

Each timed operation is complete New/Write/End/Close, nominalChunk64 over fixed16KiB or variable/empty-chunk holdout, retaining owned groups32. Fixed has256writes; holdout write counts vary. Rates below are raw custom writes/s medians (Write calls excluding End, complete lifetime denominator), not strict maximum capacities or per-request latency.

| Workload | Screen Bare / Augmented writes/s | Confirm Bare / Augmented writes/s | Time Δ screen / confirm | p screen / confirm |
| --- | --- | --- | --- | --- |
| Fixed-P1-Homes1 | 1,597,910 / 1,587,498 | 697,006 / 695,089 | +0.656% / +0.276% | 0.026 / 0.710 |
| Fixed-P16-Homes1 | 1,276,193 / 1,274,493 | 1,254,105 / 1,186,471 | +0.133% / +5.700% | 0.456 / 0.535 |
| Fixed-P16-Homes16 | 5,962,399 / 7,000,035 | 9,617,923 / 9,755,223 | -14.824% / -1.409% | 0.902 / 0.456 |
| Holdout-P1-Homes1 | 1,118,360 / 1,074,210 | 749,973 / 752,251 | +4.110% / -0.303% | 1.000 / 0.710 |
| Holdout-P16-Homes1 | 884,796 / 854,772 | 1,182,721 / 1,385,474 | +3.513% / -14.634% | 1.000 / 0.902 |
| Holdout-P16-Homes16 | 5,207,858 / 5,181,730 | 10,207,514 / 10,193,892 | +0.505% / +0.134% | 0.620 / 0.620 |

Only FixedP1 detects screening loss(+.656%,p=.026); confirmation is+.276%,p=.710. All other stream comparisons are undetected, including P16one-home Fixed+.133%/+5.700%, and one-home Holdout+3.513% screening/−14.634% confirmation. Sixteen-home fixed screen−14.824%p=.902 is extremely noisy. P1fixed Bare367.285µs confirmation versus160.209µs screening describes different sampled conditions, not a code slowdown. Keep these cross-set differences visible and make no equality or home-only causal scaling claim. Confirmation Bare P16Fixed reaches1.254Mone-home/9.618Msixteen-home writes/s; Holdout1.183M/10.208M. Augmented1.186M/9.755M Fixed;1.385M/10.194M Holdout.

Fixed outputs remain16392ownedB/250allocations per stream; holdout16390ownedB/268. Host B/op≈17496/19604 atP1/sharded, with modest constructor amortization for P16one-home. These count host allocations, not guest allocator activity or RSS. No Batch-session path is measured here; its tradeoffs are unchanged and not accepted anew.

## Source/proof identity and comparison limits

OriginalAdd and original translated export are byte-source-untouched in augmented ELF044d01a57f615b58433c5d3141781f1ecc0e2039335ce2d04fe358febf60c8c2; Bare=5d0b0c63b654cfcbabefd2778f079d004bfbfd7a6e2f1b8a67fd6a34af8ba7ac. Same-ELF Checked/Oracle share the actual per-loop dynamic mode load. Machine observations retain one indirect observable reply Memory CALL and original independent postquery. Disabled/nonOK invoke original ResultView once; enabledOK intentionally accepts malformed replies and stale metadata. No callbacks, admission, owner/epoch checks, locks, reset/recovery, MaxMemory, error ownership or detected-fault poisoning are removed. The compiler sinks the pure t42 loaded value into disabled publication, while retaining its earlier bounds check; actual enabled machine omission includes that pure publication-dependent value read as well as the three stores. Do not claim only three machine memory stores change.

Final native amd64/386 full4M+8M consistency runs compare603979776GoAddcalls across both architectures (301989888/arch), each input through all3roles and exact final Count/fullprotobuf. Corpora/goldens match across architectures. This is finite state consistency, not full-N Wasm proof or universal wire equivalence. The bounded original-Wasm ledger records582operation requests/arch (15constructors552methods15destructors), plus identity/init/reserve/output crossings separately; states/growth/stale-publication transitions match. Runtime semantic mutants are real execution failures, not compiler crashes. NativeARM/big-endian and privateSDK claims remain absent.

OfficialGo1.26.8 timing is CGO0,GOAMD64v1,PGOoff,defaultGC/memory, unpinnedRyzen5800HS,powersave/boostenabled. Comparison observations reportactualP1/P16 at leaf boundaries. CPU frequency/load vary considerably despite stable policy; no additive profile attribution, workload equivalence or universal maximum follows. Quality usesGo1.27.2 except check/lint using official1268 and pinned2.13.1; all7gates and2complete61fingerprint reproductions pass before qualified timing.

## Fresh reference and M1

The fresh independent reference preserves56selected authored-source hashes, own lockedRust1.97/Binaryen133/wasm2go0.4.16/hardener, no Cocoon implementation transplant. Wasm/module reproduce old controls; raw reference binary does NOT reproduce the old ELF, and observed reference ELF66d5e53119531390452de0704f0f9b0ec5c834d2860e609d5a35df063939a8b7 contains only outside-timer actualprocessor observations. The journal has9start/end actual command pairs including a nested driver; do not label it18distinctbuilds. ABI2borrowed/background/four-instance topology and ownership/input-history differences remain. Reference comparisons were explicitly contextual and excluded from guard rejection before data.

Fresh adaptive reference scalar55.07/55.12ns gives110%limits60.577/60.632ns. Bare original88.71/89.26 and augmented88.05/88.43miss both freshlimits and absolute55.44ns. Even unsupported Oracle85.51/85.52 is30.07/30.08ns above absolute and24.933/24.888ns above freshlimits. This is no M1 acceptance or safe ABI feasibility.

Fresh reference SQL1996/1983ns gives110%limits2195.6/2181.3ns. Bare2124/2126 and augmented2178/2178meet these medians and absolute2215.4ns; augmented confirmation fresh margin is only3.3ns, not a durable guarantee. Augmented/reference ratios scalar1.5989/1.6043 andSQL1.09118/1.09834 are whole-implementation contextual comparisons, not a safety-overhead decomposition. SQL alone cannot accept M1, and the repeated SQL linkage guards remain failed.

## Retention recommendation

READY for signed evidence/documentation-only retention under the strict NO-GO. Preserve cause/generated ignored files, all controls/proofs/mutants/goldens/raw samples/negatives and honest role labels in the compressed archive. Retain no production API/ABI/schema/module/lock change; do not tune helper/layout/modes, filter noisy increasing samples, or revive fusion/unit specialization. This one joint envelope fails the signed economic threshold, not a theorem that every future ABI representation has zero upside. A future public representation would still require separate compatibility/design review and explicit operator approval. M1 remains unaccepted. Host tools stop after this note.
