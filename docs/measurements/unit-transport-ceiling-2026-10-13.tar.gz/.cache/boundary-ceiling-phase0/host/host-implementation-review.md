# Host implementation review — READY

2026-10-13; signed private specification `bf01a1a`. All authored changes are
new ignored files under host/, with no production/runtime/facade/module body
or layout edit. No performance benchmark or CPU profile was run by this reviewer.
No further host source edit is planned. Root must freeze/rebuild final actual
ELFs and run final native/full-N proofs before isolated measurements.

## Applied source audit

`Call.Phase0UnitReply` contains one observable interface Memory call on enabled
OK, without interpreting deliberately stale descriptor/payload state. Disabled
all-status and non-OK paths delegate to original ResultView exactly once and
retain the successful-unit empty check. The original Instance.Call still owns
independent post-Memory/MaxMemory, reset/recovery and immediate poisoning.
Runtime fake-module/query/mutant proofs are owned by the adversarial reviewer;
their applied source review reports no helper/consumer/harness blocker.

The private Add helper preserves both nested callbacks and all original
admission/Leave, Resource.Use, full-width current handle, and Instance.Call
logic. `check-shapes.py` pins runtime, facade, module and historical corpus
sources and verifies exact copied Add text with only the declared header,
guest-entry and reply-block substitutions. This check passes before both
functional compiler runs. The original Add/Call/ResultView bodies remain intact.

Original fixed/adaptive loops call Sketch.Add directly. Scaffold loops call the
same compiled helper and reload a mutable global as the skip argument every
timed iteration; no function-valued Add adapter or pre-resolved handle occurs.
The paired flag reaches both guest publication and host reply halves. Ordinary
assembly must still verify the real per-loop load/conditional and retained
interface reply query; source inspection alone cannot establish that inventory.

Bare and augmented ELFs share phase0_original_test.go byte for byte. Bare has
no private method dependency. Source-untouched original within augmented ELF
is not byte-identical production linkage; scaffold and bare penalties are
reported rather than used to rescue the repeated both-comparator decision.

## Proof and measurement accounting

FullReplay evaluates every ordered input through all three Go roles and checks
exact Count plus complete protobuf against original output. Original goldens
include complete prefix input-bit SHA, wire bytes/full SHA and Count bits;
raw .pb bytes remain owned/persisted. Exact seven 8192-value corpus arrays are
exported as little-endian binary64 .bin bytes with SHA/shape records. Increasing
remains exactly 1..N; no warm Add, numerical oracle or corpus retuning exists.
There are 24*N Add calls per full-prefix process, separate from bounded Wasm
requests and not a universal/full-N original-Wasm proof.

Fixed leaves require preregistered 4M/8M and benchtime=1x. Raw ns/op is the
complete prefix; points/op=N, ns/input and points/s are explicit. Every sample
must match the independently prevalidated golden's full wire bytes, not merely
its short reporting checksum. Adaptive leaves retain value++ and original Add
loop shape; they replay a fresh original resource for exactly their own final
b.N after StopTimer and compare full state. points/op=1 for adaptive rows.

Actual measured leaves set/restore P1 and assert directly before ResetTimer
and directly after StopTimer; actual-procs is reported after reset. Timed
memory snapshots precede untimed Count/Encode/witness work. They describe
logical linear lengths, not native heap/RSS or guest-allocation proofs. Output
protobuf-B describes owned final encoding; wire-digest32 is reporting only.
Setup, disk golden/corpus hash preparation, cleanup and witnesses remain
untimed; all per-input mode and checked boundary work remain timed. Finite
resource lifetimes/output history do not grow with measurement iteration count.

## Functional validation and identities

Official Go version is `go1.26.8 linux/amd64`, with CGO0, GOAMD64v1, PGOoff,
GOTOOLCHAIN=local and repo GOCACHE. Bare and augmented bounded functional
compiler/tests pass. Final augmented compilation after corpus-export addition
passes; initial logs/journals remain separate from final ones. No benchmarks
are invoked by run-functional.py. Root reports initial full 4M/8M native
amd64/386 proofs passed with byte-identical goldens, but those ELFs preceded
the final untimed provenance addition. Final root rebuild/reproof is therefore
required and is not claimed completed here.

Stable hashes (also host-source-hashes.json):

| File | SHA-256 |
| --- | --- |
| rt_unit_transport.go.txt | ef1d6307712f949a9af09f109dfb2ecb43b37ec63342479fbce294b523c0155d |
| dd_transport.go.txt | d34858224c9dba583636a9aa66e927f3526f736672d6c7791e1d2ef507caf926 |
| phase0_original_test.go.txt | 39b54a9a14c0f85f32d56398b583776d00a87b3a1d0c4d684396086be6e99200 |
| phase0_scaffold_test.go.txt | 4e58e99b09e2af8e47808126e233a4c3c93a2c544d2b1ad94c4fab0a53d76e6b |
| check-shapes.py | eae53dde06cc1a30d170c1e56f069de911ea93c470443b47168801d8ea2aa78d |
| run-functional.py | b730d452195cd3efdd5a6d24a3dd63685b1baef807703ab791cfbf97cc74a38c |
| host-driver.md | d7efdcfc32030a9afed842a2ea6993af5e4896518fde3a7ffee40735e079262b |

READY under the signed private ceiling scope, subject to parent final frozen
ELF/proof/query/assembly/gate qualification. This supplies no supported public
method, ABI 3 safety equivalence, typed-return feasibility or M1 acceptance.
Host reviewer stops all tools now; root owns further builds and timing.
