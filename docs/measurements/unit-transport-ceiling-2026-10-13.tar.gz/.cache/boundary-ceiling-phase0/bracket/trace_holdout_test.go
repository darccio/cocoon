package dd

import (
	"bytes"
	"crypto/sha256"
	"runtime"
	"testing"
)

func BenchmarkPhase0TraceHoldout(b *testing.B) {
	batchingProcessors(b, 1)
	library := openTest(b, Options{Instances: 1})
	inputs := [][]byte{tracePayload(32), tracePayload(1000), tracePayload(4096)}
	expected := make([][]byte, len(inputs))
	hashes := make([][32]byte, len(inputs))
	for index, input := range inputs {
		var err error
		expected[index], err = library.ObfuscateTraces(b.Context(), input)
		if err != nil || len(expected[index]) == 0 {
			b.Fatal("holdout setup", err)
		}
		hashes[index] = sha256.Sum256(expected[index])
	}
	index := 0
	var result []byte
	b.ReportAllocs()
	b.ResetTimer()
	for b.Loop() {
		var err error
		result, err = library.ObfuscateTraces(b.Context(), inputs[index])
		if err != nil || len(result) != len(expected[index]) {
			b.Fatal("holdout call", err)
		}
		index = (index + 1) % len(inputs)
	}
	b.StopTimer()
	last := (index + len(inputs) - 1) % len(inputs)
	if !bytes.Equal(result, expected[last]) || sha256.Sum256(result) != hashes[last] {
		b.Fatal("holdout output")
	}
	if runtime.GOMAXPROCS(0) != 1 {
		b.Fatal("actual processor mismatch")
	}
	b.ReportMetric(1, "actual-procs")
}
