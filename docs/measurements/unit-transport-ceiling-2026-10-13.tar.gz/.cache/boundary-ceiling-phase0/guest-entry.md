# Guest entry: one successful-unit transport ceiling

Entry HEAD47f307971894d9257023dca1d6d7d848a2d0bc55 is clean; local main and origin/main both identify aeaf01b341a85024804e9ae1abe43af90d36e4d1. Read docs/roadmap.md, docs/performance.md and docs/abi.md in full, including the retained no-gos. This entry used only source/document/hash reads and wrote this ignored note. No code, cache prototype, production docs/artifacts/locks or public contract changed; no build/test/profile/benchmark ran.

## Selected question and distinction

Measure the full successful-unit wire round-trip for Sketch.Add only: the existing guest output-vector/descriptor publication together with host descriptor/range/empty-result validation. Keep guest STATE setup/borrow, Slab handle resolution, point validation, exact fn176 body, error paths and host lifecycle/ownership/Instance.Call/reset/recovery/post-memory work unchanged. Keep one observable reply Memory query even in the private enabled ceiling, plus the separate current post-operation Memory/MaxMemory check. This is one joint structural cost question, not an estimate obtained by adding profile/component shares.

This is materially different from the prior existing-ABI ResultUnit specialization: that retained guest publication and all descriptor/range checks and saved about1.6ns only in an isolated component, without a repeated untouched scalar gain. It is also different from the rejected Resource.Call callback fusion (both locks/checks and wire transport unchanged), the rejected two-site descending store guard experiment (all actual publication stores remained), and numerical cache/polynomial/classifier/read64-store64 proposals. Do not relabel any of those as untried.

The existing retained changes already force inline canonical unit success, use cold unit-error publication, cache the descriptor address and skip general successful status dispatch only AFTER validation. This diagnostic asks about eliminating that successful transport obligation itself, not rearranging it again. Typed scalar return/Count is a separate ABI question and should not be included in this one Add ceiling.

## Existing exact hot path

- Generated Go Add, examples/datadog/go/dd/cocoon_gen.go571: nil/library/owner guard, lifecycle Enter/Leave, Resource.Use, Instance.Call, Xcocoon_sketch_add(handle,value), ResultView, then successful empty check. Add correctly has no input Reserve. Ordinary AddMany/Count/Encode/Close remain outside selection.
- Rust shim export, examples/datadog/shim/src/cocoon_gen.rs84: STATE.with_borrow_mut, sketch.get_mut(handle), service.sketch_add(resource,value), then cocoon_guest::reply_unit.
- Guest library, rust/cocoon-guest/src/lib.rs123: successful reply_unit clears cached output Vec, publishes its current pointer and zero length; errors use the retained cold reply_unit_error→reply path. Descriptor address is fixed, contents are not constant. Slab::index/get_mut at230/239 checks low-word slot-plus-one, vector bounds, high-word generation and occupied Option; remove243 increments generation or retires the final generation.
- Translated scalar export starts module.go48457. It preserves STATE setup and borrow checking, calls fn84 into its16-byte result frame, validates finite/nonnegative bits, calls fn176 and formats original errors. The normal unit tail is l5 at48600 onward; l6 restores g0 and returns status.
- rt/instance.go348 ResultView makes one current Memory query, checks the full8-byte descriptor, decodes LE pointer/length, applies MaxOutput, checks logical payload range including zero length, then interprets status. rt/instance.go158 Call supplies actual execution locking, state/reset/recovery, current post-memory check and protocol poisoning. Resource.Use in rt/resource.go75 retains shared owner/epoch/closed/alive checks and KeepAlive.

### Exact tail store inventory

The normal l5 tail contains FOUR store32 calls, but only THREE are successful publication stores:

1. STATE borrow release: store32(m.memory,1101424,t39+1). KEEP.
2. Descriptor pointer: store32(m.memory,1101804,t42), after t42=load32(m.memory,1101796).
3. Cached output Vec length: store32(m.memory,1101800,0).
4. Descriptor length: store32(m.memory,1101808,0).

Only2–4 may be conditionally omitted for this ceiling. Keep the pointer read at its original position as well, so no read/check/trap is silently removed. Keep prior initialization at1101820/fn105, BUFFERS borrow guard1101776/fn24/unreachable, STATE release, p6=0 and g0 restoration. The lower1101800 write is Vec metadata, not the descriptor size. The actual canonical output descriptor starts1101804. No error path or other method is selected.

The ignored authored AST cause must require complete module SHA, exact unique Add function/full-tail identity, bound receiver/memory/store/load/i32 declarations, primitive literal values and exact expected l5 statement order. Reject missing/multiple stores, additional effects/control, changed bindings/types or altered surrounding borrow/init/restore shapes. Count the three selected calls independently and reproduce the baseline. These payload/function/source pins qualify a private diagnostic only, never a generic compiler predicate. Preserve the authoring cause and generated overlay rather than retaining an isolated generated edit.

## Host diagnostic and contract limits

Enabled OK skips descriptor decoding, MaxOutput/payload range and successful-empty validation but still makes exactly one current reply Memory query. Non-OK invokes the original ResultView once, with no earlier query and no guest reinvocation; preserve descriptor/MaxOutput/range-before-status precedence and owned opaque error messages. The actual rt.Module interface Memory call is observable: do not replace it with a pure concrete getter that the compiler may eliminate, and inspect the actual frozen machine code/query proof. Never merge its view with the independent post-call query or retain it across growth.

This enabled diagnostic is UNSUPPORTED UNDER ABI3. ABI3 requires canonical checked empty success. Malformed successful descriptors/pointers/nonempty replies may therefore be accepted by the ceiling although untouched ABI3 rejects them. Existing wire-fault oracles must demonstrate and label that deliberate divergence, not be weakened to declare general ABI equivalence. Protocol poisoning remains unchanged when a detected non-OK fault reaches it; skipped successful-wire faults cannot be claimed detected. Initial ABI/schema validation can remain unchanged only as a historical diagnostic pin, not as permission to publish the altered success behavior under ABI3.

Baseline and disabled ceiling mode retain ordinary canonical transport. Enabled/disabled should share a frozen ELF/module layout and differ only by a per-instance private flag; untouched production supplies a separate control. Append private diagnostic state without changing original field offsets where possible, but disclose allocation/layout/linkage confounds against untouched. Do not add padding or pursue layout rescues. A dynamic flag plus preserved reads can impose overhead, so a measured result is the ceiling of this exact envelope, not a mathematical maximum or an additive guest/host transport share. There is no predicted percentage from historical profiles.

## Why handle resolution stays unchanged

Forcing Slab::index/get_mut inline did not establish a gain; the later single checked mutable lookup improved scalar but lost SQL/batch/trace and was removed. Combining that rejected lookup with reply removal would add a second causal question. Pre-resolving a raw slab/resource address is substantially less safe: the Slab Vec can reallocate after another constructor, reuse/retirement changes generations/occupation, raw state/RefCell reentry can trap, and host epoch ownership alone does not prove the guest slot remains valid. Memory growth/backing replacement and payload allocations add further view/lifetime hazards. A host-pinned address is neither a valid ABI3 handle nor an authority to omit guest checks. No such bypass belongs in this first diagnostic.

## Required evidence before any decision

Fresh ordinary compiler/profile/assembly records should verify this exact boundary is exercised. Preserve all original scalar workloads and new matched fixed prefixes/holdouts, with Count/full protobuf versus original Wasm after ordered histories, growth/collapse/revisits, errors and canonical reply transitions. Avoid comparing differently calibrated state sizes as if stationary. All priors include sensitive placement/control effects; a new paired full-facade measurement against both controls is required.

Native/query/lifetime proof should separately cover error-after-unit, unit-after-nonempty/error, stale and fresh generation handles, unknown/negative/reserved statuses, error output limits/logical bounds/message ownership, guest/host traps, Memory-query ordering, post-MaxMemory precedence, reset, immediate detected-fault poisoning/epochs, no subsequent callback, alias once-only Close, abandoned resources and terminal drain. Known ABI3 successful-wire divergences require explicit expected counterexamples. Original-Wasm supplies state/bin/Count/full-output oracles, not equivalence of the deliberately skipped metadata writes. No library/reply/Call view escapes; no new reentry or preemption assumption is introduced.

Public approval gates a future payload-free success/direct-return ABI, compatibility/version/schema/export rules, migration and supported generator/runtime contract. The present user-authorized private counterfactual can measure without implementing any NEW supported public contract. A positive ceiling permits proposing that separate review; it does not authorize it, M1 acceptance or a shipping shortcut. If the joint ceiling is not materially useful under the frozen rule, park it without restarting cache or guard tuning.

Source identities at entry: guest primitives bc1d3c620c010139ba2426637db2012f063b0bd8d172c5e8eb2adb3094643db9; Rust shim f1bda5d5bb179d1e1d3ac0fd00fd50aa5db5a41f7da4cab65bf03f905b98aaa3; translated module626550cafa323c490a6a2ec6b2b341656c40e223c7c84701e414078633dcc298; rt/instance.go607103f216fb1da1445e705deaea8891f21cbdd04f74e385f4958795ef107d74; rt/resource.go10576bedf0d4745afed6f73f4dd7db2c0f11c1018b302c2df5cfcfab96cfee8c. Guest entry complete; tools stopped after this note.
