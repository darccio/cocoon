from pathlib import Path
import re,json,subprocess,hashlib
root=Path.cwd();out=root/'.cache/boundary-ceiling-phase0';folder=out/'bracket';folder.mkdir(exist_ok=True)
def observe(source):
 if '"runtime"' not in source:
  if 'import "testing"' in source:source=source.replace('import "testing"','import ("testing"; "runtime")',1)
  else:source=source.replace('import (','import ("runtime";',1)
 return re.sub(r'(func Benchmark\w+\(b \*testing.B\) \{)',r'\1\n defer func() { b.StopTimer(); if runtime.GOMAXPROCS(0)!=1 { b.Fatal("actual processor mismatch") }; b.ReportMetric(1,"actual-procs") }()',source)
replace={}
for name in ['bench_test.go','varied_bench_test.go','negative_bench_test.go']:
 old=root/'examples/datadog/go/dd'/name;target=folder/name;target.write_text(observe(old.read_text()));replace[str(old)]=str(target)
ref=Path('/home/dario/Code/cocoon-spike/go/dd/bench_test.go');target=folder/'reference_bench_test.go';target.write_text(observe(ref.read_text()))
(out/'reference-overlay.json').write_text(json.dumps({'Replace':{**json.loads((out/'reference-overlay.json').read_text())['Replace'],str(ref):str(target)}},indent=2)+'\n')
trace=folder/'trace_holdout_test.go';trace.write_text('''package dd
import ("bytes"; "crypto/sha256"; "runtime"; "testing")
func BenchmarkPhase0TraceHoldout(b *testing.B) {
 batchingProcessors(b,1)
 library:=openTest(b,Options{Instances:1})
 inputs:=[][]byte{tracePayload(32),tracePayload(1000),tracePayload(4096)}
 expected:=make([][]byte,len(inputs));hashes:=make([][32]byte,len(inputs))
 for index,input:=range inputs{ var err error;expected[index],err=library.ObfuscateTraces(b.Context(),input);if err!=nil||len(expected[index])==0{b.Fatal("holdout setup",err)};hashes[index]=sha256.Sum256(expected[index]) }
 index:=0;var result []byte
 b.ReportAllocs();b.ResetTimer()
 for b.Loop(){var err error; result,err=library.ObfuscateTraces(b.Context(),inputs[index]);if err!=nil||len(result)!=len(expected[index]){b.Fatal("holdout call",err)};index=(index+1)%len(inputs)}
 b.StopTimer();last:=(index+len(inputs)-1)%len(inputs)
 if !bytes.Equal(result,expected[last])||sha256.Sum256(result)!=hashes[last]{b.Fatal("holdout output")}
 if runtime.GOMAXPROCS(0)!=1{b.Fatal("actual processor mismatch")};b.ReportMetric(1,"actual-procs")
}
''')
replace[str(root/'examples/datadog/go/dd/phase0_trace_holdout_test.go')]=str(trace)
(folder/'overlay.json').write_text(json.dumps({'Replace':replace},indent=2)+'\n')
subprocess.run(['/usr/bin/gofmt','-w',*map(str,folder.glob('*.go'))],check=True)
(folder/'source.json').write_text(json.dumps({'original_harness_sha256':{str(root/'examples/datadog/go/dd'/name):hashlib.sha256((root/'examples/datadog/go/dd'/name).read_bytes()).hexdigest() for name in ['bench_test.go','varied_bench_test.go','negative_bench_test.go']},'reference_harness_sha256':hashlib.sha256(ref.read_bytes()).hexdigest(),'change':'deferred StopTimer and observable actual P1 metric outside original timed loops; broad trace is authored shared holdout with 32/1000/4096 spans, timed length/error check and outside-timer final exact bytes/digest'},indent=2)+'\n')
