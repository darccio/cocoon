# Host review of private unit transport ceiling specification

Reviewed `docs/unit-transport-ceiling.md`, SHA-256
`0286fa5d20813a16a52048f760d16c6e1b67d92c7cfd05d209ee2664108e9e11`,
on 2026-10-13. Status shows only the new untracked specification on
`task/unit-transport-ceiling`; no production edit/build/test/timing was performed.

Verdict: scope and host invariants are coherent. One minimal wording correction
is requested before signing: explicitly state that **disabled mode, for every
status including OK, invokes original ResultView exactly once and applies the
original successful-unit emptiness check**. Existing text makes disabled guest
execution exact and describes enabled OK/non-OK correctly, but leaves disabled
OK host behavior implicit. This closes the only query/control ambiguity; it is
not a request to broaden the experiment.

The complete successful transport omission is materially different from checked
unit specialization/fused callbacks. Both callbacks, resource/admission/execution
locks, current generation/epoch ownership, reset/recovery, post-Memory/MaxMemory,
non-OK error validation/precedence/ownership, poisoning, once-only destruction,
replacement and terminal drain remain. Retained reply query observability is
required both in mocks and frozen assembly. Enabled OK intentionally bypasses
wire safety rather than validating stale metadata.

The exact three stores include descriptor pointer/length and cached vector
length; stale data/error metadata and future normal operations are explicitly
proved. Malformed OK divergence is documented rather than presented as ABI 3
equivalence. Original Wasm provides finite state/Count/protobuf witnesses, not
proof of the deliberately omitted wire effects. Fake-module semantic mutants
test all remaining checked obligations rather than merely expecting a crash.

Dynamic checked/oracle modes within one ELF, direct source-untouched Add, and
the preregistered bare ELF bracket address distinct scaffold/linkage confounds.
No equal-source/equal-speed or original-ELF identity claim follows. All primary
adaptive/fixed-prefix and scalar corpus controls, SQL/batch/trace holdouts and
one/sixteen-home complete streams remain in scope with actual leaf processors.
Fresh independent reference contracts stay separate. The repeated >=10% both-
control decision and strict repeated guard losses cannot be rescued by retiming
or a slower scaffold. Neither a positive ceiling nor unchanged quality gates
accept M1 or authorize a new supported ABI.

After the one explicit disabled-path sentence is added, READY to sign this
private specification before implementation. No additional host redesign or
public-contract proposal is necessary for the diagnostic. Reviewer stops tools.
