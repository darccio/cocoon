from pathlib import Path
import json
root=Path.cwd();out=root/'.cache/boundary-ceiling-phase0';s=json.loads((out/'summary.json').read_text());decision=json.loads((out/'decision.json').read_text())
text='''# Successful-unit transport ceiling — 2026-10-13

**NO-GO.** Signed private specification bf01a1a preceded the ignored prototype.
The unsupported joint guest-publication/host-validation oracle misses every
required 10% primary comparison. Repeated original, varied and holdout SQL
losses also trigger the frozen collateral guard. No production implementation,
new public contract or M1 acceptance follows. Park this exact question without
flag/helper/layout/numeric/cache tuning or selected retiming.

The source-pinned AST generator clones only Sketch.Add's guest entry into an
additional private overlay. Exactly three successful publication stores are
conditional. STATE release, buffer init/borrow, complete handle resolution,
exact mathematics/counter/collapse/errors and stack restoration remain.
The pointer-read expression and its bounds remain; the ordinary compiler sinks
its pure loaded value into the disabled-publication branch. Enabled machine
work therefore also omits that publication-dependent value load. The host keeps
one observable reply Memory interface CALL, both consumer callbacks and all
original admission/ownership/locks/reset/recovery/post-memory/poison/drain.
Disabled all-status and enabled non-OK use original ResultView exactly once.
Enabled OK deliberately skips descriptor/limit/range/unit checks and leaves old
output metadata. Explicit canaries demonstrate ABI3 divergence. This is a
ceiling of the tested dynamic scaffold, not a mathematical maximum, safe ABI3
optimization, generic typed-return proof or attained release implementation.

Frozen ELF roles are bare original, augmented source-untouched original,
same-ELF checked scaffold and same-ELF oracle. Original calls Add directly;
scaffold reloads the mutable mode inside each actual timed loop. Adding source
changes linkage; augmented original is not an untouched production ELF. Bare
shares the original-only replay harness and outside-timer processor observation.
Report every scaffold/linkage penalty. The future public ABI approval gate
remains closed; the private diagnostic defines no shipping contract.

## Conditions, all samples and negative precision results

Official Go1.26.8, CGO0, GOAMD64v1, PGOoff; actual P1 scalar/SQL/batch/trace,
actual P1/P16 complete streams. Ryzen7 5800HS, Linux7.2.8-1-default, powersave
with boost enabled, CPUs0..15 available and no imposed affinity. GOGC100,
GOMEMLIMIToff; GODEBUG/GOEXPERIMENT empty and GOWORKoff. Seven fresh-process
samples per cell, rotated 500ms screening and reversed1s confirmation, with
fixed prefixes4,194,304/8,388,608 using benchtime1x (one complete prefix).
Raw fixed ns/op is the WHOLE prefix; ns/input/points/op=N are separate metrics.
Adaptive calibration has different actualN; each sample verifies full Count/
protobuf against its own fresh untimed original replay after StopTimer.

All481 frozen identities remain unchanged through25 groups/70 cases per pass,
980 rows at07:14:56–07:29:24UTC. All raw rows, allocations/custom metrics,
full process logs/commands, conditions and derived aliases remain. No build,
test, lint, fuzz, profile, memory observer or reviewer tool overlaps timing.
PID/PPID/command-name conditions do not prove exclusive use of the desktop;
load averages changed2.05/2.10/2.28 to4.51/3.31/2.78. External work is not
attributed to a specific sample or removed.

Screening Fixed Increasing is a negative precision result: pooled per-input
observations span84.71–205.9ns and do not establish a gain. Confirmation spans
84.47–91.74ns. Streaming and broad trace are also unstable across sets;
confirmation BroadTrace has a27.22% adverse augmented median but p=.902.
These observations are retained, with no filtering, retiming or equality claim.
All significance values are exploratory unadjusted benchstat comparisons
(seven samples), with multiple-testing limitations. Reference ratios are
contextual M1 comparisons, explicitly excluded from code-regression predicates
in the plan before data; bare/augmented comparisons remain mandatory guards.

## Complete scalar

Times below are ns/input for fixed prefixes and ns/op for adaptive calls.

| Set | Scope | Bare | Augmented original | Checked scaffold | Oracle |
| --- | --- | ---: | ---: | ---: | ---: |
'''
for rd in ['screen','confirm']:
 for key in ['Adaptive-Increasing',*[k for k in s[rd] if k.startswith('Fixed-')]]:
  g=s[rd][key];metric='ns/input' if g['scope']=='fixed' else 'ns/op'
  text+='| '+rd+' | '+key+' | '+' | '.join(f"{g['roles'][role]['metrics'][metric]:.2f}" for role in ['Bare','Original','Checked','Oracle'])+' |\n'
text+='''
Adaptive oracle time reductions are3.15%/3.79% versus bare,2.15%/3.08% versus
augmented original and6.27%/6.97% versus slower checked scaffold (all p=.001).
Confirmation Fixed Increasing gains4.62%/3.65%/6.93% (all p=.001); screening
has adverse+17.95%/+7.91% medians versus bare/original, with p=.805/.710, and
only5.55% versus checked (p=.383). All12 primary predicates fail. No control-
only gain, nearby reuse or holdout improvement rescues the frozen decision.

All scalar roles allocate0B/op and0allocs/op in both adaptive sets. Initial
and final timed linear memory are1,179,648B with zero growth there; untimed
Count/Encode/witness work is separate. These are logical linear-memory
observations, not process heap, stack or RSS limits. Full fixed metrics and
owned protobuf sizes are preserved per row rather than collapsed into a bound.

## Original workloads and holdouts

These methods execute original code. Times are ns/op; source-untouched code
in the augmented link can still have collateral costs.

| Set | Scope | Bare | Augmented | Delta time | Unadjusted p |
| --- | --- | ---: | ---: | ---: | ---: |
'''
for rd in ['screen','confirm']:
 for key,g in s[rd].items():
  if not key.startswith('Bracket-'):continue
  c=next(c for c in g['comparisons'] if c['baseline']=='Bare')
  text+=f"| {rd} | {key} | {g['roles']['Bare']['metrics']['ns/op']:.2f} | {g['roles']['Augmented']['metrics']['ns/op']:.2f} | {c['delta_percent_time']:+.2f}% | {c['unadjusted_p']:.3f} |\n"
text+='''
Original SQL loses2.54%/2.45% (p=.024/.001), varied SQL4.11%/4.38% and SQL
holdout4.43%/4.47% (all p=.001). All three repeated same-comparator guards
reject. Original batch+1.95%/+0.20%, trace+1.17%/+1.56% and broad batch
+0.55%/+0.26% remain adverse undetected medians. Broad trace loses1.82% in
screening (p=.002), then has the noisy27.22% confirmation loss (p=.902).
Neither nondetection nor unchanged source establishes performance equivalence.

Fresh independent locked Rust1.97/Binaryen133/Wasm2Go0.4.16 plus its own hardener
reproduces the original Wasm and module hashes. Original/wazero functional
oracles pass. Exact selected authored inputs are archived, with locked upstream
revision; not every transitive dependency is fingerprinted. The inherited
reference helper's final print still mentions a one-iteration benchmark; its
actual command journal confirms that invocation was omitted and no reference
benchmark ran during preparation. Reference timing uses its own frozen ELF
with outside-timer actualP1 observation. Its ABI2 borrowed/background/four-home,
error-checking and workload differences remain context, not removable costs.

Spike scalar55.07/55.12ns gives fresh110% limits60.577/60.632ns. Even the
unsupported adaptive oracle85.51/85.52ns misses those by41.16%/41.05% and
the historical55.44ns scalar limit by54.24%/54.26%. Original augmented SQL
2.178/2.178us is below historical2.2154us and fresh2.1956/2.1813us limits
in this scope, but its repeated collateral losses still reject the candidate.
This matrix is not a new safe full-M1 qualification. M1 remains unaccepted.

## Complete streaming and serialization observations

Every operation includes construction,256 nominal64-byte chunks, owned outputs,
End and disposal, retaining finite32-output groups. Holdout varies/empties
chunks. These unselected production methods retain all standalone checks.
ActualP1 one-home and actualP16 one/16-home topology are measured explicitly;
the testing-name suffix is not the actual processor count.

| Set | Scope | Bare ns/stream | Augmented ns/stream | Bare writes/s | Augmented delta | p |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
'''
for rd in ['screen','confirm']:
 for key,g in s[rd].items():
  if not key.startswith('Stream-'):continue
  c=g['comparisons'][0];m=g['roles']['Bare']['metrics']
  text+=f"| {rd} | {key} | {m['ns/op']:.0f} | {g['roles']['Augmented']['metrics']['ns/op']:.0f} | {m['writes/s']:.0f} | {c['delta_percent_time']:+.2f}% | {c['unadjusted_p']:.3f} |\n"
text+='''
Untouched P16 screening rates are1.276/5.962M writes/s fixed and0.885/5.208M
holdout for one/16 homes. Confirmation is1.254/9.618M fixed and1.183/10.208M
holdout. Confirmation ratios are7.67x/8.63x; preserve the lower screening
observations and substantial uncertainty. These are full-lifetime rates of the
retained resource-home feature, not strict maximum ceilings, a new unit-oracle
throughput gain or a new streaming promotion. DefaultP1 fixed has a detected
0.66% screening loss (p=.026) and0.28% undetected confirmation loss (p=.710).
Every other adverse streaming median remains in the table/raw rows.

## Proof, gates, source identity and retention

Final native amd64/386 full replays each execute301,989,888 Add calls across
three roles/eight corpora/two prefixes. Every input returns the expected nil error;
all final Count and complete protobuf bytes agree. Exact seven8192-value corpus
arrays, complete ordered input-bit SHA and owned protobuf goldens are retained.
Initial replays preceded an untimed corpus-export addition; distinct final
rebuild/replay logs qualify the final timing ELFs. Initial records remain.
This is finite Go consistency, not full-N original-Wasm or universal proof.

The final bounded Wasm driver is582 actual operation-export calls/architecture:
15 constructors,552 methods,15 destructors; six identity queries,three init
and582 reserve/582 output queries are separately charged. Both native targets
match Count8233/protobuf SHAa56f1b1f9510e63cf8a359922541f4378296138ac5b8b45a6c0b27eb1d27d7b4.
Unmodified AddMany8192 setup crosses collapse and actual1,245,184→1,507,328B
growth, followed by revisits/errors/invalid-tail atomicity. Domain edges,
stale/fresh full-width handles, independent resources, real owned-error objects
and reply bytes, and explicit stale-descriptor transitions pass. The retained
error-object assertion was corrected before finalnative proofs/timing; initial
proof-only source/logs are retained separately.

Observable fake-module memory-query order/replacement/growth/panics, non-OK
precedence/status/error ownership, independent post-MaxMemory override, complete
call/host-marker reset, poison/epochs/no next callback, alias close and drain
pass on native amd64/386. Four compiled semantic mutants per architecture
drop reply query, post-memory check, non-OK validation or detected-fault poison;
all eight exit1 with their required concrete assertion markers. Compiler or
startup failures receive no credit. Source/binding/drift/mechanical-clone
negative tests also pass. The absent distributed objdump was built from exact
officialGo1.26.8 source; executable/source identity and failed initial lookup
are retained. Final ordinary assembly proves actual mode reload/branch and
observable indirect replyMemory CALL; no profile or instrumentation is timed.

All seven production gates pass: make check (49 strict pinned2.13.1 linters),
race, rust/native+all-featureClippy, cross, smoke, fuzz and integration. Make check
uses official Go 1.26.8; other Go gates use system Go 1.27.2 and Rust 1.97.0.
Two complete compute/Datadog/streaming builds and generated-runtime repetitions
leave all61 production artifact/lock/harness fingerprints unchanged. Existing
production ownership/re-entry/Goexit tests supplement the private reply scope.
No nativearm64, new public ABI, compiler pass, release speedup or M1 acceptance
is claimed. Guest/host/adversarial preimplementation and applied/result reviews,
exact commands, hashes, positives, authoring negatives and raw statistics are
archived together with the authored cause/generated overlay.

The private spec remains its unchanged historical checkpoint. Root uses darna,
exact staged validation and approved local SSH-signed docs commits; no push
or PR publication is authorized. Evidence-only retention rejects the prototype
for production. A future supported transport requires a separately reviewed
version/compatibility/migration/generator/runtime proposal and explicit operator
approval before implementation; this no-go does not prove all future ABIs
impossible. Do not revive this exact dynamic scaffold or numerical cache round.
'''
# Format numeric prose for readability without changing tables/data.
for a,b in {'Go1.26.8':'Go 1.26.8','CGO0':'CGO disabled','GOAMD64v1':'GOAMD64=v1','PGOoff':'PGO off','Ryzen7':'Ryzen 7','Linux7.2.8':'Linux 7.2.8','CPUs0..15':'CPUs 0..15','GOGC100':'GOGC=100','GOMEMLIMIToff':'GOMEMLIMIT=off','GOWORKoff':'GOWORK=off','reversed1s':'reversed 1 s','prefixes4,194,304':'prefixes 4,194,304','benchtime1x':'benchtime=1x','actualN':'actual N','All481':'All 481','through25':'through 25','at07:14:56':'at 07:14:56','07:29:24UTC':'07:29:24 UTC','changed2.05':'changed 2.05','to4.51':'to 4.51','span84.71':'span 84.71','84.47–91.74ns':'84.47–91.74 ns','a27.22%':'a 27.22%','are3.15%':'are 3.15%','bare,2.15%':'bare, 2.15%','and6.27%':'and 6.27%','gains4.62%':'gains 4.62%','adverse+17.95%':'adverse +17.95%','only5.55%':'only 5.55%','All12':'All 12','allocate0B/op':'allocate 0 B/op','and0allocs/op':'and 0 allocs/op','are1,179,648B':'are 1,179,648 B','loses2.54%':'loses 2.54%','SQL4.11%':'SQL 4.11%','holdout4.43%':'holdout 4.43%','batch+1.95%':'batch +1.95%','trace+1.17%':'trace +1.17%','loses1.82%':'loses 1.82%','noisy27.22%':'noisy 27.22%','Rust1.97':'Rust 1.97','Binaryen133':'Binaryen 133','Wasm2Go0.4.16':'Wasm2Go 0.4.16','actualP1':'actual P1','actualP16':'actual P16','scalar55.07':'scalar 55.07','fresh110%':'fresh 110%','limits60.577':'limits 60.577','oracle85.51':'oracle 85.51','historical55.44ns':'historical 55.44 ns','historical2.2154us':'historical 2.2154 µs','fresh2.1956/2.1813us':'fresh 2.1956/2.1813 µs','construction,256':'construction, 256','nominal64-byte':'nominal 64-byte','finite32-output':'finite 32-output','are1.276':'are 1.276','and0.885':'and 0.885','is1.254':'is 1.254','and1.183':'and 1.183','are7.67x/8.63x':'are 7.67×/8.63×','DefaultP1':'Default P1','and0.28%':'and 0.28%','execute301,989,888':'execute 301,989,888','seven8192-value':'seven 8,192-value','is582':'is 582','constructors,552':'constructors, 552','methods,15':'methods, 15','queries,three':'queries, three','and582':'and 582','Count8233':'Count 8,233','SHAa56':'SHA a56','AddMany8192':'AddMany 8,192','actual1,245,184':'actual 1,245,184','finalnative':'final native','exit1':'exit 1','replyMemory':'reply Memory','pinned2.13.1':'pinned 2.13.1','all-featureClippy':'all-feature Clippy','systemGo1.27.2':'system Go 1.27.2','official1.26.8':'official 1.26.8','exportdata':'export data','all61':'all 61','nativearm64':'native arm64'}.items():text=text.replace(a,b)
(out/'report-body.md').write_text(text)
