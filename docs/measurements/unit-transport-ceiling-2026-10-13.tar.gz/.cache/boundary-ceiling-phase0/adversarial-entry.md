# Adversarial entry: one structural successful-call boundary ceiling

Read-only entry at clean HEAD `47f307971894d9257023dca1d6d7d848a2d0bc55`; local main/origin compare 0/0. Reviewed current roadmap, performance history, ABI v3, design review, checked runtime/template, resource/lifecycle/errors/batch and authored/generated Datadog facade/export/layer sources. No builds, tests, lint, profiles or benchmarks, no tracked edits. This note is entry advice, not approval of a new public ABI or production implementation.

## Distinct question and scope

Ask one question: **Does eliminating the entire successful-unit wire publication/descriptor transport, while retaining the complete remaining supported scalar envelope and exact guest algorithm/state effects, expose at least a 10% complete original-scalar ceiling?** A same-envelope ceiling can bound whether a prospective payload-free success contract is worth a separate compatibility/proof proposal. A maximal raw bridge that also discards admission, ownership, locking, recovery, reset or post-memory checks answers a different unsupported question and cannot establish this transport ceiling or an attainable checked design.

This must be materially broader than rearranging the existing ResultUnit/ResultView helper or flattening Resource.Use to Instance.Call. The former already improved its isolated component 18.72%/18.80% but failed original scalar against untouched in both sets, with repeated varied/holdout SQL regressions. The fused Resource.Call/Call.Handle callback boundary likewise failed its intended scalar benefit. R1-R7/R9-R11 shared-core/recovery/layout attempts and separate-file placement failures remain rejected. Do not relabel their helpers or profile them again as an untried structural question. Numeric cache, approximation, compiler predicates and PGO remain separate and parked/qualified under their existing scopes.

The source confirms scalar Add has no variable-input reservation/copy. Its actual envelope is nil checks, Lifecycle Enter/Leave, shared Resource cell lock/KeepAlive/alive/epoch/full-width handle, Instance execution lock/state/direct deferred recovery/Host panic reset/full Call reset, real typed export, ResultView/empty-unit shape, separate post-call current Memory/MaxMemory, immediate protocol poisoning and release. Count/Encode/Close, typed buffers, home replacement and stateless pool/recycle have their own paths. Any claim to remove the 'full bridge' must enumerate which of these remains and which is intentionally omitted.

## Unsupported model versus attainable implementation

A private diagnostic may estimate a counterfactual success transport, but it must be explicitly unsupported. ABI3 requires guest publication and host checks of descriptor8, current memory, MaxOutput, full payload logical range even when empty, status and unit shape. Omitting them changes observable query/trap/error/state semantics. It cannot be described as an ABI3-conforming fully checked fast path, equivalent release checker removal, or attainable ceiling merely because the other locks and checks still execute.

Keep an omission ledger: guest reply metadata writes/state, host reply Memory query, descriptor/range/output-limit/shape checks and any adapter dispatch that disappear. Separate host-read-only elision (original guest publication still executes) from a full prospective publication+transport elision. The former is a partial counterfactual, not evidence of full typed-return cost. Do not cache pointer/length or prevalidate a successful reply in untimed setup and claim a universal guarantee; alternating Memory, shrink/grow/replacement, arbitrary replies and real faults violate it.

Retain current ABI3 slow/error paths, query and precedence where modeled, plus exact independent post-Memory/MaxMemory and panic/poison boundary. A malformed-success wire test must demonstrate and label the counterfactual's deliberate loss of ABI3 validation rather than being excluded and then claimed equivalent. Source-pinned one-payload success assumptions are sufficient only for that finite diagnostic. No exported Resource.Call, Call.Handle, ABI method, supported option, manifest/schema/version or guest export/signature is introduced by it. Private authored diagnostic cause/overlays may exist only after its scope/proof is reviewed; generated-only production edits and reference code transplants are not authorized.

A future typed-return proposal would require a versioned status/result/error representation, type-width/float-bit/bool rules, memory-limit/fault/owned-error semantics, schema/export verification, mixed old/new compatibility and migration, all affected generators and runtimes, and an explicit operator decision BEFORE implementation. Unit Add is status-only already; an empty output shape does not by itself require scalar-result multivalue signatures. Do not oversell this unit ceiling as proof for generic direct scalar results, variable outputs or constructors.

## Controls and provenance required before the one measurement

Freeze the whole authored diagnostic source, actual generated variants, original guest/Wasm/runtime/facade/harness identities, ordinary machine code and toolchain. Untouched production is mandatory; regenerate/roundtrip and reproduce its earlier same-toolchain binary if feasible. Preserve that frozen ordinary original benchmark source. New test-only source has previously reversed a full-stream sign; a newly linked untouched binary needs an explicit old-binary bracket and cannot silently replace it.

Use baseline supported facade, identical private scaffold disabled, and enabled counterfactual in the same ELF where possible. All disabled/enabled per-call control work and input/output consumption must be matched and real timed work. Record dynamic flag environment, selected shape and exact source diff; prevent mode-constant DCE and check actual compiled branches. A separate untouched role detects scaffold and linkage penalties; a win against a slower scaffold alone fails. If making modes changes guest code, memory setup, globals, native text, retained state or error bodies, retain these confounds rather than claiming a sole transport mechanism.

Execute the original complete scalar facade, not a new raw call pretending to be it. Keep exact ordered increasing inputs and genuine live resource lifetime. Fixed equal-prefix supplements isolate state evolution; ordinary adaptive roles may calibrate different prefixes and must disclose that. Count/full protobuf, invalid-input atomicity and reuse are checked outside timing; full-N Go checks/digests are finite consistency, not full-N Wasm or universal transport proof. No pre-read live handle/parameter, hoisted admission or batched N calls replaces per-call work. Bound retention independent of b.N and time any real dispatch, status, digest/result work consistently.

Official Go1.26.8, CGO0, GOAMD64v1, PGOoff; record compiler/GOROOT/compiler/linker identities and processor/governor/affinity/GC conditions. Set/assert/report GOMAXPROCS inside actual measured leaves (including original or copied-original diagnostics), not parents or suffix-only assumptions. Freeze all before timing. Profiles/SSA/builds/quality/review tools run separately; stop every local tool throughout all qualified samples. Preserve every raw row, allocation/custom metric, process invocation, failure and negative; no filter/outlier deletion. Seven alternating screening passes and seven independently reversed confirmation passes are sufficient for the bounded decision; exploratory p-values are unadjusted and nondetection is not equality.

Fresh independent reference uses its own locked source/pipeline and original oracles, no implementation transplant. Its ABI2 borrowed/background/four-instance and original batch/trace differences remain context, not the removable safety cost. Do not add profile cumulative percentages, independent layer differences or separately measured optimistic ceilings. Existing ResultView 8.92%-11.17% attribution and Guest/Facade differences cannot promise a 10% gain. The unsupported log oracle's70.74ns cannot be arithmetically combined with a new boundary saving.

## Invariant proofs and holdouts

For the unchanged retained envelope, require exact legal-error classes/fields/owned messages, all positive/negative/unknown/PENDING statuses, descriptor/range/MaxOutput precedence on preserved paths, zero-size pointers/logical len versus cap, current/replacement/grown memory and independent post-MaxMemory override. Test alternating/panicking Memory query histories to catch hidden removed/repeated queries; disclose success omissions explicitly. Trap and import panic classification/host marker reset, immediate epoch invalidation/stale aliases/no next callback, once-only destructor and old-handle nonmigration remain mandatory.

Exercise callback/decoder panic and Goexit unlock/Leave/KeepAlive obligations, alias Close concurrent with Use, blocked admitted call then actual terminal-admission observation/drain, expected error followed by healthy call, pooled faulty callback capacity restoration where affected, sibling homes/replacement and full-width generation handles. A dynamic success bridge cannot create re-entry or expose Call/memory lifetime. Mutants must run and fail explicit semantic assertions, not compiler/startup faults. Actual amd64 and386 correctness are distinct from cross compilation; no native arm64/big-endian claim without execution.

The guard matrix includes original scalar/SQL/batch/trace, varied scalar/SQL, negative bins, increasing and independent broad scalar, SQL holdout, matched repeated/broad batches, and fixed/variable/empty streaming lifetimes. P1 one-home plus P16 one/sixteen-home streams include New/Write/End/Close, bounded owned Retain32 outputs and untouched oracles/warmup outside. If stream implementation is byte-identical, its named roles are conditions brackets, not candidate gains/equivalence. If reply/Close changes, use actual distinct generated roles. No component-only or raw Guest gain substitutes for complete scalar.

## Bounded stop rule

Preregister exactly four primary comparisons: **at least10% median TIME reduction and unadjusted p<.05 for complete original scalar against BOTH untouched and same-ELF disabled control in BOTH sets.** The question is positive only if all four pass; a one-round gain, sub10% gain, control-only gain, noisy inconclusive result, selected holdout gain or failed proof is NO-GO. Freeze guard rules before timing; conservative recommendation is no repeated detected scalar/SQL/batch/trace/complete-stream slowdown against the SAME comparator in both sets, including small scalar/SQL losses. Preserve upward/one-round/undetected medians rather than announcing equivalence. A threshold for tolerated minor nonprimary loss must be an explicit premeasurement choice, not a later waiver.

If the ceiling fails, park this structural boundary question with evidence; no follow-up unit-helper, fusion/defer/layout/flag variants, selected retiming, newholdout or policy rescue in this round. If it passes but a guard/proof fails, retain the positive unsupported ceiling and the negative; do not promote implementation. If it passes all gates, authorize only ONE separately scoped attainable feasibility/compatibility proposal. Any new public contract still requires approval before implementing even that next prototype. Its actual complete gain must be qualified independently after every required check is restored or made unnecessary by an approved representation; an optimistic unsupported bound is not that result.

Even10% from88.02ns leaves79.218ns, far above the historical absolute55.44ns and contextual fresh61.358ns limits. Those old medians are not today's acceptance result; a fresh full reference comparison remains required. No production gain/M1 acceptance follows from this entry or a private ceiling. The operator-approved budget is one structural question, not an open-ended sequence of small optimizations.

## Reviewed identities

- `docs/roadmap.md`: `cab5d4ac266d416b3a1ee71720380e0314291fc7ef9577ee3816610bba80fbe2`
- `docs/performance.md`: `42a2a1d776718c1efdf5ba6b8fd701faa01d54d025822b53669fe882964881f1`
- `docs/abi.md`: `f5534633c15c03e2799a53c6439ec42c9e4fafe6bac790fff035bb24fe7cc029`
- `docs/design-review.md`: `9dd2040d0fd83b0da15c1dfe7403d4dd988d91ec2be98905e77049879d548c9d`
- `rt/instance.go`: `607103f216fb1da1445e705deaea8891f21cbdd04f74e385f4958795ef107d74`
- `rt/resource.go`: `10576bedf0d4745afed6f73f4dd7db2c0f11c1018b302c2df5cfcfab96cfee8c`
- `rt/lifecycle.go`: `f3d9d622162f78f0b952e44a9aa21a5c1933d366e5078dbf93e8eada098b39b7`
- `rt/errors.go`: `08701336f91d84ef2b061f091eee8fc23ec5be2a67b39d315bdeb34ab970317e`
- `rt/batch.go`: `558812fe6c9773cfaa17f46ec71cace2656ad99f9f159d6bb1dac43803abb0f6`
- `internal/gen/rtgen/checked.go.tmpl`: `7f9e683d1c8bba45d5471b06ed82b09080a77d7aea8136da9d9cf16a00991740`
- `internal/gen/gogen/gogen.go`: `c26dc4d527d70c10a24a67e7b5f10d3414215b6453908192874ae98ac388a1d4`
- `examples/datadog/go/dd/cocoon_gen.go`: `3d5aeacda6069a347a0e91e7840792ec194b0cdfd414f3c33328ec037231d672`
- `examples/datadog/go/dd/zz_adapter.go`: `1c8c8471f924e9f5b75dc3dcc6e421e112e2f5558827a320600660ae72ee962a`
- `examples/datadog/go/dd/internal/wasm/module.go`: `626550cafa323c490a6a2ec6b2b341656c40e223c7c84701e414078633dcc298`
- `examples/datadog/go/dd/bench_test.go`: `8417e155c36680cbbc74febe82eed90bfcfc8ba9c585a5088c6b4a7196f979e3`
- `examples/datadog/go/dd/layers_bench_test.go`: `a9313fc2b6bd358d423168f70922356a35c435d6aeef571bfed697667950e284`

Entry review complete; ALL TOOLS STOPPED after writing this ignored note.
