from pathlib import Path
import subprocess,json,hashlib,os,datetime
root=Path.cwd();out=root/'.cache/boundary-ceiling-phase0';folder=out/'assembly';folder.mkdir(exist_ok=True);go=root/'.cache/toolchains/go1.26.8/go/bin/go'
records=[]
for name,pattern in [('reply','Phase0UnitReply'),('guest','Phase0SketchAdd'),('scaffold','Phase0TransportScaffold'),('consumer','phase0TransportAdd'),('original','Sketch.*Add$'),('postcall','Instance.*Call$')]:
 args=[str(out/'objdump'),'-s',pattern,str(out/'augmented-amd64.test')]
 data=subprocess.check_output(args);assert data,name
 (folder/(name+'.asm')).write_bytes(data);records.append({'name':name,'argv':args,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
reply=(folder/'reply.asm').read_text();scaffold=(folder/'scaffold.asm').read_text()
assert 'ResultView' in reply and 'CALL' in reply and 'phase0TransportMode' in scaffold
subprocess.run([go,'vet','-overlay='+str(out/'augmented-overlay.json'),'./examples/datadog/go/dd/...'],env=dict(os.environ,GOTOOLCHAIN='local',CGO_ENABLED='0',GOCACHE=str(root/'.cache/go'),GOFLAGS='-buildvcs=false'),stdout=(folder/'private-vet.log').open('x'),stderr=subprocess.STDOUT,check=True)
(out/'compiler-observations.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ELF_sha256':hashlib.sha256((out/'augmented-amd64.test').read_bytes()).hexdigest(),'records':records,'assertions':'reply interface-call instruction and original ResultView cold call remain; scaffold disassembly refers to mutable global mode. Root/applied reviews must inspect placement inside actual loop, not merely symbol existence. No profile/measurement run.'},indent=2)+'\n')
print('PASS ordinary compiled branch/query observation and private vet',flush=True)
