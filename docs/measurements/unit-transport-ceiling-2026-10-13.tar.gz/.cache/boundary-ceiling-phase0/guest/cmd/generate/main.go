package main

import (
	guestgen "cocoonboundaryguest"
	"encoding/json"
	"flag"
	"fmt"
	"os"
)

func main() {
	source := flag.String("source", "", "pinned translated module")
	output := flag.String("output", "", "additional module method")
	metadata := flag.String("metadata", "", "JSON provenance")
	flag.Parse()
	if err := run(*source, *output, *metadata); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
func run(source, output, metadata string) error {
	data, err := os.ReadFile(source)
	if err != nil {
		return err
	}
	generated, info, err := guestgen.Generate(data)
	if err != nil {
		return err
	}
	if err := os.WriteFile(output, generated, 0600); err != nil {
		return err
	}
	raw, err := json.MarshalIndent(info, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(metadata, append(raw, '\n'), 0600)
}
