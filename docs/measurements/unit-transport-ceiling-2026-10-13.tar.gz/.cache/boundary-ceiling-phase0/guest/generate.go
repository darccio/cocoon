// Package guestgen authors an unsupported, source-pinned transport diagnostic.
package guestgen

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"go/ast"
	"go/format"
	"go/parser"
	"go/token"
	"strconv"
)

const SourceSHA = "626550cafa323c490a6a2ec6b2b341656c40e223c7c84701e414078633dcc298"

var pins = map[string]string{
	"Xcocoon_sketch_add": "6a74a4e0da288e8ec413d3ca56c55c0f2eef65660476612c19bdab7563800950",
	"load32":             "28f900370c75c3e9bf79928d92f8f6bde2db32d934e8a0f8ca3fd899de4e61da",
	"store32":            "55654779236d834236113c14ee920ebe9313fb639734328fc0eb861a2baa7eba",
	"i32":                "54be8f58aaca1547d4694f565e749d369e6b06ebd62afd1f97ef1352ef5ef6f0",
	"Module":             "84497dd947e05d5badcc4b3c888bd8862ad7a8e7b8d7f011c69020c0116c3d2c",
}

type Metadata struct {
	SourceSHA         string    `json:"source_sha256"`
	GeneratedSHA      string    `json:"generated_sha256"`
	OriginalMethodSHA string    `json:"original_method_sha256"`
	OmittedAddresses  [3]uint32 `json:"omitted_addresses"`
	Entry             string    `json:"entry"`
	UnsupportedABI    bool      `json:"unsupported_abi3"`
}

func digest(data []byte) string { h := sha256.Sum256(data); return hex.EncodeToString(h[:]) }
func printed(n ast.Node) string {
	var b bytes.Buffer
	if err := format.Node(&b, token.NewFileSet(), n); err != nil {
		panic(err)
	}
	return b.String()
}

// validateShape is deliberately tested independently of the complete-file pin.
// Raw declaration pins bind every effect, guard, evaluation and helper body;
// separate binding checks make name collisions and import changes explicit.
func validateShape(source []byte) (*ast.File, *ast.FuncDecl, error) {
	fs := token.NewFileSet()
	f, err := parser.ParseFile(fs, "module.go", source, parser.ParseComments)
	if err != nil {
		return nil, nil, err
	}
	if f.Name.Name != "wasm" {
		return nil, nil, fmt.Errorf("package drift")
	}
	if len(f.Imports) == 0 {
		return nil, nil, fmt.Errorf("imports missing")
	}
	mathBound := false
	for _, imp := range f.Imports {
		p, _ := strconv.Unquote(imp.Path.Value)
		if p == "math" {
			if imp.Name != nil {
				return nil, nil, fmt.Errorf("math import alias drift")
			}
			mathBound = true
		}
	}
	if !mathBound {
		return nil, nil, fmt.Errorf("math import missing")
	}
	found := map[string]ast.Node{}
	for _, d := range f.Decls {
		switch d := d.(type) {
		case *ast.FuncDecl:
			if d.Name.Name == "Phase0SketchAdd" {
				return nil, nil, fmt.Errorf("diagnostic name collision")
			}
			if _, ok := pins[d.Name.Name]; ok {
				if found[d.Name.Name] != nil {
					return nil, nil, fmt.Errorf("duplicate %s", d.Name.Name)
				}
				found[d.Name.Name] = d
			}
		case *ast.GenDecl:
			for _, spec := range d.Specs {
				switch spec := spec.(type) {
				case *ast.TypeSpec:
					if spec.Name.Name == "bool" || spec.Name.Name == "math" {
						return nil, nil, fmt.Errorf("builtin/import shadow")
					}
					if spec.Name.Name == "Module" {
						if found["Module"] != nil {
							return nil, nil, fmt.Errorf("duplicate Module")
						}
						found["Module"] = spec
					}
				case *ast.ValueSpec:
					for _, name := range spec.Names {
						if name.Name == "bool" || name.Name == "math" || name.Name == "store32" || name.Name == "load32" || name.Name == "i32" {
							return nil, nil, fmt.Errorf("binding shadow %s", name.Name)
						}
					}
				}
			}
		}
	}
	for name, want := range pins {
		node := found[name]
		if node == nil {
			return nil, nil, fmt.Errorf("missing %s", name)
		}
		start, end := fs.Position(node.Pos()).Offset, fs.Position(node.End()).Offset
		if name == "Module" {
			start -= len("type ")
		}
		if digest(source[start:end]) != want {
			return nil, nil, fmt.Errorf("declaration drift: %s", name)
		}
		if name == "load32" || name == "store32" || name == "i32" {
			fn := node.(*ast.FuncDecl)
			if fn.Doc == nil {
				return nil, nil, fmt.Errorf("missing helper directive")
			}
			nosplit := false
			for _, c := range fn.Doc.List {
				if c.Text == "//go:nosplit" {
					nosplit = true
				}
			}
			if !nosplit {
				return nil, nil, fmt.Errorf("nosplit drift: %s", name)
			}
		}
	}
	fn := found["Xcocoon_sketch_add"].(*ast.FuncDecl)
	collision := false
	ast.Inspect(fn, func(n ast.Node) bool {
		if id, ok := n.(*ast.Ident); ok && id.Name == "skip" {
			collision = true
		}
		return true
	})
	if collision {
		return nil, nil, fmt.Errorf("skip collision")
	}
	return f, fn, nil
}

func Generate(source []byte) ([]byte, Metadata, error) {
	if digest(source) != SourceSHA {
		return nil, Metadata{}, fmt.Errorf("complete source drift: got %s", digest(source))
	}
	_, fn, err := validateShape(source)
	if err != nil {
		return nil, Metadata{}, err
	}
	// The clone is parsed from immutable source separately: the original AST/file
	// is never rewritten or emitted. Only this new additional method is output.
	fn.Name = ast.NewIdent("Phase0SketchAdd")
	fn.Type.Params.List = append(fn.Type.Params.List, &ast.Field{Names: []*ast.Ident{ast.NewIdent("skip")}, Type: ast.NewIdent("bool")})
	target := []string{
		"store32(m.memory, uint32(i32(1101804)), uint32(t42))",
		"store32(m.memory, uint32(i32(1101800)), uint32(i32(0)))",
		"store32(m.memory, uint32(i32(1101808)), uint32(i32(0)))",
	}
	replaced := 0
	ast.Inspect(fn.Body, func(n ast.Node) bool {
		block, ok := n.(*ast.BlockStmt)
		if !ok {
			return true
		}
		for i := 0; i+2 < len(block.List); i++ {
			if printed(block.List[i]) != target[0] {
				continue
			}
			for j := 1; j < 3; j++ {
				if printed(block.List[i+j]) != target[j] {
					err = fmt.Errorf("publication order drift")
					return false
				}
			}
			if i == 0 || printed(block.List[i-1]) != "t42 := int32(load32(m.memory, uint32(i32(1101796))))" {
				err = fmt.Errorf("pointer-read drift")
				return false
			}
			stores := append([]ast.Stmt(nil), block.List[i:i+3]...)
			branch := &ast.IfStmt{Cond: &ast.UnaryExpr{Op: token.NOT, X: ast.NewIdent("skip")}, Body: &ast.BlockStmt{List: stores}}
			next := append([]ast.Stmt(nil), block.List[:i]...)
			next = append(next, branch)
			next = append(next, block.List[i+3:]...)
			block.List = next
			replaced++
			return false
		}
		return true
	})
	if err != nil {
		return nil, Metadata{}, err
	}
	if replaced != 1 {
		return nil, Metadata{}, fmt.Errorf("publication match count %d", replaced)
	}
	outFile := &ast.File{Name: ast.NewIdent("wasm"), Decls: []ast.Decl{&ast.GenDecl{Tok: token.IMPORT, Specs: []ast.Spec{&ast.ImportSpec{Path: &ast.BasicLit{Kind: token.STRING, Value: "\"math\""}}}}, fn}}
	var b bytes.Buffer
	b.WriteString("// Private phase-0 diagnostic generated by cocoonboundaryguest.\n// Unsupported under ABI 3; no Wasm export or supported API is added.\n")
	if err := format.Node(&b, token.NewFileSet(), outFile); err != nil {
		return nil, Metadata{}, err
	}
	output, err := format.Source(b.Bytes())
	if err != nil {
		return nil, Metadata{}, err
	}
	return output, Metadata{SourceSHA: SourceSHA, GeneratedSHA: digest(output), OriginalMethodSHA: pins["Xcocoon_sketch_add"], OmittedAddresses: [3]uint32{1101804, 1101800, 1101808}, Entry: "(*Module).Phase0SketchAdd(int64,float64,bool) int32", UnsupportedABI: true}, nil
}
