package guestgen

import (
	"bytes"
	"go/ast"
	"go/parser"
	"go/token"
	"os"
	"testing"
)

func original(t *testing.T) []byte {
	t.Helper()
	data, err := os.ReadFile("../../../examples/datadog/go/dd/internal/wasm/module.go")
	if err != nil {
		t.Fatal(err)
	}
	return data
}
func TestGeneratedExactClone(t *testing.T) {
	source := original(t)
	before := append([]byte(nil), source...)
	output, meta, err := Generate(source)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(before, source) || meta.OmittedAddresses != [3]uint32{1101804, 1101800, 1101808} {
		t.Fatal("source mutation/omission ledger")
	}
	_, want, err := validateShape(source)
	if err != nil {
		t.Fatal(err)
	}
	f, err := parser.ParseFile(token.NewFileSet(), "clone.go", output, 0)
	if err != nil {
		t.Fatal(err)
	}
	got := f.Decls[1].(*ast.FuncDecl)
	if got.Name.Name != "Phase0SketchAdd" || len(got.Type.Params.List) != 3 {
		t.Fatal("entry signature")
	}
	got.Name.Name = "Xcocoon_sketch_add"
	got.Type.Params.List = got.Type.Params.List[:2]
	count := 0
	ast.Inspect(got.Body, func(n ast.Node) bool {
		block, ok := n.(*ast.BlockStmt)
		if !ok {
			return true
		}
		for i, stmt := range block.List {
			branch, ok := stmt.(*ast.IfStmt)
			if !ok || printed(branch.Cond) != "!skip" {
				continue
			}
			if len(branch.Body.List) != 3 {
				t.Fatal("not three writes")
			}
			next := append([]ast.Stmt(nil), block.List[:i]...)
			next = append(next, branch.Body.List...)
			next = append(next, block.List[i+1:]...)
			block.List = next
			count++
			return false
		}
		return true
	})
	if count != 1 || printed(got) != printed(want) {
		t.Fatal("clone changes effects beyond the three-store branch")
	}
}
func TestDriftRejected(t *testing.T) {
	source := original(t)
	cases := []struct{ name, old, next string }{
		{"state-release", "uint32(t39+i32(1))", "uint32(t39+i32(2))"},
		{"init", "if t40 != i32(1)", "if t40 != i32(0)"},
		{"borrow", "if t41 != 0", "if t41 == 0"},
		{"pointer-read", "t42 := int32(load32(m.memory, uint32(i32(1101796))))", "t42 := int32(load32(m.memory, uint32(i32(1101792))))"},
		{"descriptor-pointer", "uint32(i32(1101804)), uint32(t42)", "uint32(i32(1101808)), uint32(t42)"},
		{"vector-length", "uint32(i32(1101800)), uint32(i32(0))", "uint32(i32(1101800)), uint32(i32(1))"},
		{"descriptor-length", "uint32(i32(1101808)), uint32(i32(0))", "uint32(i32(1101808)), uint32(i32(1))"},
		{"stack-restore", "m.g0 = v3 + i32(16)", "m.g0 = v3 + i32(32)"},
		{"helper-body", "val = bits.ReverseBytes32(val)", "val = bits.ReverseBytes32(val + 1)"},
		{"helper-directive", "//go:nosplit\nfunc store32", "// changed\nfunc store32"},
		{"module-field", "memory   []byte", "memory   []uint32"},
		{"math-import", "\"math\"", "aliasmath \"math\""},
		{"method-signature", "Xcocoon_sketch_add(v0 int64, v1 float64)", "Xcocoon_sketch_add(v0 uint64, v1 float64)"},
	}
	for _, test := range cases {
		t.Run(test.name, func(t *testing.T) {
			if !bytes.Contains(source, []byte(test.old)) {
				t.Fatalf("missing test source %q", test.old)
			}
			mutant := bytes.ReplaceAll(source, []byte(test.old), []byte(test.next))
			if _, _, err := Generate(mutant); err == nil {
				t.Fatal("whole-source drift accepted")
			}
			if _, _, err := validateShape(mutant); err == nil {
				t.Fatal("shape drift accepted independently of whole SHA")
			}
		})
	}
	for _, declaration := range []string{"var store32 = 1", "type bool int", "func (m *Module) Phase0SketchAdd() {}", "func store32() {}"} {
		mutant := append(append([]byte(nil), source...), []byte("\n"+declaration+"\n")...)
		if _, _, err := validateShape(mutant); err == nil {
			t.Fatalf("binding collision accepted: %s", declaration)
		}
	}
}
