# Guest implementation review — READY

2026-10-13. Signed private specification bf01a1a; current scope is an unsupported
successful-unit transport ceiling, without a supported ABI or production change.
All authored files are ignored under guest/. No benchmark or profile was run.

## Source cause and exact effect scope

The stdlib Go AST generator pins the complete translated source SHA626550ca...,
original Add declaration SHA6a74a4e0..., Module layout and load32/store32/i32
helper declarations/directives. It checks unique declarations, import/builtin
bindings, new-method collision and the exact publication order. The complete
source pin covers every remaining dependency, math, call, label and helper.
Independent shape tests bypass the whole-file pin, so a declaration/binding
failure is not hidden behind the top-level SHA rejection.

The output is a NEW additional method, Phase0SketchAdd(int64,float64,bool), in
NEW virtual module file. Original Module/Add/helper files stay untouched. It
wraps exactly three consecutive successful-label publication stores1101804,
1101800,1101808 in if !skip. STATE borrow release, t42 pointer read, buffer
initialization and borrow trap, input/domain checks, fn84 full-width lookup,
fn176 math and state, error publication, labels and stack restoration remain.
A parsed-output test removes that single branch and added parameter/name, then
compares the entire normalized method to the pinned original. This passes.
Negative source/shape tests reject changes to guards, addresses/values, helper
body/directive, field type, import, signature, restoration and collisions.
This is a source-pinned diagnostic cause, not a reusable production predicate.

The t42 read is source-preserved. Its value is consumed only by conditional
publication, so ordinary optimization may sink/eliminate the loaded value on
enabled execution once preceding bounds are established. No observable value
read is claimed; parent records actual frozen assembly. Parent confirms the
host reply Memory interface CALL and dynamic per-loop mode load survive.

## State proof and deliberate wire divergence

TestPhase0TransportGuest passes on actual native amd64 officialGo1.26.8, CGO0,
GOAMD64v1, PGOoff. The final386 ELF is compiled with the same pinned toolchain
and handed to parent for escalated native execution; this note does not claim
that pending execution completed. All final exact argv/environment/source and
ELF hashes are in commands.json/final-source-hashes.json. Raw focused logs and
setup/authoring negatives are preserved separately.

The original Wasm oracle independently compares statuses, exact expected error
kinds/messages, Count bits and every complete protobuf byte for all three
roles. The enabled path explicitly keeps previous nonempty protobuf/error
vector and descriptor metadata; disabled/checked success subsequently clears
it. Enabled non-OK still publishes/checks the original error, then valid calls
recover. This demonstrates the deliberate ABI3 violation; it is not an ABI3
wire equivalence claim.

All22 finite/domain edge cases include healthy argument-error atomicity.
Stale and wrong-high-generation handles are actually invoked inside the guest
under Instance.Call (separate from host owner rejection), compared to original
Wasm ErrHandle, then fresh-generation calls succeed on a healthy instance.
Resources are independent. Explicit close/reuse and alias close retain ownership;
parent runtime proofs additionally count once-only destructor and drain behavior.

An unchanged AddMany8192 setup exercises actual growth/collapse within the
export cap, followed by32 min/max revisits, negative-bin values, an invalid-tail
batch that must remain atomic and empty batch. The singleton Wasm low/high bins
prove range>2048 and the final first bin proves collapse. This is not an8192-
scalar Wasm history. All three checked guests grow1,245,184→1,507,328 logical
bytes; final Count8233 and complete protobuf SHAa56f1b1f9510e63cf8a359922541f437
8296138ac5b8b45a6c0b27eb1d27d7b4 match. Logical byte sizes are not heap/RSS.
Retained Go reply bytes and the actual owned error object survive guest overwrite
and growth; final Error()/AppError.Message are re-evaluated, not a copied-string
stand-in.

The shared actual original-Wasm ledger is582 operation exports per architecture:
15 constructors,552 methods,15 destructors. It charges one operation before
invocation, rejects exhausted2048 cap before the next export, and records6
identity queries,3 init calls and582 reserve/582 output base calls separately.
Every healthy-status operation reached its reserve, operation and output;
no trap/short-input startup is counted as a completed bounded operation.
Full-N Go replay and runtime fake/mutant proofs are separate parent/peer ledgers.

## Cross-review and limits

Host Phase0UnitReply composition is correct for this private scope: enabledOK
makes one interface query and skips wire validation; disabled every status and
enabled nonOK use ResultView exactly once with the original empty-unit rule.
The source-pinned Add envelope retains admission, both nested callbacks,
Resource.Use ownership, Instance.Call reset/recovery/post-memory and immediate
poisoning of detected faults. No scalar Reserve, pre-resolved handle or lifetime
change was added. Host shape audit passes exact original-envelope substitutions.
Adversarial cross-review is READY after the real-error-object ownership fix.

Parent must qualify final actual native386/full-N/query/mutant/assembly and frozen
ELFs before timing. Source proof, finite histories and unchanged gates do not
prove all guest equivalence, a supported direct-result ABI, release feasibility,
performance gain or M1 acceptance. Any supported contract requires a separate
explicit operator approval. No production/cache/numerical/generated lock edits
or future design are retained here. All reviewer tools stop after this note.
