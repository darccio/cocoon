# Guest results review — READY / NO-GO

2026-10-13. Read-only audit after all980 samples completed; no compiler, test,
profile or timing invoked by this reviewer. Only this ignored review note is
new. No source, arithmetic, caps, controls or measurement was changed.

## Decision from complete results

The signed advance rule fails. Adaptive Increasing oracle medians85.51/85.52
ns/input improve versus bare88.29/88.89 by3.149%/3.791%, augmented original
87.39/88.24 by2.151%/3.083%, and checked scaffold91.23/91.93 by6.270%/6.973%
(all six exploratory p=.001). These are repeated detected gains, but below10%
against each required comparator. They are complete counterfactual-path times,
not an additive estimate of three stores or a pure guest/host transport cost.

Fixed Increasing screen oracle153.6 ns/input versus bare130.2, original142.3
and checked162.6 has +17.952%(p=.805), +7.908%(p=.710), -5.550%(p=.383).
Confirmation oracle84.82 versus88.93/88.03/91.13 improves4.622%/3.652%/6.931%
(all p=.001), still below10% and not a repeated original/bare gain. Retain the
screening dispersion and every sample; do not replace the screen with a chosen
confirmation result or infer equality from nondetection. Fixed4M/8M state
sizes and evolving input histories differ by design, so cross-set absolute
medians do not isolate a per-call primitive.

The independent guard also fails. Augmented original SQL is2.542% slower than
bare(p=.024) in screen and2.446% slower(p=.001) in confirmation. VariedSQL is
4.111%/4.385% slower, SQLHoldout4.434%/4.469% slower (all p=.001). These methods
retain original source and never use the oracle helper. The bracket detects
collateral effects of the augmented frozen ELF; no causal attribution to the
three selected stores, unit reply, one source placement or guest mathematics
is justified. Primary and guard failures each independently establish NO-GO.
No retiming, layout rescue, alternate control, private supported-contract spec
or production implementation follows. No M1 acceptance or shipping speed claim.

## Source and actual machine omission

Current guest source/cause/output and386 ELF match every hash in
final-source-hashes.json. Generated method SHA14f8d577debd64a86698b86649eef46db
090ba3c1f345b4584bbcd6b3161a69e retains the exact original method after
mechanically unwrapping the one if !skip and restoring name/signature. Complete
source SHA626550ca... and61 tracked proof-before/proof-after identities match;
I also recomputed current tracked hashes with no mismatches. Production Module,
Add, helpers, rt boundary, original Wasm and all three fixture locks remain
unchanged. The source-pinned diagnostic is an additional ignored overlay method,
not a generic optimizer predicate or new Wasm export.

Frozen assembly-final/guest.asm shows t42's checked endpoint1101799
(CMPQ $0x10cfe7 and failure branch at0x692480/0x692487) BEFORE the dynamic skip
branch at0x692497. Its actual value MOVL from1101796 ($0x10cfe4,0x6924ad) is
sunk into the disabled branch immediately before pointer publication. Enabled
therefore keeps the source-preserved read's bounds/trap condition, but does not
execute that value load. The compiler optimization is explicitly part of this
exact ceiling. Do not claim enabled executes an observable t42 value read.
The three successful publication stores1101804/1101800/1101808 are conditional;
STATE release, initialization/borrow guards, status and stack restore remain.
No fn84 handle/math/classifier/fn176 body or arithmetic is rewritten.

Frozen reply.asm retains the enabledOK indirect Memory CALL at0x5c8caa; the
non-OK/disabled branch has one original ResultView CALL at0x5c8cb6. The
independent post-call Memory/MaxMemory boundary remains original. Query-count
proofs test observable replacement/panic order; assembly alone is not a proof
that Memory is pure or interchangeable. Dynamic mode is loaded in the actual
scalar-loop backedge, and both guest and host halves receive it.

## Proof ledgers and meaning

Final actual native amd64 and386 bounded logs pass. Independently recomputed
ledgers match: each architecture performs582 original-Wasm operation exports,
15 constructors +552 methods +15 destructors. The map sum is also582. Separate
base calls are6 identity,3 init,582 reserve and582 output. Each operation is
charged before execution; no history is renamed one call. Both architecture
role reports agree exactly. Checked guests grow1,245,184→1,507,328 logical
linear bytes; final Count8233 and full protobuf SHAa56f1b1f9510e63cf8a359922541f
4378296138ac5b8b45a6c0b27eb1d27d7b4 match all three roles and both architectures.
These sizes are not actual Go/Rust allocation or RSS guarantees.

The bounded proof exercises original-Wasm statuses/Count/full protobuf across
22 point-domain edges, errors without state mutation, stale/full-generation
handles, explicit generation reuse, independent resources, actual memory growth,
collapse/revisits, batch invalid-tail atomicity, empty batch and alias release.
The retained reply bytes and actual error object are re-evaluated after later
overwrite/growth. Collapse is prepared through unmodified AddMany8192, not8192
scalar Wasm exports; subsequent scalar calls and singleton low/high evidence
are charged separately. Passing this finite driver is not universal equivalence.

I independently compared all32 final native golden files (8 corpora ×2 prefix
sizes × .json/.pb): amd64/386 bytes are identical. Four final full-replay records
exit0. Total full-N Go Add calls per architecture is
24×(4,194,304+8,388,608)=301,989,888. Every input is accepted by all3 Go roles;
final exact Count/full protobuf agrees with source-untouched original. This is
Go state consistency, not a complete-N original-Wasm or universal proof.

## Deliberate successful-wire violations and retained boundaries

EnabledOK intentionally accepts wire shapes that ABI3 must reject: nonempty
unit, empty pointer beyond logical memory/spare capacity, widened end, short
payload/descriptor and output-limit violations. Some checked counterexamples
are protocol faults and poison immediately; MaxOutput failures alone do not
all poison. Avoid claiming every checked rejection changes epoch. Runtime fake
proofs retain concrete precedence, query counts, terminal epoch/no-next-callback,
owned opaque errors, reset, import/trap containment, alias release and drain.
Four executed mutants fail explicit semantic assertions on both native arches,
not compiler/startup failures.

Real guest transitions likewise leave old nonempty/error Vec.len and descriptor
words untouched on oracleOK, then checked success publishes canonical empty
metadata. NonOK still uses original publication and full original validation
once; a later valid point remains healthy. State/Count/protobuf equality does
not make those wire omissions valid under ABI3. No supported public contract,
ABI/schema/version, typed return, cache, generated lock, payload or shipping
implementation is retained. Further supported work would need fresh explicit
operator approval and independent feasibility/performance qualification.

READY to retain the private no-go evidence with these limits. Parent owns final
gates/archive/docs qualification. No additional reviewer tool activity is needed.
