from pathlib import Path
import datetime,hashlib,json,os,platform,re,statistics,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'.cache/boundary-ceiling-phase0';GO=ROOT/'.cache/toolchains/go1.26.8/go/bin/go'
ENV=dict(os.environ,GOTOOLCHAIN='local',CGO_ENABLED='0',GOAMD64='v1',GOMAXPROCS='1',GOGC='100',GOMEMLIMIT='off',GODEBUG='',GOEXPERIMENT='',GOWORK='off',GOFLAGS='-buildvcs=false',GOCACHE=str(ROOT/'.cache/go'))
ENV.pop('GOROOT',None)
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def policy():
 base=Path('/sys/devices/system/cpu')
 return {str(p):p.read_text().strip() for pattern in ['cpu*/cpufreq/scaling_governor','cpufreq/boost'] for p in sorted(base.glob(pattern))}
def conditions():
 return {'utc':utc(),'uname':platform.uname()._asdict(),'affinity':sorted(os.sched_getaffinity(0)),'cpu_policy':policy(),'cpuinfo':Path('/proc/cpuinfo').read_text(),'loadavg':Path('/proc/loadavg').read_text(),'frequencies':{str(p):p.read_text().strip() for p in sorted(Path('/sys/devices/system/cpu').glob('cpu*/cpufreq/scaling_cur_freq'))},'processes_pid_ppid_command_only':subprocess.check_output(['ps','-eo','pid,ppid,comm'],text=True),'env':{k:ENV[k] for k in ['GOTOOLCHAIN','CGO_ENABLED','GOAMD64','GOMAXPROCS','GOGC','GOMEMLIMIT','GODEBUG','GOEXPERIMENT','GOWORK','GOFLAGS']}}
def verify(frozen):
 for name,digest in frozen['sha256'].items():assert sha(name)==digest,name
def freeze():
 plan=json.loads((OUT/'plan.json').read_text())
 paths=[Path(v) for v in plan['binaries'].values()]+[OUT/'augmented-386.test',OUT/'runtime-amd64.test',OUT/'runtime-386.test',OUT/'objdump',GO,*[GO.parent.parent/'pkg/tool/linux_amd64'/name for name in ['compile','link','asm']],ROOT/'docs/unit-transport-ceiling.md',ROOT/'go.mod',ROOT/'go.sum']
 paths.extend(ROOT/p for p in json.loads((OUT/'proof-before.json').read_text()))
 paths.extend((ROOT/'rt').glob('*.go'))
 for p in OUT.rglob('*'):
  if not p.is_file() or 'reference-rust' in p.parts or '__pycache__' in p.parts or 'costs' in p.parts or 'spec' in p.parts:continue
  if p.suffix in ['.go','.txt','.py','.json','.jsonl','.mod','.sum','.pb','.wasm','.md','.log','.asm']:paths.append(p)
 paths=sorted(set(p.resolve() for p in paths))
 records={'utc':utc(),'HEAD':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'plan':plan,'conditions':conditions(),'go_version':subprocess.check_output([GO,'version'],text=True).strip(),'buildinfo':{k:subprocess.check_output([GO,'version','-m',v],text=True) for k,v in plan['binaries'].items()},'sha256':{str(p):sha(p) for p in paths}}
 assert 'go1.26.8' in records['go_version']
 for info in records['buildinfo'].values():assert 'go1.26.8' in info and 'CGO_ENABLED=0' in info and 'GOAMD64=v1' in info
 (OUT/'frozen-spec.md').write_bytes((ROOT/'docs/unit-transport-ceiling.md').read_bytes())
 (OUT/'frozen.json').write_text(json.dumps(records,indent=2)+'\n');print('FROZEN',len(paths),'sources/artifacts;',plan['expected_rows'],'declared rows')
def run():
 frozen=json.loads((OUT/'frozen.json').read_text());verify(frozen);plan=frozen['plan'];costs=OUT/'costs';costs.mkdir(exist_ok=False)
 before=conditions();assert before['affinity']==frozen['conditions']['affinity'] and before['cpu_policy']==frozen['conditions']['cpu_policy']
 (OUT/'measurement-before.json').write_text(json.dumps(before,indent=2)+'\n');rows=[]
 with (OUT/'records.jsonl').open('x') as records:
  for rd in plan['rounds']:
   for sample in range(7):
    verify(frozen);groups=plan['groups'];shift=sample%len(groups);groups=groups[shift:]+groups[:shift]
    if rd['reverse']:groups=list(reversed(groups))
    for group in groups:
     cases=group['cases'];shift=sample%len(cases);cases=cases[shift:]+cases[:shift]
     if rd['reverse']:cases=list(reversed(cases))
     for case in cases:
      selector='/'.join('^'+re.escape(part)+'$' for part in case['parts'])
      duration='1x' if group['scope']=='fixed' else rd['duration']
      cmd=[plan['binaries'][case['binary']],'-test.run=^$','-test.bench='+selector,'-test.benchtime='+duration,'-test.count=1','-test.cpu=1','-test.benchmem','-test.timeout=10m']
      extra={'COCOON_UNIT_PREFIX_N':str(rd['prefix']),'COCOON_UNIT_EXPECTED_DIR':str(OUT/'functional-final-amd64/goldens')}
      name=f"{rd['name']}-{sample}-{group['key']}-{case['role']}";filename=costs/(name+'.log')
      record={'round':rd['name'],'sample':sample,'group':group['key'],'role':case['role'],'scope':group['scope'],'binary':case['binary'],'argv':cmd,'env':extra,'started_utc':utc(),'raw':str(filename.relative_to(OUT))}
      with filename.open('x') as log:
       print('COMMAND',json.dumps(record),file=log,flush=True);result=subprocess.run(cmd,cwd=ROOT,env=dict(ENV,**extra),stdout=log,stderr=subprocess.STDOUT);print('EXIT',result.returncode,file=log,flush=True)
      record.update(exit=result.returncode,completed_utc=utc());assert result.returncode==0,name
      raw=filename.read_text();lines=[line for line in raw.splitlines() if line.startswith('Benchmark')];assert len(lines)==1,(name,lines);fields=lines[0].split()
      metrics={fields[i+1]:float(fields[i]) for i in range(2,len(fields),2)};assert metrics['actual-procs']==case['actual_procs'] and '\nPASS\n' in raw
      if group['scope']=='fixed':assert int(fields[1])==1 and metrics['points/op']==rd['prefix'] and metrics['count']==rd['prefix']
      record.update(iterations=int(fields[1]),metrics=metrics,raw_row=lines[0]);records.write(json.dumps(record)+'\n');records.flush();rows.append(record)
    print('PASS',rd['name'],sample+1,len(rows),'rows preserved',flush=True)
   verify(frozen);assert policy()==frozen['conditions']['cpu_policy']
 assert len(rows)==plan['expected_rows'];verify(frozen)
 (OUT/'measurement-after.json').write_text(json.dumps(conditions(),indent=2)+'\n');(OUT/'complete.json').write_text(json.dumps({'utc':utc(),'rows':len(rows),'frozen_sha256':sha(OUT/'frozen.json')},indent=2)+'\n')
def summarize():
 plan=json.loads((OUT/'plan.json').read_text());rows=[json.loads(line) for line in (OUT/'records.jsonl').read_text().splitlines()];assert len(rows)==plan['expected_rows'];folder=OUT/'statistics';folder.mkdir(exist_ok=False);summary={}
 for rd in plan['rounds']:
  summary[rd['name']]={}
  for group in plan['groups']:
   results={};files={}
   for case in group['cases']:
    selected=[r for r in rows if (r['round'],r['group'],r['role'])==(rd['name'],group['key'],case['role'])];assert len(selected)==7
    results[case['role']]={'metrics':{k:statistics.median([r['metrics'][k] for r in selected]) for k in selected[0]['metrics']},'iterations':[r['iterations'] for r in selected]}
    file=folder/(rd['name']+'-'+group['key']+'-'+case['role']+'.txt')
    with file.open('x') as output:
     print('goos: linux\ngoarch: amd64\npkg: private-unit-transport-ceiling',file=output)
     for r in selected:print('BenchmarkComparison/'+group['key']+'-1 '+' '.join(r['raw_row'].split()[1:]),file=output)
    files[case['role']]=file
   comparisons=[]
   for baseline,candidate in group['comparators']:
    name=rd['name']+'-'+group['key']+'-'+candidate+'-vs-'+baseline
    with (folder/(name+'.txt')).open('x') as output, (folder/(name+'.warnings')).open('x') as warnings:
     subprocess.run(['/home/dario/go/bin/benchstat','-filter','.unit:sec/op',files[baseline],files[candidate]],stdout=output,stderr=warnings,check=True)
    text=(folder/(name+'.txt')).read_text();match=re.search(r'p=([0-9.]+)',text);p=float(match.group(1)) if match else None
    delta=100*(results[candidate]['metrics']['ns/op']/results[baseline]['metrics']['ns/op']-1)
    comparisons.append({'baseline':baseline,'candidate':candidate,'delta_percent_time':delta,'unadjusted_p':p,'guard':[baseline,candidate] in group['guard_comparators'],'contextual_reference':[baseline,candidate] in group['contextual_comparators'],'benchstat':str((folder/(name+'.txt')).relative_to(OUT))})
   summary[rd['name']][group['key']]={'scope':group['scope'],'primary':group['primary'],'roles':results,'comparisons':comparisons}
 (OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 for rd,values in summary.items():
  for key in ['Adaptive-Increasing','Fixed-Increasing']:print(rd,key,values[key]['comparisons'])
if __name__=='__main__':{'freeze':freeze,'run':run,'summarize':summarize}[sys.argv[1]]()
