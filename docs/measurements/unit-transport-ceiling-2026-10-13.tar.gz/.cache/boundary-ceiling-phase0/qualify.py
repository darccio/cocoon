from pathlib import Path
import os, subprocess, json, hashlib, datetime, sys
root=Path.cwd();out=root/'.cache/boundary-ceiling-phase0'
env=dict(os.environ,GOTOOLCHAIN='local',CGO_ENABLED='0',GOCACHE=str(root/'.cache/go'),GOFLAGS='-buildvcs=false',GOLANGCI_LINT_CACHE=str(root/'.cache/lint'),RUSTUP_TOOLCHAIN='1.97.0')
env['PATH']=str(root/'.cache/binaryen/binaryen-version_133/bin')+':'+os.path.expanduser('~/.cargo/bin')+':'+env['PATH']
lint=str(root/'.cache/sessions-phase0/golangci-lint-2.13.1-linux-amd64/golangci-lint')
env.pop('GOROOT',None)
records=[]
(out/'quality-toolchains.json').write_text(json.dumps({name:subprocess.check_output(argv,text=True).strip() for name,argv in [('go_quality',['/usr/bin/go','version']),('go_measurement',[str(root/'.cache/toolchains/go1.26.8/go/bin/go'),'version']),('rust',['cargo','--version']),('rustc',['rustc','--version']),('lint',[lint,'version'])]},indent=2)+'\n')
def run(name,args,extra=None):
 item={'name':name,'log_file':name+'.log','argv':args,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (out/(name+'.log')).open('x') as log:
  print('COMMAND',json.dumps(args),file=log,flush=True)
  result=subprocess.run(args,env=env if extra is None else dict(env,**extra),stdout=log,stderr=subprocess.STDOUT)
  print('EXIT',result.returncode,file=log,flush=True)
 item.update(exit=result.returncode,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());records.append(item)
 (out/'qualification-command-records.json').write_text(json.dumps(records,indent=2)+'\n')
 assert result.returncode==0, name
 print('PASS',name,flush=True)
roots=['testdata/compute','examples/datadog','testdata/streaming','rt/instance.go']
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','--',*roots],text=True).splitlines()
def fingerprints(): return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
expected=json.loads((out/'proof-before.json').read_text());assert fingerprints()==expected
for gate in ['check','race','rust','cross','smoke','fuzz','integration']:
 assert fingerprints()==expected
 run('gate-check-go1268' if gate=='check' else 'gate-'+gate,['make',gate,'GOLANGCI_LINT='+lint],{'PATH':str(root/'.cache/toolchains/go1.26.8/go/bin')+':'+env['PATH']} if gate=='check' else None)
for repeat in [1,2]:
 for fixture in ['testdata/compute','examples/datadog','testdata/streaming']:
  run('repeat'+str(repeat)+'-'+fixture.split('/')[-1],['/usr/bin/go','run','./cmd/cocoon','build','--manifest',fixture+'/cocoon.toml'])
 run('repeat'+str(repeat)+'-runtime',['/usr/bin/go','generate','./rt'])
 assert fingerprints()==expected
 print('PASS repeat',repeat,len(paths),'proof/runtime/harness files unchanged',flush=True)
assert fingerprints()==expected
(out/'proof-after.json').write_text(json.dumps(fingerprints(),indent=2)+'\n')
print('PASS all gates and two proof/runtime reproductions; no timing binaries replaced',flush=True)
