from pathlib import Path
import os,subprocess,json,datetime
root=Path.cwd();out=root/'.cache/boundary-ceiling-phase0';go=root/'.cache/toolchains/go1.26.8/go/bin/go'
env=dict(os.environ,GOTOOLCHAIN='local',CGO_ENABLED='0',GOAMD64='v1',GOCACHE=str(root/'.cache/go'),GOFLAGS='-buildvcs=false',GOWORK='off');env.pop('GOROOT',None)
base=json.loads((out/'bare-overlay.json').read_text())['Replace']
for virtual,target in [('rt/phase0_unit_transport.go','host/rt_unit_transport.go.txt'),('examples/datadog/go/dd/phase0_transport.go','host/dd_transport.go.txt'),('examples/datadog/go/dd/phase0_scaffold_test.go','host/phase0_scaffold_test.go.txt'),('examples/datadog/go/dd/internal/wasm/phase0_add.go','guest/generated/phase0_add.go.txt')]:
 assert (out/target).is_file();base[str(root/virtual)]=str(out/target)
(out/'augmented-overlay.json').write_text(json.dumps({'Replace':base},indent=2)+'\n')
records=[]
for name,args,extra in [('build-final-augmented-amd64',[go,'test','-overlay='+str(out/'augmented-overlay.json'),'-pgo=off','-c','-o',out/'augmented-amd64.test','./examples/datadog/go/dd'],{}),('build-final-augmented-386',[go,'test','-overlay='+str(out/'augmented-overlay.json'),'-pgo=off','-c','-o',out/'augmented-386.test','./examples/datadog/go/dd'],{'GOARCH':'386'}),('build-final-stream-augmented',[go,'test','-overlay='+str(out/'augmented-overlay.json'),'-pgo=off','-c','-o',out/'stream-augmented.test','./testdata/streaming/go/streaming'],{})]:
 record={'name':name,'argv':list(map(str,args)),'extra_env':extra,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (out/(name+'.log')).open('x') as log: result=subprocess.run(args,env=dict(env,**extra),stdout=log,stderr=subprocess.STDOUT)
 record.update(exit=result.returncode,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());records.append(record);(out/'final-augmented-build-records.json').write_text(json.dumps(records,indent=2)+'\n');assert result.returncode==0,name;print('PASS',name,flush=True)
