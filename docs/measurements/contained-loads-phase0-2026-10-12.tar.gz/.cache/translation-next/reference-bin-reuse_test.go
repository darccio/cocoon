package dd

import (
	"math"
	"runtime"
	"testing"
)

const binReuseCorpusSize = 8192

var binReuseCorpora = []string{"Repeated", "UniqueCycle", "NearbyUniqueCycle", "MostlyUniqueCycle", "Phases", "BroadHoldout", "NegativeBins"}

// Freeze these inputs before selecting a cache. All finite corpora repeat after
// 8,192 points in timed loops; the separate Increasing control never repeats.
func binReuseValues(corpus string) []float64 {
	values := make([]float64, binReuseCorpusSize)
	negative := negativeBinSketchValues()
	for index := range values {
		switch corpus {
		case "Repeated":
			values[index] = 42
		case "UniqueCycle":
			values[index] = float64(index + 1)
		case "NearbyUniqueCycle":
			values[index] = math.Float64frombits(math.Float64bits(42) + uint64(index)) // #nosec G115 -- The index is bounded by the corpus size.
		case "MostlyUniqueCycle":
			values[index] = float64(1_000_000 + index)
			if index%16 == 0 {
				values[index] = 42
			}
		case "Phases":
			values[index] = float64(1_000_000 + index)
			if index/1024%2 == 0 {
				values[index] = float64(40 + index%16)
			}
		case "BroadHoldout":
			// An odd multiplier permutes the 52-bit mantissa; unique indices
			// cannot repeat a value even when their exponents coincide.
			mantissa := uint64(index+1) * 0x9e3779b97f4a7c15 & ((1 << 52) - 1) // #nosec G115 -- The index is positive and bounded.
			exponent := uint64(723 + index*37%601)                             // #nosec G115 -- Exponents are in [723, 1323].
			values[index] = math.Float64frombits(exponent<<52 | mantissa)
		case "NegativeBins":
			values[index] = negative[index%len(negative)]
		default:
			panic("unknown bin-reuse corpus")
		}
	}
	return values
}

func BenchmarkSketchBinReuse(b *testing.B) {
	for _, corpus := range append([]string{"Increasing"}, binReuseCorpora...) {
		b.Run(corpus, func(b *testing.B) {
			batchingProcessors(b, 1)
			sketch, _ := benchmarkSketch(b)
			values := binReuseValues("UniqueCycle")
			if corpus != "Increasing" {
				values = binReuseValues(corpus)
			}
			// Warm the store with one corpus, including collapse for the
			// broad holdout. UniqueCycle stresses the cache capacity.
			for _, value := range values {
				if err := sketch.Add(value); err != nil {
					b.Fatal(err)
				}
			}
			index := 0
			before := 0
			b.ReportAllocs()
			b.ResetTimer()
			for b.Loop() {
				value := values[index&(binReuseCorpusSize-1)]
				if corpus == "Increasing" {
					value = float64(binReuseCorpusSize + index + 1)
				}
				if err := sketch.Add(value); err != nil {
					b.Fatal(err)
				}
				index++
			}
			b.StopTimer()
			batchingMetrics(b, 1, 1, before, 0)
			if count, err := sketch.Count(); err != nil || count != float64(b.N+len(values)) {
				b.Fatalf("count=%g, want=%d: %v", count, b.N+len(values), err)
			}
		})
	}
}


func benchmarkSketch(b *testing.B) (*Sketch, int64) {
 b.Helper();library:=open(b);sketch,err:=library.NewSketch();if err!=nil {b.Fatal(err)}
 b.Cleanup(func(){if err:=sketch.Close();err!=nil {b.Error(err)}});return sketch,0
}
func batchingProcessors(b *testing.B, processors int) {
 b.Helper();previous:=runtime.GOMAXPROCS(processors);b.Cleanup(func(){runtime.GOMAXPROCS(previous)})
 if runtime.GOMAXPROCS(0)!=processors {b.Fatal("actual processor mismatch")}
}
func batchingMetrics(b *testing.B, points, processors, before, after int) {
 b.Helper();if runtime.GOMAXPROCS(0)!=processors {b.Fatal("actual processor mismatch")}
 b.ReportMetric(float64(processors),"actual-procs");b.ReportMetric(float64(points),"points/op")
 b.ReportMetric(float64(points)*float64(b.N)/b.Elapsed().Seconds(),"points/s")
}

