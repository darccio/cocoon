"""Preserve exact independent-reference command boundaries, including failures."""
from pathlib import Path
import datetime
import json
import os
import subprocess

DIRECTORY = Path(__file__).resolve().parent
JOURNAL = DIRECTORY / "reference-command-records.jsonl"
KEYS = ("RUSTUP_TOOLCHAIN", "CARGO_TARGET_DIR", "RUSTC_BOOTSTRAP", "CARGO_PROFILE_RELEASE_OPT_LEVEL",
        "CARGO_TARGET_WASM32_UNKNOWN_UNKNOWN_RUSTFLAGS", "GOTOOLCHAIN", "CGO_ENABLED", "GOAMD64",
        "GOCACHE", "GOFLAGS", "GOGC", "GOMEMLIMIT", "GODEBUG", "GOEXPERIMENT", "GOMAXPROCS")


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def run(command, **kwargs):
    check = kwargs.pop("check", False)
    env = kwargs.get("env", os.environ)
    record = {"started_utc": utc(), "cwd": str(Path(kwargs.get("cwd", Path.cwd())).resolve()),
              "argv": [str(x) for x in command], "environment": {key: env.get(key, "default") for key in KEYS}}
    with JOURNAL.open("a") as log:
        log.write(json.dumps({"event": "start", **record}) + "\n")
    try:
        result = subprocess.run(command, **kwargs)
    except BaseException as error:
        with JOURNAL.open("a") as log:
            log.write(json.dumps({"event": "execution-error", **record, "completed_utc": utc(), "error": repr(error)}) + "\n")
        raise
    with JOURNAL.open("a") as log:
        log.write(json.dumps({"event": "end", **record, "completed_utc": utc(), "exit": result.returncode}) + "\n")
    if check and result.returncode:
        raise subprocess.CalledProcessError(result.returncode, command)
    return result
