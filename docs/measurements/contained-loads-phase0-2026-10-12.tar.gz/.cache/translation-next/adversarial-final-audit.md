# Contained-load phase 0: final adversarial audit

Read-only audit, 2026-10-12. Disposition: positive evidence for a conservative
production specification and independent proof round, not a diagnostic no-go.
No production transform, scalar latency gain or M1 acceptance is qualified.
No source edit, build, test, lint, profile or benchmark was performed by this
reviewer; only this ignored note was written after timing completed.

## Completeness and provenance

All 189 frozen file/binary fingerprints match current bytes. Independently
verified every one of 770 raw process records against the planned alternating
500 ms/reversed 1 s order, command duration/count/CPU arguments, one exact leaf,
PASS/EXIT 0, iteration count and all metrics. Per-process times are sequential.
All 110 role/round cells contain exactly sample IDs 1 through 7. Summary sample
arrays, medians/deltas and normalized alias rows match the raw output; aliases
identify the actual roles and parts. No raw discrepancy or omitted sample found.

Processor metrics verify 280 P1 corpus rows and 56 P16 stream rows. The 434
original/raw rows lack an in-window processor metric and retain their disclosed
framework/environment P16 policy. Only 168 corpus/batch production-role rows
report guest-growth-B; all are zero. No blanket zero-growth claim follows for
the 602 rows without that observation. Increasing remains calibrated evolving
state, not equal final state. Timing runs 08:28:06.372112 through
08:39:49.096960 UTC. Isolation acknowledgment/sequential logs cannot prove
absence of unrelated external work.

Root's gate logs record check with zero lint issues, race, Rust, cross, smoke,
fuzz and integration on the unchanged production tree. Two complete builds
reproduce all 61 proof/runtime/harness files, which still match current bytes.
These gates do not qualify an authored production pass: candidate/recheck were
ignored overlays with separate whole-DD and WAT/native correctness checks.
Fresh reference provenance records successful rebuilding/test/oracles and
reproduction of previous reference Wasm, Go and executable identities.

## Paired benefit and limits

Baseline -> probe screening/confirmation:

- Original SQL 2205 -> 2116 ns / 2197 -> 2116 ns: -4.04%/-3.69%, p=.001/.001.
- Varied SQL 2812 -> 2675 ns / 2800 -> 2655 ns: -4.87%/-5.18%, p=.001/.001.
- SQL holdout 5671 -> 5446 ns / 5665 -> 5471 ns: -3.97%/-3.42%, p=.001/.017.
- Original batch 38716 -> 38047 ns / 38551 -> 37904 ns:
  -1.73%/-1.68%, p=.001/.001.
- Matched repeated batch -0.73%/-0.82%, p=.001/.010.
- Broad batch -1.91%/-2.03%, p=.128/.001: the baseline screening gain is not
  detected. It is detected in screening against recheck (-2.47%, p=.026),
  which must not be substituted for the baseline comparison.
- Raw scalar -2.54%/-2.05%, p=.023/.001. Original checked scalar is undetected
  in both rounds; this raw result does not establish public scalar speedup.
- Negative-bin scalar improves -1.41%/-0.71%, p=.005/.026, but its recheck
  comparison is undetected in screening; no general scalar claim follows.

The SQL, varied SQL, SQL holdout and original/matched repeated-batch gains also
repeat against the restored-check helper. Recheck does not reproduce their
benefit. However, this is not sole-check attribution: copied helper names,
inlining, register allocation, placement and the sketch frame all change.
The recheck confirmation trace negative is +1.07% versus baseline (p=.011);
its screening +0.34% is undetected. Keep that control negative. Probe trace
has no detected gain, and all uncertainty/smaller estimates remain reportable.
Probe versus recheck has small undetected upward scalar estimates in some
roles; they are not equivalence or evidence of a hidden accepted regression.

All p-values are exploratory and unadjusted. No holdout or function-ID rule
selected production eligibility, and no source-order/padding reroll is proposed.
The prototype removes only the later unsafe endpoint check at the 319 selected
sites; restorative inventory and helper-copy evidence support the intended
scope, not a generic binding/ownership proof.

## Semantics and acceptance

The initial utility input holes were closed: globally fresh helper identifier,
local/parameter bases, exact bound identity i32/i64 wrappers. The current DD
wrappers are identity functions, not aliases. The strengthened shadow case
declares its impure wrapper before establishing a bound; restoring name-only
purity produces a third selected site and fails its runtime assertion. Actual
first-guard and import-crossing mutants also compile and fail native semantic
assertions using physical spare capacity. Covered/rising/conditional/high-bit,
store/import/growth, logical len/cap/header and fallback/native386 evidence is
present. Two intended fixture sites are independently asserted. These are
credible diagnostic adversaries but do not replace generic production guards.

Baseline production scalar 87.62 ns in confirmation exceeds both original
55.44 ns and fresh 60.808 ns limits. SQL baseline 2197 ns is below the original
2215.4 ns limit but above fresh 2136.2 ns. Probe SQL 2116 ns is below both
screening and confirmation SQL limits; it remains an ignored diagnostic, not
qualified production. Probe scalar 87.49 ns still fails both scalar limits.
M1 remains unaccepted. Stream observations are refresh controls on unchanged
modules, not candidate gains or renewed acceptance of default-stream overhead.

Recommendation: proceed to an independently reviewed conservative predicate
and authored pipeline proof. Reject or narrow it if generic safety, code size,
maintenance or repeated workload negatives outweigh the modest SQL benefit.
Do not count the prior publication-view gains or claim a total saving by
subtracting cumulative profiles/layers. Production qualification must be fresh.
