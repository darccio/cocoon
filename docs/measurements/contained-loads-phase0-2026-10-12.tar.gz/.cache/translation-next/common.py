"""Read-only helpers shared by freeze, isolated runner, and reporting."""
from pathlib import Path
import hashlib
import json
import math
import re

DIRECTORY = Path(__file__).resolve().parent
ROOT = DIRECTORY.parents[1]
ENV_KEYS = ("CGO_ENABLED", "GOAMD64", "GOMAXPROCS", "GOGC", "GOMEMLIMIT", "GODEBUG",
            "GOEXPERIMENT", "GOTOOLCHAIN", "GOFLAGS", "GOWORK", "GOTRACEBACK")


def path(value):
    value = Path(value)
    return value if value.is_absolute() else ROOT / value


def digest(filename):
    return hashlib.sha256(filename.read_bytes()).hexdigest()


def cpu_policy(include_frequencies=False):
    base = Path("/sys/devices/system/cpu")
    patterns = ["cpu*/cpufreq/scaling_governor", "cpufreq/boost"]
    if include_frequencies:
        patterns += ["cpu*/cpufreq/scaling_cur_freq", "cpu*/cpufreq/scaling_min_freq", "cpu*/cpufreq/scaling_max_freq",
                     "cpu*/cpufreq/cpuinfo_min_freq", "cpu*/cpufreq/cpuinfo_max_freq"]
    return {str(filename): filename.read_text().strip() for pattern in patterns for filename in sorted(base.glob(pattern))}


def verify(snapshot):
    for filename, expected in snapshot["sha256"].items():
        actual = digest(Path(filename))
        if actual != expected:
            raise RuntimeError(f"frozen input changed: {filename}: {expected} -> {actual}")


def validate_plan(plan):
    assert plan["measurement_go_version"] == "go1.26.8"
    assert plan["samples"] == 7
    assert plan["rounds"] == [
        {"name": "screen", "duration": "500ms", "reverse": False},
        {"name": "confirm", "duration": "1s", "reverse": True},
    ]
    assert plan["framework_procs"] > 0
    assert plan["comparisons"], "fill actual reviewed benchmark names before freezing"
    keys = set()
    for group in plan["comparisons"]:
        assert group["key"] not in keys
        keys.add(group["key"])
        assert re.fullmatch(r"[A-Za-z0-9_-]+", group["key"]), group["key"]
        assert group["kind"] in {"cross-backend", "translation-control", "call-layers", "independent-reference", "stream-control", "startup"}
        assert group["cases"]
        assert len({case["role"] for case in group["cases"]}) == len(group["cases"])
        assert group["baseline_role"] in {case["role"] for case in group["cases"]}
        for comparison in group.get("secondary_comparisons", []):
            assert len(comparison["roles"]) >= 2
            assert set(comparison["roles"]) <= {case["role"] for case in group["cases"]}
            assert len(set(comparison["roles"])) == len(comparison["roles"])
            assert re.fullmatch(r"[A-Za-z0-9_-]+", comparison["key"])
        for case in group["cases"]:
            assert re.fullmatch(r"[A-Za-z0-9_-]+", case["role"]), case
            assert case["parts"] and all(isinstance(v, str) and v and "/" not in v for v in case["parts"])
            assert case["actual_procs"] > 0
            assert isinstance(case["metric_required"], bool)
    # Startup trials are fixed-count fresh-process observations, not benchmark
    # calibration of a cold path. Both orders have seven independent processes.
    if not any(group["kind"] == "startup" for group in plan["comparisons"]):
        return
    assert plan["startup_trials_per_round"] == 7
    assert plan["startup_rounds"] == [
        {"name": "startup-screen", "duration": "1x", "reverse": False},
        {"name": "startup-confirm", "duration": "1x", "reverse": True},
    ]


def parse_row(output, case, plan):
    rows = [line for line in output.splitlines() if line.startswith("Benchmark")]
    assert len(rows) == 1, (case, rows, output)
    fields = rows[0].split()
    name = "/".join(case["parts"]) + "-" + str(plan["framework_procs"])
    assert fields[0] == name, (name, rows)
    assert len(fields) >= 8 and len(fields) % 2 == 0, rows
    iterations = int(fields[1])
    assert iterations > 0
    metrics = {}
    for offset in range(2, len(fields), 2):
        unit = fields[offset + 1]
        assert unit not in metrics
        metrics[unit] = float(fields[offset])
        assert math.isfinite(metrics[unit])
    assert set(metrics) >= {"ns/op", "B/op", "allocs/op"}
    if case["metric_required"] or "actual-procs" in metrics:
        assert metrics.get("actual-procs") == case["actual_procs"], rows
    assert "goos: linux" in output and "goarch: amd64" in output
    assert "\nPASS\n" in "\n" + output
    return {"name": name, "iterations": iterations, "metrics": metrics, "raw_row": rows[0]}


def expected_count(plan, mode):
    groups = [g for g in plan["comparisons"] if (g["kind"] == "startup") == (mode == "startup")]
    passes = len(plan["startup_rounds"]) * plan["startup_trials_per_round"] if mode == "startup" else len(plan["rounds"]) * plan["samples"]
    return passes * sum(len(g["cases"]) for g in groups)
