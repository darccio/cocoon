from pathlib import Path
import os,subprocess,json,hashlib,datetime
root=Path.cwd();out=root/'.cache/translation-next';go='/usr/lib64/go/1.26/bin/go';env=dict(os.environ,GOTOOLCHAIN='local',CGO_ENABLED='0',GOAMD64='v1',GOCACHE=str(root/'.cache/go'),GOFLAGS='-buildvcs=false');records=[]
def run(name,args):
 item={'name':name,'argv':args,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (out/(name+'.log')).open('w') as log:
  print('COMMAND',json.dumps(args),file=log,flush=True);result=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT);print('EXIT',result.returncode,file=log,flush=True)
 item.update(exit=result.returncode,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());records.append(item);(out/'variant-build-records.json').write_text(json.dumps(records,indent=2)+'\n');assert result.returncode==0
 print('PASS',name,flush=True)
for role in ('probe','recheck'):
 run(role+'-prepare',[go,'run',str(out/'range-probe.go'),'-input',str(root/'examples/datadog/go/dd/internal/wasm/module.go'),'-sha256','f92c5853385d9c4b3cfc3d164507def81beff36b9f7a8564c92f247c9a3ab948','-mode',role,'-output',str(out/(role+'-module.go')),'-inventory',str(out/(role+'-inventory.json'))])
 assert json.loads((out/(role+'-inventory.json')).read_text())==json.loads((out/'probe-inventory.json').read_text())
for role in ('baseline','probe','recheck'):
 overlay=[] if role=='baseline' else ['-overlay='+str(out/(role+'-overlay.json'))]
 run(role+'-whole-oracles',[go,'test','-pgo=off',*overlay,'./examples/datadog/go/dd/...','-count=1'])
 if role!='baseline':run(role+'-compile',[go,'test','-c','-pgo=off',*overlay,'-o',str(out/(role+'.test')),'./examples/datadog/go/dd'])
records.append({'binaries_sha256':{role:hashlib.sha256((out/(role+'.test')).read_bytes()).hexdigest() for role in ('baseline','probe','recheck')}});(out/'variant-build-records.json').write_text(json.dumps(records,indent=2)+'\n')
print('PASS prepared variants and whole package original-Wasm oracles',flush=True)
