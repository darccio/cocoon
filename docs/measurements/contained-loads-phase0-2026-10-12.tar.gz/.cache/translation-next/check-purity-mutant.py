from pathlib import Path
import subprocess,os,hashlib,shutil,json
root=Path.cwd();out=root/'.cache/translation-next';fixture=out/'fixture';directory=fixture/'name-only-purity';directory.mkdir(exist_ok=True)
source=(out/'range-probe.go').read_text();old='case "i32","i64":if !identityConversion(id) {return false}';assert old in source
mutant=out/'range-probe-name-mutant.go';mutant.write_text(source.replace(old,'case "i32","i64":if id.Obj==nil {return false}',1))
input=fixture/'hardened-module.go';env=dict(os.environ,GOTOOLCHAIN='local',CGO_ENABLED='0',GOCACHE=str(root/'.cache/go'),GOFLAGS='-buildvcs=false')
prepare=['/usr/lib64/go/1.26/bin/go','run',str(mutant),'-input',str(input),'-sha256',hashlib.sha256(input.read_bytes()).hexdigest(),'-mode','probe','-output',str(directory/'module.go'),'-inventory',str(directory/'inventory.json')]
args=['/usr/lib64/go/1.26/bin/go','test','./.cache/translation-next/fixture/name-only-purity','-run=^TestNativeSelectionBarriers$/^shadowFunction$','-v','-count=1']
with (out/'name-only-purity-mutant.log').open('w') as log:
 print('COMMAND',json.dumps(prepare),file=log,flush=True);subprocess.run(prepare,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 shutil.copyfile(out/'fixture-goldens_test.go',directory/'goldens_test.go')
 print('COMMAND',json.dumps(args),file=log,flush=True);result=subprocess.run(args,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);log.write(result.stdout);print('EXIT',result.returncode,file=log)
 assert result.returncode!=0 and '--- FAIL:' in result.stdout and 'selection barrier crossed' in result.stdout,result.stdout
(out/'name-purity-mutant-result.json').write_text(json.dumps({'prepare':prepare,'test':args,'exit':result.returncode,'semantic_failure':True},indent=2)+'\n')
print('PASS meaningful name-only purity mutant rejected',flush=True)
