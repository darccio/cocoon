# Track 5 phase 0: adversarial entry review

Read-only review on 2026-10-12. Merged `776b897` and local `06cf6f9` have the
same tree, `b09a88d3ad6e6bf81d2c4bd4c91994850af10bd4`. Production artifacts
and locks remain unchanged. No build, test, lint, profile or benchmark was run
by this reviewer; only this ignored review note was written.

Fresh matching profiles, SSA and machine code must demonstrate one surviving
cost before selecting an exact, private, hash-pinned attainable-ceiling probe.
Old hotspot percentages and the previous batch gain are hypotheses, not new
evidence. The current publication-tail pass already removes its qualified
reloads; another experiment cannot count those gains again.

## Required evidence before a design

- Record exact source/Wasm/generated-module/binary hashes, compiler flags and
  architecture for each profile and dump. Profile tools and SSA builds remain
  separate from ordinary optimized timing binaries. Map inlined and cumulative
  samples to the actual surviving instructions; do not add percentages or
  separately timed layer differences as component savings.
- Show the particular memory/stack/branch operation survives normal optimization,
  how often it executes on the selected workload, and why an exact replacement
  can change that machine code. Fewer AST nodes, header-looking source, stack
  operands or bytes do not alone prove fewer spills or lower latency.
- Freeze an untouched control and a no-op/roundtrip control with identical
  harnesses before the probe. A restorative or code-shape control is useful but
  cannot guarantee identical placement, liveness or cache behavior. Preserve
  all linkage and instruction/stack-frame changes as limitations.
- A module hash and function IDs may delimit ignored diagnostic probes, but
  production eligibility must have a plausible structural binding/effect/type
  predicate. Reject payload names, function IDs, source lines, benchmark names,
  input-value distributions and held-out results as production selectors.
  Do not reroll a predicate after consulting holdouts and still call them held out.

## Semantic rejection conditions

Reject a probe as an exact attainable candidate if it changes original-Wasm
statuses, complete relevant state or memory, imports, trap prefixes, or owned
results. Count alone is insufficient for a sketch; compare full protobuf bins
and zero counts, invalid-tail atomicity, boundaries and collapse histories.
No removed or approximate logarithm/polynomial, floating reassociation, changed
rounding/FMA, signed-zero/NaN treatment, saturating conversion or overflow rule
is authorized. A deliberately incorrect semantic mutant must compile and fail
the executable oracle, rather than satisfy it by source rejection.

Any memory-backed value promotion requires stronger proof than header reuse.
Wasm stack addresses are not Go-private merely because the guest compiler calls
them stack slots. Check overlapping source/destination or partial-width accesses,
aliases through all arguments/receivers, calls/imports, bulk memory, native
header replacement, spare capacity, reallocating growth and logical len versus
cap. Preserve every original access and its ordering unless exact elimination
is independently proved; an access that can trap is observable even if its
value appears dead. Preserve uint32 wrapping versus uint64 widening, end and
width arithmetic, and native 386 conversions. Captures/promotion cannot cross
labels, alternate entries, loops or exceptional paths without a control-flow
proof. Validate actual declarations, builtins, helpers and constructor ownership;
shadowed names, parentheses, indirect assignments and unsupported grammar must
fail closed. Existing memory-view fixtures do not automatically prove a new pass.

## Measurement and retention rejection conditions

Use Go 1.26.8, CGO disabled, PGO off, recorded default GC/memory and CPU settings.
Set/assert actual processors inside each measured leaf before ResetTimer and
after StopTimer; reject missing/mismatched required metrics. Freeze all roles
first, stop reviewer/build/test/lint/profile/fuzz tools, interleave paired samples
and reverse role/leaf order in confirmation. Archive all raw samples, command
boundaries, hashes, failures, dispersion and exploratory unadjusted p-values.

Match inputs, ordered groups, warmup, handles/homes, logical growth and bounded
owned-output retention. Increasing prefixes evolve with calibrated iteration
counts and need that limitation; guest-B is not total heap/executable/RSS. Keep
full checked call-state reset, memory checks, ownership, canonical reply,
immediate poison and terminal drain work in the end-to-end comparison. Raw and
pure-helper diagnostics cannot replace it. Scalar versus batch comparisons
must use matched groups, with original four workloads kept separately.

Reject claims supported only by pure-helper gains, one screening result,
historical separately linked binaries, or subtraction of profile/layer shares.
Before qualification, state the primary workload, minimum useful benefit and
guard rejection policy. Repeat scalar, SQL, batch, trace, varied and negative
bins plus existing independent holdouts/streaming. Smaller repeated standalone
scalar regressions are not waived by the preceding publication pass's 3%
material-loss rule; uncertain and undetected negatives must still be reported.
Previously exposed default-stream overhead remains unresolved, not newly
accepted. Native architecture execution and cross compilation are distinct.

A positive phase 0 qualifies only further proof/design work, not a reusable
production pass. Implementation must come from authored pipeline causes with
executable WAT/native adversaries and regenerated proof packages/locks, then
all gates, exact staged validation and repeat reproductions. Any new public
contract needs operator approval; no push is authorized. M1 remains unaccepted
until production scalar/SQL meet both original absolute and fresh within-10%
reference limits with their safety and workload guards.

Review status: ready for the concrete matching-profile hypothesis and ignored
probe audit. No current implementation was proposed or approved. Tools stopped.
