# Guest review before contained-load diagnostic timing

The frozen Go1.26 assembly confirms an actual unremoved opportunity. In
`fn176.asm` around lines 779–796, the same normalized i32 base has three
load32 guards at inclusive ends +7, +11 and +3. The third check is contained
in the already successful second check. The subsequent unrelated load64+7
check must remain. SSA/assembly establishes survival, not attainable speed.

Root's proposed diagnostic is sound within its stated scope: load32 only,
same exact memory selector and explicit unchanged builtin i32 base, one
straight-line lexical block, proved nonoverflowing widened constant offsets,
keeping the first and every new-largest guard and all reads/evaluation order.
Copy the pinned helper exactly apart from the redundant unsafe-branch check;
retain endian reversal and the unaligned fallback. Preserve first-trap order;
never move a largest check ahead of earlier loads. Root's full-module hash pin
qualifies only this diagnostic, not generic production helper/effect proof.

Suggested small proof matrix before timing:

| Fixture shape | Required checks / outcome |
|---|---|
| high8, low0 | First guard retained; second contained check removed; two reads retain original order and weighted result |
| offsets4,8,0 | First two guards retained; last check removed, matching the demonstrated hot path |
| high8, low4, low0 | One first check, two contained loads; all three independently distinguishable values |
| offsets0,4,8 | All three checks retained; no preflight of the last/largest address |
| new base, changed base, wrapping i32 add | No containment across these forms; preserve each original check |
| call/import/store/header/control/label | Reset evidence; never assume a check on an untaken path or earlier iteration |

Use actual translated WAT plus the diagnostic to assert that the intended
contained calls were rewritten and executed. Return a noncommutative weighted
combination of read values (plus distinct seeded bytes), so skipped/reordered
or wrong-address reads cannot pass on zeros. Keep explicit golden values and
original-Wasm results separate from original/transformed equality. A fixture
optimized into load64 or otherwise lacking the intended sites is a setup
failure, not proof. Assert helper/call counts and actual emitted load32 shape.

For WAT page-sized memory, place bases at every distance 0–16 from the 64KiB
end to cover all exact-end and short-range checks. Include unaligned bases,
signed-negative raw i32 bits and values near MaxUint32. Widened memarg offsets
must trap past the page end rather than wrap; explicit i32.add may wrap and
must remain ineligible. Seed a counter before the first load sequence, then
perform observable stores only after successful reads. A trap must retain the
same counter/memory prefix and omit subsequent effects. In offsets0,4,8, the
first read may succeed while the next traps; moving the largest check earlier
would change the original read/trap order and is excluded structurally even
where reads themselves have no visible effect.

Native header proofs are necessary in addition to WAT:

- Backing cap64 with logical len0..16; sentinel bytes beyond logical len. All
  invalid first loads must still trap, despite readable spare backing bytes.
- Header replacement/shrink import between a successful high8 load and later
  low4 load: shrink len to4 and preserve spare backing, requiring the later
  check to trap. This is an observable counterexample to crossing a call.
  Wazero cannot shrink a memory, so native goldens carry this distinct proof.
- Header replacement retaining length but changing bytes; growth with spare
  capacity and allocation; every later read must see current backing data.
- Alias or field/base writes and conditional/goto entry: assert retained
  guards structurally, and use native length changes or an untaken prior check
  where possible to make an incorrectly retained proof fail semantically.

At least two post-rewrite mutants should fail independent runtime assertions:
remove the first guard on a spare-cap short logical slice; incorrectly remove
the second guard across header shrink/conditional entry. Restrict unsafe
mutants to readable spare-cap cases to get a clear semantic assertion, not a
hardware crash or compile failure. Require the child test's explicit FAIL and
oracle mismatch, as prior smoke proofs do. Positive full/native386 runs must
precede mutation checks; architecture fallback behavior stays unchanged.

No math/predicate changes, value forwarding, store removal, broad header
reuse or public contracts are justified by this pattern. Preserve the batch
whole-input validation and atomic errors. After oracles, inspect matching
candidate SSA/assembly for the actual removed branch, frame/register and
placement effects, then measure the ceiling against all scalar/SQL/batch/trace
and negative-bin/broad/stream holdouts. No percentage is predicted here.

Review performed read-only; no compilation, tests, profiles or benchmarks.
