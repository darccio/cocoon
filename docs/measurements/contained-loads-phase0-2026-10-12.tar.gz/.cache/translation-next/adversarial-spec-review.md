# Contained-load production draft: adversarial review

Read-only review of docs/translation-contained-loads.md after phase-0 evidence
audit, 2026-10-12. The repeated SQL and restorative-control results support a
conservative specification/proof round. This is not approval of an implementation,
a new public contract, or production performance. No builds/tests/lint/timings
were performed and no source/docs were edited by this reviewer.

The proposed proof is appropriately narrow: successful prior logical-length
checks, same bound local base/current memory, finite widened offsets, no
propagation through effects or control, retained first/new-largest checks and
every actual read, checked fallback, exact helper/directive bindings and private
helper namespace. Existing ownership/serialization assumptions and the 386
address-width condition remain explicit. Unsupported syntax must stay unchanged.
Nothing permits approximate math, value forwarding, payload/function-ID
selection, public ABI changes or relaxed per-operation checked work.

Clarify before signing:

1. Base and destination types are different obligations. The base needs an
   explicitly declared builtin int32 local/parameter. Most diagnostic destinations
   are `tXXX := int32(load32(...))`; a requirement that the destination be
   explicitly declared would exclude the demonstrated 319 sites. Permit a short
   destination declaration only when its exact builtin int32/uint32 type follows
   from the sole validated load RHS, or state the narrower intended eligibility
   and measure its different ceiling. Existing destinations still need validated
   local scalar types. Resolve the declarations-barrier exception explicitly.
2. "Reuse ... where applicable" leaves the binding/helper/architecture/Module/
   construction guards discretionary. State which validated guard set is
   mandatory and which independently proved exception exists, if any. The
   diagnostic source hash is not a production safety argument.
3. A private helper-name collision should skip the pass and preserve the module,
   not add a new build rejection for otherwise supported inputs. Preserve the
   existing mandatory bulk-helper drift failures separately.

Plan the executable proof around mandatory constructor/ownership validation.
The current diagnostic XshadowFunc directly writes m.memory; reusing the full
publication-view ownership guard could reject its entire module and make all
covered sites vacuous. For authored production proofs, let the locally shadowed
callback invoke a declared host import, whose external host shrinks/replaces the
header. That exercises impurity while retaining canonical translated ownership.
Keep direct native header operations in external host assertions/post-rewrite
test plumbing. Assert actual qualifying sites before accepting semantic tests.

Production qualification must remain independent of phase 0. The recheck trace
negative and broad-batch baseline screening nondetection remain visible; smaller
repeated standalone scalar regressions are not waived by a 3% material threshold.
The changed sketch frame/placement prevents a clean per-check attribution.
Proceed only from reviewed authored hardener/tests, regenerate all three proofs
and locks, and rerun all gates, staged validation and paired qualification.

Disposition: conceptually sound after the three specification clarifications
and the proof-plumbing interaction above. Await final draft before approval.
