"""Fingerprint selected spike source plus separate upstream identity."""
from pathlib import Path
import hashlib
import subprocess

SPIKE = Path("/home/dario/Code/cocoon-spike")


def snapshot():
    selected = {}
    for area in ("shim", "rust/cocoon-guest", "rust/patches", "go/dd", "go/rt", "go/internal/testpayload"):
        for filename in sorted((SPIKE / area).rglob("*")):
            if filename.is_file() and filename.suffix in {".go", ".rs", ".toml", ".lock"}:
                selected[str(filename.relative_to(SPIKE))] = hashlib.sha256(filename.read_bytes()).hexdigest()
    for name in ("tools_exports.py", "tools_harden.py", "go/go.mod", "go/go.sum"):
        selected[name] = hashlib.sha256((SPIKE / name).read_bytes()).hexdigest()
    upstream = Path("/home/dario/Code/libdatadog")
    identity = {}
    if (upstream / ".git").exists():
        identity = {"head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=upstream, text=True).strip(),
                    "status": subprocess.check_output(["git", "status", "--short"], cwd=upstream, text=True)}
    return {"spike": str(SPIKE), "source_sha256": selected, "external_upstream": {"path": str(upstream), **identity},
            "limits": "Selected authored source is fingerprinted. External upstream HEAD/status is additional identity, not a fingerprint of every transitive dependency. Fresh artifact reproduction is checked separately."}
