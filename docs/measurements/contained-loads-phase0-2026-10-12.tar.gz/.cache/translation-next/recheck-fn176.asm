TEXT dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn176(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/internal/wasm/module.go
  module.go:35694	0x630c00		4c8d6424e8		LEAQ -0x18(SP), R12								
  module.go:35694	0x630c05		4d3b6610		CMPQ R12, 0x10(R14)								
  module.go:35694	0x630c09		0f868b160000		JBE 0x63229a									
  module.go:35694	0x630c0f		55			PUSHQ BP									
  module.go:35694	0x630c10		4889e5			MOVQ SP, BP									
  module.go:35694	0x630c13		4881ec90000000		SUBQ $0x90, SP									
  module.go:35713	0x630c1a		48898424a0000000	MOVQ AX, 0xa0(SP)								
  module.go:35713	0x630c22		899c24a8000000		MOVL BX, 0xa8(SP)								
  module.go:35699	0x630c29		8b5050			MOVL 0x50(AX), DX								
  module.go:35699	0x630c2c		89542434		MOVL DX, 0x34(SP)								
  module.go:35705	0x630c30		448d4ae0		LEAL -0x20(DX), R9								
  module.go:35706	0x630c34		44894850		MOVL R9, 0x50(AX)								
  unsafe.go:35		0x630c38		66490f7ec2		MOVQ X0, R10									
  module.go:35711	0x630c3d		4d89d3			MOVQ R10, R11									
  module.go:35711	0x630c40		490fbaf23f		BTRQ $0x3f, R10									
  module.go:35713	0x630c45		4d8d62ff		LEAQ -0x1(R10), R12								
  module.go:35733	0x630c49		49bd000000000000f0ff	MOVQ $0xfff0000000000000, R13							
  module.go:35733	0x630c53		4d01d5			ADDQ R10, R13									
  module.go:35710	0x630c56		90			NOPL										
  module.go:35713	0x630c57		49bfffffffffffff0f00	MOVQ $0xfffffffffffff, R15							
  module.go:35713	0x630c61		4d39e7			CMPQ R15, R12									
  module.go:35713	0x630c64		410f97c4		SETA R12									
  module.go:35714	0x630c68		450fb6e4		MOVZX R12, R12									
  module.go:35717	0x630c6c		4d85db			TESTQ R11, R11									
  module.go:35717	0x630c6f		410f9cc7		SETL R15									
  module.go:35718	0x630c73		450fb6ff		MOVZX R15, R15									
  module.go:35721	0x630c77		4521fc			ANDL R15, R12									
  module.go:35705	0x630c7a		4489ce			MOVL R9, SI									
  module.go:35728	0x630c7d		49b9000000000000f07f	MOVQ $0x7ff0000000000000, R9							
  module.go:35728	0x630c87		4d39d1			CMPQ R9, R10									
  module.go:35723	0x630c8a		410f94c1		SETE R9										
  module.go:35728	0x630c8e		410f92c2		SETB R10									
  module.go:35724	0x630c92		450fb6c9		MOVZX R9, R9									
  module.go:35726	0x630c96		4509cc			ORL R9, R12									
  module.go:35729	0x630c99		450fb6ca		MOVZX R10, R9									
  module.go:35731	0x630c9d		4509cc			ORL R9, R12									
  module.go:35733	0x630ca0		49b9000000000000e07f	MOVQ $0x7fe0000000000000, R9							
  module.go:35733	0x630caa		4d39e9			CMPQ R9, R13									
  module.go:35733	0x630cad		410f97c1		SETA R9										
  module.go:35734	0x630cb1		450fb6c9		MOVZX R9, R9									
  module.go:35736	0x630cb5		4521f9			ANDL R15, R9									
  module.go:35736	0x630cb8		4509e1			ORL R12, R9									
  module.go:35736	0x630cbb		0f1f440000		NOPL 0(AX)(AX*1)								
  module.go:35736	0x630cc0		4585c9			TESTL R9, R9									
  module.go:35736	0x630cc3		0f857c090000		JNE 0x631645									
  module.go:35772	0x630cc9		4c8b4838		MOVQ 0x38(AX), R9								
  module.go:35772	0x630ccd		4189ca			MOVL CX, R10									
  module.go:63009	0x630cd0		4d8d6237		LEAQ 0x37(R10), R12								
  module.go:63009	0x630cd4		4d39e1			CMPQ R9, R12									
  module.go:63009	0x630cd7		0f86b7150000		JBE 0x632294									
  module.go:35772	0x630cdd		4c8b4830		MOVQ 0x30(AX), R9								
  module.go:63010	0x630ce1		4f8b4c0a30		MOVQ 0x30(R10)(R9*1), R9							
  unsafe.go:41		0x630ce6		66490f6ec9		MOVQ R9, X1									
  module.go:35773	0x630ceb		660f2ec8		UCOMISD X0, X1									
  module.go:35773	0x630cef		0f87fc080000		JA 0x6315f1									
  module.go:35774	0x630cf5		4c8b4838		MOVQ 0x38(AX), R9								
  module.go:63009	0x630cf9		4d8d622f		LEAQ 0x2f(R10), R12								
  module.go:63009	0x630cfd		0f1f00			NOPL 0(AX)									
  module.go:63009	0x630d00		4d39e1			CMPQ R9, R12									
  module.go:63009	0x630d03		0f8686150000		JBE 0x63228f									
  module.go:35774	0x630d09		4c8b4830		MOVQ 0x30(AX), R9								
  module.go:63010	0x630d0d		4f8b4c0a28		MOVQ 0x28(R10)(R9*1), R9							
  module.go:35780	0x630d12		49bc0000000000001000	MOVQ $0x10000000000000, R12							
  module.go:35780	0x630d1c		0f1f4000		NOPL 0(AX)									
  module.go:35780	0x630d20		4d39e3			CMPQ R11, R12									
  module.go:35780	0x630d23		7c45			JL 0x630d6a									
  module.go:35781	0x630d25		49bcffffffffffffef7f	MOVQ $0x7fefffffffffffff, R12							
  module.go:35781	0x630d2f		4d39e3			CMPQ R11, R12									
  module.go:35781	0x630d32		0f87c2010000		JA 0x630efa									
  module.go:35785	0x630d38		4d89dc			MOVQ R11, R12									
  module.go:35785	0x630d3b		49c1eb20		SHRQ $0x20, R11									
  module.go:35785	0x630d3f		90			NOPL										
  module.go:35786	0x630d40		4981fb0000f03f		CMPQ R11, $0x3ff00000								
  module.go:35786	0x630d47		7407			JE 0x630d50									
  module.go:35786	0x630d49		be01fcffff		MOVL $-0x3ff, SI								
  module.go:35789	0x630d4e		eb7b			JMP 0x630dcb									
  module.go:35791	0x630d50		4585e4			TESTL R12, R12									
  module.go:35791	0x630d53		740d			JE 0x630d62									
  module.go:35791	0x630d55		41bb0000f03f		MOVL $0x3ff00000, R11								
  module.go:35791	0x630d5b		be01fcffff		MOVL $-0x3ff, SI								
  module.go:35793	0x630d60		eb69			JMP 0x630dcb									
  module.go:35793	0x630d62		0f57c0			XORPS X0, X0									
  module.go:35796	0x630d65		e990010000		JMP 0x630efa									
  module.go:35798	0x630d6a		0f10c8			MOVUPS X0, X1									
  module.go:35798	0x630d6d		f20f59c0		MULSD X0, X0									
  module.go:35798	0x630d71		f20f1015e7332d00	MOVSD_XMM $f64.bff0000000000000(SB), X2						
  module.go:35798	0x630d79		f20f5ed0		DIVSD X0, X2									
  module.go:35799	0x630d7d		0f57db			XORPS X3, X3									
  module.go:35799	0x630d80		660f2ecb		UCOMISD X3, X1									
  module.go:35799	0x630d84		750a			JNE 0x630d90									
  module.go:35799	0x630d86		7a08			JP 0x630d90									
  module.go:35795	0x630d88		0f10c2			MOVUPS X2, X0									
  module.go:35801	0x630d8b		e96a010000		JMP 0x630efa									
  module.go:35717	0x630d90		4d85db			TESTQ R11, R11									
  module.go:35803	0x630d93		7d10			JGE 0x630da5									
  module.go:35828	0x630d95		f20f5cc9		SUBSD X1, X1									
  module.go:35828	0x630d99		f20f5ecb		DIVSD X3, X1									
  module.go:35828	0x630d9d		0f10c1			MOVUPS X1, X0									
  module.go:35829	0x630da0		e955010000		JMP 0x630efa									
  module.go:35807	0x630da5		f20f1015a3332d00	MOVSD_XMM $f64.4350000000000000(SB), X2						
  module.go:35807	0x630dad		f20f59d1		MULSD X1, X2									
  unsafe.go:35		0x630db1		66490f7ed3		MOVQ X2, R11									
  module.go:35808	0x630db6		4d89dc			MOVQ R11, R12									
  module.go:35808	0x630db9		49c1ec20		SHRQ $0x20, R12									
  module.go:35808	0x630dbd		becbfbffff		MOVL $-0x435, SI								
  module.go:35792	0x630dc2		4c89df			MOVQ R11, DI									
  module.go:35792	0x630dc5		4d89e3			MOVQ R12, R11									
  module.go:35807	0x630dc8		4989fc			MOVQ DI, R12									
  module.go:35811	0x630dcb		4181c3625f0900		ADDL $0x95f62, R11								
  module.go:35812	0x630dd2		4589dd			MOVL R11, R13									
  module.go:35812	0x630dd5		41c1eb14		SHRL $0x14, R11									
  module.go:35812	0x630dd9		4101f3			ADDL SI, R11									
  module.go:35812	0x630ddc		0f57d2			XORPS X2, X2									
  module.go:35812	0x630ddf		f2410f2ad3		CVTSI2SDL R11, X2								
  module.go:35813	0x630de4		f20f100d3c332d00	MOVSD_XMM $f64.3fe62e42fee00000(SB), X1						
  module.go:35813	0x630dec		f20f59ca		MULSD X2, X1									
  module.go:35814	0x630df0		41bbffffffff		MOVL $-0x1, R11									
  module.go:35814	0x630df6		4d21dc			ANDQ R11, R12									
  module.go:35814	0x630df9		4181e5ffff0f00		ANDL $0xfffff, R13								
  module.go:35814	0x630e00		458d9d9ea0e63f		LEAL 0x3fe6a09e(R13), R11							
  module.go:35814	0x630e07		4589db			MOVL R11, R11									
  module.go:35814	0x630e0a		49c1e320		SHLQ $0x20, R11									
  module.go:35814	0x630e0e		4d09dc			ORQ R11, R12									
  module.go:35816	0x630e11		f20f101dcf322d00	MOVSD_XMM $f64.3dea39ef35793c76(SB), X3						
  module.go:35816	0x630e19		f20f59d3		MULSD X3, X2									
  unsafe.go:41		0x630e1d		66490f6edc		MOVQ R12, X3									
  module.go:35814	0x630e22		f20f102536332d00	MOVSD_XMM $f64.bff0000000000000(SB), X4						
  module.go:35814	0x630e2a		f20f58e3		ADDSD X3, X4									
  module.go:35817	0x630e2e		f20f101d3a312d00	MOVSD_XMM $f64.4000000000000000(SB), X3						
  module.go:35817	0x630e36		f20f58dc		ADDSD X4, X3									
  module.go:35817	0x630e3a		0f10ec			MOVUPS X4, X5									
  module.go:35817	0x630e3d		f20f5ee3		DIVSD X3, X4									
  module.go:35819	0x630e41		f20f101da7312d00	MOVSD_XMM $f64.3fe0000000000000(SB), X3						
  module.go:35819	0x630e49		f20f59dd		MULSD X5, X3									
  module.go:35819	0x630e4d		f20f59dd		MULSD X5, X3									
  module.go:35821	0x630e51		0f10f4			MOVUPS X4, X6									
  module.go:35821	0x630e54		f20f59e4		MULSD X4, X4									
  module.go:35822	0x630e58		0f10fc			MOVUPS X4, X7									
  module.go:35822	0x630e5b		f20f59e4		MULSD X4, X4									
  module.go:35823	0x630e5f		f2440f100590322d00	MOVSD_XMM $f64.3fc39a09d078c69f(SB), X8						
  module.go:35823	0x630e68		f2440f59c4		MULSD X4, X8									
  module.go:35823	0x630e6d		f2440f100d92322d00	MOVSD_XMM $f64.3fcc71c51d8e78af(SB), X9						
  module.go:35823	0x630e76		f2450f58c8		ADDSD X8, X9									
  module.go:35823	0x630e7b		f2440f59cc		MULSD X4, X9									
  module.go:35823	0x630e80		f2440f10058f322d00	MOVSD_XMM $f64.3fd999999997fa04(SB), X8						
  module.go:35823	0x630e89		f2450f58c1		ADDSD X9, X8									
  module.go:35823	0x630e8e		f2440f59c4		MULSD X4, X8									
  module.go:35823	0x630e93		f2440f100d54322d00	MOVSD_XMM $f64.3fc2f112df3e5244(SB), X9						
  module.go:35823	0x630e9c		f2440f59cc		MULSD X4, X9									
  module.go:35823	0x630ea1		f2440f101556322d00	MOVSD_XMM $f64.3fc7466496cb03de(SB), X10					
  module.go:35823	0x630eaa		f2450f58d1		ADDSD X9, X10									
  module.go:35823	0x630eaf		f2440f59d4		MULSD X4, X10									
  module.go:35823	0x630eb4		f2440f100d53322d00	MOVSD_XMM $f64.3fd2492494229359(SB), X9						
  module.go:35823	0x630ebd		f2450f58ca		ADDSD X10, X9									
  module.go:35823	0x630ec2		f2440f59cc		MULSD X4, X9									
  module.go:35823	0x630ec7		f20f102551322d00	MOVSD_XMM $f64.3fe5555555555593(SB), X4						
  module.go:35823	0x630ecf		f2410f58e1		ADDSD X9, X4									
  module.go:35823	0x630ed4		f20f59e7		MULSD X7, X4									
  module.go:35823	0x630ed8		f2440f58c4		ADDSD X4, X8									
  module.go:35823	0x630edd		f2440f58c3		ADDSD X3, X8									
  module.go:35823	0x630ee2		f2410f59f0		MULSD X8, X6									
  module.go:35823	0x630ee7		f20f58d6		ADDSD X6, X2									
  module.go:35823	0x630eeb		f20f5cd3		SUBSD X3, X2									
  module.go:35823	0x630eef		f20f58d5		ADDSD X5, X2									
  module.go:35823	0x630ef3		f20f58d1		ADDSD X1, X2									
  module.go:35795	0x630ef7		0f10c2			MOVUPS X2, X0									
  module.go:35832	0x630efa		4c8b5838		MOVQ 0x38(AX), R11								
  module.go:63009	0x630efe		4d8d623f		LEAQ 0x3f(R10), R12								
  module.go:63009	0x630f02		4d39e3			CMPQ R11, R12									
  module.go:63009	0x630f05		0f867f130000		JBE 0x63228a									
  module.go:35713	0x630f0b		898c24ac000000		MOVL CX, 0xac(SP)								
  module.go:35772	0x630f12		4c89942488000000	MOVQ R10, 0x88(SP)								
  module.go:35832	0x630f1a		4c8b5830		MOVQ 0x30(AX), R11								
  unsafe.go:41		0x630f1e		66490f6ec9		MOVQ R9, X1									
  module.go:35833	0x630f23		f20f59c1		MULSD X1, X0									
  module.go:63010	0x630f27		4f8b4c1a38		MOVQ 0x38(R10)(R11*1), R9							
  module.go:35832	0x630f2c		66490f6ec9		MOVQ R9, X1									
  module.go:35833	0x630f31		f20f58c1		ADDSD X1, X0									
  module.go:35833	0x630f35		440fb60dd7ea6c00	MOVZX runtime.x86HasSSE41(SB), R9						
  module.go:35833	0x630f3d		0f1f00			NOPL 0(AX)									
  module.go:35833	0x630f40		4585c9			TESTL R9, R9									
  module.go:35833	0x630f43		7408			JE 0x630f4d									
  module.go:35833	0x630f45		660f3a0bc001		ROUNDSD $0x1, X0, X0								
  module.go:35833	0x630f4b		eb27			JMP 0x630f74									
  module.go:35833	0x630f4d		e88ea2eaff		CALL math.Floor(SB)								
  module.go:35834	0x630f52		488b8424a0000000	MOVQ 0xa0(SP), AX								
  module.go:62984	0x630f5a		8b8c24ac000000		MOVL 0xac(SP), CX								
  module.go:35702	0x630f61		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x630f65		8b9c24a8000000		MOVL 0xa8(SP), BX								
  module.go:62983	0x630f6c		4c8b942488000000	MOVQ 0x88(SP), R10								
  module.go:63074	0x630f74		f20f100d4c322d00	MOVSD_XMM $f64.c1e0000000000000(SB), X1						
  module.go:63074	0x630f7c		660f2ec8		UCOMISD X0, X1									
  module.go:63074	0x630f80		7208			JB 0x630f8a									
  module.go:63074	0x630f82		41b900000080		MOVL $-0x80000000, R9								
  module.go:35833	0x630f88		eb2a			JMP 0x630fb4									
  module.go:63076	0x630f8a		f20f100d26322d00	MOVSD_XMM $f64.41dfffffffc00000(SB), X1						
  module.go:63076	0x630f92		660f2ec1		UCOMISD X1, X0									
  module.go:63076	0x630f96		720a			JB 0x630fa2									
  module.go:63076	0x630f98		41b9ffffff7f		MOVL $0x7fffffff, R9								
  module.go:63076	0x630f9e		6690			NOPW										
  module.go:35833	0x630fa0		eb12			JMP 0x630fb4									
  module.go:63078	0x630fa2		660f2ec0		UCOMISD X0, X0									
  module.go:63078	0x630fa6		7502			JNE 0x630faa									
  module.go:63078	0x630fa8		7b05			JNP 0x630faf									
  module.go:63078	0x630faa		4531c9			XORL R9, R9									
  module.go:35833	0x630fad		eb05			JMP 0x630fb4									
  module.go:63081	0x630faf		f2440f2cc8		CVTTSD2SIL X0, R9								
  module.go:35834	0x630fb4		4c8b5838		MOVQ 0x38(AX), R11								
  module.go:62983	0x630fb8		4d8d620f		LEAQ 0xf(R10), R12								
  module.go:62983	0x630fbc		0f1f4000		NOPL 0(AX)									
  module.go:62983	0x630fc0		4d39e3			CMPQ R11, R12									
  module.go:62983	0x630fc3		0f86bc120000		JBE 0x632285									
  module.go:62983	0x630fc9		4c89a42480000000	MOVQ R12, 0x80(SP)								
  module.go:35834	0x630fd1		4c8b6830		MOVQ 0x30(AX), R13								
  module.go:62984	0x630fd5		478b7c2a0c		MOVL 0xc(R10)(R13*1), R15							
  module.go:62984	0x630fda		660f1f440000		NOPW 0(AX)(AX*1)								
  module.go:35836	0x630fe0		4585ff			TESTL R15, R15									
  module.go:35836	0x630fe3		0f84dc040000		JE 0x6314c5									
  module.go:62983	0x630fe9		498d7213		LEAQ 0x13(R10), SI								
  module.go:35863	0x630fed		90			NOPL										
  module.go:62983	0x630fee		4939f3			CMPQ R11, SI									
  module.go:62983	0x630ff1		0f8687120000		JBE 0x63227e									
  module.go:62983	0x630ff7		4889742478		MOVQ SI, 0x78(SP)								
  module.go:62984	0x630ffc		438b7c2a10		MOVL 0x10(R10)(R13*1), DI							
  module.go:35865	0x631001		4139f9			CMPL R9, DI									
  module.go:35865	0x631004		0f8c3b010000		JL 0x631145									
  module.go:35833	0x63100a		44894c2424		MOVL R9, 0x24(SP)								
  module.go:35867	0x63100f		468d043f		LEAL 0(DI)(R15*1), R8								
  module.go:35866	0x631013		4129f9			SUBL DI, R9									
  module.go:35867	0x631016		8b542424		MOVL 0x24(SP), DX								
  module.go:35867	0x63101a		660f1f440000		NOPW 0(AX)(AX*1)								
  module.go:35867	0x631020		4439c2			CMPL DX, R8									
  module.go:35867	0x631023		0f8c0d010000		JL 0x631136									
  module.go:62983	0x631029		4d8d4217		LEAQ 0x17(R10), R8								
  module.go:35871	0x63102d		90			NOPL										
  module.go:62983	0x63102e		4d39c3			CMPQ R11, R8									
  module.go:62983	0x631031		0f8642120000		JBE 0x632279									
  module.go:35870	0x631037		458d4101		LEAL 0x1(R9), R8								
  module.go:62984	0x63103b		438b5c1514		MOVL 0x14(R13)(R10*1), BX							
  module.go:35874	0x631040		4439c3			CMPL BX, R8									
  module.go:35874	0x631043		0f8d400c0000		JGE 0x631c89									
  module.go:35877	0x631049		4129d9			SUBL BX, R9									
  module.go:35877	0x63104c		458d4101		LEAL 0x1(R9), R8								
  module.go:35878	0x631050		4585c0			TESTL R8, R8									
  module.go:35878	0x631053		0f8e92000000		JLE 0x6310eb									
  module.go:62983	0x631059		498d720b		LEAQ 0xb(R10), SI								
  module.go:35879	0x63105d		90			NOPL										
  module.go:35879	0x63105e		6690			NOPW										
  module.go:62983	0x631060		4939f3			CMPQ R11, SI									
  module.go:62983	0x631063		0f860b120000		JBE 0x632274									
  module.go:62983	0x631069		4889742470		MOVQ SI, 0x70(SP)								
  module.go:35877	0x63106e		44894c244c		MOVL R9, 0x4c(SP)								
  module.go:63184	0x631073		4d8d4a07		LEAQ 0x7(R10), R9								
  module.go:35881	0x631077		90			NOPL										
  module.go:62984	0x631078		438b741508		MOVL 0x8(R13)(R10*1), SI							
  module.go:62984	0x63107d		0f1f00			NOPL 0(AX)									
  module.go:63184	0x631080		4d39cb			CMPQ R11, R9									
  module.go:63184	0x631083		0f86e6110000		JBE 0x63226f									
  module.go:63184	0x631089		4c894c2468		MOVQ R9, 0x68(SP)								
  module.go:63184	0x63108e		4d8d4a03		LEAQ 0x3(R10), R9								
  module.go:35883	0x631092		90			NOPL										
  module.go:63185	0x631093		478b541504		MOVL 0x4(R13)(R10*1), R10							
  module.go:63185	0x631098		0f1f840000000000	NOPL 0(AX)(AX*1)								
  module.go:63184	0x6310a0		4d39cb			CMPQ R11, R9									
  module.go:63184	0x6310a3		0f86c1110000		JBE 0x63226a									
  module.go:63184	0x6310a9		4c894c2460		MOVQ R9, 0x60(SP)								
  module.go:35885	0x6310ae		448d1c1f		LEAL 0(DI)(BX*1), R11								
  module.go:63185	0x6310b2		89cb			MOVL CX, BX									
  module.go:63185	0x6310b4		48895c2458		MOVQ BX, 0x58(SP)								
  module.go:63185	0x6310b9		458b6c1d00		MOVL 0(R13)(BX*1), R13								
  module.go:63185	0x6310be		6690			NOPW										
  module.go:35885	0x6310c0		4439da			CMPL DX, R11									
  module.go:35885	0x6310c3		750b			JNE 0x6310d0									
  module.go:36088	0x6310c5		4589f8			MOVL R15, R8									
  module.go:36088	0x6310c8		0f57c0			XORPS X0, X0									
  module.go:35888	0x6310cb		e9230f0000		JMP 0x631ff3									
  module.go:62984	0x6310d0		897c2448		MOVL DI, 0x48(SP)								
  module.go:35891	0x6310d4		4589c3			MOVL R8, R11									
  module.go:35891	0x6310d7		4181e0feffff7f		ANDL $0x7ffffffe, R8								
  module.go:35952	0x6310de		44897c2428		MOVL R15, 0x28(SP)								
  module.go:35952	0x6310e3		0f57c0			XORPS X0, X0									
  module.go:35894	0x6310e6		e9680d0000		JMP 0x631e53									
  module.go:62983	0x6310eb		4d8d4207		LEAQ 0x7(R10), R8								
  module.go:35957	0x6310ef		90			NOPL										
  module.go:62983	0x6310f0		4d39c3			CMPQ R11, R8									
  module.go:62983	0x6310f3		0f86450d0000		JBE 0x631e3e									
  module.go:63184	0x6310f9		4d8d4203		LEAQ 0x3(R10), R8								
  module.go:35959	0x6310fd		90			NOPL										
  module.go:62984	0x6310fe		438b5c1504		MOVL 0x4(R13)(R10*1), BX							
  module.go:63184	0x631103		4d39c3			CMPQ R11, R8									
  module.go:63184	0x631106		0f862d0d0000		JBE 0x631e39									
  module.go:63185	0x63110c		4189c8			MOVL CX, R8									
  module.go:62983	0x63110f		4d8d620b		LEAQ 0xb(R10), R12								
  module.go:35961	0x631113		90			NOPL										
  module.go:63185	0x631114		478b440500		MOVL 0(R13)(R8*1), R8								
  module.go:63185	0x631119		0f1f8000000000		NOPL 0(AX)									
  module.go:62983	0x631120		4d39e3			CMPQ R11, R12									
  module.go:62983	0x631123		0f860b0d0000		JBE 0x631e34									
  module.go:62984	0x631129		478b5c1508		MOVL 0x8(R13)(R10*1), R11							
  module.go:62984	0x63112e		0f57c0			XORPS X0, X0									
  module.go:35964	0x631131		e9d40a0000		JMP 0x631c0a									
  module.go:35702	0x631136		8b542434		MOVL 0x34(SP), DX								
  module.go:36195	0x63113a		4589f8			MOVL R15, R8									
  module.go:36195	0x63113d		0f1f00			NOPL 0(AX)									
  module.go:35868	0x631140		e9ca070000		JMP 0x63190f									
  module.go:62983	0x631145		4d8d4217		LEAQ 0x17(R10), R8								
  module.go:35968	0x631149		90			NOPL										
  module.go:62983	0x63114a		4d39c3			CMPQ R11, R8									
  module.go:62983	0x63114d		0f86b20a0000		JBE 0x631c05									
  module.go:35971	0x631153		4429cf			SUBL R9, DI									
  module.go:62984	0x631156		478b4c1514		MOVL 0x14(R13)(R10*1), R9							
  module.go:35969	0x63115b		4529f9			SUBL R15, R9									
  module.go:35973	0x63115e		4439cf			CMPL DI, R9									
  module.go:35974	0x631161		410f47f9		CMOVA R9, DI									
  module.go:35977	0x631165		458d0c3f		LEAL 0(R15)(DI*1), R9								
  module.go:35978	0x631169		4439cf			CMPL DI, R9									
  module.go:35973	0x63116c		0f87670a0000		JA 0x631bd9									
  module.go:62983	0x631172		4d8d4203		LEAQ 0x3(R10), R8								
  module.go:35979	0x631176		90			NOPL										
  module.go:35979	0x631177		660f1f840000000000	NOPW 0(AX)(AX*1)								
  module.go:62983	0x631180		4d39c3			CMPQ R11, R8									
  module.go:62983	0x631183		0f864b0a0000		JBE 0x631bd4									
  module.go:62983	0x631189		4c89442470		MOVQ R8, 0x70(SP)								
  module.go:35974	0x63118e		897c242c		MOVL DI, 0x2c(SP)								
  module.go:62984	0x631192		4189cb			MOVL CX, R11									
  module.go:62984	0x631195		4c895c2458		MOVQ R11, 0x58(SP)								
  module.go:62984	0x63119a		478b6c1d00		MOVL 0(R13)(R11*1), R13								
  module.go:62984	0x63119f		90			NOPL										
  module.go:35982	0x6311a0		4539cd			CMPL R13, R9									
  module.go:35982	0x6311a3		0f830b030000		JAE 0x6314b4									
  module.go:62984	0x6311a9		44896c2448		MOVL R13, 0x48(SP)								
  module.go:35992	0x6311ae		4589e9			MOVL R13, R9									
  module.go:35992	0x6311b1		4529fd			SUBL R15, R13									
  module.go:35994	0x6311b4		4439ef			CMPL DI, R13									
  module.go:35994	0x6311b7		0f8695000000		JBE 0x631252									
  module.go:35997	0x6311bd		89cb			MOVL CX, BX									
  module.go:35997	0x6311bf		4489f9			MOVL R15, CX									
  module.go:35997	0x6311c2		be08000000		MOVL $0x8, SI									
  module.go:35997	0x6311c7		4189f0			MOVL SI, R8									
  module.go:35997	0x6311ca		e891aff9ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn3(SB)	
  module.go:35998	0x6311cf		488b8424a0000000	MOVQ 0xa0(SP), AX								
  module.go:35998	0x6311d7		488b5038		MOVQ 0x38(AX), DX								
  module.go:62983	0x6311db		4c8b8c2480000000	MOVQ 0x80(SP), R9								
  module.go:62983	0x6311e3		4c39ca			CMPQ DX, R9									
  module.go:62983	0x6311e6		0f86e3090000		JBE 0x631bcf									
  module.go:35998	0x6311ec		488b7030		MOVQ 0x30(AX), SI								
  module.go:62984	0x6311f0		4c8b842488000000	MOVQ 0x88(SP), R8								
  module.go:62984	0x6311f8		458b54300c		MOVL 0xc(R8)(SI*1), R10								
  module.go:36001	0x6311fd		448b5c2448		MOVL 0x48(SP), R11								
  module.go:36001	0x631202		4529d3			SUBL R10, R11									
  module.go:63184	0x631205		4c8b6c2470		MOVQ 0x70(SP), R13								
  module.go:63184	0x63120a		4c39ea			CMPQ DX, R13									
  module.go:63184	0x63120d		0f86b7090000		JBE 0x631bca									
  module.go:63185	0x631213		488b542458		MOVQ 0x58(SP), DX								
  module.go:63185	0x631218		8b3432			MOVL 0(DX)(SI*1), SI								
  module.go:36047	0x63121b		8b8c24ac000000		MOVL 0xac(SP), CX								
  module.go:35702	0x631222		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x631226		8b9c24a8000000		MOVL 0xa8(SP), BX								
  module.go:36042	0x63122d		8b7c242c		MOVL 0x2c(SP), DI								
  module.go:63184	0x631231		4d89e8			MOVQ R13, R8									
  module.go:63000	0x631234		4d89cc			MOVQ R9, R12									
  module.go:36002	0x631237		4189f1			MOVL SI, R9									
  module.go:36002	0x63123a		4589d7			MOVL R10, R15									
  module.go:36002	0x63123d		4589dd			MOVL R11, R13									
  module.go:62983	0x631240		488b742478		MOVQ 0x78(SP), SI								
  module.go:62983	0x631245		4c8b942488000000	MOVQ 0x88(SP), R10								
  module.go:63185	0x63124d		4c8b5c2458		MOVQ 0x58(SP), R11								
  module.go:36006	0x631252		488b5838		MOVQ 0x38(AX), BX								
  module.go:62983	0x631256		4d8d5a0b		LEAQ 0xb(R10), R11								
  module.go:62983	0x63125a		660f1f440000		NOPW 0(AX)(AX*1)								
  module.go:62983	0x631260		4c39db			CMPQ BX, R11									
  module.go:62983	0x631263		0f865c090000		JBE 0x631bc5									
  module.go:36006	0x631269		4c8b4030		MOVQ 0x30(AX), R8								
  module.go:62984	0x63126d		438b540208		MOVL 0x8(R10)(R8*1), DX								
  module.go:36008	0x631272		4139d5			CMPL R13, DX									
  module.go:36008	0x631275		721d			JB 0x631294									
  module.go:35702	0x631277		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x63127b		8b9c24a8000000		MOVL 0xa8(SP), BX								
  module.go:63184	0x631282		4c8b442470		MOVQ 0x70(SP), R8								
  module.go:63185	0x631287		4c8b5c2458		MOVQ 0x58(SP), R11								
  module.go:36041	0x63128c		4589cd			MOVL R9, R13									
  module.go:36009	0x63128f		e920020000		JMP 0x6314b4									
  module.go:36002	0x631294		44897c2428		MOVL R15, 0x28(SP)								
  module.go:36002	0x631299		44894c2438		MOVL R9, 0x38(SP)								
  module.go:36011	0x63129e		448b6c2448		MOVL 0x48(SP), R13								
  module.go:36011	0x6312a3		4129d5			SUBL DX, R13									
  module.go:36013	0x6312a6		4529ef			SUBL R13, R15									
  module.go:36019	0x6312a9		8b742448		MOVL 0x48(SP), SI								
  module.go:36019	0x6312ad		4129f1			SUBL SI, R9									
  module.go:36015	0x6312b0		4539ef			CMPL R15, R13									
  module.go:36015	0x6312b3		0f92c1			SETB CL										
  module.go:36016	0x6312b6		0fb6c9			MOVZX CL, CX									
  module.go:36019	0x6312b9		4539f9			CMPL R9, R15									
  module.go:36019	0x6312bc		410f93c1		SETAE R9									
  module.go:36020	0x6312c0		450fb6c9		MOVZX R9, R9									
  module.go:36022	0x6312c4		4485c9			TESTL R9, CX									
  module.go:36022	0x6312c7		0f8502010000		JNE 0x6313cf									
  module.go:36024	0x6312cd		4489ee			MOVL R13, SI									
  module.go:36024	0x6312d0		41c1e503		SHLL $0x3, R13									
  module.go:36023	0x6312d4		448b4c2438		MOVL 0x38(SP), R9								
  module.go:36023	0x6312d9		4589cf			MOVL R9, R15									
  module.go:36023	0x6312dc		4129f1			SUBL SI, R9									
  module.go:36023	0x6312df		90			NOPL										
  module.go:36025	0x6312e0		4585ed			TESTL R13, R13									
  module.go:36025	0x6312e3		0f84a0000000		JE 0x631389									
  module.go:62983	0x6312e9		498d7207		LEAQ 0x7(R10), SI								
  module.go:36026	0x6312ed		90			NOPL										
  module.go:62983	0x6312ee		4839f3			CMPQ BX, SI									
  module.go:62983	0x6312f1		0f86c7080000		JBE 0x631bbe									
  module.go:62984	0x6312f7		438b741004		MOVL 0x4(R8)(R10*1), SI								
  module.go:36028	0x6312fc		428d0cce		LEAL 0(SI)(R9*8), CX								
  module.go:36028	0x631300		8d14d6			LEAL 0(SI)(DX*8), DX								
  module.go:63109	0x631303		89ce			MOVL CX, SI									
  module.go:63110	0x631305		89d2			MOVL DX, DX									
  module.go:63111	0x631307		4489e9			MOVL R13, CX									
  module.go:63111	0x63130a		4c8d2c31		LEAQ 0(CX)(SI*1), R13								
  module.go:63112	0x63130e		4c8d2411		LEAQ 0(CX)(DX*1), R12								
  module.go:63113	0x631312		4c39eb			CMPQ BX, R13									
  module.go:63113	0x631315		0f829e080000		JB 0x631bb9									
  module.go:63113	0x63131b		4989f5			MOVQ SI, R13									
  module.go:63113	0x63131e		4829de			SUBQ BX, SI									
  module.go:63113	0x631321		48c1fe3f		SARQ $0x3f, SI									
  module.go:63113	0x631325		4921f5			ANDQ SI, R13									
  module.go:63113	0x631328		4b8d740500		LEAQ 0(R13)(R8*1), SI								
  module.go:63113	0x63132d		4c39e3			CMPQ BX, R12									
  module.go:63113	0x631330		0f827e080000		JB 0x631bb4									
  module.go:63113	0x631336		4989d4			MOVQ DX, R12									
  module.go:63113	0x631339		4829da			SUBQ BX, DX									
  module.go:63113	0x63133c		48c1fa3f		SARQ $0x3f, DX									
  module.go:63113	0x631340		4921d4			ANDQ DX, R12									
  module.go:63113	0x631343		4b8d1c04		LEAQ 0(R12)(R8*1), BX								
  module.go:63113	0x631347		4839f3			CMPQ BX, SI									
  module.go:63113	0x63134a		7435			JE 0x631381									
  module.go:62983	0x63134c		4c895c2468		MOVQ R11, 0x68(SP)								
  module.go:36023	0x631351		44894c2430		MOVL R9, 0x30(SP)								
  module.go:63113	0x631356		4889f0			MOVQ SI, AX									
  module.go:63113	0x631359		e802fae5ff		CALL runtime.memmove(SB)							
  module.go:36030	0x63135e		488b8424a0000000	MOVQ 0xa0(SP), AX								
  module.go:36042	0x631366		8b7c242c		MOVL 0x2c(SP), DI								
  module.go:63001	0x63136a		448b4c2430		MOVL 0x30(SP), R9								
  module.go:63001	0x63136f		4c8b942488000000	MOVQ 0x88(SP), R10								
  module.go:63000	0x631377		4c8b5c2468		MOVQ 0x68(SP), R11								
  module.go:36041	0x63137c		448b7c2438		MOVL 0x38(SP), R15								
  module.go:63000	0x631381		4c8ba42480000000	MOVQ 0x80(SP), R12								
  module.go:36030	0x631389		488b5038		MOVQ 0x38(AX), DX								
  module.go:63000	0x63138d		4c39da			CMPQ DX, R11									
  module.go:63000	0x631390		0f8619080000		JBE 0x631baf									
  module.go:36030	0x631396		488b5030		MOVQ 0x30(AX), DX								
  module.go:63001	0x63139a		45894c1208		MOVL R9, 0x8(R10)(DX*1)								
  module.go:36047	0x63139f		8b8c24ac000000		MOVL 0xac(SP), CX								
  module.go:35702	0x6313a6		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x6313aa		8b9c24a8000000		MOVL 0xa8(SP), BX								
  module.go:62983	0x6313b1		488b742478		MOVQ 0x78(SP), SI								
  module.go:63184	0x6313b6		4c8b442470		MOVQ 0x70(SP), R8								
  module.go:63185	0x6313bb		4c8b5c2458		MOVQ 0x58(SP), R11								
  module.go:36041	0x6313c0		448b7c2428		MOVL 0x28(SP), R15								
  module.go:36041	0x6313c5		448b6c2438		MOVL 0x38(SP), R13								
  module.go:36031	0x6313ca		e9e5000000		JMP 0x6314b4									
  module.go:36033	0x6313cf		41c1e703		SHLL $0x3, R15									
  module.go:36034	0x6313d3		4585ff			TESTL R15, R15									
  module.go:36034	0x6313d6		7530			JNE 0x631408									
  module.go:36047	0x6313d8		8b8c24ac000000		MOVL 0xac(SP), CX								
  module.go:35702	0x6313df		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x6313e3		8b9c24a8000000		MOVL 0xa8(SP), BX								
  module.go:62983	0x6313ea		488b742478		MOVQ 0x78(SP), SI								
  module.go:63184	0x6313ef		4c8b442470		MOVQ 0x70(SP), R8								
  module.go:63185	0x6313f4		4c8b5c2458		MOVQ 0x58(SP), R11								
  module.go:36041	0x6313f9		448b7c2428		MOVL 0x28(SP), R15								
  module.go:36041	0x6313fe		448b6c2438		MOVL 0x38(SP), R13								
  module.go:36035	0x631403		e9ac000000		JMP 0x6314b4									
  module.go:62983	0x631408		498d5207		LEAQ 0x7(R10), DX								
  module.go:36037	0x63140c		90			NOPL										
  module.go:62983	0x63140d		4839d3			CMPQ BX, DX									
  module.go:62983	0x631410		0f8694070000		JBE 0x631baa									
  module.go:62984	0x631416		438b541004		MOVL 0x4(R8)(R10*1), DX								
  module.go:36039	0x63141b		8d34f2			LEAL 0(DX)(SI*8), SI								
  module.go:63109	0x63141e		89f6			MOVL SI, SI									
  module.go:63111	0x631420		4489f9			MOVL R15, CX									
  module.go:63111	0x631423		4c8d0c31		LEAQ 0(CX)(SI*1), R9								
  module.go:63112	0x631427		4c8d1c11		LEAQ 0(CX)(DX*1), R11								
  module.go:63113	0x63142b		4c39cb			CMPQ BX, R9									
  module.go:63113	0x63142e		0f8271070000		JB 0x631ba5									
  module.go:63113	0x631434		4989f1			MOVQ SI, R9									
  module.go:63113	0x631437		4829de			SUBQ BX, SI									
  module.go:63113	0x63143a		48c1fe3f		SARQ $0x3f, SI									
  module.go:63113	0x63143e		4921f1			ANDQ SI, R9									
  module.go:63113	0x631441		4b8d3401		LEAQ 0(R9)(R8*1), SI								
  module.go:63113	0x631445		4c39db			CMPQ BX, R11									
  module.go:63113	0x631448		0f8250070000		JB 0x631b9e									
  module.go:63113	0x63144e		4189d1			MOVL DX, R9									
  module.go:63113	0x631451		4829da			SUBQ BX, DX									
  module.go:63113	0x631454		48c1fa3f		SARQ $0x3f, DX									
  module.go:63113	0x631458		4c21ca			ANDQ R9, DX									
  module.go:63113	0x63145b		4a8d1c02		LEAQ 0(DX)(R8*1), BX								
  module.go:63113	0x63145f		90			NOPL										
  module.go:63113	0x631460		4839f3			CMPQ BX, SI									
  module.go:63113	0x631463		7424			JE 0x631489									
  module.go:63113	0x631465		4889f0			MOVQ SI, AX									
  module.go:63113	0x631468		e8f3f8e5ff		CALL runtime.memmove(SB)							
  module.go:36055	0x63146d		488b8424a0000000	MOVQ 0xa0(SP), AX								
  module.go:36042	0x631475		8b7c242c		MOVL 0x2c(SP), DI								
  module.go:63001	0x631479		4c8b942488000000	MOVQ 0x88(SP), R10								
  module.go:63000	0x631481		4c8ba42480000000	MOVQ 0x80(SP), R12								
  module.go:36047	0x631489		8b8c24ac000000		MOVL 0xac(SP), CX								
  module.go:35702	0x631490		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x631494		8b9c24a8000000		MOVL 0xa8(SP), BX								
  module.go:62983	0x63149b		488b742478		MOVQ 0x78(SP), SI								
  module.go:63184	0x6314a0		4c8b442470		MOVQ 0x70(SP), R8								
  module.go:63185	0x6314a5		4c8b5c2458		MOVQ 0x58(SP), R11								
  module.go:36041	0x6314aa		448b7c2428		MOVL 0x28(SP), R15								
  module.go:36041	0x6314af		448b6c2438		MOVL 0x38(SP), R13								
  module.go:36042	0x6314b4		85ff			TESTL DI, DI									
  module.go:36042	0x6314b6		0f8453050000		JE 0x631a0f									
  module.go:35974	0x6314bc		4189f9			MOVL DI, R9									
  module.go:35974	0x6314bf		90			NOPL										
  module.go:36044	0x6314c0		e984050000		JMP 0x631a49									
  module.go:63000	0x6314c5		498d7213		LEAQ 0x13(R10), SI								
  module.go:35837	0x6314c9		90			NOPL										
  module.go:63000	0x6314ca		4939f3			CMPQ R11, SI									
  module.go:63000	0x6314cd		0f8637050000		JBE 0x631a0a									
  module.go:63001	0x6314d3		47894c2a10		MOVL R9, 0x10(R10)(R13*1)							
  module.go:35839	0x6314d8		488b7038		MOVQ 0x38(AX), SI								
  module.go:62983	0x6314dc		4d8d4203		LEAQ 0x3(R10), R8								
  module.go:62983	0x6314e0		4c39c6			CMPQ SI, R8									
  module.go:62983	0x6314e3		0f861c050000		JBE 0x631a05									
  module.go:35839	0x6314e9		488b7030		MOVQ 0x30(AX), SI								
  module.go:62984	0x6314ed		4189c9			MOVL CX, R9									
  module.go:62984	0x6314f0		418b3431		MOVL 0(R9)(SI*1), SI								
  module.go:35841	0x6314f4		85f6			TESTL SI, SI									
  module.go:35841	0x6314f6		7404			JE 0x6314fc									
  module.go:35841	0x6314f8		31ff			XORL DI, DI									
  module.go:35841	0x6314fa		eb74			JMP 0x631570									
  module.go:62983	0x6314fc		4c89442478		MOVQ R8, 0x78(SP)								
  module.go:62984	0x631501		4c894c2458		MOVQ R9, 0x58(SP)								
  module.go:35842	0x631506		89cb			MOVL CX, BX									
  module.go:35842	0x631508		e8f335fbff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn88(SB)	
  module.go:35843	0x63150d		488b8424a0000000	MOVQ 0xa0(SP), AX								
  module.go:35843	0x631515		488b4838		MOVQ 0x38(AX), CX								
  module.go:62983	0x631519		488b542478		MOVQ 0x78(SP), DX								
  module.go:62983	0x63151e		6690			NOPW										
  module.go:62983	0x631520		4839d1			CMPQ CX, DX									
  module.go:62983	0x631523		0f86d5040000		JBE 0x6319fe									
  module.go:35843	0x631529		488b5030		MOVQ 0x30(AX), DX								
  module.go:62984	0x63152d		488b742458		MOVQ 0x58(SP), SI								
  module.go:62984	0x631532		8b3416			MOVL 0(SI)(DX*1), SI								
  module.go:62983	0x631535		4c8b842480000000	MOVQ 0x80(SP), R8								
  module.go:62983	0x63153d		0f1f00			NOPL 0(AX)									
  module.go:62983	0x631540		4c39c1			CMPQ CX, R8									
  module.go:62983	0x631543		0f86b0040000		JBE 0x6319f9									
  module.go:62984	0x631549		4c8b8c2488000000	MOVQ 0x88(SP), R9								
  module.go:62984	0x631551		418b54110c		MOVL 0xc(R9)(DX*1), DX								
  module.go:63185	0x631556		8b8c24ac000000		MOVL 0xac(SP), CX								
  module.go:63000	0x63155d		8b9c24a8000000		MOVL 0xa8(SP), BX								
  module.go:63001	0x631564		4d89ca			MOVQ R9, R10									
  module.go:63000	0x631567		4d89c4			MOVQ R8, R12									
  module.go:35845	0x63156a		89d7			MOVL DX, DI									
  module.go:35702	0x63156c		8b542434		MOVL 0x34(SP), DX								
  module.go:35850	0x631570		4c8b4038		MOVQ 0x38(AX), R8								
  module.go:63000	0x631574		4d39e0			CMPQ R8, R12									
  module.go:63000	0x631577		0f8677040000		JBE 0x6319f4									
  module.go:35849	0x63157d		448d4701		LEAL 0x1(DI), R8								
  module.go:35850	0x631581		4c8b4830		MOVQ 0x30(AX), R9								
  module.go:63001	0x631585		4789440a0c		MOVL R8, 0xc(R10)(R9*1)								
  module.go:35851	0x63158a		4c8b4838		MOVQ 0x38(AX), R9								
  module.go:62983	0x63158e		4d8d5a07		LEAQ 0x7(R10), R11								
  module.go:62983	0x631592		4d39d9			CMPQ R9, R11									
  module.go:62983	0x631595		0f8654040000		JBE 0x6319ef									
  module.go:35851	0x63159b		4c8b5830		MOVQ 0x30(AX), R11								
  module.go:62983	0x63159f		4d8d620b		LEAQ 0xb(R10), R12								
  module.go:35852	0x6315a3		90			NOPL										
  module.go:62984	0x6315a4		478b6c1a04		MOVL 0x4(R10)(R11*1), R13							
  module.go:62983	0x6315a9		4d39e1			CMPQ R9, R12									
  module.go:62983	0x6315ac		0f8638040000		JBE 0x6319ea									
  module.go:62984	0x6315b2		478b641a08		MOVL 0x8(R10)(R11*1), R12							
  module.go:35853	0x6315b7		4101fc			ADDL DI, R12									
  module.go:35856	0x6315ba		4439e6			CMPL SI, R12									
  module.go:35857	0x6315bd		41bf00000000		MOVL $0x0, R15									
  module.go:35857	0x6315c3		440f46fe		CMOVBE SI, R15									
  module.go:35859	0x6315c7		4529fc			SUBL R15, R12									
  module.go:35859	0x6315ca		438d74e500		LEAL 0(R13)(R12*8), SI								
  module.go:63026	0x6315cf		4189f4			MOVL SI, R12									
  module.go:63026	0x6315d2		4983c407		ADDQ $0x7, R12									
  module.go:63026	0x6315d6		4d39e1			CMPQ R9, R12									
  module.go:35856	0x6315d9		0f8606040000		JBE 0x6319e5									
  module.go:63027	0x6315df		89f6			MOVL SI, SI									
  module.go:63027	0x6315e1		49c7043300000000	MOVQ $0x0, 0(R11)(SI*1)								
  module.go:63027	0x6315e9		4531c9			XORL R9, R9									
  module.go:35860	0x6315ec		e91e030000		JMP 0x63190f									
  module.go:36080	0x6315f1		488b7038		MOVQ 0x38(AX), SI								
  module.go:63009	0x6315f5		498d7a1f		LEAQ 0x1f(R10), DI								
  module.go:63009	0x6315f9		0f1f8000000000		NOPL 0(AX)									
  module.go:63009	0x631600		4839fe			CMPQ SI, DI									
  module.go:63009	0x631603		0f8601030000		JBE 0x63190a									
  module.go:36080	0x631609		488b7030		MOVQ 0x30(AX), SI								
  module.go:36081	0x63160d		4c8b4038		MOVQ 0x38(AX), R8								
  module.go:63010	0x631611		498b743218		MOVQ 0x18(R10)(SI*1), SI							
  unsafe.go:41		0x631616		66480f6ec6		MOVQ SI, X0									
  module.go:36081	0x63161b		f20f100d45292d00	MOVSD_XMM $f64.3ff0000000000000(SB), X1						
  module.go:36081	0x631623		f20f58c8		ADDSD X0, X1									
  module.go:63026	0x631627		4939f8			CMPQ R8, DI									
  module.go:63026	0x63162a		0f86d5020000		JBE 0x631905									
  module.go:36081	0x631630		488b7030		MOVQ 0x30(AX), SI								
  module.go:63027	0x631634		f2410f114c3218		MOVSD_XMM X1, 0x18(R10)(SI*1)							
  module.go:63027	0x63163b		0f1f440000		NOPL 0(AX)(AX*1)								
  module.go:36082	0x631640		e9b3020000		JMP 0x6318f8									
  module.go:35705	0x631645		8974244c		MOVL SI, 0x4c(SP)								
  module.go:35739	0x631649		bb10000000		MOVL $0x10, BX									
  module.go:35739	0x63164e		b901000000		MOVL $0x1, CX									
  module.go:35739	0x631653		e808adf9ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn4(SB)	
  module.go:35739	0x631658		0f1f840000000000	NOPL 0(AX)(AX*1)								
  module.go:35741	0x631660		85c0			TESTL AX, AX									
  module.go:35741	0x631662		0f8462020000		JE 0x6318ca									
  module.go:35742	0x631668		488b9424a0000000	MOVQ 0xa0(SP), DX								
  module.go:35742	0x631670		488b7238		MOVQ 0x38(DX), SI								
  module.go:63109	0x631674		89c7			MOVL AX, DI									
  module.go:63111	0x631676		4c8d4710		LEAQ 0x10(DI), R8								
  module.go:63111	0x63167a		660f1f440000		NOPW 0(AX)(AX*1)								
  module.go:63113	0x631680		4c39c6			CMPQ SI, R8									
  module.go:63113	0x631683		0f823c020000		JB 0x6318c5									
  module.go:35742	0x631689		4c8b4230		MOVQ 0x30(DX), R8								
  module.go:63113	0x63168d		4c01c7			ADDQ R8, DI									
  module.go:63113	0x631690		4881fe718e1000		CMPQ SI, $0x108e71								
  module.go:63113	0x631697		0f821b020000		JB 0x6318b8									
  module.go:35739	0x63169d		89442428		MOVL AX, 0x28(SP)								
  module.go:63113	0x6316a1		498db0618e1000		LEAQ 0x108e61(R8), SI								
  module.go:63113	0x6316a8		4839fe			CMPQ SI, DI									
  module.go:63113	0x6316ab		740b			JE 0x6316b8									
  module.go:63113	0x6316ad		410f1080618e1000	MOVUPS 0x108e61(R8), X0								
  module.go:63113	0x6316b5		0f1107			MOVUPS X0, 0(DI)								
  module.go:35743	0x6316b8		4889d0			MOVQ DX, AX									
  module.go:35743	0x6316bb		bb0c000000		MOVL $0xc, BX									
  module.go:35743	0x6316c0		b904000000		MOVL $0x4, CX									
  module.go:35743	0x6316c5		e896acf9ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn4(SB)	
  module.go:35745	0x6316ca		85c0			TESTL AX, AX									
  module.go:35745	0x6316cc		0f84b8010000		JE 0x63188a									
  module.go:35749	0x6316d2		488b8c24a0000000	MOVQ 0xa0(SP), CX								
  module.go:35749	0x6316da		488b5138		MOVQ 0x38(CX), DX								
  module.go:35749	0x6316de		89c3			MOVL AX, BX									
  module.go:63000	0x6316e0		488d730b		LEAQ 0xb(BX), SI								
  module.go:63000	0x6316e4		4839f2			CMPQ DX, SI									
  module.go:63000	0x6316e7		0f8698010000		JBE 0x631885									
  module.go:35749	0x6316ed		488b5130		MOVQ 0x30(CX), DX								
  module.go:63001	0x6316f1		c744130810000000	MOVL $0x10, 0x8(BX)(DX*1)							
  module.go:35750	0x6316f9		488b5138		MOVQ 0x38(CX), DX								
  module.go:63000	0x6316fd		488d7307		LEAQ 0x7(BX), SI								
  module.go:63000	0x631701		4839f2			CMPQ DX, SI									
  module.go:63000	0x631704		0f8674010000		JBE 0x63187e									
  module.go:35750	0x63170a		488b5130		MOVQ 0x30(CX), DX								
  module.go:63001	0x63170e		8b742428		MOVL 0x28(SP), SI								
  module.go:63001	0x631712		89741304		MOVL SI, 0x4(BX)(DX*1)								
  module.go:35751	0x631716		488b5138		MOVQ 0x38(CX), DX								
  module.go:63000	0x63171a		4883c303		ADDQ $0x3, BX									
  module.go:63000	0x63171e		6690			NOPW										
  module.go:63000	0x631720		4839da			CMPQ DX, BX									
  module.go:63000	0x631723		0f8650010000		JBE 0x631879									
  module.go:35737	0x631729		8b542434		MOVL 0x34(SP), DX								
  module.go:35737	0x63172d		8d5ae8			LEAL -0x18(DX), BX								
  module.go:35751	0x631730		488b7130		MOVQ 0x30(CX), SI								
  module.go:35752	0x631734		89df			MOVL BX, DI									
  module.go:63001	0x631736		4189c0			MOVL AX, R8									
  module.go:63001	0x631739		42c7040610000000	MOVL $0x10, 0(SI)(R8*1)								
  module.go:35752	0x631741		488b7138		MOVQ 0x38(CX), SI								
  module.go:63000	0x631745		4c8d4707		LEAQ 0x7(DI), R8								
  module.go:63000	0x631749		4c39c6			CMPQ SI, R8									
  module.go:63000	0x63174c		0f8622010000		JBE 0x631874									
  module.go:35752	0x631752		488b7130		MOVQ 0x30(CX), SI								
  module.go:63001	0x631756		c744370490931000	MOVL $0x109390, 0x4(DI)(SI*1)							
  module.go:35753	0x63175e		488b7138		MOVQ 0x38(CX), SI								
  module.go:63000	0x631762		4883c703		ADDQ $0x3, DI									
  module.go:63000	0x631766		4839fe			CMPQ SI, DI									
  module.go:63000	0x631769		0f8600010000		JBE 0x63186f									
  module.go:35753	0x63176f		488b7130		MOVQ 0x30(CX), SI								
  module.go:35755	0x631773		8b7c244c		MOVL 0x4c(SP), DI								
  module.go:35755	0x631777		89ff			MOVL DI, DI									
  module.go:63001	0x631779		89db			MOVL BX, BX									
  module.go:63001	0x63177b		89041e			MOVL AX, 0(SI)(BX*1)								
  module.go:35755	0x63177e		488b4138		MOVQ 0x38(CX), AX								
  module.go:62983	0x631782		488d5f0f		LEAQ 0xf(DI), BX								
  module.go:62983	0x631786		4839d8			CMPQ AX, BX									
  module.go:62983	0x631789		0f86db000000		JBE 0x63186a									
  module.go:35755	0x63178f		488b5930		MOVQ 0x30(CX), BX								
  module.go:63184	0x631793		488d770b		LEAQ 0xb(DI), SI								
  module.go:62984	0x631797		448b441f0c		MOVL 0xc(DI)(BX*1), R8								
  module.go:62984	0x63179c		0f1f4000		NOPL 0(AX)									
  module.go:63184	0x6317a0		4839f0			CMPQ AX, SI									
  module.go:63184	0x6317a3		0f86bc000000		JBE 0x631865									
  module.go:63185	0x6317a9		8b441f08		MOVL 0x8(DI)(BX*1), AX								
  module.go:35702	0x6317ad		8d5af8			LEAL -0x8(DX), BX								
  module.go:36219	0x6317b0		488b7138		MOVQ 0x38(CX), SI								
  module.go:36220	0x6317b4		89df			MOVL BX, DI									
  module.go:63000	0x6317b6		4c8d4f07		LEAQ 0x7(DI), R9								
  module.go:63000	0x6317ba		660f1f440000		NOPW 0(AX)(AX*1)								
  module.go:63000	0x6317c0		4c39ce			CMPQ SI, R9									
  module.go:63000	0x6317c3		0f8695000000		JBE 0x63185e									
  module.go:36219	0x6317c9		4c8b4930		MOVQ 0x30(CX), R9								
  module.go:63001	0x6317cd		4689440f04		MOVL R8, 0x4(DI)(R9*1)								
  module.go:63000	0x6317d2		4883c703		ADDQ $0x3, DI									
  module.go:36221	0x6317d6		90			NOPL										
  module.go:63000	0x6317d7		4839fe			CMPQ SI, DI									
  module.go:63000	0x6317da		767d			JBE 0x631859									
  module.go:35700	0x6317dc		8d72f0			LEAL -0x10(DX), SI								
  module.go:36226	0x6317df		89f7			MOVL SI, DI									
  module.go:63001	0x6317e1		89db			MOVL BX, BX									
  module.go:63001	0x6317e3		41890419		MOVL AX, 0(R9)(BX*1)								
  module.go:36222	0x6317e7		897150			MOVL SI, 0x50(CX)								
  module.go:36226	0x6317ea		488b4138		MOVQ 0x38(CX), AX								
  module.go:62983	0x6317ee		488d5f0f		LEAQ 0xf(DI), BX								
  module.go:62983	0x6317f2		4839d8			CMPQ AX, BX									
  module.go:62983	0x6317f5		765d			JBE 0x631854									
  module.go:36226	0x6317f7		488b5930		MOVQ 0x30(CX), BX								
  module.go:62983	0x6317fb		488d770b		LEAQ 0xb(DI), SI								
  module.go:36229	0x6317ff		90			NOPL										
  module.go:62984	0x631800		448b441f0c		MOVL 0xc(DI)(BX*1), R8								
  module.go:62983	0x631805		4839f0			CMPQ AX, SI									
  module.go:62983	0x631808		7645			JBE 0x63184f									
  module.go:63000	0x63180a		8bb424a8000000		MOVL 0xa8(SP), SI								
  module.go:63000	0x631811		4189f1			MOVL SI, R9									
  module.go:63000	0x631814		4d8d5103		LEAQ 0x3(R9), R10								
  module.go:36230	0x631818		90			NOPL										
  module.go:62984	0x631819		8b7c1f08		MOVL 0x8(DI)(BX*1), DI								
  module.go:62984	0x63181d		0f1f00			NOPL 0(AX)									
  module.go:63000	0x631820		4c39d0			CMPQ AX, R10									
  module.go:63000	0x631823		7625			JBE 0x63184a									
  module.go:63001	0x631825		89f6			MOVL SI, SI									
  module.go:63001	0x631827		893c33			MOVL DI, 0(BX)(SI*1)								
  module.go:63000	0x63182a		498d7107		LEAQ 0x7(R9), SI								
  module.go:36231	0x63182e		90			NOPL										
  module.go:63000	0x63182f		4839f0			CMPQ AX, SI									
  module.go:63000	0x631832		7611			JBE 0x631845									
  module.go:63001	0x631834		4589441904		MOVL R8, 0x4(R9)(BX*1)								
  module.go:36232	0x631839		895150			MOVL DX, 0x50(CX)								
  module.go:36233	0x63183c		4881c490000000		ADDQ $0x90, SP									
  module.go:36233	0x631843		5d			POPQ BP										
  module.go:36233	0x631844		c3			RET										
  module.go:63000	0x631845		e876f1e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x63184a		e871f1e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x63184f		e86cf1e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x631854		e867f1e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x631859		e862f1e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x63185e		6690			NOPW										
  module.go:63000	0x631860		e85bf1e5ff		CALL runtime.panicBounds(SB)							
  module.go:63184	0x631865		e856f1e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x63186a		e851f1e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x63186f		e84cf1e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x631874		e847f1e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x631879		e842f1e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x63187e		6690			NOPW										
  module.go:63000	0x631880		e83bf1e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x631885		e836f1e5ff		CALL runtime.panicBounds(SB)							
  module.go:35746	0x63188a		488b8424a0000000	MOVQ 0xa0(SP), AX								
  module.go:35746	0x631892		bb04000000		MOVL $0x4, BX									
  module.go:35746	0x631897		b90c000000		MOVL $0xc, CX									
  module.go:35746	0x63189c		0f1f4000		NOPL 0(AX)									
  module.go:35746	0x6318a0		e89b2efaff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn35(SB)	
  module.go:35747	0x6318a5		488d0574b12100		LEAQ 0x21b174(IP), AX								
  module.go:35747	0x6318ac		488d1d3d2a2d00		LEAQ 0x2d2a3d(IP), BX								
  module.go:35747	0x6318b3		e8286fe5ff		CALL runtime.gopanic(SB)							
  module.go:63113	0x6318b8		48c7c0718e1000		MOVQ $0x108e71, AX								
  module.go:63113	0x6318bf		90			NOPL										
  module.go:63113	0x6318c0		e8fbf0e5ff		CALL runtime.panicBounds(SB)							
  module.go:63113	0x6318c5		e8f6f0e5ff		CALL runtime.panicBounds(SB)							
  module.go:35762	0x6318ca		488b8424a0000000	MOVQ 0xa0(SP), AX								
  module.go:35762	0x6318d2		bb01000000		MOVL $0x1, BX									
  module.go:35762	0x6318d7		b910000000		MOVL $0x10, CX									
  module.go:35762	0x6318dc		0f1f4000		NOPL 0(AX)									
  module.go:35762	0x6318e0		e8fba7f9ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn2(SB)	
  module.go:35763	0x6318e5		488d0534b12100		LEAQ 0x21b134(IP), AX								
  module.go:35763	0x6318ec		488d1dfd292d00		LEAQ 0x2d29fd(IP), BX								
  module.go:35763	0x6318f3		e8e86ee5ff		CALL runtime.gopanic(SB)							
  module.go:35757	0x6318f8		4189c8			MOVL CX, R8									
  module.go:36219	0x6318fb		4889c1			MOVQ AX, CX									
  module.go:36219	0x6318fe		31c0			XORL AX, AX									
  module.go:36217	0x631900		e9a8feffff		JMP 0x6317ad									
  module.go:63026	0x631905		e8b6f0e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x63190a		e8b1f0e5ff		CALL runtime.panicBounds(SB)							
  module.go:36196	0x63190f		4539c8			CMPL R8, R9									
  module.go:36196	0x631912		0f86a1000000		JBE 0x6319b9									
  module.go:36200	0x631918		488b7038		MOVQ 0x38(AX), SI								
  module.go:62983	0x63191c		498d7a07		LEAQ 0x7(R10), DI								
  module.go:62983	0x631920		4839fe			CMPQ SI, DI									
  module.go:62983	0x631923		0f868b000000		JBE 0x6319b4									
  module.go:36200	0x631929		488b7830		MOVQ 0x30(AX), DI								
  module.go:62983	0x63192d		4d8d420b		LEAQ 0xb(R10), R8								
  module.go:36201	0x631931		90			NOPL										
  module.go:62984	0x631932		458b5c3a04		MOVL 0x4(R10)(DI*1), R11							
  module.go:62983	0x631937		4c39c6			CMPQ SI, R8									
  module.go:62983	0x63193a		7673			JBE 0x6319af									
  module.go:62984	0x63193c		458b443a08		MOVL 0x8(R10)(DI*1), R8								
  module.go:63184	0x631941		4983c203		ADDQ $0x3, R10									
  module.go:36202	0x631945		4501c8			ADDL R9, R8									
  module.go:36203	0x631948		90			NOPL										
  module.go:63184	0x631949		4c39d6			CMPQ SI, R10									
  module.go:63184	0x63194c		765c			JBE 0x6319aa									
  module.go:63185	0x63194e		89c9			MOVL CX, CX									
  module.go:63185	0x631950		8b0c39			MOVL 0(CX)(DI*1), CX								
  module.go:36207	0x631953		4439c1			CMPL CX, R8									
  module.go:36207	0x631956		7602			JBE 0x63195a									
  module.go:36207	0x631958		31c9			XORL CX, CX									
  module.go:36210	0x63195a		4129c8			SUBL CX, R8									
  module.go:36210	0x63195d		438d0cc3		LEAL 0(R11)(R8*8), CX								
  module.go:63009	0x631961		4189c8			MOVL CX, R8									
  module.go:63009	0x631964		4983c007		ADDQ $0x7, R8									
  module.go:36211	0x631968		90			NOPL										
  module.go:63009	0x631969		4c39c6			CMPQ SI, R8									
  module.go:63009	0x63196c		7637			JBE 0x6319a5									
  module.go:36212	0x63196e		488b7038		MOVQ 0x38(AX), SI								
  module.go:63010	0x631972		4189c9			MOVL CX, R9									
  module.go:63010	0x631975		498b3c39		MOVQ 0(R9)(DI*1), DI								
  unsafe.go:41		0x631979		66480f6ec7		MOVQ DI, X0									
  module.go:36211	0x63197e		90			NOPL										
  module.go:36212	0x63197f		f20f100de1252d00	MOVSD_XMM $f64.3ff0000000000000(SB), X1						
  module.go:36212	0x631987		f20f58c1		ADDSD X1, X0									
  module.go:63026	0x63198b		4c39c6			CMPQ SI, R8									
  module.go:63026	0x63198e		760f			JBE 0x63199f									
  module.go:36212	0x631990		488b7030		MOVQ 0x30(AX), SI								
  module.go:63027	0x631994		f2420f11040e		MOVSD_XMM X0, 0(SI)(R9*1)							
  module.go:36215	0x63199a		e959ffffff		JMP 0x6318f8									
  module.go:63026	0x63199f		90			NOPL										
  module.go:63026	0x6319a0		e81bf0e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x6319a5		e816f0e5ff		CALL runtime.panicBounds(SB)							
  module.go:63184	0x6319aa		e811f0e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x6319af		e80cf0e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x6319b4		e807f0e5ff		CALL runtime.panicBounds(SB)							
  module.go:36197	0x6319b9		bbf88e1000		MOVL $0x108ef8, BX								
  module.go:36197	0x6319be		b914000000		MOVL $0x14, CX									
  module.go:36197	0x6319c3		bf0c8f1000		MOVL $0x108f0c, DI								
  module.go:36197	0x6319c8		e833e2faff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn69(SB)	
  module.go:36198	0x6319cd		488d054cb02100		LEAQ 0x21b04c(IP), AX								
  module.go:36198	0x6319d4		488d1d15292d00		LEAQ 0x2d2915(IP), BX								
  module.go:36198	0x6319db		0f1f440000		NOPL 0(AX)(AX*1)								
  module.go:36198	0x6319e0		e8fb6de5ff		CALL runtime.gopanic(SB)							
  module.go:63026	0x6319e5		e8d6efe5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x6319ea		e8d1efe5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x6319ef		e8ccefe5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x6319f4		e8c7efe5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x6319f9		e8c2efe5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x6319fe		6690			NOPW										
  module.go:62983	0x631a00		e8bbefe5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x631a05		e8b6efe5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x631a0a		e8b1efe5ff		CALL runtime.panicBounds(SB)							
  module.go:36074	0x631a0f		4c8b4038		MOVQ 0x38(AX), R8								
  module.go:62983	0x631a13		4939f0			CMPQ R8, SI									
  module.go:62983	0x631a16		7615			JBE 0x631a2d									
  module.go:36074	0x631a18		488b7030		MOVQ 0x30(AX), SI								
  module.go:36075	0x631a1c		90			NOPL										
  module.go:63001	0x631a1d		41297c3210		SUBL DI, 0x10(R10)(SI*1)							
  module.go:63001	0x631a22		4531c9			XORL R9, R9									
  module.go:36195	0x631a25		4589f8			MOVL R15, R8									
  module.go:36077	0x631a28		e9e2feffff		JMP 0x63190f									
  module.go:62983	0x631a2d		e88eefe5ff		CALL runtime.panicBounds(SB)							
  module.go:36068	0x631a32		ffcf			DECL DI										
  module.go:35702	0x631a34		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x631a38		8b9c24a8000000		MOVL 0xa8(SP), BX								
  module.go:63184	0x631a3f		4c8b442470		MOVQ 0x70(SP), R8								
  module.go:63185	0x631a44		4c8b5c2458		MOVQ 0x58(SP), R11								
  module.go:36046	0x631a49		4539ef			CMPL R15, R13									
  module.go:36046	0x631a4c		0f8586000000		JNE 0x631ad8									
  module.go:36070	0x631a52		897c244c		MOVL DI, 0x4c(SP)								
  module.go:36047	0x631a56		89cb			MOVL CX, BX									
  module.go:36047	0x631a58		e8a330fbff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn88(SB)	
  module.go:36048	0x631a5d		488b8424a0000000	MOVQ 0xa0(SP), AX								
  module.go:36048	0x631a65		488b4838		MOVQ 0x38(AX), CX								
  module.go:62983	0x631a69		488b942480000000	MOVQ 0x80(SP), DX								
  module.go:62983	0x631a71		4839d1			CMPQ CX, DX									
  module.go:62983	0x631a74		0f861f010000		JBE 0x631b99									
  module.go:36048	0x631a7a		488b7030		MOVQ 0x30(AX), SI								
  module.go:62984	0x631a7e		4c8b842488000000	MOVQ 0x88(SP), R8								
  module.go:62984	0x631a86		458b4c300c		MOVL 0xc(R8)(SI*1), R9								
  module.go:63184	0x631a8b		4c8b542470		MOVQ 0x70(SP), R10								
  module.go:63184	0x631a90		4c39d1			CMPQ CX, R10									
  module.go:63184	0x631a93		0f86fb000000		JBE 0x631b94									
  module.go:63185	0x631a99		4c8b5c2458		MOVQ 0x58(SP), R11								
  module.go:63185	0x631a9e		458b2c33		MOVL 0(R11)(SI*1), R13								
  module.go:36047	0x631aa2		8b8c24ac000000		MOVL 0xac(SP), CX								
  module.go:35702	0x631aa9		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x631aad		8b9c24a8000000		MOVL 0xa8(SP), BX								
  module.go:62983	0x631ab4		488b742478		MOVQ 0x78(SP), SI								
  module.go:36069	0x631ab9		8b7c244c		MOVL 0x4c(SP), DI								
  module.go:63184	0x631abd		4d89d0			MOVQ R10, R8									
  module.go:63001	0x631ac0		4c8b942488000000	MOVQ 0x88(SP), R10								
  module.go:63000	0x631ac8		4c8ba42480000000	MOVQ 0x80(SP), R12								
  module.go:36050	0x631ad0		4589cf			MOVL R9, R15									
  module.go:63001	0x631ad3		448b4c242c		MOVL 0x2c(SP), R9								
  module.go:36055	0x631ad8		488b5838		MOVQ 0x38(AX), BX								
  module.go:36055	0x631adc		0f1f4000		NOPL 0(AX)									
  module.go:63000	0x631ae0		4c39e3			CMPQ BX, R12									
  module.go:63000	0x631ae3		0f86a6000000		JBE 0x631b8f									
  module.go:36054	0x631ae9		41ffc7			INCL R15									
  module.go:36055	0x631aec		488b5830		MOVQ 0x30(AX), BX								
  module.go:63001	0x631af0		45897c1a0c		MOVL R15, 0xc(R10)(BX*1)							
  module.go:36056	0x631af5		488b5838		MOVQ 0x38(AX), BX								
  module.go:62983	0x631af9		4d8d5a0b		LEAQ 0xb(R10), R11								
  module.go:62983	0x631afd		0f1f00			NOPL 0(AX)									
  module.go:62983	0x631b00		4c39db			CMPQ BX, R11									
  module.go:62983	0x631b03		0f8681000000		JBE 0x631b8a									
  module.go:36056	0x631b09		4c8b5830		MOVQ 0x30(AX), R11								
  module.go:62984	0x631b0d		438b5c1a08		MOVL 0x8(R10)(R11*1), BX							
  module.go:36058	0x631b12		448d43ff		LEAL -0x1(BX), R8								
  module.go:36059	0x631b16		418d5c1d00		LEAL 0(R13)(BX*1), BX								
  module.go:36059	0x631b1b		8d5bff			LEAL -0x1(BX), BX								
  module.go:62983	0x631b1e		498d5207		LEAQ 0x7(R10), DX								
  module.go:36065	0x631b22		90			NOPL										
  module.go:36061	0x631b23		4439c3			CMPL BX, R8									
  module.go:36062	0x631b26		440f42c3		CMOVB BX, R8									
  module.go:63001	0x631b2a		4789441a08		MOVL R8, 0x8(R10)(R11*1)							
  module.go:36066	0x631b2f		4c8b5838		MOVQ 0x38(AX), R11								
  module.go:62983	0x631b33		4939d3			CMPQ R11, DX									
  module.go:62983	0x631b36		764d			JBE 0x631b85									
  module.go:36066	0x631b38		488b5030		MOVQ 0x30(AX), DX								
  module.go:62984	0x631b3c		418b5c1204		MOVL 0x4(R10)(DX*1), BX								
  module.go:36067	0x631b41		468d04c3		LEAL 0(BX)(R8*8), R8								
  module.go:63026	0x631b45		4489c3			MOVL R8, BX									
  module.go:63026	0x631b48		4883c307		ADDQ $0x7, BX									
  module.go:63026	0x631b4c		4939db			CMPQ R11, BX									
  module.go:63026	0x631b4f		762b			JBE 0x631b7c									
  module.go:63027	0x631b51		4589c0			MOVL R8, R8									
  module.go:63027	0x631b54		4ac7040200000000	MOVQ $0x0, 0(DX)(R8*1)								
  module.go:63027	0x631b5c		0f1f4000		NOPL 0(AX)									
  module.go:36069	0x631b60		83ff01			CMPL DI, $0x1									
  module.go:36069	0x631b63		0f85c9feffff		JNE 0x631a32									
  module.go:35702	0x631b69		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x631b6d		8b9c24a8000000		MOVL 0xa8(SP), BX								
  module.go:63001	0x631b74		4489cf			MOVL R9, DI									
  module.go:36069	0x631b77		e993feffff		JMP 0x631a0f									
  module.go:63026	0x631b7c		0f1f4000		NOPL 0(AX)									
  module.go:63026	0x631b80		e83beee5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x631b85		e836eee5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x631b8a		e831eee5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x631b8f		e82ceee5ff		CALL runtime.panicBounds(SB)							
  module.go:63184	0x631b94		e827eee5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x631b99		e822eee5ff		CALL runtime.panicBounds(SB)							
  module.go:63113	0x631b9e		6690			NOPW										
  module.go:63113	0x631ba0		e81beee5ff		CALL runtime.panicBounds(SB)							
  module.go:63113	0x631ba5		e816eee5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x631baa		e811eee5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x631baf		e80ceee5ff		CALL runtime.panicBounds(SB)							
  module.go:63113	0x631bb4		e807eee5ff		CALL runtime.panicBounds(SB)							
  module.go:63113	0x631bb9		e802eee5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x631bbe		6690			NOPW										
  module.go:62983	0x631bc0		e8fbede5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x631bc5		e8f6ede5ff		CALL runtime.panicBounds(SB)							
  module.go:63184	0x631bca		e8f1ede5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x631bcf		e8ecede5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x631bd4		e8e7ede5ff		CALL runtime.panicBounds(SB)							
  module.go:35988	0x631bd9		bb508e1000		MOVL $0x108e50, BX								
  module.go:35988	0x631bde		b911000000		MOVL $0x11, CX									
  module.go:35988	0x631be3		bfe88e1000		MOVL $0x108ee8, DI								
  module.go:35988	0x631be8		e813e0faff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn69(SB)	
  module.go:35989	0x631bed		488d052cae2100		LEAQ 0x21ae2c(IP), AX								
  module.go:35989	0x631bf4		488d1df5262d00		LEAQ 0x2d26f5(IP), BX								
  module.go:35989	0x631bfb		0f1f440000		NOPL 0(AX)(AX*1)								
  module.go:35989	0x631c00		e8db6be5ff		CALL runtime.gopanic(SB)							
  module.go:62983	0x631c05		e8b6ede5ff		CALL runtime.panicBounds(SB)							
  module.go:36143	0x631c0a		4539d8			CMPL R8, R11									
  module.go:36143	0x631c0d		7603			JBE 0x631c12									
  module.go:36143	0x631c0f		4531c0			XORL R8, R8									
  module.go:36146	0x631c12		4529c3			SUBL R8, R11									
  module.go:36146	0x631c15		468d04db		LEAL 0(BX)(R11*8), R8								
  module.go:36147	0x631c19		4c8b5838		MOVQ 0x38(AX), R11								
  module.go:63009	0x631c1d		4589c4			MOVL R8, R12									
  module.go:63009	0x631c20		4983c407		ADDQ $0x7, R12									
  module.go:63009	0x631c24		4d39e3			CMPQ R11, R12									
  module.go:63009	0x631c27		0f8602020000		JBE 0x631e2f									
  module.go:36147	0x631c2d		4c8b5830		MOVQ 0x30(AX), R11								
  module.go:36148	0x631c31		4c8b6838		MOVQ 0x38(AX), R13								
  module.go:63010	0x631c35		4589c0			MOVL R8, R8									
  module.go:63010	0x631c38		4f8b1c18		MOVQ 0(R8)(R11*1), R11								
  module.go:36147	0x631c3c		66490f6ecb		MOVQ R11, X1									
  module.go:36148	0x631c41		f20f58c1		ADDSD X1, X0									
  module.go:63026	0x631c45		4d39e5			CMPQ R13, R12									
  module.go:63026	0x631c48		0f86dc010000		JBE 0x631e2a									
  module.go:36148	0x631c4e		4c8b5830		MOVQ 0x30(AX), R11								
  module.go:63027	0x631c52		f2430f110403		MOVSD_XMM X0, 0(R11)(R8*1)							
  module.go:36153	0x631c58		4c8b4038		MOVQ 0x38(AX), R8								
  module.go:36152	0x631c5c		468d1c0f		LEAL 0(DI)(R9*1), R11								
  module.go:36152	0x631c60		458d0c39		LEAL 0(R9)(DI*1), R9								
  module.go:36152	0x631c64		458d4901		LEAL 0x1(R9), R9								
  module.go:63000	0x631c68		4939f0			CMPQ R8, SI									
  module.go:63000	0x631c6b		0f86b4010000		JBE 0x631e25									
  module.go:36153	0x631c71		488b7030		MOVQ 0x30(AX), SI								
  module.go:63001	0x631c75		45894c3210		MOVL R9, 0x10(R10)(SI*1)							
  module.go:36154	0x631c7a		4429da			SUBL R11, DX									
  module.go:36154	0x631c7d		448d4aff		LEAL -0x1(DX), R9								
  module.go:63000	0x631c81		4c8ba42480000000	MOVQ 0x80(SP), R12								
  module.go:36157	0x631c89		4489ca			MOVL R9, DX									
  module.go:36157	0x631c8c		4529f9			SUBL R15, R9									
  module.go:36157	0x631c8f		4181f9feffff7f		CMPL R9, $0x7ffffffe								
  module.go:36157	0x631c96		7730			JA 0x631cc8									
  module.go:36161	0x631c98		488b7038		MOVQ 0x38(AX), SI								
  module.go:62983	0x631c9c		4d8d4203		LEAQ 0x3(R10), R8								
  module.go:62983	0x631ca0		4c39c6			CMPQ SI, R8									
  module.go:62983	0x631ca3		0f8675010000		JBE 0x631e1e									
  module.go:62983	0x631ca9		4c89442478		MOVQ R8, 0x78(SP)								
  module.go:36154	0x631cae		8954244c		MOVL DX, 0x4c(SP)								
  module.go:36161	0x631cb2		488b7030		MOVQ 0x30(AX), SI								
  module.go:62984	0x631cb6		4189c9			MOVL CX, R9									
  module.go:62984	0x631cb9		4c894c2458		MOVQ R9, 0x58(SP)								
  module.go:36160	0x631cbe		458d5fff		LEAL -0x1(R15), R11								
  module.go:62984	0x631cc2		418b3431		MOVL 0(R9)(SI*1), SI								
  module.go:36163	0x631cc6		eb26			JMP 0x631cee									
  module.go:63000	0x631cc8		8b9c24a8000000		MOVL 0xa8(SP), BX								
  module.go:36076	0x631ccf		4189d1			MOVL DX, R9									
  module.go:36195	0x631cd2		4589f8			MOVL R15, R8									
  module.go:35702	0x631cd5		8b542434		MOVL 0x34(SP), DX								
  module.go:36158	0x631cd9		e931fcffff		JMP 0x63190f									
  module.go:62983	0x631cde		4c8b442478		MOVQ 0x78(SP), R8								
  module.go:36191	0x631ce3		4589ef			MOVL R13, R15									
  module.go:36191	0x631ce6		4589cb			MOVL R9, R11									
  module.go:62984	0x631ce9		4c8b4c2458		MOVQ 0x58(SP), R9								
  module.go:36167	0x631cee		4439fe			CMPL SI, R15									
  module.go:36167	0x631cf1		7579			JNE 0x631d6c									
  module.go:36191	0x631cf3		44895c242c		MOVL R11, 0x2c(SP)								
  module.go:36168	0x631cf8		89cb			MOVL CX, BX									
  module.go:36168	0x631cfa		e8012efbff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn88(SB)	
  module.go:36169	0x631cff		488b8424a0000000	MOVQ 0xa0(SP), AX								
  module.go:36169	0x631d07		488b4838		MOVQ 0x38(AX), CX								
  module.go:62983	0x631d0b		488b542478		MOVQ 0x78(SP), DX								
  module.go:62983	0x631d10		4839d1			CMPQ CX, DX									
  module.go:62983	0x631d13		0f8600010000		JBE 0x631e19									
  module.go:36169	0x631d19		488b7030		MOVQ 0x30(AX), SI								
  module.go:62984	0x631d1d		4c8b442458		MOVQ 0x58(SP), R8								
  module.go:62984	0x631d22		458b0c30		MOVL 0(R8)(SI*1), R9								
  module.go:62983	0x631d26		4c8b942480000000	MOVQ 0x80(SP), R10								
  module.go:62983	0x631d2e		4c39d1			CMPQ CX, R10									
  module.go:62983	0x631d31		0f86dd000000		JBE 0x631e14									
  module.go:62984	0x631d37		4c8b9c2488000000	MOVQ 0x88(SP), R11								
  module.go:62984	0x631d3f		458b7c330c		MOVL 0xc(R11)(SI*1), R15							
  module.go:36168	0x631d44		8b8c24ac000000		MOVL 0xac(SP), CX								
  module.go:36190	0x631d4b		8b54244c		MOVL 0x4c(SP), DX								
  module.go:62983	0x631d4f		4c8b442478		MOVQ 0x78(SP), R8								
  module.go:63001	0x631d54		4d89da			MOVQ R11, R10									
  module.go:36189	0x631d57		448b5c242c		MOVL 0x2c(SP), R11								
  module.go:63000	0x631d5c		4c8ba42480000000	MOVQ 0x80(SP), R12								
  module.go:36171	0x631d64		4489ce			MOVL R9, SI									
  module.go:62984	0x631d67		4c8b4c2458		MOVQ 0x58(SP), R9								
  module.go:36178	0x631d6c		4c8b6838		MOVQ 0x38(AX), R13								
  module.go:63000	0x631d70		4d39e5			CMPQ R13, R12									
  module.go:63000	0x631d73		0f8696000000		JBE 0x631e0f									
  module.go:36177	0x631d79		458d6f01		LEAL 0x1(R15), R13								
  module.go:36178	0x631d7d		488b5830		MOVQ 0x30(AX), BX								
  module.go:63001	0x631d81		45896c1a0c		MOVL R13, 0xc(R10)(BX*1)							
  module.go:36179	0x631d86		488b5838		MOVQ 0x38(AX), BX								
  module.go:62983	0x631d8a		498d7a07		LEAQ 0x7(R10), DI								
  module.go:62983	0x631d8e		4839fb			CMPQ BX, DI									
  module.go:62983	0x631d91		7677			JBE 0x631e0a									
  module.go:36179	0x631d93		488b7830		MOVQ 0x30(AX), DI								
  module.go:62983	0x631d97		4d8d4a0b		LEAQ 0xb(R10), R9								
  module.go:36180	0x631d9b		90			NOPL										
  module.go:62984	0x631d9c		458b443a04		MOVL 0x4(R10)(DI*1), R8								
  module.go:62983	0x631da1		4c39cb			CMPQ BX, R9									
  module.go:62983	0x631da4		765f			JBE 0x631e05									
  module.go:62984	0x631da6		458b4c3a08		MOVL 0x8(R10)(DI*1), R9								
  module.go:36181	0x631dab		4501f9			ADDL R15, R9									
  module.go:36184	0x631dae		4439ce			CMPL SI, R9									
  module.go:36185	0x631db1		41bf00000000		MOVL $0x0, R15									
  module.go:36185	0x631db7		440f46fe		CMOVBE SI, R15									
  module.go:36187	0x631dbb		4529f9			SUBL R15, R9									
  module.go:36187	0x631dbe		478d04c8		LEAL 0(R8)(R9*8), R8								
  module.go:63026	0x631dc2		4589c1			MOVL R8, R9									
  module.go:63026	0x631dc5		4983c107		ADDQ $0x7, R9									
  module.go:63026	0x631dc9		4c39cb			CMPQ BX, R9									
  module.go:36184	0x631dcc		7631			JBE 0x631dff									
  module.go:36189	0x631dce		458d4b01		LEAL 0x1(R11), R9								
  module.go:63027	0x631dd2		4589c0			MOVL R8, R8									
  module.go:63027	0x631dd5		4ac7040700000000	MOVQ $0x0, 0(DI)(R8*1)								
  module.go:63027	0x631ddd		0f1f00			NOPL 0(AX)									
  module.go:36190	0x631de0		4439ca			CMPL DX, R9									
  module.go:36190	0x631de3		0f85f5feffff		JNE 0x631cde									
  module.go:63000	0x631de9		8b9c24a8000000		MOVL 0xa8(SP), BX								
  module.go:36076	0x631df0		4189d1			MOVL DX, R9									
  module.go:36195	0x631df3		4589e8			MOVL R13, R8									
  module.go:35702	0x631df6		8b542434		MOVL 0x34(SP), DX								
  module.go:36190	0x631dfa		e910fbffff		JMP 0x63190f									
  module.go:63026	0x631dff		90			NOPL										
  module.go:63026	0x631e00		e8bbebe5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x631e05		e8b6ebe5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x631e0a		e8b1ebe5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x631e0f		e8acebe5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x631e14		e8a7ebe5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x631e19		e8a2ebe5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x631e1e		6690			NOPW										
  module.go:62983	0x631e20		e89bebe5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x631e25		e896ebe5ff		CALL runtime.panicBounds(SB)							
  module.go:63026	0x631e2a		e891ebe5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x631e2f		e88cebe5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x631e34		e887ebe5ff		CALL runtime.panicBounds(SB)							
  module.go:63184	0x631e39		e882ebe5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x631e3e		6690			NOPW										
  module.go:62983	0x631e40		e87bebe5ff		CALL runtime.panicBounds(SB)							
  module.go:35950	0x631e45		4183c0fe		ADDL $-0x2, R8									
  module.go:35952	0x631e49		44897c2428		MOVL R15, 0x28(SP)								
  module.go:35952	0x631e4e		448b7c2440		MOVL 0x40(SP), R15								
  module.go:35898	0x631e53		4585ff			TESTL R15, R15									
  module.go:35898	0x631e56		750d			JNE 0x631e65									
  module.go:35898	0x631e58		4531ff			XORL R15, R15									
  module.go:35898	0x631e5b		0f57c9			XORPS X1, X1									
  module.go:35898	0x631e5e		6690			NOPW										
  module.go:35902	0x631e60		e9a3000000		JMP 0x631f08									
  module.go:35906	0x631e65		488b5838		MOVQ 0x38(AX), BX								
  module.go:63000	0x631e69		4c39e3			CMPQ BX, R12									
  module.go:63000	0x631e6c		0f86f3030000		JBE 0x632265									
  module.go:35905	0x631e72		41ffcf			DECL R15									
  module.go:35906	0x631e75		488b5830		MOVQ 0x30(AX), BX								
  module.go:63001	0x631e79		4c8b8c2488000000	MOVQ 0x88(SP), R9								
  module.go:63001	0x631e81		45897c190c		MOVL R15, 0xc(R9)(BX*1)								
  module.go:35908	0x631e86		8d5e01			LEAL 0x1(SI), BX								
  module.go:35911	0x631e89		4139dd			CMPL R13, BX									
  module.go:35911	0x631e8c		7705			JA 0x631e93									
  module.go:63185	0x631e8e		4489eb			MOVL R13, BX									
  module.go:35912	0x631e91		eb06			JMP 0x631e99									
  module.go:35938	0x631e93		4489eb			MOVL R13, BX									
  module.go:35938	0x631e96		4531ed			XORL R13, R13									
  module.go:35952	0x631e99		89742430		MOVL SI, 0x30(SP)								
  module.go:35915	0x631e9d		488b4838		MOVQ 0x38(AX), CX								
  module.go:35914	0x631ea1		4429ee			SUBL R13, SI									
  module.go:63000	0x631ea4		4c8b6c2470		MOVQ 0x70(SP), R13								
  module.go:63000	0x631ea9		4c39e9			CMPQ CX, R13									
  module.go:63000	0x631eac		0f86ac030000		JBE 0x63225e									
  module.go:35914	0x631eb2		ffc6			INCL SI										
  module.go:35915	0x631eb4		488b4830		MOVQ 0x30(AX), CX								
  module.go:63001	0x631eb8		4189740908		MOVL SI, 0x8(R9)(CX*1)								
  module.go:35916	0x631ebd		488b4838		MOVQ 0x38(AX), CX								
  module.go:35916	0x631ec1		8b542430		MOVL 0x30(SP), DX								
  module.go:35916	0x631ec5		418d14d2		LEAL 0(R10)(DX*8), DX								
  module.go:63009	0x631ec9		89d7			MOVL DX, DI									
  module.go:63009	0x631ecb		4883c707		ADDQ $0x7, DI									
  module.go:63009	0x631ecf		4839f9			CMPQ CX, DI									
  module.go:63009	0x631ed2		0f8681030000		JBE 0x632259									
  module.go:35916	0x631ed8		488b4830		MOVQ 0x30(AX), CX								
  module.go:63010	0x631edc		89d2			MOVL DX, DX									
  module.go:63010	0x631ede		488b140a		MOVQ 0(DX)(CX*1), DX								
  unsafe.go:41		0x631ee2		66480f6eca		MOVQ DX, X1									
  module.go:62984	0x631ee7		8b8c24ac000000		MOVL 0xac(SP), CX								
  module.go:36154	0x631eee		8b542424		MOVL 0x24(SP), DX								
  module.go:36122	0x631ef2		8b7c2448		MOVL 0x48(SP), DI								
  module.go:63184	0x631ef6		4c8b4c2460		MOVQ 0x60(SP), R9								
  module.go:35938	0x631efb		4189dd			MOVL BX, R13									
  module.go:35916	0x631efe		44897c2428		MOVL R15, 0x28(SP)								
  module.go:63185	0x631f03		488b5c2458		MOVQ 0x58(SP), BX								
  module.go:35922	0x631f08		f20f58c8		ADDSD X0, X1									
  module.go:35925	0x631f0c		4585ff			TESTL R15, R15									
  module.go:35925	0x631f0f		751a			JNE 0x631f2b									
  module.go:35925	0x631f11		0f57c0			XORPS X0, X0									
  module.go:35943	0x631f14		448b7c2428		MOVL 0x28(SP), R15								
  module.go:35943	0x631f19		4531ff			XORL R15, R15									
  module.go:35943	0x631f1c		44897c2440		MOVL R15, 0x40(SP)								
  module.go:35943	0x631f21		448b7c2428		MOVL 0x28(SP), R15								
  module.go:35929	0x631f26		e9a3000000		JMP 0x631fce									
  module.go:35933	0x631f2b		488b5838		MOVQ 0x38(AX), BX								
  module.go:63000	0x631f2f		4c39e3			CMPQ BX, R12									
  module.go:63000	0x631f32		0f861c030000		JBE 0x632254									
  module.go:35932	0x631f38		41ffcf			DECL R15									
  module.go:35933	0x631f3b		488b5830		MOVQ 0x30(AX), BX								
  module.go:63001	0x631f3f		4c8b8c2488000000	MOVQ 0x88(SP), R9								
  module.go:63001	0x631f47		45897c190c		MOVL R15, 0xc(R9)(BX*1)								
  module.go:35935	0x631f4c		8d5e01			LEAL 0x1(SI), BX								
  module.go:35938	0x631f4f		4139dd			CMPL R13, BX									
  module.go:35938	0x631f52		7705			JA 0x631f59									
  module.go:63185	0x631f54		4489eb			MOVL R13, BX									
  module.go:35939	0x631f57		eb06			JMP 0x631f5f									
  module.go:35911	0x631f59		4489eb			MOVL R13, BX									
  module.go:35911	0x631f5c		4531ed			XORL R13, R13									
  module.go:35916	0x631f5f		89742444		MOVL SI, 0x44(SP)								
  module.go:35942	0x631f63		488b4838		MOVQ 0x38(AX), CX								
  module.go:35941	0x631f67		4429ee			SUBL R13, SI									
  module.go:63000	0x631f6a		4c8b6c2470		MOVQ 0x70(SP), R13								
  module.go:63000	0x631f6f		4c39e9			CMPQ CX, R13									
  module.go:63000	0x631f72		0f86d7020000		JBE 0x63224f									
  module.go:35941	0x631f78		ffc6			INCL SI										
  module.go:35942	0x631f7a		488b4830		MOVQ 0x30(AX), CX								
  module.go:63001	0x631f7e		4189740908		MOVL SI, 0x8(R9)(CX*1)								
  module.go:35943	0x631f83		488b4838		MOVQ 0x38(AX), CX								
  module.go:35943	0x631f87		8b542444		MOVL 0x44(SP), DX								
  module.go:35943	0x631f8b		418d14d2		LEAL 0(R10)(DX*8), DX								
  module.go:63009	0x631f8f		89d7			MOVL DX, DI									
  module.go:63009	0x631f91		4883c707		ADDQ $0x7, DI									
  module.go:63009	0x631f95		4839f9			CMPQ CX, DI									
  module.go:63009	0x631f98		0f86ac020000		JBE 0x63224a									
  module.go:35943	0x631f9e		488b4830		MOVQ 0x30(AX), CX								
  module.go:63010	0x631fa2		89d2			MOVL DX, DX									
  module.go:63010	0x631fa4		488b140a		MOVQ 0(DX)(CX*1), DX								
  unsafe.go:41		0x631fa8		66480f6ec2		MOVQ DX, X0									
  module.go:62984	0x631fad		8b8c24ac000000		MOVL 0xac(SP), CX								
  module.go:36154	0x631fb4		8b542424		MOVL 0x24(SP), DX								
  module.go:36122	0x631fb8		8b7c2448		MOVL 0x48(SP), DI								
  module.go:63184	0x631fbc		4c8b4c2460		MOVQ 0x60(SP), R9								
  module.go:35911	0x631fc1		4189dd			MOVL BX, R13									
  module.go:35943	0x631fc4		44897c2440		MOVL R15, 0x40(SP)								
  module.go:63185	0x631fc9		488b5c2458		MOVQ 0x58(SP), BX								
  module.go:35949	0x631fce		f20f58c1		ADDSD X1, X0									
  module.go:35951	0x631fd2		4183f802		CMPL R8, $0x2									
  module.go:35951	0x631fd6		0f8569feffff		JNE 0x631e45									
  module.go:36085	0x631fdc		410fbae300		BTL $0x0, R11									
  module.go:36085	0x631fe1		7208			JB 0x631feb									
  module.go:36086	0x631fe3		4589f8			MOVL R15, R8									
  module.go:36086	0x631fe6		e9b5000000		JMP 0x6320a0									
  module.go:36088	0x631feb		4589f8			MOVL R15, R8									
  module.go:36088	0x631fee		448b7c2440		MOVL 0x40(SP), R15								
  module.go:36089	0x631ff3		4585ff			TESTL R15, R15									
  module.go:36089	0x631ff6		0f849d000000		JE 0x632099									
  module.go:36092	0x631ffc		4c8b4038		MOVQ 0x38(AX), R8								
  module.go:63000	0x632000		4d39e0			CMPQ R8, R12									
  module.go:63000	0x632003		0f863c020000		JBE 0x632245									
  module.go:36091	0x632009		458d47ff		LEAL -0x1(R15), R8								
  module.go:36092	0x63200d		4c8b5830		MOVQ 0x30(AX), R11								
  module.go:63001	0x632011		4c8bbc2488000000	MOVQ 0x88(SP), R15								
  module.go:63001	0x632019		4789441f0c		MOVL R8, 0xc(R15)(R11*1)							
  module.go:36094	0x63201e		448d5e01		LEAL 0x1(SI), R11								
  module.go:36097	0x632022		4539dd			CMPL R13, R11									
  module.go:36097	0x632025		7705			JA 0x63202c									
  module.go:63185	0x632027		4589eb			MOVL R13, R11									
  module.go:36098	0x63202a		eb06			JMP 0x632032									
  module.go:36112	0x63202c		4589eb			MOVL R13, R11									
  module.go:36112	0x63202f		4531ed			XORL R13, R13									
  module.go:36088	0x632032		8974243c		MOVL SI, 0x3c(SP)								
  module.go:36101	0x632036		488b5838		MOVQ 0x38(AX), BX								
  module.go:36100	0x63203a		4429ee			SUBL R13, SI									
  module.go:63000	0x63203d		4c8b6c2470		MOVQ 0x70(SP), R13								
  module.go:63000	0x632042		4c39eb			CMPQ BX, R13									
  module.go:63000	0x632045		0f86f3010000		JBE 0x63223e									
  module.go:36100	0x63204b		ffc6			INCL SI										
  module.go:36101	0x63204d		488b5830		MOVQ 0x30(AX), BX								
  module.go:63001	0x632051		4189741f08		MOVL SI, 0x8(R15)(BX*1)								
  module.go:36102	0x632056		488b5838		MOVQ 0x38(AX), BX								
  module.go:36102	0x63205a		448b4c243c		MOVL 0x3c(SP), R9								
  module.go:36102	0x63205f		478d0cca		LEAL 0(R10)(R9*8), R9								
  module.go:63009	0x632063		4489c9			MOVL R9, CX									
  module.go:63009	0x632066		4883c107		ADDQ $0x7, CX									
  module.go:63009	0x63206a		4839cb			CMPQ BX, CX									
  module.go:63009	0x63206d		0f86c6010000		JBE 0x632239									
  module.go:36102	0x632073		488b4830		MOVQ 0x30(AX), CX								
  module.go:63010	0x632077		4589c9			MOVL R9, R9									
  module.go:63010	0x63207a		4d8b0c09		MOVQ 0(R9)(CX*1), R9								
  unsafe.go:41		0x63207e		66490f6ec9		MOVQ R9, X1									
  module.go:62984	0x632083		8b8c24ac000000		MOVL 0xac(SP), CX								
  module.go:63185	0x63208a		488b5c2458		MOVQ 0x58(SP), BX								
  module.go:63184	0x63208f		4c8b4c2460		MOVQ 0x60(SP), R9								
  module.go:36112	0x632094		4589dd			MOVL R11, R13									
  module.go:36104	0x632097		eb03			JMP 0x63209c									
  module.go:36104	0x632099		0f57c9			XORPS X1, X1									
  module.go:36106	0x63209c		f20f58c1		ADDSD X1, X0									
  module.go:36108	0x6320a0		4585c0			TESTL R8, R8									
  module.go:36108	0x6320a3		7423			JE 0x6320c8									
  module.go:36152	0x6320a5		448b4c244c		MOVL 0x4c(SP), R9								
  module.go:36109	0x6320aa		4189f3			MOVL SI, R11									
  module.go:36109	0x6320ad		4589c7			MOVL R8, R15									
  module.go:36109	0x6320b0		4489d3			MOVL R10, BX									
  module.go:63000	0x6320b3		488b742478		MOVQ 0x78(SP), SI								
  module.go:63001	0x6320b8		4c8b942488000000	MOVQ 0x88(SP), R10								
  module.go:36109	0x6320c0		4589e8			MOVL R13, R8									
  module.go:36109	0x6320c3		e942fbffff		JMP 0x631c0a									
  module.go:36112	0x6320c8		4585ed			TESTL R13, R13									
  module.go:36112	0x6320cb		740b			JE 0x6320d8									
  module.go:36112	0x6320cd		41b901000000		MOVL $0x1, R9									
  module.go:36112	0x6320d3		e9b8000000		JMP 0x632190									
  module.go:36086	0x6320d8		f20f11442450		MOVSD_XMM X0, 0x50(SP)								
  module.go:36113	0x6320de		89cb			MOVL CX, BX									
  module.go:36113	0x6320e0		e81b2afbff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn88(SB)	
  module.go:36114	0x6320e5		488b8424a0000000	MOVQ 0xa0(SP), AX								
  module.go:36114	0x6320ed		488b4838		MOVQ 0x38(AX), CX								
  module.go:62983	0x6320f1		488b942480000000	MOVQ 0x80(SP), DX								
  module.go:62983	0x6320f9		0f1f8000000000		NOPL 0(AX)									
  module.go:62983	0x632100		4839d1			CMPQ CX, DX									
  module.go:62983	0x632103		0f862b010000		JBE 0x632234									
  module.go:36114	0x632109		488b7030		MOVQ 0x30(AX), SI								
  module.go:36116	0x63210d		90			NOPL										
  module.go:62984	0x63210e		4c8b842488000000	MOVQ 0x88(SP), R8								
  module.go:62984	0x632116		458b4c300c		MOVL 0xc(R8)(SI*1), R9								
  module.go:62983	0x63211b		4c8b542478		MOVQ 0x78(SP), R10								
  module.go:62983	0x632120		4c39d1			CMPQ CX, R10									
  module.go:62983	0x632123		0f8606010000		JBE 0x63222f									
  module.go:36118	0x632129		90			NOPL										
  module.go:62984	0x63212a		458b5c3010		MOVL 0x10(R8)(SI*1), R11							
  module.go:63184	0x63212f		4c8b642468		MOVQ 0x68(SP), R12								
  module.go:63184	0x632134		4c39e1			CMPQ CX, R12									
  module.go:63184	0x632137		0f86ed000000		JBE 0x63222a									
  module.go:36120	0x63213d		90			NOPL										
  module.go:63185	0x63213e		458b643004		MOVL 0x4(R8)(SI*1), R12								
  module.go:63184	0x632143		4c8b6c2460		MOVQ 0x60(SP), R13								
  module.go:63184	0x632148		4c39e9			CMPQ CX, R13									
  module.go:63184	0x63214b		0f86d4000000		JBE 0x632225									
  module.go:63185	0x632151		4c8b6c2458		MOVQ 0x58(SP), R13								
  module.go:63185	0x632156		458b6c3500		MOVL 0(R13)(SI*1), R13								
  module.go:63184	0x63215b		4c8b7c2470		MOVQ 0x70(SP), R15								
  module.go:63184	0x632160		4c39f9			CMPQ CX, R15									
  module.go:63184	0x632163		0f86b5000000		JBE 0x63221e									
  module.go:36115	0x632169		41ffc1			INCL R9										
  module.go:63185	0x63216c		418b743008		MOVL 0x8(R8)(SI*1), SI								
  module.go:62984	0x632171		8b8c24ac000000		MOVL 0xac(SP), CX								
  module.go:36154	0x632178		8b542424		MOVL 0x24(SP), DX								
  module.go:63027	0x63217c		f20f10442450		MOVSD_XMM 0x50(SP), X0								
  module.go:36122	0x632182		4489df			MOVL R11, DI									
  module.go:36122	0x632185		4589e2			MOVL R12, R10									
  module.go:63000	0x632188		4c8ba42480000000	MOVQ 0x80(SP), R12								
  module.go:36125	0x632190		4c8b4038		MOVQ 0x38(AX), R8								
  module.go:63000	0x632194		4d39e0			CMPQ R8, R12									
  module.go:63000	0x632197		0f867c000000		JBE 0x632219									
  module.go:36125	0x63219d		4c8b4030		MOVQ 0x30(AX), R8								
  module.go:63001	0x6321a1		4c8b9c2488000000	MOVQ 0x88(SP), R11								
  module.go:63001	0x6321a9		47894c030c		MOVL R9, 0xc(R11)(R8*1)								
  module.go:36128	0x6321ae		448d46ff		LEAL -0x1(SI), R8								
  module.go:36129	0x6321b2		418d743500		LEAL 0(R13)(SI*1), SI								
  module.go:36129	0x6321b7		8d76ff			LEAL -0x1(SI), SI								
  module.go:36135	0x6321ba		4c8b7838		MOVQ 0x38(AX), R15								
  module.go:36131	0x6321be		4139f5			CMPL R13, SI									
  module.go:36132	0x6321c1		440f47c6		CMOVA SI, R8									
  module.go:63000	0x6321c5		488b742470		MOVQ 0x70(SP), SI								
  module.go:63000	0x6321ca		4939f7			CMPQ R15, SI									
  module.go:36131	0x6321cd		7645			JBE 0x632214									
  module.go:36135	0x6321cf		488b7030		MOVQ 0x30(AX), SI								
  module.go:63001	0x6321d3		4589443308		MOVL R8, 0x8(R11)(SI*1)								
  module.go:36136	0x6321d8		488b7038		MOVQ 0x38(AX), SI								
  module.go:36136	0x6321dc		478d04c2		LEAL 0(R10)(R8*8), R8								
  module.go:63026	0x6321e0		4589c2			MOVL R8, R10									
  module.go:63026	0x6321e3		4983c207		ADDQ $0x7, R10									
  module.go:63026	0x6321e7		4c39d6			CMPQ SI, R10									
  module.go:63026	0x6321ea		7623			JBE 0x63220f									
  module.go:36136	0x6321ec		4c8b6830		MOVQ 0x30(AX), R13								
  module.go:63027	0x6321f0		4589c0			MOVL R8, R8									
  module.go:63027	0x6321f3		f2430f11440500		MOVSD_XMM X0, 0(R13)(R8*1)							
  module.go:63000	0x6321fa		488b742478		MOVQ 0x78(SP), SI								
  module.go:63001	0x6321ff		4d89da			MOVQ R11, R10									
  module.go:36137	0x632202		4589cf			MOVL R9, R15									
  module.go:36152	0x632205		448b4c244c		MOVL 0x4c(SP), R9								
  module.go:36137	0x63220a		e949faffff		JMP 0x631c58									
  module.go:63026	0x63220f		e8ace7e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x632214		e8a7e7e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x632219		e8a2e7e5ff		CALL runtime.panicBounds(SB)							
  module.go:63184	0x63221e		6690			NOPW										
  module.go:63184	0x632220		e89be7e5ff		CALL runtime.panicBounds(SB)							
  module.go:63184	0x632225		e896e7e5ff		CALL runtime.panicBounds(SB)							
  module.go:63184	0x63222a		e891e7e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x63222f		e88ce7e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x632234		e887e7e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x632239		e882e7e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x63223e		6690			NOPW										
  module.go:63000	0x632240		e87be7e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x632245		e876e7e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x63224a		e871e7e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x63224f		e86ce7e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x632254		e867e7e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x632259		e862e7e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x63225e		6690			NOPW										
  module.go:63000	0x632260		e85be7e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x632265		e856e7e5ff		CALL runtime.panicBounds(SB)							
  module.go:63184	0x63226a		e851e7e5ff		CALL runtime.panicBounds(SB)							
  module.go:63184	0x63226f		e84ce7e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x632274		e847e7e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x632279		e842e7e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x63227e		6690			NOPW										
  module.go:62983	0x632280		e83be7e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x632285		e836e7e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x63228a		e831e7e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x63228f		e82ce7e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x632294		e827e7e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x632299		90			NOPL										
  module.go:35694	0x63229a		4889442408		MOVQ AX, 0x8(SP)								
  module.go:35694	0x63229f		895c2410		MOVL BX, 0x10(SP)								
  module.go:35694	0x6322a3		894c2414		MOVL CX, 0x14(SP)								
  module.go:35694	0x6322a7		f20f11442418		MOVSD_XMM X0, 0x18(SP)								
  module.go:35694	0x6322ad		e8eec9e5ff		CALL runtime.morestack_noctxt.abi0(SB)						
  module.go:35694	0x6322b2		488b442408		MOVQ 0x8(SP), AX								
  module.go:35694	0x6322b7		8b5c2410		MOVL 0x10(SP), BX								
  module.go:35694	0x6322bb		8b4c2414		MOVL 0x14(SP), CX								
  module.go:35694	0x6322bf		f20f10442418		MOVSD_XMM 0x18(SP), X0								
  module.go:35694	0x6322c5		e936e9ffff		JMP dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn176(SB)	
