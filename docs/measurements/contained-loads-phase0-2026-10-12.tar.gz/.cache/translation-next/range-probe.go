// Private phase-0 diagnostic. This is not a production hardener pass.
package main

import (
 "bytes"
 "crypto/sha256"
 "encoding/hex"
 "encoding/json"
 "flag"
 "fmt"
 "go/ast"
 "go/format"
 "go/parser"
 "go/token"
 "os"
 "strconv"
)

type address struct { base *ast.Object; offset uint64 }
type selection struct { Function string; Line int; Base string; Offset, PriorEnd uint64 }
type probe struct {
 set *token.FileSet
 helper *ast.Object
 receiver *ast.Object
 locals map[*ast.Object]bool
 mode string
 function string
 selections []selection
}
func main() {
 input:=flag.String("input","","module source")
 expected:=flag.String("sha256","","required exact source SHA256")
 output:=flag.String("output","","output source")
 inventory:=flag.String("inventory","","selection JSON")
 mode:=flag.String("mode","probe","probe, recheck, or roundtrip")
 flag.Parse()
 source,err:=os.ReadFile(*input);must(err)
 sum:=sha256.Sum256(source);if hex.EncodeToString(sum[:])!=*expected {panic("source identity mismatch")}
 if *mode!="probe"&&*mode!="recheck"&&*mode!="roundtrip" {panic("invalid mode")}
 set:=token.NewFileSet();file,err:=parser.ParseFile(set,*input,source,parser.ParseComments);must(err)
 var helper *ast.FuncDecl
 for _,decl:=range file.Decls {if f,ok:=decl.(*ast.FuncDecl);ok&&f.Name.Name=="load32" {if helper!=nil {panic("duplicate helper")};helper=f}}
 if helper==nil||helper.Name.Obj==nil||file.Scope.Lookup("cocoon_load32_in_range")!=nil {panic("helper/namespace mismatch")}
 ast.Inspect(file,func(node ast.Node)bool{if id,ok:=node.(*ast.Ident);ok&&id.Name=="cocoon_load32_in_range" {panic("reserved helper name in source")};return true})
 p:=probe{set:set,helper:helper.Name.Obj,mode:*mode}
 if *mode!="roundtrip" {
  for _,decl:=range file.Decls {
   f,ok:=decl.(*ast.FuncDecl);if !ok||f.Recv==nil||len(f.Recv.List)!=1||len(f.Recv.List[0].Names)!=1 {continue}
   star,ok:=f.Recv.List[0].Type.(*ast.StarExpr);if !ok {continue};typ,ok:=star.X.(*ast.Ident);if !ok||typ.Name!="Module" {continue}
   p.receiver=f.Recv.List[0].Names[0].Obj;p.function=f.Name.Name
   p.locals=map[*ast.Object]bool{}
   for _,field:=range f.Type.Params.List {for _,name:=range field.Names {p.locals[name.Obj]=true}}
   ast.Inspect(f.Body,func(node ast.Node)bool{if _,nested:=node.(*ast.FuncLit);nested{return false};if spec,ok:=node.(*ast.ValueSpec);ok {for _,name:=range spec.Names{p.locals[name.Obj]=true}};return true})
   ast.Inspect(f.Body,func(node ast.Node)bool {if _,nested:=node.(*ast.FuncLit);nested{return false};if b,ok:=node.(*ast.BlockStmt);ok {p.block(b)};return true})
  }
 }
 var buffer bytes.Buffer;must(format.Node(&buffer,set,file))
 if *mode!="roundtrip" {
  if len(helper.Body.List)!=5 {panic("unexpected helper body")}
  helperSource:=source[set.Position(helper.Pos()).Offset:set.Position(helper.End()).Offset]
  helperSource=bytes.Replace(helperSource,[]byte("func load32["),[]byte("func cocoon_load32_in_range["),1)
  check:=[]byte("\t_ = mem[uint64(addr)+3]\n")
  if bytes.Count(helperSource,check)!=1 {panic("unexpected helper bounds check")}
  if *mode=="probe" {helperSource=bytes.Replace(helperSource,check,nil,1)}
  buffer.WriteString("\n//go:nosplit\n");buffer.Write(helperSource);buffer.WriteByte('\n')
 }
 formatted,err:=format.Source(buffer.Bytes());must(err)
 if *mode=="roundtrip"&&!bytes.Equal(source,formatted) {panic("AST roundtrip changes baseline")}
 must(os.WriteFile(*output,formatted,0600));data,err:=json.MarshalIndent(p.selections,"","  ");must(err);must(os.WriteFile(*inventory,append(data,'\n'),0600))
 fmt.Println(*mode,"selected",len(p.selections),"reads")
}
func must(err error) {if err!=nil {panic(err)}}
func (p *probe) memory(expr ast.Expr) bool {
 s,ok:=expr.(*ast.SelectorExpr);if !ok||s.Sel.Name!="memory" {return false}
 receiver,ok:=s.X.(*ast.Ident);return ok&&receiver.Obj==p.receiver
}
func builtinCall(expr ast.Expr,name string) (ast.Expr,bool) {
 c,ok:=expr.(*ast.CallExpr);if !ok||len(c.Args)!=1||c.Ellipsis.IsValid() {return nil,false}
 id,ok:=c.Fun.(*ast.Ident);if !ok||id.Name!=name||id.Obj!=nil {return nil,false};return c.Args[0],true
}
func explicitI32(obj *ast.Object) bool {
 if obj==nil {return false}
 var typ ast.Expr
 switch d:=obj.Decl.(type) {case *ast.Field:typ=d.Type;case *ast.ValueSpec:typ=d.Type;default:return false}
 id,ok:=typ.(*ast.Ident);return ok&&id.Name=="int32"&&id.Obj==nil
}
func parseAddress(expr ast.Expr) (address,bool) {
 var offset uint64
 if binary,ok:=expr.(*ast.BinaryExpr);ok {
  if binary.Op!=token.ADD {return address{},false}
  literal,ok:=binary.Y.(*ast.BasicLit);if !ok||literal.Kind!=token.INT {return address{},false}
  value,err:=strconv.ParseUint(literal.Value,0,32);if err!=nil {return address{},false};offset=value
  x,ok:=builtinCall(binary.X,"uint64");if !ok {return address{},false};expr=x
 }
 x,ok:=builtinCall(expr,"uint32");if !ok {return address{},false}
 id,ok:=x.(*ast.Ident);if !ok||!explicitI32(id.Obj) {return address{},false}
 return address{base:id.Obj,offset:offset},true
}
func (p *probe) load(expr ast.Expr) (*ast.CallExpr,address,bool) {
 if x,ok:=builtinCall(expr,"int32");ok {expr=x}
 c,ok:=expr.(*ast.CallExpr);if !ok||len(c.Args)!=2||c.Ellipsis.IsValid() {return nil,address{},false}
 id,ok:=c.Fun.(*ast.Ident);if !ok||id.Obj!=p.helper||!p.memory(c.Args[0]) {return nil,address{},false}
 addr,ok:=parseAddress(c.Args[1]);return c,addr,ok&&p.locals[addr.base]
}
// The exact pinned module supplies builtin bindings and identity wrappers.
// Unknown calls, memory reads/indices and selectors are conservatively barriers.
func identityConversion(id *ast.Ident) bool {
 if id.Obj==nil{return false}
 target:="int32";if id.Name=="i64"{target="int64"}
 if alias,ok:=id.Obj.Decl.(*ast.TypeSpec);ok {typ,ok:=alias.Type.(*ast.Ident);return ok&&alias.Assign.IsValid()&&alias.TypeParams==nil&&typ.Name==target&&typ.Obj==nil}
 f,ok:=id.Obj.Decl.(*ast.FuncDecl);if !ok||f.Recv!=nil||f.Type.TypeParams!=nil||f.Body==nil||len(f.Body.List)!=1||f.Type.Params==nil||len(f.Type.Params.List)!=1||f.Type.Results==nil||len(f.Type.Results.List)!=1{return false}
 param:=f.Type.Params.List[0];result:=f.Type.Results.List[0]
 if len(param.Names)!=1||len(result.Names)!=0{return false}
 pt,pok:=param.Type.(*ast.Ident);rt,rok:=result.Type.(*ast.Ident)
 if !pok||!rok||pt.Name!=target||rt.Name!=target||pt.Obj!=nil||rt.Obj!=nil{return false}
 ret,ok:=f.Body.List[0].(*ast.ReturnStmt);if !ok||len(ret.Results)!=1{return false}
 value,ok:=ret.Results[0].(*ast.Ident);return ok&&value.Obj==param.Names[0].Obj
}
func pure(expr ast.Expr) bool {
 switch e:=expr.(type) {
 case *ast.Ident,*ast.BasicLit:return true
 case *ast.ParenExpr:return pure(e.X)
 case *ast.UnaryExpr:return e.Op!=token.AND&&e.Op!=token.ARROW&&pure(e.X)
 case *ast.BinaryExpr:return pure(e.X)&&pure(e.Y)
 case *ast.CallExpr:
  id,ok:=e.Fun.(*ast.Ident);if !ok||len(e.Args)!=1||e.Ellipsis.IsValid() {return false}
  switch id.Name {case "i32","i64":if !identityConversion(id) {return false};case "int32","int64","uint32","uint64","float32","float64":if id.Obj!=nil {return false};default:return false}
  return pure(e.Args[0])
 default:return false
 }
}
func (p *probe) block(block *ast.BlockStmt) {
 facts:=map[*ast.Object]uint64{}
 for _,statement:=range block.List {
  assignment,ok:=statement.(*ast.AssignStmt)
  if !ok||len(assignment.Lhs)!=1||len(assignment.Rhs)!=1||(assignment.Tok!=token.ASSIGN&&assignment.Tok!=token.DEFINE) {clear(facts);continue}
  destination,ok:=assignment.Lhs[0].(*ast.Ident);if !ok||destination.Obj==p.receiver {clear(facts);continue}
  call,addr,loaded:=p.load(assignment.Rhs[0])
  if loaded {
   end:=addr.offset+3 // Absolute endpoint <=2^33+1; widened arithmetic fits uint64.
   if prior,seen:=facts[addr.base];seen&&end<=prior {
    p.selections=append(p.selections,selection{p.function,p.set.Position(call.Pos()).Line,addr.base.Name,addr.offset,prior})
    call.Fun=&ast.Ident{Name:"cocoon_load32_in_range",NamePos:call.Fun.(*ast.Ident).NamePos}
   } else {facts[addr.base]=end}
  } else if !pure(assignment.Rhs[0]) {clear(facts)}
  // RHS observes the old base; assignment then invalidates its range fact.
  delete(facts,destination.Obj)
 }
}
