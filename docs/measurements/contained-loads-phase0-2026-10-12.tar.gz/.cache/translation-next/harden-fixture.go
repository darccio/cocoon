package main
import("os";"flag";"dario.cat/cocoon/internal/harden")
func main(){flag.Parse();source,err:=os.ReadFile(flag.Arg(0));if err!=nil{panic(err)};needed,err:=harden.Required(source);if err!=nil{panic(err)};result,err:=harden.Rewrite(source,needed);if err!=nil{panic(err)};if err:=os.WriteFile(flag.Arg(1),result,0600);err!=nil{panic(err)}}
