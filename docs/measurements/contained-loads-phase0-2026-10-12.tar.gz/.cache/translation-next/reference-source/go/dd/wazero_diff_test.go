package dd

import (
	"bytes"
	"context"
	_ "embed"
	"encoding/binary"
	"fmt"
	"math"
	"testing"

	"cocoon.dev/cocoon/internal/testpayload"
	"github.com/tetratelabs/wazero"
	"github.com/tetratelabs/wazero/api"
)

// The exact bytes wasm2go translated. The reference runtime executes these,
// so differences can only come from translation, not from a different build.
//
//go:embed testdata/shim.wasm
var shimWasm []byte

// wz is a reference implementation of the Cocoon ABI v2 caller on wazero,
// with the same fast path as rt.Instance (cached input buffer, fixed output
// descriptor), so its benchmarks are comparable.
type wz struct {
	ctx          context.Context
	mod          api.Module
	out          uint32
	inPtr, inCap uint32
	fns          map[string]api.Function // cached: each ExportedFunction call builds a new call engine
}

func newWZ(t testing.TB, rtc wazero.RuntimeConfig) *wz {
	ctx := context.Background()
	r := wazero.NewRuntimeWithConfig(ctx, rtc)
	t.Cleanup(func() { r.Close(ctx) })
	_, err := r.NewHostModuleBuilder("cocoon").
		NewFunctionBuilder().WithFunc(func(context.Context, int32, uint32, uint32) {}).Export("log").
		Instantiate(ctx)
	if err != nil {
		t.Fatal(err)
	}
	mod, err := r.InstantiateWithConfig(ctx, shimWasm, wazero.NewModuleConfig().WithName("shim"))
	if err != nil {
		t.Fatal(err)
	}
	w := &wz{ctx: ctx, mod: mod, fns: map[string]api.Function{}}
	w.out = uint32(w.call("cocoon_out")[0])
	return w
}

func (w *wz) call(name string, args ...uint64) []uint64 {
	f := w.fns[name]
	if f == nil {
		f = w.mod.ExportedFunction(name)
		w.fns[name] = f
	}
	res, err := f.Call(w.ctx, args...)
	if err != nil {
		panic(fmt.Sprintf("%s: %v", name, err))
	}
	return res
}

func (w *wz) output() []byte {
	d, _ := w.mod.Memory().Read(w.out, 8)
	b, _ := w.mod.Memory().Read(binary.LittleEndian.Uint32(d), binary.LittleEndian.Uint32(d[4:]))
	return bytes.Clone(b)
}

// bytesOp calls fn(ptr, len) with in placed in the guest input buffer.
func (w *wz) bytesOp(name string, in []byte) (int32, []byte) {
	if uint32(len(in)) > w.inCap || w.inPtr == 0 {
		w.inCap = uint32(max(len(in), 2*int(w.inCap), 4096))
		w.inPtr = uint32(w.call("cocoon_in_reserve", uint64(w.inCap))[0])
	}
	w.mod.Memory().Write(w.inPtr, in)
	st := int32(w.call(name, uint64(w.inPtr), uint64(len(in)))[0])
	return st, w.output()
}

// TestDifferentialWazero runs the same inputs through wazero (interpreter and
// compiler) and through the wasm2go translation, and requires identical
// status codes and bytes.
func TestDifferentialWazero(t *testing.T) {
	l := open(t)
	ctx := context.Background()
	for _, cfg := range []struct {
		name string
		rc   wazero.RuntimeConfig
	}{{"interpreter", wazero.NewRuntimeConfigInterpreter()}, {"compiler", wazero.NewRuntimeConfigCompiler()}} {
		w := newWZ(t, cfg.rc)
		for i, q := range append(sqlCorpus, "SELECT '\xff'") {
			st, ref := w.bytesOp("cocoon_sql_obfuscate", []byte(q))
			got, err := l.ObfuscateSQL(ctx, q)
			if (st == 0) != (err == nil) || (st == 0 && got != string(ref)) {
				t.Fatalf("%s sql[%d]: wazero %d %q, wasm2go %q %v", cfg.name, i, st, ref, got, err)
			}
		}
		for _, shape := range [][2]int{{1, 1}, {3, 12}, {20, 50}} {
			in := testpayload.Traces(shape[0], shape[1])
			st, ref := w.bytesOp("cocoon_traces_obfuscate", in)
			got, err := l.ObfuscateTraces(ctx, in)
			if st != 0 || err != nil || !bytes.Equal(ref, got) {
				t.Fatalf("%s traces %v: wazero st=%d (%d bytes), wasm2go %d bytes %v", cfg.name, shape, st, len(ref), len(got), err)
			}
		}
		h := w.call("cocoon_sketch_new")[0]
		s, _ := l.NewSketch()
		for i := 0; i < 5000; i++ {
			v := float64(i%997) * 1.37
			w.call("cocoon_sketch_add", h, math.Float64bits(v))
			s.Add(v)
		}
		w.call("cocoon_sketch_encode", h)
		ref := w.output()
		got, _ := s.Encode()
		if !bytes.Equal(ref, got) {
			t.Fatalf("%s sketch encodings differ", cfg.name)
		}
		t.Logf("%s: %d SQL, 3 trace payloads, 1 sketch identical", cfg.name, len(sqlCorpus)+1)
	}
}

func benchWZ(b *testing.B, rc wazero.RuntimeConfig, payload []byte, fn string) {
	w := newWZ(b, rc)
	b.ReportAllocs()
	for b.Loop() {
		if st, _ := w.bytesOp(fn, payload); st != 0 {
			b.Fatal(st)
		}
	}
}

func BenchmarkWazeroCompilerSQL(b *testing.B) {
	benchWZ(b, wazero.NewRuntimeConfigCompiler(), []byte(benchQuery), "cocoon_sql_obfuscate")
}

func BenchmarkWazeroCompilerTraces1k(b *testing.B) {
	benchWZ(b, wazero.NewRuntimeConfigCompiler(), testpayload.Traces(20, 50), "cocoon_traces_obfuscate")
}

func BenchmarkWazeroInterpreterSQL(b *testing.B) {
	benchWZ(b, wazero.NewRuntimeConfigInterpreter(), []byte(benchQuery), "cocoon_sql_obfuscate")
}

func BenchmarkWazeroSketchAdd(b *testing.B) {
	w := newWZ(b, wazero.NewRuntimeConfigCompiler())
	h := w.call("cocoon_sketch_new")[0]
	f := w.mod.ExportedFunction("cocoon_sketch_add")
	i := 0.0
	for b.Loop() {
		i++
		f.Call(w.ctx, h, math.Float64bits(i))
	}
}

// New instance of an already-compiled module on a live runtime.
func BenchmarkWazeroNewInstance(b *testing.B) {
	ctx := context.Background()
	r := wazero.NewRuntimeWithConfig(ctx, wazero.NewRuntimeConfigCompiler())
	defer r.Close(ctx)
	r.NewHostModuleBuilder("cocoon").NewFunctionBuilder().
		WithFunc(func(context.Context, int32, uint32, uint32) {}).Export("log").Instantiate(ctx)
	cm, err := r.CompileModule(ctx, shimWasm)
	if err != nil {
		b.Fatal(err)
	}
	for b.Loop() {
		m, err := r.InstantiateModule(ctx, cm, wazero.NewModuleConfig().WithName(""))
		if err != nil {
			b.Fatal(err)
		}
		m.Close(ctx)
	}
}

// New runtime per iteration, sharing an in-memory compilation cache.
func BenchmarkWazeroNewInstanceCached(b *testing.B) {
	ctx := context.Background()
	cache := wazero.NewCompilationCache()
	defer cache.Close(ctx)
	for b.Loop() {
		r := wazero.NewRuntimeWithConfig(ctx, wazero.NewRuntimeConfigCompiler().WithCompilationCache(cache))
		r.NewHostModuleBuilder("cocoon").NewFunctionBuilder().
			WithFunc(func(context.Context, int32, uint32, uint32) {}).Export("log").Instantiate(ctx)
		if _, err := r.Instantiate(ctx, shimWasm); err != nil {
			b.Fatal(err)
		}
		r.Close(ctx)
	}
}
