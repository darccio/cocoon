package dd

import (
	"bytes"
	"cocoon.dev/cocoon/internal/testpayload"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"strings"
	"sync"
	"testing"

	"cocoon.dev/cocoon/rt"
)

func open(t testing.TB) *Library {
	t.Helper()
	l, err := Open(Options{Instances: 4})
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { l.Close() })
	return l
}

var sqlCorpus = []string{
	"SELECT * FROM users WHERE id = 42 AND name = 'bob'",
	"select a, b from t where x in (1, 2, 3) limit 10",
	"UPDATE accounts SET balance = balance - 100.50 WHERE id = 7",
	"INSERT INTO logs (msg, at) VALUES ('héllo wörld', '2026-10-03')",
	"SELECT * FROM t WHERE c = $1 AND d = :name AND e = ?",
	"",
	"SELECT 'unterminated",
	strings.Repeat("SELECT 1 UNION ALL ", 500) + "SELECT 2",
}

func TestObfuscateSQL(t *testing.T) {
	l := open(t)
	ctx := context.Background()
	got, err := l.ObfuscateSQL(ctx, sqlCorpus[0])
	if err != nil {
		t.Fatal(err)
	}
	t.Logf("%q", got)
	if strings.Contains(got, "42") || strings.Contains(got, "bob") {
		t.Fatalf("literals leaked: %q", got)
	}
	// Invalid UTF-8 never reaches Rust's &str: the shim rejects it with ErrArg.
	_, err = l.ObfuscateSQL(ctx, "SELECT '\xff'")
	var ae *rt.AppError
	if !errors.As(err, &ae) || ae.Status != rt.ErrArg {
		t.Fatalf("want ErrArg, got %v", err)
	}
}

func TestObfuscateTraces(t *testing.T) {
	l := open(t)
	in := testpayload.Traces(2, 9)
	out, err := l.ObfuscateTraces(context.Background(), in)
	if err != nil {
		t.Fatal(err)
	}
	// http.url query strings are kept: remove_query_string is off by default, as in the agent.
	for _, secret := range []string{"user3@example.com", "secret-token-4"} {
		if bytes.Contains(out, []byte(secret)) {
			t.Errorf("%q survived obfuscation", secret)
		}
	}
	if _, err := l.ObfuscateTraces(context.Background(), []byte{0xc1}); err == nil {
		t.Fatal("garbage payload accepted")
	}
}

func TestSketch(t *testing.T) {
	l := open(t)
	s, err := l.NewSketch()
	if err != nil {
		t.Fatal(err)
	}
	for i := 1; i <= 1000; i++ {
		if err := s.Add(float64(i)); err != nil {
			t.Fatal(err)
		}
	}
	if c, _ := s.Count(); c != 1000 {
		t.Fatalf("count %v", c)
	}
	batch := make([]float64, 5000)
	for i := range batch {
		batch[i] = float64(i)
	}
	if err := s.AddMany(batch); err != nil {
		t.Fatal(err)
	}
	if c, _ := s.Count(); c != 6000 {
		t.Fatalf("count after AddMany %v", c)
	}
	pb, err := s.Encode()
	if err != nil || len(pb) == 0 {
		t.Fatalf("encode: %d bytes, %v", len(pb), err)
	}
	if err := s.Close(); err != nil {
		t.Fatal(err)
	}
	var he *rt.HandleError
	if err := s.Close(); !errors.As(err, &he) {
		t.Fatalf("double free not detected: %v", err)
	}
}

func TestFaultIsContained(t *testing.T) {
	l := open(t)
	err := l.testPanic(7)
	var fe *rt.FaultError
	if !errors.As(err, &fe) || !strings.Contains(fe.GuestMsg, "cocoon_test_panic(7)") {
		t.Fatalf("want FaultError carrying the guest panic message, got %v", err)
	}
	t.Logf("%v", err)
	// The library keeps working: the pool discards the poisoned instance.
	for i := 0; i < 8; i++ {
		if _, err := l.ObfuscateSQL(context.Background(), "SELECT 1"); err != nil {
			t.Fatal(err)
		}
	}
}

func TestPoisonInvalidatesHandles(t *testing.T) {
	l := open(t)
	s, _ := l.NewSketch()
	if err := l.poisonHome(); err == nil {
		t.Fatal("expected fault")
	}
	var he *rt.HandleError
	if err := s.Add(1); !errors.As(err, &he) {
		t.Fatalf("stale handle accepted: %v", err)
	}
	s2, err := l.NewSketch()
	if err != nil {
		t.Fatal(err)
	}
	if err := s2.Add(1); err != nil {
		t.Fatal(err)
	}
}

func TestConcurrent(t *testing.T) {
	l := open(t)
	var wg sync.WaitGroup
	errs := make(chan error, 64)
	for g := 0; g < 32; g++ {
		wg.Add(1)
		go func(g int) {
			defer wg.Done()
			for i := 0; i < 100; i++ {
				q := fmt.Sprintf("SELECT * FROM t WHERE id = %d AND g = %d", i, g)
				got, err := l.ObfuscateSQL(context.Background(), q)
				if err != nil || got != "SELECT * FROM t WHERE id = ? AND g = ?" {
					errs <- fmt.Errorf("%q -> %q, %v", q, got, err)
					return
				}
			}
		}(g)
	}
	wg.Wait()
	close(errs)
	for err := range errs {
		t.Fatal(err)
	}
}

// TestGolden records every backend's outputs so they can be diffed across
// builds (go test -tags ... -run Golden, then compare the files).
func TestGolden(t *testing.T) {
	dir := os.Getenv("COCOON_GOLDEN_DIR")
	if dir == "" {
		t.Skip("set COCOON_GOLDEN_DIR")
	}
	l := open(t)
	ctx := context.Background()
	rec := map[string]string{}
	for i, q := range sqlCorpus {
		out, err := l.ObfuscateSQL(ctx, q)
		rec[fmt.Sprintf("sql/%d", i)] = fmt.Sprintf("%q %v", out, err)
	}
	out, err := l.ObfuscateTraces(ctx, testpayload.Traces(3, 12))
	rec["traces"] = fmt.Sprintf("%x %v", out, err)
	s, _ := l.NewSketch()
	for i := 0; i < 5000; i++ {
		s.Add(float64(i%997) * 1.37)
	}
	pb, err := s.Encode()
	rec["sketch"] = fmt.Sprintf("%x %v", pb, err)
	b, _ := json.MarshalIndent(rec, "", " ")
	if err := os.WriteFile(dir+"/golden_"+os.Getenv("COCOON_GOLDEN_NAME")+".json", b, 0o644); err != nil {
		t.Fatal(err)
	}
}
