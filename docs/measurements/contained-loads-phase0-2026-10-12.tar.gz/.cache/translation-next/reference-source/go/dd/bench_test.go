package dd

import (
	"cocoon.dev/cocoon/internal/testpayload"
	"context"
	"testing"
)

const benchQuery = "SELECT * FROM users WHERE id = 42 AND name = 'bob'"

func BenchmarkObfuscateSQL(b *testing.B) {
	l := open(b)
	ctx := context.Background()
	b.ReportAllocs()
	for b.Loop() {
		if _, err := l.ObfuscateSQL(ctx, benchQuery); err != nil {
			b.Fatal(err)
		}
	}
}

func BenchmarkObfuscateSQLParallel(b *testing.B) {
	l := open(b)
	ctx := context.Background()
	b.RunParallel(func(pb *testing.PB) {
		for pb.Next() {
			if _, err := l.ObfuscateSQL(ctx, benchQuery); err != nil {
				b.Error(err)
				return
			}
		}
	})
}

// 1,000 spans per call: the boundary is crossed once per batch.
func BenchmarkObfuscateTraces1k(b *testing.B) {
	l := open(b)
	in := testpayload.Traces(20, 50)
	ctx := context.Background()
	b.SetBytes(int64(len(in)))
	b.ReportAllocs()
	for b.Loop() {
		if _, err := l.ObfuscateTraces(ctx, in); err != nil {
			b.Fatal(err)
		}
	}
}

func BenchmarkSketchAdd(b *testing.B) {
	l := open(b)
	s, _ := l.NewSketch()
	defer s.Close()
	i := 0.0
	for b.Loop() {
		i++
		s.Add(i)
	}
}

// Cost of a cold instance (wasm backends) or of a library open (native).
func BenchmarkNewInstance(b *testing.B) {
	for b.Loop() {
		l, err := Open(Options{Instances: 1})
		if err != nil {
			b.Fatal(err)
		}
		l.Close()
	}
}

// 1,000 values per call.
func BenchmarkSketchAddMany1k(b *testing.B) {
	l := open(b)
	s, _ := l.NewSketch()
	defer s.Close()
	vs := make([]float64, 1000)
	for i := range vs {
		vs[i] = float64(i) * 1.5
	}
	for b.Loop() {
		if err := s.AddMany(vs); err != nil {
			b.Fatal(err)
		}
	}
}
