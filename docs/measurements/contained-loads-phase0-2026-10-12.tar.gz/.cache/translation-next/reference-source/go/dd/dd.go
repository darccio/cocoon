// Package dd is a Cocoon facade over a slice of libdatadog: SQL and trace
// obfuscation (libdd-trace-obfuscation, libdd-trace-utils) and DDSketch
// (libdd-ddsketch), compiled to wasm32 and translated to Go by wasm2go.
// It is pure Go: CGO_ENABLED=0, any GOOS/GOARCH.
package dd

import (
	"context"
	"encoding/binary"
	"fmt"
	"log/slog"
	"math"
	"runtime"
	"sync"

	"cocoon.dev/cocoon/internal/ddwasm"
	"cocoon.dev/cocoon/rt"
)

// ABIVersion is the Cocoon ABI this package was generated against.
const ABIVersion = 2

// Options configures a Library.
type Options struct {
	// Instances bounds concurrent guest instances. Default GOMAXPROCS.
	Instances int
	// MaxInput rejects larger inputs before they reach the guest. Default 64 MiB.
	MaxInput int
	// MaxGuestMemory discards instances whose linear memory grew past it. Default 256 MiB.
	MaxGuestMemory int
	// Logger receives guest log lines and panic messages.
	Logger *slog.Logger
}

func (o *Options) defaults() {
	if o.Instances <= 0 {
		o.Instances = runtime.GOMAXPROCS(0)
	}
	if o.MaxInput <= 0 {
		o.MaxInput = 64 << 20
	}
	if o.MaxGuestMemory <= 0 {
		o.MaxGuestMemory = 256 << 20
	}
}

// hostAdapter maps the imports wasm2go generated (interface Xcocoon) onto rt.Host.
type hostAdapter struct{ h *rt.Host }

func (a hostAdapter) Xlog(level, ptr, n int32)       { a.h.Log(level, uint32(ptr), uint32(n)) }
func (a hostAdapter) Xrandom_get(ptr, n int32) int32 { return a.h.RandomGet(uint32(ptr), uint32(n)) }

type inst = rt.Instance[*ddwasm.Module]

func newInst(logger *slog.Logger) (*inst, error) {
	h := rt.NewHost(logger)
	mod := ddwasm.New(hostAdapter{h})
	mem := mod.Xmemory().Slice()
	w := rt.NewInstance(mod, h, func() []byte { return *mem })
	var v, out int32
	if err := w.Call("init", func() {
		v = mod.Xcocoon_abi_version()
		mod.Xcocoon_init()
		out = mod.Xcocoon_out()
	}); err != nil {
		return nil, err
	}
	if v != ABIVersion {
		return nil, fmt.Errorf("%w: guest %d, facade %d", rt.ErrABI, v, ABIVersion)
	}
	w.Wire(mod.Xcocoon_in_reserve, out)
	return w, nil
}

// Library is safe for concurrent use. Stateless calls run on a bounded pool
// of instances; sketches live on one "home" instance.
type Library struct {
	opt  Options
	pool *rt.Pool[inst]

	homeMu sync.Mutex // guards home and serialises stateful calls
	home   *inst
}

// Open creates a Library. Instances are built lazily, on first use.
func Open(opt Options) (*Library, error) {
	opt.defaults()
	l := &Library{opt: opt}
	l.pool = rt.NewPool(opt.Instances,
		func() (*inst, error) { return newInst(opt.Logger) },
		func(w *inst) bool { return w.Usable() && w.MemSize() <= opt.MaxGuestMemory })
	// Fail fast if the module cannot even initialise.
	if err := l.pool.Do(context.Background(), func(*inst) error { return nil }); err != nil {
		return nil, err
	}
	return l, nil
}

// Close releases the home instance. Outstanding sketches become invalid.
func (l *Library) Close() error {
	l.homeMu.Lock()
	defer l.homeMu.Unlock()
	if l.home != nil {
		l.home.Close()
	}
	return nil
}

// ObfuscateSQL replaces literals in a SQL query, as the Datadog agent does.
func (l *Library) ObfuscateSQL(ctx context.Context, query string) (string, error) {
	if len(query) > l.opt.MaxInput {
		return "", rt.ErrTooLarge
	}
	var out string
	err := l.pool.Do(ctx, func(w *inst) error {
		p, err := w.PutString("ObfuscateSQL", query)
		if err != nil {
			return err
		}
		var st int32
		if err := w.Call("ObfuscateSQL", func() { st = w.Mod.Xcocoon_sql_obfuscate(p, int32(len(query))) }); err != nil {
			return err
		}
		out, err = w.ResultString("ObfuscateSQL", st)
		return err
	})
	return out, err
}

// ObfuscateTraces decodes a v0.4 msgpack trace payload, obfuscates every span
// with the default configuration and returns the re-encoded payload.
// Batching many spans into one call amortises the boundary crossing.
func (l *Library) ObfuscateTraces(ctx context.Context, payload []byte) ([]byte, error) {
	if len(payload) > l.opt.MaxInput {
		return nil, rt.ErrTooLarge
	}
	var out []byte
	err := l.pool.Do(ctx, func(w *inst) error {
		p, err := w.PutBytes("ObfuscateTraces", payload)
		if err != nil {
			return err
		}
		var st int32
		if err := w.Call("ObfuscateTraces", func() { st = w.Mod.Xcocoon_traces_obfuscate(p, int32(len(payload))) }); err != nil {
			return err
		}
		out, err = w.Result("ObfuscateTraces", st)
		return err
	})
	return out, err
}

// homeInst returns the instance that owns stateful objects, replacing it if
// an earlier fault poisoned it. Callers hold homeMu.
func (l *Library) homeInst() (*inst, error) {
	if l.home != nil && l.home.Usable() {
		return l.home, nil
	}
	w, err := newInst(l.opt.Logger)
	if err != nil {
		return nil, err
	}
	l.home = w
	return w, nil
}

// Sketch is a DDSketch living inside the library. Close it when done; a
// cleanup frees it if it becomes unreachable first.
type Sketch struct {
	ref *sketchRef
	c   runtime.Cleanup
}

type sketchRef struct {
	l     *Library
	inst  *inst // instance affinity: the handle is only meaningful there
	h     int64
	freed bool
}

// NewSketch creates an empty DDSketch.
func (l *Library) NewSketch() (*Sketch, error) {
	l.homeMu.Lock()
	defer l.homeMu.Unlock()
	w, err := l.homeInst()
	if err != nil {
		return nil, err
	}
	var h int64
	if err := w.Call("NewSketch", func() { h = w.Mod.Xcocoon_sketch_new() }); err != nil {
		return nil, err
	}
	s := &Sketch{ref: &sketchRef{l: l, inst: w, h: h}}
	s.c = runtime.AddCleanup(s, func(r *sketchRef) { _ = r.free() }, s.ref)
	return s, nil
}

// with runs fn on the sketch's own instance, after checking the handle is still live there.
func (r *sketchRef) with(op string, fn func(w *inst) error) error {
	r.l.homeMu.Lock()
	defer r.l.homeMu.Unlock()
	switch {
	case r.freed:
		return &rt.HandleError{Op: op, Reason: "already freed"}
	case !r.inst.Usable():
		return &rt.HandleError{Op: op, Reason: "owning instance was poisoned or closed"}
	}
	return fn(r.inst)
}

// Add inserts one value. Prefer AddMany for more than a handful of values:
// each call crosses the boundary once.
func (s *Sketch) Add(v float64) error {
	return s.ref.with("Sketch.Add", func(w *inst) error {
		var st int32
		if err := w.Call("Sketch.Add", func() { st = w.Mod.Xcocoon_sketch_add(s.ref.h, v) }); err != nil {
			return err
		}
		return rt.FromStatus("Sketch.Add", rt.Status(st), []byte("rejected value"))
	})
}

// AddMany inserts all values in one boundary crossing.
func (s *Sketch) AddMany(vs []float64) error {
	return s.ref.with("Sketch.AddMany", func(w *inst) error {
		buf, p, err := w.InputView("Sketch.AddMany", 8*len(vs))
		if err != nil {
			return err
		}
		for i, v := range vs {
			binary.LittleEndian.PutUint64(buf[8*i:], math.Float64bits(v))
		}
		var st int32
		if err := w.Call("Sketch.AddMany", func() { st = w.Mod.Xcocoon_sketch_add_many(s.ref.h, p, int32(len(buf))) }); err != nil {
			return err
		}
		_, err = w.Result("Sketch.AddMany", st)
		return err
	})
}

// Count returns the number of values added.
func (s *Sketch) Count() (float64, error) {
	var c float64
	err := s.ref.with("Sketch.Count", func(w *inst) error {
		return w.Call("Sketch.Count", func() { c = w.Mod.Xcocoon_sketch_count(s.ref.h) })
	})
	return c, err
}

// Encode returns the sketch as a protobuf DDSketch.
func (s *Sketch) Encode() ([]byte, error) {
	var out []byte
	err := s.ref.with("Sketch.Encode", func(w *inst) error {
		var st int32
		if err := w.Call("Sketch.Encode", func() { st = w.Mod.Xcocoon_sketch_encode(s.ref.h) }); err != nil {
			return err
		}
		var err error
		out, err = w.Result("Sketch.Encode", st)
		return err
	})
	return out, err
}

// Close frees the sketch. Calling it twice returns a HandleError.
func (s *Sketch) Close() error {
	s.c.Stop()
	return s.ref.free()
}

func (r *sketchRef) free() error {
	return r.with("Sketch.Close", func(w *inst) error {
		var st int32
		if err := w.Call("Sketch.Close", func() { st = w.Mod.Xcocoon_sketch_free(r.h) }); err != nil {
			return err
		}
		r.freed = true
		return rt.FromStatus("Sketch.Close", rt.Status(st), []byte("unknown handle"))
	})
}

// testPanic and poisonHome are test hooks for fault handling.
func (l *Library) testPanic(code int32) error {
	return l.pool.Do(context.Background(), func(w *inst) error {
		return w.Call("testPanic", func() { w.Mod.Xcocoon_test_panic(code) })
	})
}

func (l *Library) poisonHome() error {
	l.homeMu.Lock()
	defer l.homeMu.Unlock()
	w, err := l.homeInst()
	if err != nil {
		return err
	}
	return w.Call("testPanic", func() { w.Mod.Xcocoon_test_panic(1) })
}
