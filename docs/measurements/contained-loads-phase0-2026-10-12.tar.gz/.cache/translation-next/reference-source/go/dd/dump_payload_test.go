package dd

import (
	"cocoon.dev/cocoon/internal/testpayload"
	"os"
	"testing"
)

func TestDumpPayload(t *testing.T) {
	if p := os.Getenv("COCOON_DUMP_PAYLOAD"); p != "" {
		os.WriteFile(p, testpayload.Traces(20, 50), 0o644)
	}
}
