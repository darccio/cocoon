// Package testpayload builds v0.4 msgpack trace payloads for tests and benchmarks.
package testpayload

import (
	"encoding/binary"
	"fmt"
	"math"
)

// A minimal msgpack writer, enough to build v0.4 trace payloads in tests.
type mp struct{ b []byte }

func (m *mp) arr(n int) *mp {
	if n < 16 {
		m.b = append(m.b, 0x90|byte(n))
	} else {
		m.b = append(m.b, 0xdc, byte(n>>8), byte(n))
	}
	return m
}

func (m *mp) mapH(n int) *mp {
	if n < 16 {
		m.b = append(m.b, 0x80|byte(n))
	} else {
		m.b = append(m.b, 0xde, byte(n>>8), byte(n))
	}
	return m
}

func (m *mp) str(s string) *mp {
	switch n := len(s); {
	case n < 32:
		m.b = append(m.b, 0xa0|byte(n))
	case n < 256:
		m.b = append(m.b, 0xd9, byte(n))
	default:
		m.b = append(m.b, 0xda, byte(n>>8), byte(n))
	}
	m.b = append(m.b, s...)
	return m
}

func (m *mp) u64(v uint64) *mp {
	m.b = append(m.b, 0xcf)
	m.b = binary.BigEndian.AppendUint64(m.b, v)
	return m
}

func (m *mp) i64(v int64) *mp {
	m.b = append(m.b, 0xd3)
	m.b = binary.BigEndian.AppendUint64(m.b, uint64(v))
	return m
}

func (m *mp) f64(v float64) *mp {
	m.b = append(m.b, 0xcb)
	m.b = binary.BigEndian.AppendUint64(m.b, math.Float64bits(v))
	return m
}

type testSpan struct {
	service, name, resource, typ string
	traceID, spanID, parentID    uint64
	meta                         map[string]string
}

// Traces builds `traces` traces of `spans` spans, alternating SQL, Redis and HTTP spans.
func Traces(traces, spans int) []byte {
	m := &mp{}
	m.arr(traces)
	for t := 0; t < traces; t++ {
		m.arr(spans)
		for s := 0; s < spans; s++ {
			sp := testSpan{service: "checkout", traceID: uint64(t + 1), spanID: uint64(s + 1)}
			switch s % 3 {
			case 0:
				sp.name, sp.typ = "postgres.query", "sql"
				sp.resource = fmt.Sprintf("SELECT * FROM orders WHERE id = %d AND email = 'user%d@example.com'", 1000+s, s)
			case 1:
				sp.name, sp.typ = "redis.command", "redis"
				sp.resource = "SET"
				sp.meta = map[string]string{"redis.raw_command": fmt.Sprintf("SET session:%d secret-token-%d", s, s)}
			default:
				sp.name, sp.typ = "http.request", "http"
				sp.resource = "GET /orders"
				sp.meta = map[string]string{"http.url": fmt.Sprintf("https://api.example.com/orders/%d?token=abc%d", s, s)}
			}
			if s > 0 {
				sp.parentID = 1
			}
			writeSpan(m, sp)
		}
	}
	return m.b
}

func writeSpan(m *mp, s testSpan) {
	m.mapH(10)
	m.str("service").str(s.service)
	m.str("name").str(s.name)
	m.str("resource").str(s.resource)
	m.str("type").str(s.typ)
	m.str("trace_id").u64(s.traceID)
	m.str("span_id").u64(s.spanID)
	m.str("parent_id").u64(s.parentID)
	m.str("start").i64(1_700_000_000_000_000_000)
	m.str("duration").i64(1_500_000)
	m.str("meta").mapH(len(s.meta))
	for k, v := range s.meta {
		m.str(k).str(v)
	}
}
