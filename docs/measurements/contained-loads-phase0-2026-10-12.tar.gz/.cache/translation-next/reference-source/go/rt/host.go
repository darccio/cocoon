package rt

import (
	"context"
	"crypto/rand"
	"log/slog"
	"time"
)

// Host implements the services a guest imports. Guests never touch the OS;
// anything effectful (logging, randomness, clocks, and in the full design
// HTTP, sleep and file access via libdd-capabilities) is a Go function.
//
// Host methods run on the goroutine that called into the guest, while the
// guest is suspended inside the call. They must copy anything they read from
// guest memory before returning, must not call back into the guest
// (no re-entry in ABI v1), and must not block indefinitely.
type Host struct {
	Logger *slog.Logger
	// Now is the wall clock offered to the guest (overridable in tests).
	Now func() time.Time

	mem       func() []byte
	lastPanic string
}

// NewHost returns a Host logging to logger (slog.Default when nil).
func NewHost(logger *slog.Logger) *Host {
	if logger == nil {
		logger = slog.Default()
	}
	return &Host{Logger: logger, Now: time.Now}
}

type hostPanic struct{ value any }

// takePanic returns and clears the panic message the guest reported, if any.
func (h *Host) takePanic() string {
	m := h.lastPanic
	h.lastPanic = ""
	return m
}

// shield converts a panic in a host import into a typed value the instance
// guard reports as HostError rather than as a guest fault.
func shield() {
	if r := recover(); r != nil {
		panic(&hostPanic{value: r})
	}
}

func (h *Host) view(ptr, n uint32) ([]byte, bool) {
	mem := h.mem()
	end := uint64(ptr) + uint64(n)
	if end > uint64(len(mem)) {
		return nil, false
	}
	return mem[ptr:end:end], true
}

// Copy returns a Go-owned copy of guest memory [ptr, ptr+n).
func (h *Host) Copy(ptr, n uint32) ([]byte, bool) {
	b, ok := h.view(ptr, n)
	if !ok {
		return nil, false
	}
	return append([]byte(nil), b...), true
}

// Log receives a UTF-8 message from the guest. Level 4 is the panic hook:
// the message is kept so the fault that follows can carry it.
func (h *Host) Log(level int32, ptr, n uint32) {
	defer shield()
	b, ok := h.view(ptr, n)
	if !ok {
		return
	}
	msg := string(b) // copy: the guest buffer dies after we return
	if level == 4 {
		h.lastPanic = msg
	}
	h.Logger.Log(context.Background(), slogLevel(level), msg, "source", "guest")
}

// RandomGet fills guest memory from crypto/rand (getrandom's Cocoon backend).
func (h *Host) RandomGet(ptr, n uint32) int32 {
	defer shield()
	b, ok := h.view(ptr, n)
	if !ok {
		return 1
	}
	if _, err := rand.Read(b); err != nil {
		return 1
	}
	return 0
}

// ClockNanos returns Unix nanoseconds (for guests built with a clock import).
func (h *Host) ClockNanos() int64 {
	defer shield()
	return h.Now().UnixNano()
}

func slogLevel(l int32) slog.Level {
	switch l {
	case 0, 1:
		return slog.LevelDebug
	case 2:
		return slog.LevelInfo
	case 3:
		return slog.LevelWarn
	default:
		return slog.LevelError
	}
}
