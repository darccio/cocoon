// Package rt is the Go half of Cocoon: the error taxonomy, the Cocoon ABI fast
// path over guest memory, instance lifecycle (poisoning, bounded pools), host
// services and the event loop for async guests. Facade packages such as
// cocoon/dd and cocoon/pipeline are thin layers over it and the module that
// wasm2go generated from the Rust shim.
package rt

import (
	"errors"
	"fmt"
)

// Status is the i32 every Cocoon ABI export returns.
type Status int32

const (
	OK        Status = 0
	ErrApp    Status = 1 // expected failure; message in the output buffer
	ErrArg    Status = 2 // invalid argument (bad UTF-8, null with length)
	ErrHandle Status = 3 // unknown, stale or double-freed handle
	Pending   Status = 4 // async call not finished yet
)

// AppError is an expected failure reported by the library (status ErrApp/ErrArg).
type AppError struct {
	Status Status
	Op     string
	Msg    string
}

func (e *AppError) Error() string { return fmt.Sprintf("%s: %s", e.Op, e.Msg) }

// HandleError reports a handle the guest did not recognise, or one invalidated
// because its instance was poisoned or closed.
type HandleError struct {
	Op     string
	Reason string
}

func (e *HandleError) Error() string { return fmt.Sprintf("%s: invalid handle (%s)", e.Op, e.Reason) }

// FaultKind classifies a guest execution fault.
type FaultKind int

const (
	FaultUnreachable  FaultKind = iota // wasm unreachable: Rust panic=abort, alloc failure, real unreachable
	FaultMemory                        // out-of-bounds guest memory access
	FaultIndirectCall                  // call_indirect signature mismatch / null table entry
	FaultArithmetic                    // integer divide by zero, overflow in conversion
)

func (k FaultKind) String() string {
	return [...]string{"unreachable", "memory", "indirect-call", "arithmetic"}[k]
}

// FaultError is a guest execution fault. The instance that raised it is
// poisoned: no further guest code runs on it and its handles are invalid.
type FaultError struct {
	Op       string
	Kind     FaultKind
	Detail   string // runtime error text or panic value
	GuestMsg string // last panic message the guest reported through the host log, if any
}

func (e *FaultError) Error() string {
	s := fmt.Sprintf("%s: guest fault (%s)", e.Op, e.Kind)
	if e.GuestMsg != "" {
		s += ": " + e.GuestMsg
	} else if e.Detail != "" {
		s += ": " + e.Detail
	}
	return s
}

// HostError wraps a panic raised by a Go host import while the guest was
// running. It is a bug on the Go side, so it is reported separately from
// guest faults; the instance is still poisoned because guest state is unknown.
type HostError struct {
	Op    string
	Value any
}

func (e *HostError) Error() string { return fmt.Sprintf("%s: host import panicked: %v", e.Op, e.Value) }

var (
	ErrPoisoned = errors.New("cocoon: instance poisoned by an earlier fault")
	ErrClosed   = errors.New("cocoon: instance closed")
	ErrTooLarge = errors.New("cocoon: input exceeds configured maximum")
	ErrABI      = errors.New("cocoon: ABI version mismatch")
)

// FromStatus converts a non-OK status plus message into an error.
func FromStatus(op string, st Status, msg []byte) error {
	switch st {
	case OK:
		return nil
	case ErrHandle:
		return &HandleError{Op: op, Reason: string(msg)}
	default:
		return &AppError{Status: st, Op: op, Msg: string(msg)}
	}
}
