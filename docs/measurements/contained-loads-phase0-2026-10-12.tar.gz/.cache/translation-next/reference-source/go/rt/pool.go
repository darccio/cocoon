package rt

import (
	"context"
)

// Pool bounds the number of live instances and reuses healthy ones.
//
// It is admission control, not a cache: at most Size instances exist, a
// caller waits (honouring ctx) when all are busy, and an instance that is
// poisoned or has outgrown its memory budget is dropped and its slot handed
// to the next caller, which builds a fresh one. Each Do is two channel
// operations; instances are created lazily.
type Pool[T any] struct {
	newFn   func() (*T, error)
	healthy func(*T) bool
	slots   chan *T // nil entries are free slots without an instance yet
}

// NewPool creates a pool of at most size instances.
func NewPool[T any](size int, newFn func() (*T, error), healthy func(*T) bool) *Pool[T] {
	if size < 1 {
		size = 1
	}
	p := &Pool[T]{newFn: newFn, healthy: healthy, slots: make(chan *T, size)}
	for range size {
		p.slots <- nil
	}
	return p
}

// Do runs fn with exclusive use of one instance.
// ctx only bounds the wait for an instance: translated guest code cannot be
// interrupted once it is running.
func (p *Pool[T]) Do(ctx context.Context, fn func(*T) error) error {
	var t *T
	select {
	case t = <-p.slots:
	default:
		select {
		case t = <-p.slots:
		case <-ctx.Done():
			return ctx.Err()
		}
	}
	if t == nil {
		var err error
		if t, err = p.newFn(); err != nil {
			p.slots <- nil
			return err
		}
	}
	err := fn(t)
	if p.healthy(t) {
		p.slots <- t
	} else {
		p.slots <- nil
	}
	return err
}
