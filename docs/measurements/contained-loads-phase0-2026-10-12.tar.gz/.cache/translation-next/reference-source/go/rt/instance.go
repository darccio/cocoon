package rt

import (
	"encoding/binary"
	"fmt"
	"runtime"
	"strings"
	"sync"
	"sync/atomic"
)

var epochs atomic.Uint64

// Instance owns one guest module instance (wasm2go-generated code).
//
// Rules it enforces:
//   - one goroutine at a time (the guest is single-threaded);
//   - every guest-memory range is checked against the logical memory length
//     (len, never cap) with overflow-safe arithmetic;
//   - the memory slice is re-read on every access, because the guest may
//     have grown (and so reallocated) it;
//   - after a fault the instance is poisoned: no guest code runs on it
//     again and every handle minted by it is invalid.
//
// It also implements the Cocoon ABI v2 fast path: inputs go into a cached,
// grow-only guest buffer and outputs are read from a fixed descriptor, so a
// typical call is a single guest entry.
type Instance[M any] struct {
	Mod  M
	Host *Host

	mu       sync.Mutex
	mem      func() []byte
	poisoned bool
	closed   bool
	epoch    uint64

	reserve func(int32) int32 // cocoon_in_reserve
	outDesc uint32            // address of the OutBuf descriptor (cocoon_out)
	inPtr   uint32            // cached input buffer address
	inCap   uint32            // its reserved size
}

// NewInstance wraps a module. mem must return the module's current memory.
func NewInstance[M any](mod M, host *Host, mem func() []byte) *Instance[M] {
	in := &Instance[M]{Mod: mod, Host: host, mem: mem, epoch: epochs.Add(1)}
	host.mem = mem
	return in
}

// Wire connects the ABI fast path: reserve is the module's cocoon_in_reserve,
// out is the address returned by its cocoon_out.
func (in *Instance[M]) Wire(reserve func(int32) int32, out int32) {
	in.reserve, in.outDesc = reserve, uint32(out)
}

func (in *Instance[M]) Lock()   { in.mu.Lock() }
func (in *Instance[M]) Unlock() { in.mu.Unlock() }

// Epoch identifies this instance; handles record it to detect reuse after replacement.
func (in *Instance[M]) Epoch() uint64 { return in.epoch }

// Usable reports whether guest code may still run on this instance.
func (in *Instance[M]) Usable() bool { return !in.poisoned && !in.closed }

func (in *Instance[M]) Poisoned() bool { return in.poisoned }

// Close marks the instance closed. Guest memory is released with the module.
func (in *Instance[M]) Close() { in.closed = true }

// MemSize is the current logical guest memory size in bytes.
func (in *Instance[M]) MemSize() int { return len(in.mem()) }

// ForgetInput drops the cached input buffer (after cocoon_trim).
func (in *Instance[M]) ForgetInput() { in.inPtr, in.inCap = 0, 0 }

// Call runs fn, which must contain only generated guest call(s), and converts
// guest faults into errors. The caller must hold the lock.
func (in *Instance[M]) Call(op string, fn func()) (err error) {
	if in.poisoned || in.closed {
		if in.closed {
			return ErrClosed
		}
		return ErrPoisoned
	}
	defer func() {
		if r := recover(); r != nil {
			in.poisoned = true
			err = classify(op, r, in.Host.takePanic())
		}
	}()
	fn()
	return nil
}

func classify(op string, r any, guestMsg string) error {
	switch v := r.(type) {
	case *hostPanic:
		return &HostError{Op: op, Value: v.value}
	case string:
		if v == "unreachable" {
			return &FaultError{Op: op, Kind: FaultUnreachable, Detail: v, GuestMsg: guestMsg}
		}
	case runtime.Error:
		msg := v.Error()
		switch {
		case strings.Contains(msg, "index out of range"), strings.Contains(msg, "slice bounds out of range"):
			return &FaultError{Op: op, Kind: FaultMemory, Detail: msg, GuestMsg: guestMsg}
		case strings.Contains(msg, "interface conversion"):
			return &FaultError{Op: op, Kind: FaultIndirectCall, Detail: msg, GuestMsg: guestMsg}
		case strings.Contains(msg, "divide by zero"):
			return &FaultError{Op: op, Kind: FaultArithmetic, Detail: msg, GuestMsg: guestMsg}
		}
	}
	// Anything else is not a recognised guest trap: do not hide it.
	panic(fmt.Sprintf("cocoon: unexpected panic in %s (instance poisoned): %v", op, r))
}

// --- ABI fast path ----------------------------------------------------------

// inputBuf returns a guest buffer of at least n bytes, growing the cached one
// (one extra guest call) only when it is too small.
func (in *Instance[M]) inputBuf(op string, n int) ([]byte, uint32, error) {
	if uint64(n) > 1<<31-1 {
		return nil, 0, ErrTooLarge
	}
	if uint32(n) > in.inCap || in.inPtr == 0 {
		want := max(n, 2*int(in.inCap), 4096)
		if want > 1<<31-1 {
			want = n
		}
		var p int32
		if err := in.Call(op, func() { p = in.reserve(int32(want)) }); err != nil {
			return nil, 0, err
		}
		in.inPtr, in.inCap = uint32(p), uint32(want)
	}
	b, ok := in.Range(in.inPtr, uint32(n))
	if !ok {
		in.poisoned = true
		return nil, 0, fmt.Errorf("%s: guest input buffer outside memory", op)
	}
	return b, in.inPtr, nil
}

// PutBytes copies b into the guest input buffer and returns its address.
func (in *Instance[M]) PutBytes(op string, b []byte) (int32, error) {
	dst, p, err := in.inputBuf(op, len(b))
	if err != nil {
		return 0, err
	}
	copy(dst, b)
	return int32(p), nil
}

// PutString is PutBytes for a string, without converting it first.
func (in *Instance[M]) PutString(op string, s string) (int32, error) {
	dst, p, err := in.inputBuf(op, len(s))
	if err != nil {
		return 0, err
	}
	copy(dst, s)
	return int32(p), nil
}

// InputView returns n writable bytes of the guest input buffer, for callers
// that encode directly into guest memory (e.g. a []float64 batch).
func (in *Instance[M]) InputView(op string, n int) ([]byte, int32, error) {
	b, p, err := in.inputBuf(op, n)
	return b, int32(p), err
}

// OutView returns the bytes the last call published at cocoon_out, without
// copying. They are valid only until the next guest call; copy them first.
func (in *Instance[M]) OutView(op string) ([]byte, error) {
	d, ok := in.Range(in.outDesc, 8)
	if !ok {
		in.poisoned = true
		return nil, fmt.Errorf("%s: output descriptor outside memory", op)
	}
	p, n := binary.LittleEndian.Uint32(d), binary.LittleEndian.Uint32(d[4:])
	b, ok := in.Range(p, n)
	if !ok {
		in.poisoned = true
		return nil, fmt.Errorf("%s: output [%d,+%d) outside memory of %d bytes", op, p, n, in.MemSize())
	}
	return b, nil
}

// Result turns a status into an error (with the published message), or
// returns a Go-owned copy of the published output.
func (in *Instance[M]) Result(op string, st int32) ([]byte, error) {
	b, err := in.OutView(op)
	if err != nil {
		return nil, err
	}
	if Status(st) != OK {
		return nil, FromStatus(op, Status(st), b)
	}
	return append([]byte(nil), b...), nil
}

// ResultString is Result for text outputs: one copy, straight into a string.
func (in *Instance[M]) ResultString(op string, st int32) (string, error) {
	b, err := in.OutView(op)
	if err != nil {
		return "", err
	}
	if Status(st) != OK {
		return "", FromStatus(op, Status(st), b)
	}
	return string(b), nil
}

// --- guest memory views -----------------------------------------------------

// Range returns mem[ptr:ptr+n] with cap clipped, after checking the range
// against the logical length. It never panics.
func (in *Instance[M]) Range(ptr, n uint32) ([]byte, bool) {
	mem := in.mem()
	end := uint64(ptr) + uint64(n)
	if end > uint64(len(mem)) {
		return nil, false
	}
	return mem[ptr:end:end], true
}

// Read copies n bytes out of guest memory.
func (in *Instance[M]) Read(ptr, n uint32) ([]byte, error) {
	b, ok := in.Range(ptr, n)
	if !ok {
		return nil, fmt.Errorf("cocoon: guest range [%d,+%d) outside memory of %d bytes", ptr, n, in.MemSize())
	}
	return append([]byte(nil), b...), nil
}

// Write copies b into guest memory at ptr.
func (in *Instance[M]) Write(ptr uint32, b []byte) error {
	if uint64(len(b)) > 1<<32-1 {
		return ErrTooLarge
	}
	dst, ok := in.Range(ptr, uint32(len(b)))
	if !ok {
		return fmt.Errorf("cocoon: guest range [%d,+%d) outside memory of %d bytes", ptr, len(b), in.MemSize())
	}
	copy(dst, b)
	return nil
}
