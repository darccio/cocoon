package rt

import (
	"context"
	"sync"
)

// Completion is the result of a host operation, delivered back to the guest.
type Completion struct {
	Op     int32
	Status int32
	Data   []byte
}

// CallResult is the outcome of a guest async call.
type CallResult struct {
	Status Status
	Out    []byte
	Err    error // fault or poisoning; Status is meaningless when set
}

// GuestLoop is the guest surface the event loop needs. Implementations call
// generated exports; every method runs with the loop's lock held.
type GuestLoop interface {
	// Deliver passes one completion to the guest (cocoon_complete).
	Deliver(c Completion) error
	// Poll runs ready guest tasks until stalled (cocoon_poll).
	Poll() error
	// Take returns Pending or the finished call's status and output (cocoon_call_take).
	Take(id int32) (Status, []byte, error)
}

// Loop is the Go side of a guest's async runtime, the counterpart of a JS
// event loop. Guest tasks run only inside Poll, under the lock. Host
// operations the guest starts run on goroutines and come back as completions
// on Done; a single pump goroutine delivers them, polls the guest again and
// wakes callers whose calls have finished. Host imports never call exports,
// so there is no re-entry.
type Loop struct {
	mu      sync.Mutex
	g       GuestLoop
	done    chan Completion
	waiters map[int32]chan CallResult
	err     error // sticky: set once the guest faults
	stop    chan struct{}
	stopped sync.WaitGroup
}

// NewLoop starts the pump. backlog bounds completions queued between polls.
func NewLoop(g GuestLoop, backlog int) *Loop {
	l := &Loop{g: g, done: make(chan Completion, backlog), waiters: map[int32]chan CallResult{}, stop: make(chan struct{})}
	l.stopped.Add(1)
	go l.pump()
	return l
}

// Complete is called by host-op goroutines. It never blocks the guest.
func (l *Loop) Complete(c Completion) {
	select {
	case l.done <- c:
	case <-l.stop:
	}
}

// Lock/Unlock expose the loop lock for synchronous guest calls.
func (l *Loop) Lock()   { l.mu.Lock() }
func (l *Loop) Unlock() { l.mu.Unlock() }

// Err is the sticky fault, if any.
func (l *Loop) Err() error { l.mu.Lock(); defer l.mu.Unlock(); return l.err }

// Call starts an async guest call with start (under the lock), polls, and
// waits for its result. ctx bounds the wait only: the guest call keeps
// running and its result is discarded if ctx ends first.
func (l *Loop) Call(ctx context.Context, start func() (int32, error)) CallResult {
	l.mu.Lock()
	if l.err != nil {
		l.mu.Unlock()
		return CallResult{Err: l.err}
	}
	id, err := start()
	if err == nil {
		err = l.g.Poll()
	}
	var r CallResult
	if err == nil {
		r.Status, r.Out, err = l.g.Take(id)
	}
	if err != nil {
		l.fail(err)
		l.mu.Unlock()
		return CallResult{Err: err}
	}
	if r.Status != Pending {
		l.mu.Unlock()
		return r
	}
	ch := make(chan CallResult, 1)
	l.waiters[id] = ch
	l.mu.Unlock()
	select {
	case r := <-ch:
		return r
	case <-ctx.Done():
		return CallResult{Err: ctx.Err()}
	}
}

func (l *Loop) pump() {
	defer l.stopped.Done()
	for {
		var c Completion
		select {
		case c = <-l.done:
		case <-l.stop:
			return
		}
		l.mu.Lock()
		err := l.g.Deliver(c)
		for err == nil && len(l.done) > 0 { // batch whatever else arrived
			err = l.g.Deliver(<-l.done)
		}
		if err == nil {
			err = l.g.Poll()
		}
		for id, ch := range l.waiters {
			if err != nil {
				break
			}
			var r CallResult
			r.Status, r.Out, err = l.g.Take(id)
			if err == nil && r.Status != Pending {
				ch <- r
				delete(l.waiters, id)
			}
		}
		if err != nil {
			l.fail(err)
			l.mu.Unlock()
			return
		}
		l.mu.Unlock()
	}
}

// fail records a fault and releases every waiter. Caller holds the lock.
func (l *Loop) fail(err error) {
	if l.err == nil {
		l.err = err
	}
	for id, ch := range l.waiters {
		ch <- CallResult{Err: l.err}
		delete(l.waiters, id)
	}
}

// Close stops the pump. In-flight host operations are abandoned.
func (l *Loop) Close() {
	l.mu.Lock()
	if l.err == nil {
		l.err = ErrClosed
	}
	l.fail(ErrClosed)
	l.mu.Unlock()
	select {
	case <-l.stop:
	default:
		close(l.stop)
	}
	l.stopped.Wait()
}
