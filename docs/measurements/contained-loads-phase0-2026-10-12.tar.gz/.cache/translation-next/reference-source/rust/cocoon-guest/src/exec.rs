//! Single-threaded executor driven by the Go host, host operations, async calls.

use std::cell::RefCell;
use std::collections::{HashMap, VecDeque};
use std::future::Future;
use std::pin::Pin;
use std::sync::{Arc, Mutex};
use std::task::{Context, Poll, Wake, Waker};

use crate::{CallResult, ERR_HANDLE, PENDING, adopt, host, reply};

type Task = Pin<Box<dyn Future<Output = ()>>>;

thread_local! {
    static TASKS: RefCell<Vec<Option<Task>>> = const { RefCell::new(Vec::new()) };
    static FREE: RefCell<Vec<usize>> = const { RefCell::new(Vec::new()) };
}
static READY: Mutex<VecDeque<usize>> = Mutex::new(VecDeque::new());

struct TaskWaker(usize);
impl Wake for TaskWaker {
    fn wake(self: Arc<Self>) {
        READY.lock().unwrap().push_back(self.0);
    }
}

/// Spawns a future on the host-driven executor.
pub fn spawn<F: Future<Output = ()> + 'static>(f: F) {
    let id = TASKS.with(|t| {
        let mut t = t.borrow_mut();
        match FREE.with(|f| f.borrow_mut().pop()) {
            Some(i) => {
                t[i] = Some(Box::pin(f));
                i
            }
            None => {
                t.push(Some(Box::pin(f)));
                t.len() - 1
            }
        }
    });
    READY.lock().unwrap().push_back(id);
}

/// Runs every ready task until none is ready. Returns the number of live tasks.
#[unsafe(no_mangle)]
pub extern "C" fn cocoon_poll() -> u32 {
    loop {
        let Some(id) = READY.lock().unwrap().pop_front() else { break };
        let Some(mut task) = TASKS.with(|t| t.borrow_mut().get_mut(id).and_then(Option::take)) else {
            continue; // stale wake for a finished task
        };
        let waker = Waker::from(Arc::new(TaskWaker(id)));
        match task.as_mut().poll(&mut Context::from_waker(&waker)) {
            Poll::Pending => TASKS.with(|t| t.borrow_mut()[id] = Some(task)),
            Poll::Ready(()) => FREE.with(|f| f.borrow_mut().push(id)),
        }
    }
    TASKS.with(|t| t.borrow().iter().filter(|s| s.is_some()).count() as u32)
}

enum OpState {
    Waiting(Option<Waker>),
    Done(i32, Vec<u8>),
}

thread_local! {
    static OPS: RefCell<HashMap<u32, OpState>> = RefCell::new(HashMap::new());
}

/// A host operation in flight. Dropping it before completion cancels it on the host.
pub struct HostOp {
    id: u32,
    done: bool,
}

impl HostOp {
    pub fn start(kind: i32, payload: &[u8]) -> HostOp {
        let id = unsafe { host::op_start(kind, payload.as_ptr(), payload.len()) };
        OPS.with(|o| o.borrow_mut().insert(id, OpState::Waiting(None)));
        HostOp { id, done: false }
    }
}

impl Future for HostOp {
    type Output = (i32, Vec<u8>);
    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        let id = self.id;
        let r = OPS.with(|o| {
            let mut o = o.borrow_mut();
            match o.get_mut(&id) {
                Some(OpState::Waiting(w)) => {
                    *w = Some(cx.waker().clone());
                    None
                }
                Some(OpState::Done(..)) => match o.remove(&id) {
                    Some(OpState::Done(st, b)) => Some((st, b)),
                    _ => unreachable!(),
                },
                None => Some((ERR_HANDLE, b"op vanished".to_vec())),
            }
        });
        match r {
            Some(v) => {
                self.done = true;
                Poll::Ready(v)
            }
            None => Poll::Pending,
        }
    }
}

impl Drop for HostOp {
    fn drop(&mut self) {
        if !self.done && OPS.with(|o| o.borrow_mut().remove(&self.id)).is_some() {
            unsafe { host::op_cancel(self.id) }
        }
    }
}

/// Completes a host operation. `ptr/len` came from `cocoon_alloc`; ownership
/// passes to the guest. Unknown (cancelled) ids are dropped.
///
/// # Safety
/// See `adopt`.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn cocoon_complete(id: u32, status: i32, ptr: *mut u8, len: usize) {
    let data = unsafe { adopt(ptr, len) };
    let waker = OPS.with(|o| {
        let mut o = o.borrow_mut();
        match o.get_mut(&id) {
            Some(st @ OpState::Waiting(_)) => match std::mem::replace(st, OpState::Done(status, data)) {
                OpState::Waiting(w) => w,
                _ => None,
            },
            _ => None,
        }
    });
    if let Some(w) = waker {
        w.wake();
    }
}

thread_local! {
    static CALLS: RefCell<HashMap<u32, Option<CallResult>>> = RefCell::new(HashMap::new());
    static NEXT_CALL: RefCell<u32> = const { RefCell::new(1) };
}

/// Spawns `f` as an async call and returns its id for `cocoon_call_take`.
pub fn spawn_call<F: Future<Output = CallResult> + 'static>(f: F) -> u32 {
    let id = NEXT_CALL.with(|n| {
        let mut n = n.borrow_mut();
        let id = *n;
        *n = n.wrapping_add(1).max(1);
        id
    });
    CALLS.with(|c| c.borrow_mut().insert(id, None));
    spawn(async move {
        let r = f.await;
        CALLS.with(|c| c.borrow_mut().insert(id, Some(r)));
    });
    id
}

/// Returns PENDING until the call finished, then its status, with the output
/// published at `cocoon_out()` (once).
#[unsafe(no_mangle)]
pub extern "C" fn cocoon_call_take(id: u32) -> i32 {
    let r = CALLS.with(|c| {
        let mut c = c.borrow_mut();
        match c.get(&id) {
            None => Some(Err((ERR_HANDLE, "unknown call id".to_string()))),
            Some(None) => None,
            Some(Some(_)) => c.remove(&id).flatten(),
        }
    });
    match r {
        None => PENDING,
        Some(r) => reply(r),
    }
}
