//! Guest half of Cocoon: the Rust side of the Cocoon ABI for libraries that
//! are compiled to wasm32 and translated to Go.
//!
//! ABI v2, designed so that a typical call is ONE guest entry:
//!   * Input: the host writes request bytes into a grow-only, per-instance
//!     buffer obtained from `cocoon_in_reserve` (cached by the host; only
//!     re-requested when it must grow) and passes `(ptr, len)` to the export.
//!     Exports borrow it for the call; anything kept past the call is copied.
//!   * Output: an export stores its result in a per-instance retained buffer
//!     and publishes `{ptr, len}` at the fixed address `cocoon_out()`. The
//!     host copies it before its next call; the buffer is reused, never freed
//!     by the host.
//!   * Status: every export returns `i32`: OK, ERR_APP, ERR_ARG, ERR_HANDLE,
//!     or PENDING (async calls). Non-OK statuses carry a UTF-8 message.
//!   * Objects live in `Slab`s and cross as generation-tagged `u64` handles.
//!   * Panics abort (wasm `unreachable`); the hook forwards the message first.
//!   * With the `async` feature: a single-threaded executor driven by the host
//!     (`cocoon_poll`), host operations completed via `cocoon_complete`, and
//!     async calls collected with `cocoon_call_take`. Never re-entrant.

use std::cell::RefCell;
use std::mem::MaybeUninit;

pub const ABI_VERSION: u32 = 2;

pub const OK: i32 = 0;
pub const ERR_APP: i32 = 1;
pub const ERR_ARG: i32 = 2;
pub const ERR_HANDLE: i32 = 3;
pub const PENDING: i32 = 4;

pub type CallResult = Result<Vec<u8>, (i32, String)>;

#[repr(C)]
pub struct OutBuf {
    pub ptr: *const u8,
    pub len: usize,
}

// ------------------------------------------------------------------ memory

thread_local! {
    static INPUT: RefCell<Vec<u8>> = const { RefCell::new(Vec::new()) };
    static OUTPUT: RefCell<Vec<u8>> = const { RefCell::new(Vec::new()) };
}
static mut OUT: OutBuf = OutBuf { ptr: std::ptr::null(), len: 0 };

#[unsafe(no_mangle)]
pub extern "C" fn cocoon_abi_version() -> u32 {
    ABI_VERSION
}

/// Ensures the input buffer holds at least `len` bytes and returns its address.
/// The address stays valid until the next `cocoon_in_reserve` or `cocoon_trim`.
#[unsafe(no_mangle)]
pub extern "C" fn cocoon_in_reserve(len: usize) -> *mut u8 {
    INPUT.with(|b| {
        let mut b = b.borrow_mut();
        if b.len() < len {
            b.resize(len, 0);
        }
        b.as_mut_ptr()
    })
}

/// Address of the output descriptor. Fixed for the lifetime of the instance.
#[unsafe(no_mangle)]
pub extern "C" fn cocoon_out() -> *const OutBuf {
    &raw const OUT
}

/// Drops the input and output buffers if they exceed `keep` bytes.
/// The host must forget its cached input address afterwards.
#[unsafe(no_mangle)]
pub extern "C" fn cocoon_trim(keep: usize) {
    INPUT.with(|b| {
        let mut b = b.borrow_mut();
        if b.capacity() > keep {
            *b = Vec::new();
        }
    });
    OUTPUT.with(|b| {
        let mut b = b.borrow_mut();
        if b.capacity() > keep {
            *b = Vec::new();
        }
    });
    unsafe { (&raw mut OUT).write(OutBuf { ptr: std::ptr::null(), len: 0 }) };
}

/// Allocates `len` bytes for host-to-guest transfers (`cocoon_complete`).
#[unsafe(no_mangle)]
pub extern "C" fn cocoon_alloc(len: usize) -> *mut u8 {
    Box::into_raw(Box::<[u8]>::new_uninit_slice(len)) as *mut u8
}

/// Takes ownership of a buffer the host got from `cocoon_alloc` and filled.
///
/// # Safety
/// `ptr`/`len` must come from `cocoon_alloc`, fully initialised, adopted once.
pub unsafe fn adopt(ptr: *mut u8, len: usize) -> Vec<u8> {
    if ptr.is_null() {
        return Vec::new();
    }
    let raw = std::ptr::slice_from_raw_parts_mut(ptr as *mut MaybeUninit<u8>, len);
    let b = unsafe { Box::from_raw(raw) };
    // SAFETY: the host initialised every byte before handing it over.
    unsafe { b.assume_init() }.into_vec()
}

/// Borrows `(ptr, len)` for the duration of a call.
///
/// # Safety
/// `ptr` must be readable for `len` bytes when `len > 0`.
pub unsafe fn borrow<'a>(ptr: *const u8, len: usize) -> Result<&'a [u8], (i32, String)> {
    if len == 0 {
        return Ok(&[]);
    }
    if ptr.is_null() {
        return Err((ERR_ARG, "null pointer with non-zero length".into()));
    }
    Ok(unsafe { std::slice::from_raw_parts(ptr, len) })
}

/// Borrows `(ptr, len)` as UTF-8.
///
/// # Safety
/// As for `borrow`.
pub unsafe fn borrow_str<'a>(ptr: *const u8, len: usize) -> Result<&'a str, (i32, String)> {
    let b = unsafe { borrow(ptr, len) }?;
    std::str::from_utf8(b).map_err(|e| (ERR_ARG, format!("invalid UTF-8: {e}")))
}

/// Publishes a result in the retained output buffer and returns its status.
pub fn reply(r: CallResult) -> i32 {
    let (st, bytes) = match r {
        Ok(b) => (OK, b),
        Err((st, msg)) => (st, msg.into_bytes()),
    };
    OUTPUT.with(|o| {
        let mut o = o.borrow_mut();
        *o = bytes; // drops the previous output
        unsafe { (&raw mut OUT).write(OutBuf { ptr: o.as_ptr(), len: o.len() }) };
    });
    st
}

/// Like `reply`, but writes the output in place, reusing the buffer's capacity.
pub fn reply_with(f: impl FnOnce(&mut Vec<u8>) -> Result<(), (i32, String)>) -> i32 {
    let r = OUTPUT.with(|o| {
        let mut o = o.borrow_mut();
        o.clear();
        f(&mut o)
    });
    match r {
        Ok(()) => OUTPUT.with(|o| {
            let o = o.borrow();
            unsafe { (&raw mut OUT).write(OutBuf { ptr: o.as_ptr(), len: o.len() }) };
            OK
        }),
        Err(e) => reply(Err(e)),
    }
}

// ------------------------------------------------------------------ handles

struct Slot<T> {
    generation: u32,
    value: Option<T>,
}

/// Objects addressed by generation-tagged `u64` handles. Handle 0 is never valid;
/// stale and double frees return `None`.
pub struct Slab<T> {
    slots: Vec<Slot<T>>,
    free: Vec<u32>,
}

impl<T> Slab<T> {
    pub const fn new() -> Self {
        Self { slots: Vec::new(), free: Vec::new() }
    }
    pub fn insert(&mut self, v: T) -> u64 {
        let idx = match self.free.pop() {
            Some(i) => i,
            None => {
                self.slots.push(Slot { generation: 0, value: None });
                (self.slots.len() - 1) as u32
            }
        };
        let s = &mut self.slots[idx as usize];
        s.generation = s.generation.wrapping_add(1).max(1);
        s.value = Some(v);
        ((s.generation as u64) << 32) | idx as u64
    }
    pub fn get_mut(&mut self, h: u64) -> Option<&mut T> {
        let s = self.slots.get_mut(h as u32 as usize)?;
        if s.generation != (h >> 32) as u32 {
            return None;
        }
        s.value.as_mut()
    }
    pub fn remove(&mut self, h: u64) -> Option<T> {
        self.get_mut(h)?;
        let v = self.slots[h as u32 as usize].value.take();
        self.free.push(h as u32);
        v
    }
}

impl<T> Default for Slab<T> {
    fn default() -> Self {
        Self::new()
    }
}

// ------------------------------------------------------------------ host imports

#[cfg(target_arch = "wasm32")]
mod host {
    #[link(wasm_import_module = "cocoon")]
    unsafe extern "C" {
        pub fn log(level: i32, ptr: *const u8, len: usize);
        #[cfg(feature = "async")]
        pub fn op_start(kind: i32, ptr: *const u8, len: usize) -> u32;
        #[cfg(feature = "async")]
        pub fn op_cancel(id: u32);
    }
}

#[cfg(not(target_arch = "wasm32"))]
mod host {
    pub unsafe fn log(level: i32, ptr: *const u8, len: usize) {
        let msg = unsafe { std::slice::from_raw_parts(ptr, len) };
        eprintln!("[cocoon {level}] {}", String::from_utf8_lossy(msg));
    }
    #[cfg(feature = "async")]
    pub unsafe fn op_start(_: i32, _: *const u8, _: usize) -> u32 {
        unimplemented!("host operations exist only on wasm32")
    }
    #[cfg(feature = "async")]
    pub unsafe fn op_cancel(_: u32) {}
}

pub fn log(level: i32, msg: &str) {
    unsafe { host::log(level, msg.as_ptr(), msg.len()) }
}

/// Installs the panic hook that forwards the message before the abort trap.
#[unsafe(no_mangle)]
pub extern "C" fn cocoon_init() {
    std::panic::set_hook(Box::new(|info| log(4, &info.to_string())));
}

#[cfg(feature = "async")]
mod exec;
#[cfg(feature = "async")]
pub use exec::*;
