//! Cocoon replacement for `wasm-bindgen-futures`: only `spawn_local`, which is
//! all libdatadog's `LocalRuntime` uses. Tasks run when the Go host calls `cocoon_poll`.
use std::future::Future;

pub fn spawn_local<F: Future<Output = ()> + 'static>(future: F) {
    cocoon_guest::spawn(future)
}
