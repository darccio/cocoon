//! Cocoon replacement for getrandom's wasm-bindgen backend.
//! On wasm32-unknown-unknown the bytes come from the Go host (crypto/rand),
//! through one import: cocoon.random_get(ptr, len) -> errno (0 = ok).
use crate::Error;
use core::mem::MaybeUninit;

#[link(wasm_import_module = "cocoon")]
extern "C" {
    fn random_get(ptr: *mut u8, len: usize) -> i32;
}

pub(crate) fn getrandom_inner(dest: &mut [MaybeUninit<u8>]) -> Result<(), Error> {
    if dest.is_empty() {
        return Ok(());
    }
    match unsafe { random_get(dest.as_mut_ptr() as *mut u8, dest.len()) } {
        0 => Ok(()),
        _ => Err(Error::WEB_CRYPTO),
    }
}
