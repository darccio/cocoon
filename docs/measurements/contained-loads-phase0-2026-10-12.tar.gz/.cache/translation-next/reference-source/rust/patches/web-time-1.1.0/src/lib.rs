//! Cocoon replacement for `web-time`. Same API subset; on wasm32-unknown-unknown
//! the clocks come from Go host imports instead of `performance.now()`/`Date.now()`.
#[cfg(not(all(target_arch = "wasm32", target_os = "unknown")))]
pub use std::time::*;

#[cfg(all(target_arch = "wasm32", target_os = "unknown"))]
mod imp {
    use std::fmt;
    use std::ops::{Add, AddAssign, Sub, SubAssign};
    pub use std::time::{Duration, TryFromFloatSecsError};

    #[link(wasm_import_module = "cocoon")]
    extern "C" {
        fn clock_mono() -> i64;
        fn clock_real() -> i64;
    }

    fn d(ns: i64) -> Duration { Duration::from_nanos(ns.max(0) as u64) }

    #[derive(Copy, Clone, PartialEq, Eq, PartialOrd, Ord, Hash, Debug)]
    pub struct Instant(Duration);

    impl Instant {
        pub fn now() -> Instant { Instant(d(unsafe { clock_mono() })) }
        pub fn duration_since(&self, earlier: Instant) -> Duration { self.0.saturating_sub(earlier.0) }
        pub fn checked_duration_since(&self, earlier: Instant) -> Option<Duration> { self.0.checked_sub(earlier.0) }
        pub fn saturating_duration_since(&self, earlier: Instant) -> Duration { self.0.saturating_sub(earlier.0) }
        pub fn elapsed(&self) -> Duration { Instant::now().duration_since(*self) }
        pub fn checked_add(&self, x: Duration) -> Option<Instant> { self.0.checked_add(x).map(Instant) }
        pub fn checked_sub(&self, x: Duration) -> Option<Instant> { self.0.checked_sub(x).map(Instant) }
    }
    impl Add<Duration> for Instant { type Output = Instant; fn add(self, x: Duration) -> Instant { Instant(self.0 + x) } }
    impl AddAssign<Duration> for Instant { fn add_assign(&mut self, x: Duration) { self.0 += x } }
    impl Sub<Duration> for Instant { type Output = Instant; fn sub(self, x: Duration) -> Instant { Instant(self.0 - x) } }
    impl SubAssign<Duration> for Instant { fn sub_assign(&mut self, x: Duration) { self.0 -= x } }
    impl Sub<Instant> for Instant { type Output = Duration; fn sub(self, x: Instant) -> Duration { self.duration_since(x) } }

    #[derive(Copy, Clone, PartialEq, Eq, PartialOrd, Ord, Hash, Debug)]
    pub struct SystemTime(Duration);
    pub const UNIX_EPOCH: SystemTime = SystemTime(Duration::ZERO);

    #[derive(Clone, Debug)]
    pub struct SystemTimeError(Duration);
    impl SystemTimeError { pub fn duration(&self) -> Duration { self.0 } }
    impl fmt::Display for SystemTimeError {
        fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result { write!(f, "second time provided was later than self") }
    }
    impl std::error::Error for SystemTimeError {}

    impl SystemTime {
        pub const UNIX_EPOCH: SystemTime = UNIX_EPOCH;
        pub fn now() -> SystemTime { SystemTime(d(unsafe { clock_real() })) }
        pub fn duration_since(&self, earlier: SystemTime) -> Result<Duration, SystemTimeError> {
            self.0.checked_sub(earlier.0).ok_or_else(|| SystemTimeError(earlier.0 - self.0))
        }
        pub fn elapsed(&self) -> Result<Duration, SystemTimeError> { SystemTime::now().duration_since(*self) }
        pub fn checked_add(&self, x: Duration) -> Option<SystemTime> { self.0.checked_add(x).map(SystemTime) }
        pub fn checked_sub(&self, x: Duration) -> Option<SystemTime> { self.0.checked_sub(x).map(SystemTime) }
    }
    impl Add<Duration> for SystemTime { type Output = SystemTime; fn add(self, x: Duration) -> SystemTime { SystemTime(self.0 + x) } }
    impl AddAssign<Duration> for SystemTime { fn add_assign(&mut self, x: Duration) { self.0 += x } }
    impl Sub<Duration> for SystemTime { type Output = SystemTime; fn sub(self, x: Duration) -> SystemTime { SystemTime(self.0 - x) } }
    impl SubAssign<Duration> for SystemTime { fn sub_assign(&mut self, x: Duration) { self.0 -= x } }
}
#[cfg(all(target_arch = "wasm32", target_os = "unknown"))]
pub use imp::*;
