//! Native Rust reference timings for the same operations, no FFI boundary.
use std::hint::black_box;
use std::time::Instant;

use libdd_ddsketch::DDSketch;
use libdd_trace_obfuscation::obfuscate::obfuscate_v04_span;
use libdd_trace_obfuscation::obfuscation_config::ObfuscationConfig;
use libdd_trace_obfuscation::sql::obfuscate_sql_string;
use libdd_trace_utils::msgpack_decoder::v04::from_slice;
use libdd_trace_utils::msgpack_encoder::v04::to_vec_from_v04;

fn time<F: FnMut()>(name: &str, iters: u32, mut f: F) {
    for _ in 0..iters / 10 { f(); }
    let t = Instant::now();
    for _ in 0..iters { f(); }
    println!("{name:<24} {:>12.1} ns/op", t.elapsed().as_nanos() as f64 / iters as f64);
}

fn main() {
    let q = "SELECT * FROM users WHERE id = 42 AND name = 'bob'";
    time("sql", 500_000, || { black_box(obfuscate_sql_string(black_box(q)).unwrap()); });
    let payload = std::fs::read(std::env::args().nth(1).expect("payload path")).unwrap();
    let cfg = ObfuscationConfig::default();
    time("traces1k", 1_000, || {
        let (mut t, _) = from_slice(&payload).unwrap();
        for c in t.iter_mut() { for s in c.iter_mut() { obfuscate_v04_span(s, &cfg); } }
        black_box(to_vec_from_v04(&t));
    });
    let mut s = DDSketch::default();
    let mut i = 0.0;
    time("sketch_add", 20_000_000, || { i += 1.0; s.add(black_box(i)).unwrap(); });
}
