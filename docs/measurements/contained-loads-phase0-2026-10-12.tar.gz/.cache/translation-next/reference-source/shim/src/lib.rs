//! Cocoon shim over libdatadog compute crates: DDSketch, SQL obfuscation and
//! v0.4 trace payload obfuscation. Compiled to wasm32 and translated to Go.
//!
//! Exports follow the Cocoon ABI v2 (see cocoon-guest): inputs arrive in the
//! host-reserved input buffer, outputs are published at `cocoon_out()`, every
//! export returns an i32 status, sketches cross as slab handles.

use std::sync::Mutex;

use cocoon_guest::{ERR_APP, ERR_ARG, ERR_HANDLE, OK, Slab, borrow, borrow_str, reply};
use libdd_ddsketch::DDSketch;
use libdd_trace_obfuscation::obfuscate::obfuscate_v04_span;
use libdd_trace_obfuscation::obfuscation_config::ObfuscationConfig;
use libdd_trace_obfuscation::sql::obfuscate_sql_string;
use libdd_trace_utils::msgpack_decoder::v04::from_slice;
use libdd_trace_utils::msgpack_encoder::v04::to_vec_from_v04;

pub use cocoon_guest::{cocoon_abi_version, cocoon_alloc, cocoon_in_reserve, cocoon_init, cocoon_out, cocoon_trim};

static SKETCHES: Mutex<Slab<DDSketch>> = Mutex::new(Slab::new());

fn sketches() -> std::sync::MutexGuard<'static, Slab<DDSketch>> {
    SKETCHES.lock().unwrap_or_else(|p| p.into_inner())
}

// ---------------------------------------------------------------- ddsketch

#[unsafe(no_mangle)]
pub extern "C" fn cocoon_sketch_new() -> u64 {
    sketches().insert(DDSketch::default())
}

#[unsafe(no_mangle)]
pub extern "C" fn cocoon_sketch_add(h: u64, v: f64) -> i32 {
    match sketches().get_mut(h) {
        None => ERR_HANDLE,
        Some(s) => match s.add(v) {
            Ok(()) => OK,
            Err(_) => ERR_ARG,
        },
    }
}

/// Adds `len / 8` little-endian f64 values from the input buffer in one call.
///
/// # Safety
/// `ptr`/`len` must describe readable memory.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn cocoon_sketch_add_many(h: u64, ptr: *const u8, len: usize) -> i32 {
    let r = unsafe { borrow(ptr, len) }.and_then(|b| {
        if b.len() % 8 != 0 {
            return Err((ERR_ARG, "length is not a multiple of 8".to_string()));
        }
        let mut slab = sketches();
        let s = slab.get_mut(h).ok_or((ERR_HANDLE, "unknown sketch handle".to_string()))?;
        for c in b.chunks_exact(8) {
            let v = f64::from_le_bytes(c.try_into().unwrap());
            s.add(v).map_err(|e| (ERR_ARG, e.to_string()))?;
        }
        Ok(Vec::new())
    });
    reply(r)
}

#[unsafe(no_mangle)]
pub extern "C" fn cocoon_sketch_count(h: u64) -> f64 {
    sketches().get_mut(h).map(|s| s.count()).unwrap_or(f64::NAN)
}

/// Publishes the sketch as a protobuf `DDSketch`.
#[unsafe(no_mangle)]
pub extern "C" fn cocoon_sketch_encode(h: u64) -> i32 {
    let mut slab = sketches();
    reply(match slab.get_mut(h) {
        Some(s) => Ok(s.clone().encode_to_vec()),
        None => Err((ERR_HANDLE, "unknown sketch handle".to_string())),
    })
}

#[unsafe(no_mangle)]
pub extern "C" fn cocoon_sketch_free(h: u64) -> i32 {
    if sketches().remove(h).is_some() { OK } else { ERR_HANDLE }
}

// ---------------------------------------------------------------- obfuscation

/// # Safety
/// `ptr`/`len` must describe readable memory.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn cocoon_sql_obfuscate(ptr: *const u8, len: usize) -> i32 {
    let r = unsafe { borrow_str(ptr, len) }.and_then(|q| {
        obfuscate_sql_string(q)
            .map(String::into_bytes)
            .map_err(|e| (ERR_APP, format!("{e:?}")))
    });
    reply(r)
}

/// Decodes a v0.4 msgpack trace payload, obfuscates every span with the default
/// config and re-encodes it: one boundary crossing per batch.
///
/// # Safety
/// `ptr`/`len` must describe readable memory.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn cocoon_traces_obfuscate(ptr: *const u8, len: usize) -> i32 {
    let r = unsafe { borrow(ptr, len) }.and_then(|data| {
        let (mut traces, _) = from_slice(data).map_err(|e| (ERR_APP, format!("decode: {e}")))?;
        let cfg = ObfuscationConfig::default();
        for chunk in traces.iter_mut() {
            for span in chunk.iter_mut() {
                obfuscate_v04_span(span, &cfg);
            }
        }
        Ok(to_vec_from_v04(&traces))
    });
    reply(r)
}

/// Test hook: panics, to exercise fault classification and poisoning.
#[unsafe(no_mangle)]
pub extern "C" fn cocoon_test_panic(code: i32) -> i32 {
    if code != 0 {
        panic!("cocoon_test_panic({code})");
    }
    OK
}
