#!/usr/bin/env python3
"""Post-process wasm2go output so bulk-memory helpers trap past the logical end.

wasm2go grows linear memory with append, leaving spare capacity; mem[x:y] is
bounded by cap, so memory.copy/fill/init into that spare region would not trap.
Re-slicing to len at the top of each helper restores the spec behaviour at the
cost of one slice header copy, and keeps amortised growth."""
import re, sys
path = sys.argv[1]
src = open(path).read()
n = 0
for name in ("memory_init", "memory_copy", "memory_fill", "memory_zero"):
    pat = re.compile(r"(func " + name + r"\[[^\n]*\(mem \[\]byte,[^\n]*\{\n)")
    src, k = pat.subn(r"\1\tmem = mem[:len(mem):len(mem)] // cocoon: bound by len, not cap\n", src)
    n += k
open(path, "w").write(src)
print(f"hardened {n} bulk-memory helpers in {path}")
