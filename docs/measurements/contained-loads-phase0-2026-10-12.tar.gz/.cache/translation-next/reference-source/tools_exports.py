#!/usr/bin/env python3
"""Print a wasm-metadce graph that keeps only Cocoon ABI exports (cocoon_*) and memory."""
import json, sys

def leb(b, i):
    r = s = 0
    while True:
        x = b[i]; i += 1
        r |= (x & 0x7f) << s; s += 7
        if x < 0x80:
            return r, i

def exports(path):
    b = open(path, 'rb').read()
    i = 8
    while i < len(b):
        sid = b[i]; i += 1
        size, i = leb(b, i)
        end = i + size
        if sid == 7:
            n, i = leb(b, i)
            for _ in range(n):
                ln, i = leb(b, i); name = b[i:i+ln].decode(); i += ln
                kind = b[i]; i += 1
                _, i = leb(b, i)
                yield name, kind
        i = end

keep = [n for n, k in exports(sys.argv[1]) if n.startswith('cocoon_') or n == 'memory']
graph = [{"name": "root", "root": True, "reaches": [f"e_{n}" for n in keep]}]
graph += [{"name": f"e_{n}", "export": n} for n in keep]
print(json.dumps(graph))
