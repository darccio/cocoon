from pathlib import Path
import os,subprocess,json,hashlib,datetime,shutil
root=Path.cwd();out=root/'.cache/translation-next';fixture=out/'fixture';fixture.mkdir(exist_ok=True)
env=dict(os.environ,GOTOOLCHAIN='local',CGO_ENABLED='0',GOAMD64='v1',GOCACHE=str(root/'.cache/go'),GOFLAGS='-buildvcs=false')
commands=json.loads((out/'fixture-commands.json').read_text()) if (out/'fixture-commands.json').exists() else []
def run(args):
 record={'argv':args,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (out/'fixture-build.log').open('a') as log:
  print('COMMAND',json.dumps(args),file=log,flush=True);result=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT);print('EXIT',result.returncode,file=log,flush=True)
 record.update(exit=result.returncode,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());commands.append(record);(out/'fixture-commands.json').write_text(json.dumps(commands,indent=2)+'\n');assert result.returncode==0
run([str(root/'.cache/binaryen/binaryen-version_133/bin/wasm-as'),str(out/'range-fixture.wat'),'-o',str(fixture/'fixture.wasm')])
run(['/usr/bin/go','tool','wasm2go','-unsafe','-pkg','wasm','-o',str(fixture/'raw-module.go'),str(fixture/'fixture.wasm')])
run(['/usr/lib64/go/1.26/bin/go','run',str(out/'harden-fixture.go'),'--',str(fixture/'raw-module.go'),str(fixture/'hardened-module.go')])
source=fixture/'hardened-module.go';source.write_bytes(source.read_bytes()+(out/'fixture-native-methods.go.txt').read_bytes());digest=hashlib.sha256(source.read_bytes()).hexdigest()
for role in ('before','probe','recheck'):
 directory=fixture/role;directory.mkdir(exist_ok=True)
 if role=='before':shutil.copyfile(source,directory/'module.go')
 else:run(['/usr/lib64/go/1.26/bin/go','run',str(out/'range-probe.go'),'-input',str(source),'-sha256',digest,'-mode',role,'-output',str(directory/'module.go'),'-inventory',str(fixture/(role+'-inventory.json'))])
 shutil.copyfile(out/'fixture-goldens_test.go',directory/'goldens_test.go')
 run(['/usr/lib64/go/1.26/bin/go','test','./.cache/translation-next/fixture/'+role,'-v','-count=1'])
print('PASS WAT/native originals/probe/recheck',flush=True)

selected=json.loads((fixture/'probe-inventory.json').read_text())
assert selected==json.loads((fixture/'recheck-inventory.json').read_text())
assert {row['Function'] for row in selected}=={'Xcovered','Xtriple'} and len(selected)==2,selected
print('PASS exact fixture inventory: only two intended covered reads',flush=True)
