"""Freeze the reviewed diagnostic matrix without running any timings."""
from pathlib import Path
import json,hashlib
root=Path.cwd();out=root/'.cache/translation-next';prior=root/'.cache/backend-control'
plan=json.loads((prior/'qualification-plan.json').read_text());plan['baseline_revision']='776b897';groups=[]
for group in plan['comparisons']:
 if group['kind']=='independent-reference':
  original=group['cases'];baseline=next(case for case in original if case['role']=='current')
  cases=[]
  for role in ('baseline','probe','recheck'):
   case=dict(baseline,role=role,binary=role);cases.append(case)
  cases.append(next(case for case in original if case['role']=='reference'))
  groups.append(dict(group,kind='translation-control',baseline_role='baseline',cases=cases,
                     secondary_comparisons=[{'key':group['key']+'-ProbeVsRecheck','roles':['recheck','probe']}]))
 elif group['kind']=='stream-control':groups.append(group)
 elif group['kind']=='call-layers':
  guest=next((case for case in group['cases'] if case['parts']==['BenchmarkSketchAddLayers','Guest']),None)
  if guest is None:continue
  groups.append({'key':'RawGuest-SketchAdd','kind':'translation-control','baseline_role':'baseline',
                 'cases':[dict(guest,role=role,binary=role) for role in ('baseline','probe','recheck')],
                 'secondary_comparisons':[{'key':'RawGuest-ProbeVsRecheck','roles':['recheck','probe']}]})
plan['comparisons']=groups
plan.pop('startup_trials_per_round',None);plan.pop('startup_rounds',None)
plan['notes']=[
 'Private hash-pinned translation-only diagnostic, not a retained production pass. Baseline/probe/recheck are separately compiled from identical authored tests; exact original Wasm and all production source remain unchanged.',
 'Probe removes only319 proved contained load32 unsafe-branch checks; all original reads/first-new-largest checks/evaluation positions/endian-fallback paths remain. Recheck restores the copied helper check with identical selected-call inventory; machine-code/frame/placement effects remain limits.',
 'Twelve production/corpus leaves each run baseline/probe/recheck/fresh independent reference, one rawGuest leaf runs three variants, four unchanged stream leaves are refresh controls:55 invocations/pass,14 passes,770 samples. No cold/startup cases run.',
 'Original/layer leaves retain explicit frameworkcpu16 with no in-window procs metric; matched leaves verify P1; stream leaves verify P16. Separate P1 CPU profile diagnostics are excluded from timings.',
 'Fresh reference ABI2/context/topology/original batch-trace input differences remain contextual. Increasing runs different calibrated prefixes and is evolving state. Standalone M1 original and fresh110percent limits are both retained.',
 'No compilation/tests/lint/fuzz/profiles/reviewer tools overlap timing. Exploratory unadjusted p-values, all custom metrics/raw outputs and negative medians are retained; nondetection is not equivalence.'
]
assert len(groups)==17 and sum(len(g['cases']) for g in groups)==55
(out/'qualification-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
build=json.loads((out/'variant-build-records.json').read_text());commands={entry['name']:entry['argv'] for entry in build if 'name' in entry}
config={'plan':'.cache/translation-next/qualification-plan.json','binaries':{role:'.cache/translation-next/'+role+'.test' for role in ('baseline','probe','recheck','reference','stream')},'added_harness':[], 'build_records':{},'artifacts':['go.mod','go.sum','examples/datadog/cocoon.lock.json','testdata/compute/cocoon.lock.json','testdata/streaming/cocoon.lock.json','.cache/reference.mod','.cache/reference.sum']}
config['build_records']['baseline']={'command':json.loads((out/'baseline-build.json').read_text())['actual_argv'],'cwd':str(root),'source_identity':'776b897; ordinary binary reproduces prior59a3d415, no source change'}
for role in ('probe','recheck'):config['build_records'][role]={'command':commands[role+'-compile'],'cwd':str(root),'source_identity':'Ignored pinned AST diagnostic overlay, exact selection/source/helper fingerprints frozen; whole package oracles passed'}
config['build_records']['reference']={'command':['/usr/lib64/go/1.26/bin/go','test','-modfile='+str(root/'.cache/reference.mod'),'-overlay='+str(out/'reference-overlay.json'),'-pgo=off','-c','-o',str(out/'reference.test'),'./dd'],'cwd':'/home/dario/Code/cocoon-spike/go','source_identity':'Fresh Rust1.97/Binaryen133/wasm2go0.4.16 rebuild; own locked source unchanged, previous three artifact hashes reproduce'}
config['build_records']['stream']={'command':['/usr/lib64/go/1.26/bin/go','test','-c','-pgo=off','-o',str(out/'stream.test'),'./testdata/streaming/go/streaming'],'cwd':str(root),'source_identity':'Untouched776b897 fixture; qualify.py after two identical proof/runtime builds'}
for filename in out.iterdir():
 if filename.is_file() and filename.suffix in ('.go','.json','.py','.asm','.cpu','.wat') and filename.name!='reference-module.go':config['artifacts'].append(str(filename.relative_to(root)))
for filename in (out/'ssa').glob('*.dump'):config['artifacts'].append(str(filename.relative_to(root)))
for filename in (out/'fixture').rglob('*'):
 if filename.is_file():config['artifacts'].append(str(filename.relative_to(root)))
config['artifacts']=sorted(set(config['artifacts']))
(out/'qualification-config.json').write_text(json.dumps(config,indent=2)+'\n')
print('Prepared',len(groups),'groups;',55*14,'planned raw rows; freeze follows final reviews/gates',flush=True)
