package wasm
import("context";"encoding/binary";"os";"testing";"github.com/tetratelabs/wazero")
type fixtureHost struct { callback func(); calls int }
func(h *fixtureHost)Xtouch(){h.calls++;if h.callback!=nil{h.callback()}}
func invoke(m *Module,name string,base,flag int32) int32 {switch name {case "covered":return m.Xcovered(base);case "triple":return m.Xtriple(base);case "rising":return m.Xrising(base);case "rebind":return m.Xrebind(base);case "wrapped":return m.Xwrapped(base);case "imported":return m.Ximported(base);case "stored":return m.Xstored(base);case "conditional":return m.Xconditional(base,flag);case "grown":return m.Xgrown(base);default:panic(name)}}
func call(m *Module,name string,base,flag int32)(result uint32,trapped bool){defer func(){if recover()!=nil{trapped=true}}();result=uint32(invoke(m,name,base,flag));return}
func bytesFixture(n int)[]byte {buf:=make([]byte,n);for i:=range buf {buf[i]=byte(i*7+3)};return buf}
func TestWasmOracle(t *testing.T){
 source,err:=os.ReadFile("../fixture.wasm");if err!=nil{t.Fatal(err)}
 names:=[]string{"covered","triple","rising","rebind","wrapped","imported","stored","conditional","grown"}
 for _,name:=range names {for _,base:=range []uint32{0,1,2,3,4,65515,65523,65524,65525,65528,65532,65535,0x7fffffff,0xfffffff0,0xfffffffc,0xffffffff} {for _,flag:=range []uint32{0,1} {
  ctx:=context.Background();r:=wazero.NewRuntimeWithConfig(ctx,wazero.NewRuntimeConfigInterpreter());calls:=0
  if _,err:=r.NewHostModuleBuilder("probe").NewFunctionBuilder().WithFunc(func(){calls++}).Export("touch").Instantiate(ctx);err!=nil{t.Fatal(err)}
  reference,err:=r.Instantiate(ctx,source);if err!=nil{t.Fatal(err)}
  data:=bytesFixture(65536);if !reference.Memory().Write(0,data){t.Fatal("write")}
  host:=&fixtureHost{};m:=New(host);copy(m.memory,data)
  args:=[]uint64{uint64(base)};if name=="conditional"{args=append(args,uint64(flag))}
  expected,werr:=reference.ExportedFunction(name).Call(ctx,args...);actual,trapped:=call(m,name,int32(base),int32(flag))
  if trapped!=(werr!=nil)||!trapped&&actual!=uint32(expected[0])||host.calls!=calls {t.Fatalf("%s base%x flag%d native%08x trap%t host%d wasm%v err%v host%d",name,base,flag,actual,trapped,host.calls,expected,werr,calls)}
  view,_:=reference.Memory().Read(0,reference.Memory().Size());if len(m.memory)!=len(view){t.Fatal("memory length")};for i,v:=range m.memory {if v!=view[i]{t.Fatalf("%s byte%d changed",name,i)}}
  if err:=r.Close(ctx);err!=nil{t.Fatal(err)}
 }}}
}
func TestNativeLogicalLength(t *testing.T){
 for _,name:=range []string{"covered","triple","rising"} {for length:=0;length<=20;length++ {for base:=0;base<=3;base++ {
  backing:=bytesFixture(64);m:=&Module{memory:backing[:length]};result,trapped:=call(m,name,int32(base),0)
  wantTrap:=base+12>length
  if trapped!=wantTrap {t.Fatalf("%s len%d cap%d base%d trap%t want%t",name,length,cap(m.memory),base,trapped,wantTrap)}
  if !trapped {a:=binary.LittleEndian.Uint32(backing[base:]);b:=binary.LittleEndian.Uint32(backing[base+4:]);c:=binary.LittleEndian.Uint32(backing[base+8:]);want:=a^c;if name!="covered"{want^=b};if result!=want{t.Fatal("bits mismatch")}}
 }}}
 for _,base:=range []int32{-1,-4,-12,0x7fffffff} {m:=&Module{memory:bytesFixture(64)};if _,trap:=call(m,"covered",base,0);!trap{t.Fatal("widened high address accepted")}}
}
func TestNativeBarriers(t *testing.T){
 for _,replace:=range []bool{false,true} {host:=&fixtureHost{};m:=&Module{memory:bytesFixture(64),_probe:host};host.callback=func(){if replace{m.memory=bytesFixture(3)}else{m.memory=m.memory[:3]}}
  if _,trap:=call(m,"imported",0,0);!trap||host.calls!=1 {t.Fatal("import/header barrier crossed",replace,trap,host.calls)}
 }
 host:=&fixtureHost{};m:=&Module{memory:bytesFixture(64),_probe:host};host.callback=func(){m.memory=make([]byte,64);binary.LittleEndian.PutUint32(m.memory,12345)}
 high:=binary.LittleEndian.Uint32(m.memory[8:]);result,trap:=call(m,"imported",0,0);if trap||result!=high^12345{t.Fatal("retained stale backing",result,trap)}
 m=&Module{memory:bytesFixture(64)[:12]};if _,trap:=call(m,"rebind",0,0);!trap{t.Fatal("base reassignment crossed")}
 m=&Module{memory:bytesFixture(64)[:3]};if _,trap:=call(m,"conditional",0,0);!trap{t.Fatal("untaken conditional established a check")}
}
func TestNativeTrapFirst(t *testing.T){
 host:=&fixtureHost{};m:=&Module{memory:bytesFixture(64)[:7],_probe:host};_,trap:=call(m,"imported",0,0);if !trap||host.calls!=0{t.Fatal("first check/import prefix",trap,host.calls)}
}

func TestNativeSelectionBarriers(t *testing.T) {
 cases:=[]struct{name string;run func(*Module)int32}{
  {"shadowFunction",func(m *Module)int32{return m.XshadowFunc(0)}},
  {"labelEntry",func(m *Module)int32{return m.Xlabel(0,0)}},
 }
 for _,entry:=range cases {t.Run(entry.name,func(t *testing.T){
  length:=3;if entry.name=="shadowFunction"{length=16}
  m:=&Module{memory:bytesFixture(64)[:length]};trapped:=false
  func(){defer func(){if recover()!=nil{trapped=true}}();_ = entry.run(m)}()
  if !trapped{t.Fatal("selection barrier crossed")}
 })}
}
