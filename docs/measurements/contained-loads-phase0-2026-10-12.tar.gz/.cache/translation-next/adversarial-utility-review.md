# Private contained-load utility: applied adversarial review

Read-only review on 2026-10-12 of `.cache/translation-next/range-probe.go` and
its current ignored probe/recheck outputs. No edits to the utility, builds,
tests, profiles, lint or timings were performed. Only this ignored note was
written. This is a module-hash-pinned diagnostic, not a generic production
binding/effect proof.

## Confirmed current behavior

Probe and recheck inventories are identical: 319 contained load32 calls across
69 methods. Every recorded offset+3 is at most its prior proved end. The current
Datadog source lacks the new helper identifier. Both appended helpers are exact
copies of the pinned original apart from their name and, for probe alone, the
single unsafe-branch `_ = mem[uint64(addr)+3]` statement. Nosplit, endian reversal
and binary.LittleEndian fallback are preserved. The demonstrated fn176 offset-0
load at source line 36203 is selected with prior end 11.

The scanner accepts only direct single-assignment load RHS, optionally under a
builtin int32 conversion. It therefore does not establish proof from nested or
short-circuit load expressions. Each lexical block starts with fresh facts;
control, labelled statements, declarations, multiassignments, IncDec, field or
indirect assignment and unknown calls clear them. Function-literal bodies are
not visited. Receiver assignment clears all facts. A successful direct load
proves its bound before the destination assignment; killing the destination's
fact afterward handles self-assignment/base replacement correctly. No values,
views or earlier reads are forwarded or hoisted.

## Guards to close before reusing it on fixture inputs

1. Fresh-helper collision is checked only in package scope. A parameter or
   local function value named cocoon_load32_in_range can capture a rewritten
   call. Reject that identifier anywhere in input before inserting the helper;
   current pinned DD has no collision, so this does not explain its inventory.
2. pure() accepts any resolved identifier named i32/i64 as a pure one-argument
   wrapper. A local function variable i32 can shrink or replace memory, leaving
   a stale bound for a later contained load. Restrict to the canonical bound
   identity/type-conversion objects or reject shadowed wrappers. The pinned DD
   uses the exact identity functions at module.go:63031/63034, rather than
   aliases; do not infer a generic helper-binding proof from that.
3. explicitI32 accepts ValueSpec declarations without distinguishing package
   globals from locals. The proposed scope requires an unchanged local or
   parameter. Reject package-level bases or make locality an inventory-checked
   input prerequisite. Globals need a different concurrency/ownership proof.

Module receiver/type, selector field, helper body, wrapper bindings and
architecture constants otherwise rely on the full input SHA and canonical
source, rather than reusable generic validation. The supplied hash is an
identity guard, not proof of arbitrary inputs merely because their caller
supplies their own hash. Any later authored production pass must independently
resolve those declarations/types and maintain the fail-closed eligibility.

Disposition: no unconditional-fact, address-end, kill or helper-copy blocker
found in the current canonical 319-read DD probe. Close the three input guard
holes before broader fixture reuse, then review executable WAT/native evidence
and actual check elimination before isolated timing. No production change or
measurement claim is approved. Tools stopped.

## Applied guard recheck

The three input guards are now closed. Every input identifier is checked for
the fresh helper name. Eligible base objects are explicitly recorded from
method parameters and local ValueSpecs, excluding package globals. Pure i32/i64
calls require a bound exact identity FuncDecl with builtin parameter/result
types and a sole return of that parameter, or an exact builtin alias. The
identity-function recognition handles the real DD wrappers; my initial alias
description was incorrect. Private module/helper/architecture proofs remain
hash-pinned rather than generic.

Root supplied passing before/probe/recheck WAT/native and fallback/native386
evidence, two actual selected fixture sites, whole-DD suites and semantic
first-guard/import-crossing mutant failures. The mutant logs fail actual
runtime assertions, not compilation/source validation. Native logical-length
cases use physical spare capacity, so unsafe-check mistakes fail semantically
without requiring an out-of-allocation read.

One regression-order correction remains at this recheck: XshadowFunc declares
its impure local i32 after the first load, and that declaration already clears
the OLD scanner's facts. Move the declaration before the first checked load,
then invoke it between that load and the lower read; this tests the actual old
purity hole. Copied backend-control plan notes must also be replaced before
freeze because their single engine binary/RawCachedCall/startup descriptions
do not match this baseline/probe/recheck round. Await those corrections before
the final measurement disposition. No builds or tests run by this reviewer.

Final applied-source follow-up: XshadowFunc now declares the impure wrapper
before its first checked load and invokes it between that load and the lower
read. This corrects the regression ordering and tests the real old purity hole.
No further scanner semantic blocker was found in the current private scope.
Root owns rerunning the changed fixture and closing the stale plan metadata
before freeze. Existing positive/mutant evidence and fixed source support the
restricted diagnostic, not a generic production guard or a sole-cause timing
claim. Fewer static panicBounds sites and the smaller fn176 frame are concrete
machine-code changes; their performance remains unmeasured. Tools stopped.
