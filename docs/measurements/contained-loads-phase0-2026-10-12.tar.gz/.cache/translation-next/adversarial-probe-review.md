# Contained load32 check diagnostic: adversarial scope review

Read-only review, 2026-10-12. This reviews a private attainable-ceiling probe,
not a generic production pass or a new public contract. No source change,
build, test, lint, profile or benchmark was performed by this reviewer.

## Demonstrated cost and proof

The ordinary Go 1.26.8 baseline assembly retains end checks at base+7, base+11
and base+3 around the three fn176 loads at offsets 4, 8 and 0. The base is the
same unchanged local int32 and the current memory header is unchanged there.
The surviving base+3 comparison is therefore a concrete diagnostic target;
old profile percentages and the prior publication-view gain are not its ceiling.

After an earlier checked four-byte load succeeds, logical len is strictly
greater than that address+3. For a common uint32 base and nonnegative widened
u32 offsets, every later smaller offset has a smaller or equal end. A u32 base
plus u32 offset plus three is below 2^34, so the retained uint64 check cannot
overflow. No wrapped uint32 addition or arbitrary expression is covered.
Keep the first load and each new-largest check at the original position, then
keep each contained read at its original position through a copied pinned
helper with only the redundant unsafe-branch check removed. The endian reversal
and binary.LittleEndian fallback, including fallback bounds, remain unchanged.

## Scope blockers to avoid

- Only an unconditionally executed earlier load may establish proof. Loads in
  short-circuit &&/|| operands, function-literal bodies, conditionally executed
  branches, or unproved effect expressions cannot establish it for later code.
  Do not propagate proof out of a nested block or across any control/label.
- Identify declarations, not names. Invalidate on assignment/rebinding of the
  base or receiver, including compound/self/multiple assignment, increments,
  shadowing and declarations; apply invalidation after RHS evaluation or reject
  such statements conservatively. The same name is not the same immutable value.
- Reset at all writes, header changes, indirect assignments, unproved calls,
  imports/growth, alternate entry and control boundaries. Do not walk into a
  function literal or assume a recursive AST visitation order is Go evaluation
  order. A whole-statement restricted grammar is safer than opportunistic calls
  found anywhere inside an expression.
- The first memory argument must be the exact current receiver.memory selector,
  not another slice, alias, captured view, field or receiver. The generic helper
  body, builtin casts, architecture constants and copied helper must be pinned.
  A successful earlier access proves logical length, not spare capacity.
- Keep all read/evaluation positions and original failures. Do not coalesce
  initial checks, precheck the largest range at block entry, forward values,
  capture a view, cross stores, or move reads. The earliest new-largest failure
  and any prior side effects must remain observable in their original order.

## Minimum executable evidence before timing

Use actual WAT -> pinned Binaryen/wasm2go -> baseline hardening -> ignored probe,
then compare original Wasm and generated Go. Assert an actual selected region
and actual unchecked call exist, so unsupported translation cannot make the
oracle vacuous. Compare result bits, complete relevant memory, trap categories
and ordered import observations. Cover at least:

1. Offset 4 then 8 then 0, and repeated/overlapping contained reads; distinctive
   bytes and aligned/unaligned bases prove every read remains present and ordered.
2. Exact logical end success, first checked load failure, and a later new-largest
   load failure while an earlier smaller load succeeded. Preserve trap prefix
   writes/events from before that failing region. Larger checks must not be
   hoisted to entry or removed from a region with only smaller prior accesses.
3. A base assignment, store, import, branch, goto/label or loop between accesses:
   no proof crosses it. An import must mutate bytes, and a native import must
   replace/shrink the header to make stale proof fail. Loop iterations must
   reestablish proof after entry/barriers; zero-iteration/alternate-entry cases
   must not execute any hoisted read.
4. Negative i32 bases/raw high bits, widened base near 2^32 with offsets 4/8,
   maximal u32 offset and a separate wrapping-i32 address shape. Unsupported
   wrapping/nested address forms stay checked. Offset+width arithmetic remains
   widened and the actual helper's failure behavior is compared.
5. Native logical len below cap, empty/nil view, shrink/replacement between
   regions, growth with spare capacity and reallocating growth. Force the
   fallback with unalignedOK=false in a separately identified fixture variant,
   since amd64/386 unsafe access alone does not execute that fallback. Keep the
   endian reversal byte-identical; setting big=true on a little-endian host is
   not by itself an original-Wasm oracle for native big-endian execution.
   Run meaningful native 386 checks before claiming its correctness support.

Add negative AST selection cases for short-circuit loads, function literals,
shadowed/reassigned bindings and impure nested arguments. Independently broken
mutants after rewriting must compile and fail the executable oracle: carry
proof across a header-changing import; remove a first/new-largest check; or
move the later read before byte mutation. Use physical spare capacity and
bounded native addresses for unsafe-check mutants so a semantic failure does
not rely on a fatal out-of-allocation read. Parser rejection or compile failure
does not prove a runtime oracle catches wrong semantics.

## Qualification limits

The copied-helper probe remains full-module-hash-pinned diagnostic code. Its
function inventory is evidence, not a production eligibility rule. Keep ordinary
baseline/no-op/probe and, if used, a restorative copied-helper control frozen
with identical harnesses; verify actual machine code removes the observed check.
Inlining, liveness, code size and placement may also change, so no sole-cause
claim follows from a time difference. Use matched scalar/batch inputs, all
original/varied/negative guards, independent holdouts and stream controls, with
actual leaf processor verification and reversed confirmation. A positive
screen only supports later structural specification/proof work; all production
artifacts/locks, math and checked runtime contracts remain unchanged here.

Review disposition: scope is plausible subject to the restricted unconditional
load/effect/binding rules and executable evidence above. Await applied utility
and fixture review; no production implementation is approved. Tools stopped.
