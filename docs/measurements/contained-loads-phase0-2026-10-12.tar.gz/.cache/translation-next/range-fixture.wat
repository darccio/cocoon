(module
 (import "probe" "touch" (func $touch))
 (memory (export "memory") 1 3)
 (func (export "covered") (param $p i32) (result i32) (local $a i32) (local $b i32)
  local.get $p i32.load offset=8 local.set $a
  local.get $p i32.load local.set $b
  local.get $a local.get $b i32.xor)
 (func (export "triple") (param $p i32) (result i32) (local $a i32) (local $b i32) (local $c i32)
  local.get $p i32.load offset=4 local.set $a
  local.get $p i32.load offset=8 local.set $b
  local.get $p i32.load local.set $c
  local.get $a local.get $b i32.xor local.get $c i32.xor)
 (func (export "rising") (param $p i32) (result i32) (local $a i32) (local $b i32) (local $c i32)
  local.get $p i32.load local.set $a
  local.get $p i32.load offset=4 local.set $b
  local.get $p i32.load offset=8 local.set $c
  local.get $a local.get $b i32.xor local.get $c i32.xor)
 (func (export "rebind") (param $p i32) (result i32) (local $a i32) (local $b i32)
  local.get $p i32.load offset=8 local.set $a
  local.get $p i32.const 16 i32.add local.set $p
  local.get $p i32.load local.set $b
  local.get $a local.get $b i32.xor)
 (func (export "wrapped") (param $p i32) (result i32) (local $a i32) (local $b i32)
  local.get $p i32.load offset=8 local.set $a
  local.get $p i32.const -16 i32.add i32.load local.set $b
  local.get $a local.get $b i32.xor)
 (func (export "imported") (param $p i32) (result i32) (local $a i32) (local $b i32)
  local.get $p i32.load offset=8 local.set $a
  call $touch
  local.get $p i32.load local.set $b
  local.get $a local.get $b i32.xor)
 (func (export "stored") (param $p i32) (result i32) (local $a i32) (local $b i32)
  local.get $p i32.load offset=8 local.set $a
  local.get $p i32.const 999 i32.store
  local.get $p i32.load local.set $b
  local.get $a local.get $b i32.xor)
 (func (export "conditional") (param $p i32) (param $flag i32) (result i32) (local $a i32) (local $b i32)
  local.get $flag if local.get $p i32.load offset=8 local.set $a end
  local.get $p i32.load local.set $b
  local.get $a local.get $b i32.xor)
 (func (export "grown") (param $p i32) (result i32) (local $a i32) (local $b i32)
  local.get $p i32.load offset=8 local.set $a
  i32.const 1 memory.grow drop
  local.get $p i32.load local.set $b
  local.get $a local.get $b i32.xor)
)
