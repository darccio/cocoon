TEXT dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).Xcocoon_sketch_add(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/internal/wasm/module.go
  module.go:48457	0x657d40		493b6610		CMPQ SP, 0x10(R14)										
  module.go:48457	0x657d44		0f86880b0000		JBE 0x6588d2											
  module.go:48457	0x657d4a		55			PUSHQ BP											
  module.go:48457	0x657d4b		4889e5			MOVQ SP, BP											
  module.go:48457	0x657d4e		4883ec70		SUBQ $0x70, SP											
  module.go:48460	0x657d52		8b5050			MOVL 0x50(AX), DX										
  module.go:48461	0x657d55		448d42f0		LEAL -0x10(DX), R8										
  module.go:48462	0x657d59		44894050		MOVL R8, 0x50(AX)										
  module.go:48463	0x657d5d		4c8b4838		MOVQ 0x38(AX), R9										
  module.go:48463	0x657d61		4981f9b0cf1000		CMPQ R9, $0x10cfb0										
  module.go:48463	0x657d68		0f86570b0000		JBE 0x6588c5											
  module.go:48463	0x657d6e		4889842480000000	MOVQ AX, 0x80(SP)										
  module.go:48463	0x657d76		f20f11842490000000	MOVSD_XMM X0, 0x90(SP)										
  module.go:48460	0x657d7f		8954242c		MOVL DX, 0x2c(SP)										
  module.go:48461	0x657d83		4489442420		MOVL R8, 0x20(SP)										
  module.go:48463	0x657d88		4c8b4830		MOVQ 0x30(AX), R9										
  module.go:48463	0x657d8c		450fb689b0cf1000	MOVZX 0x10cfb0(R9), R9										
  module.go:48464	0x657d94		4183f901		CMPL R9, $0x1											
  module.go:48464	0x657d98		742f			JE 0x657dc9											
  module.go:48463	0x657d9a		48899c2488000000	MOVQ BX, 0x88(SP)										
  module.go:48465	0x657da2		e839e0f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn41(SB)			
  module.go:48468	0x657da7		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48620	0x657daf		8b54242c		MOVL 0x2c(SP), DX										
  module.go:48473	0x657db3		488b9c2488000000	MOVQ 0x88(SP), BX										
  module.go:48474	0x657dbb		448b442420		MOVL 0x20(SP), R8										
  unsafe.go:35		0x657dc0		f20f10842490000000	MOVSD_XMM 0x90(SP), X0										
  module.go:48468	0x657dc9		4c8b4838		MOVQ 0x38(AX), R9										
  module.go:62983	0x657dcd		4981f973ce1000		CMPQ R9, $0x10ce73										
  module.go:62983	0x657dd4		0f86de0a0000		JBE 0x6588b8											
  module.go:48468	0x657dda		4c8b4830		MOVQ 0x30(AX), R9										
  module.go:62984	0x657dde		4183b970ce100000	CMPL 0x10ce70(R9), $0x0										
  module.go:48469	0x657de6		0f85aa0a0000		JNE 0x658896											
  module.go:48470	0x657dec		90			NOPL												
  module.go:63001	0x657ded		41c78170ce1000ffffffff	MOVL $-0x1, 0x10ce70(R9)									
  module.go:48471	0x657df8		4c8b4838		MOVQ 0x38(AX), R9										
  module.go:48471	0x657dfc		0f1f4000		NOPL 0(AX)											
  module.go:62983	0x657e00		4981f97fce1000		CMPQ R9, $0x10ce7f										
  module.go:62983	0x657e07		0f867d0a0000		JBE 0x65888a											
  module.go:48472	0x657e0d		90			NOPL												
  module.go:62983	0x657e0e		4981f983ce1000		CMPQ R9, $0x10ce83										
  module.go:62983	0x657e15		0f86630a0000		JBE 0x65887e											
  module.go:48471	0x657e1b		488b5030		MOVQ 0x30(AX), DX										
  module.go:48474	0x657e1f		4589c1			MOVL R8, R9											
  module.go:48474	0x657e22		4c894c2468		MOVQ R9, 0x68(SP)										
  module.go:62984	0x657e27		8b8a7cce1000		MOVL 0x10ce7c(DX), CX										
  module.go:62984	0x657e2d		8bba80ce1000		MOVL 0x10ce80(DX), DI										
  module.go:48473	0x657e33		4889de			MOVQ BX, SI											
  module.go:48473	0x657e36		4489c3			MOVL R8, BX											
  module.go:48473	0x657e39		e8e2bbf8ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn84(SB)			
  module.go:48474	0x657e3e		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48474	0x657e46		488b5038		MOVQ 0x38(AX), DX										
  module.go:62983	0x657e4a		4c8b442468		MOVQ 0x68(SP), R8										
  module.go:62983	0x657e4f		4d8d4807		LEAQ 0x7(R8), R9										
  module.go:62983	0x657e53		4c39ca			CMPQ DX, R9											
  module.go:62983	0x657e56		0f861d0a0000		JBE 0x658879											
  module.go:48474	0x657e5c		488b7030		MOVQ 0x30(AX), SI										
  module.go:62983	0x657e60		498d7803		LEAQ 0x3(R8), DI										
  module.go:48481	0x657e64		90			NOPL												
  module.go:62984	0x657e65		418b4c3004		MOVL 0x4(R8)(SI*1), CX										
  module.go:62983	0x657e6a		4839fa			CMPQ DX, DI											
  module.go:62983	0x657e6d		0f86010a0000		JBE 0x658874											
  module.go:62984	0x657e73		8b5c2420		MOVL 0x20(SP), BX										
  module.go:62984	0x657e77		4189da			MOVL BX, R10											
  module.go:62984	0x657e7a		458b1c32		MOVL 0(R10)(SI*1), R11										
  module.go:62984	0x657e7e		6690			NOPW												
  module.go:48483	0x657e80		4183fbff		CMPL R11, $-0x1											
  module.go:48483	0x657e84		7418			JE 0x657e9e											
  module.go:63009	0x657e86		4d8d600f		LEAQ 0xf(R8), R12										
  module.go:48484	0x657e8a		90			NOPL												
  module.go:63009	0x657e8b		4c39e2			CMPQ DX, R12											
  module.go:63009	0x657e8e		0f86db090000		JBE 0x65886f											
  module.go:63010	0x657e94		498b543008		MOVQ 0x8(R8)(SI*1), DX										
  module.go:48486	0x657e99		e926070000		JMP 0x6585c4											
  module.go:62983	0x657e9e		4c894c2460		MOVQ R9, 0x60(SP)										
  module.go:62983	0x657ea3		48897c2458		MOVQ DI, 0x58(SP)										
  module.go:62984	0x657ea8		4c89542450		MOVQ R10, 0x50(SP)										
  module.go:48488	0x657ead		8b5050			MOVL 0x50(AX), DX										
  module.go:48488	0x657eb0		89542428		MOVL DX, 0x28(SP)										
  module.go:48489	0x657eb4		8d72c0			LEAL -0x40(DX), SI										
  module.go:48490	0x657eb7		897050			MOVL SI, 0x50(AX)										
  unsafe.go:35		0x657eba		f20f10842490000000	MOVSD_XMM 0x90(SP), X0										
  unsafe.go:35		0x657ec3		66490f7ec3		MOVQ X0, R11											
  module.go:48493	0x657ec8		4d89dc			MOVQ R11, R12											
  module.go:48493	0x657ecb		490fbaf33f		BTRQ $0x3f, R11											
  module.go:48499	0x657ed0		4d8d6c24ff		LEAQ -0x1(R12), R13										
  module.go:48504	0x657ed5		49bf000000000000f0ff	MOVQ $0xfff0000000000000, R15									
  module.go:48504	0x657edf		4d01df			ADDQ R11, R15											
  module.go:48492	0x657ee2		90			NOPL												
  module.go:48495	0x657ee3		4d85db			TESTQ R11, R11											
  module.go:48495	0x657ee6		410f94c3		SETE R11											
  module.go:48498	0x657eea		450fb6db		MOVZX R11, R11											
  module.go:48499	0x657eee		49b8ffffffffffff0f00	MOVQ $0xfffffffffffff, R8									
  module.go:48499	0x657ef8		4d39e8			CMPQ R8, R13											
  module.go:48499	0x657efb		410f97c0		SETA R8												
  module.go:48502	0x657eff		450fb6c0		MOVZX R8, R8											
  module.go:48502	0x657f03		4509c3			ORL R8, R11											
  module.go:48504	0x657f06		49b8000000000000e07f	MOVQ $0x7fe0000000000000, R8									
  module.go:48504	0x657f10		4d39f8			CMPQ R8, R15											
  module.go:48504	0x657f13		410f97c0		SETA R8												
  module.go:48507	0x657f17		450fb6c0		MOVZX R8, R8											
  module.go:48508	0x657f1b		4d85e4			TESTQ R12, R12											
  module.go:48508	0x657f1e		410f9dc4		SETGE R12											
  module.go:48511	0x657f22		450fb6e4		MOVZX R12, R12											
  module.go:48511	0x657f26		4521e0			ANDL R12, R8											
  module.go:48511	0x657f29		4509d8			ORL R11, R8											
  module.go:48511	0x657f2c		4585c0			TESTL R8, R8											
  module.go:48511	0x657f2f		0f8493030000		JE 0x6582c8											
  module.go:48489	0x657f35		89742424		MOVL SI, 0x24(SP)										
  module.go:48535	0x657f39		8d5ac8			LEAL -0x38(DX), BX										
  module.go:48535	0x657f3c		0f1f4000		NOPL 0(AX)											
  module.go:48535	0x657f40		e8bb8cfdff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn176(SB)			
  module.go:48536	0x657f45		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48536	0x657f4d		488b5038		MOVQ 0x38(AX), DX										
  module.go:48536	0x657f51		8b742424		MOVL 0x24(SP), SI										
  module.go:48536	0x657f55		89f6			MOVL SI, SI											
  module.go:62983	0x657f57		488d7e0b		LEAQ 0xb(SI), DI										
  module.go:62983	0x657f5b		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:62983	0x657f60		4839fa			CMPQ DX, DI											
  module.go:62983	0x657f63		0f8601090000		JBE 0x65886a											
  module.go:48536	0x657f69		488b7830		MOVQ 0x30(AX), DI										
  module.go:62984	0x657f6d		448b443e08		MOVL 0x8(SI)(DI*1), R8										
  module.go:48538	0x657f72		4585c0			TESTL R8, R8											
  module.go:48538	0x657f75		7536			JNE 0x657fad											
  module.go:48574	0x657f77		90			NOPL												
  module.go:63000	0x657f78		488b4c2458		MOVQ 0x58(SP), CX										
  module.go:63000	0x657f7d		0f1f00			NOPL 0(AX)											
  module.go:63000	0x657f80		4839ca			CMPQ DX, CX											
  module.go:63000	0x657f83		0f86dc080000		JBE 0x658865											
  module.go:63001	0x657f89		488b542450		MOVQ 0x50(SP), DX										
  module.go:63001	0x657f8e		c70417ffffffff		MOVL $-0x1, 0(DI)(DX*1)										
  module.go:63009	0x657f95		488b742468		MOVQ 0x68(SP), SI										
  module.go:62983	0x657f9a		488b7c2460		MOVQ 0x60(SP), DI										
  module.go:62983	0x657f9f		4989c8			MOVQ CX, R8											
  module.go:62984	0x657fa2		4989d1			MOVQ DX, R9											
  module.go:48577	0x657fa5		4889c1			MOVQ AX, CX											
  module.go:48577	0x657fa8		e9cf040000		JMP 0x65847c											
  module.go:62983	0x657fad		4c8d4e0f		LEAQ 0xf(SI), R9										
  module.go:48539	0x657fb1		90			NOPL												
  module.go:62983	0x657fb2		4c39ca			CMPQ DX, R9											
  module.go:62983	0x657fb5		0f86a3080000		JBE 0x65885e											
  module.go:63000	0x657fbb		4c8d4e2b		LEAQ 0x2b(SI), R9										
  module.go:48541	0x657fbf		90			NOPL												
  module.go:62984	0x657fc0		448b543e0c		MOVL 0xc(SI)(DI*1), R10										
  module.go:63000	0x657fc5		4c39ca			CMPQ DX, R9											
  module.go:63000	0x657fc8		0f868b080000		JBE 0x658859											
  module.go:63001	0x657fce		c7443e2800000000	MOVL $0x0, 0x28(SI)(DI*1)									
  module.go:48542	0x657fd6		488b7838		MOVQ 0x38(AX), DI										
  module.go:63026	0x657fda		4c8d5e27		LEAQ 0x27(SI), R11										
  module.go:63026	0x657fde		6690			NOPW												
  module.go:63026	0x657fe0		4c39df			CMPQ DI, R11											
  module.go:63026	0x657fe3		0f866b080000		JBE 0x658854											
  module.go:48542	0x657fe9		488b7830		MOVQ 0x30(AX), DI										
  module.go:63027	0x657fed		49bc0000000001000000	MOVQ $0x100000000, R12										
  module.go:63027	0x657ff7		4c89643e20		MOVQ R12, 0x20(SI)(DI*1)									
  module.go:48543	0x657ffc		488b7838		MOVQ 0x38(AX), DI										
  module.go:63000	0x658000		4c8d6633		LEAQ 0x33(SI), R12										
  module.go:63000	0x658004		4c39e7			CMPQ DI, R12											
  module.go:63000	0x658007		0f8642080000		JBE 0x65884f											
  module.go:48543	0x65800d		488b7830		MOVQ 0x30(AX), DI										
  module.go:63001	0x658011		c7443e30c81a1000	MOVL $0x101ac8, 0x30(SI)(DI*1)									
  module.go:48544	0x658019		488b7838		MOVQ 0x38(AX), DI										
  module.go:63026	0x65801d		4c8d663b		LEAQ 0x3b(SI), R12										
  module.go:63026	0x658021		4c39e7			CMPQ DI, R12											
  module.go:63026	0x658024		0f8620080000		JBE 0x65884a											
  module.go:48544	0x65802a		488b7830		MOVQ 0x30(AX), DI										
  module.go:63027	0x65802e		48c7443e3420000060	MOVQ $0x60000020, 0x34(SI)(DI*1)								
  module.go:48545	0x658037		488b7838		MOVQ 0x38(AX), DI										
  module.go:63000	0x65803b		4c8d662f		LEAQ 0x2f(SI), R12										
  module.go:63000	0x65803f		90			NOPL												
  module.go:63000	0x658040		4c39e7			CMPQ DI, R12											
  module.go:63000	0x658043		0f86fc070000		JBE 0x658845											
  module.go:48545	0x658049		488b7830		MOVQ 0x30(AX), DI										
  module.go:48545	0x65804d		8b5c2428		MOVL 0x28(SP), BX										
  module.go:48545	0x658051		448d63e0		LEAL -0x20(BX), R12										
  module.go:63001	0x658055		4489643e2c		MOVL R12, 0x2c(SI)(DI*1)									
  module.go:48546	0x65805a		488b7838		MOVQ 0x38(AX), DI										
  module.go:62983	0x65805e		4d8d6213		LEAQ 0x13(R10), R12										
  module.go:62983	0x658062		4c39e7			CMPQ DI, R12											
  module.go:62983	0x658065		0f86d3070000		JBE 0x65883e											
  module.go:48546	0x65806b		488b7830		MOVQ 0x30(AX), DI										
  module.go:62984	0x65806f		498d3c3a		LEAQ 0(R10)(DI*1), DI										
  module.go:62984	0x658073		488d7f10		LEAQ 0x10(DI), DI										
  module.go:62984	0x658077		48633f			MOVSXD 0(DI), DI										
  module.go:62984	0x65807a		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:63164	0x658080		48397808		CMPQ 0x8(AX), DI										
  module.go:63164	0x658084		0f86a1070000		JBE 0x65882b											
  module.go:48547	0x65808a		48c1e704		SHLQ $0x4, DI											
  module.go:48547	0x65808e		4c8b20			MOVQ 0(AX), R12											
  module.go:48547	0x658091		4e8b2c27		MOVQ 0(DI)(R12*1), R13										
  module.go:48547	0x658095		4a8b542708		MOVQ 0x8(DI)(R12*1), DX										
  module.go:48547	0x65809a		488d3dbf562000		LEAQ 0x2056bf(IP), DI										
  module.go:48547	0x6580a1		4939fd			CMPQ R13, DI											
  module.go:48547	0x6580a4		0f856f070000		JNE 0x658819											
  module.go:48536	0x6580aa		4889742448		MOVQ SI, 0x48(SP)										
  module.go:62984	0x6580af		4489442434		MOVL R8, 0x34(SP)										
  module.go:62984	0x6580b4		4489542430		MOVL R10, 0x30(SP)										
  module.go:63000	0x6580b9		4c894c2440		MOVQ R9, 0x40(SP)										
  module.go:63026	0x6580be		4c895c2438		MOVQ R11, 0x38(SP)										
  module.go:48547	0x6580c3		488b0a			MOVQ 0(DX), CX											
  module.go:48547	0x6580c6		83c3ec			ADDL $-0x14, BX											
  module.go:48547	0x6580c9		4489c0			MOVL R8, AX											
  module.go:48547	0x6580cc		ffd1			CALL CX												
  module.go:48548	0x6580ce		85c0			TESTL AX, AX											
  module.go:48548	0x6580d0		0f8508070000		JNE 0x6587de											
  module.go:48552	0x6580d6		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48552	0x6580de		488b7038		MOVQ 0x38(AX), SI										
  module.go:62983	0x6580e2		488b7c2440		MOVQ 0x40(SP), DI										
  module.go:62983	0x6580e7		4839fe			CMPQ SI, DI											
  module.go:62983	0x6580ea		0f86e9060000		JBE 0x6587d9											
  module.go:48552	0x6580f0		488b7830		MOVQ 0x30(AX), DI										
  module.go:63000	0x6580f4		4c8b442448		MOVQ 0x48(SP), R8										
  module.go:63000	0x6580f9		4d8d481b		LEAQ 0x1b(R8), R9										
  module.go:48553	0x6580fd		90			NOPL												
  module.go:62984	0x6580fe		458b543828		MOVL 0x28(R8)(DI*1), R10									
  module.go:63000	0x658103		4c39ce			CMPQ SI, R9											
  module.go:63000	0x658106		0f86c8060000		JBE 0x6587d4											
  module.go:63001	0x65810c		4589543818		MOVL R10, 0x18(R8)(DI*1)									
  module.go:48554	0x658111		488b7038		MOVQ 0x38(AX), SI										
  module.go:63009	0x658115		488b7c2438		MOVQ 0x38(SP), DI										
  module.go:63009	0x65811a		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:63009	0x658120		4839fe			CMPQ SI, DI											
  module.go:63009	0x658123		0f86a6060000		JBE 0x6587cf											
  module.go:48554	0x658129		488b7830		MOVQ 0x30(AX), DI										
  module.go:63026	0x65812d		4d8d5017		LEAQ 0x17(R8), R10										
  module.go:48555	0x658131		90			NOPL												
  module.go:63010	0x658132		4d8b5c3820		MOVQ 0x20(R8)(DI*1), R11									
  module.go:63010	0x658137		660f1f840000000000	NOPW 0(AX)(AX*1)										
  module.go:63026	0x658140		4c39d6			CMPQ SI, R10											
  module.go:63026	0x658143		0f8681060000		JBE 0x6587ca											
  module.go:63027	0x658149		4d895c3810		MOVQ R11, 0x10(R8)(DI*1)									
  module.go:48556	0x65814e		488b7038		MOVQ 0x38(AX), SI										
  module.go:62983	0x658152		8b7c2430		MOVL 0x30(SP), DI										
  module.go:62983	0x658156		4c8d5f03		LEAQ 0x3(DI), R11										
  module.go:62983	0x65815a		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:62983	0x658160		4c39de			CMPQ SI, R11											
  module.go:62983	0x658163		0f865c060000		JBE 0x6587c5											
  module.go:63000	0x658169		4c894c2440		MOVQ R9, 0x40(SP)										
  module.go:63026	0x65816e		4c89542438		MOVQ R10, 0x38(SP)										
  module.go:48556	0x658173		488b7030		MOVQ 0x30(AX), SI										
  module.go:62984	0x658177		8b3437			MOVL 0(DI)(SI*1), SI										
  module.go:48558	0x65817a		85f6			TESTL SI, SI											
  module.go:48558	0x65817c		7451			JE 0x6581cf											
  module.go:48559	0x65817e		4863f6			MOVSXD SI, SI											
  module.go:63164	0x658181		48397008		CMPQ 0x8(AX), SI										
  module.go:63164	0x658185		0f8622060000		JBE 0x6587ad											
  module.go:48559	0x65818b		48c1e604		SHLQ $0x4, SI											
  module.go:48559	0x65818f		4c8b18			MOVQ 0(AX), R11											
  module.go:48559	0x658192		4e8b241e		MOVQ 0(SI)(R11*1), R12										
  module.go:48559	0x658196		4a8b541e08		MOVQ 0x8(SI)(R11*1), DX										
  module.go:48559	0x65819b		488d1d3e671f00		LEAQ 0x1f673e(IP), BX										
  module.go:48559	0x6581a2		4939dc			CMPQ R12, BX											
  module.go:48559	0x6581a5		0f85f3050000		JNE 0x65879e											
  module.go:48559	0x6581ab		488b0a			MOVQ 0(DX), CX											
  module.go:48559	0x6581ae		8b442434		MOVL 0x34(SP), AX										
  module.go:48559	0x6581b2		ffd1			CALL CX												
  module.go:48561	0x6581b4		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:62983	0x6581bc		8b7c2430		MOVL 0x30(SP), DI										
  module.go:62984	0x6581c0		4c8b442448		MOVQ 0x48(SP), R8										
  module.go:62983	0x6581c5		4c8b4c2440		MOVQ 0x40(SP), R9										
  module.go:63009	0x6581ca		4c8b542438		MOVQ 0x38(SP), R10										
  module.go:48561	0x6581cf		488b5038		MOVQ 0x38(AX), DX										
  module.go:62983	0x6581d3		488d7707		LEAQ 0x7(DI), SI										
  module.go:62983	0x6581d7		660f1f840000000000	NOPW 0(AX)(AX*1)										
  module.go:62983	0x6581e0		4839f2			CMPQ DX, SI											
  module.go:62983	0x6581e3		0f86b0050000		JBE 0x658799											
  module.go:48561	0x6581e9		488b7030		MOVQ 0x30(AX), SI										
  module.go:62984	0x6581ed		8b4c3704		MOVL 0x4(DI)(SI*1), CX										
  module.go:48563	0x6581f1		85c9			TESTL CX, CX											
  module.go:48563	0x6581f3		7434			JE 0x658229											
  module.go:62983	0x6581f5		488d770b		LEAQ 0xb(DI), SI										
  module.go:48564	0x6581f9		90			NOPL												
  module.go:48564	0x6581fa		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:62983	0x658200		4839f2			CMPQ DX, SI											
  module.go:62983	0x658203		0f868b050000		JBE 0x658794											
  module.go:48565	0x658209		8b5c2434		MOVL 0x34(SP), BX										
  module.go:48565	0x65820d		e8ce3df7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn1(SB)			
  module.go:48567	0x658212		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:62984	0x65821a		4c8b442448		MOVQ 0x48(SP), R8										
  module.go:62983	0x65821f		4c8b4c2440		MOVQ 0x40(SP), R9										
  module.go:63009	0x658224		4c8b542438		MOVQ 0x38(SP), R10										
  module.go:48567	0x658229		488b4838		MOVQ 0x38(AX), CX										
  module.go:62983	0x65822d		4c39c9			CMPQ CX, R9											
  module.go:62983	0x658230		0f8659050000		JBE 0x65878f											
  module.go:48567	0x658236		488b5030		MOVQ 0x30(AX), DX										
  module.go:63000	0x65823a		488b742468		MOVQ 0x68(SP), SI										
  module.go:63000	0x65823f		488d7e0b		LEAQ 0xb(SI), DI										
  module.go:48568	0x658243		90			NOPL												
  module.go:62984	0x658244		458b4c1018		MOVL 0x18(R8)(DX*1), R9										
  module.go:63000	0x658249		4839f9			CMPQ CX, DI											
  module.go:63000	0x65824c		0f8638050000		JBE 0x65878a											
  module.go:63001	0x658252		44894c1608		MOVL R9, 0x8(SI)(DX*1)										
  module.go:48569	0x658257		488b4838		MOVQ 0x38(AX), CX										
  module.go:48569	0x65825b		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:63009	0x658260		4c39d1			CMPQ CX, R10											
  module.go:63009	0x658263		0f861c050000		JBE 0x658785											
  module.go:48569	0x658269		488b5030		MOVQ 0x30(AX), DX										
  module.go:48570	0x65826d		90			NOPL												
  module.go:63010	0x65826e		498b7c1010		MOVQ 0x10(R8)(DX*1), DI										
  module.go:63026	0x658273		4c8b442460		MOVQ 0x60(SP), R8										
  module.go:63026	0x658278		0f1f840000000000	NOPL 0(AX)(AX*1)										
  module.go:63026	0x658280		4c39c1			CMPQ CX, R8											
  module.go:63026	0x658283		0f86f5040000		JBE 0x65877e											
  module.go:63027	0x658289		488b4c2450		MOVQ 0x50(SP), CX										
  module.go:63027	0x65828e		48893c0a		MOVQ DI, 0(DX)(CX*1)										
  module.go:48571	0x658292		488b5038		MOVQ 0x38(AX), DX										
  module.go:63000	0x658296		488d7e0f		LEAQ 0xf(SI), DI										
  module.go:63000	0x65829a		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:63000	0x6582a0		4839fa			CMPQ DX, DI											
  module.go:63000	0x6582a3		0f86d0040000		JBE 0x658779											
  module.go:48571	0x6582a9		488b5030		MOVQ 0x30(AX), DX										
  module.go:63001	0x6582ad		c744160c01000000	MOVL $0x1, 0xc(SI)(DX*1)									
  module.go:62983	0x6582b5		4c89c7			MOVQ R8, DI											
  module.go:62983	0x6582b8		4c8b442458		MOVQ 0x58(SP), R8										
  module.go:62984	0x6582bd		4989c9			MOVQ CX, R9											
  module.go:48577	0x6582c0		4889c1			MOVQ AX, CX											
  module.go:48572	0x6582c3		e9b4010000		JMP 0x65847c											
  module.go:48512	0x6582c8		bb2c000000		MOVL $0x2c, BX											
  module.go:48512	0x6582cd		b901000000		MOVL $0x1, CX											
  module.go:48512	0x6582d2		e88940f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn4(SB)			
  module.go:48514	0x6582d7		85c0			TESTL AX, AX											
  module.go:48514	0x6582d9		0f8470040000		JE 0x65874f											
  module.go:48518	0x6582df		488b8c2480000000	MOVQ 0x80(SP), CX										
  module.go:48518	0x6582e7		488b5138		MOVQ 0x38(CX), DX										
  module.go:63026	0x6582eb		488b742468		MOVQ 0x68(SP), SI										
  module.go:63026	0x6582f0		488d7e0f		LEAQ 0xf(SI), DI										
  module.go:63026	0x6582f4		4839fa			CMPQ DX, DI											
  module.go:63026	0x6582f7		0f864d040000		JBE 0x65874a											
  module.go:48518	0x6582fd		488b5130		MOVQ 0x30(CX), DX										
  module.go:63027	0x658301		48bf2c00000002000000	MOVQ $0x20000002c, DI										
  module.go:63027	0x65830b		48897c1608		MOVQ DI, 0x8(SI)(DX*1)										
  module.go:48519	0x658310		488b5138		MOVQ 0x38(CX), DX										
  module.go:63000	0x658314		488b7c2460		MOVQ 0x60(SP), DI										
  module.go:63000	0x658319		0f1f8000000000		NOPL 0(AX)											
  module.go:63000	0x658320		4839fa			CMPQ DX, DI											
  module.go:63000	0x658323		0f861c040000		JBE 0x658745											
  module.go:48519	0x658329		488b5130		MOVQ 0x30(CX), DX										
  module.go:63001	0x65832d		89441604		MOVL AX, 0x4(SI)(DX*1)										
  module.go:48520	0x658331		488b5138		MOVQ 0x38(CX), DX										
  module.go:63000	0x658335		4c8b442458		MOVQ 0x58(SP), R8										
  module.go:63000	0x65833a		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:63000	0x658340		4c39c2			CMPQ DX, R8											
  module.go:63000	0x658343		0f86f3030000		JBE 0x65873c											
  module.go:48520	0x658349		488b5130		MOVQ 0x30(CX), DX										
  module.go:63001	0x65834d		4c8b4c2450		MOVQ 0x50(SP), R9										
  module.go:63001	0x658352		42c7040a2c000000	MOVL $0x2c, 0(DX)(R9*1)										
  module.go:48521	0x65835a		488b5138		MOVQ 0x38(CX), DX										
  module.go:48521	0x65835e		6690			NOPW												
  module.go:62983	0x658360		4881fa9b191000		CMPQ DX, $0x10199b										
  module.go:62983	0x658367		0f86c3030000		JBE 0x658730											
  module.go:48522	0x65836d		4189c2			MOVL AX, R10											
  module.go:63000	0x658370		4d8d5a2b		LEAQ 0x2b(R10), R11										
  module.go:63000	0x658374		4c39da			CMPQ DX, R11											
  module.go:63000	0x658377		0f86ae030000		JBE 0x65872b											
  module.go:48521	0x65837d		488b5130		MOVQ 0x30(CX), DX										
  module.go:62984	0x658381		448b9a98191000		MOVL 0x101998(DX), R11										
  module.go:63001	0x658388		45895c1228		MOVL R11, 0x28(R10)(DX*1)									
  module.go:48523	0x65838d		488b5138		MOVQ 0x38(CX), DX										
  module.go:63009	0x658391		4881fa97191000		CMPQ DX, $0x101997										
  module.go:63009	0x658398		0f8681030000		JBE 0x65871f											
  module.go:63026	0x65839e		4d8d5a27		LEAQ 0x27(R10), R11										
  module.go:48524	0x6583a2		90			NOPL												
  module.go:63026	0x6583a3		4c39da			CMPQ DX, R11											
  module.go:63026	0x6583a6		0f866e030000		JBE 0x65871a											
  module.go:48523	0x6583ac		488b5130		MOVQ 0x30(CX), DX										
  module.go:63010	0x6583b0		4c8b9a90191000		MOVQ 0x101990(DX), R11										
  module.go:63027	0x6583b7		4d895c1220		MOVQ R11, 0x20(R10)(DX*1)									
  module.go:48525	0x6583bc		488b5138		MOVQ 0x38(CX), DX										
  module.go:63009	0x6583c0		4881fa8f191000		CMPQ DX, $0x10198f										
  module.go:63009	0x6583c7		0f8641030000		JBE 0x65870e											
  module.go:63026	0x6583cd		4d8d5a1f		LEAQ 0x1f(R10), R11										
  module.go:48526	0x6583d1		90			NOPL												
  module.go:63026	0x6583d2		4c39da			CMPQ DX, R11											
  module.go:63026	0x6583d5		0f862e030000		JBE 0x658709											
  module.go:48525	0x6583db		488b5130		MOVQ 0x30(CX), DX										
  module.go:63010	0x6583df		4c8b9a88191000		MOVQ 0x101988(DX), R11										
  module.go:63027	0x6583e6		4d895c1218		MOVQ R11, 0x18(R10)(DX*1)									
  module.go:48527	0x6583eb		488b5138		MOVQ 0x38(CX), DX										
  module.go:63009	0x6583ef		4881fa87191000		CMPQ DX, $0x101987										
  module.go:63009	0x6583f6		0f8601030000		JBE 0x6586fd											
  module.go:63026	0x6583fc		4d8d5a17		LEAQ 0x17(R10), R11										
  module.go:48528	0x658400		90			NOPL												
  module.go:63026	0x658401		4c39da			CMPQ DX, R11											
  module.go:63026	0x658404		0f86ee020000		JBE 0x6586f8											
  module.go:48527	0x65840a		488b5130		MOVQ 0x30(CX), DX										
  module.go:63010	0x65840e		4c8b9a80191000		MOVQ 0x101980(DX), R11										
  module.go:63027	0x658415		4d895c1210		MOVQ R11, 0x10(R10)(DX*1)									
  module.go:48529	0x65841a		488b5138		MOVQ 0x38(CX), DX										
  module.go:48529	0x65841e		6690			NOPW												
  module.go:63009	0x658420		4881fa7f191000		CMPQ DX, $0x10197f										
  module.go:63009	0x658427		0f86bf020000		JBE 0x6586ec											
  module.go:63026	0x65842d		4d8d5a0f		LEAQ 0xf(R10), R11										
  module.go:48530	0x658431		90			NOPL												
  module.go:63026	0x658432		4c39da			CMPQ DX, R11											
  module.go:63026	0x658435		0f86ac020000		JBE 0x6586e7											
  module.go:48529	0x65843b		488b5130		MOVQ 0x30(CX), DX										
  module.go:63010	0x65843f		4c8b9a78191000		MOVQ 0x101978(DX), R11										
  module.go:63027	0x658446		4d895c1208		MOVQ R11, 0x8(R10)(DX*1)									
  module.go:48531	0x65844b		488b5138		MOVQ 0x38(CX), DX										
  module.go:63009	0x65844f		4881fa77191000		CMPQ DX, $0x101977										
  module.go:63009	0x658456		0f867f020000		JBE 0x6586db											
  module.go:63026	0x65845c		4983c207		ADDQ $0x7, R10											
  module.go:48532	0x658460		90			NOPL												
  module.go:63026	0x658461		4c39d2			CMPQ DX, R10											
  module.go:63026	0x658464		0f866c020000		JBE 0x6586d6											
  module.go:48531	0x65846a		488b5130		MOVQ 0x30(CX), DX										
  module.go:63010	0x65846e		4c8b9270191000		MOVQ 0x101970(DX), R10										
  module.go:63027	0x658475		4189c3			MOVL AX, R11											
  module.go:63027	0x658478		4e89141a		MOVQ R10, 0(DX)(R11*1)										
  module.go:48577	0x65847c		8b542428		MOVL 0x28(SP), DX										
  module.go:48577	0x658480		895150			MOVL DX, 0x50(CX)										
  module.go:48580	0x658483		488b5138		MOVQ 0x38(CX), DX										
  module.go:62983	0x658487		4c39c2			CMPQ DX, R8											
  module.go:62983	0x65848a		0f8641020000		JBE 0x6586d1											
  module.go:48580	0x658490		4c8b5130		MOVQ 0x30(CX), R10										
  module.go:62984	0x658494		478b1c11		MOVL 0(R9)(R10*1), R11										
  module.go:62984	0x658498		0f1f840000000000	NOPL 0(AX)(AX*1)										
  module.go:48582	0x6584a0		4183fbff		CMPL R11, $-0x1											
  module.go:48582	0x6584a4		0f85e2000000		JNE 0x65858c											
  module.go:48602	0x6584aa		90			NOPL												
  module.go:62983	0x6584ab		4881fa73ce1000		CMPQ DX, $0x10ce73										
  module.go:62983	0x6584b2		0f860d020000		JBE 0x6586c5											
  module.go:48603	0x6584b8		90			NOPL												
  module.go:63001	0x6584b9		41ff8270ce1000		INCL 0x10ce70(R10)										
  module.go:48604	0x6584c0		488b5138		MOVQ 0x38(CX), DX										
  module.go:48604	0x6584c4		4881fafccf1000		CMPQ DX, $0x10cffc										
  module.go:48604	0x6584cb		0f86e4010000		JBE 0x6586b5											
  module.go:48604	0x6584d1		488b5130		MOVQ 0x30(CX), DX										
  module.go:48604	0x6584d5		0fb692fccf1000		MOVZX 0x10cffc(DX), DX										
  module.go:48604	0x6584dc		0f1f4000		NOPL 0(AX)											
  module.go:48605	0x6584e0		83fa01			CMPL DX, $0x1											
  module.go:48605	0x6584e3		7410			JE 0x6584f5											
  module.go:48606	0x6584e5		4889c8			MOVQ CX, AX											
  module.go:48606	0x6584e8		e8f3f9faff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn105(SB)			
  module.go:48608	0x6584ed		488b8c2480000000	MOVQ 0x80(SP), CX										
  module.go:48608	0x6584f5		488b5138		MOVQ 0x38(CX), DX										
  module.go:48608	0x6584f9		0f1f8000000000		NOPL 0(AX)											
  module.go:62983	0x658500		4881fad3cf1000		CMPQ DX, $0x10cfd3										
  module.go:62983	0x658507		0f869c010000		JBE 0x6586a9											
  module.go:48608	0x65850d		488b7130		MOVQ 0x30(CX), SI										
  module.go:62984	0x658511		83bed0cf100000		CMPL 0x10cfd0(SI), $0x0										
  module.go:48609	0x658518		0f856b010000		JNE 0x658689											
  module.go:48613	0x65851e		90			NOPL												
  module.go:48613	0x65851f		90			NOPL												
  module.go:62983	0x658520		4881fae7cf1000		CMPQ DX, $0x10cfe7										
  module.go:62983	0x658527		0f8650010000		JBE 0x65867d											
  module.go:48614	0x65852d		90			NOPL												
  module.go:63000	0x65852e		4881faefcf1000		CMPQ DX, $0x10cfef										
  module.go:63000	0x658535		0f8636010000		JBE 0x658671											
  module.go:62984	0x65853b		8b96e4cf1000		MOVL 0x10cfe4(SI), DX										
  module.go:63001	0x658541		8996eccf1000		MOVL DX, 0x10cfec(SI)										
  module.go:48615	0x658547		488b5138		MOVQ 0x38(CX), DX										
  module.go:63000	0x65854b		4881faebcf1000		CMPQ DX, $0x10cfeb										
  module.go:63000	0x658552		0f860d010000		JBE 0x658665											
  module.go:48615	0x658558		488b5130		MOVQ 0x30(CX), DX										
  module.go:63001	0x65855c		c782e8cf100000000000	MOVL $0x0, 0x10cfe8(DX)										
  module.go:48616	0x658566		488b5138		MOVQ 0x38(CX), DX										
  module.go:63000	0x65856a		4881faf3cf1000		CMPQ DX, $0x10cff3										
  module.go:63000	0x658571		0f86dd000000		JBE 0x658654											
  module.go:48616	0x658577		488b5130		MOVQ 0x30(CX), DX										
  module.go:63001	0x65857b		c782f0cf100000000000	MOVL $0x0, 0x10cff0(DX)										
  module.go:63001	0x658585		31c0			XORL AX, AX											
  module.go:48619	0x658587		e996000000		JMP 0x658622											
  module.go:48585	0x65858c		90			NOPL												
  module.go:62983	0x65858d		4839fa			CMPQ DX, DI											
  module.go:62983	0x658590		0f86b9000000		JBE 0x65864f											
  module.go:63009	0x658596		4c8d660f		LEAQ 0xf(SI), R12										
  module.go:48587	0x65859a		90			NOPL												
  module.go:62984	0x65859b		468b6c1604		MOVL 0x4(SI)(R10*1), R13									
  module.go:63009	0x6585a0		4c39e2			CMPQ DX, R12											
  module.go:63009	0x6585a3		0f86a1000000		JBE 0x65864a											
  module.go:63010	0x6585a9		4a8b541608		MOVQ 0x8(SI)(R10*1), DX										
  module.go:48592	0x6585ae		4889c8			MOVQ CX, AX											
  module.go:48597	0x6585b1		8b5c2420		MOVL 0x20(SP), BX										
  module.go:63001	0x6585b5		4d89ca			MOVQ R9, R10											
  module.go:48591	0x6585b8		4489e9			MOVL R13, CX											
  module.go:63000	0x6585bb		4989f9			MOVQ DI, R9											
  module.go:63000	0x6585be		4c89c7			MOVQ R8, DI											
  module.go:63026	0x6585c1		4989f0			MOVQ SI, R8											
  module.go:48592	0x6585c4		488b7038		MOVQ 0x38(AX), SI										
  module.go:62983	0x6585c8		4881fe73ce1000		CMPQ SI, $0x10ce73										
  module.go:62983	0x6585cf		766d			JBE 0x65863e											
  module.go:48592	0x6585d1		488b7030		MOVQ 0x30(AX), SI										
  module.go:63026	0x6585d5		4d8d600f		LEAQ 0xf(R8), R12										
  module.go:48593	0x6585d9		90			NOPL												
  module.go:63001	0x6585da		ff8670ce1000		INCL 0x10ce70(SI)										
  module.go:48594	0x6585e0		488b7038		MOVQ 0x38(AX), SI										
  module.go:63026	0x6585e4		4c39e6			CMPQ SI, R12											
  module.go:63026	0x6585e7		7650			JBE 0x658639											
  module.go:48594	0x6585e9		488b7030		MOVQ 0x30(AX), SI										
  module.go:63027	0x6585ed		4989543008		MOVQ DX, 0x8(R8)(SI*1)										
  module.go:48595	0x6585f2		488b5038		MOVQ 0x38(AX), DX										
  module.go:63000	0x6585f6		4c39ca			CMPQ DX, R9											
  module.go:63000	0x6585f9		7639			JBE 0x658634											
  module.go:48595	0x6585fb		488b5030		MOVQ 0x30(AX), DX										
  module.go:63001	0x6585ff		41894c1004		MOVL CX, 0x4(R8)(DX*1)										
  module.go:48596	0x658604		488b4838		MOVQ 0x38(AX), CX										
  module.go:63000	0x658608		4839f9			CMPQ CX, DI											
  module.go:63000	0x65860b		7622			JBE 0x65862f											
  module.go:48596	0x65860d		488b4830		MOVQ 0x30(AX), CX										
  module.go:63001	0x658611		46891c11		MOVL R11, 0(CX)(R10*1)										
  module.go:48597	0x658615		e88644f8ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn60(SB)			
  module.go:48620	0x65861a		488b8c2480000000	MOVQ 0x80(SP), CX										
  module.go:48620	0x658622		8b54242c		MOVL 0x2c(SP), DX										
  module.go:48620	0x658626		895150			MOVL DX, 0x50(CX)										
  module.go:48621	0x658629		4883c470		ADDQ $0x70, SP											
  module.go:48621	0x65862d		5d			POPQ BP												
  module.go:48621	0x65862e		c3			RET												
  module.go:63000	0x65862f		e88c83e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x658634		e88783e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x658639		e88283e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x65863e		48c7c073ce1000		MOVQ $0x10ce73, AX										
  module.go:62983	0x658645		e87683e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x65864a		e87183e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x65864f		e86c83e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x658654		48c7c0f3cf1000		MOVQ $0x10cff3, AX										
  module.go:63000	0x65865b		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:63000	0x658660		e85b83e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x658665		48c7c0ebcf1000		MOVQ $0x10cfeb, AX										
  module.go:63000	0x65866c		e84f83e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x658671		48c7c0efcf1000		MOVQ $0x10cfef, AX										
  module.go:63000	0x658678		e84383e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x65867d		48c7c0e7cf1000		MOVQ $0x10cfe7, AX										
  module.go:62983	0x658684		e83783e3ff		CALL runtime.panicBounds(SB)									
  module.go:48610	0x658689		4889c8			MOVQ CX, AX											
  module.go:48610	0x65868c		bb60171000		MOVL $0x101760, BX										
  module.go:48610	0x658691		e84aa9f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn24(SB)			
  module.go:48611	0x658696		488d0583431f00		LEAQ 0x1f4383(IP), AX										
  module.go:48611	0x65869d		488d1d4cbc2a00		LEAQ 0x2abc4c(IP), BX										
  module.go:48611	0x6586a4		e83701e3ff		CALL runtime.gopanic(SB)									
  module.go:62983	0x6586a9		48c7c0d3cf1000		MOVQ $0x10cfd3, AX										
  module.go:62983	0x6586b0		e80b83e3ff		CALL runtime.panicBounds(SB)									
  module.go:48604	0x6586b5		48c7c0fccf1000		MOVQ $0x10cffc, AX										
  module.go:48604	0x6586bc		0f1f4000		NOPL 0(AX)											
  module.go:48604	0x6586c0		e8fb82e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x6586c5		48c7c073ce1000		MOVQ $0x10ce73, AX										
  module.go:62983	0x6586cc		e8ef82e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x6586d1		e8ea82e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x6586d6		e8e582e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x6586db		48c7c077191000		MOVQ $0x101977, AX										
  module.go:63009	0x6586e2		e8d982e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x6586e7		e8d482e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x6586ec		48c7c07f191000		MOVQ $0x10197f, AX										
  module.go:63009	0x6586f3		e8c882e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x6586f8		e8c382e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x6586fd		48c7c087191000		MOVQ $0x101987, AX										
  module.go:63009	0x658704		e8b782e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x658709		e8b282e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x65870e		48c7c08f191000		MOVQ $0x10198f, AX										
  module.go:63009	0x658715		e8a682e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x65871a		e8a182e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x65871f		48c7c097191000		MOVQ $0x101997, AX										
  module.go:63009	0x658726		e89582e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x65872b		e89082e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x658730		48c7c09b191000		MOVQ $0x10199b, AX										
  module.go:62983	0x658737		e88482e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x65873c		0f1f4000		NOPL 0(AX)											
  module.go:63000	0x658740		e87b82e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x658745		e87682e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x65874a		e87182e3ff		CALL runtime.panicBounds(SB)									
  module.go:48515	0x65874f		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48515	0x658757		bb01000000		MOVL $0x1, BX											
  module.go:48515	0x65875c		b92c000000		MOVL $0x2c, CX											
  module.go:48515	0x658761		e87a39f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn2(SB)			
  module.go:48516	0x658766		488d05b3421f00		LEAQ 0x1f42b3(IP), AX										
  module.go:48516	0x65876d		488d1d7cbb2a00		LEAQ 0x2abb7c(IP), BX										
  module.go:48516	0x658774		e86700e3ff		CALL runtime.gopanic(SB)									
  module.go:63000	0x658779		e84282e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x65877e		6690			NOPW												
  module.go:63026	0x658780		e83b82e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x658785		e83682e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x65878a		e83182e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x65878f		e82c82e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x658794		e82782e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x658799		e82282e3ff		CALL runtime.panicBounds(SB)									
  module.go:48559	0x65879e		4c89e0			MOVQ R12, AX											
  module.go:48559	0x6587a1		488d0d78532000		LEAQ 0x205378(IP), CX										
  module.go:48559	0x6587a8		e8d359dcff		CALL runtime.panicdottypeE(SB)									
  module.go:63165	0x6587ad		488d056c421f00		LEAQ 0x1f426c(IP), AX										
  module.go:63165	0x6587b4		488d1d85d22a00		LEAQ 0x2ad285(IP), BX										
  module.go:63165	0x6587bb		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:63165	0x6587c0		e81b00e3ff		CALL runtime.gopanic(SB)									
  module.go:62983	0x6587c5		e8f681e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x6587ca		e8f181e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x6587cf		e8ec81e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x6587d4		e8e781e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x6587d9		e8e281e3ff		CALL runtime.panicBounds(SB)									
  module.go:48549	0x6587de		8b7c2428		MOVL 0x28(SP), DI										
  module.go:48549	0x6587e2		ffcf			DECL DI												
  module.go:48549	0x6587e4		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48549	0x6587ec		bbf01a1000		MOVL $0x101af0, BX										
  module.go:48549	0x6587f1		b937000000		MOVL $0x37, CX											
  module.go:48549	0x6587f6		bee01a1000		MOVL $0x101ae0, SI										
  module.go:48549	0x6587fb		41b8281b1000		MOVL $0x101b28, R8										
  module.go:48549	0x658801		e89aabf7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn27(SB)			
  module.go:48550	0x658806		488d0513421f00		LEAQ 0x1f4213(IP), AX										
  module.go:48550	0x65880d		488d1ddcba2a00		LEAQ 0x2abadc(IP), BX										
  module.go:48550	0x658814		e8c7ffe2ff		CALL runtime.gopanic(SB)									
  module.go:48547	0x658819		4c89e8			MOVQ R13, AX											
  module.go:48547	0x65881c		4889fb			MOVQ DI, BX											
  module.go:48547	0x65881f		488d0dfa522000		LEAQ 0x2052fa(IP), CX										
  module.go:48547	0x658826		e85559dcff		CALL runtime.panicdottypeE(SB)									
  module.go:63165	0x65882b		488d05ee411f00		LEAQ 0x1f41ee(IP), AX										
  module.go:63165	0x658832		488d1d07d22a00		LEAQ 0x2ad207(IP), BX										
  module.go:63165	0x658839		e8a2ffe2ff		CALL runtime.gopanic(SB)									
  module.go:62983	0x65883e		6690			NOPW												
  module.go:62983	0x658840		e87b81e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x658845		e87681e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x65884a		e87181e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x65884f		e86c81e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x658854		e86781e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x658859		e86281e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x65885e		6690			NOPW												
  module.go:62983	0x658860		e85b81e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x658865		e85681e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x65886a		e85181e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x65886f		e84c81e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x658874		e84781e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x658879		e84281e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x65887e		48c7c083ce1000		MOVQ $0x10ce83, AX										
  module.go:62983	0x658885		e83681e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x65888a		48c7c07fce1000		MOVQ $0x10ce7f, AX										
  module.go:62983	0x658891		e82a81e3ff		CALL runtime.panicBounds(SB)									
  module.go:48623	0x658896		bb60171000		MOVL $0x101760, BX										
  module.go:48623	0x65889b		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:48623	0x6588a0		e83ba7f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn24(SB)			
  module.go:48624	0x6588a5		488d0574411f00		LEAQ 0x1f4174(IP), AX										
  module.go:48624	0x6588ac		488d1d3dba2a00		LEAQ 0x2aba3d(IP), BX										
  module.go:48624	0x6588b3		e828ffe2ff		CALL runtime.gopanic(SB)									
  module.go:62983	0x6588b8		48c7c073ce1000		MOVQ $0x10ce73, AX										
  module.go:62983	0x6588bf		90			NOPL												
  module.go:62983	0x6588c0		e8fb80e3ff		CALL runtime.panicBounds(SB)									
  module.go:48463	0x6588c5		48c7c0b0cf1000		MOVQ $0x10cfb0, AX										
  module.go:48463	0x6588cc		e8ef80e3ff		CALL runtime.panicBounds(SB)									
  module.go:48463	0x6588d1		90			NOPL												
  module.go:48457	0x6588d2		4889442408		MOVQ AX, 0x8(SP)										
  module.go:48457	0x6588d7		48895c2410		MOVQ BX, 0x10(SP)										
  module.go:48457	0x6588dc		f20f11442418		MOVSD_XMM X0, 0x18(SP)										
  module.go:48457	0x6588e2		e8b963e3ff		CALL runtime.morestack_noctxt.abi0(SB)								
  module.go:48457	0x6588e7		488b442408		MOVQ 0x8(SP), AX										
  module.go:48457	0x6588ec		488b5c2410		MOVQ 0x10(SP), BX										
  module.go:48457	0x6588f1		f20f10442418		MOVSD_XMM 0x18(SP), X0										
  module.go:48457	0x6588f7		e944f4ffff		JMP dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).Xcocoon_sketch_add(SB)	
