TEXT dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).Xcocoon_sketch_add(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/internal/wasm/module.go
  module.go:48457	0x656660		493b6610		CMPQ SP, 0x10(R14)										
  module.go:48457	0x656664		0f86880b0000		JBE 0x6571f2											
  module.go:48457	0x65666a		55			PUSHQ BP											
  module.go:48457	0x65666b		4889e5			MOVQ SP, BP											
  module.go:48457	0x65666e		4883ec70		SUBQ $0x70, SP											
  module.go:48460	0x656672		8b5050			MOVL 0x50(AX), DX										
  module.go:48461	0x656675		448d42f0		LEAL -0x10(DX), R8										
  module.go:48462	0x656679		44894050		MOVL R8, 0x50(AX)										
  module.go:48463	0x65667d		4c8b4838		MOVQ 0x38(AX), R9										
  module.go:48463	0x656681		4981f9b0cf1000		CMPQ R9, $0x10cfb0										
  module.go:48463	0x656688		0f86570b0000		JBE 0x6571e5											
  module.go:48463	0x65668e		4889842480000000	MOVQ AX, 0x80(SP)										
  module.go:48463	0x656696		f20f11842490000000	MOVSD_XMM X0, 0x90(SP)										
  module.go:48460	0x65669f		8954242c		MOVL DX, 0x2c(SP)										
  module.go:48461	0x6566a3		4489442420		MOVL R8, 0x20(SP)										
  module.go:48463	0x6566a8		4c8b4830		MOVQ 0x30(AX), R9										
  module.go:48463	0x6566ac		450fb689b0cf1000	MOVZX 0x10cfb0(R9), R9										
  module.go:48464	0x6566b4		4183f901		CMPL R9, $0x1											
  module.go:48464	0x6566b8		742f			JE 0x6566e9											
  module.go:48463	0x6566ba		48899c2488000000	MOVQ BX, 0x88(SP)										
  module.go:48465	0x6566c2		e8f9f6f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn41(SB)			
  module.go:48468	0x6566c7		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48620	0x6566cf		8b54242c		MOVL 0x2c(SP), DX										
  module.go:48473	0x6566d3		488b9c2488000000	MOVQ 0x88(SP), BX										
  module.go:48474	0x6566db		448b442420		MOVL 0x20(SP), R8										
  unsafe.go:35		0x6566e0		f20f10842490000000	MOVSD_XMM 0x90(SP), X0										
  module.go:48468	0x6566e9		4c8b4838		MOVQ 0x38(AX), R9										
  module.go:62983	0x6566ed		4981f973ce1000		CMPQ R9, $0x10ce73										
  module.go:62983	0x6566f4		0f86de0a0000		JBE 0x6571d8											
  module.go:48468	0x6566fa		4c8b4830		MOVQ 0x30(AX), R9										
  module.go:62984	0x6566fe		4183b970ce100000	CMPL 0x10ce70(R9), $0x0										
  module.go:48469	0x656706		0f85aa0a0000		JNE 0x6571b6											
  module.go:48470	0x65670c		90			NOPL												
  module.go:63001	0x65670d		41c78170ce1000ffffffff	MOVL $-0x1, 0x10ce70(R9)									
  module.go:48471	0x656718		4c8b4838		MOVQ 0x38(AX), R9										
  module.go:48471	0x65671c		0f1f4000		NOPL 0(AX)											
  module.go:62983	0x656720		4981f97fce1000		CMPQ R9, $0x10ce7f										
  module.go:62983	0x656727		0f867d0a0000		JBE 0x6571aa											
  module.go:48472	0x65672d		90			NOPL												
  module.go:62983	0x65672e		4981f983ce1000		CMPQ R9, $0x10ce83										
  module.go:62983	0x656735		0f86630a0000		JBE 0x65719e											
  module.go:48471	0x65673b		488b5030		MOVQ 0x30(AX), DX										
  module.go:48474	0x65673f		4589c1			MOVL R8, R9											
  module.go:48474	0x656742		4c894c2468		MOVQ R9, 0x68(SP)										
  module.go:62984	0x656747		8b8a7cce1000		MOVL 0x10ce7c(DX), CX										
  module.go:62984	0x65674d		8bba80ce1000		MOVL 0x10ce80(DX), DI										
  module.go:48473	0x656753		4889de			MOVQ BX, SI											
  module.go:48473	0x656756		4489c3			MOVL R8, BX											
  module.go:48473	0x656759		e842d0f8ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn84(SB)			
  module.go:48474	0x65675e		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48474	0x656766		488b5038		MOVQ 0x38(AX), DX										
  module.go:62983	0x65676a		4c8b442468		MOVQ 0x68(SP), R8										
  module.go:62983	0x65676f		4d8d4807		LEAQ 0x7(R8), R9										
  module.go:62983	0x656773		4c39ca			CMPQ DX, R9											
  module.go:62983	0x656776		0f861d0a0000		JBE 0x657199											
  module.go:48474	0x65677c		488b7030		MOVQ 0x30(AX), SI										
  module.go:62983	0x656780		498d7803		LEAQ 0x3(R8), DI										
  module.go:48481	0x656784		90			NOPL												
  module.go:62984	0x656785		418b4c3004		MOVL 0x4(R8)(SI*1), CX										
  module.go:62983	0x65678a		4839fa			CMPQ DX, DI											
  module.go:62983	0x65678d		0f86010a0000		JBE 0x657194											
  module.go:62984	0x656793		8b5c2420		MOVL 0x20(SP), BX										
  module.go:62984	0x656797		4189da			MOVL BX, R10											
  module.go:62984	0x65679a		458b1c32		MOVL 0(R10)(SI*1), R11										
  module.go:62984	0x65679e		6690			NOPW												
  module.go:48483	0x6567a0		4183fbff		CMPL R11, $-0x1											
  module.go:48483	0x6567a4		7418			JE 0x6567be											
  module.go:63009	0x6567a6		4d8d600f		LEAQ 0xf(R8), R12										
  module.go:48484	0x6567aa		90			NOPL												
  module.go:63009	0x6567ab		4c39e2			CMPQ DX, R12											
  module.go:63009	0x6567ae		0f86db090000		JBE 0x65718f											
  module.go:63010	0x6567b4		498b543008		MOVQ 0x8(R8)(SI*1), DX										
  module.go:48486	0x6567b9		e926070000		JMP 0x656ee4											
  module.go:62983	0x6567be		4c894c2460		MOVQ R9, 0x60(SP)										
  module.go:62983	0x6567c3		48897c2458		MOVQ DI, 0x58(SP)										
  module.go:62984	0x6567c8		4c89542450		MOVQ R10, 0x50(SP)										
  module.go:48488	0x6567cd		8b5050			MOVL 0x50(AX), DX										
  module.go:48488	0x6567d0		89542428		MOVL DX, 0x28(SP)										
  module.go:48489	0x6567d4		8d72c0			LEAL -0x40(DX), SI										
  module.go:48490	0x6567d7		897050			MOVL SI, 0x50(AX)										
  unsafe.go:35		0x6567da		f20f10842490000000	MOVSD_XMM 0x90(SP), X0										
  unsafe.go:35		0x6567e3		66490f7ec3		MOVQ X0, R11											
  module.go:48493	0x6567e8		4d89dc			MOVQ R11, R12											
  module.go:48493	0x6567eb		490fbaf33f		BTRQ $0x3f, R11											
  module.go:48499	0x6567f0		4d8d6c24ff		LEAQ -0x1(R12), R13										
  module.go:48504	0x6567f5		49bf000000000000f0ff	MOVQ $0xfff0000000000000, R15									
  module.go:48504	0x6567ff		4d01df			ADDQ R11, R15											
  module.go:48492	0x656802		90			NOPL												
  module.go:48495	0x656803		4d85db			TESTQ R11, R11											
  module.go:48495	0x656806		410f94c3		SETE R11											
  module.go:48498	0x65680a		450fb6db		MOVZX R11, R11											
  module.go:48499	0x65680e		49b8ffffffffffff0f00	MOVQ $0xfffffffffffff, R8									
  module.go:48499	0x656818		4d39e8			CMPQ R8, R13											
  module.go:48499	0x65681b		410f97c0		SETA R8												
  module.go:48502	0x65681f		450fb6c0		MOVZX R8, R8											
  module.go:48502	0x656823		4509c3			ORL R8, R11											
  module.go:48504	0x656826		49b8000000000000e07f	MOVQ $0x7fe0000000000000, R8									
  module.go:48504	0x656830		4d39f8			CMPQ R8, R15											
  module.go:48504	0x656833		410f97c0		SETA R8												
  module.go:48507	0x656837		450fb6c0		MOVZX R8, R8											
  module.go:48508	0x65683b		4d85e4			TESTQ R12, R12											
  module.go:48508	0x65683e		410f9dc4		SETGE R12											
  module.go:48511	0x656842		450fb6e4		MOVZX R12, R12											
  module.go:48511	0x656846		4521e0			ANDL R12, R8											
  module.go:48511	0x656849		4509d8			ORL R11, R8											
  module.go:48511	0x65684c		4585c0			TESTL R8, R8											
  module.go:48511	0x65684f		0f8493030000		JE 0x656be8											
  module.go:48489	0x656855		89742424		MOVL SI, 0x24(SP)										
  module.go:48535	0x656859		8d5ac8			LEAL -0x38(DX), BX										
  module.go:48535	0x65685c		0f1f4000		NOPL 0(AX)											
  module.go:48535	0x656860		e8bb96fdff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn176(SB)			
  module.go:48536	0x656865		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48536	0x65686d		488b5038		MOVQ 0x38(AX), DX										
  module.go:48536	0x656871		8b742424		MOVL 0x24(SP), SI										
  module.go:48536	0x656875		89f6			MOVL SI, SI											
  module.go:62983	0x656877		488d7e0b		LEAQ 0xb(SI), DI										
  module.go:62983	0x65687b		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:62983	0x656880		4839fa			CMPQ DX, DI											
  module.go:62983	0x656883		0f8601090000		JBE 0x65718a											
  module.go:48536	0x656889		488b7830		MOVQ 0x30(AX), DI										
  module.go:62984	0x65688d		448b443e08		MOVL 0x8(SI)(DI*1), R8										
  module.go:48538	0x656892		4585c0			TESTL R8, R8											
  module.go:48538	0x656895		7536			JNE 0x6568cd											
  module.go:48574	0x656897		90			NOPL												
  module.go:63000	0x656898		488b4c2458		MOVQ 0x58(SP), CX										
  module.go:63000	0x65689d		0f1f00			NOPL 0(AX)											
  module.go:63000	0x6568a0		4839ca			CMPQ DX, CX											
  module.go:63000	0x6568a3		0f86dc080000		JBE 0x657185											
  module.go:63001	0x6568a9		488b542450		MOVQ 0x50(SP), DX										
  module.go:63001	0x6568ae		c70417ffffffff		MOVL $-0x1, 0(DI)(DX*1)										
  module.go:63009	0x6568b5		488b742468		MOVQ 0x68(SP), SI										
  module.go:62983	0x6568ba		488b7c2460		MOVQ 0x60(SP), DI										
  module.go:62983	0x6568bf		4989c8			MOVQ CX, R8											
  module.go:62984	0x6568c2		4989d1			MOVQ DX, R9											
  module.go:48577	0x6568c5		4889c1			MOVQ AX, CX											
  module.go:48577	0x6568c8		e9cf040000		JMP 0x656d9c											
  module.go:62983	0x6568cd		4c8d4e0f		LEAQ 0xf(SI), R9										
  module.go:48539	0x6568d1		90			NOPL												
  module.go:62983	0x6568d2		4c39ca			CMPQ DX, R9											
  module.go:62983	0x6568d5		0f86a3080000		JBE 0x65717e											
  module.go:63000	0x6568db		4c8d4e2b		LEAQ 0x2b(SI), R9										
  module.go:48541	0x6568df		90			NOPL												
  module.go:62984	0x6568e0		448b543e0c		MOVL 0xc(SI)(DI*1), R10										
  module.go:63000	0x6568e5		4c39ca			CMPQ DX, R9											
  module.go:63000	0x6568e8		0f868b080000		JBE 0x657179											
  module.go:63001	0x6568ee		c7443e2800000000	MOVL $0x0, 0x28(SI)(DI*1)									
  module.go:48542	0x6568f6		488b7838		MOVQ 0x38(AX), DI										
  module.go:63026	0x6568fa		4c8d5e27		LEAQ 0x27(SI), R11										
  module.go:63026	0x6568fe		6690			NOPW												
  module.go:63026	0x656900		4c39df			CMPQ DI, R11											
  module.go:63026	0x656903		0f866b080000		JBE 0x657174											
  module.go:48542	0x656909		488b7830		MOVQ 0x30(AX), DI										
  module.go:63027	0x65690d		49bc0000000001000000	MOVQ $0x100000000, R12										
  module.go:63027	0x656917		4c89643e20		MOVQ R12, 0x20(SI)(DI*1)									
  module.go:48543	0x65691c		488b7838		MOVQ 0x38(AX), DI										
  module.go:63000	0x656920		4c8d6633		LEAQ 0x33(SI), R12										
  module.go:63000	0x656924		4c39e7			CMPQ DI, R12											
  module.go:63000	0x656927		0f8642080000		JBE 0x65716f											
  module.go:48543	0x65692d		488b7830		MOVQ 0x30(AX), DI										
  module.go:63001	0x656931		c7443e30c81a1000	MOVL $0x101ac8, 0x30(SI)(DI*1)									
  module.go:48544	0x656939		488b7838		MOVQ 0x38(AX), DI										
  module.go:63026	0x65693d		4c8d663b		LEAQ 0x3b(SI), R12										
  module.go:63026	0x656941		4c39e7			CMPQ DI, R12											
  module.go:63026	0x656944		0f8620080000		JBE 0x65716a											
  module.go:48544	0x65694a		488b7830		MOVQ 0x30(AX), DI										
  module.go:63027	0x65694e		48c7443e3420000060	MOVQ $0x60000020, 0x34(SI)(DI*1)								
  module.go:48545	0x656957		488b7838		MOVQ 0x38(AX), DI										
  module.go:63000	0x65695b		4c8d662f		LEAQ 0x2f(SI), R12										
  module.go:63000	0x65695f		90			NOPL												
  module.go:63000	0x656960		4c39e7			CMPQ DI, R12											
  module.go:63000	0x656963		0f86fc070000		JBE 0x657165											
  module.go:48545	0x656969		488b7830		MOVQ 0x30(AX), DI										
  module.go:48545	0x65696d		8b5c2428		MOVL 0x28(SP), BX										
  module.go:48545	0x656971		448d63e0		LEAL -0x20(BX), R12										
  module.go:63001	0x656975		4489643e2c		MOVL R12, 0x2c(SI)(DI*1)									
  module.go:48546	0x65697a		488b7838		MOVQ 0x38(AX), DI										
  module.go:62983	0x65697e		4d8d6213		LEAQ 0x13(R10), R12										
  module.go:62983	0x656982		4c39e7			CMPQ DI, R12											
  module.go:62983	0x656985		0f86d3070000		JBE 0x65715e											
  module.go:48546	0x65698b		488b7830		MOVQ 0x30(AX), DI										
  module.go:62984	0x65698f		498d3c3a		LEAQ 0(R10)(DI*1), DI										
  module.go:62984	0x656993		488d7f10		LEAQ 0x10(DI), DI										
  module.go:62984	0x656997		48633f			MOVSXD 0(DI), DI										
  module.go:62984	0x65699a		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:63164	0x6569a0		48397808		CMPQ 0x8(AX), DI										
  module.go:63164	0x6569a4		0f86a1070000		JBE 0x65714b											
  module.go:48547	0x6569aa		48c1e704		SHLQ $0x4, DI											
  module.go:48547	0x6569ae		4c8b20			MOVQ 0(AX), R12											
  module.go:48547	0x6569b1		4e8b2c27		MOVQ 0(DI)(R12*1), R13										
  module.go:48547	0x6569b5		4a8b542708		MOVQ 0x8(DI)(R12*1), DX										
  module.go:48547	0x6569ba		488d3d9f4d2000		LEAQ 0x204d9f(IP), DI										
  module.go:48547	0x6569c1		4939fd			CMPQ R13, DI											
  module.go:48547	0x6569c4		0f856f070000		JNE 0x657139											
  module.go:48536	0x6569ca		4889742448		MOVQ SI, 0x48(SP)										
  module.go:62984	0x6569cf		4489442434		MOVL R8, 0x34(SP)										
  module.go:62984	0x6569d4		4489542430		MOVL R10, 0x30(SP)										
  module.go:63000	0x6569d9		4c894c2440		MOVQ R9, 0x40(SP)										
  module.go:63026	0x6569de		4c895c2438		MOVQ R11, 0x38(SP)										
  module.go:48547	0x6569e3		488b0a			MOVQ 0(DX), CX											
  module.go:48547	0x6569e6		83c3ec			ADDL $-0x14, BX											
  module.go:48547	0x6569e9		4489c0			MOVL R8, AX											
  module.go:48547	0x6569ec		ffd1			CALL CX												
  module.go:48548	0x6569ee		85c0			TESTL AX, AX											
  module.go:48548	0x6569f0		0f8508070000		JNE 0x6570fe											
  module.go:48552	0x6569f6		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48552	0x6569fe		488b7038		MOVQ 0x38(AX), SI										
  module.go:62983	0x656a02		488b7c2440		MOVQ 0x40(SP), DI										
  module.go:62983	0x656a07		4839fe			CMPQ SI, DI											
  module.go:62983	0x656a0a		0f86e9060000		JBE 0x6570f9											
  module.go:48552	0x656a10		488b7830		MOVQ 0x30(AX), DI										
  module.go:63000	0x656a14		4c8b442448		MOVQ 0x48(SP), R8										
  module.go:63000	0x656a19		4d8d481b		LEAQ 0x1b(R8), R9										
  module.go:48553	0x656a1d		90			NOPL												
  module.go:62984	0x656a1e		458b543828		MOVL 0x28(R8)(DI*1), R10									
  module.go:63000	0x656a23		4c39ce			CMPQ SI, R9											
  module.go:63000	0x656a26		0f86c8060000		JBE 0x6570f4											
  module.go:63001	0x656a2c		4589543818		MOVL R10, 0x18(R8)(DI*1)									
  module.go:48554	0x656a31		488b7038		MOVQ 0x38(AX), SI										
  module.go:63009	0x656a35		488b7c2438		MOVQ 0x38(SP), DI										
  module.go:63009	0x656a3a		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:63009	0x656a40		4839fe			CMPQ SI, DI											
  module.go:63009	0x656a43		0f86a6060000		JBE 0x6570ef											
  module.go:48554	0x656a49		488b7830		MOVQ 0x30(AX), DI										
  module.go:63026	0x656a4d		4d8d5017		LEAQ 0x17(R8), R10										
  module.go:48555	0x656a51		90			NOPL												
  module.go:63010	0x656a52		4d8b5c3820		MOVQ 0x20(R8)(DI*1), R11									
  module.go:63010	0x656a57		660f1f840000000000	NOPW 0(AX)(AX*1)										
  module.go:63026	0x656a60		4c39d6			CMPQ SI, R10											
  module.go:63026	0x656a63		0f8681060000		JBE 0x6570ea											
  module.go:63027	0x656a69		4d895c3810		MOVQ R11, 0x10(R8)(DI*1)									
  module.go:48556	0x656a6e		488b7038		MOVQ 0x38(AX), SI										
  module.go:62983	0x656a72		8b7c2430		MOVL 0x30(SP), DI										
  module.go:62983	0x656a76		4c8d5f03		LEAQ 0x3(DI), R11										
  module.go:62983	0x656a7a		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:62983	0x656a80		4c39de			CMPQ SI, R11											
  module.go:62983	0x656a83		0f865c060000		JBE 0x6570e5											
  module.go:63000	0x656a89		4c894c2440		MOVQ R9, 0x40(SP)										
  module.go:63026	0x656a8e		4c89542438		MOVQ R10, 0x38(SP)										
  module.go:48556	0x656a93		488b7030		MOVQ 0x30(AX), SI										
  module.go:62984	0x656a97		8b3437			MOVL 0(DI)(SI*1), SI										
  module.go:48558	0x656a9a		85f6			TESTL SI, SI											
  module.go:48558	0x656a9c		7451			JE 0x656aef											
  module.go:48559	0x656a9e		4863f6			MOVSXD SI, SI											
  module.go:63164	0x656aa1		48397008		CMPQ 0x8(AX), SI										
  module.go:63164	0x656aa5		0f8622060000		JBE 0x6570cd											
  module.go:48559	0x656aab		48c1e604		SHLQ $0x4, SI											
  module.go:48559	0x656aaf		4c8b18			MOVQ 0(AX), R11											
  module.go:48559	0x656ab2		4e8b241e		MOVQ 0(SI)(R11*1), R12										
  module.go:48559	0x656ab6		4a8b541e08		MOVQ 0x8(SI)(R11*1), DX										
  module.go:48559	0x656abb		488d1d1e5e1f00		LEAQ 0x1f5e1e(IP), BX										
  module.go:48559	0x656ac2		4939dc			CMPQ R12, BX											
  module.go:48559	0x656ac5		0f85f3050000		JNE 0x6570be											
  module.go:48559	0x656acb		488b0a			MOVQ 0(DX), CX											
  module.go:48559	0x656ace		8b442434		MOVL 0x34(SP), AX										
  module.go:48559	0x656ad2		ffd1			CALL CX												
  module.go:48561	0x656ad4		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:62983	0x656adc		8b7c2430		MOVL 0x30(SP), DI										
  module.go:62984	0x656ae0		4c8b442448		MOVQ 0x48(SP), R8										
  module.go:62983	0x656ae5		4c8b4c2440		MOVQ 0x40(SP), R9										
  module.go:63009	0x656aea		4c8b542438		MOVQ 0x38(SP), R10										
  module.go:48561	0x656aef		488b5038		MOVQ 0x38(AX), DX										
  module.go:62983	0x656af3		488d7707		LEAQ 0x7(DI), SI										
  module.go:62983	0x656af7		660f1f840000000000	NOPW 0(AX)(AX*1)										
  module.go:62983	0x656b00		4839f2			CMPQ DX, SI											
  module.go:62983	0x656b03		0f86b0050000		JBE 0x6570b9											
  module.go:48561	0x656b09		488b7030		MOVQ 0x30(AX), SI										
  module.go:62984	0x656b0d		8b4c3704		MOVL 0x4(DI)(SI*1), CX										
  module.go:48563	0x656b11		85c9			TESTL CX, CX											
  module.go:48563	0x656b13		7434			JE 0x656b49											
  module.go:62983	0x656b15		488d770b		LEAQ 0xb(DI), SI										
  module.go:48564	0x656b19		90			NOPL												
  module.go:48564	0x656b1a		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:62983	0x656b20		4839f2			CMPQ DX, SI											
  module.go:62983	0x656b23		0f868b050000		JBE 0x6570b4											
  module.go:48565	0x656b29		8b5c2434		MOVL 0x34(SP), BX										
  module.go:48565	0x656b2d		e8ae54f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn1(SB)			
  module.go:48567	0x656b32		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:62984	0x656b3a		4c8b442448		MOVQ 0x48(SP), R8										
  module.go:62983	0x656b3f		4c8b4c2440		MOVQ 0x40(SP), R9										
  module.go:63009	0x656b44		4c8b542438		MOVQ 0x38(SP), R10										
  module.go:48567	0x656b49		488b4838		MOVQ 0x38(AX), CX										
  module.go:62983	0x656b4d		4c39c9			CMPQ CX, R9											
  module.go:62983	0x656b50		0f8659050000		JBE 0x6570af											
  module.go:48567	0x656b56		488b5030		MOVQ 0x30(AX), DX										
  module.go:63000	0x656b5a		488b742468		MOVQ 0x68(SP), SI										
  module.go:63000	0x656b5f		488d7e0b		LEAQ 0xb(SI), DI										
  module.go:48568	0x656b63		90			NOPL												
  module.go:62984	0x656b64		458b4c1018		MOVL 0x18(R8)(DX*1), R9										
  module.go:63000	0x656b69		4839f9			CMPQ CX, DI											
  module.go:63000	0x656b6c		0f8638050000		JBE 0x6570aa											
  module.go:63001	0x656b72		44894c1608		MOVL R9, 0x8(SI)(DX*1)										
  module.go:48569	0x656b77		488b4838		MOVQ 0x38(AX), CX										
  module.go:48569	0x656b7b		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:63009	0x656b80		4c39d1			CMPQ CX, R10											
  module.go:63009	0x656b83		0f861c050000		JBE 0x6570a5											
  module.go:48569	0x656b89		488b5030		MOVQ 0x30(AX), DX										
  module.go:48570	0x656b8d		90			NOPL												
  module.go:63010	0x656b8e		498b7c1010		MOVQ 0x10(R8)(DX*1), DI										
  module.go:63026	0x656b93		4c8b442460		MOVQ 0x60(SP), R8										
  module.go:63026	0x656b98		0f1f840000000000	NOPL 0(AX)(AX*1)										
  module.go:63026	0x656ba0		4c39c1			CMPQ CX, R8											
  module.go:63026	0x656ba3		0f86f5040000		JBE 0x65709e											
  module.go:63027	0x656ba9		488b4c2450		MOVQ 0x50(SP), CX										
  module.go:63027	0x656bae		48893c0a		MOVQ DI, 0(DX)(CX*1)										
  module.go:48571	0x656bb2		488b5038		MOVQ 0x38(AX), DX										
  module.go:63000	0x656bb6		488d7e0f		LEAQ 0xf(SI), DI										
  module.go:63000	0x656bba		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:63000	0x656bc0		4839fa			CMPQ DX, DI											
  module.go:63000	0x656bc3		0f86d0040000		JBE 0x657099											
  module.go:48571	0x656bc9		488b5030		MOVQ 0x30(AX), DX										
  module.go:63001	0x656bcd		c744160c01000000	MOVL $0x1, 0xc(SI)(DX*1)									
  module.go:62983	0x656bd5		4c89c7			MOVQ R8, DI											
  module.go:62983	0x656bd8		4c8b442458		MOVQ 0x58(SP), R8										
  module.go:62984	0x656bdd		4989c9			MOVQ CX, R9											
  module.go:48577	0x656be0		4889c1			MOVQ AX, CX											
  module.go:48572	0x656be3		e9b4010000		JMP 0x656d9c											
  module.go:48512	0x656be8		bb2c000000		MOVL $0x2c, BX											
  module.go:48512	0x656bed		b901000000		MOVL $0x1, CX											
  module.go:48512	0x656bf2		e86957f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn4(SB)			
  module.go:48514	0x656bf7		85c0			TESTL AX, AX											
  module.go:48514	0x656bf9		0f8470040000		JE 0x65706f											
  module.go:48518	0x656bff		488b8c2480000000	MOVQ 0x80(SP), CX										
  module.go:48518	0x656c07		488b5138		MOVQ 0x38(CX), DX										
  module.go:63026	0x656c0b		488b742468		MOVQ 0x68(SP), SI										
  module.go:63026	0x656c10		488d7e0f		LEAQ 0xf(SI), DI										
  module.go:63026	0x656c14		4839fa			CMPQ DX, DI											
  module.go:63026	0x656c17		0f864d040000		JBE 0x65706a											
  module.go:48518	0x656c1d		488b5130		MOVQ 0x30(CX), DX										
  module.go:63027	0x656c21		48bf2c00000002000000	MOVQ $0x20000002c, DI										
  module.go:63027	0x656c2b		48897c1608		MOVQ DI, 0x8(SI)(DX*1)										
  module.go:48519	0x656c30		488b5138		MOVQ 0x38(CX), DX										
  module.go:63000	0x656c34		488b7c2460		MOVQ 0x60(SP), DI										
  module.go:63000	0x656c39		0f1f8000000000		NOPL 0(AX)											
  module.go:63000	0x656c40		4839fa			CMPQ DX, DI											
  module.go:63000	0x656c43		0f861c040000		JBE 0x657065											
  module.go:48519	0x656c49		488b5130		MOVQ 0x30(CX), DX										
  module.go:63001	0x656c4d		89441604		MOVL AX, 0x4(SI)(DX*1)										
  module.go:48520	0x656c51		488b5138		MOVQ 0x38(CX), DX										
  module.go:63000	0x656c55		4c8b442458		MOVQ 0x58(SP), R8										
  module.go:63000	0x656c5a		660f1f440000		NOPW 0(AX)(AX*1)										
  module.go:63000	0x656c60		4c39c2			CMPQ DX, R8											
  module.go:63000	0x656c63		0f86f3030000		JBE 0x65705c											
  module.go:48520	0x656c69		488b5130		MOVQ 0x30(CX), DX										
  module.go:63001	0x656c6d		4c8b4c2450		MOVQ 0x50(SP), R9										
  module.go:63001	0x656c72		42c7040a2c000000	MOVL $0x2c, 0(DX)(R9*1)										
  module.go:48521	0x656c7a		488b5138		MOVQ 0x38(CX), DX										
  module.go:48521	0x656c7e		6690			NOPW												
  module.go:62983	0x656c80		4881fa9b191000		CMPQ DX, $0x10199b										
  module.go:62983	0x656c87		0f86c3030000		JBE 0x657050											
  module.go:48522	0x656c8d		4189c2			MOVL AX, R10											
  module.go:63000	0x656c90		4d8d5a2b		LEAQ 0x2b(R10), R11										
  module.go:63000	0x656c94		4c39da			CMPQ DX, R11											
  module.go:63000	0x656c97		0f86ae030000		JBE 0x65704b											
  module.go:48521	0x656c9d		488b5130		MOVQ 0x30(CX), DX										
  module.go:62984	0x656ca1		448b9a98191000		MOVL 0x101998(DX), R11										
  module.go:63001	0x656ca8		45895c1228		MOVL R11, 0x28(R10)(DX*1)									
  module.go:48523	0x656cad		488b5138		MOVQ 0x38(CX), DX										
  module.go:63009	0x656cb1		4881fa97191000		CMPQ DX, $0x101997										
  module.go:63009	0x656cb8		0f8681030000		JBE 0x65703f											
  module.go:63026	0x656cbe		4d8d5a27		LEAQ 0x27(R10), R11										
  module.go:48524	0x656cc2		90			NOPL												
  module.go:63026	0x656cc3		4c39da			CMPQ DX, R11											
  module.go:63026	0x656cc6		0f866e030000		JBE 0x65703a											
  module.go:48523	0x656ccc		488b5130		MOVQ 0x30(CX), DX										
  module.go:63010	0x656cd0		4c8b9a90191000		MOVQ 0x101990(DX), R11										
  module.go:63027	0x656cd7		4d895c1220		MOVQ R11, 0x20(R10)(DX*1)									
  module.go:48525	0x656cdc		488b5138		MOVQ 0x38(CX), DX										
  module.go:63009	0x656ce0		4881fa8f191000		CMPQ DX, $0x10198f										
  module.go:63009	0x656ce7		0f8641030000		JBE 0x65702e											
  module.go:63026	0x656ced		4d8d5a1f		LEAQ 0x1f(R10), R11										
  module.go:48526	0x656cf1		90			NOPL												
  module.go:63026	0x656cf2		4c39da			CMPQ DX, R11											
  module.go:63026	0x656cf5		0f862e030000		JBE 0x657029											
  module.go:48525	0x656cfb		488b5130		MOVQ 0x30(CX), DX										
  module.go:63010	0x656cff		4c8b9a88191000		MOVQ 0x101988(DX), R11										
  module.go:63027	0x656d06		4d895c1218		MOVQ R11, 0x18(R10)(DX*1)									
  module.go:48527	0x656d0b		488b5138		MOVQ 0x38(CX), DX										
  module.go:63009	0x656d0f		4881fa87191000		CMPQ DX, $0x101987										
  module.go:63009	0x656d16		0f8601030000		JBE 0x65701d											
  module.go:63026	0x656d1c		4d8d5a17		LEAQ 0x17(R10), R11										
  module.go:48528	0x656d20		90			NOPL												
  module.go:63026	0x656d21		4c39da			CMPQ DX, R11											
  module.go:63026	0x656d24		0f86ee020000		JBE 0x657018											
  module.go:48527	0x656d2a		488b5130		MOVQ 0x30(CX), DX										
  module.go:63010	0x656d2e		4c8b9a80191000		MOVQ 0x101980(DX), R11										
  module.go:63027	0x656d35		4d895c1210		MOVQ R11, 0x10(R10)(DX*1)									
  module.go:48529	0x656d3a		488b5138		MOVQ 0x38(CX), DX										
  module.go:48529	0x656d3e		6690			NOPW												
  module.go:63009	0x656d40		4881fa7f191000		CMPQ DX, $0x10197f										
  module.go:63009	0x656d47		0f86bf020000		JBE 0x65700c											
  module.go:63026	0x656d4d		4d8d5a0f		LEAQ 0xf(R10), R11										
  module.go:48530	0x656d51		90			NOPL												
  module.go:63026	0x656d52		4c39da			CMPQ DX, R11											
  module.go:63026	0x656d55		0f86ac020000		JBE 0x657007											
  module.go:48529	0x656d5b		488b5130		MOVQ 0x30(CX), DX										
  module.go:63010	0x656d5f		4c8b9a78191000		MOVQ 0x101978(DX), R11										
  module.go:63027	0x656d66		4d895c1208		MOVQ R11, 0x8(R10)(DX*1)									
  module.go:48531	0x656d6b		488b5138		MOVQ 0x38(CX), DX										
  module.go:63009	0x656d6f		4881fa77191000		CMPQ DX, $0x101977										
  module.go:63009	0x656d76		0f867f020000		JBE 0x656ffb											
  module.go:63026	0x656d7c		4983c207		ADDQ $0x7, R10											
  module.go:48532	0x656d80		90			NOPL												
  module.go:63026	0x656d81		4c39d2			CMPQ DX, R10											
  module.go:63026	0x656d84		0f866c020000		JBE 0x656ff6											
  module.go:48531	0x656d8a		488b5130		MOVQ 0x30(CX), DX										
  module.go:63010	0x656d8e		4c8b9270191000		MOVQ 0x101970(DX), R10										
  module.go:63027	0x656d95		4189c3			MOVL AX, R11											
  module.go:63027	0x656d98		4e89141a		MOVQ R10, 0(DX)(R11*1)										
  module.go:48577	0x656d9c		8b542428		MOVL 0x28(SP), DX										
  module.go:48577	0x656da0		895150			MOVL DX, 0x50(CX)										
  module.go:48580	0x656da3		488b5138		MOVQ 0x38(CX), DX										
  module.go:62983	0x656da7		4c39c2			CMPQ DX, R8											
  module.go:62983	0x656daa		0f8641020000		JBE 0x656ff1											
  module.go:48580	0x656db0		4c8b5130		MOVQ 0x30(CX), R10										
  module.go:62984	0x656db4		478b1c11		MOVL 0(R9)(R10*1), R11										
  module.go:62984	0x656db8		0f1f840000000000	NOPL 0(AX)(AX*1)										
  module.go:48582	0x656dc0		4183fbff		CMPL R11, $-0x1											
  module.go:48582	0x656dc4		0f85e2000000		JNE 0x656eac											
  module.go:48602	0x656dca		90			NOPL												
  module.go:62983	0x656dcb		4881fa73ce1000		CMPQ DX, $0x10ce73										
  module.go:62983	0x656dd2		0f860d020000		JBE 0x656fe5											
  module.go:48603	0x656dd8		90			NOPL												
  module.go:63001	0x656dd9		41ff8270ce1000		INCL 0x10ce70(R10)										
  module.go:48604	0x656de0		488b5138		MOVQ 0x38(CX), DX										
  module.go:48604	0x656de4		4881fafccf1000		CMPQ DX, $0x10cffc										
  module.go:48604	0x656deb		0f86e4010000		JBE 0x656fd5											
  module.go:48604	0x656df1		488b5130		MOVQ 0x30(CX), DX										
  module.go:48604	0x656df5		0fb692fccf1000		MOVZX 0x10cffc(DX), DX										
  module.go:48604	0x656dfc		0f1f4000		NOPL 0(AX)											
  module.go:48605	0x656e00		83fa01			CMPL DX, $0x1											
  module.go:48605	0x656e03		7410			JE 0x656e15											
  module.go:48606	0x656e05		4889c8			MOVQ CX, AX											
  module.go:48606	0x656e08		e8b306fbff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn105(SB)			
  module.go:48608	0x656e0d		488b8c2480000000	MOVQ 0x80(SP), CX										
  module.go:48608	0x656e15		488b5138		MOVQ 0x38(CX), DX										
  module.go:48608	0x656e19		0f1f8000000000		NOPL 0(AX)											
  module.go:62983	0x656e20		4881fad3cf1000		CMPQ DX, $0x10cfd3										
  module.go:62983	0x656e27		0f869c010000		JBE 0x656fc9											
  module.go:48608	0x656e2d		488b7130		MOVQ 0x30(CX), SI										
  module.go:62984	0x656e31		83bed0cf100000		CMPL 0x10cfd0(SI), $0x0										
  module.go:48609	0x656e38		0f856b010000		JNE 0x656fa9											
  module.go:48613	0x656e3e		90			NOPL												
  module.go:48613	0x656e3f		90			NOPL												
  module.go:62983	0x656e40		4881fae7cf1000		CMPQ DX, $0x10cfe7										
  module.go:62983	0x656e47		0f8650010000		JBE 0x656f9d											
  module.go:48614	0x656e4d		90			NOPL												
  module.go:63000	0x656e4e		4881faefcf1000		CMPQ DX, $0x10cfef										
  module.go:63000	0x656e55		0f8636010000		JBE 0x656f91											
  module.go:62984	0x656e5b		8b96e4cf1000		MOVL 0x10cfe4(SI), DX										
  module.go:63001	0x656e61		8996eccf1000		MOVL DX, 0x10cfec(SI)										
  module.go:48615	0x656e67		488b5138		MOVQ 0x38(CX), DX										
  module.go:63000	0x656e6b		4881faebcf1000		CMPQ DX, $0x10cfeb										
  module.go:63000	0x656e72		0f860d010000		JBE 0x656f85											
  module.go:48615	0x656e78		488b5130		MOVQ 0x30(CX), DX										
  module.go:63001	0x656e7c		c782e8cf100000000000	MOVL $0x0, 0x10cfe8(DX)										
  module.go:48616	0x656e86		488b5138		MOVQ 0x38(CX), DX										
  module.go:63000	0x656e8a		4881faf3cf1000		CMPQ DX, $0x10cff3										
  module.go:63000	0x656e91		0f86dd000000		JBE 0x656f74											
  module.go:48616	0x656e97		488b5130		MOVQ 0x30(CX), DX										
  module.go:63001	0x656e9b		c782f0cf100000000000	MOVL $0x0, 0x10cff0(DX)										
  module.go:63001	0x656ea5		31c0			XORL AX, AX											
  module.go:48619	0x656ea7		e996000000		JMP 0x656f42											
  module.go:48585	0x656eac		90			NOPL												
  module.go:62983	0x656ead		4839fa			CMPQ DX, DI											
  module.go:62983	0x656eb0		0f86b9000000		JBE 0x656f6f											
  module.go:63009	0x656eb6		4c8d660f		LEAQ 0xf(SI), R12										
  module.go:48587	0x656eba		90			NOPL												
  module.go:62984	0x656ebb		468b6c1604		MOVL 0x4(SI)(R10*1), R13									
  module.go:63009	0x656ec0		4c39e2			CMPQ DX, R12											
  module.go:63009	0x656ec3		0f86a1000000		JBE 0x656f6a											
  module.go:63010	0x656ec9		4a8b541608		MOVQ 0x8(SI)(R10*1), DX										
  module.go:48592	0x656ece		4889c8			MOVQ CX, AX											
  module.go:48597	0x656ed1		8b5c2420		MOVL 0x20(SP), BX										
  module.go:63001	0x656ed5		4d89ca			MOVQ R9, R10											
  module.go:48591	0x656ed8		4489e9			MOVL R13, CX											
  module.go:63000	0x656edb		4989f9			MOVQ DI, R9											
  module.go:63000	0x656ede		4c89c7			MOVQ R8, DI											
  module.go:63026	0x656ee1		4989f0			MOVQ SI, R8											
  module.go:48592	0x656ee4		488b7038		MOVQ 0x38(AX), SI										
  module.go:62983	0x656ee8		4881fe73ce1000		CMPQ SI, $0x10ce73										
  module.go:62983	0x656eef		766d			JBE 0x656f5e											
  module.go:48592	0x656ef1		488b7030		MOVQ 0x30(AX), SI										
  module.go:63026	0x656ef5		4d8d600f		LEAQ 0xf(R8), R12										
  module.go:48593	0x656ef9		90			NOPL												
  module.go:63001	0x656efa		ff8670ce1000		INCL 0x10ce70(SI)										
  module.go:48594	0x656f00		488b7038		MOVQ 0x38(AX), SI										
  module.go:63026	0x656f04		4c39e6			CMPQ SI, R12											
  module.go:63026	0x656f07		7650			JBE 0x656f59											
  module.go:48594	0x656f09		488b7030		MOVQ 0x30(AX), SI										
  module.go:63027	0x656f0d		4989543008		MOVQ DX, 0x8(R8)(SI*1)										
  module.go:48595	0x656f12		488b5038		MOVQ 0x38(AX), DX										
  module.go:63000	0x656f16		4c39ca			CMPQ DX, R9											
  module.go:63000	0x656f19		7639			JBE 0x656f54											
  module.go:48595	0x656f1b		488b5030		MOVQ 0x30(AX), DX										
  module.go:63001	0x656f1f		41894c1004		MOVL CX, 0x4(R8)(DX*1)										
  module.go:48596	0x656f24		488b4838		MOVQ 0x38(AX), CX										
  module.go:63000	0x656f28		4839f9			CMPQ CX, DI											
  module.go:63000	0x656f2b		7622			JBE 0x656f4f											
  module.go:48596	0x656f2d		488b4830		MOVQ 0x30(AX), CX										
  module.go:63001	0x656f31		46891c11		MOVL R11, 0(CX)(R10*1)										
  module.go:48597	0x656f35		e8865af8ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn60(SB)			
  module.go:48620	0x656f3a		488b8c2480000000	MOVQ 0x80(SP), CX										
  module.go:48620	0x656f42		8b54242c		MOVL 0x2c(SP), DX										
  module.go:48620	0x656f46		895150			MOVL DX, 0x50(CX)										
  module.go:48621	0x656f49		4883c470		ADDQ $0x70, SP											
  module.go:48621	0x656f4d		5d			POPQ BP												
  module.go:48621	0x656f4e		c3			RET												
  module.go:63000	0x656f4f		e86c9ae3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x656f54		e8679ae3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x656f59		e8629ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x656f5e		48c7c073ce1000		MOVQ $0x10ce73, AX										
  module.go:62983	0x656f65		e8569ae3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x656f6a		e8519ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x656f6f		e84c9ae3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x656f74		48c7c0f3cf1000		MOVQ $0x10cff3, AX										
  module.go:63000	0x656f7b		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:63000	0x656f80		e83b9ae3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x656f85		48c7c0ebcf1000		MOVQ $0x10cfeb, AX										
  module.go:63000	0x656f8c		e82f9ae3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x656f91		48c7c0efcf1000		MOVQ $0x10cfef, AX										
  module.go:63000	0x656f98		e8239ae3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x656f9d		48c7c0e7cf1000		MOVQ $0x10cfe7, AX										
  module.go:62983	0x656fa4		e8179ae3ff		CALL runtime.panicBounds(SB)									
  module.go:48610	0x656fa9		4889c8			MOVQ CX, AX											
  module.go:48610	0x656fac		bb60171000		MOVL $0x101760, BX										
  module.go:48610	0x656fb1		e82ac0f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn24(SB)			
  module.go:48611	0x656fb6		488d05633a1f00		LEAQ 0x1f3a63(IP), AX										
  module.go:48611	0x656fbd		488d1d2cb32a00		LEAQ 0x2ab32c(IP), BX										
  module.go:48611	0x656fc4		e81718e3ff		CALL runtime.gopanic(SB)									
  module.go:62983	0x656fc9		48c7c0d3cf1000		MOVQ $0x10cfd3, AX										
  module.go:62983	0x656fd0		e8eb99e3ff		CALL runtime.panicBounds(SB)									
  module.go:48604	0x656fd5		48c7c0fccf1000		MOVQ $0x10cffc, AX										
  module.go:48604	0x656fdc		0f1f4000		NOPL 0(AX)											
  module.go:48604	0x656fe0		e8db99e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x656fe5		48c7c073ce1000		MOVQ $0x10ce73, AX										
  module.go:62983	0x656fec		e8cf99e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x656ff1		e8ca99e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x656ff6		e8c599e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x656ffb		48c7c077191000		MOVQ $0x101977, AX										
  module.go:63009	0x657002		e8b999e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x657007		e8b499e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x65700c		48c7c07f191000		MOVQ $0x10197f, AX										
  module.go:63009	0x657013		e8a899e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x657018		e8a399e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x65701d		48c7c087191000		MOVQ $0x101987, AX										
  module.go:63009	0x657024		e89799e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x657029		e89299e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x65702e		48c7c08f191000		MOVQ $0x10198f, AX										
  module.go:63009	0x657035		e88699e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x65703a		e88199e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x65703f		48c7c097191000		MOVQ $0x101997, AX										
  module.go:63009	0x657046		e87599e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x65704b		e87099e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x657050		48c7c09b191000		MOVQ $0x10199b, AX										
  module.go:62983	0x657057		e86499e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x65705c		0f1f4000		NOPL 0(AX)											
  module.go:63000	0x657060		e85b99e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x657065		e85699e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x65706a		e85199e3ff		CALL runtime.panicBounds(SB)									
  module.go:48515	0x65706f		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48515	0x657077		bb01000000		MOVL $0x1, BX											
  module.go:48515	0x65707c		b92c000000		MOVL $0x2c, CX											
  module.go:48515	0x657081		e85a50f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn2(SB)			
  module.go:48516	0x657086		488d0593391f00		LEAQ 0x1f3993(IP), AX										
  module.go:48516	0x65708d		488d1d5cb22a00		LEAQ 0x2ab25c(IP), BX										
  module.go:48516	0x657094		e84717e3ff		CALL runtime.gopanic(SB)									
  module.go:63000	0x657099		e82299e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x65709e		6690			NOPW												
  module.go:63026	0x6570a0		e81b99e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x6570a5		e81699e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x6570aa		e81199e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x6570af		e80c99e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x6570b4		e80799e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x6570b9		e80299e3ff		CALL runtime.panicBounds(SB)									
  module.go:48559	0x6570be		4c89e0			MOVQ R12, AX											
  module.go:48559	0x6570c1		488d0d584a2000		LEAQ 0x204a58(IP), CX										
  module.go:48559	0x6570c8		e8b370dcff		CALL runtime.panicdottypeE(SB)									
  module.go:63165	0x6570cd		488d054c391f00		LEAQ 0x1f394c(IP), AX										
  module.go:63165	0x6570d4		488d1d65c92a00		LEAQ 0x2ac965(IP), BX										
  module.go:63165	0x6570db		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:63165	0x6570e0		e8fb16e3ff		CALL runtime.gopanic(SB)									
  module.go:62983	0x6570e5		e8d698e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x6570ea		e8d198e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x6570ef		e8cc98e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x6570f4		e8c798e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x6570f9		e8c298e3ff		CALL runtime.panicBounds(SB)									
  module.go:48549	0x6570fe		8b7c2428		MOVL 0x28(SP), DI										
  module.go:48549	0x657102		ffcf			DECL DI												
  module.go:48549	0x657104		488b842480000000	MOVQ 0x80(SP), AX										
  module.go:48549	0x65710c		bbf01a1000		MOVL $0x101af0, BX										
  module.go:48549	0x657111		b937000000		MOVL $0x37, CX											
  module.go:48549	0x657116		bee01a1000		MOVL $0x101ae0, SI										
  module.go:48549	0x65711b		41b8281b1000		MOVL $0x101b28, R8										
  module.go:48549	0x657121		e87ac2f7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn27(SB)			
  module.go:48550	0x657126		488d05f3381f00		LEAQ 0x1f38f3(IP), AX										
  module.go:48550	0x65712d		488d1dbcb12a00		LEAQ 0x2ab1bc(IP), BX										
  module.go:48550	0x657134		e8a716e3ff		CALL runtime.gopanic(SB)									
  module.go:48547	0x657139		4c89e8			MOVQ R13, AX											
  module.go:48547	0x65713c		4889fb			MOVQ DI, BX											
  module.go:48547	0x65713f		488d0dda492000		LEAQ 0x2049da(IP), CX										
  module.go:48547	0x657146		e83570dcff		CALL runtime.panicdottypeE(SB)									
  module.go:63165	0x65714b		488d05ce381f00		LEAQ 0x1f38ce(IP), AX										
  module.go:63165	0x657152		488d1de7c82a00		LEAQ 0x2ac8e7(IP), BX										
  module.go:63165	0x657159		e88216e3ff		CALL runtime.gopanic(SB)									
  module.go:62983	0x65715e		6690			NOPW												
  module.go:62983	0x657160		e85b98e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x657165		e85698e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x65716a		e85198e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x65716f		e84c98e3ff		CALL runtime.panicBounds(SB)									
  module.go:63026	0x657174		e84798e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x657179		e84298e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x65717e		6690			NOPW												
  module.go:62983	0x657180		e83b98e3ff		CALL runtime.panicBounds(SB)									
  module.go:63000	0x657185		e83698e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x65718a		e83198e3ff		CALL runtime.panicBounds(SB)									
  module.go:63009	0x65718f		e82c98e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x657194		e82798e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x657199		e82298e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x65719e		48c7c083ce1000		MOVQ $0x10ce83, AX										
  module.go:62983	0x6571a5		e81698e3ff		CALL runtime.panicBounds(SB)									
  module.go:62983	0x6571aa		48c7c07fce1000		MOVQ $0x10ce7f, AX										
  module.go:62983	0x6571b1		e80a98e3ff		CALL runtime.panicBounds(SB)									
  module.go:48623	0x6571b6		bb60171000		MOVL $0x101760, BX										
  module.go:48623	0x6571bb		0f1f440000		NOPL 0(AX)(AX*1)										
  module.go:48623	0x6571c0		e81bbef7ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn24(SB)			
  module.go:48624	0x6571c5		488d0554381f00		LEAQ 0x1f3854(IP), AX										
  module.go:48624	0x6571cc		488d1d1db12a00		LEAQ 0x2ab11d(IP), BX										
  module.go:48624	0x6571d3		e80816e3ff		CALL runtime.gopanic(SB)									
  module.go:62983	0x6571d8		48c7c073ce1000		MOVQ $0x10ce73, AX										
  module.go:62983	0x6571df		90			NOPL												
  module.go:62983	0x6571e0		e8db97e3ff		CALL runtime.panicBounds(SB)									
  module.go:48463	0x6571e5		48c7c0b0cf1000		MOVQ $0x10cfb0, AX										
  module.go:48463	0x6571ec		e8cf97e3ff		CALL runtime.panicBounds(SB)									
  module.go:48463	0x6571f1		90			NOPL												
  module.go:48457	0x6571f2		4889442408		MOVQ AX, 0x8(SP)										
  module.go:48457	0x6571f7		48895c2410		MOVQ BX, 0x10(SP)										
  module.go:48457	0x6571fc		f20f11442418		MOVSD_XMM X0, 0x18(SP)										
  module.go:48457	0x657202		e8997ae3ff		CALL runtime.morestack_noctxt.abi0(SB)								
  module.go:48457	0x657207		488b442408		MOVQ 0x8(SP), AX										
  module.go:48457	0x65720c		488b5c2410		MOVQ 0x10(SP), BX										
  module.go:48457	0x657211		f20f10442418		MOVSD_XMM 0x18(SP), X0										
  module.go:48457	0x657217		e944f4ffff		JMP dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).Xcocoon_sketch_add(SB)	
