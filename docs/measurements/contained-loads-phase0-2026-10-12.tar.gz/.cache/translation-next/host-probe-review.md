# Host review: contained load32 bounds diagnostic

Read-only phase-0 review, 2026-10-12. Parent reports a current matching
ordinary Go1.26.8 profile/SSA/assembly witness; no new performance conclusion
is asserted here. No builds, tests, profiles, benchmarks or committed edits
were performed by this reviewer.

## Scope and controls

Approve the proposed diagnostic matrix: untouched ordinary baseline, exact
hash/shape-pinned probe, and a recheck shape control with identical selected
helper-call inventory but the original bound check retained. Preserve original
seven workloads, SQL translation holdout, actual-P1 increasing/broad scalar,
matched repeated/broad batches, raw production Guest, four existing P16 stream
controls and a freshly independently built reference. Seven alternating 500ms
samples followed by seven reversed 1s samples are suitable. Preserve all rows,
failures, checks, provenance and exploratory unadjusted p-values.

Compare probe to both untouched baseline and recheck. Audit ordinary machine
code: an original check remaining in source does not establish that it survives
in the recheck binary. Verify selected helpers inline comparably and report
check inventory, instructions, frame/spill/text size, addresses and allocation
changes. Changed function placement remains a limitation even with the
control; one comparison or one successful workload cannot identify a pure
check cost. Do not use an SSA-dump build as a timing role.

Old original/layer leaves have initial/framework P16 and no in-window custom
processor metrics; explicitly record that policy instead of labeling them P1
because fresh diagnostic profiles used P1. Matched leaves verify P1 themselves.
Raw Guest omits runtime/ownership/reply checks; full scalar includes them.
SQL includes admission, UTF8/size checks, pooled reserve/copy/SQL/owned decode
and separate checked recycling Trim. No host control may be removed or charged
to a guest source pattern. All layer differences remain nonadditive ceilings.

Four unchanged streaming singleton roles describe refreshed observed full-
stream throughput. If the stream module/binary is byte-identical across
diagnostic roles, that identity is the evidence that this DD-only overlay does
not change it; repeated singleton samples do not prove a future generic pass
has no streaming effect. Their retention groups, home topology and lifetimes
stay unchanged. A future production pass must regenerate and qualify every
proof, including streaming. A fresh ABI2 reference is contextual; its original
batch/trace inputs, facade/context/topology differ. No M1 acceptance follows.

## Safety obligation before timing

Deleting a check is justified only after an earlier original check executes
and succeeds on every path reaching the selected read. For the bound check
`mem[uint64(address)+3]`, prove the later endpoint is no greater than the
already validated endpoint, both computations cannot wrap, both refer to the
same unchanged logical slice length/backing, and the actual bound base value
and declaration are unchanged. A higher-address successful load proves a
valid prefix ending there; it need not read the same bytes as the later load.
Every read still executes, so this is not value reuse or overlapping-byte
alias analysis. Same base spelling is insufficient after reassignment or
shadowing. Widened `uint64(uint32(base))+offset` must not be replaced by
wrapping i32 or uint32 addition.

Do not carry a proof across writes, calls/imports, growth, header/receiver
changes, pointers escaping or control-flow/label boundaries. Keep the first
check and read at their original positions; no preflight, widened/coalesced
load, changed operand evaluation or reordered trap is authorized. Validate
the real helper binding/body, conversions, architecture constants and imports
against the pinned source. Preserve endian reversal and non-unaligned-safe
fallback behavior. Logical length governs validity even when capacity is
larger; a successful endpoint within host-int-sized length also protects
unsafe uintptr conversion on 32-bit hosts. Arbitrary uint64 wrapped endpoints
are ineligible, not a permitted inherited helper weakness.

**Before timing:** run the full generated DD package test suite on untouched,
probe and recheck, including complete original-Wasm differential/contract,
typed input/reply, invalid-late-value atomicity, growth, retained outputs and
fault histories. Selective successful workload oracles are insufficient.
Execute native boundary/adversarial tests of the actual unchecked helper and
the selection predicate: first check fails, first succeeds and later endpoint
is equal/lower, partially overlapping reads, last valid byte/end-of-memory,
nil/empty slice, logical length below capacity, widened near-u32 addresses,
base reassignment/shadowing, calls/import/header replacement/growth, labels
and branches. Rejected cases must keep original checks. Compare values,
trap category/order and observable bytes with the checked control.

A small ignored translated WAT/wazero fixture is the best independent byte-
effect/trap oracle before screening unsafe range elision. Native assertions
are separately necessary for exposed Go-header replacement and len<cap;
Wasm alone cannot represent arbitrary Go-header replacement. Native amd64
execution is required for the actual probe unsafe path; 386 cross compilation
is not execution. A retained generic implementation would additionally need
native386 and all supported architecture-path proofs, complete WAT/effect/
binding adversaries, whole generated proof suites and every required gate.

This remains one private demonstrated pattern and an attainable-ceiling
experiment. No public API, ABI, runtime boundary, default PGO or guard-policy
change is approved. Small repeated standalone negatives remain blockers;
guest/host/adversarial retention review and a committed private production
predicate precede any implementation if phase 0 is worthwhile.
