# Host entry review: next translation analysis

Read-only review on 2026-10-12, clean HEAD
`776b897e74b7faef44375b2c31bd3c17ac88f876`. No builds, tests, lint, profiles,
benchmarks, or production edits. Only this ignored note is authored.

## What the controls actually execute

- Original scalar and Guest/Instance/Resource/Facade layers consume increasing
  positive values, one sketch from one default resource home. Add has no input
  reservation or pool recycling. Facade includes lifecycle admission, shared
  resource ownership, checked execution, canonical empty reply validation and
  memory/fault checks. Guest omits these checks; Instance adds checked execution
  and replies; Resource adds ownership but omits library admission. Only Facade
  is supported production behavior. Setup/constructor/disposal are outside
  these steady-call timings. The layer harness checks Count afterward; the
  original scalar benchmark has no post-loop Count assertion. Layers and empty
  callbacks are separately timed and do not form additive component shares.
- Original SQL is the fixed SELECT query through a lazy one-slot stateless
  pool (`Options{Instances:1}`). It includes caller-context admission, size and
  UTF8 checks, one aggregate reservation, PutString, guest SQL, canonical reply
  validation and owned string decoding. Pool return invokes Recycle's separate
  checked Trim. Guest samples under a full SQL profile can belong to Reserve,
  SQL or Trim; attribute those call sites separately. Initial lazy creation and
  capacity setup may be amortized inside original timing, unlike explicitly
  warmed private controls. Varied SQL cycles eight fixed queries; translation
  holdout cycles six independently tested queries with long scans/comments,
  escaped literals, Unicode and quoted names.
- Original batch uses 1000 values 0..999. Matched batches use identical ordered
  groups across modes and warm one full group before timing: repeated42,
  nearby values, increasing finite groups, negative bins, and broad exponents.
  Current generated AddMany preflights size before ownership but performs
  reservation and direct little-endian encoding under Instance.Call. The
  contention comment claiming Facade encodes before its lock is historical;
  use actual generated code for attribution. Batch layer Encode allocates an
  independent temporary; Copy/Direct run checked preparation without ingest;
  Guest ingests a prefilled reservation. These are distinct diagnostic scopes,
  not additive guest/encoding shares or replacements for full AddMany.
- Private same-Wasm RawGuest/CheckedControl add dispatch, reusable carriers and
  backend contexts. SQL/trace raw still encode/copy/check/decode, checked
  stateless roles use actual pool/recycling and retain an unused home. They
  cannot identify the production guest-body or boundary cost by subtraction.

## Processor and provenance policy

Original scalar/SQL/batch/trace, varied and old layer leaves do not set or emit
an in-window processor count. Fresh matching profiles should explicitly request
`-test.cpu=1` and record process environment/argv; this differs from older P16
framework controls and is not a historical performance comparison. Matched
batch, bin-reuse and SQL translation holdout leaves set P1 themselves and
report actual-procs afterward. Streaming and contention controls are separate
P16 throughput diagnostics with their own home counts and retained lifetimes.

Freeze source, Wasm, module/lock, ordinary Go1.26.8 CGO0 GOAMD64v1 PGO-off binary,
tool/viewer and exact profile commands before diagnostic execution. Collect
each CPU profile alone, matching the binary used for symbol/assembly analysis.
Record default GC/memory, affinity, CPU policy and frequencies. Do not compare
profiled benchmark times with qualification samples. SSA dump binaries are
diagnostic artifacts, not candidates for timing; compare ordinary machine code
to establish that the observed pattern survives optimization.

The old translation profiles are from `5a5c8df`, module `f50d20e7…`, binary
`cd533f99…`, before retained publication memory views. Current production module
is `f92c5853…` with the same original Wasm `ae0119ca…`. Old fn176/fn96 hotness
and overlapping cumulative percentages guide selectors, not current attribution
or an attainable ceiling. fn176's two publication tails already cache headers;
the register-resident log polynomial does not justify another promotion or
approximate-math proposal. Prior 88 ns scalar and fresh 2.237/2.1626 µs SQL
reference/limit are prior-session observations, not this round's performance.

## Candidate and measurement requirements

Select exactly one structural pattern only after fresh flat/cumulative and
instruction-level evidence identifies repeated surviving work in a hot guest
path. Prior safe memory-header caching is a proof model, not evidence that
expanding it wins. A repeated header load, duplicate scalar access or bounds
check is a hypothesis until matching machine code and hot path demonstrate it;
compiler CSE or existing publication views may already remove it.

Keep the first ignored prototype full-module-hash and shape pinned. Preserve
every original operand evaluation, width, memory access, trap/partial-store
order, import event and math rounding. A future generic production predicate
must use bindings/effects and structural shape rather than payload names,
function numbers or source lines. Header stability requires separately owned
Module/backing construction and serialized checked execution. Imports, calls,
growth, header writes, escapes and control-flow joins are barriers. Do not
promote Wasm stack bytes into private locals or forward loads across unproved
stores/calls: those addresses remain observable and may alias. Bounds use
logical length, width-end addition must not overflow, and i32 wrapping differs
from widened address addition.

First screen an exact direct prototype alongside untouched baseline with
identical authored harnesses. If extraction/extra helpers are needed, include
a no-optimization shape control to separate dispatch and placement. Compare
full generated facade and raw guest; a raw-only gain is not an end-to-end claim.
Use repeated and broad/negative/long-SQL holdouts, report allocations, current
memory and timed growth, complete Count/reply oracles, frames/spills/text size,
and every negative. Profiles and SSA finish before all isolated timings.
Only a credible demonstrated ceiling justifies a private spec/implementation
round; no public ABI, runtime boundary, guard or default PGO change is in scope.
Guest/host/adversarial review must precede retention. Final qualification would
require fresh identical-harness paired broad guards and independent references,
all gates and proof reproductions; no M1 acceptance follows from phase 0.
