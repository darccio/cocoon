TEXT dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn176(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/internal/wasm/module.go
  module.go:35694	0x62ff20		4c8d6424f8		LEAQ -0x8(SP), R12								
  module.go:35694	0x62ff25		4d3b6610		CMPQ R12, 0x10(R14)								
  module.go:35694	0x62ff29		0f8617150000		JBE 0x631446									
  module.go:35694	0x62ff2f		55			PUSHQ BP									
  module.go:35694	0x62ff30		4889e5			MOVQ SP, BP									
  module.go:35694	0x62ff33		4883c480		ADDQ $-0x80, SP									
  module.go:35713	0x62ff37		4889842490000000	MOVQ AX, 0x90(SP)								
  module.go:35713	0x62ff3f		899c2498000000		MOVL BX, 0x98(SP)								
  module.go:35699	0x62ff46		8b5050			MOVL 0x50(AX), DX								
  module.go:35699	0x62ff49		89542434		MOVL DX, 0x34(SP)								
  module.go:35705	0x62ff4d		448d4ae0		LEAL -0x20(DX), R9								
  module.go:35706	0x62ff51		44894850		MOVL R9, 0x50(AX)								
  unsafe.go:35		0x62ff55		66490f7ec2		MOVQ X0, R10									
  module.go:35711	0x62ff5a		4d89d3			MOVQ R10, R11									
  module.go:35711	0x62ff5d		490fbaf23f		BTRQ $0x3f, R10									
  module.go:35713	0x62ff62		4d8d62ff		LEAQ -0x1(R10), R12								
  module.go:35733	0x62ff66		49bd000000000000f0ff	MOVQ $0xfff0000000000000, R13							
  module.go:35733	0x62ff70		4d01d5			ADDQ R10, R13									
  module.go:35710	0x62ff73		90			NOPL										
  module.go:35713	0x62ff74		49bfffffffffffff0f00	MOVQ $0xfffffffffffff, R15							
  module.go:35713	0x62ff7e		4d39e7			CMPQ R15, R12									
  module.go:35713	0x62ff81		410f97c4		SETA R12									
  module.go:35714	0x62ff85		450fb6e4		MOVZX R12, R12									
  module.go:35717	0x62ff89		4d85db			TESTQ R11, R11									
  module.go:35717	0x62ff8c		410f9cc7		SETL R15									
  module.go:35718	0x62ff90		450fb6ff		MOVZX R15, R15									
  module.go:35721	0x62ff94		4521fc			ANDL R15, R12									
  module.go:35705	0x62ff97		4489ce			MOVL R9, SI									
  module.go:35728	0x62ff9a		49b9000000000000f07f	MOVQ $0x7ff0000000000000, R9							
  module.go:35728	0x62ffa4		4d39d1			CMPQ R9, R10									
  module.go:35723	0x62ffa7		410f94c1		SETE R9										
  module.go:35728	0x62ffab		410f92c2		SETB R10									
  module.go:35724	0x62ffaf		450fb6c9		MOVZX R9, R9									
  module.go:35726	0x62ffb3		4509cc			ORL R9, R12									
  module.go:35729	0x62ffb6		450fb6ca		MOVZX R10, R9									
  module.go:35731	0x62ffba		4509cc			ORL R9, R12									
  module.go:35733	0x62ffbd		49b9000000000000e07f	MOVQ $0x7fe0000000000000, R9							
  module.go:35733	0x62ffc7		4d39e9			CMPQ R9, R13									
  module.go:35733	0x62ffca		410f97c1		SETA R9										
  module.go:35734	0x62ffce		450fb6c9		MOVZX R9, R9									
  module.go:35736	0x62ffd2		4521f9			ANDL R15, R9									
  module.go:35736	0x62ffd5		4509e1			ORL R12, R9									
  module.go:35736	0x62ffd8		0f1f840000000000	NOPL 0(AX)(AX*1)								
  module.go:35736	0x62ffe0		4585c9			TESTL R9, R9									
  module.go:35736	0x62ffe3		0f85f0080000		JNE 0x6308d9									
  module.go:35772	0x62ffe9		4c8b4838		MOVQ 0x38(AX), R9								
  module.go:35772	0x62ffed		4189ca			MOVL CX, R10									
  module.go:63009	0x62fff0		4d8d6237		LEAQ 0x37(R10), R12								
  module.go:63009	0x62fff4		4d39e1			CMPQ R9, R12									
  module.go:63009	0x62fff7		0f8641140000		JBE 0x63143e									
  module.go:35772	0x62fffd		4c8b4830		MOVQ 0x30(AX), R9								
  module.go:63010	0x630001		4f8b4c0a30		MOVQ 0x30(R10)(R9*1), R9							
  unsafe.go:41		0x630006		66490f6ec9		MOVQ R9, X1									
  module.go:35773	0x63000b		660f2ec8		UCOMISD X0, X1									
  module.go:35773	0x63000f		0f8779080000		JA 0x63088e									
  module.go:35774	0x630015		4c8b4838		MOVQ 0x38(AX), R9								
  module.go:63009	0x630019		4d8d622f		LEAQ 0x2f(R10), R12								
  module.go:63009	0x63001d		0f1f00			NOPL 0(AX)									
  module.go:63009	0x630020		4d39e1			CMPQ R9, R12									
  module.go:63009	0x630023		0f8610140000		JBE 0x631439									
  module.go:35774	0x630029		4c8b4830		MOVQ 0x30(AX), R9								
  module.go:63010	0x63002d		4f8b4c0a28		MOVQ 0x28(R10)(R9*1), R9							
  module.go:35780	0x630032		49bc0000000000001000	MOVQ $0x10000000000000, R12							
  module.go:35780	0x63003c		0f1f4000		NOPL 0(AX)									
  module.go:35780	0x630040		4d39e3			CMPQ R11, R12									
  module.go:35780	0x630043		7c45			JL 0x63008a									
  module.go:35781	0x630045		49bcffffffffffffef7f	MOVQ $0x7fefffffffffffff, R12							
  module.go:35781	0x63004f		4d39e3			CMPQ R11, R12									
  module.go:35781	0x630052		0f87c2010000		JA 0x63021a									
  module.go:35785	0x630058		4d89dc			MOVQ R11, R12									
  module.go:35785	0x63005b		49c1eb20		SHRQ $0x20, R11									
  module.go:35785	0x63005f		90			NOPL										
  module.go:35786	0x630060		4981fb0000f03f		CMPQ R11, $0x3ff00000								
  module.go:35786	0x630067		7407			JE 0x630070									
  module.go:35786	0x630069		be01fcffff		MOVL $-0x3ff, SI								
  module.go:35789	0x63006e		eb7b			JMP 0x6300eb									
  module.go:35791	0x630070		4585e4			TESTL R12, R12									
  module.go:35791	0x630073		740d			JE 0x630082									
  module.go:35791	0x630075		41bb0000f03f		MOVL $0x3ff00000, R11								
  module.go:35791	0x63007b		be01fcffff		MOVL $-0x3ff, SI								
  module.go:35793	0x630080		eb69			JMP 0x6300eb									
  module.go:35793	0x630082		0f57c0			XORPS X0, X0									
  module.go:35796	0x630085		e990010000		JMP 0x63021a									
  module.go:35798	0x63008a		0f10c8			MOVUPS X0, X1									
  module.go:35798	0x63008d		f20f59c0		MULSD X0, X0									
  module.go:35798	0x630091		f20f1015c7202d00	MOVSD_XMM $f64.bff0000000000000(SB), X2						
  module.go:35798	0x630099		f20f5ed0		DIVSD X0, X2									
  module.go:35799	0x63009d		0f57db			XORPS X3, X3									
  module.go:35799	0x6300a0		660f2ecb		UCOMISD X3, X1									
  module.go:35799	0x6300a4		750a			JNE 0x6300b0									
  module.go:35799	0x6300a6		7a08			JP 0x6300b0									
  module.go:35795	0x6300a8		0f10c2			MOVUPS X2, X0									
  module.go:35801	0x6300ab		e96a010000		JMP 0x63021a									
  module.go:35717	0x6300b0		4d85db			TESTQ R11, R11									
  module.go:35803	0x6300b3		7d10			JGE 0x6300c5									
  module.go:35828	0x6300b5		f20f5cc9		SUBSD X1, X1									
  module.go:35828	0x6300b9		f20f5ecb		DIVSD X3, X1									
  module.go:35828	0x6300bd		0f10c1			MOVUPS X1, X0									
  module.go:35829	0x6300c0		e955010000		JMP 0x63021a									
  module.go:35807	0x6300c5		f20f101583202d00	MOVSD_XMM $f64.4350000000000000(SB), X2						
  module.go:35807	0x6300cd		f20f59d1		MULSD X1, X2									
  unsafe.go:35		0x6300d1		66490f7ed3		MOVQ X2, R11									
  module.go:35808	0x6300d6		4d89dc			MOVQ R11, R12									
  module.go:35808	0x6300d9		49c1ec20		SHRQ $0x20, R12									
  module.go:35808	0x6300dd		becbfbffff		MOVL $-0x435, SI								
  module.go:35792	0x6300e2		4c89df			MOVQ R11, DI									
  module.go:35792	0x6300e5		4d89e3			MOVQ R12, R11									
  module.go:35807	0x6300e8		4989fc			MOVQ DI, R12									
  module.go:35811	0x6300eb		4181c3625f0900		ADDL $0x95f62, R11								
  module.go:35812	0x6300f2		4589dd			MOVL R11, R13									
  module.go:35812	0x6300f5		41c1eb14		SHRL $0x14, R11									
  module.go:35812	0x6300f9		4101f3			ADDL SI, R11									
  module.go:35812	0x6300fc		0f57d2			XORPS X2, X2									
  module.go:35812	0x6300ff		f2410f2ad3		CVTSI2SDL R11, X2								
  module.go:35813	0x630104		f20f100d1c202d00	MOVSD_XMM $f64.3fe62e42fee00000(SB), X1						
  module.go:35813	0x63010c		f20f59ca		MULSD X2, X1									
  module.go:35814	0x630110		41bbffffffff		MOVL $-0x1, R11									
  module.go:35814	0x630116		4d21dc			ANDQ R11, R12									
  module.go:35814	0x630119		4181e5ffff0f00		ANDL $0xfffff, R13								
  module.go:35814	0x630120		458d9d9ea0e63f		LEAL 0x3fe6a09e(R13), R11							
  module.go:35814	0x630127		4589db			MOVL R11, R11									
  module.go:35814	0x63012a		49c1e320		SHLQ $0x20, R11									
  module.go:35814	0x63012e		4d09dc			ORQ R11, R12									
  module.go:35816	0x630131		f20f101daf1f2d00	MOVSD_XMM $f64.3dea39ef35793c76(SB), X3						
  module.go:35816	0x630139		f20f59d3		MULSD X3, X2									
  unsafe.go:41		0x63013d		66490f6edc		MOVQ R12, X3									
  module.go:35814	0x630142		f20f102516202d00	MOVSD_XMM $f64.bff0000000000000(SB), X4						
  module.go:35814	0x63014a		f20f58e3		ADDSD X3, X4									
  module.go:35817	0x63014e		f20f101d1a1e2d00	MOVSD_XMM $f64.4000000000000000(SB), X3						
  module.go:35817	0x630156		f20f58dc		ADDSD X4, X3									
  module.go:35817	0x63015a		0f10ec			MOVUPS X4, X5									
  module.go:35817	0x63015d		f20f5ee3		DIVSD X3, X4									
  module.go:35819	0x630161		f20f101d871e2d00	MOVSD_XMM $f64.3fe0000000000000(SB), X3						
  module.go:35819	0x630169		f20f59dd		MULSD X5, X3									
  module.go:35819	0x63016d		f20f59dd		MULSD X5, X3									
  module.go:35821	0x630171		0f10f4			MOVUPS X4, X6									
  module.go:35821	0x630174		f20f59e4		MULSD X4, X4									
  module.go:35822	0x630178		0f10fc			MOVUPS X4, X7									
  module.go:35822	0x63017b		f20f59e4		MULSD X4, X4									
  module.go:35823	0x63017f		f2440f1005701f2d00	MOVSD_XMM $f64.3fc39a09d078c69f(SB), X8						
  module.go:35823	0x630188		f2440f59c4		MULSD X4, X8									
  module.go:35823	0x63018d		f2440f100d721f2d00	MOVSD_XMM $f64.3fcc71c51d8e78af(SB), X9						
  module.go:35823	0x630196		f2450f58c8		ADDSD X8, X9									
  module.go:35823	0x63019b		f2440f59cc		MULSD X4, X9									
  module.go:35823	0x6301a0		f2440f10056f1f2d00	MOVSD_XMM $f64.3fd999999997fa04(SB), X8						
  module.go:35823	0x6301a9		f2450f58c1		ADDSD X9, X8									
  module.go:35823	0x6301ae		f2440f59c4		MULSD X4, X8									
  module.go:35823	0x6301b3		f2440f100d341f2d00	MOVSD_XMM $f64.3fc2f112df3e5244(SB), X9						
  module.go:35823	0x6301bc		f2440f59cc		MULSD X4, X9									
  module.go:35823	0x6301c1		f2440f1015361f2d00	MOVSD_XMM $f64.3fc7466496cb03de(SB), X10					
  module.go:35823	0x6301ca		f2450f58d1		ADDSD X9, X10									
  module.go:35823	0x6301cf		f2440f59d4		MULSD X4, X10									
  module.go:35823	0x6301d4		f2440f100d331f2d00	MOVSD_XMM $f64.3fd2492494229359(SB), X9						
  module.go:35823	0x6301dd		f2450f58ca		ADDSD X10, X9									
  module.go:35823	0x6301e2		f2440f59cc		MULSD X4, X9									
  module.go:35823	0x6301e7		f20f1025311f2d00	MOVSD_XMM $f64.3fe5555555555593(SB), X4						
  module.go:35823	0x6301ef		f2410f58e1		ADDSD X9, X4									
  module.go:35823	0x6301f4		f20f59e7		MULSD X7, X4									
  module.go:35823	0x6301f8		f2440f58c4		ADDSD X4, X8									
  module.go:35823	0x6301fd		f2440f58c3		ADDSD X3, X8									
  module.go:35823	0x630202		f2410f59f0		MULSD X8, X6									
  module.go:35823	0x630207		f20f58d6		ADDSD X6, X2									
  module.go:35823	0x63020b		f20f5cd3		SUBSD X3, X2									
  module.go:35823	0x63020f		f20f58d5		ADDSD X5, X2									
  module.go:35823	0x630213		f20f58d1		ADDSD X1, X2									
  module.go:35795	0x630217		0f10c2			MOVUPS X2, X0									
  module.go:35832	0x63021a		4c8b5838		MOVQ 0x38(AX), R11								
  module.go:63009	0x63021e		4d8d623f		LEAQ 0x3f(R10), R12								
  module.go:63009	0x630222		4d39e3			CMPQ R11, R12									
  module.go:63009	0x630225		0f8609120000		JBE 0x631434									
  module.go:35713	0x63022b		898c249c000000		MOVL CX, 0x9c(SP)								
  module.go:35772	0x630232		4c89542478		MOVQ R10, 0x78(SP)								
  module.go:35832	0x630237		4c8b5830		MOVQ 0x30(AX), R11								
  unsafe.go:41		0x63023b		66490f6ec9		MOVQ R9, X1									
  module.go:35833	0x630240		f20f59c1		MULSD X1, X0									
  module.go:63010	0x630244		4f8b4c1a38		MOVQ 0x38(R10)(R11*1), R9							
  module.go:35832	0x630249		66490f6ec9		MOVQ R9, X1									
  module.go:35833	0x63024e		f20f58c1		ADDSD X1, X0									
  module.go:35833	0x630252		440fb60dbac76c00	MOVZX runtime.x86HasSSE41(SB), R9						
  module.go:35833	0x63025a		4585c9			TESTL R9, R9									
  module.go:35833	0x63025d		7408			JE 0x630267									
  module.go:35833	0x63025f		660f3a0bc001		ROUNDSD $0x1, X0, X0								
  module.go:35833	0x630265		eb24			JMP 0x63028b									
  module.go:35833	0x630267		e874afeaff		CALL math.Floor(SB)								
  module.go:35834	0x63026c		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:62984	0x630274		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:35702	0x63027b		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x63027f		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:62983	0x630286		4c8b542478		MOVQ 0x78(SP), R10								
  module.go:63074	0x63028b		f20f100d351f2d00	MOVSD_XMM $f64.c1e0000000000000(SB), X1						
  module.go:63074	0x630293		660f2ec8		UCOMISD X0, X1									
  module.go:63074	0x630297		7209			JB 0x6302a2									
  module.go:63074	0x630299		41b900000080		MOVL $-0x80000000, R9								
  module.go:63074	0x63029f		90			NOPL										
  module.go:35833	0x6302a0		eb2a			JMP 0x6302cc									
  module.go:63076	0x6302a2		f20f100d0e1f2d00	MOVSD_XMM $f64.41dfffffffc00000(SB), X1						
  module.go:63076	0x6302aa		660f2ec1		UCOMISD X1, X0									
  module.go:63076	0x6302ae		7208			JB 0x6302b8									
  module.go:63076	0x6302b0		41b9ffffff7f		MOVL $0x7fffffff, R9								
  module.go:35833	0x6302b6		eb14			JMP 0x6302cc									
  module.go:63078	0x6302b8		660f2ec0		UCOMISD X0, X0									
  module.go:63078	0x6302bc		7504			JNE 0x6302c2									
  module.go:63078	0x6302be		6690			NOPW										
  module.go:63078	0x6302c0		7b05			JNP 0x6302c7									
  module.go:63078	0x6302c2		4531c9			XORL R9, R9									
  module.go:35833	0x6302c5		eb05			JMP 0x6302cc									
  module.go:63081	0x6302c7		f2440f2cc8		CVTTSD2SIL X0, R9								
  module.go:35834	0x6302cc		4c8b5838		MOVQ 0x38(AX), R11								
  module.go:62983	0x6302d0		4d8d620f		LEAQ 0xf(R10), R12								
  module.go:62983	0x6302d4		4d39e3			CMPQ R11, R12									
  module.go:62983	0x6302d7		0f8652110000		JBE 0x63142f									
  module.go:62983	0x6302dd		4c89642470		MOVQ R12, 0x70(SP)								
  module.go:35834	0x6302e2		4c8b6830		MOVQ 0x30(AX), R13								
  module.go:62984	0x6302e6		478b7c2a0c		MOVL 0xc(R10)(R13*1), R15							
  module.go:35836	0x6302eb		4585ff			TESTL R15, R15									
  module.go:35836	0x6302ee		0f8471040000		JE 0x630765									
  module.go:62983	0x6302f4		498d7213		LEAQ 0x13(R10), SI								
  module.go:35863	0x6302f8		90			NOPL										
  module.go:35863	0x6302f9		0f1f8000000000		NOPL 0(AX)									
  module.go:62983	0x630300		4939f3			CMPQ R11, SI									
  module.go:62983	0x630303		0f8621110000		JBE 0x63142a									
  module.go:62983	0x630309		4889742468		MOVQ SI, 0x68(SP)								
  module.go:62984	0x63030e		438b7c2a10		MOVL 0x10(R10)(R13*1), DI							
  module.go:35865	0x630313		4139f9			CMPL R9, DI									
  module.go:35865	0x630316		0f8cec000000		JL 0x630408									
  module.go:35833	0x63031c		44894c2424		MOVL R9, 0x24(SP)								
  module.go:35867	0x630321		468d043f		LEAL 0(DI)(R15*1), R8								
  module.go:35866	0x630325		4129f9			SUBL DI, R9									
  module.go:35867	0x630328		8b542424		MOVL 0x24(SP), DX								
  module.go:35867	0x63032c		4439c2			CMPL DX, R8									
  module.go:35867	0x63032f		0f8cc7000000		JL 0x6303fc									
  module.go:62983	0x630335		4d8d4217		LEAQ 0x17(R10), R8								
  module.go:35871	0x630339		90			NOPL										
  module.go:35871	0x63033a		660f1f440000		NOPW 0(AX)(AX*1)								
  module.go:62983	0x630340		4d39c3			CMPQ R11, R8									
  module.go:62983	0x630343		0f86dc100000		JBE 0x631425									
  module.go:35870	0x630349		458d4101		LEAL 0x1(R9), R8								
  module.go:62984	0x63034d		438b5c1514		MOVL 0x14(R13)(R10*1), BX							
  module.go:35874	0x630352		4439c3			CMPL BX, R8									
  module.go:35874	0x630355		0f8d6b0b0000		JGE 0x630ec6									
  module.go:35877	0x63035b		4129d9			SUBL BX, R9									
  module.go:35877	0x63035e		458d4101		LEAL 0x1(R9), R8								
  module.go:35878	0x630362		4585c0			TESTL R8, R8									
  module.go:35878	0x630365		7e5e			JLE 0x6303c5									
  module.go:62983	0x630367		498d720b		LEAQ 0xb(R10), SI								
  module.go:35879	0x63036b		90			NOPL										
  module.go:62983	0x63036c		4939f3			CMPQ R11, SI									
  module.go:62983	0x63036f		0f86a9100000		JBE 0x63141e									
  module.go:35877	0x630375		44894c244c		MOVL R9, 0x4c(SP)								
  module.go:35885	0x63037a		448d1c1f		LEAL 0(DI)(BX*1), R11								
  module.go:63184	0x63037e		89cb			MOVL CX, BX									
  module.go:63184	0x630380		48895c2460		MOVQ BX, 0x60(SP)								
  module.go:35881	0x630385		90			NOPL										
  module.go:35883	0x630386		90			NOPL										
  module.go:62984	0x630387		438b4c1508		MOVL 0x8(R13)(R10*1), CX							
  module.go:63184	0x63038c		478b4c1504		MOVL 0x4(R13)(R10*1), R9							
  module.go:63184	0x630391		458b6c1d00		MOVL 0(R13)(BX*1), R13								
  module.go:35885	0x630396		4439da			CMPL DX, R11									
  module.go:35885	0x630399		750b			JNE 0x6303a6									
  module.go:36088	0x63039b		4589f8			MOVL R15, R8									
  module.go:36088	0x63039e		0f57c0			XORPS X0, X0									
  module.go:35888	0x6303a1		e9600e0000		JMP 0x631206									
  module.go:62984	0x6303a6		897c2448		MOVL DI, 0x48(SP)								
  module.go:35891	0x6303aa		4589c3			MOVL R8, R11									
  module.go:35891	0x6303ad		4181e0feffff7f		ANDL $0x7ffffffe, R8								
  module.go:35952	0x6303b4		44897c2428		MOVL R15, 0x28(SP)								
  module.go:35952	0x6303b9		0f57c0			XORPS X0, X0									
  module.go:35952	0x6303bc		0f1f4000		NOPL 0(AX)									
  module.go:35894	0x6303c0		e9bd0c0000		JMP 0x631082									
  module.go:62983	0x6303c5		4d8d4207		LEAQ 0x7(R10), R8								
  module.go:35957	0x6303c9		90			NOPL										
  module.go:62983	0x6303ca		4d39c3			CMPQ R11, R8									
  module.go:62983	0x6303cd		0f869c0c0000		JBE 0x63106f									
  module.go:63184	0x6303d3		4189c8			MOVL CX, R8									
  module.go:62983	0x6303d6		498d5a0b		LEAQ 0xb(R10), BX								
  module.go:35959	0x6303da		90			NOPL										
  module.go:35961	0x6303db		90			NOPL										
  module.go:62984	0x6303dc		478b641504		MOVL 0x4(R13)(R10*1), R12							
  module.go:63184	0x6303e1		478b440500		MOVL 0(R13)(R8*1), R8								
  module.go:62983	0x6303e6		4939db			CMPQ R11, BX									
  module.go:62983	0x6303e9		0f867b0c0000		JBE 0x63106a									
  module.go:62984	0x6303ef		478b5c1508		MOVL 0x8(R13)(R10*1), R11							
  module.go:62984	0x6303f4		0f57c0			XORPS X0, X0									
  module.go:35964	0x6303f7		e94e0a0000		JMP 0x630e4a									
  module.go:35702	0x6303fc		8b542434		MOVL 0x34(SP), DX								
  module.go:36195	0x630400		4589f8			MOVL R15, R8									
  module.go:35868	0x630403		e987070000		JMP 0x630b8f									
  module.go:62983	0x630408		4d8d4217		LEAQ 0x17(R10), R8								
  module.go:35968	0x63040c		90			NOPL										
  module.go:62983	0x63040d		4d39c3			CMPQ R11, R8									
  module.go:62983	0x630410		0f862f0a0000		JBE 0x630e45									
  module.go:35971	0x630416		4429cf			SUBL R9, DI									
  module.go:62984	0x630419		478b4c1514		MOVL 0x14(R13)(R10*1), R9							
  module.go:35969	0x63041e		4529f9			SUBL R15, R9									
  module.go:35973	0x630421		4439cf			CMPL DI, R9									
  module.go:35974	0x630424		410f47f9		CMOVA R9, DI									
  module.go:35977	0x630428		458d0c3f		LEAL 0(R15)(DI*1), R9								
  module.go:35978	0x63042c		4439cf			CMPL DI, R9									
  module.go:35973	0x63042f		0f87e4090000		JA 0x630e19									
  module.go:62983	0x630435		4d8d4203		LEAQ 0x3(R10), R8								
  module.go:35979	0x630439		90			NOPL										
  module.go:35979	0x63043a		660f1f440000		NOPW 0(AX)(AX*1)								
  module.go:62983	0x630440		4d39c3			CMPQ R11, R8									
  module.go:62983	0x630443		0f86cb090000		JBE 0x630e14									
  module.go:35974	0x630449		897c242c		MOVL DI, 0x2c(SP)								
  module.go:62984	0x63044d		4189cb			MOVL CX, R11									
  module.go:62984	0x630450		4c895c2460		MOVQ R11, 0x60(SP)								
  module.go:62984	0x630455		478b6c1d00		MOVL 0(R13)(R11*1), R13								
  module.go:62984	0x63045a		660f1f440000		NOPW 0(AX)(AX*1)								
  module.go:35982	0x630460		4539cd			CMPL R13, R9									
  module.go:35982	0x630463		0f83e9020000		JAE 0x630752									
  module.go:35992	0x630469		4589e9			MOVL R13, R9									
  module.go:35992	0x63046c		4529fd			SUBL R15, R13									
  module.go:35994	0x63046f		4439ef			CMPL DI, R13									
  module.go:35994	0x630472		7708			JA 0x63047c									
  module.go:62984	0x630474		4589c8			MOVL R9, R8									
  module.go:35995	0x630477		e98e000000		JMP 0x63050a									
  module.go:62984	0x63047c		44894c2448		MOVL R9, 0x48(SP)								
  module.go:35997	0x630481		89cb			MOVL CX, BX									
  module.go:35997	0x630483		4489f9			MOVL R15, CX									
  module.go:35997	0x630486		be08000000		MOVL $0x8, SI									
  module.go:35997	0x63048b		4189f0			MOVL SI, R8									
  module.go:35997	0x63048e		e8cdbcf9ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn3(SB)	
  module.go:35998	0x630493		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:35998	0x63049b		488b5038		MOVQ 0x38(AX), DX								
  module.go:62983	0x63049f		4c8b4c2470		MOVQ 0x70(SP), R9								
  module.go:62983	0x6304a4		4c39ca			CMPQ DX, R9									
  module.go:62983	0x6304a7		0f8662090000		JBE 0x630e0f									
  module.go:35998	0x6304ad		488b5030		MOVQ 0x30(AX), DX								
  module.go:62984	0x6304b1		488b742478		MOVQ 0x78(SP), SI								
  module.go:62984	0x6304b6		448b7c160c		MOVL 0xc(SI)(DX*1), R15								
  module.go:36001	0x6304bb		448b6c2448		MOVL 0x48(SP), R13								
  module.go:36001	0x6304c0		4589e8			MOVL R13, R8									
  module.go:36001	0x6304c3		4529f8			SUBL R15, R8									
  module.go:63184	0x6304c6		4c8b542460		MOVQ 0x60(SP), R10								
  module.go:63184	0x6304cb		418b1412		MOVL 0(R10)(DX*1), DX								
  module.go:36047	0x6304cf		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:63000	0x6304d6		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:62983	0x6304dd		488b742468		MOVQ 0x68(SP), SI								
  module.go:36042	0x6304e2		8b7c242c		MOVL 0x2c(SP), DI								
  module.go:62983	0x6304e6		4c8b542478		MOVQ 0x78(SP), R10								
  module.go:63184	0x6304eb		4c8b5c2460		MOVQ 0x60(SP), R11								
  module.go:63000	0x6304f0		4d89cc			MOVQ R9, R12									
  module.go:36002	0x6304f3		4189d1			MOVL DX, R9									
  module.go:35702	0x6304f6		8b542434		MOVL 0x34(SP), DX								
  module.go:36011	0x6304fa		4489c1			MOVL R8, CX									
  module.go:36011	0x6304fd		4589e8			MOVL R13, R8									
  module.go:36002	0x630500		4189cd			MOVL CX, R13									
  module.go:36047	0x630503		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:36006	0x63050a		488b5838		MOVQ 0x38(AX), BX								
  module.go:62983	0x63050e		4d8d5a0b		LEAQ 0xb(R10), R11								
  module.go:62983	0x630512		4c39db			CMPQ BX, R11									
  module.go:62983	0x630515		0f86ef080000		JBE 0x630e0a									
  module.go:36006	0x63051b		488b5030		MOVQ 0x30(AX), DX								
  module.go:62984	0x63051f		418b4c1208		MOVL 0x8(R10)(DX*1), CX								
  module.go:36008	0x630524		4139cd			CMPL R13, CX									
  module.go:36008	0x630527		721f			JB 0x630548									
  module.go:36047	0x630529		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:35702	0x630530		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x630534		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:63184	0x63053b		4c8b5c2460		MOVQ 0x60(SP), R11								
  module.go:36041	0x630540		4589cd			MOVL R9, R13									
  module.go:36009	0x630543		e90a020000		JMP 0x630752									
  module.go:36002	0x630548		44897c2428		MOVL R15, 0x28(SP)								
  module.go:36002	0x63054d		44894c2438		MOVL R9, 0x38(SP)								
  module.go:36011	0x630552		4589c5			MOVL R8, R13									
  module.go:36011	0x630555		4129c8			SUBL CX, R8									
  module.go:36013	0x630558		4529c7			SUBL R8, R15									
  module.go:36019	0x63055b		4529e9			SUBL R13, R9									
  module.go:36015	0x63055e		4539c7			CMPL R15, R8									
  module.go:36015	0x630561		400f92c6		SETB SI										
  module.go:36016	0x630565		400fb6f6		MOVZX SI, SI									
  module.go:36019	0x630569		4539f9			CMPL R9, R15									
  module.go:36019	0x63056c		410f93c1		SETAE R9									
  module.go:36020	0x630570		450fb6c9		MOVZX R9, R9									
  module.go:36022	0x630574		4485ce			TESTL R9, SI									
  module.go:36022	0x630577		0f85fb000000		JNE 0x630678									
  module.go:36024	0x63057d		4489c6			MOVL R8, SI									
  module.go:36024	0x630580		41c1e003		SHLL $0x3, R8									
  module.go:36023	0x630584		448b4c2438		MOVL 0x38(SP), R9								
  module.go:36023	0x630589		4589cd			MOVL R9, R13									
  module.go:36023	0x63058c		4129f1			SUBL SI, R9									
  module.go:36025	0x63058f		4585c0			TESTL R8, R8									
  module.go:36025	0x630592		0f849e000000		JE 0x630636									
  module.go:62983	0x630598		498d7207		LEAQ 0x7(R10), SI								
  module.go:36026	0x63059c		90			NOPL										
  module.go:36026	0x63059d		0f1f00			NOPL 0(AX)									
  module.go:62983	0x6305a0		4839f3			CMPQ BX, SI									
  module.go:62983	0x6305a3		0f865c080000		JBE 0x630e05									
  module.go:62984	0x6305a9		428b741204		MOVL 0x4(DX)(R10*1), SI								
  module.go:36028	0x6305ae		468d3cce		LEAL 0(SI)(R9*8), R15								
  module.go:36028	0x6305b2		8d34ce			LEAL 0(SI)(CX*8), SI								
  module.go:63109	0x6305b5		4589ff			MOVL R15, R15									
  module.go:63110	0x6305b8		89f6			MOVL SI, SI									
  module.go:63111	0x6305ba		4489c1			MOVL R8, CX									
  module.go:63111	0x6305bd		4e8d0439		LEAQ 0(CX)(R15*1), R8								
  module.go:63112	0x6305c1		4c8d2431		LEAQ 0(CX)(SI*1), R12								
  module.go:63113	0x6305c5		4c39c3			CMPQ BX, R8									
  module.go:63113	0x6305c8		0f8230080000		JB 0x630dfe									
  module.go:63113	0x6305ce		4d89f8			MOVQ R15, R8									
  module.go:63113	0x6305d1		4929df			SUBQ BX, R15									
  module.go:63113	0x6305d4		49c1ff3f		SARQ $0x3f, R15									
  module.go:63113	0x6305d8		4d21f8			ANDQ R15, R8									
  module.go:63113	0x6305db		4901d0			ADDQ DX, R8									
  module.go:63113	0x6305de		6690			NOPW										
  module.go:63113	0x6305e0		4c39e3			CMPQ BX, R12									
  module.go:63113	0x6305e3		0f8210080000		JB 0x630df9									
  module.go:63113	0x6305e9		4989f4			MOVQ SI, R12									
  module.go:63113	0x6305ec		4829de			SUBQ BX, SI									
  module.go:63113	0x6305ef		48c1fe3f		SARQ $0x3f, SI									
  module.go:63113	0x6305f3		4921f4			ANDQ SI, R12									
  module.go:63113	0x6305f6		498d1c14		LEAQ 0(R12)(DX*1), BX								
  module.go:63113	0x6305fa		4c39c3			CMPQ BX, R8									
  module.go:63113	0x6305fd		7432			JE 0x630631									
  module.go:62983	0x6305ff		4c895c2458		MOVQ R11, 0x58(SP)								
  module.go:36023	0x630604		44894c2430		MOVL R9, 0x30(SP)								
  module.go:63113	0x630609		4c89c0			MOVQ R8, AX									
  module.go:63113	0x63060c		e84f07e6ff		CALL runtime.memmove(SB)							
  module.go:36030	0x630611		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:36042	0x630619		8b7c242c		MOVL 0x2c(SP), DI								
  module.go:63001	0x63061d		448b4c2430		MOVL 0x30(SP), R9								
  module.go:63001	0x630622		4c8b542478		MOVQ 0x78(SP), R10								
  module.go:63000	0x630627		4c8b5c2458		MOVQ 0x58(SP), R11								
  module.go:36041	0x63062c		448b6c2438		MOVL 0x38(SP), R13								
  module.go:63000	0x630631		4c8b642470		MOVQ 0x70(SP), R12								
  module.go:36030	0x630636		488b5038		MOVQ 0x38(AX), DX								
  module.go:36030	0x63063a		660f1f440000		NOPW 0(AX)(AX*1)								
  module.go:63000	0x630640		4c39da			CMPQ DX, R11									
  module.go:63000	0x630643		0f86ab070000		JBE 0x630df4									
  module.go:36030	0x630649		488b5030		MOVQ 0x30(AX), DX								
  module.go:63001	0x63064d		45894c1208		MOVL R9, 0x8(R10)(DX*1)								
  module.go:36047	0x630652		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:35702	0x630659		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x63065d		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:62983	0x630664		488b742468		MOVQ 0x68(SP), SI								
  module.go:63184	0x630669		4c8b5c2460		MOVQ 0x60(SP), R11								
  module.go:36041	0x63066e		448b7c2428		MOVL 0x28(SP), R15								
  module.go:36031	0x630673		e9da000000		JMP 0x630752									
  module.go:36033	0x630678		41c1e703		SHLL $0x3, R15									
  module.go:36033	0x63067c		0f1f4000		NOPL 0(AX)									
  module.go:36034	0x630680		4585ff			TESTL R15, R15									
  module.go:36034	0x630683		752b			JNE 0x6306b0									
  module.go:36047	0x630685		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:35702	0x63068c		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x630690		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:62983	0x630697		488b742468		MOVQ 0x68(SP), SI								
  module.go:63184	0x63069c		4c8b5c2460		MOVQ 0x60(SP), R11								
  module.go:36041	0x6306a1		448b7c2428		MOVL 0x28(SP), R15								
  module.go:36041	0x6306a6		448b6c2438		MOVL 0x38(SP), R13								
  module.go:36035	0x6306ab		e9a2000000		JMP 0x630752									
  module.go:62983	0x6306b0		498d7207		LEAQ 0x7(R10), SI								
  module.go:36037	0x6306b4		90			NOPL										
  module.go:62983	0x6306b5		4839f3			CMPQ BX, SI									
  module.go:62983	0x6306b8		0f8631070000		JBE 0x630def									
  module.go:62984	0x6306be		428b741204		MOVL 0x4(DX)(R10*1), SI								
  module.go:36039	0x6306c3		468d04ee		LEAL 0(SI)(R13*8), R8								
  module.go:63109	0x6306c7		4589c0			MOVL R8, R8									
  module.go:63111	0x6306ca		4489f9			MOVL R15, CX									
  module.go:63111	0x6306cd		4e8d0c01		LEAQ 0(CX)(R8*1), R9								
  module.go:63112	0x6306d1		4c8d1c31		LEAQ 0(CX)(SI*1), R11								
  module.go:63113	0x6306d5		4c39cb			CMPQ BX, R9									
  module.go:63113	0x6306d8		0f820c070000		JB 0x630dea									
  module.go:63113	0x6306de		4d89c1			MOVQ R8, R9									
  module.go:63113	0x6306e1		4929d8			SUBQ BX, R8									
  module.go:63113	0x6306e4		49c1f83f		SARQ $0x3f, R8									
  module.go:63113	0x6306e8		4d21c1			ANDQ R8, R9									
  module.go:63113	0x6306eb		4d8d0411		LEAQ 0(R9)(DX*1), R8								
  module.go:63113	0x6306ef		4c39db			CMPQ BX, R11									
  module.go:63113	0x6306f2		0f82ed060000		JB 0x630de5									
  module.go:63113	0x6306f8		4189f1			MOVL SI, R9									
  module.go:63113	0x6306fb		4829de			SUBQ BX, SI									
  module.go:63113	0x6306fe		48c1fe3f		SARQ $0x3f, SI									
  module.go:63113	0x630702		4c21ce			ANDQ R9, SI									
  module.go:63113	0x630705		488d1c16		LEAQ 0(SI)(DX*1), BX								
  module.go:63113	0x630709		4c39c3			CMPQ BX, R8									
  module.go:63113	0x63070c		741e			JE 0x63072c									
  module.go:63113	0x63070e		4c89c0			MOVQ R8, AX									
  module.go:63113	0x630711		e84a06e6ff		CALL runtime.memmove(SB)							
  module.go:36055	0x630716		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:36042	0x63071e		8b7c242c		MOVL 0x2c(SP), DI								
  module.go:63001	0x630722		4c8b542478		MOVQ 0x78(SP), R10								
  module.go:63000	0x630727		4c8b642470		MOVQ 0x70(SP), R12								
  module.go:36047	0x63072c		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:35702	0x630733		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x630737		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:62983	0x63073e		488b742468		MOVQ 0x68(SP), SI								
  module.go:63184	0x630743		4c8b5c2460		MOVQ 0x60(SP), R11								
  module.go:36041	0x630748		448b7c2428		MOVL 0x28(SP), R15								
  module.go:36041	0x63074d		448b6c2438		MOVL 0x38(SP), R13								
  module.go:36042	0x630752		85ff			TESTL DI, DI									
  module.go:36042	0x630754		0f842b050000		JE 0x630c85									
  module.go:35974	0x63075a		4189f8			MOVL DI, R8									
  module.go:35974	0x63075d		0f1f00			NOPL 0(AX)									
  module.go:36044	0x630760		e95b050000		JMP 0x630cc0									
  module.go:63000	0x630765		498d7213		LEAQ 0x13(R10), SI								
  module.go:35837	0x630769		90			NOPL										
  module.go:63000	0x63076a		4939f3			CMPQ R11, SI									
  module.go:63000	0x63076d		0f860b050000		JBE 0x630c7e									
  module.go:63001	0x630773		47894c2a10		MOVL R9, 0x10(R10)(R13*1)							
  module.go:35839	0x630778		488b7038		MOVQ 0x38(AX), SI								
  module.go:62983	0x63077c		4d8d4203		LEAQ 0x3(R10), R8								
  module.go:62983	0x630780		4c39c6			CMPQ SI, R8									
  module.go:62983	0x630783		0f86f0040000		JBE 0x630c79									
  module.go:35839	0x630789		488b7030		MOVQ 0x30(AX), SI								
  module.go:62984	0x63078d		4189c9			MOVL CX, R9									
  module.go:62984	0x630790		418b3431		MOVL 0(R9)(SI*1), SI								
  module.go:35841	0x630794		85f6			TESTL SI, SI									
  module.go:35841	0x630796		7404			JE 0x63079c									
  module.go:35841	0x630798		31ff			XORL DI, DI									
  module.go:35841	0x63079a		eb71			JMP 0x63080d									
  module.go:62983	0x63079c		4c89442468		MOVQ R8, 0x68(SP)								
  module.go:62984	0x6307a1		4c894c2460		MOVQ R9, 0x60(SP)								
  module.go:35842	0x6307a6		89cb			MOVL CX, BX									
  module.go:35842	0x6307a8		e8d340fbff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn88(SB)	
  module.go:35843	0x6307ad		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:35843	0x6307b5		488b4838		MOVQ 0x38(AX), CX								
  module.go:62983	0x6307b9		488b542468		MOVQ 0x68(SP), DX								
  module.go:62983	0x6307be		6690			NOPW										
  module.go:62983	0x6307c0		4839d1			CMPQ CX, DX									
  module.go:62983	0x6307c3		0f86ab040000		JBE 0x630c74									
  module.go:35843	0x6307c9		488b5030		MOVQ 0x30(AX), DX								
  module.go:62984	0x6307cd		488b742460		MOVQ 0x60(SP), SI								
  module.go:62984	0x6307d2		8b3416			MOVL 0(SI)(DX*1), SI								
  module.go:62983	0x6307d5		4c8b442470		MOVQ 0x70(SP), R8								
  module.go:62983	0x6307da		660f1f440000		NOPW 0(AX)(AX*1)								
  module.go:62983	0x6307e0		4c39c1			CMPQ CX, R8									
  module.go:62983	0x6307e3		0f8686040000		JBE 0x630c6f									
  module.go:62984	0x6307e9		4c8b4c2478		MOVQ 0x78(SP), R9								
  module.go:62984	0x6307ee		418b54110c		MOVL 0xc(R9)(DX*1), DX								
  module.go:63184	0x6307f3		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:63000	0x6307fa		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:63001	0x630801		4d89ca			MOVQ R9, R10									
  module.go:63000	0x630804		4d89c4			MOVQ R8, R12									
  module.go:35845	0x630807		89d7			MOVL DX, DI									
  module.go:35702	0x630809		8b542434		MOVL 0x34(SP), DX								
  module.go:35850	0x63080d		4c8b4038		MOVQ 0x38(AX), R8								
  module.go:63000	0x630811		4d39e0			CMPQ R8, R12									
  module.go:63000	0x630814		0f8650040000		JBE 0x630c6a									
  module.go:35849	0x63081a		448d4701		LEAL 0x1(DI), R8								
  module.go:35850	0x63081e		4c8b4830		MOVQ 0x30(AX), R9								
  module.go:63001	0x630822		4789440a0c		MOVL R8, 0xc(R10)(R9*1)								
  module.go:35851	0x630827		4c8b4838		MOVQ 0x38(AX), R9								
  module.go:62983	0x63082b		4d8d5a07		LEAQ 0x7(R10), R11								
  module.go:62983	0x63082f		4d39d9			CMPQ R9, R11									
  module.go:62983	0x630832		0f862d040000		JBE 0x630c65									
  module.go:35851	0x630838		4c8b5830		MOVQ 0x30(AX), R11								
  module.go:62983	0x63083c		4d8d620b		LEAQ 0xb(R10), R12								
  module.go:35852	0x630840		90			NOPL										
  module.go:62984	0x630841		478b6c1a04		MOVL 0x4(R10)(R11*1), R13							
  module.go:62983	0x630846		4d39e1			CMPQ R9, R12									
  module.go:62983	0x630849		0f860e040000		JBE 0x630c5d									
  module.go:62984	0x63084f		478b641a08		MOVL 0x8(R10)(R11*1), R12							
  module.go:35853	0x630854		4101fc			ADDL DI, R12									
  module.go:35856	0x630857		4439e6			CMPL SI, R12									
  module.go:35857	0x63085a		41bf00000000		MOVL $0x0, R15									
  module.go:35857	0x630860		440f46fe		CMOVBE SI, R15									
  module.go:35859	0x630864		4529fc			SUBL R15, R12									
  module.go:35859	0x630867		438d74e500		LEAL 0(R13)(R12*8), SI								
  module.go:63026	0x63086c		4189f4			MOVL SI, R12									
  module.go:63026	0x63086f		4983c407		ADDQ $0x7, R12									
  module.go:63026	0x630873		4d39e1			CMPQ R9, R12									
  module.go:35856	0x630876		0f86dc030000		JBE 0x630c58									
  module.go:63027	0x63087c		89f6			MOVL SI, SI									
  module.go:63027	0x63087e		49c7043300000000	MOVQ $0x0, 0(R11)(SI*1)								
  module.go:63027	0x630886		4531c9			XORL R9, R9									
  module.go:35860	0x630889		e901030000		JMP 0x630b8f									
  module.go:36080	0x63088e		488b7038		MOVQ 0x38(AX), SI								
  module.go:63009	0x630892		498d7a1f		LEAQ 0x1f(R10), DI								
  module.go:63009	0x630896		4839fe			CMPQ SI, DI									
  module.go:63009	0x630899		0f86eb020000		JBE 0x630b8a									
  module.go:36080	0x63089f		488b7030		MOVQ 0x30(AX), SI								
  module.go:36081	0x6308a3		4c8b4038		MOVQ 0x38(AX), R8								
  module.go:63010	0x6308a7		498b743218		MOVQ 0x18(R10)(SI*1), SI							
  unsafe.go:41		0x6308ac		66480f6ec6		MOVQ SI, X0									
  module.go:36081	0x6308b1		f20f100daf162d00	MOVSD_XMM $f64.3ff0000000000000(SB), X1						
  module.go:36081	0x6308b9		f20f58c8		ADDSD X0, X1									
  module.go:36081	0x6308bd		0f1f00			NOPL 0(AX)									
  module.go:63026	0x6308c0		4939f8			CMPQ R8, DI									
  module.go:63026	0x6308c3		0f86bc020000		JBE 0x630b85									
  module.go:36081	0x6308c9		488b7030		MOVQ 0x30(AX), SI								
  module.go:63027	0x6308cd		f2410f114c3218		MOVSD_XMM X1, 0x18(R10)(SI*1)							
  module.go:36082	0x6308d4		e99f020000		JMP 0x630b78									
  module.go:35705	0x6308d9		8974244c		MOVL SI, 0x4c(SP)								
  module.go:35739	0x6308dd		bb10000000		MOVL $0x10, BX									
  module.go:35739	0x6308e2		b901000000		MOVL $0x1, CX									
  module.go:35739	0x6308e7		e874baf9ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn4(SB)	
  module.go:35741	0x6308ec		85c0			TESTL AX, AX									
  module.go:35741	0x6308ee		0f8456020000		JE 0x630b4a									
  module.go:35742	0x6308f4		488b942490000000	MOVQ 0x90(SP), DX								
  module.go:35742	0x6308fc		488b7238		MOVQ 0x38(DX), SI								
  module.go:63109	0x630900		89c7			MOVL AX, DI									
  module.go:63111	0x630902		4c8d4710		LEAQ 0x10(DI), R8								
  module.go:63113	0x630906		4c39c6			CMPQ SI, R8									
  module.go:63113	0x630909		0f8236020000		JB 0x630b45									
  module.go:35742	0x63090f		4c8b4230		MOVQ 0x30(DX), R8								
  module.go:63113	0x630913		4c01c7			ADDQ R8, DI									
  module.go:63113	0x630916		660f1f840000000000	NOPW 0(AX)(AX*1)								
  module.go:63113	0x63091f		90			NOPL										
  module.go:63113	0x630920		4881fe718e1000		CMPQ SI, $0x108e71								
  module.go:63113	0x630927		0f820c020000		JB 0x630b39									
  module.go:35739	0x63092d		89442428		MOVL AX, 0x28(SP)								
  module.go:63113	0x630931		498db0618e1000		LEAQ 0x108e61(R8), SI								
  module.go:63113	0x630938		4839fe			CMPQ SI, DI									
  module.go:63113	0x63093b		740b			JE 0x630948									
  module.go:63113	0x63093d		410f1080618e1000	MOVUPS 0x108e61(R8), X0								
  module.go:63113	0x630945		0f1107			MOVUPS X0, 0(DI)								
  module.go:35743	0x630948		4889d0			MOVQ DX, AX									
  module.go:35743	0x63094b		bb0c000000		MOVL $0xc, BX									
  module.go:35743	0x630950		b904000000		MOVL $0x4, CX									
  module.go:35743	0x630955		e806baf9ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn4(SB)	
  module.go:35743	0x63095a		660f1f440000		NOPW 0(AX)(AX*1)								
  module.go:35745	0x630960		85c0			TESTL AX, AX									
  module.go:35745	0x630962		0f84a7010000		JE 0x630b0f									
  module.go:35749	0x630968		488b8c2490000000	MOVQ 0x90(SP), CX								
  module.go:35749	0x630970		488b5138		MOVQ 0x38(CX), DX								
  module.go:35749	0x630974		89c3			MOVL AX, BX									
  module.go:63000	0x630976		488d730b		LEAQ 0xb(BX), SI								
  module.go:63000	0x63097a		660f1f440000		NOPW 0(AX)(AX*1)								
  module.go:63000	0x630980		4839f2			CMPQ DX, SI									
  module.go:63000	0x630983		0f8681010000		JBE 0x630b0a									
  module.go:35749	0x630989		488b5130		MOVQ 0x30(CX), DX								
  module.go:63001	0x63098d		c744130810000000	MOVL $0x10, 0x8(BX)(DX*1)							
  module.go:35750	0x630995		488b5138		MOVQ 0x38(CX), DX								
  module.go:63000	0x630999		488d7307		LEAQ 0x7(BX), SI								
  module.go:63000	0x63099d		0f1f00			NOPL 0(AX)									
  module.go:63000	0x6309a0		4839f2			CMPQ DX, SI									
  module.go:63000	0x6309a3		0f865c010000		JBE 0x630b05									
  module.go:35750	0x6309a9		488b5130		MOVQ 0x30(CX), DX								
  module.go:63001	0x6309ad		8b742428		MOVL 0x28(SP), SI								
  module.go:63001	0x6309b1		89741304		MOVL SI, 0x4(BX)(DX*1)								
  module.go:35751	0x6309b5		488b5138		MOVQ 0x38(CX), DX								
  module.go:63000	0x6309b9		4883c303		ADDQ $0x3, BX									
  module.go:63000	0x6309bd		0f1f00			NOPL 0(AX)									
  module.go:63000	0x6309c0		4839da			CMPQ DX, BX									
  module.go:63000	0x6309c3		0f8635010000		JBE 0x630afe									
  module.go:35737	0x6309c9		8b542434		MOVL 0x34(SP), DX								
  module.go:35737	0x6309cd		8d5ae8			LEAL -0x18(DX), BX								
  module.go:35751	0x6309d0		488b7130		MOVQ 0x30(CX), SI								
  module.go:35752	0x6309d4		89df			MOVL BX, DI									
  module.go:63001	0x6309d6		4189c0			MOVL AX, R8									
  module.go:63001	0x6309d9		42c7040610000000	MOVL $0x10, 0(SI)(R8*1)								
  module.go:35752	0x6309e1		488b7138		MOVQ 0x38(CX), SI								
  module.go:63000	0x6309e5		4c8d4707		LEAQ 0x7(DI), R8								
  module.go:63000	0x6309e9		4c39c6			CMPQ SI, R8									
  module.go:63000	0x6309ec		0f8607010000		JBE 0x630af9									
  module.go:35752	0x6309f2		488b7130		MOVQ 0x30(CX), SI								
  module.go:63001	0x6309f6		c744370490931000	MOVL $0x109390, 0x4(DI)(SI*1)							
  module.go:35753	0x6309fe		488b7138		MOVQ 0x38(CX), SI								
  module.go:63000	0x630a02		4883c703		ADDQ $0x3, DI									
  module.go:63000	0x630a06		4839fe			CMPQ SI, DI									
  module.go:63000	0x630a09		0f86e5000000		JBE 0x630af4									
  module.go:35753	0x630a0f		488b7130		MOVQ 0x30(CX), SI								
  module.go:35755	0x630a13		8b7c244c		MOVL 0x4c(SP), DI								
  module.go:35755	0x630a17		89ff			MOVL DI, DI									
  module.go:63001	0x630a19		89db			MOVL BX, BX									
  module.go:63001	0x630a1b		89041e			MOVL AX, 0(SI)(BX*1)								
  module.go:35755	0x630a1e		488b4138		MOVQ 0x38(CX), AX								
  module.go:62983	0x630a22		488d5f0f		LEAQ 0xf(DI), BX								
  module.go:62983	0x630a26		4839d8			CMPQ AX, BX									
  module.go:62983	0x630a29		0f86c0000000		JBE 0x630aef									
  module.go:35755	0x630a2f		488b4130		MOVQ 0x30(CX), AX								
  module.go:62984	0x630a33		8b5c070c		MOVL 0xc(DI)(AX*1), BX								
  module.go:63184	0x630a37		8b440708		MOVL 0x8(DI)(AX*1), AX								
  module.go:35702	0x630a3b		8d72f8			LEAL -0x8(DX), SI								
  module.go:36219	0x630a3e		488b7938		MOVQ 0x38(CX), DI								
  module.go:36220	0x630a42		4189f0			MOVL SI, R8									
  module.go:63000	0x630a45		4d8d4807		LEAQ 0x7(R8), R9								
  module.go:63000	0x630a49		4c39cf			CMPQ DI, R9									
  module.go:63000	0x630a4c		0f8698000000		JBE 0x630aea									
  module.go:36219	0x630a52		4c8b4930		MOVQ 0x30(CX), R9								
  module.go:63001	0x630a56		43895c0804		MOVL BX, 0x4(R8)(R9*1)								
  module.go:63000	0x630a5b		498d5803		LEAQ 0x3(R8), BX								
  module.go:36221	0x630a5f		90			NOPL										
  module.go:63000	0x630a60		4839df			CMPQ DI, BX									
  module.go:63000	0x630a63		0f867c000000		JBE 0x630ae5									
  module.go:35700	0x630a69		8d5af0			LEAL -0x10(DX), BX								
  module.go:36226	0x630a6c		89df			MOVL BX, DI									
  module.go:63001	0x630a6e		89f6			MOVL SI, SI									
  module.go:63001	0x630a70		41890431		MOVL AX, 0(R9)(SI*1)								
  module.go:36222	0x630a74		895950			MOVL BX, 0x50(CX)								
  module.go:36226	0x630a77		488b4138		MOVQ 0x38(CX), AX								
  module.go:62983	0x630a7b		488d5f0f		LEAQ 0xf(DI), BX								
  module.go:62983	0x630a7f		90			NOPL										
  module.go:62983	0x630a80		4839d8			CMPQ AX, BX									
  module.go:62983	0x630a83		7657			JBE 0x630adc									
  module.go:36226	0x630a85		488b5930		MOVQ 0x30(CX), BX								
  module.go:62983	0x630a89		488d770b		LEAQ 0xb(DI), SI								
  module.go:36229	0x630a8d		90			NOPL										
  module.go:62984	0x630a8e		448b441f0c		MOVL 0xc(DI)(BX*1), R8								
  module.go:62983	0x630a93		4839f0			CMPQ AX, SI									
  module.go:62983	0x630a96		763f			JBE 0x630ad7									
  module.go:63000	0x630a98		8bb42498000000		MOVL 0x98(SP), SI								
  module.go:63000	0x630a9f		4189f1			MOVL SI, R9									
  module.go:63000	0x630aa2		4d8d5103		LEAQ 0x3(R9), R10								
  module.go:36230	0x630aa6		90			NOPL										
  module.go:62984	0x630aa7		8b7c1f08		MOVL 0x8(DI)(BX*1), DI								
  module.go:63000	0x630aab		4c39d0			CMPQ AX, R10									
  module.go:63000	0x630aae		7622			JBE 0x630ad2									
  module.go:63001	0x630ab0		89f6			MOVL SI, SI									
  module.go:63001	0x630ab2		893c33			MOVL DI, 0(BX)(SI*1)								
  module.go:63000	0x630ab5		498d7107		LEAQ 0x7(R9), SI								
  module.go:36231	0x630ab9		90			NOPL										
  module.go:63000	0x630aba		4839f0			CMPQ AX, SI									
  module.go:63000	0x630abd		760e			JBE 0x630acd									
  module.go:63001	0x630abf		4589441904		MOVL R8, 0x4(R9)(BX*1)								
  module.go:36232	0x630ac4		895150			MOVL DX, 0x50(CX)								
  module.go:36233	0x630ac7		4883ec80		SUBQ $-0x80, SP									
  module.go:36233	0x630acb		5d			POPQ BP										
  module.go:36233	0x630acc		c3			RET										
  module.go:63000	0x630acd		e8eefee5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630ad2		e8e9fee5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630ad7		e8e4fee5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630adc		0f1f4000		NOPL 0(AX)									
  module.go:62983	0x630ae0		e8dbfee5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630ae5		e8d6fee5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630aea		e8d1fee5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630aef		e8ccfee5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630af4		e8c7fee5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630af9		e8c2fee5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630afe		6690			NOPW										
  module.go:63000	0x630b00		e8bbfee5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630b05		e8b6fee5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630b0a		e8b1fee5ff		CALL runtime.panicBounds(SB)							
  module.go:35746	0x630b0f		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:35746	0x630b17		bb04000000		MOVL $0x4, BX									
  module.go:35746	0x630b1c		b90c000000		MOVL $0xc, CX									
  module.go:35746	0x630b21		e81a3cfaff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn35(SB)	
  module.go:35747	0x630b26		488d05f39e2100		LEAQ 0x219ef3(IP), AX								
  module.go:35747	0x630b2d		488d1dbc172d00		LEAQ 0x2d17bc(IP), BX								
  module.go:35747	0x630b34		e8a77ce5ff		CALL runtime.gopanic(SB)							
  module.go:63113	0x630b39		48c7c0718e1000		MOVQ $0x108e71, AX								
  module.go:63113	0x630b40		e87bfee5ff		CALL runtime.panicBounds(SB)							
  module.go:63113	0x630b45		e876fee5ff		CALL runtime.panicBounds(SB)							
  module.go:35762	0x630b4a		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:35762	0x630b52		bb01000000		MOVL $0x1, BX									
  module.go:35762	0x630b57		b910000000		MOVL $0x10, CX									
  module.go:35762	0x630b5c		0f1f4000		NOPL 0(AX)									
  module.go:35762	0x630b60		e87bb5f9ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn2(SB)	
  module.go:35763	0x630b65		488d05b49e2100		LEAQ 0x219eb4(IP), AX								
  module.go:35763	0x630b6c		488d1d7d172d00		LEAQ 0x2d177d(IP), BX								
  module.go:35763	0x630b73		e8687ce5ff		CALL runtime.gopanic(SB)							
  module.go:35757	0x630b78		89cb			MOVL CX, BX									
  module.go:36219	0x630b7a		4889c1			MOVQ AX, CX									
  module.go:36219	0x630b7d		31c0			XORL AX, AX									
  module.go:36219	0x630b7f		90			NOPL										
  module.go:36217	0x630b80		e9b6feffff		JMP 0x630a3b									
  module.go:63026	0x630b85		e836fee5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x630b8a		e831fee5ff		CALL runtime.panicBounds(SB)							
  module.go:36196	0x630b8f		4539c8			CMPL R8, R9									
  module.go:36196	0x630b92		0f8697000000		JBE 0x630c2f									
  module.go:36200	0x630b98		488b7038		MOVQ 0x38(AX), SI								
  module.go:62983	0x630b9c		498d7a07		LEAQ 0x7(R10), DI								
  module.go:62983	0x630ba0		4839fe			CMPQ SI, DI									
  module.go:62983	0x630ba3		0f8681000000		JBE 0x630c2a									
  module.go:36200	0x630ba9		488b7830		MOVQ 0x30(AX), DI								
  module.go:62983	0x630bad		4d8d420b		LEAQ 0xb(R10), R8								
  module.go:36201	0x630bb1		90			NOPL										
  module.go:62984	0x630bb2		458b5c3a04		MOVL 0x4(R10)(DI*1), R11							
  module.go:62983	0x630bb7		4c39c6			CMPQ SI, R8									
  module.go:62983	0x630bba		7669			JBE 0x630c25									
  module.go:62984	0x630bbc		458b443a08		MOVL 0x8(R10)(DI*1), R8								
  module.go:36202	0x630bc1		4501c8			ADDL R9, R8									
  module.go:63184	0x630bc4		89c9			MOVL CX, CX									
  module.go:63184	0x630bc6		8b0c39			MOVL 0(CX)(DI*1), CX								
  module.go:36203	0x630bc9		90			NOPL										
  module.go:36207	0x630bca		4439c1			CMPL CX, R8									
  module.go:36207	0x630bcd		7602			JBE 0x630bd1									
  module.go:36207	0x630bcf		31c9			XORL CX, CX									
  module.go:36210	0x630bd1		4129c8			SUBL CX, R8									
  module.go:36210	0x630bd4		438d0cc3		LEAL 0(R11)(R8*8), CX								
  module.go:63009	0x630bd8		4189c8			MOVL CX, R8									
  module.go:63009	0x630bdb		4983c007		ADDQ $0x7, R8									
  module.go:36211	0x630bdf		90			NOPL										
  module.go:63009	0x630be0		4c39c6			CMPQ SI, R8									
  module.go:63009	0x630be3		7636			JBE 0x630c1b									
  module.go:36212	0x630be5		488b7038		MOVQ 0x38(AX), SI								
  module.go:63010	0x630be9		4189c9			MOVL CX, R9									
  module.go:63010	0x630bec		498b3c39		MOVQ 0(R9)(DI*1), DI								
  unsafe.go:41		0x630bf0		66480f6ec7		MOVQ DI, X0									
  module.go:36211	0x630bf5		90			NOPL										
  module.go:36212	0x630bf6		f20f100d6a132d00	MOVSD_XMM $f64.3ff0000000000000(SB), X1						
  module.go:36212	0x630bfe		f20f58c1		ADDSD X1, X0									
  module.go:63026	0x630c02		4c39c6			CMPQ SI, R8									
  module.go:63026	0x630c05		760f			JBE 0x630c16									
  module.go:36212	0x630c07		488b7030		MOVQ 0x30(AX), SI								
  module.go:63027	0x630c0b		f2420f11040e		MOVSD_XMM X0, 0(SI)(R9*1)							
  module.go:36215	0x630c11		e962ffffff		JMP 0x630b78									
  module.go:63026	0x630c16		e8a5fde5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x630c1b		0f1f440000		NOPL 0(AX)(AX*1)								
  module.go:63009	0x630c20		e89bfde5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630c25		e896fde5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630c2a		e891fde5ff		CALL runtime.panicBounds(SB)							
  module.go:36197	0x630c2f		bbf88e1000		MOVL $0x108ef8, BX								
  module.go:36197	0x630c34		b914000000		MOVL $0x14, CX									
  module.go:36197	0x630c39		bf0c8f1000		MOVL $0x108f0c, DI								
  module.go:36197	0x630c3e		6690			NOPW										
  module.go:36197	0x630c40		e85bedfaff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn69(SB)	
  module.go:36198	0x630c45		488d05d49d2100		LEAQ 0x219dd4(IP), AX								
  module.go:36198	0x630c4c		488d1d9d162d00		LEAQ 0x2d169d(IP), BX								
  module.go:36198	0x630c53		e8887be5ff		CALL runtime.gopanic(SB)							
  module.go:63026	0x630c58		e863fde5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630c5d		0f1f00			NOPL 0(AX)									
  module.go:62983	0x630c60		e85bfde5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630c65		e856fde5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630c6a		e851fde5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630c6f		e84cfde5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630c74		e847fde5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630c79		e842fde5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630c7e		6690			NOPW										
  module.go:63000	0x630c80		e83bfde5ff		CALL runtime.panicBounds(SB)							
  module.go:36074	0x630c85		4c8b4038		MOVQ 0x38(AX), R8								
  module.go:62983	0x630c89		4939f0			CMPQ R8, SI									
  module.go:62983	0x630c8c		7617			JBE 0x630ca5									
  module.go:36074	0x630c8e		488b7030		MOVQ 0x30(AX), SI								
  module.go:36075	0x630c92		90			NOPL										
  module.go:63001	0x630c93		41297c3210		SUBL DI, 0x10(R10)(SI*1)							
  module.go:63001	0x630c98		4531c9			XORL R9, R9									
  module.go:36195	0x630c9b		4589f8			MOVL R15, R8									
  module.go:36195	0x630c9e		6690			NOPW										
  module.go:36077	0x630ca0		e9eafeffff		JMP 0x630b8f									
  module.go:62983	0x630ca5		e816fde5ff		CALL runtime.panicBounds(SB)							
  module.go:36068	0x630caa		ffcf			DECL DI										
  module.go:35702	0x630cac		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x630cb0		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:63184	0x630cb7		4c8b5c2460		MOVQ 0x60(SP), R11								
  module.go:36070	0x630cbc		4589cf			MOVL R9, R15									
  module.go:36070	0x630cbf		90			NOPL										
  module.go:36046	0x630cc0		4539ef			CMPL R15, R13									
  module.go:36046	0x630cc3		756a			JNE 0x630d2f									
  module.go:36070	0x630cc5		897c244c		MOVL DI, 0x4c(SP)								
  module.go:36047	0x630cc9		89cb			MOVL CX, BX									
  module.go:36047	0x630ccb		e8b03bfbff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn88(SB)	
  module.go:36048	0x630cd0		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:36048	0x630cd8		488b4838		MOVQ 0x38(AX), CX								
  module.go:62983	0x630cdc		488b542470		MOVQ 0x70(SP), DX								
  module.go:62983	0x630ce1		4839d1			CMPQ CX, DX									
  module.go:62983	0x630ce4		0f86f2000000		JBE 0x630ddc									
  module.go:36048	0x630cea		488b7030		MOVQ 0x30(AX), SI								
  module.go:36050	0x630cee		90			NOPL										
  module.go:62984	0x630cef		4c8b442478		MOVQ 0x78(SP), R8								
  module.go:62984	0x630cf4		458b7c300c		MOVL 0xc(R8)(SI*1), R15								
  module.go:63184	0x630cf9		4c8b4c2460		MOVQ 0x60(SP), R9								
  module.go:63184	0x630cfe		458b2c31		MOVL 0(R9)(SI*1), R13								
  module.go:36047	0x630d02		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:35702	0x630d09		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x630d0d		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:62983	0x630d14		488b742468		MOVQ 0x68(SP), SI								
  module.go:36069	0x630d19		8b7c244c		MOVL 0x4c(SP), DI								
  module.go:63001	0x630d1d		448b44242c		MOVL 0x2c(SP), R8								
  module.go:63001	0x630d22		4c8b542478		MOVQ 0x78(SP), R10								
  module.go:63184	0x630d27		4d89cb			MOVQ R9, R11									
  module.go:63000	0x630d2a		4c8b642470		MOVQ 0x70(SP), R12								
  module.go:36055	0x630d2f		4c8b4838		MOVQ 0x38(AX), R9								
  module.go:63000	0x630d33		4d39e1			CMPQ R9, R12									
  module.go:63000	0x630d36		0f869b000000		JBE 0x630dd7									
  module.go:36054	0x630d3c		458d4f01		LEAL 0x1(R15), R9								
  module.go:36055	0x630d40		4c8b7830		MOVQ 0x30(AX), R15								
  module.go:63001	0x630d44		47894c3a0c		MOVL R9, 0xc(R10)(R15*1)							
  module.go:36056	0x630d49		4c8b7838		MOVQ 0x38(AX), R15								
  module.go:62983	0x630d4d		498d5a0b		LEAQ 0xb(R10), BX								
  module.go:62983	0x630d51		4939df			CMPQ R15, BX									
  module.go:62983	0x630d54		767c			JBE 0x630dd2									
  module.go:36056	0x630d56		4c8b7830		MOVQ 0x30(AX), R15								
  module.go:62984	0x630d5a		438b5c3a08		MOVL 0x8(R10)(R15*1), BX							
  module.go:36058	0x630d5f		448d5bff		LEAL -0x1(BX), R11								
  module.go:36059	0x630d63		418d5c1d00		LEAL 0(R13)(BX*1), BX								
  module.go:36059	0x630d68		8d5bff			LEAL -0x1(BX), BX								
  module.go:62983	0x630d6b		498d5207		LEAQ 0x7(R10), DX								
  module.go:36065	0x630d6f		90			NOPL										
  module.go:36061	0x630d70		4439db			CMPL BX, R11									
  module.go:36062	0x630d73		440f42db		CMOVB BX, R11									
  module.go:63001	0x630d77		47895c3a08		MOVL R11, 0x8(R10)(R15*1)							
  module.go:36066	0x630d7c		4c8b7838		MOVQ 0x38(AX), R15								
  module.go:62983	0x630d80		4939d7			CMPQ R15, DX									
  module.go:62983	0x630d83		7648			JBE 0x630dcd									
  module.go:36066	0x630d85		488b5030		MOVQ 0x30(AX), DX								
  module.go:62984	0x630d89		418b5c1204		MOVL 0x4(R10)(DX*1), BX								
  module.go:36067	0x630d8e		468d1cdb		LEAL 0(BX)(R11*8), R11								
  module.go:63026	0x630d92		4489db			MOVL R11, BX									
  module.go:63026	0x630d95		4883c307		ADDQ $0x7, BX									
  module.go:63026	0x630d99		4939df			CMPQ R15, BX									
  module.go:63026	0x630d9c		762a			JBE 0x630dc8									
  module.go:63027	0x630d9e		4589db			MOVL R11, R11									
  module.go:63027	0x630da1		4ac7041a00000000	MOVQ $0x0, 0(DX)(R11*1)								
  module.go:36069	0x630da9		83ff01			CMPL DI, $0x1									
  module.go:36069	0x630dac		0f85f8feffff		JNE 0x630caa									
  module.go:35702	0x630db2		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x630db6		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:63001	0x630dbd		4489c7			MOVL R8, DI									
  module.go:63001	0x630dc0		4589cf			MOVL R9, R15									
  module.go:36069	0x630dc3		e9bdfeffff		JMP 0x630c85									
  module.go:63026	0x630dc8		e8f3fbe5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630dcd		e8eefbe5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630dd2		e8e9fbe5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630dd7		e8e4fbe5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630ddc		0f1f4000		NOPL 0(AX)									
  module.go:62983	0x630de0		e8dbfbe5ff		CALL runtime.panicBounds(SB)							
  module.go:63113	0x630de5		e8d6fbe5ff		CALL runtime.panicBounds(SB)							
  module.go:63113	0x630dea		e8d1fbe5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630def		e8ccfbe5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630df4		e8c7fbe5ff		CALL runtime.panicBounds(SB)							
  module.go:63113	0x630df9		e8c2fbe5ff		CALL runtime.panicBounds(SB)							
  module.go:63113	0x630dfe		6690			NOPW										
  module.go:63113	0x630e00		e8bbfbe5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630e05		e8b6fbe5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630e0a		e8b1fbe5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630e0f		e8acfbe5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630e14		e8a7fbe5ff		CALL runtime.panicBounds(SB)							
  module.go:35988	0x630e19		bb508e1000		MOVL $0x108e50, BX								
  module.go:35988	0x630e1e		b911000000		MOVL $0x11, CX									
  module.go:35988	0x630e23		bfe88e1000		MOVL $0x108ee8, DI								
  module.go:35988	0x630e28		e873ebfaff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn69(SB)	
  module.go:35989	0x630e2d		488d05ec9b2100		LEAQ 0x219bec(IP), AX								
  module.go:35989	0x630e34		488d1db5142d00		LEAQ 0x2d14b5(IP), BX								
  module.go:35989	0x630e3b		0f1f440000		NOPL 0(AX)(AX*1)								
  module.go:35989	0x630e40		e89b79e5ff		CALL runtime.gopanic(SB)							
  module.go:62983	0x630e45		e876fbe5ff		CALL runtime.panicBounds(SB)							
  module.go:36143	0x630e4a		4539d8			CMPL R8, R11									
  module.go:36143	0x630e4d		7603			JBE 0x630e52									
  module.go:36143	0x630e4f		4531c0			XORL R8, R8									
  module.go:36146	0x630e52		4529c3			SUBL R8, R11									
  module.go:36146	0x630e55		478d04dc		LEAL 0(R12)(R11*8), R8								
  module.go:36147	0x630e59		4c8b5838		MOVQ 0x38(AX), R11								
  module.go:63009	0x630e5d		4589c4			MOVL R8, R12									
  module.go:63009	0x630e60		4983c407		ADDQ $0x7, R12									
  module.go:63009	0x630e64		4d39e3			CMPQ R11, R12									
  module.go:63009	0x630e67		0f86f8010000		JBE 0x631065									
  module.go:36147	0x630e6d		4c8b5830		MOVQ 0x30(AX), R11								
  module.go:36148	0x630e71		4c8b6838		MOVQ 0x38(AX), R13								
  module.go:63010	0x630e75		4589c0			MOVL R8, R8									
  module.go:63010	0x630e78		4f8b1c18		MOVQ 0(R8)(R11*1), R11								
  module.go:36147	0x630e7c		66490f6ecb		MOVQ R11, X1									
  module.go:36148	0x630e81		f20f58c1		ADDSD X1, X0									
  module.go:63026	0x630e85		4d39e5			CMPQ R13, R12									
  module.go:63026	0x630e88		0f86d0010000		JBE 0x63105e									
  module.go:36148	0x630e8e		4c8b5830		MOVQ 0x30(AX), R11								
  module.go:63027	0x630e92		f2430f110403		MOVSD_XMM X0, 0(R11)(R8*1)							
  module.go:36153	0x630e98		4c8b4038		MOVQ 0x38(AX), R8								
  module.go:36152	0x630e9c		468d1c0f		LEAL 0(DI)(R9*1), R11								
  module.go:36152	0x630ea0		458d0c39		LEAL 0(R9)(DI*1), R9								
  module.go:36152	0x630ea4		458d4901		LEAL 0x1(R9), R9								
  module.go:63000	0x630ea8		4939f0			CMPQ R8, SI									
  module.go:63000	0x630eab		0f86a8010000		JBE 0x631059									
  module.go:36153	0x630eb1		488b7030		MOVQ 0x30(AX), SI								
  module.go:63001	0x630eb5		45894c3210		MOVL R9, 0x10(R10)(SI*1)							
  module.go:36154	0x630eba		4429da			SUBL R11, DX									
  module.go:36154	0x630ebd		448d4aff		LEAL -0x1(DX), R9								
  module.go:63000	0x630ec1		4c8b642470		MOVQ 0x70(SP), R12								
  module.go:36157	0x630ec6		4489ca			MOVL R9, DX									
  module.go:36157	0x630ec9		4529f9			SUBL R15, R9									
  module.go:36157	0x630ecc		4181f9feffff7f		CMPL R9, $0x7ffffffe								
  module.go:36157	0x630ed3		7733			JA 0x630f08									
  module.go:36161	0x630ed5		488b7038		MOVQ 0x38(AX), SI								
  module.go:62983	0x630ed9		4d8d4203		LEAQ 0x3(R10), R8								
  module.go:62983	0x630edd		0f1f00			NOPL 0(AX)									
  module.go:62983	0x630ee0		4c39c6			CMPQ SI, R8									
  module.go:62983	0x630ee3		0f866b010000		JBE 0x631054									
  module.go:62983	0x630ee9		4c89442468		MOVQ R8, 0x68(SP)								
  module.go:36154	0x630eee		8954244c		MOVL DX, 0x4c(SP)								
  module.go:36161	0x630ef2		488b7030		MOVQ 0x30(AX), SI								
  module.go:62984	0x630ef6		4189c9			MOVL CX, R9									
  module.go:62984	0x630ef9		4c894c2460		MOVQ R9, 0x60(SP)								
  module.go:36160	0x630efe		458d5fff		LEAL -0x1(R15), R11								
  module.go:62984	0x630f02		418b3431		MOVL 0(R9)(SI*1), SI								
  module.go:36163	0x630f06		eb26			JMP 0x630f2e									
  module.go:63000	0x630f08		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:36076	0x630f0f		4189d1			MOVL DX, R9									
  module.go:36195	0x630f12		4589f8			MOVL R15, R8									
  module.go:35702	0x630f15		8b542434		MOVL 0x34(SP), DX								
  module.go:36158	0x630f19		e971fcffff		JMP 0x630b8f									
  module.go:62983	0x630f1e		4c8b442468		MOVQ 0x68(SP), R8								
  module.go:36191	0x630f23		4589ef			MOVL R13, R15									
  module.go:36191	0x630f26		4589cb			MOVL R9, R11									
  module.go:62984	0x630f29		4c8b4c2460		MOVQ 0x60(SP), R9								
  module.go:36167	0x630f2e		4439fe			CMPL SI, R15									
  module.go:36167	0x630f31		7570			JNE 0x630fa3									
  module.go:36191	0x630f33		44895c242c		MOVL R11, 0x2c(SP)								
  module.go:36168	0x630f38		89cb			MOVL CX, BX									
  module.go:36168	0x630f3a		e84139fbff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn88(SB)	
  module.go:36169	0x630f3f		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:36169	0x630f47		488b4838		MOVQ 0x38(AX), CX								
  module.go:62983	0x630f4b		488b542468		MOVQ 0x68(SP), DX								
  module.go:62983	0x630f50		4839d1			CMPQ CX, DX									
  module.go:62983	0x630f53		0f86f6000000		JBE 0x63104f									
  module.go:36169	0x630f59		488b7030		MOVQ 0x30(AX), SI								
  module.go:62984	0x630f5d		4c8b442460		MOVQ 0x60(SP), R8								
  module.go:62984	0x630f62		458b0c30		MOVL 0(R8)(SI*1), R9								
  module.go:62983	0x630f66		4c8b542470		MOVQ 0x70(SP), R10								
  module.go:62983	0x630f6b		4c39d1			CMPQ CX, R10									
  module.go:62983	0x630f6e		0f86d6000000		JBE 0x63104a									
  module.go:62984	0x630f74		4c8b5c2478		MOVQ 0x78(SP), R11								
  module.go:62984	0x630f79		458b7c330c		MOVL 0xc(R11)(SI*1), R15							
  module.go:36168	0x630f7e		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:36190	0x630f85		8b54244c		MOVL 0x4c(SP), DX								
  module.go:62983	0x630f89		4c8b442468		MOVQ 0x68(SP), R8								
  module.go:63001	0x630f8e		4d89da			MOVQ R11, R10									
  module.go:36189	0x630f91		448b5c242c		MOVL 0x2c(SP), R11								
  module.go:63000	0x630f96		4c8b642470		MOVQ 0x70(SP), R12								
  module.go:36171	0x630f9b		4489ce			MOVL R9, SI									
  module.go:62984	0x630f9e		4c8b4c2460		MOVQ 0x60(SP), R9								
  module.go:36178	0x630fa3		4c8b6838		MOVQ 0x38(AX), R13								
  module.go:63000	0x630fa7		4d39e5			CMPQ R13, R12									
  module.go:63000	0x630faa		0f8695000000		JBE 0x631045									
  module.go:36177	0x630fb0		458d6f01		LEAL 0x1(R15), R13								
  module.go:36178	0x630fb4		488b5830		MOVQ 0x30(AX), BX								
  module.go:63001	0x630fb8		45896c1a0c		MOVL R13, 0xc(R10)(BX*1)							
  module.go:36179	0x630fbd		488b5838		MOVQ 0x38(AX), BX								
  module.go:62983	0x630fc1		498d7a07		LEAQ 0x7(R10), DI								
  module.go:62983	0x630fc5		4839fb			CMPQ BX, DI									
  module.go:62983	0x630fc8		7673			JBE 0x63103d									
  module.go:36179	0x630fca		488b7830		MOVQ 0x30(AX), DI								
  module.go:62983	0x630fce		4d8d4a0b		LEAQ 0xb(R10), R9								
  module.go:36180	0x630fd2		90			NOPL										
  module.go:62984	0x630fd3		458b443a04		MOVL 0x4(R10)(DI*1), R8								
  module.go:62983	0x630fd8		4c39cb			CMPQ BX, R9									
  module.go:62983	0x630fdb		765b			JBE 0x631038									
  module.go:62984	0x630fdd		458b4c3a08		MOVL 0x8(R10)(DI*1), R9								
  module.go:36181	0x630fe2		4501f9			ADDL R15, R9									
  module.go:36184	0x630fe5		4439ce			CMPL SI, R9									
  module.go:36185	0x630fe8		41bf00000000		MOVL $0x0, R15									
  module.go:36185	0x630fee		440f46fe		CMOVBE SI, R15									
  module.go:36187	0x630ff2		4529f9			SUBL R15, R9									
  module.go:36187	0x630ff5		478d04c8		LEAL 0(R8)(R9*8), R8								
  module.go:63026	0x630ff9		4589c1			MOVL R8, R9									
  module.go:63026	0x630ffc		4983c107		ADDQ $0x7, R9									
  module.go:63026	0x631000		4c39cb			CMPQ BX, R9									
  module.go:36184	0x631003		762e			JBE 0x631033									
  module.go:36189	0x631005		458d4b01		LEAL 0x1(R11), R9								
  module.go:63027	0x631009		4589c0			MOVL R8, R8									
  module.go:63027	0x63100c		4ac7040700000000	MOVQ $0x0, 0(DI)(R8*1)								
  module.go:36190	0x631014		4439ca			CMPL DX, R9									
  module.go:36190	0x631017		0f8501ffffff		JNE 0x630f1e									
  module.go:63000	0x63101d		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:36076	0x631024		4189d1			MOVL DX, R9									
  module.go:36195	0x631027		4589e8			MOVL R13, R8									
  module.go:35702	0x63102a		8b542434		MOVL 0x34(SP), DX								
  module.go:36190	0x63102e		e95cfbffff		JMP 0x630b8f									
  module.go:63026	0x631033		e888f9e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x631038		e883f9e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x63103d		0f1f00			NOPL 0(AX)									
  module.go:62983	0x631040		e87bf9e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x631045		e876f9e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x63104a		e871f9e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x63104f		e86cf9e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x631054		e867f9e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x631059		e862f9e5ff		CALL runtime.panicBounds(SB)							
  module.go:63026	0x63105e		6690			NOPW										
  module.go:63026	0x631060		e85bf9e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x631065		e856f9e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x63106a		e851f9e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x63106f		e84cf9e5ff		CALL runtime.panicBounds(SB)							
  module.go:35950	0x631074		4183c0fe		ADDL $-0x2, R8									
  module.go:35952	0x631078		44897c2428		MOVL R15, 0x28(SP)								
  module.go:35952	0x63107d		448b7c2440		MOVL 0x40(SP), R15								
  module.go:35898	0x631082		4585ff			TESTL R15, R15									
  module.go:35898	0x631085		750b			JNE 0x631092									
  module.go:35898	0x631087		4531ff			XORL R15, R15									
  module.go:35898	0x63108a		0f57c9			XORPS X1, X1									
  module.go:35902	0x63108d		e996000000		JMP 0x631128									
  module.go:35906	0x631092		488b5838		MOVQ 0x38(AX), BX								
  module.go:63000	0x631096		4c39e3			CMPQ BX, R12									
  module.go:63000	0x631099		0f867a030000		JBE 0x631419									
  module.go:35905	0x63109f		41ffcf			DECL R15									
  module.go:35906	0x6310a2		488b5830		MOVQ 0x30(AX), BX								
  module.go:63001	0x6310a6		45897c1a0c		MOVL R15, 0xc(R10)(BX*1)							
  module.go:35908	0x6310ab		8d5901			LEAL 0x1(CX), BX								
  module.go:35911	0x6310ae		4139dd			CMPL R13, BX									
  module.go:35911	0x6310b1		7705			JA 0x6310b8									
  module.go:63184	0x6310b3		4489eb			MOVL R13, BX									
  module.go:35912	0x6310b6		eb06			JMP 0x6310be									
  module.go:35938	0x6310b8		4489eb			MOVL R13, BX									
  module.go:35938	0x6310bb		4531ed			XORL R13, R13									
  module.go:35952	0x6310be		894c2430		MOVL CX, 0x30(SP)								
  module.go:35915	0x6310c2		488b5038		MOVQ 0x38(AX), DX								
  module.go:35914	0x6310c6		4429e9			SUBL R13, CX									
  module.go:63000	0x6310c9		4839f2			CMPQ DX, SI									
  module.go:63000	0x6310cc		0f8642030000		JBE 0x631414									
  module.go:35914	0x6310d2		8d5101			LEAL 0x1(CX), DX								
  module.go:35915	0x6310d5		4c8b6830		MOVQ 0x30(AX), R13								
  module.go:63001	0x6310d9		4389542a08		MOVL DX, 0x8(R10)(R13*1)							
  module.go:35916	0x6310de		4c8b6838		MOVQ 0x38(AX), R13								
  module.go:35877	0x6310e2		4489d9			MOVL R11, CX									
  module.go:35916	0x6310e5		448b5c2430		MOVL 0x30(SP), R11								
  module.go:35916	0x6310ea		478d1cd9		LEAL 0(R9)(R11*8), R11								
  module.go:63009	0x6310ee		4489df			MOVL R11, DI									
  module.go:63009	0x6310f1		4883c707		ADDQ $0x7, DI									
  module.go:63009	0x6310f5		4939fd			CMPQ R13, DI									
  module.go:63009	0x6310f8		0f8611030000		JBE 0x63140f									
  module.go:35916	0x6310fe		4c8b6830		MOVQ 0x30(AX), R13								
  module.go:63010	0x631102		4589db			MOVL R11, R11									
  module.go:63010	0x631105		4f8b1c2b		MOVQ 0(R11)(R13*1), R11								
  unsafe.go:41		0x631109		66490f6ecb		MOVQ R11, X1									
  module.go:36122	0x63110e		8b7c2448		MOVL 0x48(SP), DI								
  module.go:36085	0x631112		4189cb			MOVL CX, R11									
  module.go:35938	0x631115		4189dd			MOVL BX, R13									
  module.go:35916	0x631118		89d1			MOVL DX, CX									
  module.go:35916	0x63111a		44897c2428		MOVL R15, 0x28(SP)								
  module.go:36154	0x63111f		8b542424		MOVL 0x24(SP), DX								
  module.go:63184	0x631123		488b5c2460		MOVQ 0x60(SP), BX								
  module.go:35922	0x631128		f20f58c8		ADDSD X0, X1									
  module.go:35925	0x63112c		4585ff			TESTL R15, R15									
  module.go:35925	0x63112f		751a			JNE 0x63114b									
  module.go:35925	0x631131		0f57c0			XORPS X0, X0									
  module.go:35943	0x631134		448b7c2428		MOVL 0x28(SP), R15								
  module.go:35943	0x631139		4531ff			XORL R15, R15									
  module.go:35943	0x63113c		44897c2440		MOVL R15, 0x40(SP)								
  module.go:35943	0x631141		448b7c2428		MOVL 0x28(SP), R15								
  module.go:35929	0x631146		e996000000		JMP 0x6311e1									
  module.go:35933	0x63114b		488b5838		MOVQ 0x38(AX), BX								
  module.go:63000	0x63114f		4c39e3			CMPQ BX, R12									
  module.go:63000	0x631152		0f86b2020000		JBE 0x63140a									
  module.go:35932	0x631158		41ffcf			DECL R15									
  module.go:35933	0x63115b		488b5830		MOVQ 0x30(AX), BX								
  module.go:63001	0x63115f		45897c1a0c		MOVL R15, 0xc(R10)(BX*1)							
  module.go:35935	0x631164		8d5901			LEAL 0x1(CX), BX								
  module.go:35938	0x631167		4139dd			CMPL R13, BX									
  module.go:35938	0x63116a		7705			JA 0x631171									
  module.go:63184	0x63116c		4489eb			MOVL R13, BX									
  module.go:35939	0x63116f		eb06			JMP 0x631177									
  module.go:35911	0x631171		4489eb			MOVL R13, BX									
  module.go:35911	0x631174		4531ed			XORL R13, R13									
  module.go:35916	0x631177		894c2444		MOVL CX, 0x44(SP)								
  module.go:35942	0x63117b		488b5038		MOVQ 0x38(AX), DX								
  module.go:35941	0x63117f		4429e9			SUBL R13, CX									
  module.go:63000	0x631182		4839f2			CMPQ DX, SI									
  module.go:63000	0x631185		0f867a020000		JBE 0x631405									
  module.go:35941	0x63118b		8d5101			LEAL 0x1(CX), DX								
  module.go:35942	0x63118e		4c8b6830		MOVQ 0x30(AX), R13								
  module.go:63001	0x631192		4389542a08		MOVL DX, 0x8(R10)(R13*1)							
  module.go:35943	0x631197		4c8b6838		MOVQ 0x38(AX), R13								
  module.go:35877	0x63119b		4489d9			MOVL R11, CX									
  module.go:35943	0x63119e		448b5c2444		MOVL 0x44(SP), R11								
  module.go:35943	0x6311a3		478d1cd9		LEAL 0(R9)(R11*8), R11								
  module.go:63009	0x6311a7		4489df			MOVL R11, DI									
  module.go:63009	0x6311aa		4883c707		ADDQ $0x7, DI									
  module.go:63009	0x6311ae		4939fd			CMPQ R13, DI									
  module.go:63009	0x6311b1		0f8647020000		JBE 0x6313fe									
  module.go:35943	0x6311b7		4c8b6830		MOVQ 0x30(AX), R13								
  module.go:63010	0x6311bb		4589db			MOVL R11, R11									
  module.go:63010	0x6311be		4f8b1c2b		MOVQ 0(R11)(R13*1), R11								
  unsafe.go:41		0x6311c2		66490f6ec3		MOVQ R11, X0									
  module.go:36122	0x6311c7		8b7c2448		MOVL 0x48(SP), DI								
  module.go:36085	0x6311cb		4189cb			MOVL CX, R11									
  module.go:35911	0x6311ce		4189dd			MOVL BX, R13									
  module.go:35943	0x6311d1		89d1			MOVL DX, CX									
  module.go:35943	0x6311d3		44897c2440		MOVL R15, 0x40(SP)								
  module.go:36154	0x6311d8		8b542424		MOVL 0x24(SP), DX								
  module.go:63184	0x6311dc		488b5c2460		MOVQ 0x60(SP), BX								
  module.go:35949	0x6311e1		f20f58c1		ADDSD X1, X0									
  module.go:35951	0x6311e5		4183f802		CMPL R8, $0x2									
  module.go:35951	0x6311e9		0f8585feffff		JNE 0x631074									
  module.go:36085	0x6311ef		410fbae300		BTL $0x0, R11									
  module.go:36085	0x6311f4		7208			JB 0x6311fe									
  module.go:36086	0x6311f6		4589f8			MOVL R15, R8									
  module.go:36086	0x6311f9		e9a2000000		JMP 0x6312a0									
  module.go:36088	0x6311fe		4589f8			MOVL R15, R8									
  module.go:36088	0x631201		448b7c2440		MOVL 0x40(SP), R15								
  module.go:36089	0x631206		4585ff			TESTL R15, R15									
  module.go:36089	0x631209		0f848a000000		JE 0x631299									
  module.go:36092	0x63120f		4c8b4038		MOVQ 0x38(AX), R8								
  module.go:63000	0x631213		4d39e0			CMPQ R8, R12									
  module.go:63000	0x631216		0f86dd010000		JBE 0x6313f9									
  module.go:36091	0x63121c		458d47ff		LEAL -0x1(R15), R8								
  module.go:36092	0x631220		4c8b5830		MOVQ 0x30(AX), R11								
  module.go:63001	0x631224		4789441a0c		MOVL R8, 0xc(R10)(R11*1)							
  module.go:36094	0x631229		448d5901		LEAL 0x1(CX), R11								
  module.go:36097	0x63122d		4539dd			CMPL R13, R11									
  module.go:36097	0x631230		7705			JA 0x631237									
  module.go:63184	0x631232		4589eb			MOVL R13, R11									
  module.go:36098	0x631235		eb06			JMP 0x63123d									
  module.go:36112	0x631237		4589eb			MOVL R13, R11									
  module.go:36112	0x63123a		4531ed			XORL R13, R13									
  module.go:36088	0x63123d		894c243c		MOVL CX, 0x3c(SP)								
  module.go:36101	0x631241		4c8b7838		MOVQ 0x38(AX), R15								
  module.go:36100	0x631245		4429e9			SUBL R13, CX									
  module.go:63000	0x631248		4939f7			CMPQ R15, SI									
  module.go:63000	0x63124b		0f86a3010000		JBE 0x6313f4									
  module.go:36100	0x631251		448d6901		LEAL 0x1(CX), R13								
  module.go:36101	0x631255		4c8b7830		MOVQ 0x30(AX), R15								
  module.go:63001	0x631259		47896c3a08		MOVL R13, 0x8(R10)(R15*1)							
  module.go:36102	0x63125e		4c8b7838		MOVQ 0x38(AX), R15								
  module.go:35833	0x631262		89d1			MOVL DX, CX									
  module.go:36102	0x631264		8b54243c		MOVL 0x3c(SP), DX								
  module.go:36102	0x631268		418d14d1		LEAL 0(R9)(DX*8), DX								
  module.go:63009	0x63126c		89d3			MOVL DX, BX									
  module.go:63009	0x63126e		4883c307		ADDQ $0x7, BX									
  module.go:63009	0x631272		4939df			CMPQ R15, BX									
  module.go:63009	0x631275		0f8674010000		JBE 0x6313ef									
  module.go:36102	0x63127b		4c8b7830		MOVQ 0x30(AX), R15								
  module.go:63010	0x63127f		89d2			MOVL DX, DX									
  module.go:63010	0x631281		4a8b143a		MOVQ 0(DX)(R15*1), DX								
  unsafe.go:41		0x631285		66480f6eca		MOVQ DX, X1									
  module.go:36154	0x63128a		89ca			MOVL CX, DX									
  module.go:63184	0x63128c		488b5c2460		MOVQ 0x60(SP), BX								
  module.go:36102	0x631291		4489e9			MOVL R13, CX									
  module.go:36112	0x631294		4589dd			MOVL R11, R13									
  module.go:36104	0x631297		eb03			JMP 0x63129c									
  module.go:36104	0x631299		0f57c9			XORPS X1, X1									
  module.go:36106	0x63129c		f20f58c1		ADDSD X1, X0									
  module.go:36108	0x6312a0		4585c0			TESTL R8, R8									
  module.go:36108	0x6312a3		7422			JE 0x6312c7									
  module.go:63000	0x6312a5		488b742468		MOVQ 0x68(SP), SI								
  module.go:36109	0x6312aa		4189cb			MOVL CX, R11									
  module.go:36109	0x6312ad		4589c7			MOVL R8, R15									
  module.go:36109	0x6312b0		4589cc			MOVL R9, R12									
  module.go:62984	0x6312b3		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:36152	0x6312ba		448b4c244c		MOVL 0x4c(SP), R9								
  module.go:36109	0x6312bf		4589e8			MOVL R13, R8									
  module.go:36109	0x6312c2		e983fbffff		JMP 0x630e4a									
  module.go:36112	0x6312c7		4585ed			TESTL R13, R13									
  module.go:36112	0x6312ca		740b			JE 0x6312d7									
  module.go:36112	0x6312cc		41bb01000000		MOVL $0x1, R11									
  module.go:36112	0x6312d2		e987000000		JMP 0x63135e									
  module.go:62983	0x6312d7		4889742458		MOVQ SI, 0x58(SP)								
  module.go:36086	0x6312dc		f20f11442450		MOVSD_XMM X0, 0x50(SP)								
  module.go:36113	0x6312e2		8b9c249c000000		MOVL 0x9c(SP), BX								
  module.go:36113	0x6312e9		e89235fbff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn88(SB)	
  module.go:36114	0x6312ee		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:36114	0x6312f6		488b4838		MOVQ 0x38(AX), CX								
  module.go:62983	0x6312fa		488b542470		MOVQ 0x70(SP), DX								
  module.go:62983	0x6312ff		90			NOPL										
  module.go:62983	0x631300		4839d1			CMPQ CX, DX									
  module.go:62983	0x631303		0f86e1000000		JBE 0x6313ea									
  module.go:36114	0x631309		488b7030		MOVQ 0x30(AX), SI								
  module.go:36116	0x63130d		90			NOPL										
  module.go:62984	0x63130e		4c8b442478		MOVQ 0x78(SP), R8								
  module.go:62984	0x631313		458b4c300c		MOVL 0xc(R8)(SI*1), R9								
  module.go:62983	0x631318		4c8b542468		MOVQ 0x68(SP), R10								
  module.go:62983	0x63131d		0f1f00			NOPL 0(AX)									
  module.go:62983	0x631320		4c39d1			CMPQ CX, R10									
  module.go:62983	0x631323		0f86bc000000		JBE 0x6313e5									
  module.go:36115	0x631329		458d5901		LEAL 0x1(R9), R11								
  module.go:36118	0x63132d		90			NOPL										
  module.go:36120	0x63132e		90			NOPL										
  module.go:62984	0x63132f		418b7c3010		MOVL 0x10(R8)(SI*1), DI								
  module.go:63184	0x631334		458b4c3004		MOVL 0x4(R8)(SI*1), R9								
  module.go:63184	0x631339		4c8b642460		MOVQ 0x60(SP), R12								
  module.go:63184	0x63133e		458b2c34		MOVL 0(R12)(SI*1), R13								
  module.go:63184	0x631342		418b4c3008		MOVL 0x8(R8)(SI*1), CX								
  module.go:36154	0x631347		8b542424		MOVL 0x24(SP), DX								
  module.go:63000	0x63134b		488b742458		MOVQ 0x58(SP), SI								
  module.go:63001	0x631350		4d89c2			MOVQ R8, R10									
  module.go:63000	0x631353		4c8b642470		MOVQ 0x70(SP), R12								
  module.go:63027	0x631358		f20f10442450		MOVSD_XMM 0x50(SP), X0								
  module.go:36125	0x63135e		4c8b4038		MOVQ 0x38(AX), R8								
  module.go:63000	0x631362		4d39e0			CMPQ R8, R12									
  module.go:63000	0x631365		7674			JBE 0x6313db									
  module.go:36125	0x631367		4c8b4030		MOVQ 0x30(AX), R8								
  module.go:63001	0x63136b		47895c020c		MOVL R11, 0xc(R10)(R8*1)							
  module.go:36128	0x631370		448d41ff		LEAL -0x1(CX), R8								
  module.go:36129	0x631374		458d7c0d00		LEAL 0(R13)(CX*1), R15								
  module.go:36129	0x631379		458d7fff		LEAL -0x1(R15), R15								
  module.go:36135	0x63137d		488b4838		MOVQ 0x38(AX), CX								
  module.go:36131	0x631381		4539fd			CMPL R13, R15									
  module.go:36132	0x631384		450f47c7		CMOVA R15, R8									
  module.go:63000	0x631388		4839f1			CMPQ CX, SI									
  module.go:36131	0x63138b		7649			JBE 0x6313d6									
  module.go:36135	0x63138d		488b7030		MOVQ 0x30(AX), SI								
  module.go:63001	0x631391		4589443208		MOVL R8, 0x8(R10)(SI*1)								
  module.go:36136	0x631396		488b7038		MOVQ 0x38(AX), SI								
  module.go:36136	0x63139a		478d04c1		LEAL 0(R9)(R8*8), R8								
  module.go:63026	0x63139e		4589c1			MOVL R8, R9									
  module.go:63026	0x6313a1		4983c107		ADDQ $0x7, R9									
  module.go:63026	0x6313a5		4c39ce			CMPQ SI, R9									
  module.go:63026	0x6313a8		7627			JBE 0x6313d1									
  module.go:36136	0x6313aa		4c8b6830		MOVQ 0x30(AX), R13								
  module.go:63027	0x6313ae		4589c0			MOVL R8, R8									
  module.go:63027	0x6313b1		f2430f11440500		MOVSD_XMM X0, 0(R13)(R8*1)							
  module.go:62984	0x6313b8		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:63000	0x6313bf		488b742468		MOVQ 0x68(SP), SI								
  module.go:36152	0x6313c4		448b4c244c		MOVL 0x4c(SP), R9								
  module.go:36137	0x6313c9		4589df			MOVL R11, R15									
  module.go:36137	0x6313cc		e9c7faffff		JMP 0x630e98									
  module.go:63026	0x6313d1		e8eaf5e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x6313d6		e8e5f5e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x6313db		0f1f440000		NOPL 0(AX)(AX*1)								
  module.go:63000	0x6313e0		e8dbf5e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x6313e5		e8d6f5e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x6313ea		e8d1f5e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x6313ef		e8ccf5e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x6313f4		e8c7f5e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x6313f9		e8c2f5e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x6313fe		6690			NOPW										
  module.go:63009	0x631400		e8bbf5e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x631405		e8b6f5e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x63140a		e8b1f5e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x63140f		e8acf5e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x631414		e8a7f5e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x631419		e8a2f5e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x63141e		6690			NOPW										
  module.go:62983	0x631420		e89bf5e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x631425		e896f5e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x63142a		e891f5e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x63142f		e88cf5e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x631434		e887f5e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x631439		e882f5e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x63143e		6690			NOPW										
  module.go:63009	0x631440		e87bf5e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x631445		90			NOPL										
  module.go:35694	0x631446		4889442408		MOVQ AX, 0x8(SP)								
  module.go:35694	0x63144b		895c2410		MOVL BX, 0x10(SP)								
  module.go:35694	0x63144f		894c2414		MOVL CX, 0x14(SP)								
  module.go:35694	0x631453		f20f11442418		MOVSD_XMM X0, 0x18(SP)								
  module.go:35694	0x631459		e842d8e5ff		CALL runtime.morestack_noctxt.abi0(SB)						
  module.go:35694	0x63145e		488b442408		MOVQ 0x8(SP), AX								
  module.go:35694	0x631463		8b5c2410		MOVL 0x10(SP), BX								
  module.go:35694	0x631467		8b4c2414		MOVL 0x14(SP), CX								
  module.go:35694	0x63146b		f20f10442418		MOVSD_XMM 0x18(SP), X0								
  module.go:35694	0x631471		e9aaeaffff		JMP dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn176(SB)	
