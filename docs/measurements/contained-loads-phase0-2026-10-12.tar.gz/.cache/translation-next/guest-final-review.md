# Guest phase-0 final review

Verdict: GO to consideration of a separately specified and qualified production
experiment. This is not approval to retain the diagnostic as production, nor
acceptance of scalar latency or M1 performance. No production edits, builds,
tests, profiles or new measurements were performed in this review.

## Measured opportunity

Reviewed warm-run/summary.json and all screen/confirm time-benchstat rows.
Baseline → probe medians and exploratory p-values:

| Workload | Screen ns/op | Screen delta / p | Confirm ns/op | Confirm delta / p |
|---|---:|---:|---:|---:|
| Original SQL | 2205 → 2116 | -4.04%, .001 | 2197 → 2116 | -3.69%, .001 |
| Varied SQL | 2812 → 2675 | -4.87%, .001 | 2800 → 2655 | -5.18%, .001 |
| SQL holdout | 5671 → 5446 | -3.97%, .001 | 5665 → 5471 | -3.42%, .017 |
| Original batch1k | 38716 → 38047 | -1.73%, .001 | 38551 → 37904 | -1.68%, .001 |
| Repeated1024 | 39402 → 39116 | -0.73%, .001 | 39389 → 39066 | -0.82%, .010 |
| Broad8192 | 319311 → 313224 | -1.91%, .128 | 319300 → 312823 | -2.03%, .001 |
| Original scalar | 88.02 → 87.75 | -0.31%, 1.000 | 87.62 → 87.49 | -0.15%, .833 |
| Varied scalar | 88.39 → 87.71 | -0.77%, .165 | 88.75 → 88.24 | -0.57%, .002 |
| Negative bins | 89.28 → 88.02 | -1.41%, .005 | 88.28 → 87.65 | -0.71%, .026 |
| Increasing | 89.18 → 88.65 | -0.59%, .053 | 89.15 → 88.91 | -0.27%, .318 |
| Broad scalar | 89.42 → 89.04 | -0.42%, .128 | 89.14 → 88.81 | -0.37%, .736 |
| Raw guest scalar | 53.92 → 52.55 | -2.54%, .023 | 53.76 → 52.66 | -2.05%, .001 |
| Trace1k | 2622961 → 2614163 | -0.34%, .620 | 2600098 → 2597131 | -0.11%, 1.000 |

SQL's original, varied and holdout results repeat. Broad batch detects a gain
only in confirmation, and varied scalar only in confirmation. The ordinary
public scalar and trace have no established gain; negative-bin/raw-guest
observations must remain distinct. Nondetection is not equivalence.

The same-selection named-helper recheck control has no repeated SQL benefit.
Its confirmation trace is +1.07%, p=.011 versus baseline (screen undetected),
which must remain visible as a control negative. Current-only streaming rows
refresh ceilings but do not test a candidate streaming module and cannot
qualify future generic-pass effects on compute or streaming.

Scalar and batch allocation medians remain zero. SQL allocation counts remain
one; byte medians have minor calibration/amortization differences. Trace heap
bytes vary with calibration and no allocation-count gain is established.

## Boundaries and controls

The private diagnostic full hash pins helper bodies, numeric/import bindings
and module construction; it is not a generic proof for arbitrary input Go.
It changes only selected call targets to the copied load32 helper minus the
unsafe endpoint check. First/new-largest checks, actual reads, operands and
statement/evaluation order remain. Unknown calls, base/header mutation,
guest writes, control/label entries and unsupported addresses remain barriers.

The positive WAT/native fixture asserts exactly two intended rewritten reads,
with original-Wasm value/trap/memory/import-count comparisons, native short
logical lengths with spare capacity, replacement/shrink imports and base/control
barriers. Reviewed native386 logs pass before/probe/recheck. First-guard,
import-crossing and name-only purity mutants all fail explicit semantic tests;
compile failures are excluded by the failure checker. This supports the
bounded diagnostic, not a broader production purity/type/declaration policy.

The current fixture XOR combines values commutatively. For authored production
proofs, strengthen outputs to a weighted/noncommutative formula and explicit
goldens, so swapped/wrong read positions are less likely to pass. Add generic
binding/directive/global/name-collision and all destination-type tests beyond
the diagnostic's whole-source hash.

Matching machine code confirms fn176 guard-call sites 88→78 and instructions
1366→1309; its frame changes 144→128 bytes. SQL fn96 guard-call sites change
1501→1452 and instructions 23173→22964, with frame856 unchanged. The scalar
export remains642 instructions/57 guard-call sites/frame112, but relocates.
Recheck restores these inspected counts and frames, not a clean all-binary
causal control. Time can include register allocation, frame and placement
effects; do not describe the medians as a per-check cost or proven spill saving.

## Draft production specification

The proposed same-bound-base, zero-extended/nonwrapping range, first/newmax
ordering, logical-length containment, conservative block barriers, preserved
fallback and shared constructor/helper proof rules are sound. No new public
contract is needed. Validate all bindings/types/directives and emit nothing for
unsupported/no-selection input; never use the diagnostic's function/line/hash
or payload identity as a production predicate. Preserve old hardener drift
behavior and regenerate all three authored proofs/locks.

One clarification was sent before approval: literal 'explicit builtin scalar
types' on destinations excludes the demonstrated short-declared tNN read
temporaries. Specify whether destination type may be proved from the exact
helper and optional int32 wrapper, or deliberately exclude those sites and
remeasure the stricter predicate. Address-base explicit i32 remains required.
The current 319-site ceiling does not automatically qualify a smaller/different
selection. Future production before/after and complete guards/gates remain
mandatory; smaller repeated standalone scalar loss cannot be waived by a 3%
general material-guard threshold.
