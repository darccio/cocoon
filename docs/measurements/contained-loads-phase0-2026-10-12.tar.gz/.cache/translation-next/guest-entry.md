# Guest entry review: contained scalar-load range checks

Read-only review from `06cf6f9` (merged tree `776b897`); no production edit,
build, test, profile or benchmark. Reviewed roadmap track 5, previous math and
header no-gos, authored Datadog shim and current translated helpers/hot paths.

One candidate for matching SSA/assembly inspection is a later scalar load's
bounds check contained in an earlier checked load on the same unchanged base.
This is a hypothesis about surviving checks, not a demonstrated opportunity.
Go may already eliminate it; reject immediately if current machine code does.

Concrete diagnostic sites in the current module:

- `fn176`, label `l7`: reads builtin i32 base `v3` at offsets 4, 8, then 0;
  only pure local arithmetic/copies separate the second and third load. The
  checked width-end 11 of the offset-8 load contains end 3 of the later load.
  These reads occur in the ordinary increment path, including repeated batches.
- SQL `fn96` initializer: `t3` reads `v6+40`, then `t4` reads `v6+32`;
  a pure local copy separates them. Its earlier end 43 contains later end 35.
- Scalar export reads its handle-result base at offset 4 then 0, but nested
  lexical blocks separate them; a first conservative single-block predicate
  should leave that case unchanged rather than require broad dominance logic.

These function names/locations select only diagnostics, never production rules.
This differs from the retained publication-tail pass: it crosses no store and
needs fresh proof before deleting a check. Do not broaden header regions using
the previous batch win. No predicted percentage or additive gain is proposed.

The smallest generic eligibility idea would track exact bound `load32` calls
in one straight-line lexical region. Require builtin i32 base identity/type,
same exact validated memory selector, unchanged base/header, and only pure
local statements between accesses. Addresses must be `uint32(base)` or widened
`uint64(uint32(base))+nonnegative u32 constant`; reject wrapping arithmetic,
arbitrary uint64 expressions, shadowed types/helpers and effectful arguments.
Use the prior successful load's checked inclusive end, not capacity, to prove
the later width-end is contained. Retain first-load position/check and every
actual read/evaluation order. No combined preflight or forward-loaded values.

All calls/imports/bulk operations, stores, receiver/header/base assignment,
labels/control joins/gotos/loops and pointer escape are barriers. Capture any
region after label entry; never infer a dominated guard on an untaken path.
No function-wide stack/privacy assumption is needed for this read-only case.
Unserialized concurrent raw-host mutation remains outside existing ownership
rules. Validated range implies uintptr/host-int representability on 386 too;
preserve endianness and unaligned fallback behavior rather than emit a generic
unchecked unsafe helper without matching the pinned helper bodies/platforms.

Required evidence before implementation: current matching profile attribution,
surviving guard in Go1.26 SSA/ASM, a hash-pinned ignored diagnostic retaining
all values/addresses/first checks, and isolated paired ceiling measurement with
ordinary scalar/SQL/batch/trace plus negative bins/broad/stream holdouts. Check
machine-code/frame/placement controls; a source simplification alone is a no-go.

If the ceiling warrants a pass, executable WAT/native proofs need every short
logical length around both checks, near-MaxUint32/widened/wrapping addresses,
unaligned reads, len<cap, exact trap prefixes, intervening header replacement,
growth/import/store barriers, aliasing, base rebinding/shadowing and label entry.
Post-rewrite mutants must remove the first guard or mistakenly cross a barrier
and fail the independent runtime oracle. Regenerate all three proofs/locks.

Keep scalar/batch validation and atomicity intact. The Rust shim validates the
whole Vec before mutation; `.add` still owns mapping/collapse/counter behavior.
The logarithm polynomial and saturation rewrite have prior negative evidence;
neither is revived by source readability or repeated-value corpus results.
