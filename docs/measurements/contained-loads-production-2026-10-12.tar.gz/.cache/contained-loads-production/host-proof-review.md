# Host executable proof review

Owned authored files: internal/smoke/contained_loads_test.go,
internal/smoke/testdata/contained-loads.wat, and
internal/smoke/testdata/contained-loads/module_test.go.txt. No production runtime,
hardener, generated module, manifest, lock or commit was edited by this agent.

Focused command (final amd64):

```
PATH=/usr/lib64/go/1.26/bin:/home/dario/.cargo/bin:/home/dario/Code/cocoon/.cache/binaryen/binaryen-version_133/bin:$PATH GOCACHE=/home/dario/Code/cocoon/.cache/go GOTOOLCHAIN=local CGO_ENABLED=0 COCOON_SMOKE=1 /usr/lib64/go/1.26/bin/go test -pgo=off ./internal/smoke -run '^TestContainedLoadSemantics$' -count=1 -v
```

Final amd64 log smoke-final.log passes in 3.695s. The same command with
GOARCH=386 initially fails with sandbox `signal: bad system call (core dumped)`
before executing the proof; smoke-native386.log preserves that procedural
negative. The authorized unsandboxed retry passes in 4.644s, recorded in
smoke-native386-unsandboxed.log. No timings or profiles were run.

Both native architectures execute original translated source, production-
hardened source, identical-call-inventory copied-check control, and a
postvalidation forced checked-unaligned-fallback control. The actual pinned
Binaryen133/wasm2go0.4.16 versions are asserted by the runner. Wasm is assembled
without O3 so compiler coalescing cannot erase the intended load32 witness.
Production helper eligibility is mandatory: exactly the offset-zero reads in
Xcovered and Xtriple must use cocoonLoad32InRange; every barrier export/native
method must remain checked. A skipped ownership proof cannot satisfy this.

Independent wazero computes 520 finite cases: ten exports, 26 bases (including
all 0–16 distances from the page end, unaligned and signed high-bit values),
and both flags/second-base choices. Complete memory, weighted results, trap
categories, observable prefix counter and ordered import events are compared.
Explicit weighted goldens independently validate the original Wasm on base0.

Native proofs add zero-length/spare-capacity cases, shrinking and replaced
headers, live changed backing bytes, first-trap/import ordering, rebind and
conditional/label barriers, global exclusion, growth with/without reallocation,
and the impure shadow wrapper. The impure wrapper is present before hardening
and invokes a declared host import; only the native host changes the header.
There is no translated direct header write or function literal invalidating
construction proof. The weighted two-base export has actual grouped translator
parameters; its len16/cap128 firstbase0/secondbase64 native history must trap.

Three postvalidation semantic mutants are rejected on both architectures:
first-check deletion by TestContainedLoadLogicalLength, import crossing by
TestContainedLoadHeaderBarrier, and name-only purity by
TestContainedLoadShadowBarrier. Their intentionally unchecked reads remain
inside allocated 64-byte backing; rejection requires a real semantic assertion
failure, not drift validation, compilation failure or a fatal bad-address read.

The root owns full pinned lint, staged validation, gates, regenerated proofs
and performance qualification. Smoke/native proof success is correctness
evidence, not a scalar speedup or M1 acceptance.
