# Guest final retention audit

Date: 2026-10-12. No compilation, test, lint, profile, or timing was run for this
audit. The verdict reviews the existing frozen production outcomes and proof
logs; it is separate from the implementation review and its source hashes in
`guest-implementation-review.md`.

## Recommendation

Retain the conservative private contained-load pass and its authored proofs.
The preregistered criterion is met by repeatable end-to-end varied SQL and SQL
holdout improvements, with no detected standalone scalar regression and no
repeated material guard regression of 3% or more. Smaller negatives remain
visible below. Nondetection is not equivalence or a regression-free claim.
No scalar speedup, pure bounds-check causal estimate, cross-architecture
performance result, or M1 performance acceptance follows from this audit.

The applied guest proof remains bounded: keep all reads/evaluation positions,
first/new-maximum logical-length guards, bound explicit i32 bases, generic
helper/type/ownership guards, per-binding invalidation, whole-method escape
screening, and effect/control barriers. Do not extend type inference or the
predicate to recover the single diagnostic-only Datadog site. Production has
318 Datadog sites, versus 319 diagnostic sites, because the inferred arithmetic
temporary in fn177 is intentionally unproved. Compute 99 and streaming 20 are
proof-module selection counts, not evidence of their workload speedups.

## Frozen qualification and proof evidence

The warm progress log records all seven screen and seven confirmation rounds
passing, 826 raw rows preserved, and frozen hashes unchanged. The frozen
snapshot records 167 SHA-256 entries and Go 1.26.8 linux/amd64. Run provenance
records CGO disabled, GOAMD64=v1, GOMAXPROCS=16, the processor affinity and CPU
policy, and the explicit limitation that the driver cannot prove absence of
external work. The machine-code provenance identifies ordinary Go 1.26.8
PGO-off binaries; inspection tools are recorded separately.

`qualification-progress.log` records check, race, rust, cross, smoke, fuzz, and
integration passing, followed by two repetitions of compute, Datadog,
streaming, and runtime generation. Each repetition preserved all 61
proof/runtime/harness files. This is six quality-gate targets plus integration,
seven commands total; cross compilation is not native execution evidence.

The final focused smoke log and the native386 unsandboxed log both show the
original, hardened, recheck, and checked-fallback cases passing. The executable
oracle rejects first-check deletion, import crossing, and name-only purity
mutants with their intended logical-length/header/shadow tests. These tests
provide semantic evidence beyond the AST-selection assertions. The parent
reports the full native386 consumers also passing. No native arm64 execution
or performance is claimed.

## Paired measured outcomes

Values below are exact summary medians in nanoseconds. P-values come from the
matching time-benchstat outputs; seven samples per set, exploratory and
unadjusted. `probe` is the committed generic production candidate, not the
earlier diagnostic. Screen uses 500 ms samples; reversed confirmation uses
one-second samples.

| Workload | Screen baseline → candidate | Screen delta / p | Confirmation baseline → candidate | Confirmation delta / p |
| --- | ---: | --- | ---: | --- |
| Original SQL | 2216 → 2136 | −3.61%, .001 | 2217 → 2134 | −3.74%, .073 |
| Varied SQL | 2857 → 2664 | −6.76%, .001 | 2827 → 2698 | −4.56%, .001 |
| SQL holdout | 5670 → 5447 | −3.93%, .011 | 5691 → 5465 | −3.97%, .001 |
| Original batch | 38775 → 38201 | −1.48%, .026 | 38809 → 38287 | −1.35%, .038 |
| Matched repeated 1024 batch | 39466 → 39074 | −0.99%, .015 | 39484 → 39150 | −0.85%, .026 |
| Matched broad 8192 batch | 318490 → 312380 | −1.92%, .001 | 320441 → 314529 | −1.84%, .001 |
| Original scalar | 87.91 → 87.87 | −0.05%, .710 | 87.80 → 88.11 | +0.35%, .620 |
| Varied scalar | 89.00 → 88.36 | −0.72%, .383 | 88.96 → 88.91 | −0.06%, 1.000 |
| Negative-bin scalar | 88.32 → 88.51 | +0.22%, .832 | 88.54 → 88.74 | +0.23%, .535 |
| Increasing scalar | 89.35 → 89.34 | −0.01%, 1.000 | 89.69 → 89.73 | +0.04%, .620 |
| Broad scalar holdout | 88.85 → 88.70 | −0.17%, 1.000 | 89.42 → 88.73 | −0.77%, .097 |
| Raw guest scalar control | 53.67 → 53.01 | −1.23%, .017 | 53.89 → 53.22 | −1.24%, .004 |
| Original trace | 2663214 → 2554478 | −4.08%, .001 | 2683518 → 2580011 | −3.86%, .001 |

Original SQL's confirmation benefit is not detected, despite its similar
median. Varied SQL and the separate holdout establish the repeated SQL benefit.
All five standalone scalar variants show no detected gain or loss; the raw
guest control is a separate unchecked diagnostic and cannot support a public
facade latency claim. Scalar and batch report zero Go allocations in both
sets. SQL and trace report one Go allocation per operation for both production
roles; calibration-dependent B/op differences must not be described as removed
guest allocations or eliminated copies.

The recheck control redirects the same production-selected calls through a
separately named helper retaining the check. It does not reproduce a
byte-identical whole binary. Trace improves versus baseline in this control
too: −1.46% (p=.026) and −1.55% (p=.017), versus the candidate's −4.08% and
−3.86%. Placement/compiler effects therefore contribute to the observed trace
comparison; no clean causal subtraction is warranted. The matching inspected
function counts and frames are restored by recheck, which strengthens the
structural evidence without controlling every layout effect.

## Streaming guard negatives and limits

The one-home fixed stream median is higher in both sets:
188461 → 192002 ns (+1.88%, p=.165), then
189475 → 192664 ns (+1.68%, p=.053). The confirmation is near the conventional
threshold and is retained as an unresolved negative; it must not be called
equivalent or improved.

The one-home streaming holdout has a detected screen negative:
228056 → 229621 ns (+0.69%, p=.038). It does not repeat detection in
confirmation: 231835 → 232709 ns (+0.38%, p=.535). This is still a negative
result to disclose, rather than erase because it fails to repeat.

The 16-home fixed stream moves −3.62% (p=.259), then +2.19% (p=1.000).
The 16-home holdout moves −0.54% (p=.456), then −3.52% (p=.710).
None establishes a streaming benefit or regression. All streaming rows retain
the matched reported output/group/owned-byte metrics and allocation counts;
the transform neither changes the bounded window nor the resource lifecycle
contract. These synthetic controls do not establish behavior for all real
payloads or contention patterns.

## Machine-code size, frames, and maintenance

The summed native text for translated guest symbols is 831228 → 822216 bytes,
a reduction of 9012 bytes. The original Wasm guest is unchanged; this is not a
Wasm artifact size reduction. Full executable `.text` is 4307729 → 4298673,
down 9056 bytes. The unstripped test binary instead grows
14435431 → 14524743 bytes, up 89312 bytes. ELF accounting shows
`.debug_rnglists` grows 1177964 → 1277111 bytes (+99147); the larger binary is
principally debug-range metadata, not larger native executable text. This
still belongs in the size report; no stripped or shipping-size measurement
was performed.

The sketch mapping function retains 78 static bounds-panic sites versus 88,
1309 instructions versus 1366, and a 128-byte frame versus 144. SQL fn96 has
1452 sites versus 1501 and 22964 instructions versus 23173; its 856-byte frame
is unchanged. The scalar export's inspected 57 bounds sites, 642
instructions, and 112-byte frame are unchanged. These are static code counts,
not dynamic check counts or proof of fewer spills. The changed mapping frame
and code placement limit per-check attribution.

Maintenance is acceptable within the specified narrow optional pass: it
reuses the existing complete scalar/constructor ownership proof, contains no
payload exceptions, keeps fail-closed ineligibility for drift, preserves the
prior publication proof, and has authored structural and independent
executable mutant coverage. Broader numeric inference, control-flow analysis,
aliasing assumptions, or architecture-specific optimization would require a
new review and qualification. Retaining this round does not accept any such
extension.
