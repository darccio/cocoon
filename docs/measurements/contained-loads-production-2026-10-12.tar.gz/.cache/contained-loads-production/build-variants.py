from pathlib import Path
import subprocess,os,json,datetime,hashlib
root=Path.cwd();out=root/'.cache/contained-loads-production';go='/usr/lib64/go/1.26/bin/go';env=dict(os.environ,GOTOOLCHAIN='local',CGO_ENABLED='0',GOAMD64='v1',GOCACHE=str(root/'.cache/go'),GOFLAGS='-buildvcs=false');records=[]
def run(name,args):
 item={'name':name,'argv':args,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (out/(name+'.log')).open('w') as log:
  print('COMMAND',json.dumps(args),file=log,flush=True);r=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT);print('EXIT',r.returncode,file=log,flush=True)
 item.update(exit=r.returncode,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());records.append(item);(out/'variant-build-records.json').write_text(json.dumps(records,indent=2)+'\n');assert r.returncode==0,name
 print('PASS',name,flush=True)
module=root/'examples/datadog/go/dd/internal/wasm/module.go'
before=subprocess.check_output(['git','show','be8f6e0:'+str(module.relative_to(root))],cwd=root)
(out/'baseline-module.go').write_bytes(before);(out/'baseline-overlay.json').write_text(json.dumps({'Replace':{str(module):str(out/'baseline-module.go')}},indent=2)+'\n')
source=module.read_bytes();assert source.count(b'func cocoonLoad32InRange[')==1
prefix,helper=source.split(b'func cocoonLoad32InRange[',1);assert b'_ = mem[uint64(addr)+3]' not in helper
needle=b'\tval := *(*uint32)(unsafe.Add(unsafe.Pointer(unsafe.SliceData(mem)), uintptr(addr)))\n';assert helper.count(needle)==1
recheck=prefix+b'func cocoonLoad32InRange['+helper.replace(needle,b'\t_ = mem[uint64(addr)+3]\n'+needle,1)
(out/'recheck-module.go').write_bytes(recheck);(out/'recheck-overlay.json').write_text(json.dumps({'Replace':{str(module):str(out/'recheck-module.go')}},indent=2)+'\n')
for role in ('baseline','probe','recheck'):
 overlay=[] if role=='probe' else ['-overlay='+str(out/(role+'-overlay.json'))]
 run(role+'-whole-oracles',[go,'test','-pgo=off',*overlay,'./examples/datadog/go/dd/...','-count=1'])
 run(role+'-compile',[go,'test','-c','-pgo=off',*overlay,'-o',str(out/(role+'.test')),'./examples/datadog/go/dd'])
streammodule=root/'testdata/streaming/go/streaming/internal/wasm/module.go'
(out/'baseline-stream-module.go').write_bytes(subprocess.check_output(['git','show','be8f6e0:'+str(streammodule.relative_to(root))],cwd=root));(out/'baseline-stream-overlay.json').write_text(json.dumps({'Replace':{str(streammodule):str(out/'baseline-stream-module.go')}},indent=2)+'\n')
run('stream-baseline-compile',[go,'test','-c','-pgo=off','-overlay='+str(out/'baseline-stream-overlay.json'),'-o',str(out/'stream-baseline.test'),'./testdata/streaming/go/streaming'])
records.append({'binaries_sha256':{r:hashlib.sha256((out/(r+'.test')).read_bytes()).hexdigest() for r in ('baseline','probe','recheck','stream-baseline')}});(out/'variant-build-records.json').write_text(json.dumps(records,indent=2)+'\n')
print('PASS all variant oracles/builds',flush=True)
