# Applied guest implementation review

Date: 2026-10-12. Reviewer: guest-side agent. This is an ignored review note,
not a public contract or performance result.

## Verdict

No remaining guest-semantics blocker was found in the applied conservative
contained-load pass. It is ready for the parent's executable proof, final gates,
artifact reproduction, and independent performance qualification. This verdict
does not accept performance, standalone scalar latency, or M1.

The review covers the implementation and authored AST regression tests listed
below. It does not substitute static selection assertions for the separately
owned WAT/native executable oracle.

## Reviewed source hashes

SHA-256 at this review:

```text
2e444f0725524a180536cad3e9dded9f6a8d08d8fb2feed1dce040cd58cbca60  internal/harden/contained_loads.go
cb451e38bdcdcca1b8430700f5fa51aa462e9b79a8458ed21fd4d7ab3117cd4d  internal/harden/contained_loads_test.go
61559ba1882d6f375eced0091ce84af998f040facd57fb3d6a39302d30f3d3cf  internal/harden/harden.go
619bcad5985e5f7c8584d61fe3569a5f7688c1116d64b85f016bea0ba71d7037  internal/harden/memory_views_bindings.go
39935777d3bfd07d6cdbf092cf6760914543f3a2dedd62a661d13f0dc0de4d05  internal/harden/memory_views_ownership.go
```

## Generic guards and evaluation order

- Eligibility uses the actual bound Module, receiver, memory field, canonical
  scalar helper/import/architecture declarations, and independently allocated
  construction. There are no payload names, function numbers, line filters, or
  measured outcomes in the production selection predicate.
- The address base is a bound, explicitly declared builtin int32 local or
  parameter. Addresses retain the original zero extension and widened literal
  addition. The maximum endpoint fits uint64; no wrapping normalization occurs.
- Facts use `(viewDeclaration, bound name)` identity. Grouped parameters and
  variables share a declaration node but cannot share facts or invalidations.
- Each lexical block starts with empty facts. The first and each new-maximum
  endpoint guard stay at their original reads. Only a later contained read on
  the same unchanged base is redirected; the read and its operands stay present.
- A successful endpoint check uses logical slice length and proves the lower
  nonnegative byte range. It does not infer capacity, allocation disjointness,
  or a different memory header.
- The assignment RHS is processed before its destination invalidates facts.
  Grouped-binding tests cover both distinct-base rejection and independent
  sibling assignments which must preserve the original base's fact.
- Stores, calls with unproved effects, imports, growth, bulk operations,
  receiver/header writes, control flow, labels, blocks, multi-assignment,
  inc/dec, declarations, defer/go, and other unsupported statements end facts.
  There is no value forwarding, load movement, or cached header in this pass.
- Pure preserving expressions are limited to proved numeric local bindings,
  bound builtin numeric conversions, and fully validated i32/i64 identity
  declarations. Shadowing and identity-body drift are barriers. Arithmetic
  which can trap remains at its original position; a later read executes only
  after that arithmetic completes successfully.
- Base nonescape is checked for the entire method before scanning regions.
  Taking a base's address or capturing it in a function literal disqualifies
  that binding even before the first checked read. A method containing a
  GoStmt is wholly ineligible. This is a conservative proof restriction,
  not concurrency support or a new host ownership condition.
- A reserved helper identifier anywhere in the source disables only this
  optional pass. An ordinary string containing the spelling is not a collision.
- The private helper is derived from the fully validated original load32 body.
  Only its unsafe-branch endpoint line is deleted. Signature, address widths,
  nosplit directive, live unsafe read, endian handling, and checked unaligned
  fallback are retained. No helper is appended if no call qualifies.

## Composition and proof coverage

The retained publication-view pass runs before contained-load processing and
before appending the new private helper. Its existing ownership predicate is
not broadened. The authored composition test requires the same single
publication capture and two captured stores plus the independent contained
read. Reserved-name collision also leaves the retained publication pass active.

The owned regression file covers inferred and explicit destinations, explicit
bases, first/new-maximum and rising endpoints, distinct grouped declarations,
RHS-before-base invalidation, pre-region escapes, control/effect barriers,
shadowing and unsupported types/addresses, reserved identifiers, mandatory
helper/ownership drift, complete helper/directive preservation, and publication
composition. Positive typed-local coverage declares int32/int64/float64 before
the first read and preserves facts across their later pure assignments; the
separate declaration-between-reads case remains a negative barrier test.
Canonical typed and inferred i64 wrapper cases have matching impure-body
negative controls.

Focused verification performed by this agent, with CGO disabled and PGO off:

```text
env GOCACHE=/home/dario/Code/cocoon/.cache/go CGO_ENABLED=0 GOTOOLCHAIN=local go test -pgo=off ./internal/harden -run 'TestContainedLoad|TestPublication' -count=1
ok  dario.cat/cocoon/internal/harden  0.455s

env PATH=/usr/lib64/go/1.26/bin:/usr/local/bin:/usr/bin:/bin GOCACHE=/home/dario/Code/cocoon/.cache/go CGO_ENABLED=0 GOTOOLCHAIN=local /usr/lib64/go/1.26/bin/go test -pgo=off ./internal/harden -run 'TestContainedLoad|TestPublication' -count=1
ok  dario.cat/cocoon/internal/harden  0.440s

env GOCACHE=/home/dario/Code/cocoon/.cache/go GOLANGCI_LINT_CACHE=/home/dario/Code/cocoon/.cache/golangci-lint CGO_ENABLED=0 GOTOOLCHAIN=local .cache/bin/golangci-lint fmt internal/harden/contained_loads_test.go
exit 0, no output
```

These outputs were observed in tool results; this note is a procedural record,
not fabricated raw stdout. No benchmark, profile, or full lint was run by this
agent in this implementation review. The parent owns full final-tree gates and
their durable logs. The parent's final check now passes; an earlier check read
the file before the final parallel-subtest edits and is not final-tree evidence.

## Known limits and selection difference

The parent reports production selections of Datadog 318, compute 99, and
streaming 20. Datadog's phase-0 diagnostic selected 319. In fn177 the later
l8-to-l0 opportunity loses its fact across `t19 := p15+p17`: the production
type inference deliberately does not establish a builtin numeric type for
that inferred arithmetic temporary. This is intentional conservative
ineligibility, not an error or reason to broaden the reviewed guard. Function
numbers explain the diagnostic difference only; they do not select production
sites.

The existing parser-binding adapter is used only in the constrained grammar
whose declarations and types are proved. Unsupported forms remain unchanged.
The pass does not perform general control-flow or alias analysis. Full Rewrite
does not gain a new idempotence contract; existing bulk-helper drift checks
must remain strict, and fresh clean generation must reproduce artifacts.

Native host replacement/shrinking at an import is covered by a barrier;
concurrent mutation and fabrication of backing storage inside the Module object
remain outside the existing trusted-host ownership precondition. Native logical
length below capacity, high/wrapped addresses, first-trap/ordered prefixes,
import effects, and semantic mutants require the independent executable proof.
Cross compilation alone is not execution evidence. Production measurements can
also change frames and placement, so diagnostic speedups are not a pure
per-check causal estimate or a production claim.
