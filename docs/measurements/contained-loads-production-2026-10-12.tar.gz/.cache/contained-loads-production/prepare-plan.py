from pathlib import Path
import json,hashlib,subprocess
root=Path.cwd();out=root/'.cache/contained-loads-production';plan=json.loads((root/'.cache/translation-next/qualification-plan.json').read_text());plan['baseline_revision']='be8f6e0'
for group in plan['comparisons']:
 if group['kind']=='stream-control':
  original=group['cases'][0];group['baseline_role']='baseline';group['cases']=[dict(original,role='baseline',binary='stream-baseline'),dict(original,role='probe',binary='stream')]
plan['notes']=[
 'Generic authored production candidate following committed specification be8f6e0. Baseline overlay restores exactly be8f6e0 translated modules; facade/runtime/harness/guest Wasm bytes are unchanged.',
 'Validated owned Module/helpers/bindings, explicit local i32 bases, binding declaration+name keys, typed pure locals, wholemethod escape/go exclusions and straightline effect/control barriers. Select318 Datadog reads,99compute,20stream; privatehelperonlyunsafeendpointcheckelided, all guestreads/first/newmax positions/endianfallback retained. Publicationpredicate unchanged.',
 'Recheck reintroduces endpoint check only in copied production privatehelper with identical selected calls. Ordinary code/frame/registerallocation/placement effects remain attribution limits. Diagnosticphase0 gains are never added to production gains.',
 'Twelve production/corpus leaves each run baseline/probe/recheck/fresh reference, one rawGuest runs three variants, four streaming leaves pair baseline/probe:59 invocations/pass,14 passes,826samples. No cold/startup cases.',
 'Original/layer leaves frameworkcpu16 with no inwindowprocessor metric; matchedleaves actualP1 verified; both streamingroles actualP16 verified. No compilation/tests/lint/fuzz/profiles/reviewertools overlap timing; no outlier removed. Exploratory unadjusted pvalues/nondetection limitations retained.',
 'Fresh independent reference ABI2/context/topology and originalbatchtrace input differences contextual, increasingdifferentcalibratedprefixes evolvingstate; paired samefacade/harness corpora equal. Originalabsolute andfresh110percent M1limits remain applicable; no standalone scalar claim.'
]
assert len(plan['comparisons'])==17 and sum(len(g['cases']) for g in plan['comparisons'])==59
(out/'qualification-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
records=json.loads((out/'variant-build-records.json').read_text());commands={x['name']:x['argv'] for x in records if 'name' in x};head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
config={'plan':'.cache/contained-loads-production/qualification-plan.json','binaries':{r:'.cache/contained-loads-production/'+r+'.test' for r in ('baseline','probe','recheck','reference','stream','stream-baseline')},'added_harness':[],'build_records':{},'artifacts':['go.mod','go.sum','Makefile','docs/translation-contained-loads.md','examples/datadog/cocoon.lock.json','testdata/compute/cocoon.lock.json','testdata/streaming/cocoon.lock.json','.cache/reference.mod','.cache/reference.sum'], 'production_sha256':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in ('examples/datadog/go/dd/testdata/module.wasm','examples/datadog/go/dd/internal/wasm/module.go','testdata/compute/go/compute/testdata/module.wasm','testdata/compute/go/compute/internal/wasm/module.go','testdata/streaming/go/streaming/testdata/module.wasm','testdata/streaming/go/streaming/internal/wasm/module.go')}}
for role in ('baseline','probe','recheck'):config['build_records'][role]={'command':commands[role+'-compile'],'cwd':str(root),'source_identity':('Exact be8f6e0 baseline overlay' if role=='baseline' else ('Authored candidate translated module at frozenHEAD '+head if role=='probe' else 'Private copied-helper-checkrestored attribution overlay of production candidate'))}
config['build_records']['stream-baseline']={'command':commands['stream-baseline-compile'],'cwd':str(root),'source_identity':'Exact be8f6e0 baseline streaming module overlay; other sources identical'}
config['build_records']['stream']={'command':['/usr/lib64/go/1.26/bin/go','test','-c','-pgo=off','-o',str(out/'stream.test'),'./testdata/streaming/go/streaming'],'cwd':str(root),'source_identity':'Fresh authored streaming candidate after full gates and two identical proof/runtime rebuilds, frozenHEAD '+head}
config['build_records']['reference']={'command':['/usr/lib64/go/1.26/bin/go','test','-modfile='+str(root/'.cache/reference.mod'),'-overlay='+str(out/'reference-overlay.json'),'-pgo=off','-c','-o',str(out/'reference.test'),'./dd'],'cwd':'/home/dario/Code/cocoon-spike/go','source_identity':'Fresh locked independent Rust/Go source own hardener, no Cocoonimplementationtransplant; buildargv/source/provenance frozen'}
for p in out.iterdir():
 if p.is_file() and p.suffix in ('.go','.json','.py','.asm','.md'):config['artifacts'].append(str(p.relative_to(root)))
for p in (root/'internal/smoke').rglob('*'):
 if p.is_file() and 'contained-loads' in str(p):config['artifacts'].append(str(p.relative_to(root)))
for p in (out/'ssa').rglob('*.dump'):config['artifacts'].append(str(p.relative_to(root)))
config['artifacts'].append('internal/smoke/contained_loads_test.go');config['artifacts']=sorted(set(config['artifacts']))
(out/'qualification-config.json').write_text(json.dumps(config,indent=2)+'\n');print('Prepared17groups59processes/pass826rows; freeze onlyafter finalgates/reviews/commit',flush=True)
