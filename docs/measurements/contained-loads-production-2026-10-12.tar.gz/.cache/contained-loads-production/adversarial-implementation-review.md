# Applied adversarial implementation review, 2026-10-12

Disposition: approve the current conservative contained-load implementation for production proof/measurement qualification. No semantic blocker found. This review is a source audit, not performance acceptance. No tests, builds, lint, profiles, benchmark tools, or production mutations were run by this reviewer.

## Identity of reviewed inputs

{
  "internal/harden/contained_loads.go": "2e444f0725524a180536cad3e9dded9f6a8d08d8fb2feed1dce040cd58cbca60",
  "internal/harden/harden.go": "61559ba1882d6f375eced0091ce84af998f040facd57fb3d6a39302d30f3d3cf",
  "internal/harden/contained_loads_test.go": "cb451e38bdcdcca1b8430700f5fa51aa462e9b79a8458ed21fd4d7ab3117cd4d",
  "internal/harden/memory_views.go": "4fadfed409e69fb42f0a43638bb0d9ec2431586d8cd624d239fdd3499790b99b",
  "internal/harden/memory_views_bindings.go": "619bcad5985e5f7c8584d61fe3569a5f7688c1116d64b85f016bea0ba71d7037",
  "internal/harden/memory_views_ownership.go": "39935777d3bfd07d6cdbf092cf6760914543f3a2dedd62a661d13f0dc0de4d05",
  "internal/harden/memory_views_shapes.go": "eaadeeaa824395fab32e2302bd74132a6691fef1abe1679a7fc64707c3b0e172",
  "docs/translation-contained-loads.md": "e269c7d40dd2c62fb5472bb1d9c4c5b7369ffec23df199d58c1a2f2f9e1983c6"
}

## Predicate and semantic audit

The pass selects by bound AST structure, not payload, function ID, source line, hash, or prior benchmark outcome. The common scalarViewBindings guard remains mandatory and all four existing memory-view source files are byte-identical to HEAD: canonical scalar helper signatures/bodies and permitted directives, builtin and import identities, architecture constants, actual Module memory field and receiver, separately allocated construction, forbidden rebindings/indirect writes/backing fabrication. Publication rewriting runs first; accesses to its captured views do not satisfy the exact receiver.memory argument predicate. The retained publication guard/predicate is unchanged.

Contained facts and escaped bindings use containedBinding{declaration,name}. Grouped parameters/variables sharing one Field/ValueSpec still have distinct names; shadows have distinct declarations. Facts require proved method-local builtin int32 bases declared explicitly as fields/ValueSpecs. Inferred load destinations are permitted only through the validated sole uint32 load or unshadowed int32 conversion; named/global/blank/unproved destinations are excluded. Generic helpers, builtin conversions, and i64 identity calls retain full declaration/binding/body/directive validation.

Each lexical block begins with fresh facts. No fact propagates across labels/control joins, nested-block entry/exit, unproved statements/calls, stores, imports, growth, declarations, multi/compound assignments, inc/dec, indexing/selectors/pointers, defer/go, or unknown effects. A proved single scalar short declaration is the explicit conservative exception. Whole-method escape scanning excludes address-taken/captured bases even when escape occurs before the current region; Go statements exclude the method. RHS is evaluated under old base facts, then its destination key is invalidated.

Addresses remain exactly builtin uint32(base) or widened uint64(uint32(base))+bounded u32 literal. Arithmetic is not normalized into wrapping addition. Offset endpoints are safe in uint64. First and new-maximum checked loads stay at the original execution positions; only later contained load callee changes. Guest values/reads/operands/evaluation order are preserved. Native logical length, not capacity, governs established ranges; wider invalid addresses trap at retained guards before uintptr narrowing on 386. Calls/imports that change headers invalidate facts.

The collision scan covers identifiers in all namespaces/scopes and leaves this pass inactive without a new build failure. No helper is appended without a selected call. The private helper clones the validated original source/directives, removes only the exact unsafe-branch endpoint check, and preserves endian conversion, unsafe live read, address widths, nosplit policy and checked unaligned fallback. The existing public/ABI/runtime memory, ownership, reply, poison and shutdown policies are unaffected.

## Tests/proof scope and limits

Earlier source review requested a positive test with explicit typed locals declared before the first read and pure assignments between reads; the original typed-local case intentionally exercised declaration barriers. Root now reports this positive coverage plus i64 drift cases and focused Go 1.26/1.27 success. Root/host report weighted 520 WAT comparisons, distinct grouped-base proof, four roles, three executable semantic-failure mutants, amd64/native386 success. These executions were not independently repeated by this reviewer. Nonvacuous selected-site assertions remain essential under mandatory ownership guards.

Root reports current authored pipeline selects Datadog318 (phase0 diagnostic319; omitted fn177 inferred arithmetic temporary), compute99 and streaming20, and regenerates all modules/locks. This conservative omission is consistent with explicit address-base typing; phase0 inventory equality is not a retention requirement. Counts do not establish performance. All gates and repeat builds must finish, followed by isolated frozen before/after production measurements with holdouts, fresh independent reference, all negatives preserved. No standalone speedup or M1 acceptance follows from this source review or diagnostic evidence. No public contract was added.

Tools stopped after saving this ignored note.
