"""Compress completed evidence without executing any build or benchmark."""
from pathlib import Path
import argparse
import collections
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile

from common import DIRECTORY, ROOT, expected_count


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, action="append", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--readable", type=Path, required=True, help="short durable text/Markdown record beside the tar.gz")
    parser.add_argument("--summary", type=Path, required=True, help="root-authored concise findings/negatives/provenance text")
    parser.add_argument("--execute-write", action="store_true")
    args = parser.parse_args()
    if not args.execute_write:
        parser.error("no document writes without --execute-write and root authorization")
    inventories = []
    for run in args.run:
        complete = json.loads((run / "complete.json").read_text())
        frozen = json.loads((run / "frozen.json").read_text())
        rows = [json.loads(line) for line in (run / "records.jsonl").read_text().splitlines()]
        assert len(rows) == complete["rows"] == expected_count(frozen["plan"], complete["mode"])
        assert len({r["raw"] for r in rows}) == len(rows)
        for row in rows:
            data = (run / row["raw"]).read_text()
            assert row["raw_row"] in data and "EXIT 0" in data
        inventories.append({"directory": str(run), "mode": complete["mode"], "rows": len(rows),
                            "groups": len(collections.Counter((r["round"], r["comparison"], r["role"]) for r in rows)),
                            "completed": complete["completed_utc"]})
    files = {}
    allowed = {".py", ".json", ".jsonl", ".txt", ".md", ".log", ".go", ".patch", ".csv", ".warnings", ".pprof", ".cpu", ".dump", ".asm", ".wat", ".wasm", ".mod", ".sum", ".sh"}
    # Generated production modules are already committed and fingerprinted;
    # omit repeated megabytes and executable binaries. Every raw process and
    # derived statistic is preserved once inside this exact-byte bundle.
    omitted = {"reference-module.go"}
    for filename in sorted(DIRECTORY.rglob("*")):
        if filename.is_file() and filename.suffix in allowed and filename.name not in omitted and "reference-rust" not in filename.parts and "__pycache__" not in filename.parts:
            files[str(filename.relative_to(ROOT))] = filename.read_bytes()
    # This phase-zero round retained no production implementation. Preserve the
    # exact ignored overlay sources/proof above; unchanged production bytes are
    # identified by clean frozen HEAD and fingerprints.
    # Preserve the unversioned reference's selected authored inputs themselves,
    # not only their hashes. Its transitive upstream remains identified by the
    # separately recorded clean Git revision and locked dependencies.
    reference = json.loads((DIRECTORY / "reference-source-before.json").read_text())
    assert reference == json.loads((DIRECTORY / "reference-source-after.json").read_text())
    spike = Path(reference["spike"])
    for name, expected in reference["source_sha256"].items():
        assert not Path(name).is_absolute() and ".." not in Path(name).parts
        data = (spike / name).read_bytes()
        assert hashlib.sha256(data).hexdigest() == expected
        files[".cache/scalar-next/reference-source/" + name] = data
    for name in (".cache/reference.mod", ".cache/reference.sum"):
        files[name] = (ROOT / name).read_bytes()
    # Record the exact authored staged patch if still uncommitted. Empty patch
    # is permitted once the harness has been committed; immutable HEAD remains
    # recorded by freeze and the supplied final summary.
    patch = subprocess.check_output(["git", "diff", "--cached", "--binary", "--", "internal/", "rt/", "testdata/", "examples/"], cwd=ROOT)
    files[".cache/scalar-next/archived-staged.patch"] = patch
    manifest = {name: {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()} for name, data in sorted(files.items())}
    manifest_bytes = (json.dumps(manifest, indent=2) + "\n").encode()
    stream = io.BytesIO()
    with tarfile.open(fileobj=stream, mode="w") as tar:
        for name, data in [("MANIFEST.json", manifest_bytes), *sorted(files.items())]:
            assert not Path(name).is_absolute() and ".." not in Path(name).parts
            member = tarfile.TarInfo(name)
            member.size, member.mode, member.mtime = len(data), 0o644, 0
            tar.addfile(member, io.BytesIO(data))
    packed = gzip.compress(stream.getvalue(), mtime=0)
    header = args.summary.read_text().rstrip() + "\n\n"
    header += "Exact-byte compressed evidence. Raw benchmark names, every sample/custom metric, failure logs, derived comparison aliases, scripts and frozen/build/reference provenance are preserved in the bundle. Binary executables and unchanged committed generated modules are identified by hashes and build commands, not embedded. No whitespace normalization changes bundled bytes.\n\n"
    header += json.dumps({"inventory": inventories, "payload_artifacts": len(files), "tar_members_including_manifest": len(files) + 1,
                          "compressed_bytes": len(packed), "compressed_sha256": hashlib.sha256(packed).hexdigest()}, indent=2) + "\n\n"
    header += "Audit without extraction or execution: verify the compressed SHA256, open gzip/tar in memory, then verify each MANIFEST.json byte length and SHA256. All member paths are relative. Reproduce the unchanged production inputs from frozen revision and exact fingerprints.\n\n"
    # Verify the exact gzip/tar bytes in memory before publishing an artifact.
    with tarfile.open(fileobj=io.BytesIO(packed), mode="r:gz") as tar:
        members = tar.getmembers()
        assert len({m.name for m in members}) == len(members)
        assert {m.name for m in members} == set(manifest) | {"MANIFEST.json"}
        inside = json.loads(tar.extractfile("MANIFEST.json").read())
        assert inside == manifest
        for member in members:
            assert member.isfile() and not Path(member.name).is_absolute() and ".." not in Path(member.name).parts
            if member.name == "MANIFEST.json":
                continue
            data = tar.extractfile(member).read()
            assert len(data) == manifest[member.name]["bytes"]
            assert hashlib.sha256(data).hexdigest() == manifest[member.name]["sha256"]
    assert args.output.name.endswith(".tar.gz"), "archive must be an actual .tar.gz artifact"
    assert args.readable.suffix in {".txt", ".md"}
    sha_file = args.output.with_name(args.output.name + ".sha256")
    assert not args.output.exists() and not args.readable.exists() and not sha_file.exists()
    with args.output.open("xb") as output:
        output.write(packed)
    with args.readable.open("x") as output:
        output.write(header.rstrip()+"\n")
    with sha_file.open("x") as output:
        output.write(hashlib.sha256(packed).hexdigest() + "  " + args.output.name + "\n")
    print("Archived", len(files), "exact artifacts;", sum(i["rows"] for i in inventories), "raw rows;", args.output.stat().st_size, "compressed bytes; manifest/bytes validated in memory")


if __name__ == "__main__":
    main()
