from pathlib import Path
import json,hashlib,subprocess
root=Path.cwd();out=root/'.cache/scalar-next';head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
records=json.loads((out/'variant-build-records.json').read_text());commands={x['name']:x['argv'] for x in records if 'name' in x}
config={'plan':'.cache/scalar-next/qualification-plan.json','binaries':{role:'.cache/scalar-next/'+role+'.test' for role in ('baseline','probe','recheck','reference','stream')},'added_harness':[],'build_records':{},'artifacts':['go.mod','go.sum','Makefile','examples/datadog/cocoon.lock.json','testdata/compute/cocoon.lock.json','testdata/streaming/cocoon.lock.json','.cache/reference.mod','.cache/reference.sum'],'production_sha256':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in ('examples/datadog/go/dd/testdata/module.wasm','examples/datadog/go/dd/internal/wasm/module.go','testdata/compute/go/compute/testdata/module.wasm','testdata/compute/go/compute/internal/wasm/module.go','testdata/streaming/go/streaming/testdata/module.wasm','testdata/streaming/go/streaming/internal/wasm/module.go')}}
for role in ('baseline','probe','recheck','stream'):
 config['build_records'][role]={'command':commands[role+'-compile'],'cwd':str(root),'source_identity':{'baseline':'Untouched clean production at '+head,'probe':'Ignored whole-source-pinned three adjacent read64/store64 pairs; canonical copied helper removes only unsafe endpoint','recheck':'Identical ignored selected calls/copied store helper restoring exactly the unsafe endpoint guard','stream':'Untouched clean streaming proof; byte-identical binary used in both bracket roles, no candidate streaming implementation'}[role]}
config['build_records']['reference']={'command':['/usr/lib64/go/1.26/bin/go','test','-modfile='+str(root/'.cache/reference.mod'),'-overlay='+str(out/'reference-overlay.json'),'-pgo=off','-c','-o',str(out/'reference.test'),'./dd'],'cwd':'/home/dario/Code/cocoon-spike/go','source_identity':'Fresh absent-target locked independent Rust source/shim and own hardener; source snapshots and actual command journal included; no Cocoon implementation transplant'}
for p in out.rglob('*'):
 if p.is_file() and p.suffix in ('.go','.json','.jsonl','.py','.asm','.md','.dump','.wat','.log','.cpu','.txt','.wasm','.mod','.sum','.sh') and 'reference-rust' not in p.parts and '__pycache__' not in p.parts and not p.name.endswith('.test'):
  config['artifacts'].append(str(p.relative_to(root)))
config['artifacts'].extend(str(p.relative_to(root)) for p in (out/'proof').glob('proof-*.test'))
config['artifacts']=sorted(set(config['artifacts']))
(out/'qualification-config.json').write_text(json.dumps(config,indent=2)+'\n')
print('Config prepared; clean-source phase-zero freeze remains mandatory before timing')
