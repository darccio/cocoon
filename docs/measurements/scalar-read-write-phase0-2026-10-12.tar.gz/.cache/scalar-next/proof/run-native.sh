#!/usr/bin/env bash
set -euo pipefail
cd /home/dario/Code/cocoon/.cache/scalar-next/proof
export PATH=/usr/lib64/go/1.26/bin:/usr/local/bin:/usr/bin:/bin
export CGO_ENABLED=0 GOTOOLCHAIN=local
export GOCACHE=/home/dario/Code/cocoon/.cache/go
proof_arch=${1:?amd64 or 386 required}
export GOARCH="$proof_arch"
printf '%s\n' "PATH=$PATH CGO_ENABLED=$CGO_ENABLED GOTOOLCHAIN=$GOTOOLCHAIN GOARCH=$GOARCH GOCACHE=$GOCACHE" > "native-$proof_arch.commands.txt"
printf '%s\n' '/usr/lib64/go/1.26/bin/go version' >> "native-$proof_arch.commands.txt"
/usr/lib64/go/1.26/bin/go version > "native-$proof_arch.version.txt"
printf '%s\n' "/usr/lib64/go/1.26/bin/go test -c -pgo=off -o proof-$proof_arch.test ." >> "native-$proof_arch.commands.txt"
/usr/lib64/go/1.26/bin/go test -c -pgo=off -o "proof-$proof_arch.test" . > "native-$proof_arch.build.log" 2>&1
printf '%s\n' "./proof-$proof_arch.test -test.v" >> "native-$proof_arch.commands.txt"
"./proof-$proof_arch.test" -test.v > "native-$proof_arch.log" 2>&1
sha256sum "proof-$proof_arch.test" > "native-$proof_arch.binary.sha256"
