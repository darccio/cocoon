module scalarproof

go 1.26.0
