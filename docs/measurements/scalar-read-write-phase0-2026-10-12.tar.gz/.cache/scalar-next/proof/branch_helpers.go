package scalarproof

import (
	"encoding/binary"
	"math/bits"
	"unsafe"
)

// Test-only branch controls; these do not claim execution on a big-endian architecture.
var modeBig, modeUnaligned bool

//go:nosplit
func modeLoad64[T uint32 | uint64](mem []byte, addr T) uint64 {
	if !modeUnaligned {
		return binary.LittleEndian.Uint64(mem[addr:])
	}
	_ = mem[uint64(addr)+7]
	val := *(*uint64)(unsafe.Add(unsafe.Pointer(unsafe.SliceData(mem)), uintptr(addr)))
	if modeBig {
		return bits.ReverseBytes64(val)
	}
	return val
}

//go:nosplit
func modeStore64[T uint32 | uint64](mem []byte, addr T, val uint64) {
	if !modeUnaligned {
		binary.LittleEndian.PutUint64(mem[addr:], val)
		return
	}
	if modeBig {
		val = bits.ReverseBytes64(val)
	}
	_ = mem[uint64(addr)+7]
	*(*uint64)(unsafe.Add(unsafe.Pointer(unsafe.SliceData(mem)), uintptr(addr))) = val
}

//go:nosplit
func modeUncheckedStore64[T uint32 | uint64](mem []byte, addr T, val uint64) {
	if !modeUnaligned {
		binary.LittleEndian.PutUint64(mem[addr:], val)
		return
	}
	if modeBig {
		val = bits.ReverseBytes64(val)
	}
	*(*uint64)(unsafe.Add(unsafe.Pointer(unsafe.SliceData(mem)), uintptr(addr))) = val
}

//go:nosplit
func modeUncheckedLoad64[T uint32 | uint64](mem []byte, addr T) uint64 {
	if !modeUnaligned {
		return binary.LittleEndian.Uint64(mem[addr:])
	}
	val := *(*uint64)(unsafe.Add(unsafe.Pointer(unsafe.SliceData(mem)), uintptr(addr)))
	if modeBig {
		return bits.ReverseBytes64(val)
	}
	return val
}
