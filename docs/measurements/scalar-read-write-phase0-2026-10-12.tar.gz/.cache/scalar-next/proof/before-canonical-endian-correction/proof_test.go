package scalarproof

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"math"
	"os"
	"os/exec"
	"reflect"
	"strings"
	"testing"
)

type operation struct {
	addr       uint64
	delta      float64
	subtract   bool
	headerLen  int // -1 means no header/import barrier.
	replace    bool
	reallocate bool
}

type scenario struct {
	name       string
	length     int
	initial    uint64
	operations []operation
}

type engine struct {
	load      func([]byte, uint64) uint64
	store     func([]byte, uint64, uint64)
	uncheck   func([]byte, uint64, uint64)
	loadBad   func([]byte, uint64) uint64
	optimized bool
}

type observation struct {
	Stage   string
	Bits    uint64
	Length  int
	Trapped bool
	Backing []byte
	Old     []byte
}

func record(history *[]observation, stage string, bits uint64, trapped bool, memory, backing, old []byte) {
	*history = append(*history, observation{stage, bits, len(memory), trapped, bytes.Clone(backing), bytes.Clone(old)})
}

func canonicalEngine(carrier32 bool, optimized bool) engine {
	if carrier32 {
		return engine{
			load:      func(memory []byte, addr uint64) uint64 { return load64(memory, uint32(addr)) },
			store:     func(memory []byte, addr, bits uint64) { store64(memory, uint32(addr), bits) },
			uncheck:   func(memory []byte, addr, bits uint64) { uncheckedStore64(memory, uint32(addr), bits) },
			loadBad:   func(memory []byte, addr uint64) uint64 { return uncheckedLoad64(memory, uint32(addr)) },
			optimized: optimized,
		}
	}
	return engine{load64[uint64], store64[uint64], uncheckedStore64[uint64], uncheckedLoad64[uint64], optimized}
}

func branchEngine(optimized bool) engine {
	return engine{modeLoad64[uint64], modeStore64[uint64], modeUncheckedStore64[uint64], modeUncheckedLoad64[uint64], optimized}
}

func backingFor(test scenario, order binary.ByteOrder) []byte {
	backing := make([]byte, 64)
	for index := range backing {
		backing[index] = byte(index*37 + 19)
	}
	for _, op := range test.operations {
		if op.addr <= uint64(len(backing)-8) {
			order.PutUint64(backing[int(op.addr):], test.initial)
		}
	}
	return backing
}

func changedHeader(op operation, memory, backing []byte) ([]byte, []byte, []byte) {
	if !op.replace && !op.reallocate {
		return backing[:op.headerLen], backing, nil
	}
	old := backing
	capacity := 64
	if op.reallocate {
		capacity = 128
	}
	backing = make([]byte, capacity)
	if op.reallocate {
		copy(backing, memory)
	} else {
		for index := range backing {
			backing[index] = byte(index*17 + 91)
		}
	}
	return backing[:op.headerLen], backing, old
}

func run(test scenario, e engine, order binary.ByteOrder, mutant string) (history []observation) {
	backing := backingFor(test, order)
	memory := backing[:test.length]
	var old []byte
	stage := "entry"
	defer func() {
		if recover() != nil {
			record(&history, stage, 0, true, memory, backing, old)
		}
	}()
	for index, op := range test.operations {
		stage = fmt.Sprintf("%d/load", index)
		load := e.load
		if mutant == "first-check deletion" {
			load = e.loadBad
		}
		bits := load(memory, op.addr)
		record(&history, stage, bits, false, memory, backing, old)
		value := math.Float64frombits(bits)
		if op.subtract {
			value = float64(value - op.delta)
		} else {
			value = float64(value + op.delta)
		}
		bits = math.Float64bits(value)
		if op.headerLen >= 0 {
			memory, backing, old = changedHeader(op, memory, backing)
			stage = fmt.Sprintf("%d/header", index)
			record(&history, stage, 0, false, memory, backing, old)
		}
		stage = fmt.Sprintf("%d/store", index)
		store := e.store
		if e.optimized && (op.headerLen < 0 || mutant == "header crossing") {
			store = e.uncheck
		}
		store(memory, op.addr, bits)
		record(&history, stage, bits, false, memory, backing, old)
	}
	return history
}

func readable(memory []byte, addr uint64) bool {
	return addr <= uint64(len(memory)) && uint64(len(memory))-addr >= 8
}

// The oracle uses binary decoding/encoding and explicit logical range tests,
// independently of the unsafe helpers and their endpoint implementation.
func oracle(test scenario, order binary.ByteOrder) (history []observation) {
	backing := backingFor(test, order)
	memory := backing[:test.length]
	var old []byte
	for index, op := range test.operations {
		stage := fmt.Sprintf("%d/load", index)
		if !readable(memory, op.addr) {
			record(&history, stage, 0, true, memory, backing, old)
			return history
		}
		bits := order.Uint64(memory[int(op.addr):])
		record(&history, stage, bits, false, memory, backing, old)
		value := math.Float64frombits(bits)
		if op.subtract {
			value = float64(value - op.delta)
		} else {
			value = float64(value + op.delta)
		}
		bits = math.Float64bits(value)
		if op.headerLen >= 0 {
			memory, backing, old = changedHeader(op, memory, backing)
			stage = fmt.Sprintf("%d/header", index)
			record(&history, stage, 0, false, memory, backing, old)
		}
		stage = fmt.Sprintf("%d/store", index)
		if !readable(memory, op.addr) {
			record(&history, stage, 0, true, memory, backing, old)
			return history
		}
		order.PutUint64(memory[int(op.addr):], bits)
		record(&history, stage, bits, false, memory, backing, old)
	}
	return history
}

func check(t *testing.T, test scenario, e engine, order binary.ByteOrder, mutant string) {
	t.Helper()
	want := oracle(test, order)
	got := run(test, e, order, mutant)
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("byte/trap mismatch for %s (%s)\n got: %#v\nwant: %#v", test.name, mutant, got, want)
	}
}

func op(addr uint64) operation { return operation{addr: addr, delta: 1, headerLen: -1} }

func scenarios() []scenario {
	wrapped := func(base, delta int32) uint64 { return uint64(uint32(base + delta)) }
	widened := func(base int32, delta uint32) uint64 { return uint64(uint32(base)) + uint64(delta) }
	shrink := op(8)
	shrink.headerLen = 4
	replace := shrink
	replace.replace = true
	grow := op(8)
	grow.headerLen = 32
	reallocate := grow
	reallocate.reallocate = true
	subtract := op(8)
	subtract.subtract = true
	return []scenario{
		{"exact", 8, math.Float64bits(1.25), []operation{op(0)}},
		{"unaligned-exact", 9, math.Float64bits(1.25), []operation{op(1)}},
		{"unaligned-three", 19, math.Float64bits(3.125), []operation{op(3)}},
		{"zero-length", 0, math.Float64bits(1), []operation{op(0)}},
		{"short", 7, math.Float64bits(1), []operation{op(0)}},
		{"unaligned-short", 8, math.Float64bits(1), []operation{op(1)}},
		{"len-below-cap-valid", 24, math.Float64bits(1), []operation{op(8)}},
		{"len-below-cap-invalid", 8, math.Float64bits(1), []operation{op(8)}},
		{"partial-write-prefix", 16, math.Float64bits(1), []operation{op(0), op(16), op(8)}},
		{"unaligned-prefix", 16, math.Float64bits(1), []operation{op(1), op(9), op(0)}},
		{"high-bit", 16, math.Float64bits(1), []operation{op(0x80000000)}},
		{"negative-base", 16, math.Float64bits(1), []operation{op(wrapped(-1, 0))}},
		{"wrapped-i32-address", 24, math.Float64bits(1), []operation{op(wrapped(-8, 24))}},
		{"widened-nonwrapping-address", 24, math.Float64bits(1), []operation{op(widened(-8, 24))}},
		{"largest-u32-plus24", 24, math.Float64bits(1), []operation{op(widened(-1, 24))}},
		{"subtract", 16, math.Float64bits(3.125), []operation{subtract}},
		{"negative-zero", 16, math.Float64bits(math.Copysign(0, -1)), []operation{op(8)}},
		{"smallest-subnormal", 16, 1, []operation{op(8)}},
		{"large-rounding", 16, math.Float64bits(0x1p53), []operation{op(8)}},
		{"maximum-finite", 16, math.Float64bits(math.MaxFloat64), []operation{op(8)}},
		{"infinity", 16, math.Float64bits(math.Inf(1)), []operation{op(8)}},
		{"quiet-nan", 16, 0x7ff8000000000001, []operation{op(8)}},
		{"header-shrink", 24, math.Float64bits(1), []operation{shrink}},
		{"header-replace", 24, math.Float64bits(1), []operation{replace}},
		{"growth-spare-capacity", 16, math.Float64bits(1), []operation{grow}},
		{"growth-reallocation", 16, math.Float64bits(1), []operation{reallocate}},
	}
}

func TestCanonicalHelpers(t *testing.T) {
	order := binary.ByteOrder(binary.LittleEndian)
	if big && unalignedOK {
		order = binary.BigEndian
	}
	for _, test := range scenarios() {
		t.Run(test.name, func(t *testing.T) {
			for _, optimized := range []bool{false, true} {
				check(t, test, canonicalEngine(false, optimized), order, "")
				if test.operations[0].addr <= 0xffffffff {
					check(t, test, canonicalEngine(true, optimized), order, "")
				}
			}
		})
	}
}

func TestFallbackAndByteSwapBranches(t *testing.T) {
	for _, mode := range []struct {
		name      string
		big       bool
		unaligned bool
	}{
		{"unsafe-native-endian", false, true},
		{"unsafe-simulated-byte-swap", true, true},
		{"checked-fallback", false, false},
		{"checked-fallback-with-byte-swap-flag", true, false},
	} {
		t.Run(mode.name, func(t *testing.T) {
			modeBig, modeUnaligned = mode.big, mode.unaligned
			order := binary.ByteOrder(binary.LittleEndian)
			if mode.big && mode.unaligned {
				order = binary.BigEndian
			}
			for _, test := range scenarios() {
				check(t, test, branchEngine(false), order, "")
				check(t, test, branchEngine(true), order, "")
			}
		})
	}
}

func TestMutantProbe(t *testing.T) {
	mutant := os.Getenv("SCALAR_PROOF_MUTANT")
	if mutant == "" {
		t.Skip("executed only by semantic mutant parent")
	}
	if !unalignedOK || big {
		t.Fatal("bounded mutant probe requires native little-endian unsafe branch")
	}
	for _, test := range scenarios() {
		if mutant == "first-check deletion" && test.name == "len-below-cap-invalid" ||
			mutant == "header crossing" && test.name == "header-shrink" {
			check(t, test, canonicalEngine(false, true), binary.LittleEndian, mutant)
			return
		}
	}
	t.Fatalf("unknown mutant %q", mutant)
}

func TestSemanticMutants(t *testing.T) {
	executable, err := os.Executable()
	if err != nil {
		t.Fatal(err)
	}
	for _, mutant := range []string{"first-check deletion", "header crossing"} {
		command := exec.Command(executable, "-test.run=^TestMutantProbe$", "-test.v")
		command.Env = append(os.Environ(), "SCALAR_PROOF_MUTANT="+mutant)
		output, callErr := command.CombinedOutput()
		if callErr == nil || !strings.Contains(string(output), "--- FAIL: TestMutantProbe") ||
			!strings.Contains(string(output), "byte/trap mismatch") {
			t.Fatalf("mutant %q did not fail semantically: %v\n%s", mutant, callErr, output)
		}
		t.Logf("mutant %q rejected by executable byte/trap oracle:\n%s", mutant, output)
	}
}
