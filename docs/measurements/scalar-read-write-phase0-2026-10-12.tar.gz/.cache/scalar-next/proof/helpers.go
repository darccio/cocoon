package scalarproof

import (
	"encoding/binary"
	"math/bits"
	"runtime"
	"unsafe"
)

// go.dev/src/cmd/compile/internal/ssa/config.go
const (
	big = false ||
		runtime.GOARCH == "ppc64" || runtime.GOARCH == "s390x" ||
		runtime.GOARCH == "mips" || runtime.GOARCH == "mips64"

	little = false ||
		runtime.GOARCH == "386" || runtime.GOARCH == "amd64" ||
		runtime.GOARCH == "arm" || runtime.GOARCH == "arm64" ||
		runtime.GOARCH == "riscv64" || runtime.GOARCH == "wasm" ||
		runtime.GOARCH == "ppc64le" || runtime.GOARCH == "loong64" ||
		runtime.GOARCH == "mipsle" || runtime.GOARCH == "mips64le"

	unalignedOK = false ||
		runtime.GOARCH == "386" || runtime.GOARCH == "amd64" ||
		runtime.GOARCH == "arm64" || runtime.GOARCH == "loong64" ||
		runtime.GOARCH == "ppc64" || runtime.GOARCH == "ppc64le" ||
		runtime.GOARCH == "s390x" || runtime.GOARCH == "wasm"
)

//go:nosplit
func load64[T uint32 | uint64](mem []byte, addr T) uint64 {
	if !unalignedOK {
		return binary.LittleEndian.Uint64(mem[addr:])
	}
	_ = mem[uint64(addr)+7]
	val := *(*uint64)(unsafe.Add(unsafe.Pointer(unsafe.SliceData(mem)), uintptr(addr)))
	if big {
		return bits.ReverseBytes64(val)
	}
	return val
}

//go:nosplit
func store64[T uint32 | uint64](mem []byte, addr T, val uint64) {
	if !unalignedOK {
		binary.LittleEndian.PutUint64(mem[addr:], val)
		return
	}
	if big {
		val = bits.ReverseBytes64(val)
	}
	_ = mem[uint64(addr)+7]
	*(*uint64)(unsafe.Add(unsafe.Pointer(unsafe.SliceData(mem)), uintptr(addr))) = val
}

//go:nosplit
func uncheckedStore64[T uint32 | uint64](mem []byte, addr T, val uint64) {
	if !unalignedOK {
		binary.LittleEndian.PutUint64(mem[addr:], val)
		return
	}
	if big {
		val = bits.ReverseBytes64(val)
	}
	*(*uint64)(unsafe.Add(unsafe.Pointer(unsafe.SliceData(mem)), uintptr(addr))) = val
}

//go:nosplit
func uncheckedLoad64[T uint32 | uint64](mem []byte, addr T) uint64 {
	if !unalignedOK {
		return binary.LittleEndian.Uint64(mem[addr:])
	}
	val := *(*uint64)(unsafe.Add(unsafe.Pointer(unsafe.SliceData(mem)), uintptr(addr)))
	if big {
		return bits.ReverseBytes64(val)
	}
	return val
}
