# Ignored adjacent load64/store64 phase-zero proof

This functional proof changes no production source and implements no generic
hardener pass. `prepare.py` requires the current translated Datadog module's
full SHA-256 `626550cafa323c490a6a2ec6b2b341656c40e223c7c84701e414078633dcc298`.
The canonical architecture constants and load64/store64 helper bodies are
copied exactly. The adjacent-store variant renames store64 and removes only
its unsafe-branch `_ = mem[uint64(addr)+7]` line; endian handling, nosplit and
checked fallback remain. Final `source-provenance.json` verifies helper byte
equality and records post-format source/binary hashes. `prepare.log` records
the earlier pre-format generation hashes separately.

The checked first load is always retained in the valid candidate. Independent
binary decoding/encoding and explicit logical range checks compare the full
backing bytes, loaded/result float bits, logical lengths, trap stage, completed
write prefix, ordered header events and old/replacement backing. Twenty-six
scenarios cover aligned and unaligned access, exact/short lengths, length below
capacity, completed prefixes before traps, high/negative/wrapped/widened
addresses, pure addition/subtraction, signed zero/subnormal/rounding/extreme
values, shrinking/replacement and spare-capacity/reallocating growth.
The canonical helper oracle always uses LittleEndian: on a real big-endian
architecture the canonical helper reverses native words to preserve Wasm's
little-endian bytes. Only the separately labelled mutable-flag simulation below
uses a BigEndian oracle on the current little-endian host.

The address domain is bounded: uint32 addresses or widening plus at most 24,
so the largest endpoint is 2^32+30. No arbitrary near-MaxUint64 address is
executed; such values can overflow the canonical guard and are outside the
diagnostic's generated address predicate. Unsafe mutants use only accessible
spare backing, so they demonstrate a logical bounds violation without an
invalid physical-memory access.

Separate renamed copies with mutable flags execute four branch controls:
native-endian unsafe, simulated byte-swap unsafe, checked fallback, and fallback
with the byte-swap flag set. Simulated byte swapping uses an independent
big-endian byte oracle; it is branch execution on native little-endian hardware,
not actual big-endian architecture execution. No new floating-point algorithm
is introduced or proved against Wasm by this helper-only proof; the parent owns
the actual original-Wasm/current guest contracts and exact diagnostic overlays.

The candidate model uses the checked store after a header/import/growth barrier.
It does not prove a selection algorithm: the parent independently pins the
three exact adjacent fn176 pairs. Child runs of this same built test binary
must fail `TestMutantProbe` with `byte/trap mismatch` for deletion of the first
load check and crossing a shrinking header. The parent checks both the explicit
semantic test failure and diagnostic marker, so a compile/startup failure
cannot satisfy mutant rejection. The full child failure output is in the
native proof logs.

Adversarial review corrected a proof-only future-architecture oracle defect:
the earlier canonical test chose BigEndian when the real architecture flag was
big. That expectation was wrong because the canonical helper performs the
native-to-Wasm byte conversion. Earlier passing amd64/386 logs, binaries,
source/provenance metadata and their hashes are preserved under
`before-canonical-endian-correction/`. Both current native targets were rebuilt
and rerun after removing the canonical override. Current amd64/386 outcomes
are unaffected because their real architecture flag is little; this correction
does not establish actual execution on a big-endian target.

Both native amd64 and native 386 pass with Go 1.26.8, CGO disabled and PGO off.
Exact environment/build/execute commands are in `native-*.commands.txt`,
toolchain outputs in `native-*.version.txt`, and raw proof output in
`native-amd64.log` and `native-386-unsandboxed.log`. The initial sandboxed 386
execution was blocked by SIGSYS (exit159) before tests started; its redirected
log and a clearly labelled observed procedural note are preserved. The already
built 386 binary passed when executed with sandbox escalation. No benchmark or
profile was run here, and these outputs are correctness evidence only.

Commands executed before freezing:

```text
python3 .cache/scalar-next/proof/prepare.py > .cache/scalar-next/proof/prepare.log
/usr/lib64/go/1.26/bin/gofmt -w .cache/scalar-next/proof/helpers.go .cache/scalar-next/proof/branch_helpers.go .cache/scalar-next/proof/proof_test.go
bash .cache/scalar-next/proof/run-native.sh amd64
bash .cache/scalar-next/proof/run-native.sh 386
# cwd: .cache/scalar-next/proof; sandbox escalation, already built executable:
./proof-386.test -test.v > native-386-unsandboxed.log 2>&1
# After the oracle correction, preserve prior artifacts, then:
/usr/lib64/go/1.26/bin/gofmt -w .cache/scalar-next/proof/proof_test.go
bash .cache/scalar-next/proof/run-native.sh amd64
# cwd: .cache/scalar-next/proof; compile only, avoiding the known sandbox blocker:
env PATH=/usr/lib64/go/1.26/bin:/usr/local/bin:/usr/bin:/bin CGO_ENABLED=0 GOTOOLCHAIN=local GOARCH=386 GOCACHE=/home/dario/Code/cocoon/.cache/go /usr/lib64/go/1.26/bin/go test -c -pgo=off -o proof-386.test . > native-386.build.log 2>&1
# sandbox escalation, already built executable:
./proof-386.test -test.v > native-386-unsandboxed.log 2>&1
```
