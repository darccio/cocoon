#!/usr/bin/env python3
"""Copy pinned helper bodies for an ignored phase-zero execution proof."""
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
MODULE = ROOT / 'examples/datadog/go/dd/internal/wasm/module.go'
EXPECTED = '626550cafa323c490a6a2ec6b2b341656c40e223c7c84701e414078633dcc298'
source = MODULE.read_bytes()
actual = hashlib.sha256(source).hexdigest()
if actual != EXPECTED:
    raise SystemExit(f'module drift: {actual}, expected {EXPECTED}')
text = source.decode()

def helper(name):
    start = text.index('//go:nosplit\nfunc ' + name + '[')
    body = text.index('{', start)
    depth = 1
    end = body + 1
    while depth:
        depth += (text[end] == '{') - (text[end] == '}')
        end += 1
    return text[start:end] + '\n'

load = helper('load64')
store = helper('store64')
guard = '\t_ = mem[uint64(addr)+7]\n'
assert load.count(guard) == store.count(guard) == 1
unchecked_store = store.replace('func store64[', 'func uncheckedStore64[').replace(guard, '')
unchecked_load = load.replace('func load64[', 'func uncheckedLoad64[').replace(guard, '')
constants_start = text.index('// go.dev/src/cmd/compile/internal/ssa/config.go\nconst (')
constants_end = text.index('\n)\n', constants_start) + 3
constants = text[constants_start:constants_end]
canonical = ('package scalarproof\n\nimport (\n"encoding/binary"\n"math/bits"\n"runtime"\n"unsafe"\n)\n\n'
             + constants + '\n' + load + '\n' + store + '\n' + unchecked_store + '\n' + unchecked_load)
(HERE / 'helpers.go').write_text(canonical)

# Only this separate branch-control copy makes flags mutable. The canonical
# helpers and architecture constants above stay byte-for-byte extracted.
def mode_copy(body, name, renamed):
    body = body.replace('func ' + name + '[', 'func ' + renamed + '[')
    return re.sub(r'\b(big|unalignedOK)\b', lambda m: {'big':'modeBig', 'unalignedOK':'modeUnaligned'}[m[0]], body)

branch = ('package scalarproof\n\nimport (\n"encoding/binary"\n"math/bits"\n"unsafe"\n)\n\n'
          '// Test-only branch controls; these do not claim execution on a big-endian architecture.\n'
          'var modeBig, modeUnaligned bool\n\n'
          + mode_copy(load, 'load64', 'modeLoad64') + '\n'
          + mode_copy(store, 'store64', 'modeStore64') + '\n'
          + mode_copy(unchecked_store, 'uncheckedStore64', 'modeUncheckedStore64') + '\n'
          + mode_copy(unchecked_load, 'uncheckedLoad64', 'modeUncheckedLoad64'))
(HERE / 'branch_helpers.go').write_text(branch)
provenance = {
    'pinned_module': str(MODULE), 'pinned_module_sha256': actual,
    'copied_helper_sha256': {name: hashlib.sha256(body.encode()).hexdigest()
                             for name,body in [('load64',load),('store64',store)]},
    'canonical_scope': 'Exact architecture constants and helper bodies; copied store deletes only its unsafe endpoint line.',
    'branch_control_scope': 'Separate renamed helper copies with mutable flag bindings for fallback/byte-swap branch execution; simulated flags are not native big-endian execution.',
    'source_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                      for p in [HERE/'prepare.py',HERE/'helpers.go',HERE/'branch_helpers.go',HERE/'go.mod']},
}
(HERE / 'source-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
print(json.dumps(provenance,indent=2))
