## Scalar read and write bounds: phase 0 (2026-10-12)

**No-go for the measured standalone scalar hypothesis.** Removing three
adjacent floating-point stores' duplicate bounds checks establishes a small raw
guest gain, but neither round establishes an end-to-end scalar gain against the
unchanged binary or the copied-check control. The broad scalar holdout supplies
negative results. Keep production at `20e33db`; retain only evidence and the
roadmap decision. No generic pass, private implementation specification, new
public contract, API/ABI change or generated artifact change follows.
**M1 performance remains unaccepted.**

The [readable record](measurements/scalar-read-write-phase0-2026-10-12.md),
[compressed evidence](measurements/scalar-read-write-phase0-2026-10-12.tar.gz)
and [SHA-256](measurements/scalar-read-write-phase0-2026-10-12.tar.gz.sha256)
preserve all 826 successful raw rows and custom metrics, both controls, fresh
independent reference, exact commands/source hashes, profiles, 27 SSA dumps,
ordinary assembly, executable proofs/mutants, review and gate/reproduction logs,
and procedural negatives. No sample or outlier was dropped. The premeasurement
`decision-plan.json` requires a scalar gain against both controls in both rounds
that survives scalar holdouts; that requirement fails. Prior qualified gains
are not added to this experiment.

### Matching attribution and diagnostic scope

A fresh ordinary Go 1.26.8 PGO-off production build exactly reproduces the last
qualified binary. Eight sequential ten-second P1 CPU diagnostics precede the
probe: original scalar, raw guest, checked instance, resource, facade, SQL,
batch and trace. Scalar attributes 33.00% flat/42.17% cumulative samples to
`fn176`, 57.08% cumulative to the guest export, and 10.42% cumulative to
`ResultView`. Raw guest attributes 52.63% flat/70.06% cumulative to `fn176`.
Profiled Guest/Instance/Resource/Facade report 53.00/73.01/83.14/89.21 ns;
original scalar 87.54 ns. These profiled times and overlapping categories are
not acceptance samples or additive attainable ceilings. Layer inputs use
different calibrated increasing prefixes and evolving states.

The ignored diagnostic pins the entire Datadog translated source SHA-256. It
renames only three literally adjacent same-memory/address/width `load64` then
`store64` pairs in `fn176`: the zero-count update at offset 24, collapse
accumulation and ordinary bin increment. Its copied canonical store helper
removes only the unsafe endpoint line. The checked first load, original
addresses and evaluations, actual reads/writes, floating operations and
explicit rounding, nosplit, endian handling and checked unaligned fallback
remain. `recheck` uses identical selected calls/helper with that line restored.
All runtime/facade/harness/Wasm bytes remain unchanged. Hash/function/line
selection is disclosed diagnostic provenance, not a production predicate.

Matching ordinary machine code removes exactly three static panic-bounds sites
(78 → 75), seven instructions (1309 → 1302) and 32 bytes (5462 → 5430) in
`fn176`; frame size stays 128 bytes. Static register stores/reloads remain
37/137, while optimized SSA bounds predicates fall 74 → 71. The copied-check
control restores the original counts/frame. `fn96` and the scalar export have
identical optimized/regalloc/genssa dumps across all roles; SQL function text
and frame counts stay unchanged. There is no SQL-export SSA claim. Static
counts/frames do not isolate causal nanoseconds or exclude placement effects.

The actual diagnostic and copied-check overlays pass the existing authored
Datadog contract and original-Wasm/wazero differential suites on Go 1.26.8;
the diagnostic also passes those suites natively on 386. A separate ignored
helper proof copies the canonical source exactly and compares full backing
bytes, old/replacement bytes, exact floating bits, logical lengths, trap stages,
completed write prefixes and ordered header events. Its 26 scenarios cover
unaligned/exact/short/spare-capacity memory, high/negative/wrapped/widened
addresses, addition/subtraction and numeric boundaries, shrink/replacement and
both growth forms. Generated addresses are bounded by u32 plus at most 24;
no arbitrary near-MaxUint64 helper access is executed. Four separate flag
controls execute fallback and simulated byte-swap branches; they are not native
big-endian evidence. Canonical byte semantics are always Wasm little endian.

Native amd64 and 386 proofs pass, and both child mutants must fail an explicit
runtime byte/trap assertion: first-load-check deletion and crossing a shrinking
header. Accessible spare backing makes these semantic failures, not crashes.
The helper model retains checked stores across barriers; no generic selector
is implemented or proved. The first 386 sandbox attempt fails with SIGSYS159
before testing and its escalated execution passes. Review finds a proof-only
canonical endian-oracle defect; it is fixed before freeze, with earlier
artifacts preserved and both native proofs repeated. No actual big-endian or
native arm64 execution is claimed.

### Conditions and complete outcomes

Freeze clean `20e33db` and 274 fingerprints after guest, host and adversarial
entry/proof/matrix review. Every fingerprint matches through both rounds.
Measure Go 1.26.8, Linux/amd64, CGO disabled, `GOAMD64=v1`, `-pgo=off`, default
GC/memory, Ryzen 7 5800HS (8 physical/16 logical cores), unpinned CPUs 0–15,
powersave governor and boost enabled; policy stays unchanged. No compilation,
tests, lint, fuzz, profiles or reviewer tools overlap timing. Unrelated system
activity cannot be excluded. Quality uses Go 1.27.1 and pinned lint 2.13.1;
Rust 1.97.0, Binaryen 133, wasm2go 0.4.16 and wazero 1.12.0 remain pinned.

Seventeen groups run 59 processes per pass: twelve original/corpus leaves
with baseline/diagnostic/copied-check/fresh-reference, one raw guest with three
roles, and four unchanged streams with two bracket roles. Seven alternating
500 ms passes plus seven reversed one-second passes yield 826 rows. Matched
leaves verify actual P1 (280 rows); streams verify actual P16 (112). Original
and raw layers retain initial framework P16 without an in-window metric (434);
the suffix does not prove timed processors. No cold/startup trials are run.
Exploratory p-values are unadjusted; nondetection is not equivalence.

The fresh independent reference uses an absent Cargo target, its own locked
Rust source/shim, std/panic_abort and hardener; all ten journaled commands and
48 one-iteration functional oracle leaves pass. All 56 selected source hashes
match before/after and are archived as bytes. Wasm/module/executable hashes
exactly reproduce the prior reference. ABI 2 borrowed inputs/background
contexts/four instances differ from ABI 3 owned checked inputs/test contexts/
one home; original batch/trace corpora also differ. Reference ratios are
contextual, not a pure facade cost. Preparation preserves unsupported-version
and inherited-cache probe failures plus a corrected nested-journal audit;
these are separate from successful build/oracle commands and qualified samples.

| Identity | SHA-256 |
| --- | --- |
| Unchanged production translated Go | `626550cafa323c490a6a2ec6b2b341656c40e223c7c84701e414078633dcc298` |
| Unchanged production executable | `74af29033f97ef277b9dd2708e7eaa7d0556c5486715866f5dfb8cfc715b3685` |
| Ignored diagnostic executable | `f05f9d1d462031ee8a3a072de881d9795294cea8935f915bf4644e0019af358a` |
| Copied-check executable | `ba0b42a1237af391ce0dd4e63e3b587b379c401d1c6c8cc98f3b4a2e44413395` |
| Fresh independent executable | `f8846dd93bd22b1adcf3b7762f685c8e96199a9d77a62f7d8ad9f1639a48bbea` |

All entries below are exact medians, screening → confirmation, seven samples
per role/round. Time change is diagnostic/unchanged minus one. Complete
copied-check/reference metrics, intervals, allocations and secondary comparisons
remain archived.

| Workload | Unchanged, screen → confirm | Diagnostic, screen → confirm | Time change, screen → confirm | p, screen / confirm |
| --- | ---: | ---: | ---: | --- |
| Original SQL | 2.167 → 2.147 µs | 2.118 → 2.120 µs | -2.26% → -1.26% | 0.010 / 0.001 |
| Original scalar | 87.69 → 87.64 ns | 87.51 → 87.43 ns | -0.21% → -0.24% | 0.620 / 0.901 |
| Original batch 1000 | 37.907 → 37.966 µs | 37.815 → 37.811 µs | -0.24% → -0.41% | 0.318 / 0.097 |
| Original trace 1000 | 2.577633 → 2.564982 ms | 2.561956 → 2.555424 ms | -0.61% → -0.37% | 0.535 / 0.456 |
| Varied scalar | 88.49 → 88.69 ns | 88.14 → 88.13 ns | -0.40% → -0.63% | 0.244 / 0.097 |
| Varied SQL | 2.676 → 2.671 µs | 2.665 → 2.667 µs | -0.41% → -0.15% | 0.012 / 0.221 |
| Negative bins | 88.70 → 88.08 ns | 88.05 → 88.05 ns | -0.73% → -0.03% | 0.165 / 0.804 |
| SQL holdout, P1 | 5.459 → 5.434 µs | 5.444 → 5.440 µs | -0.27% → +0.11% | 0.119 / 0.876 |
| Increasing scalar, P1 | 89.47 → 88.92 ns | 89.45 → 88.76 ns | -0.02% → -0.18% | 0.779 / 0.079 |
| Broad scalar, P1 | 88.77 → 88.92 ns | 89.18 → 89.01 ns | +0.46% → +0.10% | 0.033 / 0.259 |
| Repeated batch 1024, P1 | 38.992 → 38.970 µs | 38.658 → 38.723 µs | -0.86% → -0.63% | 0.007 / 0.097 |
| Broad batch 8192, P1 | 313.314 → 312.216 µs | 312.224 → 312.375 µs | -0.35% → +0.05% | 0.318 / 0.710 |
| Raw guest scalar | 53.04 → 53.12 ns | 52.82 → 52.86 ns | -0.41% → -0.49% | 0.002 / 0.026 |

Default scalar is undetected against both controls in both rounds; the
copied-check comparisons have p=.334/.876. Broad scalar loses in screening
versus unchanged (+0.46%, p=.033); confirmation versus unchanged is undetected
(+0.10%, p=.259), while confirmation versus copied-check loses (+0.24%, p=.041).
These are different comparators, not a repeated same-comparator regression.
Raw guest gains about 0.4–0.5% against both controls, but do not establish a
supported scalar latency win. Varied/negative/increasing scalar confirmation
gains versus copied-check alone do not rescue the default comparison.

Original SQL decreases 2.26%/1.26%, but only `fn176` store sites change;
`fn96` source/SSA stay identical and the restored-check control itself improves
confirmation SQL 0.65% (p=.004). Linking/placement effects remain unresolved;
no direct per-store-check or retained SQL speedup claim follows. Varied SQL and
repeated batch have screening gains that do not confirm; original batch, trace and broad batch have
no detected change. The SQL holdout and broad batch's upward confirmation
medians remain negatives. No allocation-count change occurs in the paired
Datadog roles.

### Unchanged streaming refresh and disposition

Streaming uses the **identical current executable in both roles**. Complete
New/Write/End/Close lifetimes use 16 KiB fixed/holdout corpora, nominal 64-byte
chunks and groups retained at 32; setup performs byte oracles outside timing.
Fixed streams own 16,392 B with 250 allocations; holdouts own 16,390 B with
268. Sixteen-home cases keep the independent stateless pool configured at one.
These are refreshed observed workload rates, not a candidate streaming effect
or universal throughput ceiling.

| P16 topology/corpus | Unchanged bracket times, screen / confirm | Observed confirmation writes/s, first / second bracket | Time change, screen / confirm | p, screen / confirm |
| --- | --- | ---: | ---: | --- |
| One home, fixed | 189.589/189.477 µs / 188.826/189.340 µs | 1,355,748 / 1,352,066 | -0.06% / +0.27% | .805 / .710 |
| 16 homes, fixed | 24.612/24.363 µs / 24.695/24.586 µs | 10,366,603 / 10,412,237 | -1.01% / -0.44% | .535 / .318 |
| One home, holdout | 227.965/227.784 µs / 227.017/228.203 µs | 1,513,103 / 1,505,239 | -0.08% / +0.52% | 1.000 / .318 |
| 16 homes, holdout | 32.607/32.652 µs / 32.670/32.526 µs | 10,514,094 / 10,560,824 | +0.14% / -0.44% | .902 / .902 |

The unchanged scalar baseline is 87.69/87.64 ns and SQL 2.167/2.147 µs.
Fresh independent scalar 55.30/55.29 ns supplies 110% limits 60.830/60.819 ns;
SQL 1.975/1.960 µs supplies limits 2.1725/2.1560 µs. SQL medians meet those
and the 2.2154 µs absolute limit, but the fresh SQL margins are only 5.5/9.0 ns,
without a durable margin claim. Scalar misses the fresh limits and the 55.44 ns
absolute limit. The rejected diagnostic does not close that gap. M1 stays
unaccepted.

Guest, host and adversarial outcome reviews agree with evidence-only retention.
After timing, all six gates (`check`, `race`, `rust`, `cross`, `smoke`, `fuzz`)
and `integration` pass; race enables CGO as required, separate from CGO-disabled
measurements. Two repeats rebuild all three proof packages/locks and regenerate
the runtime, reproducing all 61 fingerprints exactly. All 274 frozen inputs
still match after these gates. Production modules/locks and host checks remain
unchanged; the rejected overlay exists only in the reproducible evidence.

Park this exact scalar guard-reuse hypothesis. Next measure the existing-ABI
checked unit-reply call-shape/specialization ceiling with unchanged-call-shape
controls, current guest and all required validation. Its profile share is
not a predicted gain. A new typed-return ABI still requires a compatibility
specification and explicit operator approval before implementation. Keep the
retained contained-load/publication predicates narrow; this no-go does not
justify broader forwarding, header caching or floating-point approximation.

