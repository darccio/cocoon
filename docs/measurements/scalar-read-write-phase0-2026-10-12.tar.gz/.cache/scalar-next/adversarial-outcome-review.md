# Scalar adjacent-read/write phase0 outcome audit, 2026-10-12

Approve evidence-only no-go. Do not retain a generic hardener pass, implementation specification, public ABI/contract, or generated-module change for this hypothesis. The preregistered decision rule requires original supported scalar benefit against both untouched and copied-check controls in both rounds; it fails. No new timing, builds, tests, lint, profiles, or production mutation by this reviewer.

## Data/provenance audit

All826 raw rows follow the exact frozen17-group59-leaf plan over seven alternating500ms and seven reversed1s passes.118 role/round cells each contain seven samples; raw process one-leaf/PASS/EXIT0, argv/durations/iterations, serial UTC start/end, metrics and exact aliases verify. All summary samples/medians/deltas and118 derived normalization aliases match raw values. Timed interval11:35:48.275524→11:48:28.037887 UTC. All274 frozen source/binary fingerprints remain current. Decision timestamp11:27:31.125079 precedes freeze11:35:47.831089/timing. Actual-procs280P1/112P16;434 original/raw rows lack in-window metric (framework16/suffix not proof).168 matched memory rows have zero growth;126 report1,179,648 guest bytes and42 report1,441,792. No streaming/RSS/peak memory inference. All56 fresh reference selected source hashes match before/after/current.

Final seven gate logs end EXIT0. All15 gate/reproduction command records succeed and begin after timing completion; two proof/runtime rebuilds reproduce all61 current fingerprints exactly. These gates validate unchanged production and correctness context, not a rejected generic implementation. Same unchanged stream executable is used in both bracket roles; any rate difference is a same-binary control observation.

## Outcomes and interpretation

Original scalar87.69→87.51ns screening,87.64→87.43 confirmation:−.205/−.240%, baselinep=.620/.901, copied-checkp=.334/.876. No detected supported scalar gain in either comparison/round. Rawguest53.04→52.82/53.12→52.86:−.415/−.489%, baselinep=.002/.026, recheckp=.012/.026; this unsupported boundary is a tiny observed linked-probe benefit, not an additive/per-check saving or safe facade speedup.

Broad scalar screen88.77→89.18 (+.46%,p=.033) vs untouched; confirmation88.92→89.01 (+.10%,p=.259) undetected. Confirmation vs copied-check88.80→89.01 (+.24%,p=.041) is a separate detected negative; screen vs recheckp=.128. These do not constitute repeated detected regression against the same comparator. No-go already follows from failed original-scalar requirement; do not invent a repeated negative to strengthen it. Varied/negative/increasing confirmation-only benefits versus recheck do not rescue the declared rule.

Original SQL improves−2.26/−1.26% vs unchanged,p=.010/.001, but screen versus recheckp=.104 is undetected and recheck itself improves confirmationSQL−.65%,p=.004. fn96 source/SSA/code counts are untouched. Preserve possible linking/control effects; no causal removed-store-guard SQL gain or retained SQL optimization follows. VariedSQL and repeated batch screening gains do not confirm. Original batch/trace/broadbatch and holdout are undetected; SQLholdout+.11% and broadbatch+.05% confirmation directions stay explicit. Other expected-control/one-round effects remain in full raw comparisons.

Static fn176 code5462→5430B,frame128 unchanged,panic sites78→75,instructions1309→1302,optBounds74→71,regalloc37StoreReg/137LoadReg unchanged. fn96 and scalar export dumps/counts are unchanged across roles. This confirms demonstrated pattern survival, not a dynamic cost estimate. Fresh CPU cumulative/inline/profile categories overlap; profiled layer timings are diagnostic and evolving-state prefixes differ. No static spill/attainable-percentage claim.

Fresh reference110% scalar limits60.830/60.819ns; SQL2.1725/2.1560us. Untouched scalar87.69/87.64 still fails fresh and original55.44. SQL2.167/2.147 fits both fresh/original2.2154 median limits with only5.5/9ns fresh margin; not durable acceptance. Rejected probe cannot qualify production; M1 stays unaccepted.

## Draft/docs scope

Draft performance/roadmap correctly retain evidence only, keep public-contract approval requirement, report scalar/comparator/stream/control uncertainty, and nominate a separate existing-ABI checked unit-reply call-shape ceiling measurement. Canonical ABI3 descriptor/status/range/unit/fault/ownership/drain protections remain; typed-return ABI compatibility/approval precedes implementation. Existing publication/contained-load predicates remain narrow. No wider forwarding/header caching/math approximation or retiming selective subsets to rescue the result.

Two minor draft corrections requested before packing: trace row should use exact2.577633→2.564982ms untouched and2.561956→2.555424ms probe if table says exact medians; roadmap must say semantic mutants fail/detection passes, not that broken mutants pass. Root final prose/archive review will verify these corrections and all compressed member hashes. No source/performance blocker otherwise.

Root confirms both minor draft corrections applied before packing: full six-decimal trace medians and explicit semantic-mutant runtime failure wording. Outcome review is complete; approve evidence-only no-go. Await exact archive-byte/member validation.
