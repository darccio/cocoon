# Scalar phase-0 guest entry review

Read-only entry review after retained contained-load work at 20e33db. No
production edits, build, test, profile, benchmark, or public contract proposal
was made. Sources and existing matching Go 1.26.8 compiler outputs were read.
The parent will freshly profile the current binary before selecting a probe.

## One concrete candidate

Measure same-range read-to-write guard reuse for an adjacent numeric update.
The current scalar hot path contains:

```go
// examples/datadog/go/dd/internal/wasm/module.go:36211
t116 := math.Float64frombits(load64(m.memory, uint32(v3)))
store64(m.memory, uint32(v3), math.Float64bits(float64(t116+float64(1))))
```

Keep the checked load, both original address expressions, the original float
operation and explicit rounding, every memory read/write, and their order.
Only the immediately following store's identical-range guard is redundant if
the same base/header cannot change in between. This is a bounded structural
diagnostic hypothesis, not a predicted percentage or production qualification.

The zero-count update at 36080–36081 uses the same widened base plus 24 for both
load and store. The collapse accumulation at 36147–36148 uses the same local
uint32 base. These are source examples explaining the opportunity; payload
names, method numbers, and line numbers must not select a future generic pass.

## Existing machine-code evidence

The retained production round's matching `probe-fn176.asm` still contains:

- load endpoint comparison and branch at 0x630be0 / 0x630be3;
- floating-point addition at 0x630bfe;
- the store's repeated endpoint comparison and branch at 0x630c02 / 0x630c05;
- memory-length reload before the store and data-pointer reload at 0x630c07.

The corresponding optimized SSA dump has distinct load and store bounds
predicates `v3659` and `v3711`. Between them, inlined Float64frombits/Float64bits
produce local-address/Store memory nodes for their bit conversions; the store
reloads the Module slice header. Go has not removed this exact redundant
check in that frozen build. This does not establish which operation dominates
current samples, nor a causal gain from removing it. Fresh profile/SSA/ASM
should confirm the current binary before timing.

Simple integer load/store updates are weaker candidates: the existing fn176
assembly at source 36074–36075 already combines the arithmetic into a memory
SUBL after one check. Prefer measuring the floating-point pair that retains
the duplicate, rather than assuming every source-level load/store pair costs
two checks.

## Honest diagnostic controls

Use ignored, full-source-hash-pinned overlays only after fresh profiles. An
untouched control, copied store helper retaining its check, and the identical
helper with only the validated unsafe endpoint line removed can distinguish
the intended structural change from helper/name/layout effects. The initial
probe should not also cache headers, combine the load/store, modify arithmetic,
forward values, or change any facade/runtime path. Keep all function operands
and evaluation counts. Inspect the matching emitted branch counts and frames;
timing alone cannot isolate per-check cost or exclude placement effects.

At the narrowest scope, require adjacent statements, the same bound receiver
memory argument, same bound explicitly typed local base, same literal offset,
same width, a bound canonical checked load, and a validated bound store.
Reject assignment to the base, base escape/capture, an effectful value/address,
control flow, stores, imports, growth/header changes, or unproved calls in
between. Prove numeric conversions and the math bit conversion bindings as
pure; reject shadowing or a same-spelling replacement. The store value's
original evaluation remains before the store guard just as in the baseline.

A successful load endpoint check proves the same store bytes against logical
length, including native length below capacity. No widening-to-wrapping
normalization is permitted. Keep unsafe/unaligned/endian architecture handling,
nosplit, and checked fallback unchanged. Reuse the existing separately
allocated Module/header/backing ownership precondition; do not broaden it.

Executable proof should compare original Wasm and translated histories for
full bytes, exact numeric bits, traps and ordered import effects. Include
misalignment, short/exact logical length, spare capacity, high/wrapped
addresses, unchanged and reassigned bases, imports that shrink/replace the
header, growth, address/value effects, shadowed conversion functions, and
first-check deletion/import-crossing mutants. Original Count/protobuf and
invalid-input atomic-state histories are still required for the real payload.
Native amd64 and 386 execution are relevant; cross compilation alone is not.

## Payload and reference boundaries

Current authored `sketch_add` first calls validate_point and then DDSketch::add,
which performs the payload's own point validation. The current shim reports
argument/application errors with owned messages and publishes the checked ABI
reply. Its add_many owns a Rust Vec and validates the entire batch before
mutating state.

The independent cocoon-spike source uses the same local libdd-ddsketch crate
but its ABI2 scalar export directly calls add after slab lookup. Its borrowed
batch mutates sequentially and can partially complete before an invalid
element. It is an independent contextual reference, not a semantically
interchangeable current facade, and no code should be transplanted from it.
Matched successful Count/protobuf histories remain useful; error and ownership
paths require their own truthful comparisons.

## Routes already rejected or unsupported

- Do not revive exact-value bin caches: prior cache prototypes failed the
  repeated/mixed scalar requirement and regressed misses/holdouts. A cached
  mutable slot would additionally violate store/collapse lifetime semantics.
- Do not simplify the logarithm polynomial or its explicit float conversions.
  Matching compiler analysis found it register-resident without the assumed
  spills/helper calls. Reassociation/FMA or approximations require new exact
  floating-point proofs and are outside this structural diagnostic.
- The guarded floor/saturated-conversion rewrite did not establish a scalar
  gain and was removed. Preserve NaN/infinity/sign/rounding and operand effects.
- Duplicate shim/payload validation is a source semantic observation, not a
  generic translation predicate: eliminating it would require an interprocedural
  implication proof with all error/message/state/trap behavior, not a payload
  name special case.
- fn84 lookup result slots and fn176 stack publications cannot simply become
  Go return values: addresses may alias guest memory or escape through calls,
  and earlier guards/stores/first-trap prefixes must stay visible. A separate
  alias/effect proof is needed; current bounds reuse does not provide it.

The remaining structural pair could have a small ceiling and may fail end-to-end
scalar qualification. Measure it first, preserve all negatives and controls,
and keep M1 unaccepted until its independent requirements are met.
