from pathlib import Path
import subprocess,re,json,hashlib,datetime
root=Path.cwd();out=root/'.cache/scalar-next';obj=root/'.cache/translation-analysis/objdump';nm=root/'.cache/translation-analysis/nm';records=[];summary={}
for role in ('baseline','probe','recheck'):
 binary=out/(role+'.test');summary[role]={'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
 args=[str(nm),'-size',str(binary)];symbols=subprocess.check_output(args,text=True);(out/(role+'-symbols.txt')).write_text(symbols);records.append({'argv':args,'output':role+'-symbols.txt'})
 for fn in ('fn176','fn96','Xcocoon_sketch_add'):
  args=[str(obj),'-s',r'wasm.*\.'+fn+'$',str(binary)];asm=subprocess.check_output(args,text=True);assert asm.startswith('TEXT '),(role,fn);name=role+'-'+fn+'.asm';(out/name).write_text(asm);records.append({'argv':args,'output':name,'sha256':hashlib.sha256(asm.encode()).hexdigest()})
  rows=[x.split() for x in symbols.splitlines()];size=next(int(r[1]) for r in rows if len(r)==4 and r[3].endswith('.'+fn))
  frame=next((int(m[2],16) if m[1]=='SUBQ' else -int(m[2],16)) for line in asm.splitlines() if (m:=re.search(r'(SUBQ|ADDQ) \$(-?0x[0-9a-f]+), SP',line)))
  summary[role][fn]={'text_bytes':size,'frame_bytes':frame,'static_panic_bounds':len(re.findall(r'CALL runtime\.panicBounds',asm)),'instructions':sum(bool(re.search(r'\s0x[0-9a-f]+\s',line)) for line in asm.splitlines())}
(out/'machine-code-summary.json').write_text(json.dumps(summary,indent=2)+'\n');(out/'machine-code-provenance.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':records,'tools_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (obj,nm)},'scope':'Ordinary freshly compiled Go1.26.8 -pgo=off timing binaries inspected with existing Go1.27 diagnostic tools. Frames/static sites/instruction totals do not isolate causal per-check cost or spills.'},indent=2)+'\n');print(json.dumps(summary,indent=2))
