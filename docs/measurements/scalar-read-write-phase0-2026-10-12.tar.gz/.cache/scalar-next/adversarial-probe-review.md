# Applied pinned adjacent64 diagnostic review, 2026-10-12

Approve the current overlay source for proof/measurement preparation; no concrete semantic blocker found. Executable fixtures/mutants and final matrix/freeze remain to review. This is a whole-source-pinned diagnostic, not a generic production transform or public contract. No builds/tests/profiles/timing run by reviewer.

Reviewed SHA256 identities:

{
  "examples/datadog/go/dd/internal/wasm/module.go": "626550cafa323c490a6a2ec6b2b341656c40e223c7c84701e414078633dcc298",
  ".cache/scalar-next/prepare-probe.py": "10ebe41d3108314c348f6c3a67087a42a2d23565491676671ca4e3a93d929bdd",
  ".cache/scalar-next/probe-module.go": "a950ffaa5265b887ef57ae03ee06aa1ae20255a1eea4d9a9bfb2fea9d7f97db4",
  ".cache/scalar-next/recheck-module.go": "20b84ad1c3afa610ae3c485454564d280fb2deada6fa3b9d2df1b085516729f0",
  ".cache/scalar-next/probe-inventory.json": "c0395bf105277f75bd4f07b5152d1286afc737069a2c2a0891445cec8e4e2eb7"
}

prepare-probe.py checks exact source626550cafa323c490a6a2ec6b2b341656c40e223c7c84701e414078633dcc298 and absence of the private name. All three unique literal adjacent pairs are inside fn176 at t82/offset24,t99/basev1,t116/basev3. Full known source supplies explicit bindings/canonical helper/import/construction and distinct owned backing proof. No intervening call, store, header effect or rebinding exists: conversion/bitcasts and64-bit floating additions remain byte-identical. First loads/checks and all guest writes remain at original positions; addresses are unchanged zero-extendedu32 or widenedu32+24, with safe endpoint arithmetic and first logical-length guards before386 uintptr narrowing.

Independently reconstructed complete expected probe/recheck source from unchanged original plus exactlythree store-callee renames and copied helper: both byte-match generated overlays/inventory hashes. Copied helper is original nosplit store64 with only name changed; probe deletes exactly unsafe+7 endpoint check, recheck retains it. Endian handling, live unsafe write, checked unaligned fallback and input/value evaluation stay intact. No memory header cache, loaded value forwarding, math approximation, new guest export or runtime/ABI3 bypass. Regex/name/function specificity is permissible only as disclosed diagnostic provenance; no generic production binding proof follows.

Matrix must remove inherited production318/99/20 or before/after streaming claims: current streaming binary is unchanged refresh/bracket, not an affected candidate. Current ordinary baseline repro74af290… controls linking; new diagnostics cannot substitute historical binary gains. Preserve all raw/unknown/error/poison/growth/ownership/drain scope and noM1 conclusion. Pending executable boundary/mutant proof and actual plan audit before timing.
