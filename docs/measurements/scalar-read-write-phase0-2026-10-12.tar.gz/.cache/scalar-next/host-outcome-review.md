# Host outcome review: adjacent read/store guard phase 0

Read-only evidence audit, 2026-10-12. No builds, tests, lint, profiling, or
benchmarks executed by this review. Only this ignored note is written.

## Evidence/provenance

All 274 frozen byte hashes match at audit. The run contains 826 raw rows,
413 per round: seven alternating 500 ms samples and seven reversed-order 1 s
samples per leaf/role. Counts are baseline238/probe238/recheck182/reference168.
All five frozen ordinary binaries report Go1.26.8; builds use CGO0, GOAMD64v1
and PGO off. Timing environment is GOMAXPROCS16 with default GOGC/GOMEMLIMIT/
GODEBUG/GOEXPERIMENT, governor powersave and boost enabled. Frequency snapshots
are recorded, not a fixed-frequency guarantee. Pinned original production is
clean20e33db; the three selected DD read64/store64 pairs exist only in ignored
whole-source-pinned overlays. Recheck restores the copied helper's endpoint
guard without changing selected call inventory. No generic pass/public contract
is implemented or qualified.

There are 280 matched rows with actual-procs1 and 112 stream rows with
actual-procs16. The remaining 434 original/layer rows have no in-window metric;
their framework16 suffix and explicit runner environment must not be described
as an in-window measurement. Exploratory p-values are unadjusted; nondetection
is not equivalence. Full calibrated prefixes/state trajectories differ.

Fresh independent reference: ten build/test commands and 48 functional1x
oracle leaves pass; source snapshots contain56 unchanged fingerprints and match
the prior independent reference. Wasm/module/binary exactly reproduce the prior
hashes8bda5ff7…/5ff25314…/f8846dd9…. Its ABI2 borrowed-input, background-context,
four-instance facade and original batch/trace input differences remain context
limits; matching success corpora are not equivalent contracts. No Cocoon guest,
runtime, generator or hardener implementation is transplanted. Functional1x
rows are excluded from this826-row timing set.

## No-go decision

The preregistered rule requires repeatable complete scalar gains against BOTH
untouched and copied-check controls in BOTH rounds, with holdout protection.
Original scalar87.69→87.51 ns(-0.205%,p=.620) and87.64→87.43 ns(-0.240%,p=.901)
fails it. Probe versus recheck also has no detected original gain(.334/.876).
Broad scalar88.77→89.18 ns(+0.462%,p=.033) screening and88.92→89.01 ns(+0.101%,
p=.259) confirmation retains the negative direction; confirmation versus
recheck88.80→89.01 ns is+0.236%(p=.041). The two losses occur in different
comparisons, so neither should be called a repeated same-comparison loss, but
neither may be concealed by the original scalar nondetection.

Raw guest53.04→52.82 /53.12→52.86 ns improves0.415/0.489%(p=.002/.026) versus
untouched; versus recheck53.02/53.07 it improves0.377/0.396%(p=.012/.026).
This is a small demonstrated raw ceiling, not a supported facade benefit.
Varied scalar and negative bins have no detected primary gains in either round;
their confirmation gains versus recheck alone do not rescue promotion.

Original SQL2167→2118 /2147→2120 ns improves2.261/1.258%(p=.010/.001), but
recheck itself moves2148/2133 ns and its confirmation decrease is detected.
Probe versus recheck is undetected in screening(.104), detected in confirmation
(.004). SQL is not a reason to promote selected fn176 store checks: source,
helper/frame/linkage placement and alternate sketch callers confound such an
attribution. Varied SQL's screening-only gain and SQL holdout nondetection give
no repeated broad SQL claim. Trace moves-0.608/-0.373% versus baseline, both
undetected; confirmation versus recheck is+0.248%(.383).

Original batch-0.243/-0.408% is undetected. Repeated1024 batch's-0.857%(.007)
screening gain is not confirmed(-0.634%,.097); screening versus recheck is
detected(.017), confirmation is not(.301). Broad8192 batch-0.348/+0.051% is
undetected, including its negative confirmation direction. SQL holdout flips
-0.275/+0.110%, also undetected. Scalar/batch/raw controls allocate zero; SQL
and trace have one Go allocation in both production/diagnostic roles, with
reported B/op affected by calibration/setup amortization. No process memory or
RSS bound follows.

Retain evidence/docs only. No production specification/implementation is
justified by this scalar promotion rule; M1 remains unaccepted. The separate
existing-ABI ResultUnit call-shape/specialization measurement is a possible next
scope, not permission to skip ABI3 checks or implement typed-return contracts.

## Current baseline versus fresh M1 references

These are CURRENT untouched baseline medians, not the rejected probe's results.
Limits apply to the original scalar/SQL pair, not arbitrary matched holdouts.

| Scope | Baseline screen / confirm | Fresh reference screen / confirm | Reference×1.10 | Original absolute limit |
| --- | ---: | ---: | ---: | ---: |
| Scalar |87.69 /87.64 ns|55.30 /55.29 ns|60.830 /60.819 ns|55.44 ns|
| SQL |2.167 /2.147 µs|1.975 /1.960 µs|2.1725 /2.1560 µs|2.2154 µs|

Baseline scalar is58.571/58.510% above fresh reference and misses fresh limits
by26.860/26.821 ns, absolute by32.250/32.200 ns. SQL is9.722/9.541% above
reference and meets fresh median limits by ONLY5.5/9.0 ns; it meets absolute
limits by48.4/68.4 ns. This narrow session-specific SQL margin is not a durable
equivalence/acceptance guarantee. Scalar alone still prevents M1 acceptance.
For transparency rejected probe87.51/87.43 ns also fails both scalar limits;
its2.118/2.120 µs SQL does not replace current baseline acceptance.

## Unchanged stream bracket controls

All stream pairs execute the EXACT SAME frozen `stream.test` bytes; baseline
and probe labels identify scheduling brackets, not changed implementations.
The checked-role name `StandaloneHomesP` still uses standalone Write/End, not
typed Batch. All112 rows verify actualP16. Each operation is a complete
16 KiB body lifetime NewStream/Write/End/Close with nominal64-byte chunks and
finite Retain32 owned-output groups. Open/warmup/oracle preparation are outside
timing; construction, all writes, owned outputs, End and resource disposal are
inside. Fixed has256 actual writes+End; holdout uses varied widths, empty writes,
boundary matches and four corpora, averaging343.5 writes+End. Rates are raw
custom writes/s (excluding End), not estimates derived from rounded ns/op.

| Topology/corpus | Screen first / second bracket writes/s | Confirm first / second bracket writes/s | Go allocs/complete stream |
| --- | ---: | ---: | ---: |
|One home, Fixed|1,350,292 /1,351,084|1,355,748 /1,352,066|250|
|16 homes, Fixed|10,401,523 /10,507,816|10,366,603 /10,412,237|250|
|One home, Holdout|1,506,812 /1,508,004|1,513,103 /1,505,239|268|
|16 homes, Holdout|10,534,559 /10,520,016|10,514,094 /10,560,824|268|

| Topology/corpus | Screen first / second complete streams/s | Confirm first / second complete streams/s | Timed median B/op screen / confirm |
| --- | ---: | ---: | ---: |
|One home, Fixed|5,275 /5,278|5,296 /5,282|17,513 /17,507–17,508|
|16 homes, Fixed|40,631 /41,046|40,495 /40,673|17,496 /17,496|
|One home, Holdout|4,387 /4,390|4,405 /4,382|19,622 /19,615–19,616|
|16 homes, Holdout|30,668 /30,626|30,609 /30,745|19,604 /19,604|

Every fixed row observes257 outputs,16,392 owned B,9 groups per stream;
every holdout row344.5 outputs,16,390 owned B,11 groups. Allocation counts match
all raw rows, including zero-length writes and flush groups.16-home rows
explicitly report configured-homes16/configured-pool1. Default one-home paths
use Options{Instances:1}, ResourceInstances default1. The pool is independent
and not an extra resource lane. Per-home serialization and per-resource state
remain; sixteen parallel workers create finite live resources with bounded
retained groups. Initialized home count, logical guest memory, host heap/RSS
and scheduler fairness cannot be inferred from configured counts or rates.

No bracket timing change is detected for any stream in either round:
one-home Fixed p=.805/.710;16-home Fixed .535/.318;one-home Holdout1.000/.318;
16-home Holdout .902/.902. These are observed complete-lifetime throughput
rates on one machine, not strict serialization ceilings or new optimization
gains. Raw ranges preserve noise, and no unchanged-default-streaming latency
equivalence or regression resolution is established.
