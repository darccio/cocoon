import argparse
parser = argparse.ArgumentParser(description="Fresh independent spike rebuild; requires parent authorization.")
parser.add_argument("--execute-build", action="store_true")
args_gate = parser.parse_args()
if not args_gate.execute_build:
    parser.error("No build or oracle execution without --execute-build and parent authorization")
from pathlib import Path
import os,subprocess,json,hashlib
from recorded_command import JOURNAL, run, utc
from reference_snapshot import snapshot
root=Path.cwd();out=root/'.cache/scalar-next'
if (out/'reference-rust').exists():
 raise RuntimeError('Fresh independent rebuild requires an absent reference-rust target; do not reuse an earlier target silently')
if JOURNAL.exists() or (out/'reference-build.log').exists() or (out/'reference-prepare.log').exists():
 raise RuntimeError('Initial build evidence already exists; preserve it and use an explicitly reviewed retry path instead of overwriting it')
JOURNAL.open('x').close()
before=snapshot()
(out/'reference-source-before.json').write_text(json.dumps(before,indent=2)+'\n')
started=utc()
env=dict(os.environ,RUSTUP_TOOLCHAIN='1.97.0',CARGO_TARGET_DIR=str(out/'reference-rust'),RUSTC_BOOTSTRAP='1',CARGO_PROFILE_RELEASE_OPT_LEVEL='3',CARGO_TARGET_WASM32_UNKNOWN_UNKNOWN_RUSTFLAGS='-C link-arg=--max-memory=268435456',GOTOOLCHAIN='local',CGO_ENABLED='0',GOCACHE=str(root/'.cache/go'),GOFLAGS='-buildvcs=false')
env['GOAMD64']='v1'
env['PATH']=str(root/'.cache/binaryen/binaryen-version_133/bin')+':'+os.path.expanduser('~/.cargo/bin')+':'+env['PATH']
args=['cargo','build','--manifest-path','/home/dario/Code/cocoon-spike/shim/Cargo.toml','--locked','--release','-Zbuild-std=std,panic_abort','--target','wasm32-unknown-unknown']
with (out/'reference-build.log').open('x') as log:
 print('COMMAND',json.dumps(args),file=log,flush=True)
 run(args,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
run(['python3',str(out/'prepare-reference.py'),'--execute-build'],env=env,check=True)
after=snapshot()
(out/'reference-source-after.json').write_text(json.dumps(after,indent=2)+'\n')
assert before==after,'independent source changed during fresh rebuild'
previous=root/'.cache/contained-loads-production'
reproduction={name:hashlib.sha256((out/name).read_bytes()).hexdigest()==hashlib.sha256((previous/name).read_bytes()).hexdigest() for name in ['reference.final.wasm','reference-module.go','reference.test'] if (previous/name).exists()}
records=[json.loads(line) for line in JOURNAL.read_text().splitlines()]
(out/'reference-run-provenance.json').write_text(json.dumps({'started_utc':started,'completed_utc':utc(),'source_snapshot_unchanged':True,'source_snapshot':before,'commands':records,'previous_artifact_reproduction':reproduction,'environment':{key:env.get(key,'default') for key in ['RUSTUP_TOOLCHAIN','CARGO_TARGET_DIR','RUSTC_BOOTSTRAP','CARGO_PROFILE_RELEASE_OPT_LEVEL','CARGO_TARGET_WASM32_UNKNOWN_UNKNOWN_RUSTFLAGS','GOTOOLCHAIN','CGO_ENABLED','GOAMD64','GOCACHE','GOFLAGS','GOGC','GOMEMLIMIT','GODEBUG','GOEXPERIMENT','GOMAXPROCS']},'limits':'Actual command boundaries are journaled during execution; startup/oracle trials are excluded from qualified timings. Reference ABI2/original batch+trace workload differences remain contextual. Output hashes alone do not establish every transitive source identity.'},indent=2)+'\n')
