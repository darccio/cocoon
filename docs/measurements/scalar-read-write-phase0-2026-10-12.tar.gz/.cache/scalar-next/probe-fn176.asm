TEXT dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn176(SB) /home/dario/Code/cocoon/examples/datadog/go/dd/internal/wasm/module.go
  module.go:35694	0x62ff20		4c8d6424f8		LEAQ -0x8(SP), R12								
  module.go:35694	0x62ff25		4d3b6610		CMPQ R12, 0x10(R14)								
  module.go:35694	0x62ff29		0f86f7140000		JBE 0x631426									
  module.go:35694	0x62ff2f		55			PUSHQ BP									
  module.go:35694	0x62ff30		4889e5			MOVQ SP, BP									
  module.go:35694	0x62ff33		4883c480		ADDQ $-0x80, SP									
  module.go:35713	0x62ff37		4889842490000000	MOVQ AX, 0x90(SP)								
  module.go:35713	0x62ff3f		899c2498000000		MOVL BX, 0x98(SP)								
  module.go:35699	0x62ff46		8b5050			MOVL 0x50(AX), DX								
  module.go:35699	0x62ff49		89542434		MOVL DX, 0x34(SP)								
  module.go:35705	0x62ff4d		448d4ae0		LEAL -0x20(DX), R9								
  module.go:35706	0x62ff51		44894850		MOVL R9, 0x50(AX)								
  unsafe.go:35		0x62ff55		66490f7ec2		MOVQ X0, R10									
  module.go:35711	0x62ff5a		4d89d3			MOVQ R10, R11									
  module.go:35711	0x62ff5d		490fbaf23f		BTRQ $0x3f, R10									
  module.go:35713	0x62ff62		4d8d62ff		LEAQ -0x1(R10), R12								
  module.go:35733	0x62ff66		49bd000000000000f0ff	MOVQ $0xfff0000000000000, R13							
  module.go:35733	0x62ff70		4d01d5			ADDQ R10, R13									
  module.go:35710	0x62ff73		90			NOPL										
  module.go:35713	0x62ff74		49bfffffffffffff0f00	MOVQ $0xfffffffffffff, R15							
  module.go:35713	0x62ff7e		4d39e7			CMPQ R15, R12									
  module.go:35713	0x62ff81		410f97c4		SETA R12									
  module.go:35714	0x62ff85		450fb6e4		MOVZX R12, R12									
  module.go:35717	0x62ff89		4d85db			TESTQ R11, R11									
  module.go:35717	0x62ff8c		410f9cc7		SETL R15									
  module.go:35718	0x62ff90		450fb6ff		MOVZX R15, R15									
  module.go:35721	0x62ff94		4521fc			ANDL R15, R12									
  module.go:35705	0x62ff97		4489ce			MOVL R9, SI									
  module.go:35728	0x62ff9a		49b9000000000000f07f	MOVQ $0x7ff0000000000000, R9							
  module.go:35728	0x62ffa4		4d39d1			CMPQ R9, R10									
  module.go:35723	0x62ffa7		410f94c1		SETE R9										
  module.go:35728	0x62ffab		410f92c2		SETB R10									
  module.go:35724	0x62ffaf		450fb6c9		MOVZX R9, R9									
  module.go:35726	0x62ffb3		4509cc			ORL R9, R12									
  module.go:35729	0x62ffb6		450fb6ca		MOVZX R10, R9									
  module.go:35731	0x62ffba		4509cc			ORL R9, R12									
  module.go:35733	0x62ffbd		49b9000000000000e07f	MOVQ $0x7fe0000000000000, R9							
  module.go:35733	0x62ffc7		4d39e9			CMPQ R9, R13									
  module.go:35733	0x62ffca		410f97c1		SETA R9										
  module.go:35734	0x62ffce		450fb6c9		MOVZX R9, R9									
  module.go:35736	0x62ffd2		4521f9			ANDL R15, R9									
  module.go:35736	0x62ffd5		4509e1			ORL R12, R9									
  module.go:35736	0x62ffd8		0f1f840000000000	NOPL 0(AX)(AX*1)								
  module.go:35736	0x62ffe0		4585c9			TESTL R9, R9									
  module.go:35736	0x62ffe3		0f85e0080000		JNE 0x6308c9									
  module.go:35772	0x62ffe9		4c8b4838		MOVQ 0x38(AX), R9								
  module.go:35772	0x62ffed		4189ca			MOVL CX, R10									
  module.go:63009	0x62fff0		4d8d6237		LEAQ 0x37(R10), R12								
  module.go:63009	0x62fff4		4d39e1			CMPQ R9, R12									
  module.go:63009	0x62fff7		0f8621140000		JBE 0x63141e									
  module.go:35772	0x62fffd		4c8b4830		MOVQ 0x30(AX), R9								
  module.go:63010	0x630001		4f8b4c0a30		MOVQ 0x30(R10)(R9*1), R9							
  unsafe.go:41		0x630006		66490f6ec9		MOVQ R9, X1									
  module.go:35773	0x63000b		660f2ec8		UCOMISD X0, X1									
  module.go:35773	0x63000f		0f8779080000		JA 0x63088e									
  module.go:35774	0x630015		4c8b4838		MOVQ 0x38(AX), R9								
  module.go:63009	0x630019		4d8d622f		LEAQ 0x2f(R10), R12								
  module.go:63009	0x63001d		0f1f00			NOPL 0(AX)									
  module.go:63009	0x630020		4d39e1			CMPQ R9, R12									
  module.go:63009	0x630023		0f86f0130000		JBE 0x631419									
  module.go:35774	0x630029		4c8b4830		MOVQ 0x30(AX), R9								
  module.go:63010	0x63002d		4f8b4c0a28		MOVQ 0x28(R10)(R9*1), R9							
  module.go:35780	0x630032		49bc0000000000001000	MOVQ $0x10000000000000, R12							
  module.go:35780	0x63003c		0f1f4000		NOPL 0(AX)									
  module.go:35780	0x630040		4d39e3			CMPQ R11, R12									
  module.go:35780	0x630043		7c45			JL 0x63008a									
  module.go:35781	0x630045		49bcffffffffffffef7f	MOVQ $0x7fefffffffffffff, R12							
  module.go:35781	0x63004f		4d39e3			CMPQ R11, R12									
  module.go:35781	0x630052		0f87c2010000		JA 0x63021a									
  module.go:35785	0x630058		4d89dc			MOVQ R11, R12									
  module.go:35785	0x63005b		49c1eb20		SHRQ $0x20, R11									
  module.go:35785	0x63005f		90			NOPL										
  module.go:35786	0x630060		4981fb0000f03f		CMPQ R11, $0x3ff00000								
  module.go:35786	0x630067		7407			JE 0x630070									
  module.go:35786	0x630069		be01fcffff		MOVL $-0x3ff, SI								
  module.go:35789	0x63006e		eb7b			JMP 0x6300eb									
  module.go:35791	0x630070		4585e4			TESTL R12, R12									
  module.go:35791	0x630073		740d			JE 0x630082									
  module.go:35791	0x630075		41bb0000f03f		MOVL $0x3ff00000, R11								
  module.go:35791	0x63007b		be01fcffff		MOVL $-0x3ff, SI								
  module.go:35793	0x630080		eb69			JMP 0x6300eb									
  module.go:35793	0x630082		0f57c0			XORPS X0, X0									
  module.go:35796	0x630085		e990010000		JMP 0x63021a									
  module.go:35798	0x63008a		0f10c8			MOVUPS X0, X1									
  module.go:35798	0x63008d		f20f59c0		MULSD X0, X0									
  module.go:35798	0x630091		f20f1015c7202d00	MOVSD_XMM $f64.bff0000000000000(SB), X2						
  module.go:35798	0x630099		f20f5ed0		DIVSD X0, X2									
  module.go:35799	0x63009d		0f57db			XORPS X3, X3									
  module.go:35799	0x6300a0		660f2ecb		UCOMISD X3, X1									
  module.go:35799	0x6300a4		750a			JNE 0x6300b0									
  module.go:35799	0x6300a6		7a08			JP 0x6300b0									
  module.go:35795	0x6300a8		0f10c2			MOVUPS X2, X0									
  module.go:35801	0x6300ab		e96a010000		JMP 0x63021a									
  module.go:35717	0x6300b0		4d85db			TESTQ R11, R11									
  module.go:35803	0x6300b3		7d10			JGE 0x6300c5									
  module.go:35828	0x6300b5		f20f5cc9		SUBSD X1, X1									
  module.go:35828	0x6300b9		f20f5ecb		DIVSD X3, X1									
  module.go:35828	0x6300bd		0f10c1			MOVUPS X1, X0									
  module.go:35829	0x6300c0		e955010000		JMP 0x63021a									
  module.go:35807	0x6300c5		f20f101583202d00	MOVSD_XMM $f64.4350000000000000(SB), X2						
  module.go:35807	0x6300cd		f20f59d1		MULSD X1, X2									
  unsafe.go:35		0x6300d1		66490f7ed3		MOVQ X2, R11									
  module.go:35808	0x6300d6		4d89dc			MOVQ R11, R12									
  module.go:35808	0x6300d9		49c1ec20		SHRQ $0x20, R12									
  module.go:35808	0x6300dd		becbfbffff		MOVL $-0x435, SI								
  module.go:35792	0x6300e2		4c89df			MOVQ R11, DI									
  module.go:35792	0x6300e5		4d89e3			MOVQ R12, R11									
  module.go:35807	0x6300e8		4989fc			MOVQ DI, R12									
  module.go:35811	0x6300eb		4181c3625f0900		ADDL $0x95f62, R11								
  module.go:35812	0x6300f2		4589dd			MOVL R11, R13									
  module.go:35812	0x6300f5		41c1eb14		SHRL $0x14, R11									
  module.go:35812	0x6300f9		4101f3			ADDL SI, R11									
  module.go:35812	0x6300fc		0f57d2			XORPS X2, X2									
  module.go:35812	0x6300ff		f2410f2ad3		CVTSI2SDL R11, X2								
  module.go:35813	0x630104		f20f100d1c202d00	MOVSD_XMM $f64.3fe62e42fee00000(SB), X1						
  module.go:35813	0x63010c		f20f59ca		MULSD X2, X1									
  module.go:35814	0x630110		41bbffffffff		MOVL $-0x1, R11									
  module.go:35814	0x630116		4d21dc			ANDQ R11, R12									
  module.go:35814	0x630119		4181e5ffff0f00		ANDL $0xfffff, R13								
  module.go:35814	0x630120		458d9d9ea0e63f		LEAL 0x3fe6a09e(R13), R11							
  module.go:35814	0x630127		4589db			MOVL R11, R11									
  module.go:35814	0x63012a		49c1e320		SHLQ $0x20, R11									
  module.go:35814	0x63012e		4d09dc			ORQ R11, R12									
  module.go:35816	0x630131		f20f101daf1f2d00	MOVSD_XMM $f64.3dea39ef35793c76(SB), X3						
  module.go:35816	0x630139		f20f59d3		MULSD X3, X2									
  unsafe.go:41		0x63013d		66490f6edc		MOVQ R12, X3									
  module.go:35814	0x630142		f20f102516202d00	MOVSD_XMM $f64.bff0000000000000(SB), X4						
  module.go:35814	0x63014a		f20f58e3		ADDSD X3, X4									
  module.go:35817	0x63014e		f20f101d1a1e2d00	MOVSD_XMM $f64.4000000000000000(SB), X3						
  module.go:35817	0x630156		f20f58dc		ADDSD X4, X3									
  module.go:35817	0x63015a		0f10ec			MOVUPS X4, X5									
  module.go:35817	0x63015d		f20f5ee3		DIVSD X3, X4									
  module.go:35819	0x630161		f20f101d871e2d00	MOVSD_XMM $f64.3fe0000000000000(SB), X3						
  module.go:35819	0x630169		f20f59dd		MULSD X5, X3									
  module.go:35819	0x63016d		f20f59dd		MULSD X5, X3									
  module.go:35821	0x630171		0f10f4			MOVUPS X4, X6									
  module.go:35821	0x630174		f20f59e4		MULSD X4, X4									
  module.go:35822	0x630178		0f10fc			MOVUPS X4, X7									
  module.go:35822	0x63017b		f20f59e4		MULSD X4, X4									
  module.go:35823	0x63017f		f2440f1005701f2d00	MOVSD_XMM $f64.3fc39a09d078c69f(SB), X8						
  module.go:35823	0x630188		f2440f59c4		MULSD X4, X8									
  module.go:35823	0x63018d		f2440f100d721f2d00	MOVSD_XMM $f64.3fcc71c51d8e78af(SB), X9						
  module.go:35823	0x630196		f2450f58c8		ADDSD X8, X9									
  module.go:35823	0x63019b		f2440f59cc		MULSD X4, X9									
  module.go:35823	0x6301a0		f2440f10056f1f2d00	MOVSD_XMM $f64.3fd999999997fa04(SB), X8						
  module.go:35823	0x6301a9		f2450f58c1		ADDSD X9, X8									
  module.go:35823	0x6301ae		f2440f59c4		MULSD X4, X8									
  module.go:35823	0x6301b3		f2440f100d341f2d00	MOVSD_XMM $f64.3fc2f112df3e5244(SB), X9						
  module.go:35823	0x6301bc		f2440f59cc		MULSD X4, X9									
  module.go:35823	0x6301c1		f2440f1015361f2d00	MOVSD_XMM $f64.3fc7466496cb03de(SB), X10					
  module.go:35823	0x6301ca		f2450f58d1		ADDSD X9, X10									
  module.go:35823	0x6301cf		f2440f59d4		MULSD X4, X10									
  module.go:35823	0x6301d4		f2440f100d331f2d00	MOVSD_XMM $f64.3fd2492494229359(SB), X9						
  module.go:35823	0x6301dd		f2450f58ca		ADDSD X10, X9									
  module.go:35823	0x6301e2		f2440f59cc		MULSD X4, X9									
  module.go:35823	0x6301e7		f20f1025311f2d00	MOVSD_XMM $f64.3fe5555555555593(SB), X4						
  module.go:35823	0x6301ef		f2410f58e1		ADDSD X9, X4									
  module.go:35823	0x6301f4		f20f59e7		MULSD X7, X4									
  module.go:35823	0x6301f8		f2440f58c4		ADDSD X4, X8									
  module.go:35823	0x6301fd		f2440f58c3		ADDSD X3, X8									
  module.go:35823	0x630202		f2410f59f0		MULSD X8, X6									
  module.go:35823	0x630207		f20f58d6		ADDSD X6, X2									
  module.go:35823	0x63020b		f20f5cd3		SUBSD X3, X2									
  module.go:35823	0x63020f		f20f58d5		ADDSD X5, X2									
  module.go:35823	0x630213		f20f58d1		ADDSD X1, X2									
  module.go:35795	0x630217		0f10c2			MOVUPS X2, X0									
  module.go:35832	0x63021a		4c8b5838		MOVQ 0x38(AX), R11								
  module.go:63009	0x63021e		4d8d623f		LEAQ 0x3f(R10), R12								
  module.go:63009	0x630222		4d39e3			CMPQ R11, R12									
  module.go:63009	0x630225		0f86e9110000		JBE 0x631414									
  module.go:35713	0x63022b		898c249c000000		MOVL CX, 0x9c(SP)								
  module.go:35772	0x630232		4c89542478		MOVQ R10, 0x78(SP)								
  module.go:35832	0x630237		4c8b5830		MOVQ 0x30(AX), R11								
  unsafe.go:41		0x63023b		66490f6ec9		MOVQ R9, X1									
  module.go:35833	0x630240		f20f59c1		MULSD X1, X0									
  module.go:63010	0x630244		4f8b4c1a38		MOVQ 0x38(R10)(R11*1), R9							
  module.go:35832	0x630249		66490f6ec9		MOVQ R9, X1									
  module.go:35833	0x63024e		f20f58c1		ADDSD X1, X0									
  module.go:35833	0x630252		440fb60dbac76c00	MOVZX runtime.x86HasSSE41(SB), R9						
  module.go:35833	0x63025a		4585c9			TESTL R9, R9									
  module.go:35833	0x63025d		7408			JE 0x630267									
  module.go:35833	0x63025f		660f3a0bc001		ROUNDSD $0x1, X0, X0								
  module.go:35833	0x630265		eb24			JMP 0x63028b									
  module.go:35833	0x630267		e874afeaff		CALL math.Floor(SB)								
  module.go:35834	0x63026c		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:62984	0x630274		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:35702	0x63027b		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x63027f		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:62983	0x630286		4c8b542478		MOVQ 0x78(SP), R10								
  module.go:63074	0x63028b		f20f100d351f2d00	MOVSD_XMM $f64.c1e0000000000000(SB), X1						
  module.go:63074	0x630293		660f2ec8		UCOMISD X0, X1									
  module.go:63074	0x630297		7209			JB 0x6302a2									
  module.go:63074	0x630299		41b900000080		MOVL $-0x80000000, R9								
  module.go:63074	0x63029f		90			NOPL										
  module.go:35833	0x6302a0		eb2a			JMP 0x6302cc									
  module.go:63076	0x6302a2		f20f100d0e1f2d00	MOVSD_XMM $f64.41dfffffffc00000(SB), X1						
  module.go:63076	0x6302aa		660f2ec1		UCOMISD X1, X0									
  module.go:63076	0x6302ae		7208			JB 0x6302b8									
  module.go:63076	0x6302b0		41b9ffffff7f		MOVL $0x7fffffff, R9								
  module.go:35833	0x6302b6		eb14			JMP 0x6302cc									
  module.go:63078	0x6302b8		660f2ec0		UCOMISD X0, X0									
  module.go:63078	0x6302bc		7504			JNE 0x6302c2									
  module.go:63078	0x6302be		6690			NOPW										
  module.go:63078	0x6302c0		7b05			JNP 0x6302c7									
  module.go:63078	0x6302c2		4531c9			XORL R9, R9									
  module.go:35833	0x6302c5		eb05			JMP 0x6302cc									
  module.go:63081	0x6302c7		f2440f2cc8		CVTTSD2SIL X0, R9								
  module.go:35834	0x6302cc		4c8b5838		MOVQ 0x38(AX), R11								
  module.go:62983	0x6302d0		4d8d620f		LEAQ 0xf(R10), R12								
  module.go:62983	0x6302d4		4d39e3			CMPQ R11, R12									
  module.go:62983	0x6302d7		0f8632110000		JBE 0x63140f									
  module.go:62983	0x6302dd		4c89642470		MOVQ R12, 0x70(SP)								
  module.go:35834	0x6302e2		4c8b6830		MOVQ 0x30(AX), R13								
  module.go:62984	0x6302e6		478b7c2a0c		MOVL 0xc(R10)(R13*1), R15							
  module.go:35836	0x6302eb		4585ff			TESTL R15, R15									
  module.go:35836	0x6302ee		0f8471040000		JE 0x630765									
  module.go:62983	0x6302f4		498d7213		LEAQ 0x13(R10), SI								
  module.go:35863	0x6302f8		90			NOPL										
  module.go:35863	0x6302f9		0f1f8000000000		NOPL 0(AX)									
  module.go:62983	0x630300		4939f3			CMPQ R11, SI									
  module.go:62983	0x630303		0f8601110000		JBE 0x63140a									
  module.go:62983	0x630309		4889742468		MOVQ SI, 0x68(SP)								
  module.go:62984	0x63030e		438b7c2a10		MOVL 0x10(R10)(R13*1), DI							
  module.go:35865	0x630313		4139f9			CMPL R9, DI									
  module.go:35865	0x630316		0f8cec000000		JL 0x630408									
  module.go:35833	0x63031c		44894c2424		MOVL R9, 0x24(SP)								
  module.go:35867	0x630321		468d043f		LEAL 0(DI)(R15*1), R8								
  module.go:35866	0x630325		4129f9			SUBL DI, R9									
  module.go:35867	0x630328		8b542424		MOVL 0x24(SP), DX								
  module.go:35867	0x63032c		4439c2			CMPL DX, R8									
  module.go:35867	0x63032f		0f8cc7000000		JL 0x6303fc									
  module.go:62983	0x630335		4d8d4217		LEAQ 0x17(R10), R8								
  module.go:35871	0x630339		90			NOPL										
  module.go:35871	0x63033a		660f1f440000		NOPW 0(AX)(AX*1)								
  module.go:62983	0x630340		4d39c3			CMPQ R11, R8									
  module.go:62983	0x630343		0f86bc100000		JBE 0x631405									
  module.go:35870	0x630349		458d4101		LEAL 0x1(R9), R8								
  module.go:62984	0x63034d		438b5c1514		MOVL 0x14(R13)(R10*1), BX							
  module.go:35874	0x630352		4439c3			CMPL BX, R8									
  module.go:35874	0x630355		0f8d430b0000		JGE 0x630e9e									
  module.go:35877	0x63035b		4129d9			SUBL BX, R9									
  module.go:35877	0x63035e		458d4101		LEAL 0x1(R9), R8								
  module.go:35878	0x630362		4585c0			TESTL R8, R8									
  module.go:35878	0x630365		7e5e			JLE 0x6303c5									
  module.go:62983	0x630367		498d720b		LEAQ 0xb(R10), SI								
  module.go:35879	0x63036b		90			NOPL										
  module.go:62983	0x63036c		4939f3			CMPQ R11, SI									
  module.go:62983	0x63036f		0f8689100000		JBE 0x6313fe									
  module.go:35877	0x630375		44894c244c		MOVL R9, 0x4c(SP)								
  module.go:35885	0x63037a		448d1c1f		LEAL 0(DI)(BX*1), R11								
  module.go:63184	0x63037e		89cb			MOVL CX, BX									
  module.go:63184	0x630380		48895c2460		MOVQ BX, 0x60(SP)								
  module.go:35881	0x630385		90			NOPL										
  module.go:35883	0x630386		90			NOPL										
  module.go:62984	0x630387		438b4c1508		MOVL 0x8(R13)(R10*1), CX							
  module.go:63184	0x63038c		478b4c1504		MOVL 0x4(R13)(R10*1), R9							
  module.go:63184	0x630391		458b6c1d00		MOVL 0(R13)(BX*1), R13								
  module.go:35885	0x630396		4439da			CMPL DX, R11									
  module.go:35885	0x630399		750b			JNE 0x6303a6									
  module.go:36088	0x63039b		4589f8			MOVL R15, R8									
  module.go:36088	0x63039e		0f57c0			XORPS X0, X0									
  module.go:35888	0x6303a1		e93e0e0000		JMP 0x6311e4									
  module.go:62984	0x6303a6		897c2448		MOVL DI, 0x48(SP)								
  module.go:35891	0x6303aa		4589c3			MOVL R8, R11									
  module.go:35891	0x6303ad		4181e0feffff7f		ANDL $0x7ffffffe, R8								
  module.go:35952	0x6303b4		44897c2428		MOVL R15, 0x28(SP)								
  module.go:35952	0x6303b9		0f57c0			XORPS X0, X0									
  module.go:35952	0x6303bc		0f1f4000		NOPL 0(AX)									
  module.go:35894	0x6303c0		e99b0c0000		JMP 0x631060									
  module.go:62983	0x6303c5		4d8d4207		LEAQ 0x7(R10), R8								
  module.go:35957	0x6303c9		90			NOPL										
  module.go:62983	0x6303ca		4d39c3			CMPQ R11, R8									
  module.go:62983	0x6303cd		0f86770c0000		JBE 0x63104a									
  module.go:63184	0x6303d3		4189c8			MOVL CX, R8									
  module.go:62983	0x6303d6		498d5a0b		LEAQ 0xb(R10), BX								
  module.go:35959	0x6303da		90			NOPL										
  module.go:35961	0x6303db		90			NOPL										
  module.go:62984	0x6303dc		478b641504		MOVL 0x4(R13)(R10*1), R12							
  module.go:63184	0x6303e1		478b440500		MOVL 0(R13)(R8*1), R8								
  module.go:62983	0x6303e6		4939db			CMPQ R11, BX									
  module.go:62983	0x6303e9		0f86560c0000		JBE 0x631045									
  module.go:62984	0x6303ef		478b5c1508		MOVL 0x8(R13)(R10*1), R11							
  module.go:62984	0x6303f4		0f57c0			XORPS X0, X0									
  module.go:35964	0x6303f7		e9240a0000		JMP 0x630e20									
  module.go:35702	0x6303fc		8b542434		MOVL 0x34(SP), DX								
  module.go:36195	0x630400		4589f8			MOVL R15, R8									
  module.go:35868	0x630403		e962070000		JMP 0x630b6a									
  module.go:62983	0x630408		4d8d4217		LEAQ 0x17(R10), R8								
  module.go:35968	0x63040c		90			NOPL										
  module.go:62983	0x63040d		4d39c3			CMPQ R11, R8									
  module.go:62983	0x630410		0f86020a0000		JBE 0x630e18									
  module.go:35971	0x630416		4429cf			SUBL R9, DI									
  module.go:62984	0x630419		478b4c1514		MOVL 0x14(R13)(R10*1), R9							
  module.go:35969	0x63041e		4529f9			SUBL R15, R9									
  module.go:35973	0x630421		4439cf			CMPL DI, R9									
  module.go:35974	0x630424		410f47f9		CMOVA R9, DI									
  module.go:35977	0x630428		458d0c3f		LEAL 0(R15)(DI*1), R9								
  module.go:35978	0x63042c		4439cf			CMPL DI, R9									
  module.go:35973	0x63042f		0f87ba090000		JA 0x630def									
  module.go:62983	0x630435		4d8d4203		LEAQ 0x3(R10), R8								
  module.go:35979	0x630439		90			NOPL										
  module.go:35979	0x63043a		660f1f440000		NOPW 0(AX)(AX*1)								
  module.go:62983	0x630440		4d39c3			CMPQ R11, R8									
  module.go:62983	0x630443		0f86a1090000		JBE 0x630dea									
  module.go:35974	0x630449		897c242c		MOVL DI, 0x2c(SP)								
  module.go:62984	0x63044d		4189cb			MOVL CX, R11									
  module.go:62984	0x630450		4c895c2460		MOVQ R11, 0x60(SP)								
  module.go:62984	0x630455		478b6c1d00		MOVL 0(R13)(R11*1), R13								
  module.go:62984	0x63045a		660f1f440000		NOPW 0(AX)(AX*1)								
  module.go:35982	0x630460		4539cd			CMPL R13, R9									
  module.go:35982	0x630463		0f83e9020000		JAE 0x630752									
  module.go:35992	0x630469		4589e9			MOVL R13, R9									
  module.go:35992	0x63046c		4529fd			SUBL R15, R13									
  module.go:35994	0x63046f		4439ef			CMPL DI, R13									
  module.go:35994	0x630472		7708			JA 0x63047c									
  module.go:62984	0x630474		4589c8			MOVL R9, R8									
  module.go:35995	0x630477		e98e000000		JMP 0x63050a									
  module.go:62984	0x63047c		44894c2448		MOVL R9, 0x48(SP)								
  module.go:35997	0x630481		89cb			MOVL CX, BX									
  module.go:35997	0x630483		4489f9			MOVL R15, CX									
  module.go:35997	0x630486		be08000000		MOVL $0x8, SI									
  module.go:35997	0x63048b		4189f0			MOVL SI, R8									
  module.go:35997	0x63048e		e8cdbcf9ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn3(SB)	
  module.go:35998	0x630493		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:35998	0x63049b		488b5038		MOVQ 0x38(AX), DX								
  module.go:62983	0x63049f		4c8b4c2470		MOVQ 0x70(SP), R9								
  module.go:62983	0x6304a4		4c39ca			CMPQ DX, R9									
  module.go:62983	0x6304a7		0f8638090000		JBE 0x630de5									
  module.go:35998	0x6304ad		488b5030		MOVQ 0x30(AX), DX								
  module.go:62984	0x6304b1		488b742478		MOVQ 0x78(SP), SI								
  module.go:62984	0x6304b6		448b7c160c		MOVL 0xc(SI)(DX*1), R15								
  module.go:36001	0x6304bb		448b6c2448		MOVL 0x48(SP), R13								
  module.go:36001	0x6304c0		4589e8			MOVL R13, R8									
  module.go:36001	0x6304c3		4529f8			SUBL R15, R8									
  module.go:63184	0x6304c6		4c8b542460		MOVQ 0x60(SP), R10								
  module.go:63184	0x6304cb		418b1412		MOVL 0(R10)(DX*1), DX								
  module.go:36047	0x6304cf		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:63000	0x6304d6		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:62983	0x6304dd		488b742468		MOVQ 0x68(SP), SI								
  module.go:36042	0x6304e2		8b7c242c		MOVL 0x2c(SP), DI								
  module.go:62983	0x6304e6		4c8b542478		MOVQ 0x78(SP), R10								
  module.go:63184	0x6304eb		4c8b5c2460		MOVQ 0x60(SP), R11								
  module.go:63000	0x6304f0		4d89cc			MOVQ R9, R12									
  module.go:36002	0x6304f3		4189d1			MOVL DX, R9									
  module.go:35702	0x6304f6		8b542434		MOVL 0x34(SP), DX								
  module.go:36011	0x6304fa		4489c1			MOVL R8, CX									
  module.go:36011	0x6304fd		4589e8			MOVL R13, R8									
  module.go:36002	0x630500		4189cd			MOVL CX, R13									
  module.go:36047	0x630503		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:36006	0x63050a		488b5838		MOVQ 0x38(AX), BX								
  module.go:62983	0x63050e		4d8d5a0b		LEAQ 0xb(R10), R11								
  module.go:62983	0x630512		4c39db			CMPQ BX, R11									
  module.go:62983	0x630515		0f86c3080000		JBE 0x630dde									
  module.go:36006	0x63051b		488b5030		MOVQ 0x30(AX), DX								
  module.go:62984	0x63051f		418b4c1208		MOVL 0x8(R10)(DX*1), CX								
  module.go:36008	0x630524		4139cd			CMPL R13, CX									
  module.go:36008	0x630527		721f			JB 0x630548									
  module.go:36047	0x630529		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:35702	0x630530		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x630534		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:63184	0x63053b		4c8b5c2460		MOVQ 0x60(SP), R11								
  module.go:36041	0x630540		4589cd			MOVL R9, R13									
  module.go:36009	0x630543		e90a020000		JMP 0x630752									
  module.go:36002	0x630548		44897c2428		MOVL R15, 0x28(SP)								
  module.go:36002	0x63054d		44894c2438		MOVL R9, 0x38(SP)								
  module.go:36011	0x630552		4589c5			MOVL R8, R13									
  module.go:36011	0x630555		4129c8			SUBL CX, R8									
  module.go:36013	0x630558		4529c7			SUBL R8, R15									
  module.go:36019	0x63055b		4529e9			SUBL R13, R9									
  module.go:36015	0x63055e		4539c7			CMPL R15, R8									
  module.go:36015	0x630561		400f92c6		SETB SI										
  module.go:36016	0x630565		400fb6f6		MOVZX SI, SI									
  module.go:36019	0x630569		4539f9			CMPL R9, R15									
  module.go:36019	0x63056c		410f93c1		SETAE R9									
  module.go:36020	0x630570		450fb6c9		MOVZX R9, R9									
  module.go:36022	0x630574		4485ce			TESTL R9, SI									
  module.go:36022	0x630577		0f85fb000000		JNE 0x630678									
  module.go:36024	0x63057d		4489c6			MOVL R8, SI									
  module.go:36024	0x630580		41c1e003		SHLL $0x3, R8									
  module.go:36023	0x630584		448b4c2438		MOVL 0x38(SP), R9								
  module.go:36023	0x630589		4589cd			MOVL R9, R13									
  module.go:36023	0x63058c		4129f1			SUBL SI, R9									
  module.go:36025	0x63058f		4585c0			TESTL R8, R8									
  module.go:36025	0x630592		0f849e000000		JE 0x630636									
  module.go:62983	0x630598		498d7207		LEAQ 0x7(R10), SI								
  module.go:36026	0x63059c		90			NOPL										
  module.go:36026	0x63059d		0f1f00			NOPL 0(AX)									
  module.go:62983	0x6305a0		4839f3			CMPQ BX, SI									
  module.go:62983	0x6305a3		0f8630080000		JBE 0x630dd9									
  module.go:62984	0x6305a9		428b741204		MOVL 0x4(DX)(R10*1), SI								
  module.go:36028	0x6305ae		468d3cce		LEAL 0(SI)(R9*8), R15								
  module.go:36028	0x6305b2		8d34ce			LEAL 0(SI)(CX*8), SI								
  module.go:63109	0x6305b5		4589ff			MOVL R15, R15									
  module.go:63110	0x6305b8		89f6			MOVL SI, SI									
  module.go:63111	0x6305ba		4489c1			MOVL R8, CX									
  module.go:63111	0x6305bd		4e8d0439		LEAQ 0(CX)(R15*1), R8								
  module.go:63112	0x6305c1		4c8d2431		LEAQ 0(CX)(SI*1), R12								
  module.go:63113	0x6305c5		4c39c3			CMPQ BX, R8									
  module.go:63113	0x6305c8		0f8206080000		JB 0x630dd4									
  module.go:63113	0x6305ce		4d89f8			MOVQ R15, R8									
  module.go:63113	0x6305d1		4929df			SUBQ BX, R15									
  module.go:63113	0x6305d4		49c1ff3f		SARQ $0x3f, R15									
  module.go:63113	0x6305d8		4d21f8			ANDQ R15, R8									
  module.go:63113	0x6305db		4901d0			ADDQ DX, R8									
  module.go:63113	0x6305de		6690			NOPW										
  module.go:63113	0x6305e0		4c39e3			CMPQ BX, R12									
  module.go:63113	0x6305e3		0f82e6070000		JB 0x630dcf									
  module.go:63113	0x6305e9		4989f4			MOVQ SI, R12									
  module.go:63113	0x6305ec		4829de			SUBQ BX, SI									
  module.go:63113	0x6305ef		48c1fe3f		SARQ $0x3f, SI									
  module.go:63113	0x6305f3		4921f4			ANDQ SI, R12									
  module.go:63113	0x6305f6		498d1c14		LEAQ 0(R12)(DX*1), BX								
  module.go:63113	0x6305fa		4c39c3			CMPQ BX, R8									
  module.go:63113	0x6305fd		7432			JE 0x630631									
  module.go:62983	0x6305ff		4c895c2458		MOVQ R11, 0x58(SP)								
  module.go:36023	0x630604		44894c2430		MOVL R9, 0x30(SP)								
  module.go:63113	0x630609		4c89c0			MOVQ R8, AX									
  module.go:63113	0x63060c		e84f07e6ff		CALL runtime.memmove(SB)							
  module.go:36030	0x630611		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:36042	0x630619		8b7c242c		MOVL 0x2c(SP), DI								
  module.go:63001	0x63061d		448b4c2430		MOVL 0x30(SP), R9								
  module.go:63001	0x630622		4c8b542478		MOVQ 0x78(SP), R10								
  module.go:63000	0x630627		4c8b5c2458		MOVQ 0x58(SP), R11								
  module.go:36041	0x63062c		448b6c2438		MOVL 0x38(SP), R13								
  module.go:63000	0x630631		4c8b642470		MOVQ 0x70(SP), R12								
  module.go:36030	0x630636		488b5038		MOVQ 0x38(AX), DX								
  module.go:36030	0x63063a		660f1f440000		NOPW 0(AX)(AX*1)								
  module.go:63000	0x630640		4c39da			CMPQ DX, R11									
  module.go:63000	0x630643		0f8681070000		JBE 0x630dca									
  module.go:36030	0x630649		488b5030		MOVQ 0x30(AX), DX								
  module.go:63001	0x63064d		45894c1208		MOVL R9, 0x8(R10)(DX*1)								
  module.go:36047	0x630652		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:35702	0x630659		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x63065d		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:62983	0x630664		488b742468		MOVQ 0x68(SP), SI								
  module.go:63184	0x630669		4c8b5c2460		MOVQ 0x60(SP), R11								
  module.go:36041	0x63066e		448b7c2428		MOVL 0x28(SP), R15								
  module.go:36031	0x630673		e9da000000		JMP 0x630752									
  module.go:36033	0x630678		41c1e703		SHLL $0x3, R15									
  module.go:36033	0x63067c		0f1f4000		NOPL 0(AX)									
  module.go:36034	0x630680		4585ff			TESTL R15, R15									
  module.go:36034	0x630683		752b			JNE 0x6306b0									
  module.go:36047	0x630685		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:35702	0x63068c		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x630690		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:62983	0x630697		488b742468		MOVQ 0x68(SP), SI								
  module.go:63184	0x63069c		4c8b5c2460		MOVQ 0x60(SP), R11								
  module.go:36041	0x6306a1		448b7c2428		MOVL 0x28(SP), R15								
  module.go:36041	0x6306a6		448b6c2438		MOVL 0x38(SP), R13								
  module.go:36035	0x6306ab		e9a2000000		JMP 0x630752									
  module.go:62983	0x6306b0		498d7207		LEAQ 0x7(R10), SI								
  module.go:36037	0x6306b4		90			NOPL										
  module.go:62983	0x6306b5		4839f3			CMPQ BX, SI									
  module.go:62983	0x6306b8		0f8607070000		JBE 0x630dc5									
  module.go:62984	0x6306be		428b741204		MOVL 0x4(DX)(R10*1), SI								
  module.go:36039	0x6306c3		468d04ee		LEAL 0(SI)(R13*8), R8								
  module.go:63109	0x6306c7		4589c0			MOVL R8, R8									
  module.go:63111	0x6306ca		4489f9			MOVL R15, CX									
  module.go:63111	0x6306cd		4e8d0c01		LEAQ 0(CX)(R8*1), R9								
  module.go:63112	0x6306d1		4c8d1c31		LEAQ 0(CX)(SI*1), R11								
  module.go:63113	0x6306d5		4c39cb			CMPQ BX, R9									
  module.go:63113	0x6306d8		0f82e0060000		JB 0x630dbe									
  module.go:63113	0x6306de		4d89c1			MOVQ R8, R9									
  module.go:63113	0x6306e1		4929d8			SUBQ BX, R8									
  module.go:63113	0x6306e4		49c1f83f		SARQ $0x3f, R8									
  module.go:63113	0x6306e8		4d21c1			ANDQ R8, R9									
  module.go:63113	0x6306eb		4d8d0411		LEAQ 0(R9)(DX*1), R8								
  module.go:63113	0x6306ef		4c39db			CMPQ BX, R11									
  module.go:63113	0x6306f2		0f82c1060000		JB 0x630db9									
  module.go:63113	0x6306f8		4189f1			MOVL SI, R9									
  module.go:63113	0x6306fb		4829de			SUBQ BX, SI									
  module.go:63113	0x6306fe		48c1fe3f		SARQ $0x3f, SI									
  module.go:63113	0x630702		4c21ce			ANDQ R9, SI									
  module.go:63113	0x630705		488d1c16		LEAQ 0(SI)(DX*1), BX								
  module.go:63113	0x630709		4c39c3			CMPQ BX, R8									
  module.go:63113	0x63070c		741e			JE 0x63072c									
  module.go:63113	0x63070e		4c89c0			MOVQ R8, AX									
  module.go:63113	0x630711		e84a06e6ff		CALL runtime.memmove(SB)							
  module.go:36055	0x630716		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:36042	0x63071e		8b7c242c		MOVL 0x2c(SP), DI								
  module.go:63001	0x630722		4c8b542478		MOVQ 0x78(SP), R10								
  module.go:63000	0x630727		4c8b642470		MOVQ 0x70(SP), R12								
  module.go:36047	0x63072c		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:35702	0x630733		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x630737		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:62983	0x63073e		488b742468		MOVQ 0x68(SP), SI								
  module.go:63184	0x630743		4c8b5c2460		MOVQ 0x60(SP), R11								
  module.go:36041	0x630748		448b7c2428		MOVL 0x28(SP), R15								
  module.go:36041	0x63074d		448b6c2438		MOVL 0x38(SP), R13								
  module.go:36042	0x630752		85ff			TESTL DI, DI									
  module.go:36042	0x630754		0f84f5040000		JE 0x630c4f									
  module.go:35974	0x63075a		4189f8			MOVL DI, R8									
  module.go:35974	0x63075d		0f1f00			NOPL 0(AX)									
  module.go:36044	0x630760		e922050000		JMP 0x630c87									
  module.go:63000	0x630765		498d7213		LEAQ 0x13(R10), SI								
  module.go:35837	0x630769		90			NOPL										
  module.go:63000	0x63076a		4939f3			CMPQ R11, SI									
  module.go:63000	0x63076d		0f86d7040000		JBE 0x630c4a									
  module.go:63001	0x630773		47894c2a10		MOVL R9, 0x10(R10)(R13*1)							
  module.go:35839	0x630778		488b7038		MOVQ 0x38(AX), SI								
  module.go:62983	0x63077c		4d8d4203		LEAQ 0x3(R10), R8								
  module.go:62983	0x630780		4c39c6			CMPQ SI, R8									
  module.go:62983	0x630783		0f86bc040000		JBE 0x630c45									
  module.go:35839	0x630789		488b7030		MOVQ 0x30(AX), SI								
  module.go:62984	0x63078d		4189c9			MOVL CX, R9									
  module.go:62984	0x630790		418b3431		MOVL 0(R9)(SI*1), SI								
  module.go:35841	0x630794		85f6			TESTL SI, SI									
  module.go:35841	0x630796		7404			JE 0x63079c									
  module.go:35841	0x630798		31ff			XORL DI, DI									
  module.go:35841	0x63079a		eb71			JMP 0x63080d									
  module.go:62983	0x63079c		4c89442468		MOVQ R8, 0x68(SP)								
  module.go:62984	0x6307a1		4c894c2460		MOVQ R9, 0x60(SP)								
  module.go:35842	0x6307a6		89cb			MOVL CX, BX									
  module.go:35842	0x6307a8		e8d340fbff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn88(SB)	
  module.go:35843	0x6307ad		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:35843	0x6307b5		488b4838		MOVQ 0x38(AX), CX								
  module.go:62983	0x6307b9		488b542468		MOVQ 0x68(SP), DX								
  module.go:62983	0x6307be		6690			NOPW										
  module.go:62983	0x6307c0		4839d1			CMPQ CX, DX									
  module.go:62983	0x6307c3		0f8675040000		JBE 0x630c3e									
  module.go:35843	0x6307c9		488b5030		MOVQ 0x30(AX), DX								
  module.go:62984	0x6307cd		488b742460		MOVQ 0x60(SP), SI								
  module.go:62984	0x6307d2		8b3416			MOVL 0(SI)(DX*1), SI								
  module.go:62983	0x6307d5		4c8b442470		MOVQ 0x70(SP), R8								
  module.go:62983	0x6307da		660f1f440000		NOPW 0(AX)(AX*1)								
  module.go:62983	0x6307e0		4c39c1			CMPQ CX, R8									
  module.go:62983	0x6307e3		0f8650040000		JBE 0x630c39									
  module.go:62984	0x6307e9		4c8b4c2478		MOVQ 0x78(SP), R9								
  module.go:62984	0x6307ee		418b54110c		MOVL 0xc(R9)(DX*1), DX								
  module.go:63184	0x6307f3		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:63000	0x6307fa		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:63001	0x630801		4d89ca			MOVQ R9, R10									
  module.go:63000	0x630804		4d89c4			MOVQ R8, R12									
  module.go:35845	0x630807		89d7			MOVL DX, DI									
  module.go:35702	0x630809		8b542434		MOVL 0x34(SP), DX								
  module.go:35850	0x63080d		4c8b4038		MOVQ 0x38(AX), R8								
  module.go:63000	0x630811		4d39e0			CMPQ R8, R12									
  module.go:63000	0x630814		0f861a040000		JBE 0x630c34									
  module.go:35849	0x63081a		448d4701		LEAL 0x1(DI), R8								
  module.go:35850	0x63081e		4c8b4830		MOVQ 0x30(AX), R9								
  module.go:63001	0x630822		4789440a0c		MOVL R8, 0xc(R10)(R9*1)								
  module.go:35851	0x630827		4c8b4838		MOVQ 0x38(AX), R9								
  module.go:62983	0x63082b		4d8d5a07		LEAQ 0x7(R10), R11								
  module.go:62983	0x63082f		4d39d9			CMPQ R9, R11									
  module.go:62983	0x630832		0f86f7030000		JBE 0x630c2f									
  module.go:35851	0x630838		4c8b5830		MOVQ 0x30(AX), R11								
  module.go:62983	0x63083c		4d8d620b		LEAQ 0xb(R10), R12								
  module.go:35852	0x630840		90			NOPL										
  module.go:62984	0x630841		478b6c1a04		MOVL 0x4(R10)(R11*1), R13							
  module.go:62983	0x630846		4d39e1			CMPQ R9, R12									
  module.go:62983	0x630849		0f86db030000		JBE 0x630c2a									
  module.go:62984	0x63084f		478b641a08		MOVL 0x8(R10)(R11*1), R12							
  module.go:35853	0x630854		4101fc			ADDL DI, R12									
  module.go:35856	0x630857		4439e6			CMPL SI, R12									
  module.go:35857	0x63085a		41bf00000000		MOVL $0x0, R15									
  module.go:35857	0x630860		440f46fe		CMOVBE SI, R15									
  module.go:35859	0x630864		4529fc			SUBL R15, R12									
  module.go:35859	0x630867		438d74e500		LEAL 0(R13)(R12*8), SI								
  module.go:63026	0x63086c		4189f4			MOVL SI, R12									
  module.go:63026	0x63086f		4983c407		ADDQ $0x7, R12									
  module.go:63026	0x630873		4d39e1			CMPQ R9, R12									
  module.go:35856	0x630876		0f86a9030000		JBE 0x630c25									
  module.go:63027	0x63087c		89f6			MOVL SI, SI									
  module.go:63027	0x63087e		49c7043300000000	MOVQ $0x0, 0(R11)(SI*1)								
  module.go:63027	0x630886		4531c9			XORL R9, R9									
  module.go:35860	0x630889		e9dc020000		JMP 0x630b6a									
  module.go:36080	0x63088e		488b7038		MOVQ 0x38(AX), SI								
  module.go:63009	0x630892		498d7a1f		LEAQ 0x1f(R10), DI								
  module.go:63009	0x630896		4839fe			CMPQ SI, DI									
  module.go:63009	0x630899		0f86c6020000		JBE 0x630b65									
  module.go:36080	0x63089f		488b7030		MOVQ 0x30(AX), SI								
  module.go:36081	0x6308a3		488b7830		MOVQ 0x30(AX), DI								
  module.go:63010	0x6308a7		498b743218		MOVQ 0x18(R10)(SI*1), SI							
  unsafe.go:41		0x6308ac		66480f6ec6		MOVQ SI, X0									
  module.go:36081	0x6308b1		f20f100daf162d00	MOVSD_XMM $f64.3ff0000000000000(SB), X1						
  module.go:36081	0x6308b9		f20f58c8		ADDSD X0, X1									
  module.go:63200	0x6308bd		f2410f114c3a18		MOVSD_XMM X1, 0x18(R10)(DI*1)							
  module.go:36082	0x6308c4		e98f020000		JMP 0x630b58									
  module.go:35705	0x6308c9		8974244c		MOVL SI, 0x4c(SP)								
  module.go:35739	0x6308cd		bb10000000		MOVL $0x10, BX									
  module.go:35739	0x6308d2		b901000000		MOVL $0x1, CX									
  module.go:35739	0x6308d7		e884baf9ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn4(SB)	
  module.go:35739	0x6308dc		0f1f4000		NOPL 0(AX)									
  module.go:35741	0x6308e0		85c0			TESTL AX, AX									
  module.go:35741	0x6308e2		0f8442020000		JE 0x630b2a									
  module.go:35742	0x6308e8		488b942490000000	MOVQ 0x90(SP), DX								
  module.go:35742	0x6308f0		488b7238		MOVQ 0x38(DX), SI								
  module.go:63109	0x6308f4		89c7			MOVL AX, DI									
  module.go:63111	0x6308f6		4c8d4710		LEAQ 0x10(DI), R8								
  module.go:63111	0x6308fa		660f1f440000		NOPW 0(AX)(AX*1)								
  module.go:63113	0x630900		4c39c6			CMPQ SI, R8									
  module.go:63113	0x630903		0f821c020000		JB 0x630b25									
  module.go:35742	0x630909		4c8b4230		MOVQ 0x30(DX), R8								
  module.go:63113	0x63090d		4c01c7			ADDQ R8, DI									
  module.go:63113	0x630910		4881fe718e1000		CMPQ SI, $0x108e71								
  module.go:63113	0x630917		0f82fc010000		JB 0x630b19									
  module.go:35739	0x63091d		89442428		MOVL AX, 0x28(SP)								
  module.go:63113	0x630921		498db0618e1000		LEAQ 0x108e61(R8), SI								
  module.go:63113	0x630928		4839fe			CMPQ SI, DI									
  module.go:63113	0x63092b		740b			JE 0x630938									
  module.go:63113	0x63092d		410f1080618e1000	MOVUPS 0x108e61(R8), X0								
  module.go:63113	0x630935		0f1107			MOVUPS X0, 0(DI)								
  module.go:35743	0x630938		4889d0			MOVQ DX, AX									
  module.go:35743	0x63093b		bb0c000000		MOVL $0xc, BX									
  module.go:35743	0x630940		b904000000		MOVL $0x4, CX									
  module.go:35743	0x630945		e816baf9ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn4(SB)	
  module.go:35745	0x63094a		85c0			TESTL AX, AX									
  module.go:35745	0x63094c		0f849d010000		JE 0x630aef									
  module.go:35749	0x630952		488b8c2490000000	MOVQ 0x90(SP), CX								
  module.go:35749	0x63095a		488b5138		MOVQ 0x38(CX), DX								
  module.go:35749	0x63095e		89c3			MOVL AX, BX									
  module.go:63000	0x630960		488d730b		LEAQ 0xb(BX), SI								
  module.go:63000	0x630964		4839f2			CMPQ DX, SI									
  module.go:63000	0x630967		0f867d010000		JBE 0x630aea									
  module.go:35749	0x63096d		488b5130		MOVQ 0x30(CX), DX								
  module.go:63001	0x630971		c744130810000000	MOVL $0x10, 0x8(BX)(DX*1)							
  module.go:35750	0x630979		488b5138		MOVQ 0x38(CX), DX								
  module.go:63000	0x63097d		488d7307		LEAQ 0x7(BX), SI								
  module.go:63000	0x630981		4839f2			CMPQ DX, SI									
  module.go:63000	0x630984		0f865b010000		JBE 0x630ae5									
  module.go:35750	0x63098a		488b5130		MOVQ 0x30(CX), DX								
  module.go:63001	0x63098e		8b742428		MOVL 0x28(SP), SI								
  module.go:63001	0x630992		89741304		MOVL SI, 0x4(BX)(DX*1)								
  module.go:35751	0x630996		488b5138		MOVQ 0x38(CX), DX								
  module.go:63000	0x63099a		4883c303		ADDQ $0x3, BX									
  module.go:63000	0x63099e		6690			NOPW										
  module.go:63000	0x6309a0		4839da			CMPQ DX, BX									
  module.go:63000	0x6309a3		0f8635010000		JBE 0x630ade									
  module.go:35737	0x6309a9		8b542434		MOVL 0x34(SP), DX								
  module.go:35737	0x6309ad		8d5ae8			LEAL -0x18(DX), BX								
  module.go:35751	0x6309b0		488b7130		MOVQ 0x30(CX), SI								
  module.go:35752	0x6309b4		89df			MOVL BX, DI									
  module.go:63001	0x6309b6		4189c0			MOVL AX, R8									
  module.go:63001	0x6309b9		42c7040610000000	MOVL $0x10, 0(SI)(R8*1)								
  module.go:35752	0x6309c1		488b7138		MOVQ 0x38(CX), SI								
  module.go:63000	0x6309c5		4c8d4707		LEAQ 0x7(DI), R8								
  module.go:63000	0x6309c9		4c39c6			CMPQ SI, R8									
  module.go:63000	0x6309cc		0f8607010000		JBE 0x630ad9									
  module.go:35752	0x6309d2		488b7130		MOVQ 0x30(CX), SI								
  module.go:63001	0x6309d6		c744370490931000	MOVL $0x109390, 0x4(DI)(SI*1)							
  module.go:35753	0x6309de		488b7138		MOVQ 0x38(CX), SI								
  module.go:63000	0x6309e2		4883c703		ADDQ $0x3, DI									
  module.go:63000	0x6309e6		4839fe			CMPQ SI, DI									
  module.go:63000	0x6309e9		0f86e5000000		JBE 0x630ad4									
  module.go:35753	0x6309ef		488b7130		MOVQ 0x30(CX), SI								
  module.go:35755	0x6309f3		8b7c244c		MOVL 0x4c(SP), DI								
  module.go:35755	0x6309f7		89ff			MOVL DI, DI									
  module.go:63001	0x6309f9		89db			MOVL BX, BX									
  module.go:63001	0x6309fb		89041e			MOVL AX, 0(SI)(BX*1)								
  module.go:35755	0x6309fe		488b4138		MOVQ 0x38(CX), AX								
  module.go:62983	0x630a02		488d5f0f		LEAQ 0xf(DI), BX								
  module.go:62983	0x630a06		4839d8			CMPQ AX, BX									
  module.go:62983	0x630a09		0f86c0000000		JBE 0x630acf									
  module.go:35755	0x630a0f		488b4130		MOVQ 0x30(CX), AX								
  module.go:62984	0x630a13		8b5c070c		MOVL 0xc(DI)(AX*1), BX								
  module.go:63184	0x630a17		8b440708		MOVL 0x8(DI)(AX*1), AX								
  module.go:35702	0x630a1b		8d72f8			LEAL -0x8(DX), SI								
  module.go:36219	0x630a1e		488b7938		MOVQ 0x38(CX), DI								
  module.go:36220	0x630a22		4189f0			MOVL SI, R8									
  module.go:63000	0x630a25		4d8d4807		LEAQ 0x7(R8), R9								
  module.go:63000	0x630a29		4c39cf			CMPQ DI, R9									
  module.go:63000	0x630a2c		0f8698000000		JBE 0x630aca									
  module.go:36219	0x630a32		4c8b4930		MOVQ 0x30(CX), R9								
  module.go:63001	0x630a36		43895c0804		MOVL BX, 0x4(R8)(R9*1)								
  module.go:63000	0x630a3b		498d5803		LEAQ 0x3(R8), BX								
  module.go:36221	0x630a3f		90			NOPL										
  module.go:63000	0x630a40		4839df			CMPQ DI, BX									
  module.go:63000	0x630a43		0f867c000000		JBE 0x630ac5									
  module.go:35700	0x630a49		8d5af0			LEAL -0x10(DX), BX								
  module.go:36226	0x630a4c		89df			MOVL BX, DI									
  module.go:63001	0x630a4e		89f6			MOVL SI, SI									
  module.go:63001	0x630a50		41890431		MOVL AX, 0(R9)(SI*1)								
  module.go:36222	0x630a54		895950			MOVL BX, 0x50(CX)								
  module.go:36226	0x630a57		488b4138		MOVQ 0x38(CX), AX								
  module.go:62983	0x630a5b		488d5f0f		LEAQ 0xf(DI), BX								
  module.go:62983	0x630a5f		90			NOPL										
  module.go:62983	0x630a60		4839d8			CMPQ AX, BX									
  module.go:62983	0x630a63		7657			JBE 0x630abc									
  module.go:36226	0x630a65		488b5930		MOVQ 0x30(CX), BX								
  module.go:62983	0x630a69		488d770b		LEAQ 0xb(DI), SI								
  module.go:36229	0x630a6d		90			NOPL										
  module.go:62984	0x630a6e		448b441f0c		MOVL 0xc(DI)(BX*1), R8								
  module.go:62983	0x630a73		4839f0			CMPQ AX, SI									
  module.go:62983	0x630a76		763f			JBE 0x630ab7									
  module.go:63000	0x630a78		8bb42498000000		MOVL 0x98(SP), SI								
  module.go:63000	0x630a7f		4189f1			MOVL SI, R9									
  module.go:63000	0x630a82		4d8d5103		LEAQ 0x3(R9), R10								
  module.go:36230	0x630a86		90			NOPL										
  module.go:62984	0x630a87		8b7c1f08		MOVL 0x8(DI)(BX*1), DI								
  module.go:63000	0x630a8b		4c39d0			CMPQ AX, R10									
  module.go:63000	0x630a8e		7622			JBE 0x630ab2									
  module.go:63001	0x630a90		89f6			MOVL SI, SI									
  module.go:63001	0x630a92		893c33			MOVL DI, 0(BX)(SI*1)								
  module.go:63000	0x630a95		498d7107		LEAQ 0x7(R9), SI								
  module.go:36231	0x630a99		90			NOPL										
  module.go:63000	0x630a9a		4839f0			CMPQ AX, SI									
  module.go:63000	0x630a9d		760e			JBE 0x630aad									
  module.go:63001	0x630a9f		4589441904		MOVL R8, 0x4(R9)(BX*1)								
  module.go:36232	0x630aa4		895150			MOVL DX, 0x50(CX)								
  module.go:36233	0x630aa7		4883ec80		SUBQ $-0x80, SP									
  module.go:36233	0x630aab		5d			POPQ BP										
  module.go:36233	0x630aac		c3			RET										
  module.go:63000	0x630aad		e80effe5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630ab2		e809ffe5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630ab7		e804ffe5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630abc		0f1f4000		NOPL 0(AX)									
  module.go:62983	0x630ac0		e8fbfee5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630ac5		e8f6fee5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630aca		e8f1fee5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630acf		e8ecfee5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630ad4		e8e7fee5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630ad9		e8e2fee5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630ade		6690			NOPW										
  module.go:63000	0x630ae0		e8dbfee5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630ae5		e8d6fee5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630aea		e8d1fee5ff		CALL runtime.panicBounds(SB)							
  module.go:35746	0x630aef		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:35746	0x630af7		bb04000000		MOVL $0x4, BX									
  module.go:35746	0x630afc		b90c000000		MOVL $0xc, CX									
  module.go:35746	0x630b01		e83a3cfaff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn35(SB)	
  module.go:35747	0x630b06		488d05139f2100		LEAQ 0x219f13(IP), AX								
  module.go:35747	0x630b0d		488d1ddc172d00		LEAQ 0x2d17dc(IP), BX								
  module.go:35747	0x630b14		e8c77ce5ff		CALL runtime.gopanic(SB)							
  module.go:63113	0x630b19		48c7c0718e1000		MOVQ $0x108e71, AX								
  module.go:63113	0x630b20		e89bfee5ff		CALL runtime.panicBounds(SB)							
  module.go:63113	0x630b25		e896fee5ff		CALL runtime.panicBounds(SB)							
  module.go:35762	0x630b2a		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:35762	0x630b32		bb01000000		MOVL $0x1, BX									
  module.go:35762	0x630b37		b910000000		MOVL $0x10, CX									
  module.go:35762	0x630b3c		0f1f4000		NOPL 0(AX)									
  module.go:35762	0x630b40		e89bb5f9ff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn2(SB)	
  module.go:35763	0x630b45		488d05d49e2100		LEAQ 0x219ed4(IP), AX								
  module.go:35763	0x630b4c		488d1d9d172d00		LEAQ 0x2d179d(IP), BX								
  module.go:35763	0x630b53		e8887ce5ff		CALL runtime.gopanic(SB)							
  module.go:35757	0x630b58		89cb			MOVL CX, BX									
  module.go:36219	0x630b5a		4889c1			MOVQ AX, CX									
  module.go:36219	0x630b5d		31c0			XORL AX, AX									
  module.go:36219	0x630b5f		90			NOPL										
  module.go:36217	0x630b60		e9b6feffff		JMP 0x630a1b									
  module.go:63009	0x630b65		e856fee5ff		CALL runtime.panicBounds(SB)							
  module.go:36196	0x630b6a		4539c8			CMPL R8, R9									
  module.go:36196	0x630b6d		0f8689000000		JBE 0x630bfc									
  module.go:36200	0x630b73		488b7038		MOVQ 0x38(AX), SI								
  module.go:62983	0x630b77		498d7a07		LEAQ 0x7(R10), DI								
  module.go:62983	0x630b7b		0f1f440000		NOPL 0(AX)(AX*1)								
  module.go:62983	0x630b80		4839fe			CMPQ SI, DI									
  module.go:62983	0x630b83		7672			JBE 0x630bf7									
  module.go:36200	0x630b85		488b7830		MOVQ 0x30(AX), DI								
  module.go:62983	0x630b89		4d8d420b		LEAQ 0xb(R10), R8								
  module.go:36201	0x630b8d		90			NOPL										
  module.go:62984	0x630b8e		458b5c3a04		MOVL 0x4(R10)(DI*1), R11							
  module.go:62983	0x630b93		4c39c6			CMPQ SI, R8									
  module.go:62983	0x630b96		765a			JBE 0x630bf2									
  module.go:62984	0x630b98		458b443a08		MOVL 0x8(R10)(DI*1), R8								
  module.go:36202	0x630b9d		4501c8			ADDL R9, R8									
  module.go:63184	0x630ba0		89c9			MOVL CX, CX									
  module.go:63184	0x630ba2		8b0c39			MOVL 0(CX)(DI*1), CX								
  module.go:36203	0x630ba5		90			NOPL										
  module.go:36207	0x630ba6		4439c1			CMPL CX, R8									
  module.go:36207	0x630ba9		7602			JBE 0x630bad									
  module.go:36207	0x630bab		31c9			XORL CX, CX									
  module.go:36210	0x630bad		4129c8			SUBL CX, R8									
  module.go:36210	0x630bb0		438d0cc3		LEAL 0(R11)(R8*8), CX								
  module.go:63009	0x630bb4		4189c8			MOVL CX, R8									
  module.go:63009	0x630bb7		4983c007		ADDQ $0x7, R8									
  module.go:36211	0x630bbb		90			NOPL										
  module.go:36211	0x630bbc		0f1f4000		NOPL 0(AX)									
  module.go:63009	0x630bc0		4c39c6			CMPQ SI, R8									
  module.go:63009	0x630bc3		7628			JBE 0x630bed									
  module.go:36212	0x630bc5		488b7030		MOVQ 0x30(AX), SI								
  module.go:63010	0x630bc9		4189c8			MOVL CX, R8									
  module.go:63010	0x630bcc		498b3c38		MOVQ 0(R8)(DI*1), DI								
  unsafe.go:41		0x630bd0		66480f6ec7		MOVQ DI, X0									
  module.go:36212	0x630bd5		f20f100d8b132d00	MOVSD_XMM $f64.3ff0000000000000(SB), X1						
  module.go:36212	0x630bdd		f20f58c1		ADDSD X1, X0									
  module.go:36211	0x630be1		90			NOPL										
  module.go:63200	0x630be2		f2420f110406		MOVSD_XMM X0, 0(SI)(R8*1)							
  module.go:36215	0x630be8		e96bffffff		JMP 0x630b58									
  module.go:63009	0x630bed		e8cefde5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630bf2		e8c9fde5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630bf7		e8c4fde5ff		CALL runtime.panicBounds(SB)							
  module.go:36197	0x630bfc		bbf88e1000		MOVL $0x108ef8, BX								
  module.go:36197	0x630c01		b914000000		MOVL $0x14, CX									
  module.go:36197	0x630c06		bf0c8f1000		MOVL $0x108f0c, DI								
  module.go:36197	0x630c0b		e890edfaff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn69(SB)	
  module.go:36198	0x630c10		488d05099e2100		LEAQ 0x219e09(IP), AX								
  module.go:36198	0x630c17		488d1dd2162d00		LEAQ 0x2d16d2(IP), BX								
  module.go:36198	0x630c1e		6690			NOPW										
  module.go:36198	0x630c20		e8bb7be5ff		CALL runtime.gopanic(SB)							
  module.go:63026	0x630c25		e896fde5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630c2a		e891fde5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630c2f		e88cfde5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630c34		e887fde5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630c39		e882fde5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630c3e		6690			NOPW										
  module.go:62983	0x630c40		e87bfde5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630c45		e876fde5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630c4a		e871fde5ff		CALL runtime.panicBounds(SB)							
  module.go:36074	0x630c4f		4c8b4038		MOVQ 0x38(AX), R8								
  module.go:62983	0x630c53		4939f0			CMPQ R8, SI									
  module.go:62983	0x630c56		7615			JBE 0x630c6d									
  module.go:36074	0x630c58		488b7030		MOVQ 0x30(AX), SI								
  module.go:36075	0x630c5c		90			NOPL										
  module.go:63001	0x630c5d		41297c3210		SUBL DI, 0x10(R10)(SI*1)							
  module.go:63001	0x630c62		4531c9			XORL R9, R9									
  module.go:36195	0x630c65		4589f8			MOVL R15, R8									
  module.go:36077	0x630c68		e9fdfeffff		JMP 0x630b6a									
  module.go:62983	0x630c6d		e84efde5ff		CALL runtime.panicBounds(SB)							
  module.go:36068	0x630c72		ffcf			DECL DI										
  module.go:35702	0x630c74		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x630c78		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:63184	0x630c7f		4c8b5c2460		MOVQ 0x60(SP), R11								
  module.go:36070	0x630c84		4589cf			MOVL R9, R15									
  module.go:36046	0x630c87		4539ef			CMPL R15, R13									
  module.go:36046	0x630c8a		756a			JNE 0x630cf6									
  module.go:36070	0x630c8c		897c244c		MOVL DI, 0x4c(SP)								
  module.go:36047	0x630c90		89cb			MOVL CX, BX									
  module.go:36047	0x630c92		e8e93bfbff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn88(SB)	
  module.go:36048	0x630c97		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:36048	0x630c9f		488b4838		MOVQ 0x38(AX), CX								
  module.go:62983	0x630ca3		488b542470		MOVQ 0x70(SP), DX								
  module.go:62983	0x630ca8		4839d1			CMPQ CX, DX									
  module.go:62983	0x630cab		0f8603010000		JBE 0x630db4									
  module.go:36048	0x630cb1		488b7030		MOVQ 0x30(AX), SI								
  module.go:36050	0x630cb5		90			NOPL										
  module.go:62984	0x630cb6		4c8b442478		MOVQ 0x78(SP), R8								
  module.go:62984	0x630cbb		458b7c300c		MOVL 0xc(R8)(SI*1), R15								
  module.go:63184	0x630cc0		4c8b4c2460		MOVQ 0x60(SP), R9								
  module.go:63184	0x630cc5		458b2c31		MOVL 0(R9)(SI*1), R13								
  module.go:36047	0x630cc9		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:35702	0x630cd0		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x630cd4		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:62983	0x630cdb		488b742468		MOVQ 0x68(SP), SI								
  module.go:36069	0x630ce0		8b7c244c		MOVL 0x4c(SP), DI								
  module.go:63001	0x630ce4		448b44242c		MOVL 0x2c(SP), R8								
  module.go:63001	0x630ce9		4c8b542478		MOVQ 0x78(SP), R10								
  module.go:63184	0x630cee		4d89cb			MOVQ R9, R11									
  module.go:63000	0x630cf1		4c8b642470		MOVQ 0x70(SP), R12								
  module.go:36055	0x630cf6		4c8b4838		MOVQ 0x38(AX), R9								
  module.go:36055	0x630cfa		660f1f440000		NOPW 0(AX)(AX*1)								
  module.go:63000	0x630d00		4d39e1			CMPQ R9, R12									
  module.go:63000	0x630d03		0f86a6000000		JBE 0x630daf									
  module.go:36054	0x630d09		458d4f01		LEAL 0x1(R15), R9								
  module.go:36055	0x630d0d		4c8b7830		MOVQ 0x30(AX), R15								
  module.go:63001	0x630d11		47894c3a0c		MOVL R9, 0xc(R10)(R15*1)							
  module.go:36056	0x630d16		4c8b7838		MOVQ 0x38(AX), R15								
  module.go:62983	0x630d1a		498d5a0b		LEAQ 0xb(R10), BX								
  module.go:62983	0x630d1e		6690			NOPW										
  module.go:62983	0x630d20		4939df			CMPQ R15, BX									
  module.go:62983	0x630d23		0f8681000000		JBE 0x630daa									
  module.go:36056	0x630d29		4c8b7830		MOVQ 0x30(AX), R15								
  module.go:62984	0x630d2d		438b5c3a08		MOVL 0x8(R10)(R15*1), BX							
  module.go:36058	0x630d32		448d5bff		LEAL -0x1(BX), R11								
  module.go:36059	0x630d36		418d5c1d00		LEAL 0(R13)(BX*1), BX								
  module.go:36059	0x630d3b		8d5bff			LEAL -0x1(BX), BX								
  module.go:62983	0x630d3e		498d5207		LEAQ 0x7(R10), DX								
  module.go:36065	0x630d42		90			NOPL										
  module.go:36061	0x630d43		4439db			CMPL BX, R11									
  module.go:36062	0x630d46		440f42db		CMOVB BX, R11									
  module.go:63001	0x630d4a		47895c3a08		MOVL R11, 0x8(R10)(R15*1)							
  module.go:36066	0x630d4f		4c8b7838		MOVQ 0x38(AX), R15								
  module.go:62983	0x630d53		4939d7			CMPQ R15, DX									
  module.go:62983	0x630d56		764d			JBE 0x630da5									
  module.go:36066	0x630d58		488b5030		MOVQ 0x30(AX), DX								
  module.go:62984	0x630d5c		418b5c1204		MOVL 0x4(R10)(DX*1), BX								
  module.go:36067	0x630d61		468d1cdb		LEAL 0(BX)(R11*8), R11								
  module.go:63026	0x630d65		4489db			MOVL R11, BX									
  module.go:63026	0x630d68		4883c307		ADDQ $0x7, BX									
  module.go:63026	0x630d6c		4939df			CMPQ R15, BX									
  module.go:63026	0x630d6f		762e			JBE 0x630d9f									
  module.go:63027	0x630d71		4589db			MOVL R11, R11									
  module.go:63027	0x630d74		4ac7041a00000000	MOVQ $0x0, 0(DX)(R11*1)								
  module.go:63027	0x630d7c		0f1f4000		NOPL 0(AX)									
  module.go:36069	0x630d80		83ff01			CMPL DI, $0x1									
  module.go:36069	0x630d83		0f85e9feffff		JNE 0x630c72									
  module.go:35702	0x630d89		8b542434		MOVL 0x34(SP), DX								
  module.go:63000	0x630d8d		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:63001	0x630d94		4489c7			MOVL R8, DI									
  module.go:63001	0x630d97		4589cf			MOVL R9, R15									
  module.go:36069	0x630d9a		e9b0feffff		JMP 0x630c4f									
  module.go:63026	0x630d9f		90			NOPL										
  module.go:63026	0x630da0		e81bfce5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630da5		e816fce5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630daa		e811fce5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630daf		e80cfce5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630db4		e807fce5ff		CALL runtime.panicBounds(SB)							
  module.go:63113	0x630db9		e802fce5ff		CALL runtime.panicBounds(SB)							
  module.go:63113	0x630dbe		6690			NOPW										
  module.go:63113	0x630dc0		e8fbfbe5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630dc5		e8f6fbe5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x630dca		e8f1fbe5ff		CALL runtime.panicBounds(SB)							
  module.go:63113	0x630dcf		e8ecfbe5ff		CALL runtime.panicBounds(SB)							
  module.go:63113	0x630dd4		e8e7fbe5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630dd9		e8e2fbe5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630dde		6690			NOPW										
  module.go:62983	0x630de0		e8dbfbe5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630de5		e8d6fbe5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630dea		e8d1fbe5ff		CALL runtime.panicBounds(SB)							
  module.go:35988	0x630def		bb508e1000		MOVL $0x108e50, BX								
  module.go:35988	0x630df4		b911000000		MOVL $0x11, CX									
  module.go:35988	0x630df9		bfe88e1000		MOVL $0x108ee8, DI								
  module.go:35988	0x630dfe		6690			NOPW										
  module.go:35988	0x630e00		e89bebfaff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn69(SB)	
  module.go:35989	0x630e05		488d05149c2100		LEAQ 0x219c14(IP), AX								
  module.go:35989	0x630e0c		488d1ddd142d00		LEAQ 0x2d14dd(IP), BX								
  module.go:35989	0x630e13		e8c879e5ff		CALL runtime.gopanic(SB)							
  module.go:62983	0x630e18		e8a3fbe5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x630e1d		0f1f00			NOPL 0(AX)									
  module.go:36143	0x630e20		4539d8			CMPL R8, R11									
  module.go:36143	0x630e23		7603			JBE 0x630e28									
  module.go:36143	0x630e25		4531c0			XORL R8, R8									
  module.go:36146	0x630e28		4529c3			SUBL R8, R11									
  module.go:36146	0x630e2b		478d04dc		LEAL 0(R12)(R11*8), R8								
  module.go:36147	0x630e2f		4c8b5838		MOVQ 0x38(AX), R11								
  module.go:63009	0x630e33		4589c4			MOVL R8, R12									
  module.go:63009	0x630e36		4983c407		ADDQ $0x7, R12									
  module.go:63009	0x630e3a		660f1f440000		NOPW 0(AX)(AX*1)								
  module.go:63009	0x630e40		4d39e3			CMPQ R11, R12									
  module.go:63009	0x630e43		0f86f5010000		JBE 0x63103e									
  module.go:36147	0x630e49		4c8b5830		MOVQ 0x30(AX), R11								
  module.go:36148	0x630e4d		4c8b6030		MOVQ 0x30(AX), R12								
  module.go:63200	0x630e51		4589c0			MOVL R8, R8									
  module.go:63010	0x630e54		4f8b1c18		MOVQ 0(R8)(R11*1), R11								
  module.go:36147	0x630e58		66490f6ecb		MOVQ R11, X1									
  module.go:36148	0x630e5d		f20f58c1		ADDSD X1, X0									
  module.go:63200	0x630e61		f2430f110404		MOVSD_XMM X0, 0(R12)(R8*1)							
  module.go:36153	0x630e67		4c8b4038		MOVQ 0x38(AX), R8								
  module.go:36152	0x630e6b		468d1c0f		LEAL 0(DI)(R9*1), R11								
  module.go:36152	0x630e6f		458d0c39		LEAL 0(R9)(DI*1), R9								
  module.go:36152	0x630e73		458d4901		LEAL 0x1(R9), R9								
  module.go:36152	0x630e77		660f1f840000000000	NOPW 0(AX)(AX*1)								
  module.go:63000	0x630e80		4939f0			CMPQ R8, SI									
  module.go:63000	0x630e83		0f86b0010000		JBE 0x631039									
  module.go:36153	0x630e89		488b7030		MOVQ 0x30(AX), SI								
  module.go:63001	0x630e8d		45894c3210		MOVL R9, 0x10(R10)(SI*1)							
  module.go:36154	0x630e92		4429da			SUBL R11, DX									
  module.go:36154	0x630e95		448d4aff		LEAL -0x1(DX), R9								
  module.go:63000	0x630e99		4c8b642470		MOVQ 0x70(SP), R12								
  module.go:36157	0x630e9e		4489ca			MOVL R9, DX									
  module.go:36157	0x630ea1		4529f9			SUBL R15, R9									
  module.go:36157	0x630ea4		4181f9feffff7f		CMPL R9, $0x7ffffffe								
  module.go:36157	0x630eab		7730			JA 0x630edd									
  module.go:36161	0x630ead		488b7038		MOVQ 0x38(AX), SI								
  module.go:62983	0x630eb1		4d8d4203		LEAQ 0x3(R10), R8								
  module.go:62983	0x630eb5		4c39c6			CMPQ SI, R8									
  module.go:62983	0x630eb8		0f8676010000		JBE 0x631034									
  module.go:62983	0x630ebe		4c89442468		MOVQ R8, 0x68(SP)								
  module.go:36154	0x630ec3		8954244c		MOVL DX, 0x4c(SP)								
  module.go:36161	0x630ec7		488b7030		MOVQ 0x30(AX), SI								
  module.go:62984	0x630ecb		4189c9			MOVL CX, R9									
  module.go:62984	0x630ece		4c894c2460		MOVQ R9, 0x60(SP)								
  module.go:36160	0x630ed3		458d5fff		LEAL -0x1(R15), R11								
  module.go:62984	0x630ed7		418b3431		MOVL 0(R9)(SI*1), SI								
  module.go:36163	0x630edb		eb26			JMP 0x630f03									
  module.go:63000	0x630edd		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:36076	0x630ee4		4189d1			MOVL DX, R9									
  module.go:36195	0x630ee7		4589f8			MOVL R15, R8									
  module.go:35702	0x630eea		8b542434		MOVL 0x34(SP), DX								
  module.go:36158	0x630eee		e977fcffff		JMP 0x630b6a									
  module.go:62983	0x630ef3		4c8b442468		MOVQ 0x68(SP), R8								
  module.go:36191	0x630ef8		4589ef			MOVL R13, R15									
  module.go:36191	0x630efb		4589cb			MOVL R9, R11									
  module.go:62984	0x630efe		4c8b4c2460		MOVQ 0x60(SP), R9								
  module.go:36167	0x630f03		4439fe			CMPL SI, R15									
  module.go:36167	0x630f06		7570			JNE 0x630f78									
  module.go:36191	0x630f08		44895c242c		MOVL R11, 0x2c(SP)								
  module.go:36168	0x630f0d		89cb			MOVL CX, BX									
  module.go:36168	0x630f0f		e86c39fbff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn88(SB)	
  module.go:36169	0x630f14		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:36169	0x630f1c		488b4838		MOVQ 0x38(AX), CX								
  module.go:62983	0x630f20		488b542468		MOVQ 0x68(SP), DX								
  module.go:62983	0x630f25		4839d1			CMPQ CX, DX									
  module.go:62983	0x630f28		0f8601010000		JBE 0x63102f									
  module.go:36169	0x630f2e		488b7030		MOVQ 0x30(AX), SI								
  module.go:62984	0x630f32		4c8b442460		MOVQ 0x60(SP), R8								
  module.go:62984	0x630f37		458b0c30		MOVL 0(R8)(SI*1), R9								
  module.go:62983	0x630f3b		4c8b542470		MOVQ 0x70(SP), R10								
  module.go:62983	0x630f40		4c39d1			CMPQ CX, R10									
  module.go:62983	0x630f43		0f86e1000000		JBE 0x63102a									
  module.go:62984	0x630f49		4c8b5c2478		MOVQ 0x78(SP), R11								
  module.go:62984	0x630f4e		458b7c330c		MOVL 0xc(R11)(SI*1), R15							
  module.go:36168	0x630f53		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:36190	0x630f5a		8b54244c		MOVL 0x4c(SP), DX								
  module.go:62983	0x630f5e		4c8b442468		MOVQ 0x68(SP), R8								
  module.go:63001	0x630f63		4d89da			MOVQ R11, R10									
  module.go:36189	0x630f66		448b5c242c		MOVL 0x2c(SP), R11								
  module.go:63000	0x630f6b		4c8b642470		MOVQ 0x70(SP), R12								
  module.go:36171	0x630f70		4489ce			MOVL R9, SI									
  module.go:62984	0x630f73		4c8b4c2460		MOVQ 0x60(SP), R9								
  module.go:36178	0x630f78		4c8b6838		MOVQ 0x38(AX), R13								
  module.go:36178	0x630f7c		0f1f4000		NOPL 0(AX)									
  module.go:63000	0x630f80		4d39e5			CMPQ R13, R12									
  module.go:63000	0x630f83		0f869c000000		JBE 0x631025									
  module.go:36177	0x630f89		458d6f01		LEAL 0x1(R15), R13								
  module.go:36178	0x630f8d		488b5830		MOVQ 0x30(AX), BX								
  module.go:63001	0x630f91		45896c1a0c		MOVL R13, 0xc(R10)(BX*1)							
  module.go:36179	0x630f96		488b5838		MOVQ 0x38(AX), BX								
  module.go:62983	0x630f9a		498d7a07		LEAQ 0x7(R10), DI								
  module.go:62983	0x630f9e		6690			NOPW										
  module.go:62983	0x630fa0		4839fb			CMPQ BX, DI									
  module.go:62983	0x630fa3		7678			JBE 0x63101d									
  module.go:36179	0x630fa5		488b7830		MOVQ 0x30(AX), DI								
  module.go:62983	0x630fa9		4d8d4a0b		LEAQ 0xb(R10), R9								
  module.go:36180	0x630fad		90			NOPL										
  module.go:62984	0x630fae		458b443a04		MOVL 0x4(R10)(DI*1), R8								
  module.go:62983	0x630fb3		4c39cb			CMPQ BX, R9									
  module.go:62983	0x630fb6		7660			JBE 0x631018									
  module.go:62984	0x630fb8		458b4c3a08		MOVL 0x8(R10)(DI*1), R9								
  module.go:36181	0x630fbd		4501f9			ADDL R15, R9									
  module.go:36184	0x630fc0		4439ce			CMPL SI, R9									
  module.go:36185	0x630fc3		41bf00000000		MOVL $0x0, R15									
  module.go:36185	0x630fc9		440f46fe		CMOVBE SI, R15									
  module.go:36187	0x630fcd		4529f9			SUBL R15, R9									
  module.go:36187	0x630fd0		478d04c8		LEAL 0(R8)(R9*8), R8								
  module.go:63026	0x630fd4		4589c1			MOVL R8, R9									
  module.go:63026	0x630fd7		4983c107		ADDQ $0x7, R9									
  module.go:63026	0x630fdb		0f1f440000		NOPL 0(AX)(AX*1)								
  module.go:63026	0x630fe0		4c39cb			CMPQ BX, R9									
  module.go:36184	0x630fe3		762e			JBE 0x631013									
  module.go:36189	0x630fe5		458d4b01		LEAL 0x1(R11), R9								
  module.go:63027	0x630fe9		4589c0			MOVL R8, R8									
  module.go:63027	0x630fec		4ac7040700000000	MOVQ $0x0, 0(DI)(R8*1)								
  module.go:36190	0x630ff4		4439ca			CMPL DX, R9									
  module.go:36190	0x630ff7		0f85f6feffff		JNE 0x630ef3									
  module.go:63000	0x630ffd		8b9c2498000000		MOVL 0x98(SP), BX								
  module.go:36076	0x631004		4189d1			MOVL DX, R9									
  module.go:36195	0x631007		4589e8			MOVL R13, R8									
  module.go:35702	0x63100a		8b542434		MOVL 0x34(SP), DX								
  module.go:36190	0x63100e		e957fbffff		JMP 0x630b6a									
  module.go:63026	0x631013		e8a8f9e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x631018		e8a3f9e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x63101d		0f1f00			NOPL 0(AX)									
  module.go:62983	0x631020		e89bf9e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x631025		e896f9e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x63102a		e891f9e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x63102f		e88cf9e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x631034		e887f9e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x631039		e882f9e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x63103e		6690			NOPW										
  module.go:63009	0x631040		e87bf9e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x631045		e876f9e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x63104a		e871f9e5ff		CALL runtime.panicBounds(SB)							
  module.go:35950	0x63104f		4183c0fe		ADDL $-0x2, R8									
  module.go:35952	0x631053		44897c2428		MOVL R15, 0x28(SP)								
  module.go:35952	0x631058		448b7c2440		MOVL 0x40(SP), R15								
  module.go:35952	0x63105d		0f1f00			NOPL 0(AX)									
  module.go:35898	0x631060		4585ff			TESTL R15, R15									
  module.go:35898	0x631063		750b			JNE 0x631070									
  module.go:35898	0x631065		4531ff			XORL R15, R15									
  module.go:35898	0x631068		0f57c9			XORPS X1, X1									
  module.go:35902	0x63106b		e996000000		JMP 0x631106									
  module.go:35906	0x631070		488b5838		MOVQ 0x38(AX), BX								
  module.go:63000	0x631074		4c39e3			CMPQ BX, R12									
  module.go:63000	0x631077		0f867c030000		JBE 0x6313f9									
  module.go:35905	0x63107d		41ffcf			DECL R15									
  module.go:35906	0x631080		488b5830		MOVQ 0x30(AX), BX								
  module.go:63001	0x631084		45897c1a0c		MOVL R15, 0xc(R10)(BX*1)							
  module.go:35908	0x631089		8d5901			LEAL 0x1(CX), BX								
  module.go:35911	0x63108c		4139dd			CMPL R13, BX									
  module.go:35911	0x63108f		7705			JA 0x631096									
  module.go:63184	0x631091		4489eb			MOVL R13, BX									
  module.go:35912	0x631094		eb06			JMP 0x63109c									
  module.go:35938	0x631096		4489eb			MOVL R13, BX									
  module.go:35938	0x631099		4531ed			XORL R13, R13									
  module.go:35952	0x63109c		894c2430		MOVL CX, 0x30(SP)								
  module.go:35915	0x6310a0		488b5038		MOVQ 0x38(AX), DX								
  module.go:35914	0x6310a4		4429e9			SUBL R13, CX									
  module.go:63000	0x6310a7		4839f2			CMPQ DX, SI									
  module.go:63000	0x6310aa		0f8644030000		JBE 0x6313f4									
  module.go:35914	0x6310b0		8d5101			LEAL 0x1(CX), DX								
  module.go:35915	0x6310b3		4c8b6830		MOVQ 0x30(AX), R13								
  module.go:63001	0x6310b7		4389542a08		MOVL DX, 0x8(R10)(R13*1)							
  module.go:35916	0x6310bc		4c8b6838		MOVQ 0x38(AX), R13								
  module.go:35877	0x6310c0		4489d9			MOVL R11, CX									
  module.go:35916	0x6310c3		448b5c2430		MOVL 0x30(SP), R11								
  module.go:35916	0x6310c8		478d1cd9		LEAL 0(R9)(R11*8), R11								
  module.go:63009	0x6310cc		4489df			MOVL R11, DI									
  module.go:63009	0x6310cf		4883c707		ADDQ $0x7, DI									
  module.go:63009	0x6310d3		4939fd			CMPQ R13, DI									
  module.go:63009	0x6310d6		0f8613030000		JBE 0x6313ef									
  module.go:35916	0x6310dc		4c8b6830		MOVQ 0x30(AX), R13								
  module.go:63010	0x6310e0		4589db			MOVL R11, R11									
  module.go:63010	0x6310e3		4f8b1c2b		MOVQ 0(R11)(R13*1), R11								
  unsafe.go:41		0x6310e7		66490f6ecb		MOVQ R11, X1									
  module.go:36122	0x6310ec		8b7c2448		MOVL 0x48(SP), DI								
  module.go:36085	0x6310f0		4189cb			MOVL CX, R11									
  module.go:35938	0x6310f3		4189dd			MOVL BX, R13									
  module.go:35916	0x6310f6		89d1			MOVL DX, CX									
  module.go:35916	0x6310f8		44897c2428		MOVL R15, 0x28(SP)								
  module.go:36154	0x6310fd		8b542424		MOVL 0x24(SP), DX								
  module.go:63184	0x631101		488b5c2460		MOVQ 0x60(SP), BX								
  module.go:35922	0x631106		f20f58c8		ADDSD X0, X1									
  module.go:35925	0x63110a		4585ff			TESTL R15, R15									
  module.go:35925	0x63110d		751a			JNE 0x631129									
  module.go:35925	0x63110f		0f57c0			XORPS X0, X0									
  module.go:35943	0x631112		448b7c2428		MOVL 0x28(SP), R15								
  module.go:35943	0x631117		4531ff			XORL R15, R15									
  module.go:35943	0x63111a		44897c2440		MOVL R15, 0x40(SP)								
  module.go:35943	0x63111f		448b7c2428		MOVL 0x28(SP), R15								
  module.go:35929	0x631124		e996000000		JMP 0x6311bf									
  module.go:35933	0x631129		488b5838		MOVQ 0x38(AX), BX								
  module.go:63000	0x63112d		4c39e3			CMPQ BX, R12									
  module.go:63000	0x631130		0f86b4020000		JBE 0x6313ea									
  module.go:35932	0x631136		41ffcf			DECL R15									
  module.go:35933	0x631139		488b5830		MOVQ 0x30(AX), BX								
  module.go:63001	0x63113d		45897c1a0c		MOVL R15, 0xc(R10)(BX*1)							
  module.go:35935	0x631142		8d5901			LEAL 0x1(CX), BX								
  module.go:35938	0x631145		4139dd			CMPL R13, BX									
  module.go:35938	0x631148		7705			JA 0x63114f									
  module.go:63184	0x63114a		4489eb			MOVL R13, BX									
  module.go:35939	0x63114d		eb06			JMP 0x631155									
  module.go:35911	0x63114f		4489eb			MOVL R13, BX									
  module.go:35911	0x631152		4531ed			XORL R13, R13									
  module.go:35916	0x631155		894c2444		MOVL CX, 0x44(SP)								
  module.go:35942	0x631159		488b5038		MOVQ 0x38(AX), DX								
  module.go:35941	0x63115d		4429e9			SUBL R13, CX									
  module.go:63000	0x631160		4839f2			CMPQ DX, SI									
  module.go:63000	0x631163		0f867c020000		JBE 0x6313e5									
  module.go:35941	0x631169		8d5101			LEAL 0x1(CX), DX								
  module.go:35942	0x63116c		4c8b6830		MOVQ 0x30(AX), R13								
  module.go:63001	0x631170		4389542a08		MOVL DX, 0x8(R10)(R13*1)							
  module.go:35943	0x631175		4c8b6838		MOVQ 0x38(AX), R13								
  module.go:35877	0x631179		4489d9			MOVL R11, CX									
  module.go:35943	0x63117c		448b5c2444		MOVL 0x44(SP), R11								
  module.go:35943	0x631181		478d1cd9		LEAL 0(R9)(R11*8), R11								
  module.go:63009	0x631185		4489df			MOVL R11, DI									
  module.go:63009	0x631188		4883c707		ADDQ $0x7, DI									
  module.go:63009	0x63118c		4939fd			CMPQ R13, DI									
  module.go:63009	0x63118f		0f8649020000		JBE 0x6313de									
  module.go:35943	0x631195		4c8b6830		MOVQ 0x30(AX), R13								
  module.go:63010	0x631199		4589db			MOVL R11, R11									
  module.go:63010	0x63119c		4f8b1c2b		MOVQ 0(R11)(R13*1), R11								
  unsafe.go:41		0x6311a0		66490f6ec3		MOVQ R11, X0									
  module.go:36122	0x6311a5		8b7c2448		MOVL 0x48(SP), DI								
  module.go:36085	0x6311a9		4189cb			MOVL CX, R11									
  module.go:35911	0x6311ac		4189dd			MOVL BX, R13									
  module.go:35943	0x6311af		89d1			MOVL DX, CX									
  module.go:35943	0x6311b1		44897c2440		MOVL R15, 0x40(SP)								
  module.go:36154	0x6311b6		8b542424		MOVL 0x24(SP), DX								
  module.go:63184	0x6311ba		488b5c2460		MOVQ 0x60(SP), BX								
  module.go:35949	0x6311bf		f20f58c1		ADDSD X1, X0									
  module.go:35951	0x6311c3		4183f802		CMPL R8, $0x2									
  module.go:35951	0x6311c7		0f8582feffff		JNE 0x63104f									
  module.go:36085	0x6311cd		410fbae300		BTL $0x0, R11									
  module.go:36085	0x6311d2		7208			JB 0x6311dc									
  module.go:36086	0x6311d4		4589f8			MOVL R15, R8									
  module.go:36086	0x6311d7		e9a4000000		JMP 0x631280									
  module.go:36088	0x6311dc		4589f8			MOVL R15, R8									
  module.go:36088	0x6311df		448b7c2440		MOVL 0x40(SP), R15								
  module.go:36089	0x6311e4		4585ff			TESTL R15, R15									
  module.go:36089	0x6311e7		0f848a000000		JE 0x631277									
  module.go:36092	0x6311ed		4c8b4038		MOVQ 0x38(AX), R8								
  module.go:63000	0x6311f1		4d39e0			CMPQ R8, R12									
  module.go:63000	0x6311f4		0f86df010000		JBE 0x6313d9									
  module.go:36091	0x6311fa		458d47ff		LEAL -0x1(R15), R8								
  module.go:36092	0x6311fe		4c8b5830		MOVQ 0x30(AX), R11								
  module.go:63001	0x631202		4789441a0c		MOVL R8, 0xc(R10)(R11*1)							
  module.go:36094	0x631207		448d5901		LEAL 0x1(CX), R11								
  module.go:36097	0x63120b		4539dd			CMPL R13, R11									
  module.go:36097	0x63120e		7705			JA 0x631215									
  module.go:63184	0x631210		4589eb			MOVL R13, R11									
  module.go:36098	0x631213		eb06			JMP 0x63121b									
  module.go:36112	0x631215		4589eb			MOVL R13, R11									
  module.go:36112	0x631218		4531ed			XORL R13, R13									
  module.go:36088	0x63121b		894c243c		MOVL CX, 0x3c(SP)								
  module.go:36101	0x63121f		4c8b7838		MOVQ 0x38(AX), R15								
  module.go:36100	0x631223		4429e9			SUBL R13, CX									
  module.go:63000	0x631226		4939f7			CMPQ R15, SI									
  module.go:63000	0x631229		0f86a5010000		JBE 0x6313d4									
  module.go:36100	0x63122f		448d6901		LEAL 0x1(CX), R13								
  module.go:36101	0x631233		4c8b7830		MOVQ 0x30(AX), R15								
  module.go:63001	0x631237		47896c3a08		MOVL R13, 0x8(R10)(R15*1)							
  module.go:36102	0x63123c		4c8b7838		MOVQ 0x38(AX), R15								
  module.go:35833	0x631240		89d1			MOVL DX, CX									
  module.go:36102	0x631242		8b54243c		MOVL 0x3c(SP), DX								
  module.go:36102	0x631246		418d14d1		LEAL 0(R9)(DX*8), DX								
  module.go:63009	0x63124a		89d3			MOVL DX, BX									
  module.go:63009	0x63124c		4883c307		ADDQ $0x7, BX									
  module.go:63009	0x631250		4939df			CMPQ R15, BX									
  module.go:63009	0x631253		0f8676010000		JBE 0x6313cf									
  module.go:36102	0x631259		4c8b7830		MOVQ 0x30(AX), R15								
  module.go:63010	0x63125d		89d2			MOVL DX, DX									
  module.go:63010	0x63125f		4a8b143a		MOVQ 0(DX)(R15*1), DX								
  unsafe.go:41		0x631263		66480f6eca		MOVQ DX, X1									
  module.go:36154	0x631268		89ca			MOVL CX, DX									
  module.go:63184	0x63126a		488b5c2460		MOVQ 0x60(SP), BX								
  module.go:36102	0x63126f		4489e9			MOVL R13, CX									
  module.go:36112	0x631272		4589dd			MOVL R11, R13									
  module.go:36104	0x631275		eb03			JMP 0x63127a									
  module.go:36104	0x631277		0f57c9			XORPS X1, X1									
  module.go:36106	0x63127a		f20f58c1		ADDSD X1, X0									
  module.go:36106	0x63127e		6690			NOPW										
  module.go:36108	0x631280		4585c0			TESTL R8, R8									
  module.go:36108	0x631283		7422			JE 0x6312a7									
  module.go:63000	0x631285		488b742468		MOVQ 0x68(SP), SI								
  module.go:36109	0x63128a		4189cb			MOVL CX, R11									
  module.go:36109	0x63128d		4589c7			MOVL R8, R15									
  module.go:36109	0x631290		4589cc			MOVL R9, R12									
  module.go:62984	0x631293		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:36152	0x63129a		448b4c244c		MOVL 0x4c(SP), R9								
  module.go:36109	0x63129f		4589e8			MOVL R13, R8									
  module.go:36109	0x6312a2		e979fbffff		JMP 0x630e20									
  module.go:36112	0x6312a7		4585ed			TESTL R13, R13									
  module.go:36112	0x6312aa		740b			JE 0x6312b7									
  module.go:36112	0x6312ac		41bb01000000		MOVL $0x1, R11									
  module.go:36112	0x6312b2		e987000000		JMP 0x63133e									
  module.go:62983	0x6312b7		4889742458		MOVQ SI, 0x58(SP)								
  module.go:36086	0x6312bc		f20f11442450		MOVSD_XMM X0, 0x50(SP)								
  module.go:36113	0x6312c2		8b9c249c000000		MOVL 0x9c(SP), BX								
  module.go:36113	0x6312c9		e8b235fbff		CALL dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn88(SB)	
  module.go:36114	0x6312ce		488b842490000000	MOVQ 0x90(SP), AX								
  module.go:36114	0x6312d6		488b4838		MOVQ 0x38(AX), CX								
  module.go:62983	0x6312da		488b542470		MOVQ 0x70(SP), DX								
  module.go:62983	0x6312df		90			NOPL										
  module.go:62983	0x6312e0		4839d1			CMPQ CX, DX									
  module.go:62983	0x6312e3		0f86e1000000		JBE 0x6313ca									
  module.go:36114	0x6312e9		488b7030		MOVQ 0x30(AX), SI								
  module.go:36116	0x6312ed		90			NOPL										
  module.go:62984	0x6312ee		4c8b442478		MOVQ 0x78(SP), R8								
  module.go:62984	0x6312f3		458b4c300c		MOVL 0xc(R8)(SI*1), R9								
  module.go:62983	0x6312f8		4c8b542468		MOVQ 0x68(SP), R10								
  module.go:62983	0x6312fd		0f1f00			NOPL 0(AX)									
  module.go:62983	0x631300		4c39d1			CMPQ CX, R10									
  module.go:62983	0x631303		0f86bc000000		JBE 0x6313c5									
  module.go:36115	0x631309		458d5901		LEAL 0x1(R9), R11								
  module.go:36118	0x63130d		90			NOPL										
  module.go:36120	0x63130e		90			NOPL										
  module.go:62984	0x63130f		418b7c3010		MOVL 0x10(R8)(SI*1), DI								
  module.go:63184	0x631314		458b4c3004		MOVL 0x4(R8)(SI*1), R9								
  module.go:63184	0x631319		4c8b642460		MOVQ 0x60(SP), R12								
  module.go:63184	0x63131e		458b2c34		MOVL 0(R12)(SI*1), R13								
  module.go:63184	0x631322		418b4c3008		MOVL 0x8(R8)(SI*1), CX								
  module.go:36154	0x631327		8b542424		MOVL 0x24(SP), DX								
  module.go:63000	0x63132b		488b742458		MOVQ 0x58(SP), SI								
  module.go:63001	0x631330		4d89c2			MOVQ R8, R10									
  module.go:63000	0x631333		4c8b642470		MOVQ 0x70(SP), R12								
  module.go:63027	0x631338		f20f10442450		MOVSD_XMM 0x50(SP), X0								
  module.go:36125	0x63133e		4c8b4038		MOVQ 0x38(AX), R8								
  module.go:63000	0x631342		4d39e0			CMPQ R8, R12									
  module.go:63000	0x631345		7674			JBE 0x6313bb									
  module.go:36125	0x631347		4c8b4030		MOVQ 0x30(AX), R8								
  module.go:63001	0x63134b		47895c020c		MOVL R11, 0xc(R10)(R8*1)							
  module.go:36128	0x631350		448d41ff		LEAL -0x1(CX), R8								
  module.go:36129	0x631354		458d7c0d00		LEAL 0(R13)(CX*1), R15								
  module.go:36129	0x631359		458d7fff		LEAL -0x1(R15), R15								
  module.go:36135	0x63135d		488b4838		MOVQ 0x38(AX), CX								
  module.go:36131	0x631361		4539fd			CMPL R13, R15									
  module.go:36132	0x631364		450f47c7		CMOVA R15, R8									
  module.go:63000	0x631368		4839f1			CMPQ CX, SI									
  module.go:36131	0x63136b		7649			JBE 0x6313b6									
  module.go:36135	0x63136d		488b7030		MOVQ 0x30(AX), SI								
  module.go:63001	0x631371		4589443208		MOVL R8, 0x8(R10)(SI*1)								
  module.go:36136	0x631376		488b7038		MOVQ 0x38(AX), SI								
  module.go:36136	0x63137a		478d04c1		LEAL 0(R9)(R8*8), R8								
  module.go:63026	0x63137e		4589c1			MOVL R8, R9									
  module.go:63026	0x631381		4983c107		ADDQ $0x7, R9									
  module.go:63026	0x631385		4c39ce			CMPQ SI, R9									
  module.go:63026	0x631388		7627			JBE 0x6313b1									
  module.go:36136	0x63138a		4c8b6830		MOVQ 0x30(AX), R13								
  module.go:63027	0x63138e		4589c0			MOVL R8, R8									
  module.go:63027	0x631391		f2430f11440500		MOVSD_XMM X0, 0(R13)(R8*1)							
  module.go:62984	0x631398		8b8c249c000000		MOVL 0x9c(SP), CX								
  module.go:63000	0x63139f		488b742468		MOVQ 0x68(SP), SI								
  module.go:36152	0x6313a4		448b4c244c		MOVL 0x4c(SP), R9								
  module.go:36137	0x6313a9		4589df			MOVL R11, R15									
  module.go:36137	0x6313ac		e9b6faffff		JMP 0x630e67									
  module.go:63026	0x6313b1		e80af6e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x6313b6		e805f6e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x6313bb		0f1f440000		NOPL 0(AX)(AX*1)								
  module.go:63000	0x6313c0		e8fbf5e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x6313c5		e8f6f5e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x6313ca		e8f1f5e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x6313cf		e8ecf5e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x6313d4		e8e7f5e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x6313d9		e8e2f5e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x6313de		6690			NOPW										
  module.go:63009	0x6313e0		e8dbf5e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x6313e5		e8d6f5e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x6313ea		e8d1f5e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x6313ef		e8ccf5e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x6313f4		e8c7f5e5ff		CALL runtime.panicBounds(SB)							
  module.go:63000	0x6313f9		e8c2f5e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x6313fe		6690			NOPW										
  module.go:62983	0x631400		e8bbf5e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x631405		e8b6f5e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x63140a		e8b1f5e5ff		CALL runtime.panicBounds(SB)							
  module.go:62983	0x63140f		e8acf5e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x631414		e8a7f5e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x631419		e8a2f5e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x63141e		6690			NOPW										
  module.go:63009	0x631420		e89bf5e5ff		CALL runtime.panicBounds(SB)							
  module.go:63009	0x631425		90			NOPL										
  module.go:35694	0x631426		4889442408		MOVQ AX, 0x8(SP)								
  module.go:35694	0x63142b		895c2410		MOVL BX, 0x10(SP)								
  module.go:35694	0x63142f		894c2414		MOVL CX, 0x14(SP)								
  module.go:35694	0x631433		f20f11442418		MOVSD_XMM X0, 0x18(SP)								
  module.go:35694	0x631439		e862d8e5ff		CALL runtime.morestack_noctxt.abi0(SB)						
  module.go:35694	0x63143e		488b442408		MOVQ 0x8(SP), AX								
  module.go:35694	0x631443		8b5c2410		MOVL 0x10(SP), BX								
  module.go:35694	0x631447		8b4c2414		MOVL 0x14(SP), CX								
  module.go:35694	0x63144b		f20f10442418		MOVSD_XMM 0x18(SP), X0								
  module.go:35694	0x631451		e9caeaffff		JMP dario.cat/cocoon/examples/datadog/go/dd/internal/wasm.(*Module).fn176(SB)	
