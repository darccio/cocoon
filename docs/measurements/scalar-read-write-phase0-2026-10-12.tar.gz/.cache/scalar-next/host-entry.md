# Host entry audit: scalar phase 0

Read-only source/artifact review at clean `20e33db`, 2026-10-12. No builds,
tests, lint, profiles, or benchmark executions. This ignored note is the only
write. Tool activity stops after the note, before the parent's fresh profiles.

## Current supported path and mandatory boundaries

`Sketch.Add` performs nil checks, one `Lifecycle.Enter`/deferred `Leave`, shared
ownership-cell `Resource.Use`, and `Instance.Call`. Add has NO input reservation
or guest Reserve call. It invokes the actual scalar guest export once, obtains
the canonical descriptor through `ResultView`, and rejects nonempty successful
unit replies. There is no pool acquisition/recycling on this resource call.

Ownership serializes aliases with the same cell mutex; closed, dead, or wrong
epoch cells fail before execution. The deferred KeepAlive protects GC cleanup
through the callback. Instance.Call holds a separate execution mutex, retains
closed/poisoned checks, clears prior host panic, resets the full Call state,
recovers guest/host panic, checks CURRENT post-call logical memory against
MaxMemory, and immediately poisons protocol faults. Library drain must continue
to wait for admitted calls. Neither lock, admission, ownership/epoch checks,
reset, panic handling, nor post-memory checks may be removed based on P1 costs.

ResultView reacquires current memory after guest growth, checks the fixed cached
descriptor's eight bytes against logical length, reads pointer/size, enforces
MaxOutput, validates the full payload range (including zero size), then handles
non-OK status. A zero-sized pointer beyond logical length is still a protocol
fault; pointer equal to length is valid. Reserved/unknown statuses and malformed
error ranges must still fail and poison as appropriate. Valid expected guest
errors own their text and remain healthy. Unit nonempty success is ErrProtocol,
but descriptor/MaxOutput/payload errors retain their existing precedence first.
The borrowed view cannot survive another guest call, growth, or lock release.

## What existing controls can establish

Guest / Instance / Resource / Facade layers all invoke real guest Add on
increasing inputs. Instance includes ResultView and unit shape validation;
Resource adds ownership but omits library admission; only Facade is supported
behavior. Empty Instance, Resource, and Lifecycle controls have no guest or
reply. Their independently calibrated timings are rough cumulative ceilings,
not additive component shares. Increasing roles run different prefixes and
state trajectories. The existing layers do not report in-window actual-procs;
fresh profiling should force `-test.cpu=1` and record the argv/environment.
Matched backend controls do explicitly bracket P1 but add engine dispatch and
private control topology, so they do not replace generated facade measurements.

Historical same-Wasm confirmation layers were Guest 54.07, Instance 72.52,
Resource 82.35, Facade 89.84 ns; empty controls 15.81/25.07/7.272 ns. These are
prior-session references, not current component costs. Prior checked profile
reply attribution was 11.99% cumulative, also overlapping and not a predicted
gain. Latest contained-load production facade scalar 87.87/88.11 ns had no
detected gain/loss while raw Guest improved 1.23/1.24%; raw gains alone did not
qualify standalone latency or M1.

Existing contained-load ordinary assembly confirms the scalar guest export
itself stayed 3004 bytes, frame112, 642 instructions and 57 static panic-bounds
sites through that transformation; fn176 was changed. Historical normalized
streaming artifacts expose a ResultView frame104 plus interface Memory call,
descriptor/payload bounds and status branch, but their binary/package placement
is old. They establish surviving work, not a fresh hotness or timing claim.
Fresh matching ordinary assembly/profile should resolve this before selection.

## Narrow host option, after fresh attribution

The least invasive host hypothesis is an ignored checked unit-return fast path
using the EXISTING `Call.ResultUnit` contract, with no change to Call's core or
ABI3. Today ResultUnit simply calls ResultView and checks length, while generated
unit operations directly do the same ResultView/length sequence. First include
an unchanged-ResultUnit call-shape control in an identical private facade path;
then measure an ignored ResultUnit specialization that still reads current
memory, validates the 8-byte descriptor, and only for OK+size0 checks the
widened zero-size pointer range before returning. All other statuses/sizes use
the exact existing validation path and error precedence. No unchecked guest
return, stale memory header, cached reply descriptor contents, or bypassed
MaxMemory/poison boundary is permitted. Generated facade and actual guest
remain in every end-to-end role. Any later retained change needs one shared
authored policy for validation rather than hand-maintained duplicate checks.

This is only a plausible ABI-preserving candidate, not an implementation or
speedup recommendation. If the fresh profile/assembly shows little attainable
share, measure the track-4 typed-return ceiling instead: a private diagnostic
must separately report descriptor-publication guest work and host validation,
and remain explicitly unsupported. Dropping ABI3 descriptor validation in a
production path is a new contract, requiring a versioned schema, compatibility
plan, specification and explicit operator approval before implementation.

The guest's proposed contained load64 followed by same-address store64 guard
is a separate translation hypothesis. Its diagnostic must preserve both actual
accesses, operand evaluation and trap/partial-store order, logical length and
width/overflow proofs; no intervening call/import/header/control crossing. It
may offer a safer first ceiling than another broad runtime refactoring, but
fresh attribution and ordinary optimized code are required.

## Past negative routes and qualification limits

Checked-core optional-lock factoring, extra reply wrappers/reset stores,
an extra checked boundary frame and directly deferred recovery helpers all
regressed scalar in the sessions rounds (R1-R4). R5's small varied-scalar loss,
R6/R7 state/reset changes, and R11 moving an identical Call to another source
file also failed guards. Exact Call/ResultView bodies at the original source
position with one generated authored policy were ultimately retained. Reusing
these rejected shapes requires a concrete new machine-code reason and paired
evidence; source simplification alone is not a performance argument.

Bin reuse improved hot batches but materially lost miss-heavy scalar workloads;
the register-resident log polynomial and guarded conversion experiment supplied
no qualified scalar win. New source/helper placement has flipped unrelated
timings before; unchanged-check/shape controls and fresh identical-source
before/after builds are necessary. Keep scalar repeated/increasing/negative/
broad, SQL original/varied/holdout, batches, trace and paired full-stream guards;
report all medians/negative directions and current memory/growth. New leaves
must bracket actual P1 after setup/before reset and after stop, and P16 streams
must retain their own topology/metrics. No profiling/build/lint overlaps any
isolated measurements. A phase-0 ceiling or raw guest gain does not accept M1.
