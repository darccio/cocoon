# Scalar phase-zero guest outcome review

Read-only final audit after timing, 2026-10-12. No builds, tests, profiles,
linting, or measurements were run for this audit. Reviewed decision plan,
probe inventory, machine/SSA provenance and summaries, all warm comparison
summaries and matching time-benchstat outputs. The frozen snapshot contains
274 hashes; records contain 826 samples. The parent reports every frozen hash
unchanged. Final gates are parent-owned and were still executing at review time.

**Verdict: no-go under the predeclared scalar promotion rule.** Park the three
exact adjacent-store hypothesis and retain its evidence only. No generic
production specification or implementation should follow this result. Do not
broaden selection, retime chosen subsets, alter math/cache policy, or add an ABI
to rescue it. M1 remains unaccepted.

## End-to-end scalar rule

The decision plan requires ordinary scalar gain in both rounds against both
untouched and copied-check controls, surviving the negative/increasing/broad
holdouts. Ordinary scalar is 87.69 → 87.51 ns (−0.205%, p=.620), then
87.64 → 87.43 ns (−0.240%, p=.901) against untouched. Comparisons against
copied-check are also undetected (p=.334/.876). No reproducible end-to-end
scalar ceiling was established, which alone satisfies the no-go rule.

Raw guest scalar improves 53.04 → 52.82 ns (−0.415%, p=.002), then
53.12 → 52.86 ns (−0.489%, p=.026). It is a separate unchecked diagnostic,
not a public-facade speedup or removable facade-cost estimate. Scalar and
batch report zero Go allocations; this probe changes neither ownership nor
guest arithmetic/copy policy.

Keep both broad scalar negatives with their actual comparators: screen
88.77 → 89.18 ns (+0.462%, p=.033) versus untouched; confirmation
88.80 → 89.01 ns (+0.236%, p=.041) versus copied-check. Confirmation versus
untouched is +0.101%, p=.259. These do not establish a repeated loss against
one identical comparator, but remain adverse results. Varied, negative-bin
and increasing scalar versus untouched show no repeated detected gain.
Some confirmation comparisons against recheck improve; they cannot satisfy
the stronger preregistered two-round/two-control requirement.

## Static change and attribution limits

Only three full-source-hash-pinned fn176 pairs are changed in ignored overlays:
t82's zero-count update at offset24, t99's collapse accumulation at uint32(v1),
and t116's ordinary bin update at uint32(v3). Original first checks, read/write
positions, numeric operands and rounding, endian/nosplit and checked fallback
remain. No production hardener, generated artifact, lock, facade, runtime,
public API or Wasm source was changed.

Matching ordinary machine code confirms three fewer static bounds-panic
sites in fn176 (78 → 75), seven fewer instructions (1309 → 1302), and native
text 5462 → 5430 bytes. Its frame stays 128 bytes. Static regalloc counts stay
37 StoreReg /137 LoadReg; their dumps differ, so this is not a claim of
identical register allocation or a proven spill reduction. Recheck restores
the guarded totals; it does not recreate a byte-identical full binary.

The 27 SSA dumps inspect three methods × three stages × three roles:
fn176, SQL fn96, and the scalar export Xcocoon_sketch_add. The fn96 and
scalar-export optimized/regalloc/genssa dumps are byte-identical across roles.
Their inspected machine counts, frames and sizes are unchanged. An SQL-export
SSA dump is not part of this recorded set and should not be claimed.

Original SQL nevertheless improves 2167 → 2118 ns (−2.26%, p=.010), then
2147 → 2120 ns (−1.26%, p=.001). These cannot be directly attributed to
three deleted fn176 checks, which are not on the SQL execution path. The
copied-check SQL control also improves in confirmation (−0.65%, p=.004).
Placement/compiler/control effects remain possible explanations, not proven
causes or a scalar-hypothesis rescue. Varied SQL's screen-only −0.41% detected
shift fails confirmation; SQL holdout has no detected benefit.

Matched repeated1024 batch improves −0.86% (p=.007) in screen, but confirmation
−0.63% (p=.097) is undetected. Original batch, broad8192 batch and trace have
no repeated detected benefit. The four streaming comparisons explicitly use
the same unchanged `stream` binary for both labelled roles. They are temporal
brackets, not before/after streaming production comparisons; none establishes
a helper-induced streaming gain or loss.

## Proof scope

The ignored helper execution proof passes native amd64 and386 with Go1.26.8,
CGO disabled and PGO off, including full bytes, float bits, logical-length
traps/prefixes, bounded addresses and safe header-barrier controls. The first
check deletion and header-crossing child mutants fail explicit semantic tests.
The canonical oracle correction and earlier native386 sandbox blocker are
preserved in its history. Simulated byte swapping is branch evidence, not real
big-endian execution; the oracle stays Wasm little endian on a real native
architecture. Original-Wasm payload contracts are separate parent-run proofs.

This validates the narrow helper equivalence at the pinned adjacent pairs.
Literal source selection and an ignored copied-helper harness do not prove
generic binding/type/effect/escape/ownership selection, nor qualify a production
pass. A phase-zero positive would still have required a separate specification,
authored executable WAT/native proof and full performance qualification. This
phase-zero result supplies no reason to start that production work.
