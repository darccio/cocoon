"""Ignored, whole-source-pinned adjacent read/write diagnostic; not a production pass."""
from pathlib import Path
import datetime, hashlib, json, os, re, subprocess
root=Path.cwd(); out=root/'.cache/scalar-next'; module=root/'examples/datadog/go/dd/internal/wasm/module.go'
source=module.read_bytes()
expected='626550cafa323c490a6a2ec6b2b341656c40e223c7c84701e414078633dcc298'
assert hashlib.sha256(source).hexdigest()==expected
text=source.decode()
helper=re.search(r'//go:nosplit\nfunc store64\[T uint32 \| uint64\]\(mem \[\]byte, addr T, val uint64\) \{.*?\n\}',text,re.S).group()
assert helper.count('\t_ = mem[uint64(addr)+7]\n')==1
assert helper.count('func store64[')==1
assert 'cocoonStore64AfterLoad' not in text
pairs=[('t82','uint64(uint32(v3))+24','math.Float64bits(float64(t82+float64(1)))'),('t99','uint32(v1)','math.Float64bits(float64(v2+t99))'),('t116','uint32(v3)','math.Float64bits(float64(t116+float64(1)))')]
modified=text; selected=[]
for variable,address,value in pairs:
 pattern=r'(?m)^(\t*)'+re.escape(variable+' := math.Float64frombits(load64(m.memory, '+address+'))')+r'\n\1'+re.escape('store64(m.memory, '+address+', '+value+')')+'$'
 matches=list(re.finditer(pattern,modified)); assert len(matches)==1,(variable,len(matches))
 old=matches[0].group(); new=old.replace('\n'+matches[0][1]+'store64(', '\n'+matches[0][1]+'cocoonStore64AfterLoad(',1)
 assert old.count('store64(')==1
 selected.append({'variable':variable,'address':address,'value':value,'before':old,'after':new,'line':modified[:matches[0].start()].count('\n')+1})
 modified=modified.replace(old,new,1)
checked=helper.replace('func store64[','func cocoonStore64AfterLoad[',1)
variants={'probe':modified+'\n'+checked.replace('\t_ = mem[uint64(addr)+7]\n','',1)+'\n','recheck':modified+'\n'+checked+'\n'}
for role,content in variants.items():
 filename=out/(role+'-module.go'); filename.write_text(content)
 (out/(role+'-overlay.json')).write_text(json.dumps({'Replace':{str(module):str(filename)}},indent=2)+'\n')
(out/'probe-inventory.json').write_text(json.dumps({'production_source_sha256':expected,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'helper_source':helper,'selected':selected,'variants_sha256':{role:hashlib.sha256(content.encode()).hexdigest() for role,content in variants.items()},'scope':'Only three literal whole-source-hash-pinned adjacent pairs. No generic selection or retained generated-module edit. Original first checks/read/write/arithmetic/order, endian/nosplit/portable fallback remain. Prototype candidate and copied-check control differ by the single copied unsafe endpoint guard line. Production runtime/facade/harness/Wasm unchanged.'},indent=2)+'\n')
go='/usr/lib64/go/1.26/bin/go'; env=dict(os.environ,GOTOOLCHAIN='local',CGO_ENABLED='0',GOAMD64='v1',GOCACHE=str(root/'.cache/go'),GOFLAGS='-buildvcs=false')
records=[]
def run(name,args):
 record={'name':name,'argv':args,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (out/(name+'.log')).open('x') as log:
  print('COMMAND',json.dumps(args),file=log,flush=True)
  result=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
  print('EXIT',result.returncode,file=log,flush=True)
 record.update(exit=result.returncode,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()); records.append(record)
 (out/'variant-build-records.json').write_text(json.dumps(records,indent=2)+'\n'); assert result.returncode==0,name
 print('PASS',name,flush=True)
for role in ('baseline','probe','recheck'):
 overlay=[] if role=='baseline' else ['-overlay='+str(out/(role+'-overlay.json'))]
 run(role+'-whole-oracles',[go,'test','-pgo=off',*overlay,'./examples/datadog/go/dd/...','-count=1'])
 run(role+'-compile',[go,'test','-c','-pgo=off',*overlay,'-o',str(out/(role+'.test')),'./examples/datadog/go/dd'])
run('stream-oracles',[go,'test','-pgo=off','./testdata/streaming/go/streaming/...','-count=1'])
run('stream-compile',[go,'test','-c','-pgo=off','-o',str(out/'stream.test'),'./testdata/streaming/go/streaming'])
records.append({'binaries_sha256':{role:hashlib.sha256((out/(role+'.test')).read_bytes()).hexdigest() for role in ('baseline','probe','recheck','stream')}})
(out/'variant-build-records.json').write_text(json.dumps(records,indent=2)+'\n')
assert hashlib.sha256(module.read_bytes()).hexdigest()==expected
print('PASS diagnostic oracles/builds; production unchanged',flush=True)
