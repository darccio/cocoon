# Final pinned scalar-next proof/matrix audit, 2026-10-12

Approve the current phase-zero diagnostic for isolated timing after root refreshes config/freezes final notes and corrected proof hashes. No unresolved source/proof/matrix blocker. No production pass or public contract approved; no broadening of retained predicates. Reviewer used only read-only source/data analysis and ignored-note writes: no builds/tests/lint/profiles/benchmark execution.

## Executable proof and limits

Independent oracle uses binary decoding/encoding plus explicit logical range checks, not unsafe endpoint helpers. It compares loaded/result bits, full current and old backing bytes, logical lengths, trap stage, completed-write prefixes and header events. Twenty-six scenarios cover exact/short/zero and spare-capacity logical lengths, unaligned access, high/negative/wrapped/widened addresses, +24 maximum, rounding/signed-zero/subnormal/extreme values, header shrinking/replacement and spare-capacity/reallocation growth. Generated address domain is at most MaxUint32+24, endpoint at most2^32+30; no uint64 endpoint wrap occurs. Helper proof preserves existing floating expressions; it does not independently prove new math against Wasm or a generic selection algorithm. Actual pinned DD overlays retain original-Wasm/contract oracles separately.

Parent TestSemanticMutants requires child nonzero, explicit TestMutantProbe failure, and byte/trap mismatch marker; startup/compile/hardware failures alone cannot pass rejection. First-check deletion and header-crossing mutants demonstrably fail semantic assertions using accessible spare backing, avoiding physical out-of-allocation memory. Completed native amd64/386 logs both end PASS and contain two child mismatch/rejection markers plus parent TestSemanticMutants PASS. Exact current source and proof executable hashes match source-provenance; actual DD native386 metadata pins exact overlay/source/log and exit0. Earlier sandbox native386 SIGSYS159 before tests is honestly preserved, separate from corrected-source unsandboxed success.

Review found and closed a future-architecture oracle defect: canonical helpers must always compare against LittleEndian because real big-endian loads/stores reverse native words to preserve Wasm bytes. Current TestCanonicalHelpers removes the erroneous BigEndian override. Only separately named mutable-flag branch simulation uses a BigEndian oracle on this little-endian host; it is not native big-endian execution evidence. Both current native targets were rebuilt/rerun after this proof-only correction; prior proof sources/logs/binaries/provenance are preserved. No real arm64/big-endian execution or performance claim follows.

## Matrix and freeze

Current17 groups have12 DD leaves×4 roles, rawGuest×3, four unchanged-stream brackets×2:59 invocations/pass; seven500ms alternating plus seven reversed1s passes=826 rows/118 role-round cells. Existing harnesses byte-equal20e33db, no added benchmark source; current production/Wasm/facade/runtime unchanged. Exact baseline ordinary binary reproduces74af290…; probe/recheck alter only the three pinned adjacent fn176 store calls and cloned store64 guard. Full-source hash and copied canonical endian/nosplit/fallback proof remain diagnostic-only.

Twenty measured matched leaves assert actualP1 (280 eventual rows), eight stream cases assertP16 (112),31 original/raw leaves lack in-window metric (434); framework suffix alone is not proof. Same byte-identical streaming binary is explicitly recorded in both baseline/probe bracket roles; these are control/system variation, never a candidate streaming effect. No inherited318/99/20 production-selection or qualification claim remains. Source/config writer pins current scripts (including.sh/.mod/.sum), overlays, all logs/journals/profiles,27 SSA dumps and both proof executables, excluding reference Cargo target. Root refreshes config after this note and correction; no stale proof fingerprint is approved.

Reference ABI/context/topology and original batch/trace inputs differ, increasing calibrated prefixes evolve state, and layer/profile shares overlap. No additive safety/reply ceiling arithmetic or per-check causal estimate. Preserve all raw/negative samples and static code/frame/placement costs. Public typed-return ABI requires operator approval; M1 remains unaccepted until full criteria actually pass. All reviewer tools stopped after this note.

## Reviewed identities

{
  "prepare-probe.py": "10ebe41d3108314c348f6c3a67087a42a2d23565491676671ca4e3a93d929bdd",
  "probe-module.go": "a950ffaa5265b887ef57ae03ee06aa1ae20255a1eea4d9a9bfb2fea9d7f97db4",
  "recheck-module.go": "20b84ad1c3afa610ae3c485454564d280fb2deada6fa3b9d2df1b085516729f0",
  "probe-inventory.json": "c0395bf105277f75bd4f07b5152d1286afc737069a2c2a0891445cec8e4e2eb7",
  "qualification-plan.json": "11cb4e52638035171a7ba2a9fb25ec3d71212e26b643c92d980791dbf45af2b4",
  "prepare-config.py": "7063a86afb2158090227689187dbebd5c9b64edabf1b8b8d54d38fd7dde67223",
  "proof/proof_test.go": "0ce1b11b00605bd43dba37e08d4787e729ca9120af1e61a7a67d6b83f0d22aea",
  "proof/helpers.go": "7a4ec913bb33bd92c016ae94bb7537056643b0fa153195b251a597759e7b0961",
  "proof/branch_helpers.go": "4eb8c3a13d5f7163179611c6235441294f3d2be480a0102159df661a768f4ede",
  "proof/source-provenance.json": "158169a1c9934e3cd58095b806d59a3e728e9a54586bb466ebc30f75c7b3f043",
  "proof/run-native.sh": "3448a14a0f038f986baa3f3759de751103f8e49a5a3f6df6302c0c890a759c7d",
  "proof/native-amd64.log": "d83fcd150c9d13c1a7a260d6bbe45043c55e4d317170a78dd9315894d13c4018",
  "proof/native-386-unsandboxed.log": "d83fcd150c9d13c1a7a260d6bbe45043c55e4d317170a78dd9315894d13c4018",
  "native386-oracle-record.json": "b12e62f5d85663242752eeabb8688344eeefdf148937bbb12fff634e7f2fdf66"
}
