"""Verify complete diagnostic samples and produce explicit comparison aliases."""
from pathlib import Path
import argparse
import collections
import json
import statistics
import subprocess

from common import expected_count


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run", type=Path)
    parser.add_argument("--benchstat", type=Path, default=Path("/home/dario/go/bin/benchstat"))
    args = parser.parse_args()
    complete = json.loads((args.run / "complete.json").read_text())
    snapshot = json.loads((args.run / "frozen.json").read_text())
    plan = snapshot["plan"]
    rows = [json.loads(line) for line in (args.run / "records.jsonl").read_text().splitlines()]
    assert len(rows) == complete["rows"] == expected_count(plan, complete["mode"])
    groups = collections.defaultdict(list)
    for row in rows:
        raw = (args.run / row["raw"]).read_text()
        assert row["raw_row"] in raw and "EXIT 0" in raw
        groups[(row["round"], row["comparison"], row["role"])].append(row)
    selected_groups = [g for g in plan["comparisons"] if (g["kind"] == "startup") == (complete["mode"] == "startup")]
    rounds = [r["name"] for r in (plan["rounds"] if complete["mode"] == "warm" else plan["startup_rounds"])]
    samples = plan["samples"] if complete["mode"] == "warm" else plan["startup_trials_per_round"]
    summary, aliases = {}, []
    for rd in rounds:
        table = {}
        for group in selected_groups:
            entry, inputs, input_roles = {}, [], {}
            for case in group["cases"]:
                selected = groups[(rd, group["key"], case["role"])]
                assert len(selected) == samples and {r["sample"] for r in selected} == set(range(1, samples + 1))
                keys = set(selected[0]["metrics"])
                assert all(set(r["metrics"]) == keys for r in selected)
                values = {k: [r["metrics"][k] for r in selected] for k in sorted(keys)}
                entry[case["role"]] = {"samples": values, "medians": {k: statistics.median(v) for k, v in values.items()}}
                filename = args.run / f"{rd}-{group['key']}-{case['role']}-normalized.txt"
                alias = "BenchmarkComparison/" + group["key"] + "-" + str(plan["framework_procs"])
                with filename.open("x") as output:
                    output.write("goos: linux\ngoarch: amd64\npkg: backend-control-comparison\n")
                    for row in selected:
                        output.write(alias + row["raw_row"][len(row["name"]):] + "\n")
                aliases.append({"round": rd, "comparison": group["key"], "kind": group["kind"], "role": case["role"],
                                "binary": case["binary"], "original_parts": case["parts"], "alias": alias,
                                "notes": "Only derived benchmark name/package grouping change; metrics/raw names/process logs remain untouched."})
                inputs.append(str(filename))
                input_roles[case["role"]] = str(filename)
            baseline = entry[group["baseline_role"]]["medians"]["ns/op"]
            for role, result in entry.items():
                result["delta_percent_ns"] = 100 * (result["medians"]["ns/op"] / baseline - 1)
            table[group["key"]] = {"kind": group["kind"], "baseline_role": group["baseline_role"], "roles": entry}
            reports = [(group["key"], inputs)]
            for secondary in group.get("secondary_comparisons", []):
                reports.append((secondary["key"], [input_roles[role] for role in secondary["roles"]]))
            for report_key, report_inputs in reports:
                for suffix, options in (("benchstat.txt", []), ("time-benchstat.txt", ["-filter", ".unit:sec/op"]), ("benchstat.csv", ["-format=csv"])):
                    with (args.run / f"{rd}-{report_key}-{suffix}").open("x") as output, (args.run / f"{rd}-{report_key}-{suffix}.warnings").open("x") as warnings:
                        subprocess.run([str(args.benchstat), *options, *report_inputs], stdout=output, stderr=warnings, check=True)
        summary[rd] = table
    for filename, data in (("summary.json", summary), ("comparison-aliases.json", aliases)):
        with (args.run / filename).open("x") as output:
            json.dump(data, output, indent=2)
            output.write("\n")
    print("Complete samples verified. Startup values are compound first-call observations; benchmark aliases and exploratory unadjusted p-values imply neither acceptance nor equivalence.")


if __name__ == "__main__":
    main()
