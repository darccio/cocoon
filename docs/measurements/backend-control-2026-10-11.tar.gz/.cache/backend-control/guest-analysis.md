# Guest-side same-Wasm backend analysis

Qualification inputs: warm-run/summary.json plus every screen/confirm Warm time-benchstat report. Seven samples per role per round; screen 500ms, confirmation 1s with reversed role order. The two rounds report separate medians; no pooled estimate. All p-values below are exploratory and unadjusted. This is analysis of test adapters and frozen binaries, not a production optimization or supported backend comparison.

Every one of the 18 primary cross-backend groups detects higher time for CompiledWazeroStack than TranslatedGo in both rounds (p=0.001, n=7 in each report). No primary compiled-adapter win is detected. There is no scalar latency improvement, no pure guest/facade accounting and no M1 acceptance.

## Exact primary medians

All times are ns/op; deltas are CompiledWazeroStack relative to TranslatedGo. Allocations and Go bytes/op are median pairs Go / compiled stack, matching in screen and confirmation.

| Workload / role | Screen Go / compiled | Screen delta | Confirm Go / compiled | Confirm delta | Go bytes/op pair | Allocs/op pair |
|---|---:|---:|---:|---:|---:|---:|
| ScalarRepeated-RawGuest | 56.32 / 141.6 | +151.42% | 56.06 / 143.3 | +155.62% | 0 / 16 | 0 / 1 |
| ScalarRepeated-CheckedControl | 96.64 / 198.6 | +105.50% | 97.03 / 203.1 | +109.32% | 0 / 16 | 0 / 1 |
| ScalarIncreasing-RawGuest | 56.6 / 143 | +152.65% | 56.2 / 146.3 | +160.32% | 0 / 16 | 0 / 1 |
| ScalarIncreasing-CheckedControl | 97.34 / 201.7 | +107.21% | 97.92 / 200.2 | +104.45% | 0 / 16 | 0 / 1 |
| ScalarNegativeBins-RawGuest | 56.26 / 140.6 | +149.91% | 56.07 / 144.5 | +157.71% | 0 / 16 | 0 / 1 |
| ScalarNegativeBins-CheckedControl | 96.32 / 197.1 | +104.63% | 96.34 / 200.7 | +108.32% | 0 / 16 | 0 / 1 |
| ScalarBroadHoldout-RawGuest | 54.17 / 145 | +167.68% | 54.55 / 147.5 | +170.39% | 0 / 16 | 0 / 1 |
| ScalarBroadHoldout-CheckedControl | 97.68 / 202.3 | +107.10% | 98.43 / 203.2 | +106.44% | 0 / 16 | 0 / 1 |
| BatchRepeated1024-RawGuest | 39419 / 53906 | +36.75% | 39525 / 53470 | +35.28% | 0 / 32 | 0 / 2 |
| BatchRepeated1024-CheckedControl | 39774 / 53961 | +35.67% | 39596 / 53541 | +35.22% | 0 / 32 | 0 / 2 |
| BatchBroad8192-RawGuest | 319876 / 401430 | +25.50% | 320114 / 401739 | +25.50% | 0 / 32 | 0 / 2 |
| BatchBroad8192-CheckedControl | 319179 / 404893 | +26.85% | 321049 / 403439 | +25.66% | 0 / 32 | 0 / 2 |
| SQLOriginal-RawGuest | 1860 / 3531 | +89.84% | 1882 / 3516 | +86.82% | 48 / 80 | 1 / 3 |
| SQLOriginal-CheckedControl | 2186 / 3969 | +81.56% | 2236 / 4018 | +79.70% | 48 / 96 | 1 / 4 |
| SQLHoldout-RawGuest | 4886 / 9757 | +99.69% | 4922 / 9876 | +100.65% | 72 / 104 | 1 / 3 |
| SQLHoldout-CheckedControl | 5676 / 10972 | +93.31% | 5641 / 10639 | +88.60% | 72 / 120 | 1 / 4 |
| Trace1k-RawGuest | 2.69665e+06 / 4.29291e+06 | +59.19% | 2.67923e+06 / 4.29177e+06 | +60.19% | 212992 / 213024 | 1 / 3 |
| Trace1k-CheckedControl | 2.68856e+06 / 4.28727e+06 | +59.46% | 2.6759e+06 / 4.28085e+06 | +59.98% | 212992 / 213040 | 1 / 4 |

## Cached Call versus reusable CallWithStack

These reuse already-qualified samples rather than introduce new measurements. Direct pairwise benchstat commands use the saved CompiledWazeroStack-normalized and CompiledWazeroCall-normalized files. Call is the comparison role and Stack is the base.

| Workload | Screen Stack / Call ns | Call delta / p | Confirm Stack / Call ns | Call delta / p | Stack / Call bytes | Stack / Call allocs |
|---|---:|---:|---:|---:|---:|---:|
| ScalarRepeated | 141.6 / 178.3 | +25.92%, .001 | 143.3 / 176.9 | +23.45%, .001 | 16 / 32 | 1 / 2 |
| BatchRepeated1024 | 53906 / 53685 | -0.41%, .477 | 53470 / 53348 | -0.23%, .209 | 32 / 64 | 2 / 4 |

Reusable stack saves one allocation/16 bytes for repeated scalar and two allocations/32 bytes for repeated batch relative to cached Call in this adapter. Repeated scalar has a detected time benefit; repeated batch has no detected time change despite the allocation difference. These are scoped API controls, not evidence that all wazero calls inherently allocate or that removing allocations has the measured scalar timing effect by itself.

## Current memory and state

All 532 new warm rows have actual-procs=1 and guest-growth-B=0 in summary samples, including nonmedian samples. Guest-B is identical between roles within each workload: 1,179,648 bytes for scalar, repeated batch and SQL; 1,441,792 for broad batch; 2,359,296 for Trace1k. The fixed guest-B reflects warmed current linear memory, not total process heap, Rust live allocation, retained capacity, compilation cache, or native executable mappings.

Increasing scalar warms 8192 points (1 through 8192), then adds monotonically increasing new values (8193 onward). Its state evolves even though linear memory does not grow. Each calibrated engine runs a different length prefix; equal inputs/order means corresponding prefixes, not equal final logical bins/point counts. Count is checked exactly as 8192+N outside timing. Full protobuf correctness is independently proven for authored bounded histories, not for every multimillion-point timed history.

| Increasing role | Screen N range | Confirm N range |
|---|---:|---:|
| RawGuest/TranslatedGo | 10,397,688–10,705,758 | 20,647,210–21,422,419 |
| RawGuest/CompiledWazeroStack | 4,134,747–4,463,660 | 7,931,730–8,633,605 |
| CheckedControl/TranslatedGo | 5,926,144–6,236,355 | 11,547,789–12,112,016 |
| CheckedControl/CompiledWazeroStack | 3,065,088–3,166,338 | 5,891,022–6,324,747 |

Finite scalar corpora cycle after 8192 values; broad scalar and broad batch use distinct authored corpora. Batch point totals are len(values)*(N+1), with one ordered warm group before timing. The broad batch covers collapse through the existing scalar-Wasm oracle and tests. The observed zero timed growth does not prove stationary Count, bin contents, guest temporary allocations, or a general memory bound.

## Scope and attribution limits

- Both roles execute the same pinned production Wasm semantics; Go is the committed translated/hardened module. No math, payload, manifest, ABI, facade, public contract, generated artifact or lock changed for the comparison. The custom controls add function dispatch and can change inlining/link placement.
- RawGuest is a prepared multi-export adapter control. Scalar omits reserve/reply decoding; batch includes reserve and numeric encoding; SQL/trace include reserve, input copy, ordinary Go descriptor bounds checks, status interpretation and generated owned typed output decoding. None is pure execution-only guest cost.
- CheckedControl includes the actual Lifecycle, Resource, Instance and per-call canonical result/memory checks; SQL/trace use the actual lazy Pool and Recycle/Trim policy. It is a private common wrapper, not the generated facade. No subtraction of separate raw/checked medians estimates causal admission or facade shares.
- The compiled adapter caches api.Function and uses a reusable carrier; its call context is prepared with context.WithoutCancel and engine CloseOnContextDone(false). Observed retained allocations must be described as this adapter/context shape. A separate frozen-binary allocation diagnostic examines the context contribution; changing context shape and its effect on ns/op are not measured in qualification.
- Capability hosts and memory/globals are independent per guest. Factory-owned compilation caches hold immutable code; no disk cache. Guest output descriptor is queried an extra time only during test adapter setup, excluded from warm timing and included in the cold adapter construction scopes.
- Both engines retain owned SQL/trace output; Go allocations exclude Rust/Wasm allocations, native executable memory and total process memory. Compiled cold compile/instantiate scopes and translated cold construction scopes are compound and cannot be added or treated as interchangeable startup costs.
- Compiler comparisons are Linux/amd64 observations. Native 386 correctness skips unsupported compiled roles while retaining translated and original-Wasm interpreter proofs; it does not supply native386 compiler performance evidence.
- Exact expected errors, invalid tail atomicity, malformed reply poisoning, actual guest panic/log-import panic containment, stale epochs, alias closure, memory growth/limits, reset, cancellation and draining are proof prerequisites, not timed failure workloads. Engine-specific fault kinds/messages differ.

## Separate context-allocation diagnostic

Root authorized a 100000x allocation-only probe of the frozen current.test,
with memprofilerate=1, after all qualification timing completed. No source,
runtime config, input corpus or context shape changed. Its measured ns/op is
profiling overhead and is excluded from all qualification estimates.

The frozen binary is Go1.26.8. Existing installed Go1.24 pprof viewed its
profile without any installation/build; exact viewer/profile hashes and argv
are in guest-context-alloc-command.txt. Output is saved as
guest-context-alloc.{log,pprof}, plus list/top/bytes/objects .txt reports.

alloc_space attribution is 1,862,416 bytes flat at
context.withoutCancelCtx.Value, and alloc_objects attribution is 116,401
objects there: exactly 16 bytes per object. The profile includes setup,
warmup, testing's run1, the fixed run and cleanup; these totals are not a
timed-only byte count. The timed row separately retains 16 B/op and 1 alloc/op.
The caller chain is backendExport.invoke → wazevo.callEngine.CallWithStack →
callWithStack → context.withoutCancelCtx.Value.

Pinned source locations:

- wazero v1.12.0 internal/engine/wazevo/call_engine.go:242 queries
  ctx.Value(expctxkeys.EnableSnapshotterKey{}) on every call, even when
  CloseOnContextDone is false.
- Go1.26 context/context.go:592 defines withoutCancelCtx as one Context field
  (a two-word interface, 16 bytes on amd64).
- Go1.26 context/context.go:608–609 implements Value on a value receiver and
  passes that receiver to the Context interface accepted by value(c,key).
- The frozen test adapter deliberately prepares export contexts using
  context.WithoutCancel(ctx), outside timing, retaining test context values.

The profile directly locates the retained allocation at that receiver/interface
conversion. This is an adapter-context contribution interacting with the pinned
engine's Value query, not an unavoidable compiled-wazero allocation contract.
No Background/direct-context alternative was timed; no time is subtracted from
the qualified medians, and there is no estimate of how removing that allocation
would change any scalar, batch, SQL or trace comparison. The prepared adapter
comparison remains reproducible with its explicitly recorded context shape.
