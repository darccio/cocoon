from pathlib import Path
import os,subprocess,json,datetime,hashlib
root=Path.cwd();out=root/'.cache/backend-control'
config=json.loads((out/'qualification-config.json').read_text());cmd=config['build_records']['current']['command']
env=dict(os.environ,GOTOOLCHAIN='local',CGO_ENABLED='0',GOAMD64='v1',GOCACHE=str(root/'.cache/go'),GOFLAGS='-buildvcs=false')
record=dict(argv=cmd,cwd=str(root),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),environment={k:env.get(k,'default') for k in ['GOTOOLCHAIN','CGO_ENABLED','GOAMD64','GOCACHE','GOFLAGS','GOGC','GOMEMLIMIT','GODEBUG','GOEXPERIMENT']})
with (out/'current-build.log').open('x') as log:subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
record['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();record['sha256']=hashlib.sha256((out/'current.test').read_bytes()).hexdigest()
(out/'current-build.json').write_text(json.dumps(record,indent=2)+'\n')
print('PASS current frozen binary build',record['sha256'],flush=True)
