# Host evidence review — same-Wasm backend control

Reviewed after all timing, 2026-10-11. This note changes no authored source or
committed documentation. Approve retention as diagnostic evidence; no production
optimization, supported runtime backend, or M1 acceptance follows.

## Independent audit

All 117 frozen SHA-256 values match the current bytes. Warm/startup copied
snapshots equal the top-level freeze. Independently checked all 1,022 warm and
42 cold JSONL rows against their raw process files, successful exit/PASS, seven
samples per comparison/role/round, and every summary metric median. Every cold
row has exactly one iteration. Custom processor metrics: 672 matched warm rows
at P1, 56 streaming rows at P16, and all 42 cold rows at P1. The remaining 294
warm original/call-layer controls retain their existing policy and have no
in-window custom processor metric; the framework suffix is 16 for all cases.

Warm screening is seven alternating 500 ms samples; confirmation is seven
reversed-order 1 s samples. Cold is seven fresh-process 1x observations per
scope in each of two reversed-order rounds. Go1.26.8, linux/amd64, CGO0,
GOAMD64=v1, explicit PGO off, default GOGC/GOMEMLIMIT/GODEBUG, affinity CPUs
0–15, powersave governor, boost enabled. Dynamic frequencies are recorded.
Isolation is operator attestation, not proof of absence of unrelated system
work. Reported p-values are exploratory and unadjusted. Raw names are intact;
derived aliases join workload names for comparisons and do not change metrics.

The pinned production Wasm and translated Go hashes match the scope. All
production Go and existing benchmark sources are unchanged. Newly linked
private controls can affect code placement: these are refreshed measurements,
not a production before/after improvement. The fresh independent ABI2 spike
reproduces its prior Wasm, module, and binary byte-for-byte; its topology,
context, facade, and original batch/trace payload differences remain limits.

## Fresh references and M1

Times are current / independent reference; each cell is the exact sample
median, not a rounded benchstat transcription.

| Workload | Screen | Confirm | Current/reference overhead, screen / confirm |
| --- | --- | --- | --- |
| Original scalar | 88.80 / 55.67 ns | 88.14 / 55.64 ns | 59.511% / 58.411% |
| Original SQL | 2.260 / 1.976 µs | 2.237 / 1.966 µs | 14.372% / 13.784% |
| Varied scalar | 88.80 / 56.72 ns | 89.36 / 55.74 ns | See raw samples |
| Negative bins | 90.01 / 55.58 ns | 88.96 / 55.41 ns | See raw samples |
| Varied SQL | 2.903 / 2.524 µs | 2.826 / 2.532 µs | See raw samples |
| P1 SQL holdout | 5.727 / 5.252 µs | 5.695 / 5.058 µs | 9.044% / 12.594% |
| P1 increasing scalar | 89.38 / 57.63 ns | 89.40 / 56.47 ns | Evolving state |
| P1 broad scalar | 89.74 / 58.45 ns | 89.90 / 57.96 ns | See raw samples |
| Original batch 1k | 39.069 / 35.929 µs | 38.592 / 35.612 µs | Original payload caveat |
| P1 matched repeated 1024 | 39.962 / 37.098 µs | 39.627 / 36.493 µs | Identical matched points |
| P1 matched broad 8192 | 322.857 / 299.922 µs | 320.430 / 298.509 µs | Identical matched points |
| Original trace 1k | 2.736681 / 2.117528 ms | 2.693541 / 2.071231 ms | Original payload caveat |

Original scalar/SQL differences have p=.001 in both sets. M1 original absolute
limits remain **55.44 ns and 2.2154 µs**. Fresh 110% reference limits are
**61.237 ns / 2.1736 µs** in screening and **61.204 ns / 2.1626 µs** in
confirmation. Both current scalar and SQL exceed both applicable limits in
both sets. The holdout SQL margin moves across 10%; it is not an acceptance
substitute. Increasing roles run different calibrated prefixes and should not
be described as a stationary ratio. The summary's negative reference-versus-
current percentage is not the positive current-versus-reference overhead.

Original/current scalar and both matched batch controls report zero Go
allocations. Current original SQL has one allocation and median 57/52 B/op;
reference SQL has one and 79/64 B/op. Original current trace reports one and
255,563/233,893 B/op; independent trace reports two/one and 349,004/283,834
B/op. These are calibration-amortized Go heap measurements and differing
original trace inputs, not new production allocation changes.

## Current call layers and private backend controls

| Current translated layer | Screen ns | Confirm ns |
| --- | --- | --- |
| Raw guest | 54.25 | 54.07 |
| Checked instance | 72.11 | 72.52 |
| Resource ownership + checked instance | 82.08 | 82.35 |
| Generated facade | 90.06 | 89.84 |
| Empty checked instance callback | 15.73 | 15.81 |
| Empty resource callback | 24.87 | 25.07 |
| Empty lifecycle admission | 7.377 | 7.272 |

All these layers report zero Go allocations. Their separately timed deltas
are rough attainable ceilings, not additive admission/ownership/reply shares.
For example, confirmation facade minus guest is 35.77 ns, not proof that
removing one component realizes that saving. Empty callbacks exclude actual
guest/reply work. Private checked roles add dispatch and indirection and are
not generated-facade latency measurements.

Repeated scalar raw Go / wazero-stack is 56.32 / 141.60 ns in screening and
56.06 / 143.30 ns in confirmation. Private checked Go / wazero-stack is
96.64 / 198.60 ns and 97.03 / 203.10 ns. Wazero-stack has one 16-byte Go
allocation per measured scalar operation; Go has zero. Cached API Call adds
a second allocation (32 B/op total) and takes 178.30 / 176.90 ns. Compared
directly with stack, this is +25.92% / +23.45%, p=.001 in each set. The stack
carrier is reused but the measured engine call is not allocation-free; no
allocation-site or intrinsic-engine-cost attribution is established here.

Private checked SQL original Go / wazero-stack is 2.186 / 3.969 µs and
2.236 / 4.018 µs; holdout is 5.676 / 10.972 µs and 5.641 / 10.639 µs.
SQL raw still reserves, copies, reads current memory, checks status/bounds,
and decodes an owned result. Checked stateless work additionally exercises
the actual pool/recycling policy. SQL allocations are one for Go, three for
raw wazero, four for checked wazero; original checked bytes are 48 / 96 B/op,
holdout 72 / 120 B/op. These are not pure-export timings.

Private checked repeated batch Go / wazero-stack is 39.774 / 53.961 µs and
39.596 / 53.541 µs; broad batch 319.179 / 404.893 µs and
321.049 / 403.439 µs. Wazero-stack batch uses two allocations/32 B versus
zero Go. API Call batch uses four/64 B and has no detected timing difference
versus stack (screen p=.477, confirm p=.209); retain the extra allocations
without claiming a batch latency gain from stack.

Private checked trace Go / wazero-stack is 2.688565 / 4.287272 ms and
2.675899 / 4.280850 ms, one/212,992 B versus four/213,040 B per operation.
The private wrapper lacks poisoned-home replacement; containment and old-
handle invalidation are proved, while the healthy warm path has no recovery
event. Neither control is a supported backend. No measured family establishes
a wazero advantage in this harness.

Warm guest-memory observations match engines: 1,179,648 B scalar/repeated
batch/SQL, 1,441,792 B broad batch, 2,359,296 B trace, with measured timed
growth zero in every sample. This is logical memory of the measured guest,
not RSS or total retained memory. Stateless checked setup also retains an
unused home, while its module metric samples the pool guest. Cached code,
oracles, test framework, and native executable mappings are excluded.

## Cold compound scopes

| Fresh-process single-operation scope | Screen / confirm median | Go B/op | Go allocations/op |
| --- | --- | --- | --- |
| Translated construction + identity/init/close | 71.005 / 59.723 µs | 1,120,368 | 117 |
| Uncached runtime + compile + compiled/runtime close | 221.801677 / 221.121024 ms | 42,943,368 | 79,218 |
| Cached compile + runtime/import setup + instantiate + identity/init/close | 4.202519 / 4.302899 ms | 2,095,128 | 9,138 |

The Go construction samples span 50.596–245.257 µs screen and
35.858–102.766 µs confirm; single observations are noisy. Wazero uncached
compilation does not instantiate a module. Cached construction owns a fresh
runtime but seeds and retains the same-Wasm compilation cache/code/runtime
outside timing; cache disposal is outside the measured guest close. Both
construction controls include private adapter setup and an extra Output
export after rt.NewInstance, and wazero also caches functions/signatures.
Do not subtract these independently measured scopes to recover compilation,
instantiation, or initialization shares or claim production startup.

Constructed logical memory is 1,114,112 B in both construction roles. **Cold
guest-growth-B=0 is emitted by passing final guestBytes as both before and
after; it does not measure construction-time memory growth.** Go heap totals
exclude native executable mappings and are not retained-footprint bounds.

## Four streaming controls

P16, 64-byte nominal chunks, 16 KiB input per complete stream, owned output
references retained in groups of 32. Times include NewStream, every Write,
End, Close, result allocation/retention and accounting. Open/home warmup and
full byte validation are outside timing. Sixteen-home roles use standalone
methods; N32 labels describe output-group retention, not typed Batch execution.

| Corpus / homes | Screen / confirm µs/stream | Screen / confirm streams/s | Screen / confirm writes/s |
| --- | --- | --- | --- |
| Fixed / one | 189.982 / 190.091 | 5,264 / 5,261 | 1,347,495 / 1,346,721 |
| Fixed / sixteen | 25.972 / 28.161 | 38,504 / 35,510 | 9,856,901 / 9,090,607 |
| Holdout / one | 226.624 / 230.585 | 4,413 / 4,337 | 1,515,727 / 1,489,689 |
| Holdout / sixteen | 33.534 / 34.670 | 29,820 / 28,844 | 10,243,313 / 9,907,774 |

Ratios of displayed median write rates are fixed 7.315× / 6.750× and holdout
6.758× / 6.651×. These are current observed throughput rates, not strict
ceilings or a refreshed original-before/after comparison. Faster writes/s
for a holdout does not mean faster streams: fixed has 256 writes + End;
holdout varies widths, including empty writes, and averages 343.5 writes +
End. It emits 344.5 outputs/stream versus fixed 257. Each raw metric is
reported independently and rounded, so reciprocals/products of displayed
medians can differ slightly. Fixed owned bytes/stream are 16,392, holdout
median 16,390; retention groups are 9/11 and Go allocations 250/268.
Median B/op one-home fixed is 17,515/17,508; sixteen-home fixed 17,496 both;
one-home holdout 19,622/19,618; sixteen-home holdout 19,604 both.

No default streaming regression or previous feature gain is newly accepted
from these single-role controls. Configured home count is a concurrency
option, not a bound on RSS, guest capacity, or lifetime resource population.

All reviewer work in this note occurred after timing. No new builds, tests,
profiles, benchmarks, or source/documentation edits were performed.
