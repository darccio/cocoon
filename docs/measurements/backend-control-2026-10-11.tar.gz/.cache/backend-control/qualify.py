from pathlib import Path
import os, subprocess, json, hashlib
root=Path.cwd();out=root/'.cache/backend-control'
env=dict(os.environ,GOTOOLCHAIN='local',CGO_ENABLED='0',GOCACHE=str(root/'.cache/go'),GOFLAGS='-buildvcs=false',GOLANGCI_LINT_CACHE=str(root/'.cache/lint'),RUSTUP_TOOLCHAIN='1.97.0')
env['PATH']=str(root/'.cache/binaryen/binaryen-version_133/bin')+':'+os.path.expanduser('~/.cargo/bin')+':'+env['PATH']
lint=str(root/'.cache/sessions-phase0/golangci-lint-2.13.1-linux-amd64/golangci-lint')
def run(name,args,extra=None):
 with (out/(name+'.log')).open('w') as log:
  print('COMMAND',json.dumps(args),file=log,flush=True)
  subprocess.run(args,env=env if extra is None else dict(env,**extra),stdout=log,stderr=subprocess.STDOUT,check=True)
 print('PASS',name,flush=True)
for gate in ['check','race','rust','cross','smoke','fuzz','integration']:
 run('gate-'+gate,['make',gate,'GOLANGCI_LINT='+lint])
roots=['testdata/compute','examples/datadog','testdata/streaming','rt/instance.go']
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','--',*roots],text=True).splitlines()
def fingerprints(): return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
expected=fingerprints();(out/'proof-before.json').write_text(json.dumps(expected,indent=2)+'\n')
for repeat in [1,2]:
 for fixture in ['testdata/compute','examples/datadog','testdata/streaming']:
  run('repeat'+str(repeat)+'-'+fixture.split('/')[-1],['/usr/bin/go','run','./cmd/cocoon','build','--manifest',fixture+'/cocoon.toml'])
 run('repeat'+str(repeat)+'-runtime',['/usr/bin/go','generate','./rt'])
 assert fingerprints()==expected
 print('PASS repeat',repeat,len(paths),'proof/runtime/harness files unchanged',flush=True)
(out/'proof-after.json').write_text(json.dumps(fingerprints(),indent=2)+'\n')
run('stream-compile',['/usr/lib64/go/1.26/bin/go','test','-c','-pgo=off','-o',str(out/'stream.test'),'./testdata/streaming/go/streaming'],{'GOAMD64':'v1'})
print('PASS all gates/proof reproduction/stream freeze',flush=True)
