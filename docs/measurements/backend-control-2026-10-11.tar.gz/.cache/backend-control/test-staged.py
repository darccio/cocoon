from pathlib import Path
import os, subprocess, tarfile, tempfile, json, sys, shutil
root=Path.cwd();out=root/'.cache/backend-control';tree=(out/'staged-tree').read_text().strip()
assert len(tree)==40 and all(c in '0123456789abcdef' for c in tree)
if len(sys.argv)>1 and sys.argv[1]=='reuse':
 snapshot=Path((out/'staged-snapshot').read_text().strip())
 assert snapshot.parent==Path('/tmp') and snapshot.name.startswith('cocoon-translation-staged-')
 shutil.rmtree(snapshot);snapshot.mkdir()
else:
 snapshot=Path(tempfile.mkdtemp(prefix='cocoon-translation-staged-',dir='/tmp'))
archive=out/'staged.tar'
with archive.open('wb') as log: subprocess.run(['git','archive',tree],stdout=log,check=True)
with tarfile.open(archive) as log: log.extractall(snapshot,filter='data')
(out/'staged-snapshot').write_text(str(snapshot)+'\n')
env=dict(os.environ,GOTOOLCHAIN='local',CGO_ENABLED='0',GOCACHE=str(root/'.cache/go'),GOFLAGS='-buildvcs=false',GOLANGCI_LINT_CACHE=str(root/'.cache/lint'))
packages=['./...','./testdata/compute/go/compute/...','./testdata/streaming/go/streaming/...']
commands=[['/usr/bin/go','test',*packages],['/usr/lib64/go/1.26/bin/go','test','./rt','./internal/gen/gogen','./examples/datadog/go/dd/...','./testdata/compute/go/compute/...','./testdata/streaming/go/streaming/...','-count=1'],['/usr/bin/go','vet',*packages]]
linter=str(root/'.cache/sessions-phase0/golangci-lint-2.13.1-linux-amd64/golangci-lint')
commands.extend([[linter,'fmt','--diff',*packages],[linter,'run',*packages]])
with (out/'staged-test.log').open('w') as log:
 for args in commands:
  print('COMMAND',json.dumps(args),file=log,flush=True)
  subprocess.run(args,cwd=snapshot,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
  print('PASS',' '.join(args[:3]),flush=True)
print('Validated staged tree',tree,'at',snapshot,flush=True)
