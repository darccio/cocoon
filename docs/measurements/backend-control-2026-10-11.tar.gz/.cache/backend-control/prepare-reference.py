import argparse
parser = argparse.ArgumentParser(description="Fresh independent spike rebuild; requires parent authorization.")
parser.add_argument("--execute-build", action="store_true")
args_gate = parser.parse_args()
if not args_gate.execute_build:
    parser.error("No build or oracle execution without --execute-build and parent authorization")
from pathlib import Path
import hashlib, json, os, subprocess
from recorded_command import run

root = Path.cwd()
out = root / '.cache/backend-control'
spike = Path('/home/dario/Code/cocoon-spike')
binaryen = root / '.cache/binaryen/binaryen-version_133/bin'
env = dict(os.environ, CGO_ENABLED='0', GOTOOLCHAIN='local', GOAMD64='v1', GOCACHE=str(root/'.cache/go'), GOFLAGS='-buildvcs=false')
raw = out / 'reference-rust/wasm32-unknown-unknown/release/cocoon_dd_shim.wasm'
with (out/'reference-prepare.log').open('x') as log:
    with (out/'reference.graph.json').open('w') as graph:
        run(['python3',str(spike/'tools_exports.py'),str(raw)],stdout=graph,check=True)
    features=['--enable-bulk-memory','--enable-sign-ext','--enable-nontrapping-float-to-int','--enable-mutable-globals','--enable-reference-types','--enable-multivalue']
    run([str(binaryen/'wasm-metadce'),str(raw),'--graph-file',str(out/'reference.graph.json'),'-o',str(out/'reference.dce.wasm'),*features],stdout=log,stderr=subprocess.STDOUT,check=True)
    run([str(binaryen/'wasm-opt'),'-O3',*features,str(out/'reference.dce.wasm'),'-o',str(out/'reference.final.wasm')],stdout=log,stderr=subprocess.STDOUT,check=True)
    run(['/usr/bin/go','tool','wasm2go','-unsafe','-pkg','ddwasm','-o',str(out/'reference-module.go'),str(out/'reference.final.wasm')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    run(['python3',str(spike/'tools_harden.py'),str(out/'reference-module.go')],stdout=log,stderr=subprocess.STDOUT,check=True)
    varied=(root/'examples/datadog/go/dd/varied_bench_test.go').read_text().replace('openTest(b, Options{Instances: 1})','open(b)').replace('openTest(t, Options{Instances: 1})','open(t)')
    negative=(root/'examples/datadog/go/dd/negative_bench_test.go').read_text().split('func TestSketchNegativeBinBenchmarkCorpus')[0].replace('openTest(b, Options{Instances: 1})','open(b)')
    (out/'reference-varied_test.go').write_text(varied)
    (out/'reference-negative_test.go').write_text(negative)
    source=(root/'examples/datadog/go/dd/batching_bench_test.go').read_text()
    values=source[source.index('func batchingValues('):source.index('func batchingAdd(')]
    matched='''package dd
import ("fmt";"math";"runtime";"testing")
'''+values+'''
func BenchmarkSketchMatchedBatch(b *testing.B) {
for _,corpus:=range []string{"Repeated","Nearby","Unique","NegativeBins","Holdout"} {
for _,size:=range []int{1,32,1024,8192} {
for _,mode:=range []string{"Scalar","Facade"} {
b.Run(fmt.Sprintf("%s/N%d/%s",corpus,size,mode),func(b *testing.B){
previous:=runtime.GOMAXPROCS(1);b.Cleanup(func(){runtime.GOMAXPROCS(previous)})
library:=open(b);sketch,err:=library.NewSketch();if err!=nil{b.Fatal(err)}
b.Cleanup(func(){if err:=sketch.Close();err!=nil{b.Error(err)}})
values:=batchingValues(corpus,size)
add:=sketch.AddMany
if mode=="Scalar" {add=func(vs []float64)error{for _,v:=range vs{if err:=sketch.Add(v);err!=nil{return err}};return nil}}
if err:=add(values);err!=nil{b.Fatal(err)}
b.ReportAllocs();b.ResetTimer()
for b.Loop(){if err:=add(values);err!=nil{b.Fatal(err)}}
b.StopTimer()
if runtime.GOMAXPROCS(0)!=1{b.Fatal("actual processor mismatch")}
b.ReportMetric(1,"actual-procs");b.ReportMetric(float64(size),"points/op")
b.ReportMetric(float64(size)*float64(b.N)/b.Elapsed().Seconds(),"points/s")
if count,err:=sketch.Count();err!=nil||count!=float64(size)*float64(b.N+1){b.Fatal("count mismatch",count,err)}
})
}}}}
'''
    (out/'reference-matched_test.go').write_text(matched)
    bin_source=(root/'examples/datadog/go/dd/bin_reuse_bench_test.go').read_text().split('// This interface')[0]
    bin_source=bin_source.replace('len(sketch.guest.module.Memory())','0')
    bin_source=bin_source.replace('"math"','"math";"fmt"')
    bin_source += '\nfunc benchmarkSketch(b *testing.B) (*Sketch, int64) {\n b.Helper();library:=open(b);sketch,err:=library.NewSketch();if err!=nil {b.Fatal(err)}\n b.Cleanup(func(){if err:=sketch.Close();err!=nil {b.Error(err)}});return sketch,0\n}\nfunc batchingProcessors(b *testing.B, processors int) {\n b.Helper();previous:=runtime.GOMAXPROCS(processors);b.Cleanup(func(){runtime.GOMAXPROCS(previous)})\n if runtime.GOMAXPROCS(0)!=processors {b.Fatal("actual processor mismatch")}\n}\nfunc batchingMetrics(b *testing.B, points, processors, before, after int) {\n b.Helper();if runtime.GOMAXPROCS(0)!=processors {b.Fatal("actual processor mismatch")}\n b.ReportMetric(float64(processors),"actual-procs");b.ReportMetric(float64(points),"points/op")\n b.ReportMetric(float64(points)*float64(b.N)/b.Elapsed().Seconds(),"points/s")\n}\nfunc TestBinReuseMatchedReferenceCount(b *testing.B) {}\n'
    bin_source=bin_source.replace(';"fmt"','')
    bin_source=bin_source.replace('func TestBinReuseMatchedReferenceCount(b *testing.B) {}','')
    (out/'reference-bin-reuse_test.go').write_text(bin_source)
    holdout=(root/'examples/datadog/go/dd/translation_bench_test.go').read_text().split('func TestTranslationSQLHoldout')[0]
    holdout=holdout.replace('\n\t\"dario.cat/cocoon/cocoontest\"','').replace('\n\t\"dario.cat/cocoon/rt\"','').replace('openTest(b, Options{Instances: 1})','open(b)')
    (out/'reference-translation_test.go').write_text(holdout)
    overlay={'Replace':{
        str(spike/'go/dd/translation_bench_test.go'):str(out/'reference-translation_test.go'),
        str(spike/'go/internal/ddwasm/module.go'):str(out/'reference-module.go'),
        str(spike/'go/dd/testdata/shim.wasm'):str(out/'reference.final.wasm'),
        str(spike/'go/dd/varied_bench_test.go'):str(out/'reference-varied_test.go'),
        str(spike/'go/dd/negative_bench_test.go'):str(out/'reference-negative_test.go'),
        str(spike/'go/dd/matched_bench_test.go'):str(out/'reference-matched_test.go'),
        str(spike/'go/dd/bin_reuse_bench_test.go'):str(out/'reference-bin-reuse_test.go'),
    }}
    overlay_path=out/'reference-overlay.json';overlay_path.write_text(json.dumps(overlay,indent=2)+'\n')
    args=['/usr/lib64/go/1.26/bin/go','test','-modfile='+str(root/'.cache/reference.mod'),'-overlay='+str(overlay_path),'-pgo=off']
    run([*args,'./dd','-count=1'],cwd=spike/'go',env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    run([*args,'-c','-o',str(out/'reference.test'),'./dd'],cwd=spike/'go',env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    run([str(out/'reference.test'),'-test.run=^$','-test.bench=^BenchmarkSketch(MatchedBatch|BinReuse)$','-test.benchtime=1x'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
paths=[spike/'shim/Cargo.lock',spike/'shim/src/lib.rs',out/'reference.final.wasm',out/'reference-module.go',out/'reference.test']
(out/'reference-provenance.json').write_text(json.dumps({'sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'spike_head':'unversioned local source snapshot; no .git present', 'source_sha256':{str(p.relative_to(spike)):hashlib.sha256(p.read_bytes()).hexdigest() for area in ['shim','rust/cocoon-guest','rust/patches','go/dd','go/rt','go/internal/testpayload'] for p in sorted((spike/area).rglob('*')) if p.is_file() and p.suffix in ['.go','.rs','.toml','.lock']} ,'notes':'Independent original Rust/Cargo ABI2; fresh std,panic_abort Rust1.97 build; Binaryen133 metaDCE/O3; wasm2go0.4.16 unsafe; reference own hardener. Four instances/background context original benchmarks; P1 matched added harness copies corpora only; no source changes or Cocoon implementation transplanted.'},indent=2)+'\n')
print('Reference rebuilt, original/wazero tests and matched one-iteration oracle passed.',flush=True)
