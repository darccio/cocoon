# Adversarial retention review: fast certified interval costs

Verdict: **READY to retain documentation and exact diagnostic evidence; economic NO-GO.** This is a read-only audit after all measurements. No production implementation, new public contract, performance acceptance, source retuning, or selected retiming follows from this round. M1 remains unaccepted.

I reconciled all 546 raw rows, each raw benchmark's custom metrics and actual P1 setting, all 39 scopes with seven samples in each of the two sets, the exact replay fixed-prefix iteration counts, all derived summary medians, and all 48 comparison aliases/median changes/p-values. The aliases retain the seven original ns/input observations. Forty-seven p-values are .001; screening Increasing versus Disabled is .004. These are exploratory unadjusted comparisons, not independent evidence of whole-caller acceptance.

The predeclared economics rule fails. Increasing Enabled is 36.96/33.51 ns/input versus Direct 14.39/14.32, a 156.85%/134.01% loss. Its screening reduction against Disabled is only 9.875640%, below the required 10%, although confirmation reaches 16.93%. Every other seven corpora loses against Direct in both sets at the declared 2% rule; Unique, MostlyUnique, Phases, Broad and Negative also lose against Disabled in both sets. Repeated/Nearby gains versus Disabled cannot replace the mandatory Direct comparison. Their one initial cold miss is now accurately described as near-perfect reuse. No policy rescue or retuning is retained.

The native numerical proof is positive within its stated domain and budgets. Both actual amd64 and 386 healthy core/reference/consumer logs pass. The finite ledger is 15,908 whole evaluations per architecture, including 114 tiny members, and 521 fresh original-Wasm singleton requests. It remains below 16,384/262,144/2,048; full 4M/8M replay work is a separately declared ledger. Consumer JSONL on each architecture has 521 original-Wasm observations, 92 candidate attempts, 57 independently verified accepted traces, and the same bank/program identity. All nine compiled numerical mutants on each architecture have actual exit 1, the exact NUMERICAL_MUTANT marker and a failed runtime assertion; compiler/startup failures receive no numerical credit.

All 32 complete replay summaries cover eight corpora and both fixed prefixes on both native architectures. Direct and Disabled calls each equal N; hits plus misses equal N; proposals are at most 5N; refinement counts sum to proposals; every miss either installs or falls back; fatal counts are zero; and corresponding architecture counts/digests are identical. This is 100,663,296 input items per architecture. The full lockstep/digest check is finite consistency evidence, not the universal containment proof or a complete-prefix Wasm replay.

The component medians, zero-allocation individual candidate/lookup/replay observations, the native bank's real one allocation of 4,864 bytes, expensive independent checker/reference observations and preparation costs are all retained. Native and reference scopes have different argument/control/loop work, so their timings are not added or subtracted as a whole-caller prediction. O-H is negative in the explicit illustrative reuse model. Builder workspace plus observer-export capacity is distinguished from summary JSON allocations, big-number/AST heap, RSS and stack frames. Compiler observations preserve the explicit arithmetic/FMA witness and extra generated text/frame costs.

All 108 frozen inputs remain byte-identical, all nine original proof-source hashes remain exact, and the 61 production fingerprints agree before and after qualification. All 15 recorded quality/reproduction commands have exit 0: seven gates plus two repeats of all three proof builds and the shared runtime generation. This qualifies unchanged production and separately tested diagnostic code; it does not promote a production cache. Historical streaming rates are clearly labeled, not newly measured gains or strict capacity limits. No scalar/SQL/batch/stream/M1 improvement is claimed from these pure mapping results.

I reread the corrected performance, roadmap and readable measurement summary. The two requested corrections are present: near-perfect reuse and the parenthesized (15+24) x7 x2 =546 sample count. The private signed specification is unchanged. Links, private-versus-production status, all adverse controls, standalone scope, statistical limitations and no-go disposition are coherent.

Archive preparation review: archive.py captures private authored/generated Go, module/config/driver sources, raw/derived samples, proof/mutant/gate logs and all review notes with per-payload byte lengths and SHA-256. Its archive is regular-file-only, checks unique safe relative paths, exact manifest identity and every payload's bytes/hash in memory, and rejects unexpected row count or M1 acceptance. Caches, executables and unmodified production payload modules are deliberately omitted; identities and reproducible source are retained. The compressed archive is not yet created, so this verdict covers the packager and its current input coverage; an independent post-packaging member/checksum audit remains required.

No remaining retention blocker. All tools stopped after writing this separate note. Frozen proof files and the earlier implementation review were not edited.

Reviewed identities:

- `docs/performance.md`: `42a2a1d776718c1efdf5ba6b8fd701faa01d54d025822b53669fe882964881f1`
- `docs/roadmap.md`: `cab5d4ac266d416b3a1ee71720380e0314291fc7ef9577ee3816610bba80fbe2`
- `docs/fast-certified-interval-cost.md`: `d557897390ddac943f0452d9a640608151ea250632d8dbab3f62b71c7b5ef0f8`
- `docs/measurements/fast-certified-interval-cost-2026-10-12.md`: `5f77a1784111b1decf157226f802ae96c1632a81e0c59d63142f00aa177211b6`
- `.cache/fast-interval-phase0/archive.py`: `82efe67c5253e91aea5007c6e8cfe5b29dd49f3c8ca1cc71aa17033b9ba922d2`
- `.cache/fast-interval-phase0/adversarial-implementation-review.md`: `7d6dc52a4c9ff523418eae84ca563a344f4b94aa3ee90fe8c969a77348372f0e`
- `.cache/fast-interval-phase0/cost-rows.jsonl`: `0eb8293fd63680b60bc5bf28b1bc29248405671a550300614d725ff8f1f0da57`
- `.cache/fast-interval-phase0/replay-statistics.json`: `cea7373f4cc331bb0b7f4a40a3bc1706b21454fbc036a41a0d719ded5dc5832f`
- `.cache/fast-interval-phase0/finite-proof-ledger.json`: `b9e26aaca1046bc0dcef16093ccb87a5ce44ff857a528303edb36d1770621e45`
