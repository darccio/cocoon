# Final guest specification readiness

**READY for the private specification checkpoint.** Reviewed the complete
`docs/fast-certified-interval-cost.md` at SHA-256
`d557897390ddac943f0452d9a640608151ea250632d8dbab3f62b71c7b5ef0f8`.
No prototype, build, test, timing, profile or tracked source change was made.

The native transfer theorem covers each exact real corner and its rounded
source value using separately rounded binary64 arithmetic and one outward
adjacent step. Signed extrema, zero-containing denominator, nonfinite result,
normalization/one/minimum branch and strict final-bin rules are explicit.
Wider bounds may fail the original finite gate; no epsilon, clipping or tuning
is permitted. Normal native nearest-even/gradual-underflow behavior and explicit
source rounding must be established by the planned local-toolchain witnesses.

Owned immutable numeric state correctly separates once-only source/program
binding from per-request numerical work. There is no caller-mutable graph or
source view behind that trust claim. The new containment adapter independently
recomputes corners from verified claimed native operands and carries the checked
claim forward; it does not reuse the old tight trace as proof or invoke native
transfer. The old reference remains byte-identical. Full original compiled
log/bin and fresh-Wasm logical/state checks retain their distinct finite scopes.

The fixed policy now settles both requested ambiguities: unsupported point
domains, including exact one, perform zero proposals and timed exact reference
work; every eligible interval uncertainty retries up to the same five proposals.
Failed/unsupported construction preserves the previous valid slot. Only success
or the timed initial reset changes it. Source/parameter query mismatch is
uncertainty/no hit; changed or unprepared model/program is fatal. Default mapping
is not falsely reused as another configuration's fallback.

The fixed-bank, bounded finite-proof and full-N replay ledgers are separate and
explicit. Full-N untimed lockstep checks compare every declared input and all
roles; timed loops check a prevalidated digest after stopping, without paying
extra reference work on hits. The mathematical containment argument and finite
proof remain the certificate soundness basis. This does not falsely require
millions of online rational checks or promote a digest into universal proof.

The 10% repeated Increasing rule against both controls and repeated 2% loss
guards on all seven other corpora are a sufficient finite economic stopping
rule. Zero warmed allocation, bounds and nonvacuity are mandatory. Component
headroom/break-even are explanatory measurements, not additive predictions or
another arbitrary promotion gate. Any failed criterion parks this unchanged
candidate; repeated/nearby success cannot override broad/negative/phase losses.
No alternative capacity, retry, bypass or backoff rescue is allowed.

All seven required quality commands are now listed once, including integration.
Public contracts, production/guest artifacts and old proof stay unchanged;
native arm64/big-endian, SDK relevance, attainable full scalar improvement and
M1 acceptance remain outside scope. No guest correctness/specification blocker
remains. Proceed only after the reviewed signed checkpoint and staged checks.
