package dd

import (
	"bytes"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"go/ast"
	"go/parser"
	"go/token"
	"math"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"testing"
	"unsafe"

	fastproof "cocoonfastintervalproof"
	intervalproof "cocoonfastintervalproof/reference"
	"dario.cat/cocoon/cocoontest"
	"dario.cat/cocoon/rt"
)

// This file exists only in the ignored consumer overlay. No production method,
// resource, cache, compiler pass or checked boundary is replaced.
const (
	intervalHostWholeLimit = 3000
	intervalHostTinyLimit  = 262144
	intervalHostWasmLimit  = 2048
)

type intervalHostLedger struct {
	Whole uint64 `json:"whole_graph_checks"`
	Tiny  uint64 `json:"tiny_span_members"`
	Wasm  uint64 `json:"original_wasm_singletons"`
}

func TestFastIntervalHostProof(t *testing.T) {
	writer := intervalHostOutput(t)
	ledger := &intervalHostLedger{}
	var report struct {
		Architecture         string               `json:"architecture"`
		SourceSHA            string               `json:"source_sha256"`
		WasmSHA              string               `json:"original_wasm_sha256"`
		ProgramID            string               `json:"native_program_sha256"`
		BankHex              string               `json:"deterministic_bank_le_bytes"`
		BankSHA              string               `json:"deterministic_bank_sha256"`
		ModelBytes           uint32               `json:"logical_model_bytes"`
		BankRetainedBytes    uint64               `json:"logical_bank_plus_encoding_bytes"`
		Build                fastproof.BankReport `json:"fixed_bank_report"`
		Certificates         uint16               `json:"certificates"`
		OriginalExponents    int                  `json:"distinct_original_exponents"`
		PositiveBins         bool                 `json:"positive_bins"`
		NegativeBins         bool                 `json:"negative_bins"`
		NearbyWhole          bool                 `json:"one_certificate_covers_nearby8192"`
		IndependentTraces    uint16               `json:"accepted_traces_independently_verified"`
		Ledger               *intervalHostLedger  `json:"verification_driver_ledger"`
		MaxExportCapacity    uint64               `json:"max_builder_export_buffer_capacity"`
		MaxCombinedWorkspace uint64               `json:"max_builder_workspace_plus_export_capacity"`
		Failed               bool                 `json:"test_failed"`
	}
	report.Architecture, report.Ledger = runtime.GOARCH, ledger
	t.Cleanup(func() {
		report.Failed = t.Failed()
		report.MaxExportCapacity = writer.maxExportCapacity
		report.MaxCombinedWorkspace = writer.maxCombinedWorkspace
		writer.event(t, "summary", report)
		if writer.file != nil {
			if err := writer.file.Close(); err != nil {
				t.Error(err)
			}
		}
	})
	path := intervalHostPath()
	intervalHostLayoutSource(t, path)
	for _, corpus := range binReuseCorpora {
		values := binReuseValues(corpus)
		data := make([]byte, 8*len(values))
		for index, value := range values {
			binary.LittleEndian.PutUint64(data[index*8:], math.Float64bits(value))
		}
		if !bytes.Equal(data, fastproof.CorpusBytes(corpus)) {
			t.Fatal("private copied corpus differs from independent authored DD input", corpus)
		}
	}
	if got := fmt.Sprintf("%x", sha256.Sum256(generatedWasm)); got != intervalproof.WasmHash {
		t.Fatalf("original Wasm drift %s", got)
	}
	graph, err := intervalproof.Load(path)
	if err != nil {
		t.Fatal(err)
	}
	ledger.whole(t)
	model, err := fastproof.Prepare(graph)
	if err != nil {
		t.Fatal(err)
	}
	ledger.whole(t)
	if err := intervalproof.VerifyNumericSnapshot(graph, model.Snapshot()); err != nil {
		t.Fatal(err)
	}
	constructor := intervalHostConstructorConfig(t)
	if constructor.Params != graph.Params || constructor.Params != model.Params() || model.SourceSHA() != graph.SourceSHA {
		t.Fatal("actual constructor, source, numeric model differ")
	}
	writer.event(t, "actual_constructor", constructor)
	report.SourceSHA, report.WasmSHA, report.ProgramID = fmt.Sprintf("%x", model.SourceSHA()), intervalproof.WasmHash, fmt.Sprintf("%x", model.ProgramID())
	report.ModelBytes = model.Bytes()
	if report.ModelBytes > 16384 {
		t.Fatal("numeric model exceeds16KiB")
	}
	observer := func(attempt fastproof.Attempt, trace *intervalproof.Trace) error {
		ledger.whole(t)
		writer.builderWorkspace = attempt.Work.WorkspaceBytes
		defer func() { writer.builderWorkspace = 0 }()
		work := attempt.Work
		if work.Nodes > 256 || work.Rounded > 96 || work.EndpointOps > 4*work.Rounded || work.OutwardSteps > 2*work.Rounded || work.OutwardSteps > 192 || work.WorkspaceBytes > 65536 {
			return fmt.Errorf("native candidate exceeded work bound: %+v", work)
		}
		writer.event(t, "candidate_attempt", attempt)
		if attempt.Reason != intervalproof.ReasonNone {
			return nil
		}
		cert := intervalproof.Certificate{Lo: attempt.Lo, Hi: attempt.Hi, Bin: attempt.Bin}
		ledger.whole(t)
		checkerWork, err := intervalproof.VerifyContainment(graph, graph.Params, cert, trace)
		writer.event(t, "accepted_checker_work", struct {
			Certificate intervalproof.Certificate
			Work        intervalproof.Work
		}{cert, checkerWork})
		if err != nil {
			return fmt.Errorf("native accepted containment: %w", err)
		}
		if checkerWork.Nodes != uint32(graph.Count) || checkerWork.Rounded != uint32(graph.Rounded) || checkerWork.EndpointOps != 4*checkerWork.Rounded || checkerWork.Conversions != 2*checkerWork.Rounded || checkerWork.MaxIntegerBits > 4096 {
			return fmt.Errorf("independent containment work invalid: %+v", checkerWork)
		}
		report.IndependentTraces++
		writer.event(t, "accepted_trace", struct {
			Certificate intervalproof.Certificate
			Trace       *intervalproof.Trace
		}{cert, trace})
		return nil
	}
	bank, build, err := fastproof.BuildBank(model, fastproof.DefaultBudget, observer)
	report.Build = build
	if err != nil {
		t.Fatal(err)
	}
	if bank.SourceSHA != model.SourceSHA() || bank.Params != constructor.Params || bank.Count > 64 || build.Count > 320 || build.Accepted != bank.Count || report.IndependentTraces != bank.Count {
		t.Fatal("native bank/accounting mismatch")
	}
	seeds := intervalproof.Seeds()
	writer.event(t, "frozen_seed_bits", seeds)
	lastSeed, lastRefinement := -1, -1
	previousAccepted := false
	returned := 0
	for index := 0; index < int(build.Count); index++ {
		attempt := build.Attempts[index]
		seed, refinement := int(attempt.Seed), int(attempt.Refinement)
		if seed >= 64 || refinement > 4 || attempt.Reason > intervalproof.ReasonBoundary {
			t.Fatal("invalid native attempt record")
		}
		if seed == lastSeed {
			if previousAccepted || refinement != lastRefinement+1 {
				t.Fatal("changed native refinement policy")
			}
		} else if seed != lastSeed+1 || refinement != 0 || lastSeed >= 0 && !previousAccepted && lastRefinement != 4 {
			t.Fatal("skipped/reordered native seed")
		}
		width := uint64(1) << uint(40-refinement)
		if seeds[seed] < width || seeds[seed] > math.MaxUint64-width || attempt.Lo != seeds[seed]-width || attempt.Hi != seeds[seed]+width {
			t.Fatal("native request clipped/retuned")
		}
		previousAccepted = attempt.Reason == intervalproof.ReasonNone
		if previousAccepted {
			want := intervalproof.Certificate{Lo: attempt.Lo, Hi: attempt.Hi, Bin: attempt.Bin}
			if returned >= int(bank.Count) || bank.Certificates[returned] != want {
				t.Fatal("native returned bank differs from independently checked attempts")
			}
			returned++
		}
		lastSeed, lastRefinement = seed, refinement
	}
	if lastSeed != 63 || returned != int(bank.Count) || !previousAccepted && lastRefinement != 4 {
		t.Fatal("native bank omitted final frozen outcome")
	}
	data, err := intervalproof.BankBytes(&bank)
	if err != nil {
		t.Fatal(err)
	}
	report.BankRetainedBytes = uint64(unsafe.Sizeof(bank)) + uint64(cap(data))
	if report.BankRetainedBytes > 4096 {
		t.Fatal("numeric bank+encoding exceeds4KiB")
	}
	report.BankHex, report.BankSHA = hex.EncodeToString(data), fmt.Sprintf("%x", sha256.Sum256(data))
	exponents := map[uint64]bool{}
	nonSingleton := 0
	_, reference := newDifferential(t)
	for index := 0; index < int(bank.Count); index++ {
		cert := bank.Certificates[index]
		if cert.Lo >= cert.Hi {
			t.Fatal("singleton/nonordered native certificate")
		}
		nonSingleton++
		exponent := cert.Lo >> 52
		if exponent != cert.Hi>>52 {
			t.Fatal("native original exponent crossing")
		}
		exponents[exponent] = true
		report.PositiveBins = report.PositiveBins || cert.Bin > 0
		report.NegativeBins = report.NegativeBins || cert.Bin < 0
		nearby := math.Float64bits(42)
		report.NearbyWhole = report.NearbyWhole || cert.Lo <= nearby && cert.Hi >= nearby+8191
		writer.event(t, "certificate_width", struct {
			Index    int
			Members  uint64
			RealSpan float64
			Exponent uint64
		}{index, cert.Hi - cert.Lo + 1, math.Float64frombits(cert.Hi) - math.Float64frombits(cert.Lo), exponent})
		for _, bits := range intervalHostCertificatePoints(cert) {
			want := intervalHostCheckPoint(t, ledger, graph, bits, &cert)
			intervalHostWasmPoint(t, writer, ledger, reference, bits, &want)
		}
		for delta := uint64(1); delta <= 2 && delta <= cert.Hi-cert.Lo; delta++ {
			ledger.tiny(t)
			intervalHostCheckPoint(t, ledger, graph, cert.Lo+delta, &cert)
		}
	}
	report.Certificates, report.OriginalExponents = bank.Count, len(exponents)
	for _, bits := range []uint64{0, 1 << 63, 1, 0x000fffffffffffff, 0x0010000000000000, graph.Params[2] - 1, graph.Params[2], graph.Params[2] + 1} {
		intervalHostWasmPoint(t, writer, ledger, reference, bits, nil)
	}
	if nonSingleton < 16 || report.OriginalExponents < 4 || !report.PositiveBins || !report.NegativeBins || !report.NearbyWhole {
		t.Errorf("native nonvacuity failed: certificates=%d exponents=%d positive=%t negative=%t Nearby=%t", nonSingleton, report.OriginalExponents, report.PositiveBins, report.NegativeBins, report.NearbyWhole)
	}
}

func (l *intervalHostLedger) whole(tb testing.TB) {
	tb.Helper()
	if l.Whole >= intervalHostWholeLimit {
		tb.Fatal("interval host driver exhausted whole-graph budget")
	}
	l.Whole++
}

func (l *intervalHostLedger) tiny(tb testing.TB) {
	tb.Helper()
	if l.Tiny >= intervalHostTinyLimit {
		tb.Fatal("interval host driver exhausted tiny-span budget")
	}
	l.Tiny++
}

func (l *intervalHostLedger) wasm(tb testing.TB) {
	tb.Helper()
	if l.Wasm >= intervalHostWasmLimit {
		tb.Fatal("interval host driver exhausted original-Wasm singleton budget")
	}
	l.Wasm++
}

type intervalHostWriter struct {
	file                 *os.File
	builderWorkspace     uint32
	maxExportCapacity    uint64
	maxCombinedWorkspace uint64
}

func intervalHostOutput(tb testing.TB) *intervalHostWriter {
	tb.Helper()
	writer := &intervalHostWriter{}
	path := os.Getenv("COCOON_FAST_INTERVAL_PROOF_OUTPUT")
	if path == "" {
		return writer
	}
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		tb.Fatal(err)
	}
	file, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0o600)
	if err != nil {
		tb.Fatalf("interval proof output must be fresh: %v", err)
	}
	writer.file = file
	return writer
}

func (w *intervalHostWriter) event(tb testing.TB, name string, value any) {
	tb.Helper()
	data, err := json.Marshal(struct {
		Event string `json:"event"`
		Data  any    `json:"data"`
	}{name, value})
	if err != nil {
		tb.Fatal(err)
	}
	if w.builderWorkspace != 0 {
		capacity := uint64(cap(data))
		combined := capacity + uint64(w.builderWorkspace)
		if combined > intervalproof.MaxWorkspaceBytes {
			tb.Fatalf("interval export capacity%d+active workspace%d exceeds64KiB", capacity, w.builderWorkspace)
		}
		w.maxExportCapacity = max(w.maxExportCapacity, capacity)
		w.maxCombinedWorkspace = max(w.maxCombinedWorkspace, combined)
	}
	if w.file == nil {
		tb.Logf("INTERVAL_HOST %s", data)
		return
	}
	if _, err := fmt.Fprintf(w.file, "%s\n", data); err != nil {
		tb.Fatal(err)
	}
}

func intervalHostPath() string {
	if path := os.Getenv("COCOON_FAST_INTERVAL_PROOF_SOURCE"); path != "" {
		return path
	}
	return filepath.Join("internal", "wasm", "module.go")
}

// Full-source identity pins this fixture layout. Literal assertions reconstruct
// why the returned handle binds the current record; they are not a generic API.
func intervalHostLayoutSource(tb testing.TB, path string) {
	tb.Helper()
	source, err := os.ReadFile(path)
	if err != nil {
		tb.Fatal(err)
	}
	if got := fmt.Sprintf("%x", sha256.Sum256(source)); got != intervalproof.SourceHash {
		tb.Fatalf("interval constructor-layout source drift: %s", got)
	}
	set := token.NewFileSet()
	file, err := parser.ParseFile(set, path, source, 0)
	if err != nil {
		tb.Fatal(err)
	}
	functions := make(map[string]string)
	for _, declaration := range file.Decls {
		function, ok := declaration.(*ast.FuncDecl)
		if !ok {
			continue
		}
		functions[function.Name.Name] = string(source[set.Position(function.Pos()).Offset:set.Position(function.End()).Offset])
	}
	checks := map[string][]string{
		"fn84": {
			"v5 = int32(v3)", "v5 = v5 - i32(1)", "if uint32(t2) <= uint32(v5)",
			"v6 = v1 + v5*i32(72)", "load32(m.memory, uint64(uint32(v6))+64)",
			"if t6 == int32(int64(uint64(v3)>>32))", "if t7 != i32(-1)",
			"store32(m.memory, uint64(uint32(v0))+4, uint32(v1))",
		},
		"Xcocoon_sketch_add": {
			"load32(m.memory, uint32(i32(1101436)))", "load32(m.memory, uint32(i32(1101440)))",
			"m.fn84(v3, t3, t4, v0)", "load32(m.memory, uint64(uint32(v3))+4)",
			"m.fn176(v2+i32(8), v4, v1)",
		},
		"fn176": {
			"load64(m.memory, uint64(uint32(v3))+48)", "load64(m.memory, uint64(uint32(v3))+40)",
			"load64(m.memory, uint64(uint32(v3))+56)",
		},
		"Xcocoon_sketch_new": {
			"uint64(i64(0x3ff0400000000000))", "uint64(i64(4634239110019182123))",
			"math.Float64bits(float64(0x1.04p-1022))", "uint64(i64(0x4094ea0000000000))",
			"store64(m.memory, uint64(uint32(v0))+32, uint64(t20))",
			"store64(m.memory, uint64(uint32(v0))+40, uint64(t19))",
			"store64(m.memory, uint64(uint32(v0))+48, uint64(t18))",
			"store64(m.memory, uint64(uint32(v0))+56, uint64(t17))",
		},
	}
	for name, literals := range checks {
		for _, literal := range literals {
			if !strings.Contains(functions[name], literal) {
				tb.Fatalf("interval constructor-layout relation drift in %s: %s", name, literal)
			}
		}
	}
}

type intervalHostConstructor struct {
	Params      intervalproof.Params `json:"parameter_bits"`
	Handle      uint64               `json:"handle"`
	Record      uint64               `json:"private_record_offset"`
	Generation  uint32               `json:"generation"`
	LiveWord    uint32               `json:"occupied_word"`
	MemoryBytes uint64               `json:"current_logical_memory_bytes"`
	MemorySHA   string               `json:"unchanged_memory_sha256"`
	Encoding    []byte               `json:"constructor_protobuf"`
}

func intervalHostU32(tb testing.TB, memory []byte, offset uint64) uint32 {
	tb.Helper()
	if offset > uint64(len(memory)) || uint64(len(memory))-offset < 4 {
		tb.Fatalf("interval constructor-layout offset outside current logical memory: %d", offset)
	}
	return binary.LittleEndian.Uint32(memory[offset : offset+4])
}

func intervalHostConstructorConfig(tb testing.TB) intervalHostConstructor {
	tb.Helper()
	library := openTest(tb, Options{Instances: 1, ResourceInstances: 1})
	sketch, err := library.NewSketch()
	if err != nil {
		tb.Fatal(err)
	}
	tb.Cleanup(func() {
		if closeErr := sketch.Close(); closeErr != nil {
			tb.Error(closeErr)
		}
	})
	var result intervalHostConstructor
	if enterErr := library.life.Enter(); enterErr != nil {
		tb.Fatal(enterErr)
	}
	defer library.life.Leave()
	useErr := sketch.owner.Use("interval-constructor-fixture", func(instance *rt.Instance, handle uint64) error {
		return instance.Call("interval-constructor-fixture", func(_ *rt.Call) error {
			memory := sketch.guest.module.Memory()
			before := sha256.Sum256(memory)
			base := uint64(intervalHostU32(tb, memory, 1101436))
			count := uint64(intervalHostU32(tb, memory, 1101440))
			index := uint64(uint32(handle))
			if index == 0 || index-1 >= count {
				tb.Fatal("interval constructor-layout handle has no current slot")
			}
			index--
			if index > (math.MaxUint32-base)/72 {
				tb.Fatal("interval constructor-layout widened record address would wrap wasm32")
			}
			record := base + index*72
			if record > uint64(len(memory)) || uint64(len(memory))-record < 72 {
				tb.Fatal("interval constructor-layout record outside current logical memory")
			}
			generation := intervalHostU32(tb, memory, record+64)
			live := intervalHostU32(tb, memory, record)
			if generation != uint32(handle>>32) || live == math.MaxUint32 {
				tb.Fatal("interval constructor-layout ownership/generation differs")
			}
			for field := range result.Params {
				offset := record + 32 + uint64(field)*8
				result.Params[field] = binary.LittleEndian.Uint64(memory[offset : offset+8])
			}
			after := sketch.guest.module.Memory()
			if len(after) != len(memory) || sha256.Sum256(after) != before {
				tb.Fatal("interval constructor-layout read changed current guest memory")
			}
			result.Handle, result.Record, result.Generation, result.LiveWord = handle, record, generation, live
			result.MemoryBytes, result.MemorySHA = uint64(len(memory)), fmt.Sprintf("%x", before)
			return nil
		})
	})
	if useErr != nil {
		tb.Fatal(useErr)
	}
	result.Encoding, err = sketch.Encode()
	if err != nil {
		tb.Fatal(err)
	}
	if count, countErr := sketch.Count(); countErr != nil || count != 0 {
		tb.Fatalf("interval constructor fixture count=%g error=%v", count, countErr)
	}
	var gamma, offset uint64
	var gammaFound, offsetFound bool
	for _, field := range sketchWireFields(tb, result.Encoding) {
		if field.number != 1 || field.wire != 2 {
			continue
		}
		for _, mapping := range sketchWireFields(tb, field.data) {
			if mapping.wire != 1 {
				continue
			}
			switch mapping.number {
			case 1:
				gamma, gammaFound = binary.LittleEndian.Uint64(mapping.data), true
			case 2:
				offset, offsetFound = binary.LittleEndian.Uint64(mapping.data), true
			}
		}
	}
	if !gammaFound || !offsetFound || gamma != result.Params[0] || offset != result.Params[3] {
		tb.Fatal("interval constructor protobuf configuration differs from bound record")
	}
	return result
}

func intervalHostCheckPoint(tb testing.TB, ledger *intervalHostLedger, graph *intervalproof.Graph, bits uint64, certificate *intervalproof.Certificate) int32 {
	tb.Helper()
	ledger.whole(tb)
	got, graphTrace, err := intervalproof.Point(graph, graph.Params, bits)
	if err != nil {
		tb.Fatalf("native interval graph point %016x: %v", bits, err)
	}
	ledger.whole(tb)
	originalLog := intervalproof.OriginalLog(math.Float64frombits(bits))
	if math.Float64bits(originalLog) != graphTrace.Slots[graph.LogOutput].Lo {
		tb.Fatalf("full original log differs from graph point %016x", bits)
	}
	ledger.whole(tb)
	originalBin := intervalproof.OriginalBin(math.Float64frombits(bits))
	if originalBin != got {
		tb.Fatalf("full original bin differs from graph point %016x", bits)
	}
	if certificate != nil && bits >= certificate.Lo && bits <= certificate.Hi && got != certificate.Bin {
		tb.Fatalf("native certificate wrong bin input=%016x", bits)
	}
	return got
}

func intervalHostWasmPoint(tb testing.TB, writer *intervalHostWriter, ledger *intervalHostLedger, reference *cocoontest.Guest, bits uint64, want *int32) {
	tb.Helper()
	ledger.wasm(tb)
	ledger.whole(tb) // Charge the original Wasm point/model even on a no-bin input.
	count, encoded := binOracleState(tb, reference, rt.Limits{MaxInput: generatedInputLimit, MaxOutput: generatedOutputLimit, MaxMemory: maximumMemory}, []float64{math.Float64frombits(bits)})
	bin := readSingletonSketchBin(tb, encoded)
	if count != math.Float64bits(1) {
		tb.Fatalf("interval original-Wasm singleton count input=%016x got=%016x", bits, count)
	}
	if want != nil && (!bin.hasBin || bin.index != int64(*want) || bin.zeroCount != 0) {
		tb.Fatalf("interval original-Wasm singleton wrong bin input=%016x result=%+v want=%d", bits, bin, *want)
	}
	if bits < intervalproof.PinnedParams[2] || bits == 1<<63 {
		if bin.hasBin || bin.zeroCount != math.Float64bits(1) {
			tb.Fatalf("interval threshold input=%016x is not the original zero/no-bin path: %+v", bits, bin)
		}
	}
	writer.event(tb, "original_wasm_singleton", struct {
		Bits      uint64 `json:"input_bits"`
		CountBits uint64 `json:"count_bits"`
		Bin       int64  `json:"logical_bin"`
		HasBin    bool   `json:"has_bin"`
		ZeroBits  uint64 `json:"zero_count_bits"`
		Protobuf  []byte `json:"complete_protobuf"`
	}{bits, count, bin.index, bin.hasBin, bin.zeroCount, encoded})
}

func intervalHostCertificatePoints(certificate intervalproof.Certificate) [9]uint64 {
	span := certificate.Hi - certificate.Lo
	return [9]uint64{
		certificate.Lo, certificate.Hi, certificate.Lo - 1, certificate.Hi + 1,
		certificate.Lo + span/2, certificate.Lo + span/4, certificate.Lo + span/4*3,
		certificate.Lo + span/8, certificate.Lo + span/8*7,
	}
}
