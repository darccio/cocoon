"""All predeclared economic comparisons, using unadjusted benchstat tests."""
from pathlib import Path
import hashlib,json,re,statistics,subprocess
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'.cache/fast-interval-phase0'
BENCHSTAT=Path('/home/dario/go/bin/benchstat')
rows=[json.loads(line) for line in (OUT/'cost-rows.jsonl').read_text().splitlines()]
plan=json.loads((OUT/'cost-plan.json').read_text());assert len(rows)==546
STAT=OUT/'statistics';STAT.mkdir(exist_ok=False)
corpora=['Increasing','Repeated','UniqueCycle','NearbyUniqueCycle','MostlyUniqueCycle','Phases','BroadHoldout','NegativeBins']
comparisons=[]
for round_name in ['screen','confirm']:
 for corpus in corpora:
  medians={}
  paths={}
  for role in ['Direct','Disabled','Enabled']:
   selected=[r for r in rows if r['round']==round_name and r['scope']==f'Replay-{role}-{corpus}'];assert len(selected)==7
   values=[r['metrics']['ns/input'] for r in selected];medians[role]=statistics.median(values)
   p=STAT/f'{round_name}-{role}-{corpus}.txt'
   p.write_text(''.join(f'BenchmarkNumeric/{corpus}\t1\t{v:.12g} ns/op\n' for v in values));paths[role]=p
  for before,after in [('Direct','Enabled'),('Disabled','Enabled'),('Direct','Disabled')]:
   argv=[str(BENCHSTAT),str(paths[before]),str(paths[after])]
   output=subprocess.check_output(argv,text=True)
   name=f'{round_name}-{before}-to-{after}-{corpus}'
   (STAT/(name+'.txt')).write_text(output)
   found=re.search(r'p=([0-9.]+)',output)
   assert found,output
   p=float(found.group(1));delta=(medians[after]/medians[before]-1)*100
   record={'round':round_name,'corpus':corpus,'control':before,'candidate':after,'control_ns_input':medians[before],'candidate_ns_input':medians[after],'delta_percent':delta,'unadjusted_benchstat_p':p,'argv':argv,'output_file':'statistics/'+name+'.txt'}
   comparisons.append(record)
def pair(corpus,control):return [r for r in comparisons if r['corpus']==corpus and r['control']==control and r['candidate']=='Enabled']
increasing={c:all(r['delta_percent']<=-10 and r['unadjusted_benchstat_p']<.05 for r in pair('Increasing',c)) for c in ['Direct','Disabled']}
guards={corpus:{c:all(r['delta_percent']>2 and r['unadjusted_benchstat_p']<.05 for r in pair(corpus,c)) for c in ['Direct','Disabled']} for corpus in corpora[1:]}
economic_pass=all(increasing.values()) and not any(v for corpus in guards.values() for v in corpus.values())
result={'benchmark_statistics_tool_sha256':hashlib.sha256(BENCHSTAT.read_bytes()).hexdigest(),'benchmark_statistics_buildinfo':subprocess.check_output([str(ROOT/'.cache/toolchains/go1.26.8/go/bin/go'),'version','-m',str(BENCHSTAT)],text=True),'method':'independent fresh-process samples; benchstat unadjusted Mann-Whitney tests; seven per set;48comparisons; exploratory no multiplicity correction, private stop rule only','comparisons':comparisons,'Increasing_ten_percent_both_sets':increasing,'Other_repeated_two_percent_slowdown_guards':guards,'economic_pass':economic_pass,'decision':'ADVANCE_ONLY_TO_NEW_SEPARATE_SPEC' if economic_pass else 'PARK_FIXED_CANDIDATE_UNCHANGED','M1_performance_accepted':False}
(OUT/'replay-statistics.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='comparisons'},indent=2))
