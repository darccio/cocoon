module cocoonfastintervalproof

go 1.26.0
