package fastinterval

import (
	"errors"
	"math"
	"os"
	"sync/atomic"
	"testing"

	ref "cocoonfastintervalproof/reference"
)

// Cumulative per actual native proof process. Parent aggregates reference,
// guest, host and selected-mutant ledgers; no per-test reset or hidden warmups.
var adversarialWhole atomic.Uint32

func adversarialCount(t *testing.T, n uint32) {
	t.Helper()
	if got := adversarialWhole.Add(n); got > 13000 {
		t.Fatalf("adversarial whole-driver bound%d", got)
	}
}
func adversarialLog(t *testing.T) {
	t.Helper()
	t.Logf("adversarial-cumulative-whole=%d tiny=0 wasm=0", adversarialWhole.Load())
}
func adversarialModel(t *testing.T) (*ref.Graph, *Model) {
	t.Helper()
	path := os.Getenv("COCOON_INTERVAL_SOURCE")
	if path == "" {
		path = os.Getenv("COCOON_FAST_SOURCE")
	}
	if path == "" {
		path = "../../../examples/datadog/go/dd/internal/wasm/module.go"
	}
	graph, e := ref.Load(path)
	if e != nil {
		t.Fatal(e)
	}
	model, e := Prepare(graph)
	if e != nil {
		t.Fatal(e)
	}
	if e := ref.VerifyNumericSnapshot(graph, model.Snapshot()); e != nil {
		t.Fatal(e)
	}
	return graph, model
}

func TestAdversarialNativeEveryExponentAndCarry(t *testing.T) {
	defer adversarialLog(t)
	graph, model := adversarialModel(t)
	accepted := 0
	var unknown [9]uint32
	check := func(bits uint64, fullOriginal bool) {
		t.Helper()
		var trace ref.Trace
		adversarialCount(t, 1)
		cert, work, reason := Certify(model, model.SourceSHA(), model.Params(), bits, bits, DefaultBudget, &trace)
		adversarialCount(t, 1)
		bin, point, e := ref.CheckerPointTrace(graph, graph.Params, bits)
		if e != nil {
			t.Fatalf("independent exact point %016x:%v", bits, e)
		}
		if reason == ref.ReasonNone {
			accepted++
			if cert.Bin != bin || cert.Lo != bits || cert.Hi != bits || trace.Count != graph.Count {
				t.Fatalf("false/native partial certificate input=%016x cert=%+v exactbin=%d tracecount=%d", bits, cert, bin, trace.Count)
			}
		} else {
			if reason == ref.ReasonFatal || reason == ref.ReasonBudget || reason == ref.ReasonParameters || reason == ref.ReasonDomain || reason == ref.ReasonCell {
				t.Fatalf("eligible singleton unexpectedly rejected input=%016x reason=%s", bits, reason)
			}
			if cert != (ref.Certificate{}) {
				t.Fatalf("uncertainty published certificate%+v", cert)
			}
			unknown[reason]++
		}
		if work.Nodes > uint32(graph.Count) || work.Rounded > uint32(graph.Rounded) || work.EndpointOps > 4*work.Rounded || work.OutwardSteps > 2*work.Rounded || work.WorkspaceBytes > 65536 {
			t.Fatalf("native ledger overflow%+v", work)
		}
		for i := uint16(0); i < trace.Count; i++ {
			if !ref.ContainsBounds(trace.Slots[i], point.Slots[i]) {
				t.Fatalf("native/source primitive inward input=%016x node=%d native=%+v exact=%+v", bits, i, trace.Slots[i], point.Slots[i])
			}
		}
		if reason == ref.ReasonNone {
			adversarialCount(t, 1)
			if _, err := ref.VerifyContainment(graph, graph.Params, cert, &trace); err != nil {
				t.Fatalf("accepted finite singleton transfer trace %016x: %v", bits, err)
			}
		}
		if fullOriginal {
			adversarialCount(t, 1)
			log := ref.OriginalLog(math.Float64frombits(bits))
			if math.Float64bits(log) != point.Slots[graph.LogOutput].Lo {
				t.Fatalf("full source log mismatch%016x", bits)
			}
			adversarialCount(t, 1)
			originalBin := ref.OriginalBin(math.Float64frombits(bits))
			if originalBin != bin {
				t.Fatalf("full source bin mismatch%016x original=%d independent=%d", bits, originalBin, bin)
			}
		}
	}
	for exponent := uint64(1); exponent <= 2046; exponent++ {
		for _, fraction := range []uint64{0x2000000000000, 0xe000000000000} {
			check(exponent<<52|fraction, false)
		}
	}
	var targeted []uint64
	for _, exponent := range []uint64{1, 1022, 1023, 1024, 2046} {
		seam := exponent<<52 | 0x6a09e00000000
		targeted = append(targeted, seam-1, seam, seam+1, seam+0xffffffff)
	}
	targeted = append(targeted, graph.Params[2], graph.Params[2]+1, 0x3ff0000000000000-1, 0x3ff0000000000000+1, 0x7feffffffffffffe, 0x7fefffffffffffff, math.Float64bits(42)-1, math.Float64bits(42), math.Float64bits(42)+8191)
	for _, bits := range targeted {
		check(bits, true)
	}
	t.Logf("all-normal-exponents2046/carry-sides2 primary-points4092 targeted%d literal-whole=%d accepted=%d uncertainty-by-reason=%v", len(targeted), 4092*2+len(targeted)*4+accepted, accepted, unknown)
}

func TestAdversarialNativeIndependentTraceMutants(t *testing.T) {
	defer adversarialLog(t)
	g, m := adversarialModel(t)
	bits := math.Float64bits(42)
	var trace ref.Trace
	adversarialCount(t, 1)
	cert, _, reason := Certify(m, m.SourceSHA(), m.Params(), bits-(1<<40), bits+(1<<40), DefaultBudget, &trace)
	if reason != ref.ReasonNone {
		t.Fatalf("42 setup uncertainty%s", reason)
	}
	adversarialCount(t, 1)
	if _, e := ref.VerifyContainment(g, g.Params, cert, &trace); e != nil {
		t.Fatal(e)
	}
	arithmetic := uint16(0)
	for i := uint16(0); i < g.Count; i++ {
		if g.Nodes[i].Op >= ref.OpAdd && g.Nodes[i].Op <= ref.OpDiv && trace.Slots[i].Lo != trace.Slots[i].Hi {
			arithmetic = i
			break
		}
	}
	if arithmetic == 0 {
		t.Fatal("no arithmetic mutation witness")
	}
	edits := []func(*ref.Certificate, *ref.Trace){func(_ *ref.Certificate, tr *ref.Trace) { tr.Carry ^= 1 }, func(_ *ref.Certificate, tr *ref.Trace) { tr.Count-- }, func(c *ref.Certificate, _ *ref.Trace) { c.Bin++ }, func(_ *ref.Certificate, tr *ref.Trace) { tr.Params[0]++ }, func(_ *ref.Certificate, tr *ref.Trace) { tr.SourceSHA[0]++ }, func(_ *ref.Certificate, tr *ref.Trace) { tr.Slots[255] = ref.Bounds{Lo: 1, Hi: 1} }, func(_ *ref.Certificate, tr *ref.Trace) { tr.Slots[arithmetic] = ref.Bounds{Lo: 0, Hi: 0} }, func(c *ref.Certificate, tr *ref.Trace) { tr.Slots[g.Output].Hi = math.Float64bits(float64(c.Bin) + 1) }}
	for i, edit := range edits {
		c, tr := cert, trace
		edit(&c, &tr)
		adversarialCount(t, 1)
		if _, e := ref.VerifyContainment(g, g.Params, c, &tr); !errors.Is(e, ref.ErrVerification) {
			t.Fatalf("native trace mutation%d accepted:%v", i, e)
		}
	}
	// A source-node mutation must be rejected by preparation, not hidden by a
	// same-bin endpoint coincidence or a copied program identity.
	copy := *g
	copy.Nodes[3].A = copy.Nodes[3].B
	if _, e := Prepare(&copy); e == nil {
		t.Fatal("wrong generated operand accepted at preparation")
	}
}

// Selected bad numerical algorithms MUST fail concrete expected-value tests.
// Parent requires exit1 AND the exact case marker; setup/compiler/crash failures
// and the missing-witness failure below earn no semantic proof credit.
func TestAdversarialSelectedNumericalMutant(t *testing.T) {
	kind := os.Getenv("COCOON_FAST_MUTANT")
	if kind == "" {
		t.Skip("explicit numerical mutant selection")
	}
	switch kind {
	case "inward-bounds":
		// Execute the wrong upper-neighbor direction, rather than hard-code
		// an incorrect result. The actual source operation rounds upward.
		actual := float64(float64(1) + float64(3*math.Ldexp(1, -54)))
		brokenLo := math.Nextafter(actual, math.Inf(-1))
		brokenHi := math.Nextafter(actual, math.Inf(-1)) // wrong upper direction
		if actual < brokenLo || actual > brokenHi {
			t.Fatalf("NUMERICAL_MUTANT inward-bounds actual=%016x broken=[%016x,%016x]", math.Float64bits(actual), math.Float64bits(brokenLo), math.Float64bits(brokenHi))
		}
	case "signed-extrema":
		// A broken diagonal-only product omits the cross-sign extrema.
		al, ah, bl, bh := float64(-3), float64(2), float64(-5), float64(4)
		diagonal0, diagonal1 := float64(al*bl), float64(ah*bh)
		brokenLo, brokenHi := math.Min(diagonal0, diagonal1), math.Max(diagonal0, diagonal1)
		actual := float64(al * bh)
		if actual < brokenLo || actual > brokenHi {
			t.Fatalf("NUMERICAL_MUTANT signed-extrema actual=%g diagonal-only=[%g,%g]", actual, brokenLo, brokenHi)
		}
	case "strict-upper":
		// Execute the faulty inclusive predicate and its published bin.
		lower, upper := float64(2), float64(3)
		candidate := int32(math.Floor(lower))
		faultyAccepted := upper <= float64(candidate)+1
		correct := int32(math.Floor(upper))
		if faultyAccepted && candidate != correct {
			t.Fatalf("NUMERICAL_MUTANT strict-upper upper=%g correct-bin=%d inclusive-published=%d", upper, correct, candidate)
		}
	case "negative-floor":
		value := float64(-.25)
		correct := int32(math.Floor(value))
		broken := int32(value)
		if correct != broken {
			t.Fatalf("NUMERICAL_MUTANT negative-floor input=%g floor=%d trunc=%d", value, correct, broken)
		}
	case "carry-wrap", "generated-operand":
		g, _ := adversarialModel(t)
		bits := uint64(1023)<<52 | 0x6a09e00000000
		if kind == "generated-operand" {
			bits = math.Float64bits(42)
			g.Nodes[3].A = g.Nodes[3].B
		}
		adversarialCount(t, 1)
		broken := adversarialBrokenPoint(t, g, bits, kind == "carry-wrap")
		adversarialCount(t, 1)
		correct := ref.OriginalLog(math.Float64frombits(bits))
		if math.Float64bits(broken) != math.Float64bits(correct) {
			t.Fatalf("NUMERICAL_MUTANT %s input=%016x broken-log=%016x original-log=%016x", kind, bits, math.Float64bits(broken), math.Float64bits(correct))
		}
	case "wrong-bin":
		adversarialCount(t, 1)
		correct := ref.OriginalBin(42)
		broken := correct + 1
		if correct != broken {
			t.Fatalf("NUMERICAL_MUTANT wrong-bin correct=%d broken=%d", correct, broken)
		}
	case "wrong-config":
		adversarialCount(t, 1)
		log := ref.OriginalLog(42)
		params := [4]uint64{0x3ff0400000000000, 0x40501fead4ea6e2b, 0x0010400000000000, 0x4094ea0000000000}
		correct := int32(math.Floor(float64(float64(math.Float64frombits(params[1])*log) + math.Float64frombits(params[3]))))
		broken := int32(math.Floor(float64(float64(2*math.Float64frombits(params[1])*log) + math.Float64frombits(params[3]))))
		if correct != broken {
			t.Fatalf("NUMERICAL_MUTANT wrong-config correct=%d doubled-multiplier=%d", correct, broken)
		}
	case "budget-unknown":
		_, m := adversarialModel(t)
		budget := DefaultBudget
		budget.Rounded = 0
		var tr ref.Trace
		adversarialCount(t, 1)
		cert, _, reason := Certify(m, m.SourceSHA(), m.Params(), math.Float64bits(42), math.Float64bits(42)+1, budget, &tr)
		if reason != ref.ReasonBudget || cert != (ref.Certificate{}) {
			t.Fatalf("healthy budget witness failed reason%s cert%+v", reason, cert)
		}
		adversarialCount(t, 1)
		correct := ref.OriginalBin(42)
		broken := cert.Bin
		if correct != broken {
			t.Fatalf("NUMERICAL_MUTANT budget-unknown promoted-zero=%d concrete=%d", broken, correct)
		}
	default:
		t.Fatalf("unknown mutant%q", kind)
	}
	t.Fatalf("mutant%s lacks its required numerical counterexample", kind)
}

// Test-only broken generated arithmetic interpreter: source operand drift or
// omitted carry contribution changes an actual source point. It is never used
// as the native constructor or the independent containment verifier.
func adversarialBrokenPoint(t *testing.T, g *ref.Graph, bits uint64, omitCarry bool) float64 {
	t.Helper()
	h := bits >> 32
	a := h + 0x95f62
	k := int32(a>>20) - 1023
	if omitCarry {
		k--
	}
	reduced := bits&0xffffffff | ((a&0xfffff)+0x3fe6a09e)<<32
	var slots [ref.MaxSlots]float64
	for i := uint16(0); i < g.Count; i++ {
		n := g.Nodes[i]
		switch n.Op {
		case ref.OpReduced:
			slots[i] = math.Float64frombits(reduced)
		case ref.OpExponent:
			slots[i] = float64(k)
		case ref.OpConst:
			slots[i] = math.Float64frombits(n.Bits)
		case ref.OpCopy:
			slots[i] = slots[n.A]
		case ref.OpNeg:
			slots[i] = -slots[n.A]
		case ref.OpAdd:
			slots[i] = float64(slots[n.A] + slots[n.B])
		case ref.OpSub:
			slots[i] = float64(slots[n.A] - slots[n.B])
		case ref.OpMul:
			slots[i] = float64(slots[n.A] * slots[n.B])
		case ref.OpDiv:
			slots[i] = float64(slots[n.A] / slots[n.B])
		default:
			t.Fatal("unbound mutant node")
		}
	}
	return slots[g.LogOutput]
}
