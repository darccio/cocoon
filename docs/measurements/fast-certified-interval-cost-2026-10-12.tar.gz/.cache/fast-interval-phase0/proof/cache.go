package fastinterval

import (
	"encoding/binary"
	"math"
	"unsafe"

	ref "cocoonfastintervalproof/reference"
)

// OneSlot is ignored numerical simulation state. It owns no resource, memory
// view, store address, ABI result, or production cache. The model is immutable.
type OneSlot struct {
	model  *Model
	source [32]byte
	params ref.Params
	cert   ref.Certificate
	valid  bool
}

type ReplayCounters struct {
	Inputs, Hits, Misses, DomainBypasses, Proposals, Installs uint64
	Fallbacks, Replacements, Resets, Fatal                    uint64
	Reasons                                                   [9]uint64
	Refinements                                               [5]uint64
	Nodes, Rounded, EndpointOps, OutwardSteps                 uint64
}

func NewOneSlot(model *Model) (*OneSlot, ref.Reason) {
	if model == nil {
		return nil, ref.ReasonFatal
	}
	s := &OneSlot{model: model, source: model.SourceSHA(), params: model.Params()}
	if reason := model.PointReason(s.source, s.params, math.Float64bits(42)); reason != ref.ReasonNone {
		return nil, reason
	}
	if s.Bytes() > ref.MaxBankBytes {
		return nil, ref.ReasonFatal
	}
	return s, ref.ReasonNone
}

func (s *OneSlot) Bytes() uint32 { return uint32(unsafe.Sizeof(*s)) }

func (s *OneSlot) Reset(counters *ReplayCounters) {
	s.cert, s.valid = ref.Certificate{}, false
	if counters != nil {
		addCounter(&counters.Resets, 1)
	}
}

func (s *OneSlot) Certificate() (ref.Certificate, bool) {
	return s.cert, s.valid
}

func (s *OneSlot) Lookup(source [32]byte, params ref.Params, bits uint64) (int32, bool, ref.Reason) {
	if s == nil || s.model == nil {
		return 0, false, ref.ReasonFatal
	}
	if reason := s.model.IdentityReason(source, params); reason != ref.ReasonNone {
		return 0, false, reason
	}
	if s.valid && source == s.source && params == s.params && bits >= s.cert.Lo && bits <= s.cert.Hi {
		return s.cert.Bin, true, ref.ReasonNone
	}
	return 0, false, ref.ReasonNone
}

// MapMode shares the disabled/enabled call shape. Optional counts are used by
// the separate lockstep replay; qualified timed loops pass nil and retain only
// their rolling output digest. All real miss work remains inside this method.
func (s *OneSlot) MapMode(value float64, enabled bool, counters *ReplayCounters) (int32, ref.Reason) {
	if s == nil || s.model == nil {
		return 0, ref.ReasonFatal
	}
	if counters != nil {
		addCounter(&counters.Inputs, 1)
	}
	bits := math.Float64bits(value)
	reason := s.model.IdentityReason(s.source, s.params)
	if reason != ref.ReasonNone {
		if counters != nil {
			addCounter(&counters.Fatal, 1)
		}
		return 0, reason
	}
	if !enabled {
		if counters != nil {
			addCounter(&counters.Fallbacks, 1)
		}
		return ref.OriginalBin(value), ref.ReasonNone
	}
	if s.valid && bits >= s.cert.Lo && bits <= s.cert.Hi {
		if counters != nil {
			addCounter(&counters.Hits, 1)
		}
		return s.cert.Bin, ref.ReasonNone
	}
	reason = s.model.DomainReason(bits)
	if reason == ref.ReasonDomain {
		if counters != nil {
			addCounter(&counters.Misses, 1)
			addCounter(&counters.DomainBypasses, 1)
			addCounter(&counters.Fallbacks, 1)
		}
		return ref.OriginalBin(value), ref.ReasonNone
	}
	if counters != nil {
		addCounter(&counters.Misses, 1)
	}
	for refinement := uint(0); refinement <= 4; refinement++ {
		width := uint64(1) << (40 - refinement)
		if bits < width || bits > math.MaxUint64-width {
			return 0, ref.ReasonFatal
		}
		cert, work, result := Certify(s.model, s.source, s.params, bits-width, bits+width, DefaultBudget, nil)
		if counters != nil {
			addCounter(&counters.Proposals, 1)
			addCounter(&counters.Refinements[refinement], 1)
			addCounter(&counters.Reasons[result], 1)
			addCounter(&counters.Nodes, uint64(work.Nodes))
			addCounter(&counters.Rounded, uint64(work.Rounded))
			addCounter(&counters.EndpointOps, uint64(work.EndpointOps))
			addCounter(&counters.OutwardSteps, uint64(work.OutwardSteps))
		}
		if result == ref.ReasonFatal {
			if counters != nil {
				addCounter(&counters.Fatal, 1)
			}
			return 0, result
		}
		if result != ref.ReasonNone {
			continue
		}
		if counters != nil {
			addCounter(&counters.Installs, 1)
			if s.valid {
				addCounter(&counters.Replacements, 1)
			}
		}
		s.cert, s.valid = cert, true
		return cert.Bin, ref.ReasonNone
	}
	if counters != nil {
		addCounter(&counters.Fallbacks, 1)
	}
	return ref.OriginalBin(value), ref.ReasonNone
}

func (c ReplayCounters) Reconciles(n uint64, enabled bool) bool {
	if n > math.MaxUint64/5 || c.Inputs != n || c.Resets != 1 || c.Fatal != 0 || c.Proposals > 5*n {
		return false
	}
	if !enabled {
		return c.Fallbacks == n && c.Proposals == 0 && c.Installs == 0 && c.Hits == 0 && c.Misses == 0
	}
	var attempts uint64
	for _, number := range c.Reasons {
		if number > math.MaxUint64-attempts {
			return false
		}
		attempts += number
	}
	var refinements uint64
	for _, number := range c.Refinements {
		if number > math.MaxUint64-refinements {
			return false
		}
		refinements += number
	}
	return refinements == c.Proposals && c.Hits+c.Misses == n && c.Installs+c.Fallbacks == c.Misses && c.Reasons[ref.ReasonNone] == c.Installs && attempts == c.Proposals && c.DomainBypasses <= c.Fallbacks && c.Replacements <= c.Installs
}

// Counted functional replay has explicit overflow guards. Qualified replay
// passes nil counters, so evidence bookkeeping is not an extra timed hit cost.
func addCounter(target *uint64, delta uint64) {
	if delta > math.MaxUint64-*target {
		panic("fast replay counter overflow")
	}
	*target += delta
}

const replayCorpusSize = 8192

var replayCorpora = []string{"Increasing", "Repeated", "UniqueCycle", "NearbyUniqueCycle", "MostlyUniqueCycle", "Phases", "BroadHoldout", "NegativeBins"}

// These are byte-identical numerical inputs from the authored DD corpus. This
// private module owns the copy; the consuming package independently compares it.
func replayValues(corpus string) [replayCorpusSize]float64 {
	var values [replayCorpusSize]float64
	negative := [8]float64{1e-12, 1.0625e-12, 1.125e-12, 1.25e-12, 1.375e-12, 1.5e-12, 1.75e-12, 2e-12}
	for index := range values {
		switch corpus {
		case "Increasing", "UniqueCycle":
			values[index] = float64(index + 1)
		case "Repeated":
			values[index] = 42
		case "NearbyUniqueCycle":
			values[index] = math.Float64frombits(math.Float64bits(42) + uint64(index))
		case "MostlyUniqueCycle":
			values[index] = float64(1_000_000 + index)
			if index%16 == 0 {
				values[index] = 42
			}
		case "Phases":
			values[index] = float64(1_000_000 + index)
			if index/1024%2 == 0 {
				values[index] = float64(40 + index%16)
			}
		case "BroadHoldout":
			mantissa := uint64(index+1) * 0x9e3779b97f4a7c15 & ((1 << 52) - 1)
			exponent := uint64(723 + index*37%601)
			values[index] = math.Float64frombits(exponent<<52 | mantissa)
		case "NegativeBins":
			values[index] = negative[index%len(negative)]
		default:
			panic("unknown frozen replay corpus")
		}
	}
	return values
}

// CorpusBytes supplies an owned fixed 64KiB input identity to the DD overlay.
func CorpusBytes(corpus string) []byte {
	values := replayValues(corpus)
	data := make([]byte, 8*len(values))
	for index, value := range values {
		binary.LittleEndian.PutUint64(data[index*8:], math.Float64bits(value))
	}
	return data
}
