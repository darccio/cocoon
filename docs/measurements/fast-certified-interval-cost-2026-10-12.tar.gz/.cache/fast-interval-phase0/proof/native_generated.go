// Code generated from the pinned source numeric graph by cmd/generate-native; DO NOT EDIT.
package fastinterval

import ref "cocoonfastintervalproof/reference"

const (
	compiledCount     = 76
	compiledRounded   = 30
	compiledOutput    = 75
	compiledLogOutput = 69
)

func compiledProgramID() [32]byte {
	return [32]uint8{0x96, 0xa5, 0x21, 0x2f, 0x2b, 0xa3, 0xa8, 0x45, 0x1, 0x93, 0xfa, 0xbb, 0x49, 0x14, 0x47, 0x35, 0x3b, 0x4c, 0xd9, 0x6a, 0x0, 0x87, 0xca, 0x5c, 0x9e, 0x77, 0xcd, 0xcf, 0xeb, 0x54, 0xe2, 0x20}
}
func compiledSourceSHA() [32]byte {
	return [32]uint8{0x62, 0x65, 0x50, 0xca, 0xfa, 0x32, 0x3c, 0x49, 0xa, 0x6a, 0x2e, 0xc6, 0xb2, 0xb3, 0x41, 0x65, 0x6c, 0x40, 0xe2, 0x23, 0xc7, 0xc8, 0x47, 0x1, 0xe4, 0x14, 0x7, 0x86, 0x33, 0xdc, 0xc2, 0x98}
}
func compiledParams() ref.Params {
	return ref.Params{0x3ff0400000000000, 0x40501fead4ea6e2b, 0x10400000000000, 0x4094ea0000000000}
}
func programSnapshot() ref.NumericSnapshot {
	return ref.NumericSnapshot{
		SourceSHA: compiledSourceSHA(), Params: compiledParams(), Count: compiledCount, Rounded: compiledRounded, Output: compiledOutput, LogOutput: compiledLogOutput,
		Nodes: [256]ref.Node{
			0:  {Bits: 0x0, A: 0, B: 0, Op: ref.Op(0)},
			1:  {Bits: 0x0, A: 0, B: 0, Op: ref.Op(1)},
			2:  {Bits: 0x3fe62e42fee00000, A: 0, B: 0, Op: ref.Op(2)},
			3:  {Bits: 0x0, A: 1, B: 2, Op: ref.Op(6)},
			4:  {Bits: 0x0, A: 3, B: 0, Op: ref.Op(8)},
			5:  {Bits: 0xbff0000000000000, A: 0, B: 0, Op: ref.Op(2)},
			6:  {Bits: 0x0, A: 0, B: 5, Op: ref.Op(4)},
			7:  {Bits: 0x0, A: 6, B: 0, Op: ref.Op(8)},
			8:  {Bits: 0x3dea39ef35793c76, A: 0, B: 0, Op: ref.Op(2)},
			9:  {Bits: 0x0, A: 1, B: 8, Op: ref.Op(6)},
			10: {Bits: 0x0, A: 9, B: 0, Op: ref.Op(8)},
			11: {Bits: 0x4000000000000000, A: 0, B: 0, Op: ref.Op(2)},
			12: {Bits: 0x0, A: 7, B: 11, Op: ref.Op(4)},
			13: {Bits: 0x0, A: 12, B: 0, Op: ref.Op(8)},
			14: {Bits: 0x0, A: 7, B: 13, Op: ref.Op(7)},
			15: {Bits: 0x0, A: 14, B: 0, Op: ref.Op(8)},
			16: {Bits: 0x3fe0000000000000, A: 0, B: 0, Op: ref.Op(2)},
			17: {Bits: 0x0, A: 7, B: 16, Op: ref.Op(6)},
			18: {Bits: 0x0, A: 17, B: 0, Op: ref.Op(8)},
			19: {Bits: 0x0, A: 7, B: 18, Op: ref.Op(6)},
			20: {Bits: 0x0, A: 19, B: 0, Op: ref.Op(8)},
			21: {Bits: 0x0, A: 15, B: 15, Op: ref.Op(6)},
			22: {Bits: 0x0, A: 21, B: 0, Op: ref.Op(8)},
			23: {Bits: 0x0, A: 22, B: 22, Op: ref.Op(6)},
			24: {Bits: 0x0, A: 23, B: 0, Op: ref.Op(8)},
			25: {Bits: 0x3fc39a09d078c69f, A: 0, B: 0, Op: ref.Op(2)},
			26: {Bits: 0x0, A: 24, B: 25, Op: ref.Op(6)},
			27: {Bits: 0x0, A: 26, B: 0, Op: ref.Op(8)},
			28: {Bits: 0x3fcc71c51d8e78af, A: 0, B: 0, Op: ref.Op(2)},
			29: {Bits: 0x0, A: 27, B: 28, Op: ref.Op(4)},
			30: {Bits: 0x0, A: 29, B: 0, Op: ref.Op(8)},
			31: {Bits: 0x0, A: 24, B: 30, Op: ref.Op(6)},
			32: {Bits: 0x0, A: 31, B: 0, Op: ref.Op(8)},
			33: {Bits: 0x3fd999999997fa04, A: 0, B: 0, Op: ref.Op(2)},
			34: {Bits: 0x0, A: 32, B: 33, Op: ref.Op(4)},
			35: {Bits: 0x0, A: 34, B: 0, Op: ref.Op(8)},
			36: {Bits: 0x0, A: 24, B: 35, Op: ref.Op(6)},
			37: {Bits: 0x0, A: 36, B: 0, Op: ref.Op(8)},
			38: {Bits: 0x3fc2f112df3e5244, A: 0, B: 0, Op: ref.Op(2)},
			39: {Bits: 0x0, A: 24, B: 38, Op: ref.Op(6)},
			40: {Bits: 0x0, A: 39, B: 0, Op: ref.Op(8)},
			41: {Bits: 0x3fc7466496cb03de, A: 0, B: 0, Op: ref.Op(2)},
			42: {Bits: 0x0, A: 40, B: 41, Op: ref.Op(4)},
			43: {Bits: 0x0, A: 42, B: 0, Op: ref.Op(8)},
			44: {Bits: 0x0, A: 24, B: 43, Op: ref.Op(6)},
			45: {Bits: 0x0, A: 44, B: 0, Op: ref.Op(8)},
			46: {Bits: 0x3fd2492494229359, A: 0, B: 0, Op: ref.Op(2)},
			47: {Bits: 0x0, A: 45, B: 46, Op: ref.Op(4)},
			48: {Bits: 0x0, A: 47, B: 0, Op: ref.Op(8)},
			49: {Bits: 0x0, A: 24, B: 48, Op: ref.Op(6)},
			50: {Bits: 0x0, A: 49, B: 0, Op: ref.Op(8)},
			51: {Bits: 0x3fe5555555555593, A: 0, B: 0, Op: ref.Op(2)},
			52: {Bits: 0x0, A: 50, B: 51, Op: ref.Op(4)},
			53: {Bits: 0x0, A: 52, B: 0, Op: ref.Op(8)},
			54: {Bits: 0x0, A: 22, B: 53, Op: ref.Op(6)},
			55: {Bits: 0x0, A: 54, B: 0, Op: ref.Op(8)},
			56: {Bits: 0x0, A: 37, B: 55, Op: ref.Op(4)},
			57: {Bits: 0x0, A: 56, B: 0, Op: ref.Op(8)},
			58: {Bits: 0x0, A: 20, B: 57, Op: ref.Op(4)},
			59: {Bits: 0x0, A: 58, B: 0, Op: ref.Op(8)},
			60: {Bits: 0x0, A: 15, B: 59, Op: ref.Op(6)},
			61: {Bits: 0x0, A: 60, B: 0, Op: ref.Op(8)},
			62: {Bits: 0x0, A: 10, B: 61, Op: ref.Op(4)},
			63: {Bits: 0x0, A: 62, B: 0, Op: ref.Op(8)},
			64: {Bits: 0x0, A: 63, B: 20, Op: ref.Op(5)},
			65: {Bits: 0x0, A: 64, B: 0, Op: ref.Op(8)},
			66: {Bits: 0x0, A: 7, B: 65, Op: ref.Op(4)},
			67: {Bits: 0x0, A: 66, B: 0, Op: ref.Op(8)},
			68: {Bits: 0x0, A: 4, B: 67, Op: ref.Op(4)},
			69: {Bits: 0x0, A: 68, B: 0, Op: ref.Op(8)},
			70: {Bits: 0x40501fead4ea6e2b, A: 0, B: 0, Op: ref.Op(2)},
			71: {Bits: 0x4094ea0000000000, A: 0, B: 0, Op: ref.Op(2)},
			72: {Bits: 0x0, A: 70, B: 69, Op: ref.Op(6)},
			73: {Bits: 0x0, A: 72, B: 0, Op: ref.Op(8)},
			74: {Bits: 0x0, A: 73, B: 71, Op: ref.Op(4)},
			75: {Bits: 0x0, A: 74, B: 0, Op: ref.Op(8)},
		}}
}
func runUnrolled(t *ref.Trace, w *NativeWork, b Budget) ref.Reason {
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Count = 1
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Count = 2
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[2] = ref.Bounds{Lo: 0x3fe62e42fee00000, Hi: 0x3fe62e42fee00000}
	t.Count = 3
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(6), t.Slots[1], t.Slots[2], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[3] = result
	}
	t.Count = 4
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[4] = t.Slots[3]
	t.Count = 5
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[5] = ref.Bounds{Lo: 0xbff0000000000000, Hi: 0xbff0000000000000}
	t.Count = 6
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(4), t.Slots[0], t.Slots[5], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[6] = result
	}
	t.Count = 7
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[7] = t.Slots[6]
	t.Count = 8
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[8] = ref.Bounds{Lo: 0x3dea39ef35793c76, Hi: 0x3dea39ef35793c76}
	t.Count = 9
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(6), t.Slots[1], t.Slots[8], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[9] = result
	}
	t.Count = 10
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[10] = t.Slots[9]
	t.Count = 11
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[11] = ref.Bounds{Lo: 0x4000000000000000, Hi: 0x4000000000000000}
	t.Count = 12
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(4), t.Slots[7], t.Slots[11], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[12] = result
	}
	t.Count = 13
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[13] = t.Slots[12]
	t.Count = 14
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(7), t.Slots[7], t.Slots[13], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[14] = result
	}
	t.Count = 15
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[15] = t.Slots[14]
	t.Count = 16
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[16] = ref.Bounds{Lo: 0x3fe0000000000000, Hi: 0x3fe0000000000000}
	t.Count = 17
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(6), t.Slots[7], t.Slots[16], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[17] = result
	}
	t.Count = 18
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[18] = t.Slots[17]
	t.Count = 19
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(6), t.Slots[7], t.Slots[18], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[19] = result
	}
	t.Count = 20
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[20] = t.Slots[19]
	t.Count = 21
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(6), t.Slots[15], t.Slots[15], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[21] = result
	}
	t.Count = 22
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[22] = t.Slots[21]
	t.Count = 23
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(6), t.Slots[22], t.Slots[22], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[23] = result
	}
	t.Count = 24
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[24] = t.Slots[23]
	t.Count = 25
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[25] = ref.Bounds{Lo: 0x3fc39a09d078c69f, Hi: 0x3fc39a09d078c69f}
	t.Count = 26
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(6), t.Slots[24], t.Slots[25], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[26] = result
	}
	t.Count = 27
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[27] = t.Slots[26]
	t.Count = 28
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[28] = ref.Bounds{Lo: 0x3fcc71c51d8e78af, Hi: 0x3fcc71c51d8e78af}
	t.Count = 29
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(4), t.Slots[27], t.Slots[28], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[29] = result
	}
	t.Count = 30
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[30] = t.Slots[29]
	t.Count = 31
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(6), t.Slots[24], t.Slots[30], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[31] = result
	}
	t.Count = 32
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[32] = t.Slots[31]
	t.Count = 33
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[33] = ref.Bounds{Lo: 0x3fd999999997fa04, Hi: 0x3fd999999997fa04}
	t.Count = 34
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(4), t.Slots[32], t.Slots[33], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[34] = result
	}
	t.Count = 35
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[35] = t.Slots[34]
	t.Count = 36
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(6), t.Slots[24], t.Slots[35], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[36] = result
	}
	t.Count = 37
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[37] = t.Slots[36]
	t.Count = 38
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[38] = ref.Bounds{Lo: 0x3fc2f112df3e5244, Hi: 0x3fc2f112df3e5244}
	t.Count = 39
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(6), t.Slots[24], t.Slots[38], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[39] = result
	}
	t.Count = 40
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[40] = t.Slots[39]
	t.Count = 41
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[41] = ref.Bounds{Lo: 0x3fc7466496cb03de, Hi: 0x3fc7466496cb03de}
	t.Count = 42
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(4), t.Slots[40], t.Slots[41], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[42] = result
	}
	t.Count = 43
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[43] = t.Slots[42]
	t.Count = 44
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(6), t.Slots[24], t.Slots[43], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[44] = result
	}
	t.Count = 45
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[45] = t.Slots[44]
	t.Count = 46
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[46] = ref.Bounds{Lo: 0x3fd2492494229359, Hi: 0x3fd2492494229359}
	t.Count = 47
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(4), t.Slots[45], t.Slots[46], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[47] = result
	}
	t.Count = 48
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[48] = t.Slots[47]
	t.Count = 49
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(6), t.Slots[24], t.Slots[48], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[49] = result
	}
	t.Count = 50
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[50] = t.Slots[49]
	t.Count = 51
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[51] = ref.Bounds{Lo: 0x3fe5555555555593, Hi: 0x3fe5555555555593}
	t.Count = 52
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(4), t.Slots[50], t.Slots[51], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[52] = result
	}
	t.Count = 53
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[53] = t.Slots[52]
	t.Count = 54
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(6), t.Slots[22], t.Slots[53], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[54] = result
	}
	t.Count = 55
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[55] = t.Slots[54]
	t.Count = 56
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(4), t.Slots[37], t.Slots[55], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[56] = result
	}
	t.Count = 57
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[57] = t.Slots[56]
	t.Count = 58
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(4), t.Slots[20], t.Slots[57], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[58] = result
	}
	t.Count = 59
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[59] = t.Slots[58]
	t.Count = 60
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(6), t.Slots[15], t.Slots[59], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[60] = result
	}
	t.Count = 61
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[61] = t.Slots[60]
	t.Count = 62
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(4), t.Slots[10], t.Slots[61], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[62] = result
	}
	t.Count = 63
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[63] = t.Slots[62]
	t.Count = 64
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(5), t.Slots[63], t.Slots[20], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[64] = result
	}
	t.Count = 65
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[65] = t.Slots[64]
	t.Count = 66
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(4), t.Slots[7], t.Slots[65], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[66] = result
	}
	t.Count = 67
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[67] = t.Slots[66]
	t.Count = 68
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(4), t.Slots[4], t.Slots[67], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[68] = result
	}
	t.Count = 69
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[69] = t.Slots[68]
	t.Count = 70
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[70] = ref.Bounds{Lo: 0x40501fead4ea6e2b, Hi: 0x40501fead4ea6e2b}
	t.Count = 71
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[71] = ref.Bounds{Lo: 0x4094ea0000000000, Hi: 0x4094ea0000000000}
	t.Count = 72
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(6), t.Slots[70], t.Slots[69], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[72] = result
	}
	t.Count = 73
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[73] = t.Slots[72]
	t.Count = 74
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	{
		result, reason := transfer(ref.Op(4), t.Slots[73], t.Slots[71], w, b)
		if reason != ref.ReasonNone {
			return reason
		}
		t.Slots[74] = result
	}
	t.Count = 75
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	t.Slots[75] = t.Slots[74]
	t.Count = 76
	return ref.ReasonNone
}
