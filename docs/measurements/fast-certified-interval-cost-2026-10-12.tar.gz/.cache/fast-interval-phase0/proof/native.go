// Package fastinterval contains ignored numerical feasibility evidence only.
package fastinterval

import (
	"fmt"
	"math"
	"unsafe"

	"cocoonfastintervalproof/internal/generator"
	ref "cocoonfastintervalproof/reference"
)

// Model owns its entire numeric snapshot. Preparation is the only writer; a
// caller's mutable graph and value-returned Snapshot never alias this storage.
type Model struct {
	numeric  ref.NumericSnapshot
	program  [32]byte
	prepared bool
}

type Budget struct {
	Nodes, Rounded, CornerOps, OutwardSteps, WorkspaceBytes, ModelBytes uint32
}

var DefaultBudget = Budget{256, 96, 384, 192, 65536, 16384}

type NativeWork struct {
	Nodes, Rounded, EndpointOps, OutwardSteps, Comparisons, WorkspaceBytes uint32
}

type Attempt struct {
	Lo, Hi           uint64
	Work             NativeWork
	Bin              int32
	Seed, Refinement uint16
	Reason           ref.Reason
}

type BankReport struct {
	Attempts        [ref.MaxAttempts]Attempt
	Total           NativeWork
	Count, Accepted uint16
}

type Observer func(Attempt, *ref.Trace) error

func Prepare(g *ref.Graph) (*Model, error) {
	if err := ref.VerifyGraph(g); err != nil {
		return nil, fmt.Errorf("%w: source verification: %v", ref.ErrFatal, err)
	}
	snapshot := generator.Snapshot(g)
	if snapshot != programSnapshot() || generator.ID(snapshot) != compiledProgramID() {
		return nil, fmt.Errorf("%w: generated numeric program mismatch", ref.ErrFatal)
	}
	m := &Model{numeric: snapshot, program: compiledProgramID(), prepared: true}
	if m.Bytes() > ref.MaxGraphBytes {
		return nil, fmt.Errorf("%w: model bound", ref.ErrFatal)
	}
	return m, nil
}

func (m *Model) Snapshot() ref.NumericSnapshot {
	if m == nil {
		return ref.NumericSnapshot{}
	}
	return m.numeric
}
func (m *Model) SourceSHA() [32]byte {
	if m == nil {
		return [32]byte{}
	}
	return m.numeric.SourceSHA
}
func (m *Model) Params() ref.Params {
	if m == nil {
		return ref.Params{}
	}
	return m.numeric.Params
}
func (m *Model) ProgramID() [32]byte {
	if m == nil {
		return [32]byte{}
	}
	return m.program
}
func (m *Model) Bytes() uint32 { return uint32(unsafe.Sizeof(Model{})) }

func (m *Model) valid() bool {
	return m != nil && m.prepared && m.program == compiledProgramID() &&
		m.numeric.SourceSHA == compiledSourceSHA() && m.numeric.Params == compiledParams() &&
		m.numeric.Count == compiledCount && m.numeric.Rounded == compiledRounded &&
		m.numeric.Output == compiledOutput && m.numeric.LogOutput == compiledLogOutput
}

// PointReason is also the one-slot lookup identity guard. Legal callers cannot
// change private model data; arbitrary unsafe or same-package corruption is
// outside the owned immutable model premise. Preparation checks every node.
func (m *Model) PointReason(querySHA [32]byte, params ref.Params, bits uint64) ref.Reason {
	if reason := m.IdentityReason(querySHA, params); reason != ref.ReasonNone {
		return reason
	}
	return m.DomainReason(bits)
}

func (m *Model) IdentityReason(querySHA [32]byte, params ref.Params) ref.Reason {
	if !m.valid() {
		return ref.ReasonFatal
	}
	if querySHA != m.numeric.SourceSHA || params != m.numeric.Params {
		return ref.ReasonParameters
	}
	return ref.ReasonNone
}

// DomainReason follows IdentityReason on a miss. It requires an owned valid
// model and deliberately does no redundant source/config comparison.
func (m *Model) DomainReason(bits uint64) ref.Reason {
	if bits < m.numeric.Params[2] || bits < 0x0010000000000000 || bits > 0x7fefffffffffffff || bits == 0x3ff0000000000000 {
		return ref.ReasonDomain
	}
	return ref.ReasonNone
}

func finite(bits uint64) bool { return bits&0x7ff0000000000000 != 0x7ff0000000000000 }

// cell uses the original pinned integer reduction, independently checked by the
// rational adapter. It preserves low-word transitions in one exponent/carry cell.
func cell(params ref.Params, lo, hi uint64) (ref.Bounds, int32, uint8, ref.Reason) {
	if lo > hi || lo < 0x0010000000000000 || hi > 0x7fefffffffffffff || lo < params[2] {
		return ref.Bounds{}, 0, 0, ref.ReasonDomain
	}
	if lo <= 0x3ff0000000000000 && hi >= 0x3ff0000000000000 {
		return ref.Bounds{}, 0, 0, ref.ReasonCell
	}
	h0, h1 := uint32(lo>>32), uint32(hi>>32)
	c0, c1 := uint8((uint64(h0&0xfffff)+0x95f62)>>20), uint8((uint64(h1&0xfffff)+0x95f62)>>20)
	if lo>>52 != hi>>52 || c0 != c1 {
		return ref.Bounds{}, 0, 0, ref.ReasonCell
	}
	a0, a1 := uint64(h0)+0x95f62, uint64(h1)+0x95f62
	if a0 > math.MaxInt32 || a1 > math.MaxInt32 || a0>>20 != a1>>20 {
		return ref.Bounds{}, 0, 0, ref.ReasonCell
	}
	r0 := lo&0xffffffff | ((a0&0xfffff)+0x3fe6a09e)<<32
	r1 := hi&0xffffffff | ((a1&0xfffff)+0x3fe6a09e)<<32
	if r1 < r0 || r1-r0 != hi-lo || !finite(r0) || !finite(r1) || r0>>63 != 0 {
		return ref.Bounds{}, 0, 0, ref.ReasonFatal
	}
	return ref.Bounds{Lo: r0, Hi: r1}, int32(a0>>20) - 1023, c0, ref.ReasonNone
}

// WorkspaceBytes accounts fixed logical data, not compiler stack copies/RSS.
// Two bank/report images cover result handoff, two traces cover observation,
// and 512 bytes conservatively reserve scalar/corner/request scratch.
func WorkspaceBytes() uint32 {
	return uint32(2*unsafe.Sizeof(ref.Bank{}) + 2*unsafe.Sizeof(BankReport{}) + 2*unsafe.Sizeof(ref.Trace{}) + unsafe.Sizeof(Budget{}) + unsafe.Sizeof(NativeWork{}) + 512)
}

func validBudget(b Budget) bool {
	return b.Nodes <= 256 && b.Rounded <= 96 && b.CornerOps <= 384 && b.OutwardSteps <= 192 && b.WorkspaceBytes <= 65536 && b.ModelBytes <= 16384
}

// Each corner contains exactly one explicitly rounded source operation. Do not
// replace these casts with a combined multiply/add expression.
func rounded(op ref.Op, a, b float64) float64 {
	switch op {
	case ref.OpAdd:
		return float64(a + b)
	case ref.OpSub:
		return float64(a - b)
	case ref.OpMul:
		return float64(a * b)
	case ref.OpDiv:
		return float64(a / b)
	default:
		return math.NaN()
	}
}

func transfer(op ref.Op, a, b ref.Bounds, w *NativeWork, budget Budget) (ref.Bounds, ref.Reason) {
	al, ah := math.Float64frombits(a.Lo), math.Float64frombits(a.Hi)
	bl, bh := math.Float64frombits(b.Lo), math.Float64frombits(b.Hi)
	if !finite(a.Lo) || !finite(a.Hi) || !finite(b.Lo) || !finite(b.Hi) || al > ah || bl > bh {
		return ref.Bounds{}, ref.ReasonNonfinite
	}
	if op == ref.OpDiv && bl <= 0 && bh >= 0 {
		return ref.Bounds{}, ref.ReasonDivision
	}
	if w.Rounded >= budget.Rounded {
		return ref.Bounds{}, ref.ReasonBudget
	}
	corners := uint32(4)
	if op == ref.OpAdd || op == ref.OpSub {
		corners = 2
	}
	if w.EndpointOps+corners > budget.CornerOps || w.OutwardSteps+2 > budget.OutwardSteps {
		return ref.Bounds{}, ref.ReasonBudget
	}
	w.Rounded++
	var values [4]float64
	switch op {
	case ref.OpAdd:
		values[0] = rounded(op, al, bl)
		values[1] = rounded(op, ah, bh)
	case ref.OpSub:
		values[0] = rounded(op, al, bh)
		values[1] = rounded(op, ah, bl)
	case ref.OpMul, ref.OpDiv:
		values[0] = rounded(op, al, bl)
		values[1] = rounded(op, al, bh)
		values[2] = rounded(op, ah, bl)
		values[3] = rounded(op, ah, bh)
	default:
		return ref.Bounds{}, ref.ReasonFatal
	}
	w.EndpointOps += corners
	low, high := values[0], values[0]
	for i := uint32(0); i < corners; i++ {
		v := values[i]
		if !finite(math.Float64bits(v)) {
			return ref.Bounds{}, ref.ReasonNonfinite
		}
		if i != 0 {
			w.Comparisons += 2
			if v < low {
				low = v
			}
			if v > high {
				high = v
			}
		}
	}
	low = math.Nextafter(low, math.Inf(-1))
	high = math.Nextafter(high, math.Inf(1))
	w.OutwardSteps += 2
	result := ref.Bounds{Lo: math.Float64bits(low), Hi: math.Float64bits(high)}
	if !finite(result.Lo) || !finite(result.Hi) {
		return ref.Bounds{}, ref.ReasonNonfinite
	}
	return result, ref.ReasonNone
}

func storeNode(t *ref.Trace, w *NativeWork, b Budget, index uint16, op ref.Op, a, c uint16, bits uint64) ref.Reason {
	if w.Nodes >= b.Nodes {
		return ref.ReasonBudget
	}
	w.Nodes++
	var result ref.Bounds
	var reason ref.Reason
	switch op {
	case ref.OpReduced, ref.OpExponent:
		result = t.Slots[index]
	case ref.OpConst:
		result = ref.Bounds{Lo: bits, Hi: bits}
	case ref.OpCopy:
		result = t.Slots[a]
	case ref.OpNeg:
		input := t.Slots[a]
		result = ref.Bounds{Lo: input.Hi ^ 1<<63, Hi: input.Lo ^ 1<<63}
	case ref.OpAdd, ref.OpSub, ref.OpMul, ref.OpDiv:
		result, reason = transfer(op, t.Slots[a], t.Slots[c], w, b)
	default:
		return ref.ReasonFatal
	}
	if reason != ref.ReasonNone {
		return reason
	}
	t.Slots[index] = result
	t.Count = index + 1
	return ref.ReasonNone
}

func Certify(m *Model, querySHA [32]byte, params ref.Params, lo, hi uint64, budget Budget, trace *ref.Trace) (ref.Certificate, NativeWork, ref.Reason) {
	return certify(m, querySHA, params, lo, hi, budget, trace, false)
}
func CertifyLoop(m *Model, querySHA [32]byte, params ref.Params, lo, hi uint64, budget Budget, trace *ref.Trace) (ref.Certificate, NativeWork, ref.Reason) {
	return certify(m, querySHA, params, lo, hi, budget, trace, true)
}

func certify(m *Model, querySHA [32]byte, params ref.Params, lo, hi uint64, budget Budget, trace *ref.Trace, loop bool) (ref.Certificate, NativeWork, ref.Reason) {
	var local ref.Trace
	if trace == nil {
		trace = &local
	}
	*trace = ref.Trace{}
	w := NativeWork{WorkspaceBytes: WorkspaceBytes()}
	if !m.valid() {
		return ref.Certificate{}, w, ref.ReasonFatal
	}
	if querySHA != m.numeric.SourceSHA || params != m.numeric.Params {
		return ref.Certificate{}, w, ref.ReasonParameters
	}
	if !validBudget(budget) || m.Bytes() > budget.ModelBytes || w.WorkspaceBytes > budget.WorkspaceBytes || uint32(m.numeric.Count) > budget.Nodes || uint32(m.numeric.Rounded) > budget.Rounded {
		return ref.Certificate{}, w, ref.ReasonBudget
	}
	reduced, exponent, carry, reason := cell(params, lo, hi)
	if reason != ref.ReasonNone {
		return ref.Certificate{}, w, reason
	}
	trace.Lo, trace.Hi, trace.SourceSHA, trace.Params, trace.Exponent, trace.Carry = lo, hi, querySHA, params, exponent, carry
	trace.Slots[0] = reduced
	ebits := math.Float64bits(float64(exponent))
	trace.Slots[1] = ref.Bounds{Lo: ebits, Hi: ebits}
	if loop {
		for i := uint16(0); i < m.numeric.Count; i++ {
			n := m.numeric.Nodes[i]
			if reason = storeNode(trace, &w, budget, i, n.Op, n.A, n.B, n.Bits); reason != ref.ReasonNone {
				break
			}
		}
	} else {
		reason = runUnrolled(trace, &w, budget)
	}
	if reason != ref.ReasonNone {
		return ref.Certificate{}, w, reason
	}
	end := trace.Slots[m.numeric.Output]
	lower, upper := math.Float64frombits(end.Lo), math.Float64frombits(end.Hi)
	if !finite(end.Lo) || !finite(end.Hi) || lower > upper {
		return ref.Certificate{}, w, ref.ReasonNonfinite
	}
	k := math.Floor(lower)
	if k <= math.MinInt32 || k >= math.MaxInt32 || upper >= k+1 {
		return ref.Certificate{}, w, ref.ReasonBoundary
	}
	return ref.Certificate{Lo: lo, Hi: hi, Bin: int32(k)}, w, ref.ReasonNone
}

func addWork(total *NativeWork, w NativeWork) {
	total.Nodes += w.Nodes
	total.Rounded += w.Rounded
	total.EndpointOps += w.EndpointOps
	total.OutwardSteps += w.OutwardSteps
	total.Comparisons += w.Comparisons
	total.WorkspaceBytes = max(total.WorkspaceBytes, w.WorkspaceBytes)
}

func BuildBank(m *Model, budget Budget, observe Observer) (ref.Bank, BankReport, error) {
	return buildBank(m, budget, observe, false)
}
func BuildBankLoop(m *Model, budget Budget, observe Observer) (ref.Bank, BankReport, error) {
	return buildBank(m, budget, observe, true)
}

func buildBank(m *Model, budget Budget, observe Observer, loop bool) (ref.Bank, BankReport, error) {
	var bank ref.Bank
	var report BankReport
	if !m.valid() {
		return bank, report, ref.ErrFatal
	}
	if !validBudget(budget) || WorkspaceBytes() > budget.WorkspaceBytes || m.Bytes() > budget.ModelBytes {
		return bank, report, &ref.UnknownError{Reason: ref.ReasonBudget}
	}
	bank.SourceSHA, bank.Params = m.SourceSHA(), m.Params()
	var trace ref.Trace
	for seed, bits := range ref.Seeds() {
		for refinement := 0; refinement <= 4; refinement++ {
			if report.Count >= ref.MaxAttempts {
				return bank, report, ref.ErrFatal
			}
			width := uint64(1) << uint(40-refinement)
			if bits < width || bits > math.MaxUint64-width {
				return bank, report, ref.ErrFatal
			}
			lo, hi := bits-width, bits+width
			cert, work, reason := certify(m, bank.SourceSHA, bank.Params, lo, hi, budget, &trace, loop)
			attempt := Attempt{Lo: lo, Hi: hi, Work: work, Bin: cert.Bin, Seed: uint16(seed), Refinement: uint16(refinement), Reason: reason}
			report.Attempts[report.Count] = attempt
			report.Count++
			addWork(&report.Total, work)
			if reason == ref.ReasonFatal {
				return bank, report, ref.ErrFatal
			}
			if observe != nil {
				if err := observe(attempt, &trace); err != nil {
					return bank, report, fmt.Errorf("%w: observer: %v", ref.ErrFatal, err)
				}
			}
			if reason != ref.ReasonNone {
				continue
			}
			for j := uint16(0); j < bank.Count; j++ {
				other := bank.Certificates[j]
				if cert.Lo <= other.Hi && other.Lo <= cert.Hi && cert.Bin != other.Bin {
					return bank, report, ref.ErrFatal
				}
			}
			if bank.Count >= ref.MaxCertificates {
				return bank, report, ref.ErrFatal
			}
			bank.Certificates[bank.Count] = cert
			bank.Count++
			report.Accepted++
			break
		}
	}
	return bank, report, nil
}

func Lookup(m *Model, bank *ref.Bank, querySHA [32]byte, params ref.Params, bits uint64) (int32, bool, ref.Reason) {
	if reason := m.PointReason(querySHA, params, bits); reason != ref.ReasonNone {
		return 0, false, reason
	}
	if bank == nil || bank.Count > ref.MaxCertificates || bank.SourceSHA != querySHA || bank.Params != params {
		return 0, false, ref.ReasonParameters
	}
	for i := uint16(0); i < bank.Count; i++ {
		c := bank.Certificates[i]
		if bits >= c.Lo && bits <= c.Hi {
			return c.Bin, true, ref.ReasonNone
		}
	}
	return 0, false, ref.ReasonNone
}
