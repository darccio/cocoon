package main

import (
	"flag"
	"log"
	"os"

	"cocoonfastintervalproof/internal/generator"
	ref "cocoonfastintervalproof/reference"
)

func main() {
	input := flag.String("source", "", "pinned translated module")
	output := flag.String("output", "native_generated.go", "generated Go output")
	flag.Parse()
	if *input == "" {
		log.Fatal("source is required")
	}
	g, err := ref.Load(*input)
	if err != nil {
		log.Fatal(err)
	}
	data, err := generator.Source(g)
	if err != nil {
		log.Fatal(err)
	}
	if err = os.WriteFile(*output, data, 0o644); err != nil {
		log.Fatal(err)
	}
}
