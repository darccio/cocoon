package fastinterval

import (
	"bufio"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"runtime"
	"strconv"
	"testing"
	"time"

	ref "cocoonfastintervalproof/reference"
)

func replayValue(values *[replayCorpusSize]float64, increasing bool, index uint64) float64 {
	if increasing {
		return float64(index + 1)
	}
	return values[index&(replayCorpusSize-1)]
}

// RollingDigest consumes the ordered output; it is consistency evidence, not a
// replacement for the independent universal containment argument.
func RollingDigest(digest uint64, index uint64, bin int32) uint64 {
	return (digest<<7 | digest>>(64-7)) ^ (uint64(uint32(bin)) + 0x9e3779b97f4a7c15*(index+1))
}

func replayCount(tb testing.TB) uint64 {
	tb.Helper()
	text := os.Getenv("COCOON_FAST_REPLAY_N")
	if text == "" {
		tb.Fatal("complete replay requires explicit COCOON_FAST_REPLAY_N")
	}
	n, err := strconv.ParseUint(text, 10, 64)
	if err != nil || n != 4194304 && n != 8388608 {
		tb.Fatalf("replay prefix must be exactly4M/8M: %q %v", text, err)
	}
	return n
}

func writeReplayEvent(tb testing.TB, name string, value any) {
	tb.Helper()
	data, err := json.Marshal(struct {
		Event string `json:"event"`
		Data  any    `json:"data"`
	}{name, value})
	if err != nil {
		tb.Fatal(err)
	}
	path := os.Getenv("COCOON_FAST_REPLAY_OUTPUT")
	if path == "" {
		tb.Logf("FAST_REPLAY %s", data)
		return
	}
	file, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_APPEND, 0o600)
	if err != nil {
		tb.Fatal(err)
	}
	if _, err := fmt.Fprintf(file, "%s\n", data); err != nil {
		_ = file.Close()
		tb.Fatal(err)
	}
	if err := file.Close(); err != nil {
		tb.Fatal(err)
	}
}

func TestFrozenReplayCorpora(t *testing.T) {
	for _, corpus := range replayCorpora {
		values := replayValues(corpus)
		for _, value := range values {
			if value <= 0 || math.IsNaN(value) || math.IsInf(value, 0) {
				t.Fatalf("frozen corpus %s left declared domain", corpus)
			}
		}
	}
	if got := replayValues("Increasing"); got[0] != 1 || got[len(got)-1] != 8192 {
		t.Fatal("Increasing helper changed")
	}
	if runtime.GOARCH == "386" && uint64(int64(8388608)) != 8388608 {
		t.Fatal("prefix overflow")
	}
}

type hostPreparation struct {
	graph       *ref.Graph
	model       *Model
	nanoseconds int64
	allocated   uint64
}

func prepareHost(tb testing.TB) hostPreparation {
	tb.Helper()
	path := os.Getenv("COCOON_FAST_INTERVAL_SOURCE")
	if path == "" {
		path = "../../../examples/datadog/go/dd/internal/wasm/module.go"
	}
	var before, after runtime.MemStats
	runtime.ReadMemStats(&before)
	start := time.Now()
	graph, err := ref.Load(path)
	if err != nil {
		tb.Fatal(err)
	}
	model, err := Prepare(graph)
	if err != nil {
		tb.Fatal(err)
	}
	if err := ref.VerifyNumericSnapshot(graph, model.Snapshot()); err != nil {
		tb.Fatal(err)
	}
	elapsed := time.Since(start).Nanoseconds()
	runtime.ReadMemStats(&after)
	return hostPreparation{graph, model, elapsed, after.TotalAlloc - before.TotalAlloc}
}

func TestOneSlotPolicy(t *testing.T) {
	f := prepareHost(t)
	s, reason := NewOneSlot(f.model)
	if reason != ref.ReasonNone {
		t.Fatal(reason)
	}
	var counters ReplayCounters
	s.Reset(&counters)
	got, reason := s.MapMode(42, true, &counters)
	if reason != ref.ReasonNone || got != ref.OriginalBin(42) || counters.Installs != 1 {
		t.Fatal("first successful miss did not install", reason, counters)
	}
	prior, valid := s.Certificate()
	if !valid {
		t.Fatal("missing installed slot")
	}
	before := counters
	for _, value := range []float64{1, 2} {
		got, reason = s.MapMode(value, true, &counters)
		if reason != ref.ReasonNone || got != ref.OriginalBin(value) {
			t.Fatal("reference fallback changed")
		}
	}
	after, valid := s.Certificate()
	if !valid || after != prior || counters.DomainBypasses-before.DomainBypasses != 1 || counters.Proposals-before.Proposals != 5 || counters.Reasons[ref.ReasonCell]-before.Reasons[ref.ReasonCell] != 5 {
		t.Fatal("unsupported bypass/eligible five retries/old-slot preservation changed", counters)
	}
	for _, bits := range []uint64{0, 1 << 63, math.Float64bits(-42), 1, 0x000fffffffffffff, f.model.Params()[2] - 1, 0x7ff0000000000000, 0xfff0000000000000, 0x7ff8000000000001} {
		before := counters
		got, reason := s.MapMode(math.Float64frombits(bits), true, &counters)
		if reason != ref.ReasonNone || got != ref.OriginalBin(math.Float64frombits(bits)) || counters.Proposals != before.Proposals || counters.DomainBypasses != before.DomainBypasses+1 {
			t.Fatal("unsupported point did not bypass with exact fallback", bits, counters, reason)
		}
		if cert, valid := s.Certificate(); !valid || cert != prior {
			t.Fatal("unsupported point changed prior slot")
		}
	}
	_, hit, reason := s.Lookup(f.model.SourceSHA(), f.model.Params(), math.Float64bits(42))
	if reason != ref.ReasonNone || !hit {
		t.Fatal("preserved slot cannot hit")
	}
	params := f.model.Params()
	params[0] ^= 1
	if _, hit, reason = s.Lookup(f.model.SourceSHA(), params, math.Float64bits(42)); hit || reason != ref.ReasonParameters {
		t.Fatal("parameter mismatch hit")
	}
	sha := f.model.SourceSHA()
	sha[0] ^= 1
	if _, hit, reason = s.Lookup(sha, f.model.Params(), math.Float64bits(42)); hit || reason != ref.ReasonParameters {
		t.Fatal("source mismatch hit")
	}
	s.Reset(nil)
	if _, valid = s.Certificate(); valid {
		t.Fatal("reset retained a certificate")
	}
	if _, reason := NewOneSlot(nil); reason != ref.ReasonFatal {
		t.Fatal("nil model accepted")
	}
	if _, reason := NewOneSlot(&Model{}); reason != ref.ReasonFatal {
		t.Fatal("unprepared model accepted")
	}
	t.Log("host-policy-whole-evaluations=29 native-candidates6 full-original-bin23 (preparation/source binding separately reported)")
}

func TestReplayCounterOverflow(t *testing.T) {
	defer func() {
		if recover() == nil {
			t.Fatal("counter overflow was unchecked")
		}
	}()
	n := uint64(math.MaxUint64)
	addCounter(&n, 1)
}

// This explicitly large lockstep result scope is separate from the capped
// mathematical proof driver. It performs no independent interval verification.
func TestFastFullReplay(t *testing.T) {
	if os.Getenv("COCOON_FAST_REPLAY_N") == "" {
		t.Skip("full replay requires explicitly declared4M/8M prefix")
	}
	n := replayCount(t)
	f := prepareHost(t)
	if path := os.Getenv("COCOON_FAST_REPLAY_OUTPUT"); path != "" {
		file, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0o600)
		if err != nil {
			t.Fatal("replay evidence must be fresh", err)
		}
		if err := file.Close(); err != nil {
			t.Fatal(err)
		}
	}
	for _, corpus := range replayCorpora {
		values := replayValues(corpus)
		enabled, reason := NewOneSlot(f.model)
		if reason != ref.ReasonNone {
			t.Fatal(reason)
		}
		disabled, reason := NewOneSlot(f.model)
		if reason != ref.ReasonNone {
			t.Fatal(reason)
		}
		var counts, disabledCounts ReplayCounters
		enabled.Reset(&counts)
		disabled.Reset(&disabledCounts)
		var digest uint64
		for index := uint64(0); index < n; index++ {
			value := replayValue(&values, corpus == "Increasing", index)
			want := ref.OriginalBin(value)
			got, reason := enabled.MapMode(value, true, &counts)
			old, oldReason := disabled.MapMode(value, false, &disabledCounts)
			if reason != ref.ReasonNone || oldReason != ref.ReasonNone || got != want || old != want {
				t.Fatalf("full replay mismatch corpus=%s input=%d bits=%016x got=%d disabled=%d want=%d reasons=%v/%v", corpus, index, math.Float64bits(value), got, old, want, reason, oldReason)
			}
			digest = RollingDigest(digest, index, want)
			if (index+1)%1024 == 0 {
				writeReplayEvent(t, "replay_phase", struct {
					Corpus         string
					N, End, Digest uint64
					Counts         ReplayCounters
				}{corpus, n, index + 1, digest, counts})
			}
		}
		if !counts.Reconciles(n, true) || !disabledCounts.Reconciles(n, false) {
			t.Fatal("full replay counters disagree", corpus, counts, disabledCounts)
		}
		writeReplayEvent(t, "replay_summary", struct {
			Architecture, Corpus                                                string
			N, Digest, DirectCalls, DisabledOriginalCalls, EnabledOriginalCalls uint64
			Counts                                                              ReplayCounters
			PreparationNS                                                       int64
			PreparationBytes                                                    uint64
		}{runtime.GOARCH, corpus, n, digest, n, disabledCounts.Fallbacks, counts.Fallbacks, counts, f.nanoseconds, f.allocated})
	}
}

func expectedReplayDigest(tb testing.TB, corpus string, n uint64) uint64 {
	tb.Helper()
	path := os.Getenv("COCOON_FAST_REPLAY_EXPECTED")
	if path == "" {
		tb.Fatal("timed replay requires prevalidated COCOON_FAST_REPLAY_EXPECTED")
	}
	file, err := os.Open(path)
	if err != nil {
		tb.Fatal(err)
	}
	defer file.Close()
	scan := bufio.NewScanner(file)
	scan.Buffer(make([]byte, 4096), 1<<20)
	for scan.Scan() {
		var event struct {
			Event string
			Data  struct {
				Architecture, Corpus string
				N, Digest            uint64
			}
		}
		if err := json.Unmarshal(scan.Bytes(), &event); err != nil {
			tb.Fatal(err)
		}
		if event.Event == "replay_summary" && event.Data.Corpus == corpus && event.Data.N == n && event.Data.Architecture == runtime.GOARCH {
			return event.Data.Digest
		}
	}
	if err := scan.Err(); err != nil {
		tb.Fatal(err)
	}
	tb.Fatal("no matching validated replay digest", corpus, n, runtime.GOARCH)
	return 0
}

var replayDigestSink uint64

func BenchmarkFastNumericReplay(b *testing.B) {
	for _, role := range []string{"Direct", "Disabled", "Enabled"} {
		b.Run(role, func(b *testing.B) {
			for _, corpus := range replayCorpora {
				b.Run(corpus, func(b *testing.B) {
					b.StopTimer()
					if b.N != 1 {
						b.Fatal("complete replay requires benchtime1x")
					}
					n := replayCount(b)
					f := prepareHost(b)
					values := replayValues(corpus)
					increasing := corpus == "Increasing"
					want := expectedReplayDigest(b, corpus, n)
					state, reason := NewOneSlot(f.model)
					if reason != ref.ReasonNone {
						b.Fatal(reason)
					}
					if runtime.GOMAXPROCS(0) != 1 {
						b.Fatal("numeric replay requires actualP1")
					}
					b.ReportAllocs()
					b.ResetTimer()
					b.StartTimer()
					var digest uint64
					for range b.N {
						state.Reset(nil)
						digest = 0
						if role == "Direct" {
							for index := uint64(0); index < n; index++ {
								value := replayValue(&values, increasing, index)
								digest = RollingDigest(digest, index, ref.OriginalBin(value))
							}
						} else {
							enabled := role == "Enabled"
							for index := uint64(0); index < n; index++ {
								value := replayValue(&values, increasing, index)
								got, reason := state.MapMode(value, enabled, nil)
								if reason != ref.ReasonNone {
									b.Fatal("fatal/mismatched model in numeric replay", reason)
								}
								digest = RollingDigest(digest, index, got)
							}
						}
					}
					b.StopTimer()
					replayDigestSink = digest
					if digest != want {
						b.Fatal("timed replay digest differs", corpus, digest, want)
					}
					if runtime.GOMAXPROCS(0) != 1 {
						b.Fatal("numeric replay changed actualP1")
					}
					b.ReportMetric(1, "actual-procs")
					b.ReportMetric(float64(n), "inputs/op")
					b.ReportMetric(float64(b.Elapsed().Nanoseconds())/float64(uint64(b.N)*n), "ns/input")
					b.ReportMetric(float64(f.nanoseconds), "source-model-prepare-ns")
					b.ReportMetric(float64(f.allocated), "source-model-prepare-bytes")
				})
			}
		})
	}
}
