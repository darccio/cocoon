package fastinterval

import (
	"bytes"
	"errors"
	"math"
	"math/big"
	"os"
	"testing"
	"unsafe"

	"cocoonfastintervalproof/internal/generator"
	ref "cocoonfastintervalproof/reference"
)

func nativeGraph(tb testing.TB) *ref.Graph {
	tb.Helper()
	path := os.Getenv("COCOON_INTERVAL_SOURCE")
	if path == "" {
		path = "../../../examples/datadog/go/dd/internal/wasm/module.go"
	}
	g, err := ref.Load(path)
	if err != nil {
		tb.Fatal(err)
	}
	return g
}
func nativeModel(tb testing.TB) (*ref.Graph, *Model) {
	tb.Helper()
	g := nativeGraph(tb)
	m, err := Prepare(g)
	if err != nil {
		tb.Fatal(err)
	}
	return g, m
}

func TestNativeOwnershipAndProgram(t *testing.T) {
	g, m := nativeModel(t)
	if m.Bytes() > 16384 || WorkspaceBytes() > 65536 || unsafe.Sizeof(ref.Bank{}) > 4096 {
		t.Fatal("fixed logical bounds exceeded")
	}
	if err := ref.VerifyNumericSnapshot(g, m.Snapshot()); err != nil {
		t.Fatal(err)
	}
	data, err := generator.Source(g)
	if err != nil {
		t.Fatal(err)
	}
	existing, err := os.ReadFile("native_generated.go")
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(data, existing) {
		t.Fatal("generated native program drift")
	}
	sha, params := m.SourceSHA(), m.Params()
	bits := math.Float64bits(42)
	var before, after ref.Trace
	cert, w, reason := Certify(m, sha, params, bits-1<<40, bits+1<<40, DefaultBudget, &before)
	if reason != ref.ReasonNone {
		t.Fatalf("baseline preparation %s", reason)
	}
	if _, err := ref.VerifyContainment(g, params, cert, &before); err != nil {
		t.Fatal(err)
	}
	copySnapshot := m.Snapshot()
	copySnapshot.Nodes[0].Op = ref.OpNeg
	copySnapshot.Params[0] ^= 1
	g.Nodes[0].Op = ref.OpNeg
	g.SourceSHA[0] ^= 1
	g.Params[0] ^= 1
	g.RawSnippet = "released input"
	got, afterW, afterReason := Certify(m, sha, params, bits-1<<40, bits+1<<40, DefaultBudget, &after)
	if got != cert || afterW != w || afterReason != reason || after != before {
		t.Fatal("input/snapshot alias changed prepared model")
	}
	if _, err := Prepare(g); !errors.Is(err, ref.ErrFatal) {
		t.Fatalf("mutated input prepare accepted: %v", err)
	}
	for _, change := range []func(*Model){func(m *Model) { m.prepared = false }, func(m *Model) { m.program[0] ^= 1 }, func(m *Model) { m.numeric.SourceSHA[0] ^= 1 }, func(m *Model) { m.numeric.Params[0] ^= 1 }, func(m *Model) { m.numeric.Count++ }} {
		changed := *m
		change(&changed)
		if _, _, r := Certify(&changed, sha, params, bits, bits, DefaultBudget, nil); r != ref.ReasonFatal {
			t.Fatalf("model identity corruption accepted: %s", r)
		}
	}
	if _, _, r := Certify(nil, sha, params, bits, bits, DefaultBudget, nil); r != ref.ReasonFatal {
		t.Fatal("nil model accepted")
	}
	if _, _, r := Certify(&Model{}, sha, params, bits, bits, DefaultBudget, nil); r != ref.ReasonFatal {
		t.Fatal("zero model accepted")
	}
	t.Logf("model=%d workspace=%d program=%x verification-ledger whole=10 tiny=0", m.Bytes(), WorkspaceBytes(), m.ProgramID())
}

func TestNativeFixedBank(t *testing.T) {
	_, m := nativeModel(t)
	bank, report, err := BuildBank(m, DefaultBudget, nil)
	if err != nil {
		t.Fatal(err)
	}
	loopBank, loopReport, err := BuildBankLoop(m, DefaultBudget, nil)
	if err != nil {
		t.Fatal(err)
	}
	if bank != loopBank || report != loopReport {
		t.Fatal("loop/unrolled bank decisions differ")
	}
	if bank.Count < 16 || report.Count > 320 || report.Total.WorkspaceBytes > 65536 {
		t.Fatalf("nonvacuity/bounds failed: %d %d %+v", bank.Count, report.Count, report.Total)
	}
	positive, negative := false, false
	exponents := map[uint64]bool{}
	for _, cert := range bank.Certificates[:bank.Count] {
		positive = positive || cert.Bin > 0
		negative = negative || cert.Bin < 0
		exponents[cert.Lo>>52] = true
		for _, bits := range []uint64{cert.Lo, cert.Lo + (cert.Hi-cert.Lo)/2, cert.Hi} {
			bin, ok, r := Lookup(m, &bank, m.SourceSHA(), m.Params(), bits)
			if !ok || r != ref.ReasonNone || bin != cert.Bin {
				t.Fatal("accepted bank lookup mismatch")
			}
		}
	}
	for i := uint64(0); i < 8192; i++ {
		if _, hit, r := Lookup(m, &bank, m.SourceSHA(), m.Params(), math.Float64bits(42)+i); !hit || r != ref.ReasonNone {
			t.Fatal("nearby8192 nonvacuity failed")
		}
	}
	if !positive || !negative || len(exponents) < 4 {
		t.Fatal("sign/exponent nonvacuity failed")
	}
	encoded, err := ref.BankBytes(&bank)
	if err != nil {
		t.Fatal(err)
	}
	if uintptr(len(encoded))+unsafe.Sizeof(bank) > 4096 {
		t.Fatal("bank+encoding exceeds4096")
	}
	counts := map[ref.Reason]int{}
	for _, attempt := range report.Attempts[:report.Count] {
		counts[attempt.Reason]++
	}
	t.Logf("accepted=%d attempts=%d categories=%v exponent-cells=%d bank+encoding=%d total=%+v verification-ledger whole=%d tiny=0 (lookup comparisons separately)", bank.Count, report.Count, counts, len(exponents), uintptr(len(encoded))+unsafe.Sizeof(bank), report.Total, 2*report.Count)
}

func TestNativeBudgetsAndDomains(t *testing.T) {
	_, m := nativeModel(t)
	sha, params := m.SourceSHA(), m.Params()
	bits := math.Float64bits(42)
	whole := 0
	for _, mutate := range []func(*Budget){
		func(b *Budget) { b.Nodes = 75 }, func(b *Budget) { b.Rounded = 29 }, func(b *Budget) { b.CornerOps = 0 }, func(b *Budget) { b.OutwardSteps = 0 }, func(b *Budget) { b.ModelBytes = m.Bytes() - 1 }, func(b *Budget) { b.WorkspaceBytes = WorkspaceBytes() - 1 },
		func(b *Budget) { b.Nodes = 257 }, func(b *Budget) { b.Rounded = 97 }, func(b *Budget) { b.CornerOps = 385 }, func(b *Budget) { b.OutwardSteps = 193 }, func(b *Budget) { b.ModelBytes = 16385 }, func(b *Budget) { b.WorkspaceBytes = 65537 },
	} {
		b := DefaultBudget
		mutate(&b)
		trace := ref.Trace{Count: 256}
		trace.Slots[255] = ref.Bounds{Lo: 1, Hi: 2}
		cert, w, r := Certify(m, sha, params, bits, bits, b, &trace)
		whole++
		if r != ref.ReasonBudget || cert != (ref.Certificate{}) || trace.Slots[255] != (ref.Bounds{}) || w.WorkspaceBytes != WorkspaceBytes() {
			t.Fatalf("budget bypass: %+v %s", b, r)
		}
		if w.EndpointOps > b.CornerOps || w.OutwardSteps > b.OutwardSteps {
			t.Fatal("performed excess bounded work")
		}
	}
	for _, request := range []struct {
		lo, hi uint64
		reason ref.Reason
	}{
		{0, 0, ref.ReasonDomain}, {1, 1, ref.ReasonDomain}, {math.Float64bits(-42), math.Float64bits(-42), ref.ReasonDomain}, {0x7ff0000000000000, 0x7ff0000000000000, ref.ReasonDomain}, {0x7ff8000000000001, 0x7ff8000000000001, ref.ReasonDomain}, {params[2] - 1, params[2] - 1, ref.ReasonDomain}, {bits + 1, bits, ref.ReasonDomain},
		{0x3ff0000000000000, 0x3ff0000000000000, ref.ReasonCell}, {0x3fefffffffffffff, 0x3ff0000000000001, ref.ReasonCell}, {0x3ff6a09dffffffff, 0x3ff6a09e00000000, ref.ReasonCell}, {0x3fffffffffffffff, 0x4000000000000000, ref.ReasonCell},
	} {
		cert, w, r := Certify(m, sha, params, request.lo, request.hi, DefaultBudget, nil)
		whole++
		if r != request.reason || cert != (ref.Certificate{}) || w.Nodes != 0 {
			t.Fatalf("domain/cell result %x..%x: %s", request.lo, request.hi, r)
		}
	}
	changedSHA := sha
	changedSHA[0] ^= 1
	if _, _, r := Certify(m, changedSHA, params, bits, bits, DefaultBudget, nil); r != ref.ReasonParameters {
		t.Fatal("query source mismatch promoted")
	}
	whole++
	changedParams := params
	changedParams[1]++
	if _, _, r := Certify(m, sha, changedParams, bits, bits, DefaultBudget, nil); r != ref.ReasonParameters {
		t.Fatal("query parameters mismatch promoted")
	}
	whole++
	if m.PointReason(sha, params, math.Float64bits(1)) != ref.ReasonDomain {
		t.Fatal("one bypass domain not rejected")
	}
	for _, bits := range []uint64{params[2], params[2] + 1, 0x3fefffffffffffff, 0x3ff0000000000001, 0x7fefffffffffffff} {
		if m.PointReason(sha, params, bits) != ref.ReasonNone {
			t.Fatal("supported point rejected")
		}
	}
	small := DefaultBudget
	small.WorkspaceBytes = WorkspaceBytes() - 1
	if _, _, err := BuildBank(m, small, nil); !errors.Is(err, ref.ErrUnknown) {
		t.Fatal("full builder workspace bypass")
	}
	t.Logf("verification-ledger whole=%d tiny=0", whole)
}

//go:noinline
func witnessOperands() (float64, float64) {
	epsilon := math.Ldexp(1, -27)
	return float64(1 + epsilon), float64(1 - epsilon)
}

func TestNativeRoundedPrimitives(t *testing.T) {
	bounds := func(a, b float64) ref.Bounds { return ref.Bounds{Lo: math.Float64bits(a), Hi: math.Float64bits(b)} }
	for _, test := range []struct {
		op     ref.Op
		a, b   ref.Bounds
		reason ref.Reason
	}{
		{ref.OpAdd, bounds(1, 1), bounds(math.Ldexp(1, -53), math.Ldexp(1, -53)), ref.ReasonNone},
		{ref.OpSub, bounds(1, 1), bounds(1, 1), ref.ReasonNone},
		{ref.OpMul, bounds(-3, 2), bounds(-4, 5), ref.ReasonNone},
		{ref.OpDiv, bounds(-3, 2), bounds(-4, -2), ref.ReasonNone},
		{ref.OpDiv, bounds(-3, 2), bounds(2, 4), ref.ReasonNone},
		{ref.OpMul, bounds(math.SmallestNonzeroFloat64, math.SmallestNonzeroFloat64), bounds(0.5, 0.5), ref.ReasonNone},
		{ref.OpAdd, bounds(math.Copysign(0, -1), 0), bounds(0, 0), ref.ReasonNone},
		{ref.OpMul, bounds(math.MaxFloat64, math.MaxFloat64), bounds(2, 2), ref.ReasonNonfinite},
		{ref.OpAdd, bounds(math.MaxFloat64, math.MaxFloat64), bounds(0, 0), ref.ReasonNonfinite},
		{ref.OpDiv, bounds(1, 2), bounds(math.Copysign(0, -1), 0), ref.ReasonDivision},
		{ref.OpDiv, bounds(1, 2), bounds(-1, 1), ref.ReasonDivision},
	} {
		var work NativeWork
		out, r := transfer(test.op, test.a, test.b, &work, DefaultBudget)
		if r != test.reason {
			t.Fatalf("primitive %d: got %s want%s", test.op, r, test.reason)
		}
		if r != ref.ReasonNone {
			continue
		}
		lower := new(big.Rat).SetFloat64(math.Float64frombits(out.Lo))
		upper := new(big.Rat).SetFloat64(math.Float64frombits(out.Hi))
		for _, ab := range []uint64{test.a.Lo, test.a.Hi} {
			for _, bb := range []uint64{test.b.Lo, test.b.Hi} {
				a := new(big.Rat).SetFloat64(math.Float64frombits(ab))
				b := new(big.Rat).SetFloat64(math.Float64frombits(bb))
				exact := new(big.Rat)
				switch test.op {
				case ref.OpAdd:
					exact.Add(a, b)
				case ref.OpSub:
					exact.Sub(a, b)
				case ref.OpMul:
					exact.Mul(a, b)
				case ref.OpDiv:
					exact.Quo(a, b)
				}
				if lower.Cmp(exact) > 0 || upper.Cmp(exact) < 0 {
					t.Fatal("native bounds miss exact signed corner")
				}
			}
		}
	}
	a, b := witnessOperands()
	product := rounded(ref.OpMul, a, b)
	separate := rounded(ref.OpSub, product, 1)
	fused := math.FMA(a, b, -1)
	if separate != 0 || math.Float64bits(fused) != math.Float64bits(math.Ldexp(-1, -54)) || separate == fused {
		t.Fatalf("separate source rounding witness failed: product=%016x separate=%016x fused=%016x", math.Float64bits(product), math.Float64bits(separate), math.Float64bits(fused))
	}
	t.Log("primitive cases=11 plus runtime FMA witness2rounded+1FMA; these are not whole-graph calls")
}

func TestNativeWholeSourcePoints(t *testing.T) {
	g, m := nativeModel(t)
	whole := 0
	seeds := ref.Seeds()
	for _, bits := range seeds[:32] {
		_, point, err := ref.Point(g, g.Params, bits)
		whole++
		if err != nil {
			t.Fatal(err)
		}
		log := ref.OriginalLog(math.Float64frombits(bits))
		whole++
		bin := ref.OriginalBin(math.Float64frombits(bits))
		whole++
		if point.Slots[g.LogOutput].Lo != math.Float64bits(log) || math.Floor(math.Float64frombits(point.Slots[g.Output].Lo)) != float64(bin) {
			t.Fatal("graph/full compiled source drift")
		}
		var a, b ref.Trace
		ca, wa, ra := Certify(m, m.SourceSHA(), m.Params(), bits, bits, DefaultBudget, &a)
		whole++
		cb, wb, rb := CertifyLoop(m, m.SourceSHA(), m.Params(), bits, bits, DefaultBudget, &b)
		whole++
		if ca != cb || wa != wb || ra != rb || a != b {
			t.Fatal("loop/unrolled source-order/rounding difference")
		}
		if ra == ref.ReasonNone && ca.Bin != bin {
			t.Fatal("certified bin differs from original source")
		}
		if ra == ref.ReasonNone {
			if _, err := ref.VerifyContainment(g, g.Params, ca, &a); err != nil {
				t.Fatal(err)
			}
			whole++
		}
		for node := uint16(0); node < a.Count; node++ {
			v := math.Float64frombits(point.Slots[node].Lo)
			if v < math.Float64frombits(a.Slots[node].Lo) || v > math.Float64frombits(a.Slots[node].Hi) {
				t.Fatalf("node%d misses source rounded value", node)
			}
		}
	}
	t.Logf("verification-ledger whole=%d tiny=0 (3point evaluators+2constructors each; each unique accepted trace independently verified)", whole)
}

func TestNativeWarmedAllocations(t *testing.T) {
	g, m := nativeModel(t)
	bits := math.Float64bits(42)
	sha, params := m.SourceSHA(), m.Params()
	whole := 0
	var trace ref.Trace
	cert, _, r := Certify(m, sha, params, bits-1<<40, bits+1<<40, DefaultBudget, &trace)
	whole++
	if r != ref.ReasonNone {
		t.Fatal("allocation witness is not accepted", r)
	}
	if _, err := ref.VerifyContainment(g, params, cert, &trace); err != nil {
		t.Fatal(err)
	}
	whole++
	for _, test := range []struct {
		name string
		call func()
	}{
		{"unrolled-observed", func() { Certify(m, sha, params, bits-1<<40, bits+1<<40, DefaultBudget, &trace) }},
		{"unrolled-nil", func() { Certify(m, sha, params, bits-1<<40, bits+1<<40, DefaultBudget, nil) }},
		{"loop-observed", func() { CertifyLoop(m, sha, params, bits-1<<40, bits+1<<40, DefaultBudget, &trace) }},
		{"loop-nil", func() { CertifyLoop(m, sha, params, bits-1<<40, bits+1<<40, DefaultBudget, nil) }},
		{"cell-unknown", func() { Certify(m, sha, params, math.Float64bits(1), math.Float64bits(1), DefaultBudget, nil) }},
		{"budget-unknown", func() { Certify(m, sha, params, bits, bits, Budget{}, nil) }},
	} {
		calls := 0
		allocs := testing.AllocsPerRun(32, func() { calls++; test.call() })
		whole += calls
		if calls != 33 || allocs != 0 {
			t.Fatalf("%s calls=%d allocs=%g", test.name, calls, allocs)
		}
	}
	bank := ref.Bank{SourceSHA: sha, Params: params, Count: 1}
	bank.Certificates[0] = ref.Certificate{Lo: bits - 1<<40, Hi: bits + 1<<40, Bin: 1}
	if allocs := testing.AllocsPerRun(32, func() { Lookup(m, &bank, sha, params, bits) }); allocs != 0 {
		t.Fatalf("lookup allocation=%g", allocs)
	}
	t.Logf("verification-ledger whole=%d tiny=0; lookup33 separately; AllocsPerRun32 includesonewarm", whole)
}
