package intervalproof

// NumericSnapshot contains only value-owned fixed numeric metadata. It is shared
// immutable evidence; it has no source strings, graph seal, slices or aliases.
type NumericSnapshot struct {
	Nodes                             [MaxSlots]Node
	SourceSHA                         [32]byte
	Params                            Params
	Count, Rounded, Output, LogOutput uint16
}
