package intervalproof

import (
	"math"
	mathbits "math/bits"
	"unsafe"
)

func VerifyNumericSnapshot(g *Graph, snapshot NumericSnapshot) error {
	if err := VerifyGraph(g); err != nil {
		return err
	}
	if snapshot.SourceSHA != g.SourceSHA || snapshot.Params != g.Params || snapshot.Nodes != g.Nodes || snapshot.Count != g.Count || snapshot.Rounded != g.Rounded || snapshot.Output != g.Output || snapshot.LogOutput != g.LogOutput {
		return verification("owned numeric model/source binding")
	}
	if unsafe.Sizeof(snapshot) > MaxGraphBytes {
		return verification("numeric model witness capacity")
	}
	return nil
}

// DecodeWidth independently bounds the ORIGINAL dyadic decode temporaries,
// including the unreduced zero denominator, before the unchanged checker may
// allocate/shift them. The finite encoding limits n<=1024,d<=1075 bits.
func DecodeWidth(encoded uint64) (uint32, error) {
	if !checkerFinite(encoded) {
		return 0, verification("nonfinite dyadic width")
	}
	biased := int(encoded >> 52 & 0x7ff)
	significand := encoded & 0x000fffffffffffff
	power := biased - 1075
	if biased == 0 {
		power = -1074
	} else {
		significand |= 1 << 52
	}
	numerator := mathbits.Len64(significand)
	denominator := 1
	if power < 0 {
		denominator += -power
	} else if numerator != 0 {
		numerator += power
	}
	if numerator > checkerIntegerLimit || denominator > checkerIntegerLimit {
		return 0, verification("dyadic preflight width")
	}
	return uint32(max(numerator, denominator)), nil
}

func containmentWidths(work *Work, values ...uint64) error {
	for _, value := range values {
		width, err := DecodeWidth(value)
		if err != nil {
			return err
		}
		work.MaxIntegerBits = max(work.MaxIntegerBits, width)
	}
	return nil
}

// ContainsBounds compares exact finite binary64 endpoint values. IEEE floating
// comparison performs no rounded arithmetic and treats both zero signs alike;
// the pinned source observes neither sign, and denominator zero always rejects.
func ContainsBounds(claimed, required Bounds) bool {
	return checkerOrdered(claimed) && checkerOrdered(required) && math.Float64frombits(claimed.Lo) <= math.Float64frombits(required.Lo) && math.Float64frombits(claimed.Hi) >= math.Float64frombits(required.Hi)
}

// VerifyContainment adds the intentional-widening contract beside the unchanged
// exact-equality checker. EVERY transfer derives from verified CLAIMED earlier
// native bounds, never from the old globally tighter reference trace. The native
// constructor/rounder/generator is not invoked, and chosen corners are untrusted.
// Work counts the independent all-corner/rounding/comparison work and conservative
// guarded integer widths, including raw dyadic decoding. Fixed interval/trace
// arrays are logical data; source AST and math/big heap are separately allocating.
func VerifyContainment(g *Graph, params Params, cert Certificate, trace *Trace) (Work, error) {
	var work Work
	work.WorkspaceBytes = uint32(unsafe.Sizeof([MaxSlots]Bounds{}) + unsafe.Sizeof(Trace{}))
	if err := VerifyGraph(g); err != nil {
		return work, err
	}
	if trace == nil || trace.Count != g.Count || trace.Lo != cert.Lo || trace.Hi != cert.Hi || trace.SourceSHA != checkerSHA() || trace.Params != checkerParameters() || params != checkerParameters() {
		return work, verification("native trace identity/completeness")
	}
	reduced, exponent, carry, err := checkerCell(params, cert.Lo, cert.Hi)
	if err != nil {
		return work, err
	}
	if trace.Exponent != exponent || trace.Carry != carry {
		return work, verification("native reduction tags")
	}
	var claimed [MaxSlots]Bounds
	for i := uint16(0); i < g.Count; i++ {
		node := g.Nodes[i]
		work.Nodes++
		actual := trace.Slots[i]
		if !checkerOrdered(actual) {
			return work, verification("node%d nonfinite/unordered claim", i)
		}
		if err := containmentWidths(&work, actual.Lo, actual.Hi); err != nil {
			return work, err
		}
		var required Bounds
		switch node.Op {
		case OpReduced:
			required = reduced
		case OpExponent:
			value := math.Float64bits(float64(exponent))
			required = Bounds{value, value}
		case OpConst:
			required = Bounds{node.Bits, node.Bits}
		case OpCopy:
			required = claimed[node.A]
		case OpNeg:
			operand := claimed[node.A]
			required = Bounds{operand.Hi ^ 1<<63, operand.Lo ^ 1<<63}
		case OpAdd, OpSub, OpMul, OpDiv:
			work.Rounded++
			// Earlier claims are already finite/order/width checked. The unchanged
			// independent helper recomputes ALL four exact signed corner operations.
			required, err = checkerTransferWork(node.Op, claimed[node.A], claimed[node.B], &work)
		default:
			err = verification("unknown containment node")
		}
		if err != nil {
			return work, verification("node%d: %v", i, err)
		}
		if err := containmentWidths(&work, required.Lo, required.Hi); err != nil {
			return work, err
		}
		work.Comparisons += 2
		if !ContainsBounds(actual, required) {
			return work, verification("node%d inward transfer from claimed prior bounds", i)
		}
		claimed[i] = actual
	}
	for i := int(trace.Count); i < MaxSlots; i++ {
		if trace.Slots[i] != (Bounds{}) {
			return work, verification("extraneous native trace slot")
		}
	}
	// Widths for these decoded final endpoints were guarded above. Evaluate the
	// final function before copying returned Work, retaining its comparisons.
	binErr := checkerBinWork(claimed[g.Output], cert.Bin, &work)
	return work, binErr
}
