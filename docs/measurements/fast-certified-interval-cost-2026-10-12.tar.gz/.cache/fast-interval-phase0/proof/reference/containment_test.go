package intervalproof

import (
	"errors"
	"math"
	"os"
	"strings"
	"sync/atomic"
	"testing"
)

// Cumulative per reference test process: parent aggregates this architecture
// ledger with native/host proof, never silently resetting per test.
var containmentDriverWhole atomic.Uint32

func containmentCount(t *testing.T, n uint32) {
	t.Helper()
	if whole := containmentDriverWhole.Add(n); whole > 256 {
		t.Fatalf("reference driver budget=%d", whole)
	}
}
func containmentGraph(t *testing.T) *Graph {
	t.Helper()
	path := os.Getenv("COCOON_INTERVAL_SOURCE")
	if path == "" {
		path = os.Getenv("COCOON_FAST_SOURCE")
	}
	if path == "" {
		path = "../../../../examples/datadog/go/dd/internal/wasm/module.go"
	}
	g, e := Load(path)
	if e != nil {
		t.Fatal(e)
	}
	return g
}
func containmentSnapshot(g *Graph) NumericSnapshot {
	return NumericSnapshot{Nodes: g.Nodes, SourceSHA: g.SourceSHA, Params: g.Params, Count: g.Count, Rounded: g.Rounded, Output: g.Output, LogOutput: g.LogOutput}
}

func TestContainmentNumericSnapshotBinding(t *testing.T) {
	g := containmentGraph(t)
	snapshot := containmentSnapshot(g)
	if e := VerifyNumericSnapshot(g, snapshot); e != nil {
		t.Fatal(e)
	}
	mutations := []func(*NumericSnapshot){func(s *NumericSnapshot) { s.Nodes[3].A = 2 }, func(s *NumericSnapshot) { s.Nodes[2].Bits++ }, func(s *NumericSnapshot) { s.SourceSHA[0]++ }, func(s *NumericSnapshot) { s.Params[0]++ }, func(s *NumericSnapshot) { s.Count-- }, func(s *NumericSnapshot) { s.Rounded-- }, func(s *NumericSnapshot) { s.Output = s.LogOutput }, func(s *NumericSnapshot) { s.LogOutput = s.Output }, func(s *NumericSnapshot) { s.Nodes[255] = Node{Op: OpConst, Bits: 1} }}
	for i, mutate := range mutations {
		changed := snapshot
		mutate(&changed)
		if e := VerifyNumericSnapshot(g, changed); !errors.Is(e, ErrVerification) {
			t.Fatalf("snapshot mutation%d accepted: %v", i, e)
		}
	}
	if e := VerifyNumericSnapshot(g, NumericSnapshot{}); !errors.Is(e, ErrVerification) {
		t.Fatal("zero snapshot accepted")
	}
	if e := VerifyNumericSnapshot(nil, snapshot); !errors.Is(e, ErrVerification) {
		t.Fatal("nil graph accepted")
	}
	changed := *g
	changed.RawSnippet = strings.Replace(changed.RawSnippet, "0.15313837699209373", "0.15313837699209374", 1)
	if e := VerifyNumericSnapshot(&changed, snapshot); !errors.Is(e, ErrVerification) {
		t.Fatal("source drift accepted despite copied numeric identity")
	}
	copy := snapshot
	copy.Nodes[0].Bits++
	if snapshot != containmentSnapshot(g) {
		t.Fatal("snapshot retained mutable array backing")
	}
}

func TestContainmentRawDecoderWidths(t *testing.T) {
	for _, c := range []struct {
		bits  uint64
		width uint32
	}{{0, 1075}, {1 << 63, 1075}, {1, 1075}, {0x0010000000000000, 1075}, {0x3ff0000000000000, 53}, {0x7fefffffffffffff, 1024}, {0xffefffffffffffff, 1024}} {
		got, e := DecodeWidth(c.bits)
		if e != nil || got != c.width {
			t.Fatalf("rawbits=%016x width=%d want=%d err=%v", c.bits, got, c.width, e)
		}
	}
	for _, b := range []uint64{0x7ff0000000000000, 0xfff0000000000000, 0x7ff8000000000001} {
		if _, e := DecodeWidth(b); !errors.Is(e, ErrVerification) {
			t.Fatal("nonfinite width admitted")
		}
	}
}

func TestContainmentSignedCornerAndBoundaryChecks(t *testing.T) {
	b := func(a, z float64) Bounds { return Bounds{math.Float64bits(a), math.Float64bits(z)} }
	required, e := checkerTransfer(OpMul, b(-3, -1), b(-2, 4))
	if e != nil {
		t.Fatal(e)
	}
	if !ContainsBounds(b(-13, 7), required) || ContainsBounds(b(2, 6), required) {
		t.Fatal("wrong signed product enclosure")
	}
	if _, e := checkerTransfer(OpDiv, b(1, 2), b(math.Copysign(0, -1), 1)); !errors.Is(e, ErrVerification) {
		t.Fatal("signed-zero denominator admitted")
	}
	if !ContainsBounds(Bounds{1 << 63, 0}, Bounds{0, 1 << 63}) {
		t.Fatal("unobserved zero signs separated")
	}
	if ContainsBounds(b(2, 1), b(1, 2)) || ContainsBounds(Bounds{0, 0x7ff0000000000000}, b(0, 1)) {
		t.Fatal("nonfinite/unordered enclosure admitted")
	}
	if e := checkerBin(b(-.75, -.25), -1); e != nil {
		t.Fatal(e)
	}
	if e := checkerBin(b(-.75, 0), -1); !errors.Is(e, ErrVerification) {
		t.Fatal("inclusive upper boundary")
	}
	if e := checkerBin(b(-.75, -.25), 0); !errors.Is(e, ErrVerification) {
		t.Fatal("negative truncation")
	}
}

// Valid checker-unit fixture, not the native candidate: independently compute
// required corners from already widened operands, then add one neighbor.
func containmentWidenedTrace(t *testing.T, g *Graph, cert Certificate) Trace {
	t.Helper()
	reduced, k, carry, e := checkerCell(g.Params, cert.Lo, cert.Hi)
	if e != nil {
		t.Fatal(e)
	}
	tr := Trace{Lo: cert.Lo, Hi: cert.Hi, Params: g.Params, SourceSHA: g.SourceSHA, Count: g.Count, Exponent: k, Carry: carry}
	for i := uint16(0); i < g.Count; i++ {
		n := g.Nodes[i]
		var b Bounds
		switch n.Op {
		case OpReduced:
			b = reduced
		case OpExponent:
			v := math.Float64bits(float64(k))
			b = Bounds{v, v}
		case OpConst:
			b = Bounds{n.Bits, n.Bits}
		case OpCopy:
			b = tr.Slots[n.A]
		case OpNeg:
			a := tr.Slots[n.A]
			b = Bounds{a.Hi ^ 1<<63, a.Lo ^ 1<<63}
		case OpAdd, OpSub, OpMul, OpDiv:
			b, e = checkerTransfer(n.Op, tr.Slots[n.A], tr.Slots[n.B])
			if e != nil {
				t.Fatal(e)
			}
			b = Bounds{checkerAdjacent(b.Lo, false), checkerAdjacent(b.Hi, true)}
		default:
			t.Fatal("unbound node")
		}
		tr.Slots[i] = b
	}
	return tr
}

func TestContainmentWideningAndClaimedPriorRegression(t *testing.T) {
	defer func() {
		t.Logf("reference-containment-cumulative-whole=%d tiny=0 wasm=0", containmentDriverWhole.Load())
	}()
	g := containmentGraph(t)
	bits := math.Float64bits(42)
	containmentCount(t, 1)
	cert, exact, _, e := Certify(g, g.Params, bits-(1<<40), bits+(1<<40), DefaultBudget)
	if e != nil {
		t.Fatal(e)
	}
	containmentCount(t, 1)
	if _, e := VerifyContainment(g, g.Params, cert, &exact); e != nil {
		t.Fatal(e)
	}
	containmentCount(t, 1)
	wide := containmentWidenedTrace(t, g, cert)
	containmentCount(t, 1)
	w, e := VerifyContainment(g, g.Params, cert, &wide)
	if e != nil {
		t.Fatal(e)
	}
	if w.Nodes != uint32(g.Count) || w.Rounded != uint32(g.Rounded) || w.EndpointOps != 4*w.Rounded || w.Conversions != 2*w.Rounded || w.MaxIntegerBits > 4096 {
		t.Fatalf("ledger=%+v", w)
	}
	// Every slot encloses the OLD tight trace, but users fail to cover operations
	// on the newly claimed input range. A global tight-trace shortcut is unsound
	// as a local transfer verifier and must fail here.
	bad := exact
	bad.Slots[0].Lo = math.Float64bits(.25)
	for i := uint16(0); i < g.Count; i++ {
		if !ContainsBounds(bad.Slots[i], exact.Slots[i]) {
			t.Fatalf("global-tighter mutation vacuous%d", i)
		}
	}
	containmentCount(t, 1)
	if _, e := VerifyContainment(g, g.Params, cert, &bad); !errors.Is(e, ErrVerification) || !strings.Contains(e.Error(), "claimed prior") {
		t.Fatalf("claimed-prior shortcut accepted: %v", e)
	}
	changes := []func(*Certificate, *Trace){func(_ *Certificate, tr *Trace) { tr.Carry ^= 1 }, func(_ *Certificate, tr *Trace) { tr.Exponent++ }, func(_ *Certificate, tr *Trace) { tr.Count-- }, func(_ *Certificate, tr *Trace) { tr.Params[0]++ }, func(_ *Certificate, tr *Trace) { tr.SourceSHA[0]++ }, func(_ *Certificate, tr *Trace) { tr.Slots[255] = Bounds{1, 1} }, func(c *Certificate, _ *Trace) { c.Bin++ }, func(_ *Certificate, tr *Trace) { tr.Slots[0].Lo = 0x7ff8000000000001 }}
	for i, change := range changes {
		c, tr := cert, wide
		change(&c, &tr)
		containmentCount(t, 1)
		if _, e := VerifyContainment(g, g.Params, c, &tr); !errors.Is(e, ErrVerification) {
			t.Fatalf("mutation%d accepted %v", i, e)
		}
	}
	containmentCount(t, 1)
	c, tr, _, e := Certify(g, g.Params, math.Float64bits(2), math.Float64bits(2), DefaultBudget)
	if e != nil {
		t.Fatal(e)
	}
	containmentCount(t, 1)
	zw, e := VerifyContainment(g, g.Params, c, &tr)
	if e != nil || zw.MaxIntegerBits != 1075 {
		t.Fatalf("zero rawdecode width omitted: work=%+v err=%v", zw, e)
	}
	containmentCount(t, 1)
	if _, e := VerifyContainment(g, g.Params, cert, nil); !errors.Is(e, ErrVerification) {
		t.Fatal("nil partial trace admitted")
	}
	t.Logf("wide-work=%+v zero-work=%+v", w, zw)
}
