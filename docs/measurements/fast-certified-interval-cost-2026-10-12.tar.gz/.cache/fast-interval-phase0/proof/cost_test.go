package fastinterval

import (
	"encoding/json"
	"fmt"
	"math"
	"runtime"
	"runtime/debug"
	"testing"

	ref "cocoonfastintervalproof/reference"
)

type hostCostFixture struct {
	setupWhole  uint64
	preparation hostPreparation
	bank        ref.Bank
	cert        ref.Certificate
	trace       ref.Trace
	slot        *OneSlot
}

var hostCostSink struct {
	bank            ref.Bank
	report          BankReport
	referenceReport ref.BankReport
	cert            ref.Certificate
	trace           ref.Trace
	native          NativeWork
	checked         ref.Work
	reason          ref.Reason
	err             error
	bin             int32
	hit             bool
}

func prepareHostCost(tb testing.TB) hostCostFixture {
	tb.Helper()
	f := hostCostFixture{preparation: prepareHost(tb)}
	m := f.preparation.model
	var reason ref.Reason
	bits := ref.Seeds()[0]
	f.cert, _, reason = Certify(m, m.SourceSHA(), m.Params(), bits-(1<<40), bits+(1<<40), DefaultBudget, &f.trace)
	if reason != ref.ReasonNone {
		tb.Fatal("native accepted42 setup", reason)
	}
	if _, err := ref.VerifyContainment(f.preparation.graph, m.Params(), f.cert, &f.trace); err != nil {
		tb.Fatal(err)
	}
	var err error
	var bankReport BankReport
	f.bank, bankReport, err = BuildBank(m, DefaultBudget, nil)
	f.setupWhole = uint64(bankReport.Count) + 3 // Accepted Certify, containment Verify, and slot-install Certify.
	if err != nil {
		tb.Fatal(err)
	}
	if f.bank.Count < 16 {
		tb.Fatal("fixed bank setup is vacuous")
	}
	f.slot, reason = NewOneSlot(m)
	if reason != ref.ReasonNone {
		tb.Fatal(reason)
	}
	if _, reason = f.slot.MapMode(42, true, nil); reason != ref.ReasonNone {
		tb.Fatal(reason)
	}
	return f
}

func (f *hostCostFixture) execute(family, name string) {
	m := f.preparation.model
	switch family {
	case "Native", "Reference":
		if name == "BankConstruct" {
			if family == "Native" {
				hostCostSink.bank, hostCostSink.report, hostCostSink.err = BuildBank(m, DefaultBudget, nil)
			} else {
				hostCostSink.bank, hostCostSink.referenceReport, hostCostSink.err = ref.BuildBank(f.preparation.graph, ref.DefaultBudget, nil)
			}
			return
		}
		index := 0
		if name == "RejectedCell2" {
			index = 3
		}
		if name == "RejectedBoundary" {
			index = 16
		}
		bits := ref.Seeds()[index]
		if family == "Native" {
			hostCostSink.cert, hostCostSink.native, hostCostSink.reason = Certify(m, m.SourceSHA(), m.Params(), bits-(1<<40), bits+(1<<40), DefaultBudget, nil)
		} else {
			hostCostSink.cert, hostCostSink.trace, hostCostSink.checked, hostCostSink.err = ref.Certify(f.preparation.graph, m.Params(), bits-(1<<40), bits+(1<<40), ref.DefaultBudget)
			hostCostSink.reason = ref.ReasonOf(hostCostSink.err)
		}
	case "ContainmentChecker":
		hostCostSink.checked, hostCostSink.err = ref.VerifyContainment(f.preparation.graph, m.Params(), f.cert, &f.trace)
	case "Lookup":
		bits := math.Float64bits(42)
		source, params := m.SourceSHA(), m.Params()
		switch name {
		case "SlotHit":
		case "SlotMiss":
			bits = math.Float64bits(43)
		case "SlotMismatch":
			params[0] ^= 1
		case "BankFirstHit":
			bits = f.bank.Certificates[0].Lo
		case "BankLastHit":
			bits = f.bank.Certificates[f.bank.Count-1].Hi
		case "BankMiss":
			bits = math.Float64bits(2)
		default:
			panic(name)
		}
		if name == "SlotHit" || name == "SlotMiss" || name == "SlotMismatch" {
			hostCostSink.bin, hostCostSink.hit, hostCostSink.reason = f.slot.Lookup(source, params, bits)
		} else {
			hostCostSink.bin, hostCostSink.hit, hostCostSink.reason = Lookup(m, &f.bank, source, params, bits)
		}
	default:
		panic(family)
	}
}

func (f *hostCostFixture) check(tb testing.TB, family, name string) {
	tb.Helper()
	if name == "BankConstruct" {
		if hostCostSink.err != nil || hostCostSink.bank.Count < 16 {
			tb.Fatal("bank cost failed", hostCostSink.err)
		}
		return
	}
	if family == "ContainmentChecker" {
		if hostCostSink.err != nil {
			tb.Fatal(hostCostSink.err)
		}
		return
	}
	if family == "Lookup" {
		wantHit := name == "SlotHit" || name == "BankFirstHit" || name == "BankLastHit"
		wantReason := ref.ReasonNone
		if name == "SlotMismatch" {
			wantReason = ref.ReasonParameters
		}
		if hostCostSink.hit != wantHit || hostCostSink.reason != wantReason {
			tb.Fatal("lookup scope changed", name, hostCostSink.hit, hostCostSink.reason)
		}
		if wantHit {
			wantBin := f.cert.Bin
			if name == "BankFirstHit" {
				wantBin = f.bank.Certificates[0].Bin
			}
			if name == "BankLastHit" {
				wantBin = f.bank.Certificates[f.bank.Count-1].Bin
			}
			if hostCostSink.bin != wantBin {
				tb.Fatal("lookup returned wrong logical bin", name, hostCostSink.bin, wantBin)
			}
		}
		return
	}
	want := ref.ReasonNone
	if name == "RejectedCell2" {
		want = ref.ReasonCell
	}
	if name == "RejectedBoundary" {
		want = ref.ReasonBoundary
	}
	if hostCostSink.reason != want {
		tb.Fatal("individual cost scope changed", family, name, hostCostSink.reason, want)
	}
}

func benchmarkHostCost(b *testing.B, family, name string) {
	b.StopTimer()
	f := prepareHostCost(b)
	f.execute(family, name)
	f.check(b, family, name)
	if runtime.GOMAXPROCS(0) != 1 {
		b.Fatal("cost scope requires actualP1")
	}
	b.ReportAllocs()
	b.ResetTimer()
	b.StartTimer()
	for range b.N {
		f.execute(family, name)
	}
	b.StopTimer()
	if runtime.GOMAXPROCS(0) != 1 {
		b.Fatal("cost scope changed actualP1")
	}
	f.check(b, family, name)
	b.ReportMetric(1, "actual-procs")
	b.ReportMetric(float64(f.preparation.nanoseconds), "source-model-prepare-ns")
	b.ReportMetric(float64(f.preparation.allocated), "source-model-prepare-bytes")
	if name == "BankConstruct" {
		attempts := hostCostSink.referenceReport.Count
		if family == "Native" {
			attempts = hostCostSink.report.Count
		}
		b.ReportMetric(float64(attempts), "attempts/op")
		b.ReportMetric(float64(hostCostSink.bank.Count), "certificates/op")
	}
	if family == "Native" && name != "BankConstruct" {
		b.ReportMetric(float64(hostCostSink.native.EndpointOps), "corners/op")
		b.ReportMetric(float64(hostCostSink.native.OutwardSteps), "outward-steps/op")
	}
}

func BenchmarkFastCost(b *testing.B) {
	for _, family := range []string{"Native", "Reference"} {
		b.Run(family, func(b *testing.B) {
			for _, name := range []string{"Accepted42", "RejectedCell2", "RejectedBoundary", "BankConstruct"} {
				b.Run(name, func(b *testing.B) { benchmarkHostCost(b, family, name) })
			}
		})
	}
	b.Run("ContainmentChecker", func(b *testing.B) { benchmarkHostCost(b, "ContainmentChecker", "") })
	b.Run("Lookup", func(b *testing.B) {
		for _, name := range []string{"SlotHit", "SlotMiss", "SlotMismatch", "BankFirstHit", "BankLastHit", "BankMiss"} {
			b.Run(name, func(b *testing.B) { benchmarkHostCost(b, "Lookup", name) })
		}
	})
}

func TestFastWarmAllocation(t *testing.T) {
	f := prepareHostCost(t)
	for _, name := range []string{"Accepted42", "RejectedCell2", "RejectedBoundary"} {
		if n := testing.AllocsPerRun(32, func() { f.execute("Native", name) }); n != 0 {
			t.Fatal("native warmed allocation", name, n)
		}
		f.check(t, "Native", name)
	}
	for _, name := range []string{"SlotHit", "SlotMiss", "SlotMismatch", "BankFirstHit", "BankLastHit", "BankMiss"} {
		if n := testing.AllocsPerRun(32, func() { f.execute("Lookup", name) }); n != 0 {
			t.Fatal("lookup warmed allocation", name, n)
		}
	}
	if n := testing.AllocsPerRun(32, func() { f.slot.Reset(nil); _, hostCostSink.reason = f.slot.MapMode(42, true, nil) }); n != 0 {
		t.Fatal("on-demand warmed allocation", n)
	}
	if n := testing.AllocsPerRun(32, func() { _, hostCostSink.reason = f.slot.MapMode(1, true, nil) }); n != 0 {
		t.Fatal("domain fallback warmed allocation", n)
	}
	t.Logf("host-warm-allocation-functional-ledger setup-whole=%d native-candidates=132 original-bin-calls=33 total-whole=%d; AllocsPerRun32 plus1 warm-up; preparation binding separately classified", f.setupWhole, f.setupWhole+165)
}

func TestFastCostMemory(t *testing.T) {
	f := prepareHostCost(t)
	old := debug.SetGCPercent(-1)
	defer debug.SetGCPercent(old)
	type scope struct{ family, name string }
	var scopes []scope
	for _, family := range []string{"Native", "Reference"} {
		for _, name := range []string{"Accepted42", "RejectedCell2", "RejectedBoundary", "BankConstruct"} {
			scopes = append(scopes, scope{family, name})
		}
	}
	scopes = append(scopes, scope{"ContainmentChecker", ""})
	for _, name := range []string{"SlotHit", "SlotMiss", "SlotMismatch", "BankFirstHit", "BankLastHit", "BankMiss"} {
		scopes = append(scopes, scope{"Lookup", name})
	}
	for _, s := range scopes {
		runtime.GC()
		var before, after, collected runtime.MemStats
		runtime.ReadMemStats(&before)
		f.execute(s.family, s.name)
		f.check(t, s.family, s.name)
		runtime.ReadMemStats(&after)
		runtime.GC()
		runtime.ReadMemStats(&collected)
		record := map[string]any{"family": s.family, "scope": s.name, "architecture": runtime.GOARCH, "GC_disabled_during_observation": true, "observation": "end-of-operation after one operation, not peakRSS or bounded heap", "before": before, "after": after, "after_forced_GC": collected, "allocated_bytes": after.TotalAlloc - before.TotalAlloc, "allocations": after.Mallocs - before.Mallocs, "heap_delta_after_collection": int64(collected.HeapAlloc) - int64(before.HeapAlloc), "model_bytes": f.preparation.model.Bytes(), "slot_bytes": f.slot.Bytes(), "native_workspace_bytes": WorkspaceBytes(), "preparation_ns": f.preparation.nanoseconds, "preparation_allocated_bytes": f.preparation.allocated}
		data, err := json.Marshal(record)
		if err != nil {
			t.Fatal(err)
		}
		t.Log("FAST_MEMORY " + string(data))
	}
	t.Log(fmt.Sprintf("memory scopes=%d; these allocation observations are separate from bounded proof-driver selection and qualified timing", len(scopes)))
}
