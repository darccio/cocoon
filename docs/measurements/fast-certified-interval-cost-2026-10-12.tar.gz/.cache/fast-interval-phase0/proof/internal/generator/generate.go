// Package generator is author preparation. It imports only the unchanged
// rational reference and metadata; it bootstraps without any generated root Go.
package generator

import (
	"bytes"
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"go/format"

	ref "cocoonfastintervalproof/reference"
)

func Snapshot(g *ref.Graph) ref.NumericSnapshot {
	return ref.NumericSnapshot{Nodes: g.Nodes, SourceSHA: g.SourceSHA, Params: g.Params, Count: g.Count, Rounded: g.Rounded, Output: g.Output, LogOutput: g.LogOutput}
}

// ID uses explicit widths/order and all fixed capacity, not native struct bytes.
func ID(snapshot ref.NumericSnapshot) [32]byte {
	var data bytes.Buffer
	data.WriteString("cocoon-fast-interval-numeric-v1\x00")
	data.Write(snapshot.SourceSHA[:])
	var scratch [8]byte
	for _, p := range snapshot.Params {
		binary.LittleEndian.PutUint64(scratch[:], p)
		data.Write(scratch[:])
	}
	for _, v := range []uint16{snapshot.Count, snapshot.Rounded, snapshot.Output, snapshot.LogOutput} {
		binary.LittleEndian.PutUint16(scratch[:2], v)
		data.Write(scratch[:2])
	}
	for _, n := range snapshot.Nodes {
		data.WriteByte(byte(n.Op))
		binary.LittleEndian.PutUint16(scratch[:2], n.A)
		data.Write(scratch[:2])
		binary.LittleEndian.PutUint16(scratch[:2], n.B)
		data.Write(scratch[:2])
		binary.LittleEndian.PutUint64(scratch[:], n.Bits)
		data.Write(scratch[:])
	}
	return sha256.Sum256(data.Bytes())
}

func Source(g *ref.Graph) ([]byte, error) {
	if err := ref.VerifyGraph(g); err != nil {
		return nil, err
	}
	s := Snapshot(g)
	var out bytes.Buffer
	fmt.Fprintln(&out, "// Code generated from the pinned source numeric graph by cmd/generate-native; DO NOT EDIT.")
	fmt.Fprintln(&out, "package fastinterval")
	fmt.Fprintln(&out, `import ref "cocoonfastintervalproof/reference"`)
	fmt.Fprintf(&out, "const (compiledCount = %d; compiledRounded = %d; compiledOutput = %d; compiledLogOutput = %d)\n", s.Count, s.Rounded, s.Output, s.LogOutput)
	fmt.Fprintf(&out, "func compiledProgramID() [32]byte {return %#v}\n", ID(s))
	fmt.Fprintf(&out, "func compiledSourceSHA() [32]byte {return %#v}\n", s.SourceSHA)
	fmt.Fprintf(&out, "func compiledParams() ref.Params {return ref.Params{%#x,%#x,%#x,%#x}}\n", s.Params[0], s.Params[1], s.Params[2], s.Params[3])
	fmt.Fprintln(&out, "func programSnapshot() ref.NumericSnapshot {return ref.NumericSnapshot{")
	fmt.Fprintln(&out, "SourceSHA: compiledSourceSHA(), Params:compiledParams(), Count:compiledCount,Rounded:compiledRounded,Output:compiledOutput,LogOutput:compiledLogOutput,")
	fmt.Fprintln(&out, "Nodes:[256]ref.Node{")
	for i, n := range s.Nodes[:s.Count] {
		fmt.Fprintf(&out, "%d:{Bits:%#x,A:%d,B:%d,Op:ref.Op(%d)},\n", i, n.Bits, n.A, n.B, n.Op)
	}
	fmt.Fprintln(&out, "}}}")
	fmt.Fprintln(&out, "func runUnrolled(t *ref.Trace,w *NativeWork,b Budget) ref.Reason {")
	for i, n := range s.Nodes[:s.Count] {
		fmt.Fprintln(&out, "if w.Nodes>=b.Nodes{return ref.ReasonBudget};w.Nodes++")
		switch n.Op {
		case ref.OpReduced, ref.OpExponent:
			// Initial values supplied by the separately checked integer cell.
		case ref.OpConst:
			fmt.Fprintf(&out, "t.Slots[%d]=ref.Bounds{Lo:%#x,Hi:%#x}\n", i, n.Bits, n.Bits)
		case ref.OpCopy:
			fmt.Fprintf(&out, "t.Slots[%d]=t.Slots[%d]\n", i, n.A)
		case ref.OpNeg:
			fmt.Fprintf(&out, "t.Slots[%d]=ref.Bounds{Lo:t.Slots[%d].Hi^1<<63,Hi:t.Slots[%d].Lo^1<<63}\n", i, n.A, n.A)
		case ref.OpAdd, ref.OpSub, ref.OpMul, ref.OpDiv:
			fmt.Fprintf(&out, "{ result,reason:=transfer(ref.Op(%d),t.Slots[%d],t.Slots[%d],w,b);if reason!=ref.ReasonNone{return reason};t.Slots[%d]=result }\n", n.Op, n.A, n.B, i)
		default:
			return nil, fmt.Errorf("unknown prepared node %d", i)
		}
		fmt.Fprintf(&out, "t.Count=%d\n", i+1)
	}
	fmt.Fprintln(&out, "return ref.ReasonNone\n}")
	return format.Source(out.Bytes())
}
