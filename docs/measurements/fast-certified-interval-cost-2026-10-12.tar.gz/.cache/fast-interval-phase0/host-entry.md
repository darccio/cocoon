# Host entry review: fast native interval construction and lookup/miss costs

This is an entry/specification recommendation, not implementation approval or
a production design. Read the completed signed rational specification and
proof/cost results, the ignored pure source/control functions, immutable-bank
lookup, and current frozen corpora. No build, test, profile, benchmark, tracked
edit, runtime/API change, or source/payload substitution was performed. Root
must commit the reviewed private experiment specification before implementing
the numerical prototype.

## Scope and safety obligations

The completed proof establishes sound universal interval membership for the
pinned default configuration, but its allocating constructor costs 12.257 ms
per bank / 69.607 ms with full verification. Its fixed bank reaches no broad
inputs and only 1,806/4,194,304 Increasing inputs. Warm coverage alone is not
an amortization result. Earlier exact-value caches and outline/oracle controls
already establish that miss overhead and code shape can erase numeric savings.

A native compiled interval graph is a distinct private hypothesis. Preserve all
76 source-derived slots, 30 separate rounded arithmetic operations (including
the two affine operations), exact bit reduction/carry cell, signs, finite-domain
checks, and strict final `[k,k+1)` acceptance. The immutable model must own fixed
data and independently bind complete source, operations/literal bits/edges,
configuration, and compiled native expression correspondence before use. A
once-validated immutable model may omit repeated parsing/seal recomputation
inside its pure constructor only when ownership prevents later mutation; report
the entire preparation/binding cost separately and reject any model mismatch.

Correct RN endpoint operations followed by Nextafter toward the appropriate
infinity can conservatively enclose the rounded source primitive. The proof
must explicitly cover signed corner choices, division excluding zero, signed
zeros, underflow/overflow, finite rejection, and distinct explicit binary64
rounding barriers. No FMA, expression reassociation, host log/exp, approximation,
or sampled membership argument is permitted. Correct endpoint rounding is a
native compiler/architecture premise to prove and test, not supplied by the
word 'Nextafter'. Test actual native amd64 and 386, not only compilation.

Native bounds may be wider than the old exact-rational tight bounds. Adapt the
independent oracle to prove that each native enclosure contains independently
recomputed rounded extrema, rather than requiring equal tight endpoints or
trusting the native-selected corners. Universal containment plus strict final
bin containment must hold even if the wider native proposer certifies fewer
old seeds. Keep all fixed seeds, five candidate requests, domain, node/storage
caps, and negative outcomes; do not widen caps or clip unsuccessful cells.

The exact original pure `OriginalBin` control represents logarithm + rounded
affine mapping + floor/saturation. It is not the entire guest Add path: the
original threshold/no-bin distinction, input validation, counters, collapse,
memory, handles, Count and protobuf are absent from this numeric helper. The
corpus called NegativeBins contains positive inputs mapping to negative bins;
it is not a negative-input API test. Label all proposed timings pure numerical
diagnostics, with no checked facade or full guest equivalence claim.

## Minimal useful experiment

Cost-only measurements can establish that the native constructor is cheaper,
and may complete a negative round. They cannot establish that on-demand work
pays for itself. Recommend the following bounded sequence in one preregistered
private round, contingent on independent soundness checks:

1. Report immutable author preparation/source/model validation, native complete
   fixed-bank construction, accepted42, early cell rejection, fully evaluated
   seed16 boundary rejection, and independent verifier costs separately. Record
   actual accepted/unknown work and retained/transient bytes, not assumed old
   57/92 totals. A trusted fast primitive argument allows native numeric timing
   without executing the expensive verifier per miss; disclose this changed
   trust boundary. Every accepted proposal used by a correctness driver still
   needs independent containment checks before performance evidence is trusted.
2. Measure fixed 64-capacity bank and one/latest-certificate lookup separately,
   including identity/domain predicates, hit/miss paths and number of probes.
   Fixed-bank lookup is an explicitly prebuilt offline control, not on-demand
   construction. Failed lookup alone is not a computed fallback.
3. Measure a complete one-slot numeric simulation, with empty initial slot:
   eligibility + lookup + at most five proposals on a miss + installation or
   uncertainty + exact OriginalBin fallback on every uncertified point. All
   proposal, failed work, replacement, and reset costs stay in the timed loop.
   If certification already establishes the current input's bin, the simulator
   may return it without another fallback; count that as construction success,
   separately from a prior-slot hit. Do not imply it is a production cache.

Use three full replay controls: (a) direct unchanged-source OriginalBin; (b) the
simulation wrapper disabled; (c) wrapper enabled. Disabled/enabled must be the
same ELF and same owned prepared model, changing only a recorded runtime flag.
Disabled follows the exact original mapping, retaining wrapper branch/call
shape but performing no lookup/proposal/install. The direct control exposes
that wrapper's overhead, and must also be beaten. All output results are
consumed through the same deterministic digest/array procedure. Verify exact
per-input logical results against the full original mapping outside timing.

Declare slot policy before outcome: success installs/replaces one certificate;
uncertainty preserves the previous slot (or a separately specified alternative)
and returns the original mapping result; source/model drift is fatal. Define
identity mismatch as immediate original fallback/no install, not speculative
certification. Widths begin at `2^40` and halve at most four times with checked
arithmetic, preserving unmodified domain/cell rejection. Unsupported inputs
can be screened directly; specify whether they consume zero or up to five
proposal attempts, and record it honestly. No hidden exact-value cache, negative
result memo, adaptive width/search, bank-on-demand scan, or policy retuning.

## Replay, costs, and economics

Replay all seven unchanged frozen 8,192-value corpora plus true nonrepeating
Increasing `1..4194304` and `1..8388608`. Each measured operation is one entire
declared sequence with an empty slot reset; reset is counted. If fixed-N loops
repeat whole sequences, reset for every sequence so framework calibration or
earlier repetitions cannot turn Increasing into a warmed repeat stream. First
and revisit passes of cycle corpora are explicit diagnostics, never silently
mixed. Distinct 4M/8M leaves need fixed input prefixes, not adaptive counts that
compare different proposal populations. Input allocation may be outside timing
but its owned bytes must be identical across roles and disclosed.

Record exact hits, misses by reason, certified-on-miss returns, proposals,
accepted/uncertain/budget failures, original fallbacks, replacements, maximum
occupied slots, allocations, and enforced scratch/work per input and per
1,024-input phase. Preserve every phase and aggregate so short hot phases do
not conceal cold loss. Lookup/certification counters must not change optimized
role comparisons asymmetrically; either use identical timed counters or a
separate counted replay verified against timed output/work control.

Keep model validation visible: warm numeric savings are conditional on prep
already paid. Report cold preparation+one full replay as a compound measured
scope or a separately labelled break-even calculation. Do not add unrelated
setup/hit/miss medians and call the sum measured end-to-end latency. Retained
model/bank/slot sizes and zero hot-loop allocation, if achieved, do not imply
bounded heap/RSS during extraction or startup. No representative private SDK
profile is available to supply an amortization lifetime.

No profile is needed before this proof/cost question. Freeze official Go1.26.8,
CGO0, GOAMD64v1, PGOoff, actual P1 at each numerical leaf, source/ELF/tool hashes,
all exact scopes/order/inputs and preregistered iteration counts. Use seven
alternating samples then seven independently reversed samples. Stop all other
tools for qualified samples. Existing untouched scalar/SQL/batch/trace and
P1/P16 one/sixteen-home stream binaries can serve context brackets if run;
unchanged identical ELFs carry no new optimization/streaming claim. Do not
attribute their background variation to this standalone numerical simulation.

## Suggested predeclared stopping and advancement rule

Any false accepted certificate, source/model mismatch accepted as healthy,
bound violation, uncertainty promotion, native-architecture disagreement, or
failure to meet unchanged numerical nonvacuity is an immediate correctness
no-go. Retain failures; no fallback can legitimize a falsely certified hit.

To justify a SEPARATE guest integration ceiling specification, require complete
enabled simulation time to fall at least 10% versus BOTH direct OriginalBin and
same-ELF disabled wrapper in BOTH seven-sample sets, p<.05, on BOTH declared
Increasing4M and Increasing8M sequences. These fixed nonrepeating inputs are
the primary economic question; repeated42 or a prebuilt nearby-hit result alone
cannot pass. All work/fallbacks remain included, deterministic and bounded.

Also require no repeated detected slowdown (p<.05 in both sets) on BroadHoldout
or NegativeBins against either control, and apply the same conservative guard
to the remaining frozen corpora for a general-use advancement claim. A lone
negative and nondetected adverse medians remain explicit uncertainty, not proof
of equivalence. No third selected retiming, tuned slot policy/width/cap, or
chosen hot-only applicability may rescue this round. A useful narrow numeric
win with repeated broad/negative loss is evidence, not authorization for a
general integration experiment. The parent can preregister a narrower question
instead before implementation, but should not change it after results.

Native construction may pass soundness and fail this economic bar. That is a
completed evidence-only no-go. Pure numeric advancement still establishes no
checked scalar gain, attainable production cache, new public API/ABI/schema,
source-independent compiler eligibility, M1 acceptance, or representative
application benefit.

## Future host boundary remains intact

This pure model is fixed numeric data with no resource, instance, handle,
guest pointer/view, descriptor, store offset, import, or memory mutation. It
does not assume shared prep validates mutable future guest words. Any later
integration must preserve original minimum+48, multiplier+40, offset+56 reads
and their positions, current logical memory/range and MaxMemory checks,
per-operation reset/recovery/reply validation, admission/context/ownership,
epochs/poisoning and draining Close. Gamma binds encoding identity but is not
an extra existing read on the selected numeric path. Poison/replacement cannot
migrate memo state or old handles; abandoned resources remain properly closed.

Certified pure arithmetic never skips counters, memory writes, allocation,
collapse, atomic invalid-tail input validation, store lookup or lifetime checks.
Constructing up to five intervals under a future execution lock is admitted
work with contention/cancellation implications that this component test does
not resolve. A later guest integration requires a separate committed spec,
full checked scalar/SQL/batch/trace and holdout qualification, matching shape
control, fresh reference limits, and P1/P16 streaming brackets. New public
contract proposals still require explicit operator approval before implementing.

ENTRY READY for the parent's concrete private spec. No implementation authorized
by this note; host tools stopped after the note.
