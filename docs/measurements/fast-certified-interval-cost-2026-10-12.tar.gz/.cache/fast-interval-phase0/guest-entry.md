# Guest entry: fast bounded interval costs

Entry/spec review only. No prototype implementation, build, numerical test,
benchmark, profile, production change or public contract was made. Reviewed the
completed rational proof, current source-derived graph/reference and the local
official Go 1.26.8 `math/nextafter.go`.

## Numerical route

The proposed native transfer is sound under ordinary correctly rounded
nearest-even binary64 arithmetic. For a finite exact corner value q, let
r=RN(q). The adjacent representable values on each side of r enclose q and r,
including ties and gradual underflow. Evaluate each corner as one explicitly
rounded operation, choose numeric min/max and step outward once. Reject NaN/
Inf corners and nonfinite outward endpoints. The argument depends on native
binary64 rounding and source operation boundaries, not mathematical ln
monotonicity or sampled endpoint agreement.

Addition/subtraction use their proper extremal pairs. Signed multiplication and
division need all four corners; division rejects any denominator enclosure
containing either zero sign. Correlated operands may widen the interval and
cause uncertainty. Never narrow correlated ranges, clip source seams or add a
post-result tolerance to recover certificates. Constants/exact copies/unary
negation do not acquire gratuitous arithmetic or lose original bindings.

At zero, local Nextafter returns the appropriately signed smallest subnormal
toward the requested infinity. This can widen zero into a two-sided interval;
it is conservative where the selected graph does not observe zero sign.
Overflow or changed floating mode is outside a successful certificate.
Gradual underflow and round-to-nearest mode should have executable witnesses;
no alternate mode/flush-to-zero environment is qualified. Explicit float64
conversions must survive in emitted code and ordinary compiler output. A
separately rounded multiply then add is not an FMA. Native amd64/386 execution
and matching code evidence are useful; no arm64/big-endian execution is implied.

The original integer bit reduction, exponent/carry/one/minimum exclusions and
strict final `[k,k+1)` rule remain intact. The original affine multiply and add
are two separate rounded operations. Widened native bounds may reduce coverage;
that is a recorded result, not grounds to change seeds, width or arithmetic.

## Source ownership and independent verification

Once-only source/model verification is acceptable only for a privately owned
immutable model. Copy numeric arrays, constants, configuration and identity;
never retain the caller's mutable Graph, source backing, Params reference,
guest memory or resource pointer. Preparation is visible separate work. The
compiled unrolled program must match the validated graph node-by-node before
requests execute. Mutating/releasing the preparation input must not affect it.
Runtime invalid/unprepared model or changed compiled program is fatal; an
ineligible request identity is unknown/no hit.

Keep the old rational reference/checker byte-identical. Add a separate native
containment adapter. It validates source/program/model and initial integer
cell, then recomputes exact rational corners from earlier *verified claimed
native* bounds. Require each claimed output to contain the independent required
directed result, then carry the verified claim forward. An adapter that compares
only with the old globally tighter trace can miss a wrong native operand/edge;
old endpoint equality would instead reject legitimate wider native results.
The new adapter must independently validate the signed corners and graph IDs,
not call the native transfer as its oracle. Final bin containment is checked
separately. Successful finite native traces supplement the universal transfer
argument; online rational omission needs that argument, not timing convenience.

## Minimum proof

Retain the previous bounds, fixed 64 seed order and requests, 320 fixed-bank
attempt cap and nonvacuity rule. Exercise ties, cancellation, subnormal results,
signed corners, zero-divisor and overflow rejection; every source exponent/
carry side, low-word rollover, threshold, exact one and neighbors; negative
logical floors, integer upper boundaries, mismatch/partial/budget failure;
and malformed, unprepared and changed-model/program cases. Verify all accepted
bank traces independently. Check compiled full original log/bin separately
from graph-derived traces, and use fresh original-Wasm singleton state/bin
oracles for finite accepted samples. Count all verification calls collectively
per architecture, including tiny members and compiled numerical faults.

Compiled mutations should expose a real numerical failure for inward steps,
omitted signed corner, wrong generated operand/edge/carry, inclusive upper bin
boundary, negative truncation and wrong configuration/bin or promotion after
uncertainty. A primitive FMA example distinguishes fused from separate source
rounding: `(1+2^-27)*(1-2^-27)-1` rounds to zero in the separate product/add
path, while the fused exact result is `-2^-54`. That is a source-rounding
witness; it does not prove a native certificate was wrong when wider bounds
incidentally contain both results. Compiler/startup failure earns no numerical
mutation credit. Source/constant drift rejection is a separate category.

## Economy and scope

Measure loop/unrolled candidates, accepted and rejected work, fixed-bank setup,
latest-entry and 64-entry hit/miss/mismatch costs, exact original raw mapping
and the complete one-slot replay. Include proposal retries, exact fallback,
install and initial empty-state reset. No rational verification, AST work or
source hashes may disappear from a scope without its owned-model trust boundary
and preparation cost being stated. A large speedup over the allocating rational
reference is not a sufficient economy result; the latter retains per-request
integrity work that the newly immutable model legitimately moves to preparation.

Zero warmed constructor/lookup allocation is an appropriate criterion. Report
hit headroom and estimated break-even reuse C/(O-H) using measured constructor,
original and hit costs, including whether O-H is positive. These non-additive
component observations do not predict the complete policy's gain; failure,
fallback and locality need actual whole replay evidence. Full raw numeric gains
also cannot be turned into checked scalar percentage claims.

The root's revised stopping rule is economical and finite: require the complete
Increasing replay to gain at least 10% against direct and identical disabled
controls in both 4M/8M sets, and park on repeated detected losses over 2% in any
other frozen corpus. The full policy must meet numerical/nonvacuity/bound and
zero-allocation rules first. Keep all smaller/single-set negatives. No extra
hit-only promotion gate is necessary because the complete replay is stronger;
headroom and break-even remain explanation only. No capacity, bypass, learned
width, failure backoff, policy rescue or post-result retuning belongs in this
round. A failure parks this candidate.

The fixed one-slot state should retain the previous valid entry after a failed
or unsupported miss; replacing or clearing it is an explicit policy decision,
not an unnoticed implementation detail. Domain-ineligible points should be a
timed, counted zero-proposal reference path, with exact one distinguished from
below-minimum no-bin semantics. Different configuration queries test lookup/
constructor rejection rather than pretending a default OriginalBin fallback
implements another mapping. Latest-entry and full bank storage are separately
bounded from the immutable model; actual retained totals must count both.

No live guest parameter reads, memory/current-view checks, ordering, counters,
collapse, admission, ownership, epochs, poison or draining semantics are solved
by this pure numeric prototype. A later guest integration and source-independent
predicate require separate approved specifications/proof and full-call controls.
No approximate arithmetic, old exact-value cache, polynomial simplification,
small guard/recovery/reply probe or reference-code transplant is revived.
