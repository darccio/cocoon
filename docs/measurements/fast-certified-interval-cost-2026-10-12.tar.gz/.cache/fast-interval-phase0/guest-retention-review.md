# Guest retention review

READY. This review read frozen proof, cost/statistics/replay/compiler/integrity records and the final durable prose. It did not alter frozen implementation or run a compiler, test, profile, benchmark, calibration or measurement. The retained result is a numerical feasibility proof plus an economic no-go, not an integration, public contract, compiler pass, new math approximation, production speedup or M1 acceptance.

## Evidence and claims checked

All108 cost-frozen SHA paths still match. The signed historical specification remains SHA d557897390ddac943f0452d9a640608151ea250632d8dbab3f62b71c7b5ef0f8. The sources, owned numeric model, generated literal program and copied original source graph remain pinned; the four old reference sources are unchanged. This proof certifies the current source's rounded mapping, not mathematical ln, arbitrary configurations or changed programs. The final prose explicitly makes that distinction.

The independent adapter verifies exact rational corner requirements from verified claimed native prior bounds, instead of trusting a globally tighter old trace. The documented15,908/16,384 whole count matches the final aggregate611+12,431+16+2,553+260+29+8 per architecture. Tiny114 is also charged to whole; original-Wasm521 is below2048. All4121 accepted adversarial singleton traces, unique source/ownership/allocation witnesses and57 fixed-bank traces have independent verification. Compiled numerical fault selections, preparation failures and large full-prefix lockstep replays have separate honest categories; no compiler failure is counted as a caught numerical mutant.

The57-cert/92-attempt bank,30cell/5boundary rejections,23exponents, nonvacuity and architecture-identical bank/program hashes match the records. All2,046 normal exponent fields on both carry sides are finite verification coverage, not a claim of native arm64/big-endian execution. Actual transfer assembly records separate2ADD/2SUB/4MUL/4DIV instructions per static helper and no fused multiply/add; the runtime FMA witness is identified separately.

Logical model4208/4204B, bank+encoding2814/2554B and active builder+observer export56240/53152B match the native records. The prose now correctly limits the latter to active observer serialization, rather than every evidence JSON record. Later preparation/summary serialization is explicitly outside that bounded numeric scope. It makes no hard heap, physical stack-copy or RSS claim. Decoder1075-bit accounting is distinguished from the historical235-bit arithmetic observation and guarded4096-bit rational temporary bound.

Unrolled7805/9868 values are machine-code bytes, not frames. Actual certify stack subtraction0x1120/0x112c gives4384/4396B; bank0x53b0/0x4cfc gives21424/19708B. Separate helper frames and the larger logical workspace remain distinct.

The component table agrees with both cost-summary sets, including confirmation native927.1ns/0B/0alloc, bank61.966us/4864B/1alloc, rational204.660us/93360B/2611alloc and full independent checker1081.053us/292853B/7270alloc. The nil-observer bank trace escape is retained as a real negative; zero warmed allocations apply to individual candidates/lookups/complete replays, not bank construction. Preparation144.183ms/41237552B and separate end-of-operation/forced-GC observations are not retained bank bytes or peak process measurements.

The39cells×7samples×2sets total546 raw rows. All48 exploratory comparisons and p-values match replay-statistics; percentage deltas match its derivation from displayed benchstat medians and are rounded descriptive values. Increasing fails the frozen rule versus direct in both sets and versus disabled in screening (only9.88% gain). Every other corpus breaches the repeated direct-control2% guard, even high-reuse Repeated/Nearby. Broad/negative zero hits and roughly0.8us input costs are accurately reported; successful one-slot replacements may be wasted without requiring a fallback. Every proposal/refinement/fallback/install is in the complete numeric scope. Component O-H is negative, and the prose correctly refuses an additive full-call prediction.

The32 full lockstep records contain16 per architecture, summing100663296 inputs each. Increasing hit percentages98.860478/99.310458 and proposal/fallback counts78577/5950 and112262/11611 match the frozen functional histories; broad/negative proposal counts also match. Those full checks compare every enabled/disabled output with compiled OriginalBin; finite original-Wasm checks supply the separate bin/Count/protobuf oracle. They do not claim millions of stateful Wasm calls or changed checked scalar/SQL/batch/stream workloads. Timed output digests are consistency evidence, not replacement mathematical proof.

The archive routine retains an explicit SHA/byte manifest and safe regular relative member names, omits executables/caches/extraction tar, checks every packed member and preserves raw sources, generated output, historical identities, all rows/comparisons, gate/repeat logs and authoring negatives. The implementation-review source stays frozen; this separate retention note is the only file written by this review. The final archive itself remains the parent's packaging/manifest verification step.

## Corrections applied before READY

The new performance paragraph now says no *new* ln approximation and explicitly limits the proof to the current source mapping. Stale roadmap statements presenting the completed fast-constructor round as future work now acknowledge its parked fixed policy. Both durable evidence files now identify active builder/observer export scope and exclude later preparation/summary serialization from that logical bound. No source, numeric cap, policy or sample changed.

## Final read hashes

- docs/performance.md:16fb17abd440321d42386ae05496f527e0bd8b4fe53e2682eed1cfe4a28f4a7e
- docs/roadmap.md:017de2e8e688f9f37c9c09c95173f5802335e680064a73db90735b9b22d2a82f
- docs/measurements/fast-certified-interval-cost-2026-10-12.md:c098fbf87cd1bd2c2bc53577bd2a133b614e68ac14171646cbc3574abee988fe
- docs/fast-certified-interval-cost.md:d557897390ddac943f0452d9a640608151ea250632d8dbab3f62b71c7b5ef0f8
- .cache/fast-interval-phase0/archive.py:82efe67c5253e91aea5007c6e8cfe5b29dd49f3c8ca1cc71aa17033b9ba922d2

READY for evidence retention with the exact fixed candidate parked. Guest tools stopped after this note.
