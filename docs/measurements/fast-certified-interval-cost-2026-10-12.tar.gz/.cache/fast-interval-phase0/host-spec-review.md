# Host specification review: fast interval construction and mapping costs

Final status: READY. Re-read the full amended specification with SHA-256
`d557897390ddac943f0452d9a640608151ea250632d8dbab3f62b71c7b5ef0f8`.
The initial findings below are preserved as review history and are resolved by
the final clarification audit appended at the end. This is approval to stage
the private specification, not executable correctness or production approval.

Reviewed in full: `docs/fast-certified-interval-cost.md`.
Reviewed SHA-256:
`ea7effbcdd4e2e77a9d95189d14eade3b698807ea0756affdd55f991135bff90`.
This review predates prototype implementation. No build, test, profile,
benchmark, tracked edit, public proposal, or publication was performed.

Verdict: the design is coherent for an ignored numerical experiment. Resolve
the three exact-policy/ledger clarifications below before signing. These are
specification scope issues, not requests to change numerical caps, improve
reported outcomes, or implement a different candidate.

## Required clarifications

1. Unsupported input attempts are not fully frozen. Policy step2 retries on
   uncertainty up to five attempts, while step4 permits fallback when the input
   is unsupported. State the exact treatment: zero proposals after an explicit
   point-domain guard, first classified failure then fallback, or all five
   uncertainty attempts. Exact1 occurs in the primary Increasing sequence, so
   the choice affects counts and cannot be left to a post-result optimization.
   Domain rejection of a point must stay distinct from a proposal interval
   crossing a cell or uncertain boundary, which may resolve after refinement.
   Source/configuration mismatch treatment should likewise be exact and must
   never install a certificate or manufacture default-config success.
2. The final requirement 'all accepted traces independently verified' must name
   its scope. The fixed-bank section requires every retained native fixed-bank
   trace; the correctness driver may also have a bounded declared native trace
   set. The on-demand timed policy intentionally omits rational verification
   because it relies on the independently established primitive theorem.
   Requiring a rational checker for millions of timed installations would
   contradict that scope and change its economics. Explicitly identify which
   accepted traces receive individual verification and why the universal native
   argument covers the remaining timed proposals.
3. Separate the <=16,384 proof-driver ledger from replay/reference evaluation
   counts. Complete exact per-input comparisons over 4M/8M runs entail millions
   of native/reference calls. Keep proof-driver caps unchanged, but identify
   functional replay/digest validation and qualified timing as separate
   preregistered scopes with actual counts. Otherwise 'all numerical results
   must match' and the whole-verification cap can be read inconsistently. The
   existing distinction between fixed-bank320 and on-demand5*N is already good.

The parent can choose any explicit defensible policy within these limits; no
user clarification or new public-contract approval is required for this private
specification detail.

## Approved scope and controls

The native model owns copied fixed arrays/configuration and is source/program
bound during preparation. Moving immutable parsing/seal work once is confined
to this pure diagnostic; it does not hoist current guest words, ownership,
epochs, memory/range/reply checks or effects. Invalid/unprepared model and source
drift remain fatal; a mismatched request remains uncertified. Native source
generation and compiled output must be retained together. No production source,
guest Wasm, facade, artifact, manifest, lock, runtime/API or old proof changes.

The RN-corner plus outward-Nextafter argument is sufficiently explicit for the
next proof implementation review, including source rounding boundaries,
denominator-zero exclusion, signed corners, finite rejection and strict bin
acceptance. The containment adapter correctly recomputes exact extrema from
previously verified claimed native bounds and carries those native bounds
forward. A comparison only against an old globally tight trace would not prove
this wider transfer. Native zero-sign and rounding premises still need the
specified proof/tests; this spec review does not establish executable correctness.

Graph/model16KiB, bank/slot4KiB, scratch64KiB, 96 rounded nodes, <=4 corners per
node, <=192 outward steps, unchanged seeds/refinements and zero warmed native
construction/lookup allocation are concrete rejection bounds. Full report and
trace handoff capacity count. Allocating extraction/reference/checker remains
separate; there is no hard process-heap/RSS claim. Actual native amd64/386
correctness, parameter/source ownership/drift, bound faults, original-Wasm
Count/full-protobuf witnesses and numerical semantic mutants remain necessary.

The complete simulation is the economic measurement: empty slot, identities,
lookup, all proposals/rejected work, install or exact fallback and reset stay
inside timing. Direct OriginalBin plus same-ELF disabled/enabled roles expose
wrapper overhead. No parameter-mismatch test pretends default OriginalBin is
the correct mapping for a changed configuration. OriginalBin remains a pure
log/affine/floor/saturation component, not full guest Add semantics.

The frozen primary is 4,194,304 points in screening and 8,388,608 in confirmation,
not both sizes in each set. Within each set all roles use identical complete
prefixes; the requirement intentionally tests both lengths in separate orders.
All seven cycle corpora use the same declared N; repeated replay resets prevent
the Increasing benchmark from inheriting a calibrated/warm slot. Require actual
N/count checks in the eventual runner, as already anticipated by the freeze.

Preparation/model/input allocation is visible and untimed. Describe these as
cold-slot/prepared-model replays, not cold-start latency. A combined startup+
sequence scope or labelled break-even calculation may be added before freeze,
but the current scope must not be used to claim prep pays for itself in an
unknown application lifetime. No representative consuming SDK profile exists.

## Advancement rule and limits

The predeclared economic gate is >=10% Increasing gain versus BOTH direct and
same-ELF disabled roles, exploratory p<.05 in BOTH4M/8M sets. Every other corpus
rejects >2% slowdown against either control detected at p<.05 in both sets.
This is an explicit component-level experiment rule, not a blanket absence of
regression: smaller repeated losses, adverse medians and multiple comparisons
must still be reported. Broad/Negative cannot be omitted or bypassed; hot-only
results do not rescue failure. No tuned retries/capacity/width/policy or third
selected retiming follows a failed result.

A positive permits only a separate reviewed guest-integration ceiling spec.
It does not authorize a production cache/pass, new public API/ABI, checked
scalar/SQL/batch/stream claim, relaxed standalone guard, source-independent
eligibility, native arm64/big-endian claim, SDK inference or M1 acceptance.
All seven production gates plus integration and two unchanged all-three/runtime
proof reproductions remain required. No build/reviewer work overlaps samples.

Host tools stopped after this review; awaiting only the explicit specification
clarifications before a final READY/hash recheck.

## Final amended-specification audit

All three findings are resolved in the fully re-read amended source:

- The timed point-domain guard gives unsupported points, including exact1,
  zero proposals. Every eligible miss retries every uncertainty category up to
  the fixed five candidate requests. Failed/unsupported construction preserves
  the prior valid slot; fatal prepared-model/source failure stops replay. Query
  identity mismatch is uncertainty/zero hits, separately from model drift.
- Independent individual verification applies to all accepted fixed-bank and
  declared finite proof-driver traces. The universal native argument, subject
  to executable proof review, covers the timed on-demand proposals without a
  hidden online rational verifier.
- The <=16,384 capped numerical proof driver is explicitly separate from
  complete full-N lockstep result checking and qualified replay. Those runs
  record actual counts/digests. Timed hits perform no extra reference call;
  an output digest is checked after timing and does not replace the membership
  proof. Fixed-bank320 and per-replay5*N remain distinct unchanged limits.

Empty-slot/prepared-model scope is explicit and is not cold-start measurement.
All point-domain/refinement/proposal/fallback/install/reset work stays timed.
Screen4M/confirm8M, same-ELF disabled/enabled plus direct control, immutable
owned preparation, zero warmed native allocation, source/model/architecture
proof requirements, and >2% repeated corpus-loss rejection remain unchanged.
Smaller/single-set losses are now explicitly retained; explanatory reuse
break-even cannot replace measured complete replay or predict a full call.

No new host/public-contract hazard introduced by the amendments. Future current
parameter reads, memory/reply/reset checks, context/admission/ownership/epochs,
immediate poisoning and draining Close remain unchanged obligations. No tracked
source edit, implementation, build, test, profile or timing was performed for
this recheck. Final amended specification is READY before staging/signing;
host tools stopped.
