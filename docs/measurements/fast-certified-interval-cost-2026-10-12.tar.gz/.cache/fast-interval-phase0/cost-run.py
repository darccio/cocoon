"""Freeze sources first; isolated fresh-process observations; retain all rows."""
from pathlib import Path
import datetime, hashlib, json, os, platform, re, statistics, subprocess, sys
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'.cache/fast-interval-phase0'
GO=ROOT/'.cache/toolchains/go1.26.8/go/bin/go';ELF=OUT/'core-amd64.test'
SOURCE=ROOT/'examples/datadog/go/dd/internal/wasm/module.go'
ENV=dict(os.environ,GOROOT=str(GO.parent.parent),GOTOOLCHAIN='local',CGO_ENABLED='0',GOAMD64='v1',GOMAXPROCS='1',GOCACHE=str(ROOT/'.cache/go'),GOFLAGS='-buildvcs=false',GOWORK='off',GODEBUG='',GOEXPERIMENT='',GOGC='100',GOMEMLIMIT='off',COCOON_INTERVAL_SOURCE=str(SOURCE),COCOON_FAST_SOURCE=str(SOURCE),COCOON_FAST_INTERVAL_SOURCE=str(SOURCE),COCOON_FAST_INTERVAL_PROOF_SOURCE=str(SOURCE))
ENV['PATH']=str(GO.parent)+':'+ENV['PATH']
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def conditions():
 base=Path('/sys/devices/system/cpu')
 return {'utc':utc(),'uname':platform.uname()._asdict(),'cpu_policy':{str(p):p.read_text().strip() for pattern in ['cpu*/cpufreq/scaling_governor','cpufreq/boost','cpu*/cpufreq/scaling_cur_freq'] for p in sorted(base.glob(pattern))},'cpuinfo':Path('/proc/cpuinfo').read_text(),'loadavg':Path('/proc/loadavg').read_text(),'processes_pid_ppid_command_only':subprocess.check_output(['ps','-eo','pid,ppid,comm'],text=True)}
def verify(freeze):
 for filename,expected in freeze['sha256'].items():assert sha(Path(filename))==expected,filename
def execute(name,cmd,extra=None):
 env=dict(ENV,**(extra or {}))
 record={'name':name,'argv':list(map(str,cmd)),'started_utc':utc(),'env':{key:value for key,value in env.items() if key.startswith('COCOON_') or key in ['GOROOT','GOTOOLCHAIN','CGO_ENABLED','GOAMD64','GOMAXPROCS','GOFLAGS','GOWORK','GODEBUG','GOEXPERIMENT','GOGC','GOMEMLIMIT']}}
 with (OUT/'costs'/(name+'.log')).open('x') as log:
  print('COMMAND',json.dumps(record),file=log,flush=True)
  result=subprocess.run(cmd,cwd=OUT/'proof',env=env,stdout=log,stderr=subprocess.STDOUT)
  print('EXIT',result.returncode,file=log,flush=True)
 record.update(exit=result.returncode,completed_utc=utc(),raw='costs/'+name+'.log')
 with (OUT/'cost-command-records.jsonl').open('a') as log:log.write(json.dumps(record)+'\n')
 assert result.returncode==0,name
 return record,(OUT/record['raw']).read_text()
def main():
 mode=sys.argv[1];plan=json.loads((OUT/'cost-plan.json').read_text())
 if mode=='freeze':
  paths=[*sorted((OUT/'proof').rglob('*.go')),OUT/'proof/go.mod',OUT/'consumer_test.go',OUT/'consumer.mod',OUT/'consumer.sum',OUT/'cost-plan.json',OUT/'proof-run.py',OUT/'mutant-run.py',Path(__file__).resolve(),ROOT/'docs/fast-certified-interval-cost.md',GO]
  paths += [OUT/(scope+'-'+arch+'.test') for scope in ['core','reference','consumer'] for arch in ['amd64','386']]
  paths += [ROOT/p for p in json.loads((OUT/'proof-before.json').read_text())]
  paths += [OUT/('functional-replay-amd64-'+n+'.jsonl') for n in ['4194304','8388608']]
  for n in ['src/math/nextafter.go','src/math/big/rat.go','src/math/big/ratconv.go','doc/go_spec.html']:paths.append(GO.parent.parent/n)
  for n in ['compile','link','asm']:paths.append(GO.parent.parent/'pkg/tool/linux_amd64'/n)
  paths += sorted(OUT.glob('*implementation-review.md'))
  paths += [OUT/'compiler-observations.json',OUT/'finite-proof-ledger.json']
  frozen={'created_utc':utc(),'HEAD':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'go_version':subprocess.check_output([GO,'version'],text=True).strip(),'buildinfo':subprocess.check_output([GO,'version','-m',ELF],text=True),'plan':plan,'sha256':{str(p):sha(p) for p in paths}}
  assert 'go1.26.8' in frozen['go_version'];assert 'CGO_ENABLED=0' in frozen['buildinfo'];assert 'GOAMD64=v1' in frozen['buildinfo']
  (OUT/'frozen-spec.md').write_bytes((ROOT/'docs/fast-certified-interval-cost.md').read_bytes())
  (OUT/'cost-frozen.json').write_text(json.dumps(frozen,indent=2)+'\n');print('FROZEN',len(paths))
 elif mode=='run':
  frozen=json.loads((OUT/'cost-frozen.json').read_text());verify(frozen)
  (OUT/'costs').mkdir(exist_ok=False)
  (OUT/'measurement-before.json').write_text(json.dumps(conditions(),indent=2)+'\n')
  rows=[]
  for round_name in plan['rounds']:
   n=plan['prefixes'][round_name]
   for sample in range(7):
    scopes=plan['scopes'];shift=sample%len(scopes);scopes=scopes[shift:]+scopes[:shift]
    if round_name=='confirm':scopes=list(reversed(scopes))
    for scope in scopes:
     verify(frozen)
     selector='/'.join('^'+re.escape(part)+'$' for part in scope['benchmark'].split('/'))
     cmd=[ELF,'-test.run=^$','-test.bench='+selector,'-test.benchtime='+str(scope['iterations'])+'x','-test.benchmem','-test.count=1','-test.cpu=1','-test.timeout=10m']
     extra={'COCOON_FAST_REPLAY_N':str(n),'COCOON_FAST_REPLAY_EXPECTED':str(OUT/('functional-replay-amd64-'+str(n)+'.jsonl'))}
     record,raw=execute(f"{round_name}-{sample}-{scope['name']}",cmd,extra)
     lines=[line for line in raw.splitlines() if line.startswith('Benchmark')];assert len(lines)==1,lines
     fields=lines[0].split();assert int(fields[1])==scope['iterations'];assert '\nPASS\n' in raw
     metrics={fields[i+1]:float(fields[i]) for i in range(2,len(fields),2)}
     assert metrics['actual-procs']==1
     row=dict(record,round=round_name,sample=sample,scope=scope['name'],iterations=scope['iterations'],metrics=metrics,raw_row=lines[0]);rows.append(row)
     with (OUT/'cost-rows.jsonl').open('a') as log:log.write(json.dumps(row)+'\n')
     print(round_name,sample,scope['name'],metrics['ns/op'],flush=True)
  verify(frozen)
  (OUT/'measurement-after.json').write_text(json.dumps(conditions(),indent=2)+'\n')
  expected=len(plan['scopes'])*7*2;assert len(rows)==expected
  (OUT/'cost-complete.json').write_text(json.dumps({'completed_utc':utc(),'rows':expected,'ELF_sha256':sha(ELF)},indent=2)+'\n')
 elif mode=='memory':
  frozen=json.loads((OUT/'cost-frozen.json').read_text());verify(frozen)
  execute('memory-observations',[ELF,'-test.run=^TestFastCostMemory$','-test.v','-test.count=1','-test.cpu=1'])
 elif mode=='summarize':
  rows=[json.loads(line) for line in (OUT/'cost-rows.jsonl').read_text().splitlines()];assert len(rows)==len(plan['scopes'])*14
  summary={}
  for round_name in plan['rounds']:
   summary[round_name]={}
   for scope in plan['scopes']:
    values=[row for row in rows if row['round']==round_name and row['scope']==scope['name']];assert len(values)==7
    summary[round_name][scope['name']]={metric:{'median':statistics.median([v['metrics'][metric] for v in values]),'min':min(v['metrics'][metric] for v in values),'max':max(v['metrics'][metric] for v in values)} for metric in values[0]['metrics']}
  (OUT/'cost-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
 else:raise ValueError(mode)
if __name__=='__main__':main()
