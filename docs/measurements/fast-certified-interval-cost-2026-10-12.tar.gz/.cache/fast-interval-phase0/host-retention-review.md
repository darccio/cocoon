# Host retention review: fast certified interval cost no-go

Verdict: READY for evidence-only retention and packaging. The latest fast
performance section, roadmap/current state, readable measurement record, frozen
results and archive utility agree. No correctness, numerical reporting,
public-contract or scope blocker remains. Do not promote this fixed candidate
or alter policy/width/retry/capacity/bypass after its failed rule. M1 unaccepted.
This is a new result review; frozen implementation notes/source were untouched.
No compiler, benchmark, profile or test was executed during retention review.

## Independent raw-result audit

Parsed all546 raw rows: every exit0 and actualP1; 78 round/cell combinations,
exactly7 samples each. Independent medians of every available metric reproduce
cost-summary.json. All108 frozen source/spec/compiler/ELF/input identities still
match. Before/after all61 production fingerprints are byte-identical; old four
reference copies preserve their original hashes. Source preparation across all
rows has median144183165.5ns and41237552 allocatedB, range130364072..217359293ns,
matching the separate disclosed preparation figures.

Native accepted42 median895.5/927.1ns, evaluated rejection901.3/922.4ns,
early rejection287.9/287.8ns and native bank61399/61966ns match. Reference
accepted196301/204660ns and bank12625751/12920192ns are concrete unchanged
reference-API costs including their repeated binding work; native preparation
is once and visible. Full independent containment992355/1081053ns retains
its source/arithmetic work. Every individual warmed native candidate, lookup
and complete replay raw sample has0B/op and0alloc. Native bank always4864B/1alloc
is a retained negative, not a zero-allocation bank claim. Separate GC-disabled
observations match native bank4864, rational bank6349416, checker394480B;
no peakRSS/hard heap/stack guarantee follows.

Replay medians and all48 comparison deltas independently agree. There are47
unadjusted p=.001 and1 p=.004 (screen Increasing Enabled vsDisabled). Enabled
Increasing36.96/33.51ns versusDirect14.39/14.32 is +156.8450%/+134.0084%; its
screen disabled gain9.8756% fails the frozen10% requirement despite confirm
16.9311%. Repeated22.70/22.37 andNearby22.28/22.38 also lose toDirect about14ns,
although they beat the roughly40ns disabled wrapper. Disabled overhead is
properly explicit. Every non-primary corpus triggers repeated >2% Direct loss;
Unique/MostlyUnique/Phases/Broad/Negative also trigger Disabled loss. Broad
841.6/840.6 andNegative796.1/798.1ns support the prominent miss/churn negatives.
The economic no-go is not a comparison solely against a slow shape control.

Component O-H is -16.37/-16.68ns with the declared direct-Repeated loop and
standalone lookup scopes. The document correctly narrows this to no favorable
finite count in THESE scopes, discloses differing argument/loop/call shapes,
and uses complete replay for the decision. It does not add independent medians
into a guest/full-call prediction, infer universal lower bounds, or hide model
startup/retention behind zero hot allocation.

## Numerical, replay, and lifecycle scope

Finite native ledger is15908/16384 with exactly documented parts on botharches:
611+12431+16+2553+260+29+8. Tiny114 is also chargedwhole andWasm521 requests
have finite stateful bin/Count/full-protobuf evidence. All-four-corner independent
prior-bound containment, all57 fixed-bank traces, native source/program/ownership
checks and compiled numerical faults are scoped correctly. Numerical proof does
not acquire production cache/guest-integration authority. Model4208/4204B,
bank+encoding2814/2554B, maxexport+workspace56240/53152B and slot104B match
finite reports. Separate source/program pins and snapshots byvalue support legal
immutable ownership, not unsafe mutation or future current-parameter hoisting.

All32 full-prefix summaries independently reconcile inputs/hits/misses/install/
fallback/refinement/reason totals, proposal<=5N, reset1 andfatal0. Architecture
pairs have identical digests/counters. Eight corpora*(4194304+8388608)=100663296
inputs/arch matches; this is explicitly distinct from the capped finite proof
and performs no millions-of-Wasm-history claim. OriginalCalls=N direct/disabled,
enabledOriginalCalls=Fallbacks agree. A hit is not a successful new construction:
Increasing prior-slot hits4146509/8330765=98.860478%/99.310458%, with78577/112262
proposals and5950/11611 fallbacks. Broad zero hits with4387840/8775680 proposals;
Negative zero hits with4194304/8388608 proposals but0fallbacks. Both can install
correct new certificates repeatedly with no reuse, exactly the documented
wasted-next-input case. Repeated/Nearby have one initial install and N-1 hits;
'perfect reuse' is the limiting behavior, not a literal zero-cold-miss claim.

Actual current-memory constructor read, ownership/generation/occupied checks,
ownedtuple/Count/protobuf observations and all corpus byte checks remain proof
fixtures. No slice/view/store pointer is stored by the model/slot. All production
per-operation memory/reset/reply, admission/context/ownership/epochs, immediate
poison and drainingClose behavior remains unchanged. No checked scalar/SQL/
batch/stream latency or representativeSDK/nativearm64/big-endian claim appears.
Streaming1.353/10.050M andholdout1.514/10.466M are explicitly historical P16
one/sixteen-home observed write rates from structural controls, not new runs,
causal gains or hard capacity ceilings.

## Documentation and archive utility

The stale track2 forward instruction to test the same fast constructor has been
corrected to completed proof/no-go and a materially different reviewed question.
Main resume, track5 and historical cross-links now agree. The new wording
preserves the original source logarithm and promises no NEW approximation,
reassociation or ideal mathematical-ln equivalence. Specification checkpoint
remains byte-identical to its signed pre-implementation version.

Reviewed archive.py (hash below) read-only: allowed suffixes retain private
sources/generated output/journals/raw rows/statistics/reviews/logs; caches and
ELFs are excluded. Paths are checked relative/non-parent; tar entries regular,
unique and set-equal to MANIFEST. Exact per-member length/SHA and reread audit,
deterministic member metadata/gzip, exclusive target creation and sidecar SHA
support packaging. It checks546 rows andM1false. Final tar payload/sidecar cannot
be audited until the parent actually packages it; no claim that this already
occurred is made here. The readable record accurately describes omitted ELFs/
caches and relocatable absolute historical paths. Root retains exact staging/
gate and reproduction responsibilities before signed evidence commit.

## Latest read identities

```json
{
  "docs/performance.md": "32e847623dad3e4e482c65d75e095d7dfb84d3f2582da0fae36c57d3f98bf7d5",
  "docs/roadmap.md": "017de2e8e688f9f37c9c09c95173f5802335e680064a73db90735b9b22d2a82f",
  "docs/measurements/fast-certified-interval-cost-2026-10-12.md": "4655f5eceb36796b18c8b553045bf7ee0e962f5e5653fd7fe48e15d2ff05fee9",
  ".cache/fast-interval-phase0/archive.py": "82efe67c5253e91aea5007c6e8cfe5b29dd49f3c8ca1cc71aa17033b9ba922d2"
}
```

READY. Retain evidence only; no source changes requested. Host tools stopped.
