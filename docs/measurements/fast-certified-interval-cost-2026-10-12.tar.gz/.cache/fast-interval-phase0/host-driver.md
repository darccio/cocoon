# Authored host policy and measurement harness

This ignored implementation follows signed private specification45d50ac. Owned
files: `proof/cache.go`, `proof/replay_test.go`, `proof/cost_test.go`, and
`consumer_test.go`. No production/generated/Wasm/lock or earlier proof source
changed. Exact focused command logs are `host-command-records.jsonl` and
`host-functional-1.log`; official Go1.26.8 CGO0/PGOoff policy, corpus, counter
overflow and zero warmed allocation checks passed. Root owns final both-native
proof builds, all full-prefix checks, final reviews/freeze, and isolated timing.

## Fixed simulation

OneSlot owns model pointer and copied identity/certificate metadata, no guest
view/address or resource. Model is independently prepared, private and immutable;
the caller's mutable graph and returned snapshot do not alias it. Numeric model
storage has16KiB cap, slot metadata4KiB, request scratch64KiB independently.
Legal callers cannot corrupt private model arrays. Prepared-model integrity and
query identities precede membership; point-domain tests occur only after miss.

Unsupported points, including exact1, bypass zero proposals with exact original
mapping; this pure mapping return is not a guest no-bin/Count contract. Every
eligible miss tries widths40..36 on each uncertainty category, stopping only on
acceptance or fatal model failure. Five failed requests leave the prior slot
unchanged. Accepted requests replace one slot and return the center's certified
bin. Full compiled OriginalBin runs on every unresolved miss. No eviction sweep,
backoff, negative memo, guessed bin, clipping or configuration-specific fallback.
Mismatched configurations/source are lookup/constructor test cases only.

MapMode is shared by Disabled/Enabled; the boolean is runtime data in one ELF.
Both modes pay the shared model/query identity guard. Disabled invokes full
original mapping without domain lookup, proposals or install. Direct invokes
unchanged full OriginalBin in the same input/digest loop. Optional checked
counters exist only for functional replay; timed loops pass nil. Native request
trace is nil in simulation, meaning the core's necessary fixed interval array
is transient/internal and fully paid, with no external diagnostic observation.
Counted replay pays the same native enclosure algorithm, not an online rational
verifier. Every meaningful lookup/proposal/fallback/install/reset stays timed.

## Mathematical consumer proof

TestFastIntervalHostProof retains the existing ownership-bound current-memory
constructor read: lifecycle→Resource.Use→Instance.Call; full source pin and
source fixture literals; slot index/count, generation/occupied, widened address,
current logical length, before/after complete memory hash. Returned four words
and constructor protobuf are owned; no slice escapes across guest operations.
Count0 and encoded gamma/offset bind the actual default constructor. No new
resource API or generic layout promise follows from this private fixture read.

Every accepted native fixed-bank trace passes the independent exact-rational
containment adapter using verified claimed prior bounds. The observer retains
one trace only and includes JSON export capacity plus complete builder workspace
under64KiB. Complete native bank/encoding includes fixed array capacity/padding.
All fixed64 seed/refinement outcomes are audited without selection/retuning.
Actual source/program/model and all7 copied corpora independently bind to the
unchanged authored DD input generator and originalWasm.

Nine points per accepted certificate preserve endpoints, neighbors, midpoint,
quarters/eighths and fresh originalWasm singleton bin/Count/full protobuf.
Each native scalar witness charges three evaluations: reference graph Point,
full original source Log, and full original source Bin. Two adjacent members
per certificate consume tiny AND whole counts. OriginalWasm requests each count
whole as well. Independent primitive checker witnesses are supplied by the
separate adversarial driver; the host does not duplicate its every-exponent set.

Host consumer cap3000 whole/262144 tiny/2048Wasm. With57 native certificates and
92 attempts, expected consumer is2553 whole/114tiny/521Wasm, including two binding
charges. Actual emitted summary controls the final number, not this estimate.
Separate finite policy test uses29 kernels (6 candidates,23 full OriginalBin).
Warm allocation fixture uses95 setup kernels (1Certify +1Verify +92bank requests
+1slotMap Certify); AllocsPerRun32 plus framework warm-up uses132 native candidates
and33OriginalBin calls, giving260. Root combines guest/reference/adversarial,
host and selected-mutant counts before final qualification; unchanged16K cap.
Single-operation allocation observations and measured cost/replay calls have
their explicit independent scopes and are not hidden finite-proof selection.

## Complete output checks and timed prefixes

TestFastFullReplay is opt-in via COCOON_FAST_REPLAY_N=4194304 or8388608 and
COCOON_FAST_REPLAY_OUTPUT points to a fresh JSONL file. All8 corpora run lockstep
with direct full source, disabled and enabled for EVERY input. This separately
declared large ledger records actual input/proposal/refinement/reason/install/
fallback/phase counts and digests; it is not the capped mathematical proof
driver and does not call the rational verifier for online proposals. Each full
sequence starts empty; unsupported points and failed proposals preserve old
slots exactly. Counters have uint64 overflow guards and final reconciliation.

BenchmarkFastNumericReplay/<Direct|Disabled|Enabled>/<corpus> requires1x,
COCOON_FAST_REPLAY_N and COCOON_FAST_REPLAY_EXPECTED identifying the prevalidated
matching architecture/prefix/corpus JSONL. Every role prepares the owned model
and input before timing with separate source-model preparation ns/allocatedB.
Timer includes empty reset and allN outputs. Increasing is exactly1..N, not an
adaptive warmed prefix; other corpora cycle8192 unchanged values. Only rolling
digest is computed in timed hit paths, checked after StopTimer; no extra original
calculation is charged to a certified hit. Digests establish consistency and
do not replace universal membership proof. No startup amortization claim.

## Fifteen primitive/cost scopes

BenchmarkFastCost/<Native|Reference>/<Accepted42|RejectedCell2|RejectedBoundary|BankConstruct>
BenchmarkFastCost/ContainmentChecker
BenchmarkFastCost/Lookup/<SlotHit|SlotMiss|SlotMismatch|BankFirstHit|BankLastHit|BankMiss>

Native individual requests use nil observed trace; the core still computes its
necessary internal fixed node intervals. Reference requests preserve the old
API including graph/source validation and returned trace. Native model
preparation/validation is once and separately observed, so these are concrete
API scopes rather than an isolated language/arithmetic comparison. Checker
retains full required source/node binding. BankConstruct has no independent
observer, with its actual allocations retained separately; only individual
candidate/lookup warmed scopes are hard zero-allocation criteria.

Before timing all cost fixtures independently verify the accepted42 witness,
prepare native bank and one-slot42. First/last lookup selects endpoint of the
first/last frozen native certificate; bin AND hit/reason are asserted. Unknown
cell/boundary costs use unchanged seeds3/16. Required runner requests: native
individual65536x, reference512x (cell65536x), bank16x, checker128x, lookup1048576x.
Root freezes all final exact counts and names before any measurements.

All actual measured leaves enforce processP1 immediately before ResetTimer and
after StopTimer, then report actual-procs. Driver MUST use -test.cpu=1 and
GOMAXPROCS=1; the suffix/default environment is no substitute. OfficialGo1268,
CGO0/PGOoff, all exact paths/bytes/tool identities and matrices freeze before
timing; reviewers/builds/lint/tests/profiles/memory observations stop during it.

TestFastCostMemory separately observes15 one-operation scopes with GC disabled
after explicitGC, before/after/collected MemStats and logical model/slot/workspace.
Source/model preparation is separately visible and outside each operation.
End-of-operation heap, forcedGC deltas and zero warmed allocation imply no peak
RSS, hard Go heap, stack or process-memory guarantee.

No source-independent eligibility, guest integration, checked facade latency,
scalar/SQL/batch/stream benefit, SDK applicability, public API/ABI or M1 acceptance
is claimed. Final advancement remains the signed complete replay rule; failures
park this exact candidate without tuning.
