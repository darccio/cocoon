"""Execute compiled numerical faults; startup/compiler failures never count."""
from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'.cache/fast-interval-phase0'
ARCH=sys.argv[1]
assert ARCH in ['amd64','386']
ELF=OUT/('core-'+ARCH+'.test')
mutants=['inward-bounds','signed-extrema','strict-upper','negative-floor','carry-wrap','generated-operand','wrong-bin','wrong-config','budget-unknown']
records=[]
for mutant in mutants:
 name='mutant-'+ARCH+'-'+mutant
 argv=[str(ELF),'-test.run=^TestAdversarialSelectedNumericalMutant$','-test.count=1','-test.v','-test.timeout=30s']
 env=dict(os.environ,GOMAXPROCS='1',COCOON_FAST_MUTANT=mutant,COCOON_INTERVAL_SOURCE=str(ROOT/'examples/datadog/go/dd/internal/wasm/module.go'))
 record={'name':name,'architecture':ARCH,'mutant':mutant,'argv':argv,'ELF_sha256':hashlib.sha256(ELF.read_bytes()).hexdigest(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'expected_exit':1,'required_marker':'NUMERICAL_MUTANT '+mutant}
 with (OUT/(name+'.log')).open('x') as log:
  print('COMMAND',json.dumps(record),file=log,flush=True)
  result=subprocess.run(argv,cwd=OUT/'proof',env=env,stdout=log,stderr=subprocess.STDOUT)
  print('EXIT',result.returncode,file=log,flush=True)
 text=(OUT/(name+'.log')).read_text()
 record.update(exit=result.returncode,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),numerical_marker_seen=('    adversarial_test.go:' in text and record['required_marker'] in text),assertion_failure_seen='--- FAIL: TestAdversarialSelectedNumericalMutant' in text)
 records.append(record)
 (OUT/('mutant-records-'+ARCH+'.json')).write_text(json.dumps(records,indent=2)+'\n')
 assert record['exit']==1 and record['numerical_marker_seen'] and record['assertion_failure_seen'],name
 print('CAUGHT',ARCH,mutant,flush=True)
