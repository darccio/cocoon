"""Separate pre-timing machine inspection and generator reproduction."""
from pathlib import Path
import hashlib,json,os,re,subprocess
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'.cache/fast-interval-phase0'
GO=ROOT/'.cache/toolchains/go1.26.8/go/bin/go'
ENV=dict(os.environ,GOROOT=str(GO.parent.parent),GOTOOLCHAIN='local',CGO_ENABLED='0',GOAMD64='v1',GOCACHE=str(ROOT/'.cache/go'),GOFLAGS='-buildvcs=false',GOWORK='off',GOMAXPROCS='1')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
records={}
for arch in ['amd64','386']:
 elf=OUT/('core-'+arch+'.test')
 build=subprocess.check_output([GO,'version','-m',elf],text=True,env=ENV)
 nm=subprocess.check_output([GO,'tool','nm','-size',elf],text=True,env=ENV)
 (OUT/('compiler-'+arch+'-buildinfo.txt')).write_text(build)
 (OUT/('compiler-'+arch+'-symbols.txt')).write_text(nm)
 selected={}
 for symbol in ['transfer','rounded','runUnrolled','certify','buildBank','OriginalLog','OriginalBin']:
  expression=r'cocoonfastintervalproof(?:/reference)?\.'+symbol+'$'
  asm=subprocess.check_output([GO,'tool','objdump','-s',expression,elf],text=True,env=ENV)
  (OUT/('compiler-'+arch+'-'+symbol+'.txt')).write_text(asm)
  sizes=[line for line in nm.splitlines() if re.search(expression,line.split()[-1])]
  selected[symbol]={'symbols':sizes,'objdump_lines':len(asm.splitlines()),'explicit_fp_op_counts':{op:len(re.findall(r'\b'+op+r'\b',asm)) for op in ['ADDSD','SUBSD','MULSD','DIVSD','VFMADD132SD','VFMADD213SD','VFMADD231SD']}}
 records[arch]={'ELF_sha256':sha(elf),'selected':selected}
source=ROOT/'examples/datadog/go/dd/internal/wasm/module.go'
generated=OUT/'native-regenerated.go.txt'
argv=[GO,'run','-pgo=off','./cmd/generate-native','-source',source,'-output',generated]
with (OUT/'native-regeneration.log').open('x') as log:
 result=subprocess.run(argv,cwd=OUT/'proof',env=ENV,stdout=log,stderr=subprocess.STDOUT)
assert result.returncode==0
assert generated.read_bytes()==(OUT/'proof/native_generated.go').read_bytes()
records['regeneration']={'argv':list(map(str,argv)),'exit':result.returncode,'generated_sha256':sha(generated),'byte_identical':True}
for name,expected in json.loads((OUT/'reference-copy.json').read_text()).items():assert sha(OUT/name)==expected,name
for name,expected in json.loads((OUT/'proof-before.json').read_text()).items():assert sha(ROOT/name)==expected,name
records['unchanged_original_reference_files']=4
records['unchanged_production_fingerprints']=61
(OUT/'compiler-observations.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps(records,indent=2))
