"""Journal private builds and actual native numerical proof, never timing."""
from pathlib import Path
import datetime, json, os, subprocess, sys
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'.cache/fast-interval-phase0'
GO=ROOT/'.cache/toolchains/go1.26.8/go/bin/go'
SOURCE=ROOT/'examples/datadog/go/dd/internal/wasm/module.go'
ENV=dict(os.environ,GOROOT=str(GO.parent.parent),GOTOOLCHAIN='local',CGO_ENABLED='0',GOAMD64='v1',GOCACHE=str(ROOT/'.cache/go'),GOFLAGS='-buildvcs=false',GOMAXPROCS='1',GOWORK='off',COCOON_INTERVAL_SOURCE=str(SOURCE),COCOON_INTERVAL_PROOF_SOURCE=str(SOURCE),COCOON_FAST_SOURCE=str(SOURCE),COCOON_FAST_INTERVAL_SOURCE=str(SOURCE),COCOON_FAST_INTERVAL_PROOF_SOURCE=str(SOURCE))
ENV['PATH']=str(GO.parent)+':'+ENV['PATH']
def run(name,cmd,cwd,extra=None):
 env=ENV if extra is None else dict(ENV,**extra)
 record={'name':name,'argv':list(map(str,cmd)),'cwd':str(cwd),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'env':{key:value for key,value in env.items() if key.startswith('COCOON_') or key in ['GOROOT','GOTOOLCHAIN','CGO_ENABLED','GOAMD64','GOARCH','GOFLAGS','GOCACHE','GOMAXPROCS','GOWORK']}}
 with (OUT/(name+'.log')).open('x') as log:
  print('COMMAND',json.dumps(record),file=log,flush=True)
  result=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
  print('EXIT',result.returncode,file=log,flush=True)
 record.update(exit=result.returncode,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 with (OUT/'proof-command-records.jsonl').open('a') as journal:journal.write(json.dumps(record)+'\n')
 print(name,'EXIT',result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
def main():
 mode=sys.argv[1]
 if mode=='build':
  prefix=('build-'+sys.argv[2]+'-') if len(sys.argv)>2 else 'build-'
  overlay={'Replace':{str(ROOT/'examples/datadog/go/dd/phase0_fast_interval_consumer_test.go'):str(OUT/'consumer_test.go')}}
  (OUT/'consumer-overlay.json').write_text(json.dumps(overlay,indent=2)+'\n')
  for arch in ['amd64','386']:
   for scope,pkg in [('core','.'),('reference','./reference')]:
    run(prefix+scope+'-'+arch,[GO,'test','-pgo=off','-c','-o',OUT/(scope+'-'+arch+'.test'),pkg],OUT/'proof',{'GOARCH':arch})
   run(prefix+'consumer-'+arch,[GO,'test','-pgo=off','-modfile='+str(OUT/'consumer.mod'),'-overlay='+str(OUT/'consumer-overlay.json'),'-c','-o',OUT/('consumer-'+arch+'.test'),'./examples/datadog/go/dd'],ROOT,{'GOARCH':arch})
 elif mode in ['amd64','386']:
  prefix='proof-'+(sys.argv[2]+'-' if len(sys.argv)>2 else '')
  for scope in ['core','reference']:
   run(prefix+scope+'-'+mode,[OUT/(scope+'-'+mode+'.test'),'-test.run=^Test','-test.skip=FullReplay|CostMemory','-test.v','-test.count=1','-test.timeout=10m'],OUT/'proof')
  run(prefix+'consumer-'+mode,[OUT/('consumer-'+mode+'.test'),'-test.run=^TestFastIntervalHostProof$','-test.v','-test.count=1','-test.timeout=10m'],ROOT/'examples/datadog/go/dd',{'COCOON_FAST_INTERVAL_PROOF_OUTPUT':str(OUT/(prefix+'consumer-'+mode+'.jsonl'))})
 elif mode=='replay':
  arch=sys.argv[2];n=sys.argv[3]
  assert arch in ['amd64','386'] and n in ['4194304','8388608']
  run('functional-replay-'+arch+'-'+n,[OUT/('core-'+arch+'.test'),'-test.run=^TestFastFullReplay$','-test.v','-test.count=1','-test.timeout=30m'],OUT/'proof',{'COCOON_FAST_REPLAY_N':n,'COCOON_FAST_REPLAY_OUTPUT':str(OUT/('functional-replay-'+arch+'-'+n+'.jsonl'))})
 else:raise ValueError(mode)
if __name__=='__main__':main()
